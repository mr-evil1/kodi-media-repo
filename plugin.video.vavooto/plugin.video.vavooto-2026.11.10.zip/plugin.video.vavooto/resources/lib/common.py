import json
import os
import re
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = 'plugin.video.vavooto'
ADDON = xbmcaddon.Addon(ADDON_ID)
NAME = 'Vavoo'

PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
MEDIA = os.path.join(PATH, 'resources', 'skins', 'Default', 'media')
COUNTRY = os.path.join(PATH, 'resources', 'country')
FANART = os.path.join(PATH, 'fanart.jpg')
ICON = os.path.join(PATH, 'icon.png')
CACHE_DIR = os.path.join(PROFILE, 'cache')

_BB_CODE = re.compile(r'\[/?[A-Za-z]{1,12}(?:=[^\]]{0,30})?\]')

def _ensure_dirs():
    for path in (PROFILE, CACHE_DIR):
        try:
            if not os.path.isdir(path):
                os.makedirs(path)
        except OSError:
            pass

_ensure_dirs()

def setting(key, default=''):
    try:
        value = ADDON.getSetting(key)
    except Exception:
        return default
    return value if value not in ('', None) else default

def setting_bool(key, default=False):
    value = setting(key, 'true' if default else 'false')
    return str(value).strip().lower() == 'true'

def setting_int(key, default=0):
    try:
        return int(setting(key, str(default)))
    except (TypeError, ValueError):
        return default

def german_only():
    return setting_int('vod_language', 0) == 1

def log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log('[Vavoo] %s' % message, level)
    except Exception:
        pass

def log_exception():
    log(traceback.format_exc(), xbmc.LOGERROR)

def notify(title, message, icon=None, millis=4000):
    try:
        xbmcgui.Dialog().notification(title, message, icon or ICON, millis)
    except Exception:
        pass

def media(name):
    path = os.path.join(MEDIA, name)
    return path if os.path.isfile(path) else ''

def flag(code):
    code = (code or 'zz').lower()
    path = os.path.join(COUNTRY, code + '.png')
    if os.path.isfile(path):
        return path
    fallback = os.path.join(COUNTRY, 'zz.png')
    return fallback if os.path.isfile(fallback) else ''

def clean(text, limit=0):

    if not text:
        return ''
    text = _BB_CODE.sub('', str(text))
    text = re.sub(r'\s+', ' ', text).strip()
    if limit and len(text) > limit:
        text = text[:limit - 3].rstrip() + '...'
    return text

def cache_path(name):
    return os.path.join(CACHE_DIR, name)

def read_cache(name):
    try:
        with open(cache_path(name), 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None

def write_cache(name, data):
    path = cache_path(name)
    tmp = path + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        log_exception()

def clear_cache():
    try:
        for entry in os.listdir(CACHE_DIR):
            target = os.path.join(CACHE_DIR, entry)
            if os.path.isfile(target):
                os.remove(target)
    except OSError:
        log_exception()

def version():
    try:
        return ADDON.getAddonInfo('version')
    except Exception:
        return '4.1.24'
