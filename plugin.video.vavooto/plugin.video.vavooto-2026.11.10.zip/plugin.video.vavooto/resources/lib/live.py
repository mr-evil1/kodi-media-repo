import json
import re
import threading
import time
import urllib.parse
from datetime import datetime, timezone

import common
import net

LIVE_UA = 'TiviMate/5.0.0 (Linux; Google TV)'
GEIL_UA = ('Mozilla/5.0 (Linux; Android 14; SM-G998B Build/UP1A.231005.007; wv) '
           'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 '
           'Chrome/156.0.8078.47 Mobile Safari/537.36')

_HEADERS = {
    'User-Agent': LIVE_UA,
    'Accept': 'application/json',
    'Accept-Charset': 'UTF-8',
    'Content-Type': 'application/json',
}

_GEIL_HEADERS = {
    'User-Agent': GEIL_UA,
    'Accept': 'application/json',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'de-AT,de;q=0.9,en-US;q=0.8,en;q=0.7',
    'X-Requested-With': 'net.vypn.app',
    'Connection': 'keep-alive',
}

_KNOWN_PORTALS = {
    'oha.to': {'prefix': '/mediaurl-', 'region': 'DE', 'discovery': '/mediaurl.json', 'api': 'vavoo'},
    'huhu.to': {'prefix': '/mediaurl-', 'region': 'DE', 'discovery': '/mediaurl.json', 'api': 'vavoo'},
    'kool.to': {'prefix': '/mediahubmx-', 'region': 'AT', 'discovery': '/mediahubmx.json', 'api': 'vavoo'},
    'vavoo.top': {'prefix': '/mediahubmx-', 'region': 'XX', 'discovery': '/mediahubmx.json', 'api': 'vavoo'},
    'vavoo.net': {'prefix': '/mediahubmx-', 'region': 'XX', 'discovery': '/mediahubmx.json', 'api': 'vavoo'},
    'geil.to': {'region': 'AT', 'api': 'geil'},
}

GROUP_INFO = {
    'germany': ('Deutschland', 'de'),
    'deutschland': ('Deutschland', 'de'),
    'austria': ('Österreich', 'at'),
    'oesterreich': ('Österreich', 'at'),
    'switzerland': ('Schweiz', 'ch'),
    'schweiz': ('Schweiz', 'ch'),
    'turkey': ('Türkei', 'tr'),
    'tuerkei': ('Türkei', 'tr'),
    'denmark': ('Dänemark', 'dk'),
    'daenemark': ('Dänemark', 'dk'),
    'sports international': ('Sport International', 'eu'),
    'sport international': ('Sport International', 'eu'),
    'albania': ('Albanien', 'al'),
    'albanien': ('Albanien', 'al'),
    'arabia': ('Arabien', 'ae'),
    'arabisch': ('Arabien', 'ae'),
    'azerbaijan': ('Aserbaidschan', 'az'),
    'balkans': ('Balkan', 'rs'),
    'balkan': ('Balkan', 'rs'),
    'bulgaria': ('Bulgarien', 'bg'),
    'bulgarien': ('Bulgarien', 'bg'),
    'france': ('Frankreich', 'fr'),
    'frankreich': ('Frankreich', 'fr'),
    'netherlands': ('Niederlande', 'nl'),
    'niederlande': ('Niederlande', 'nl'),
    'poland': ('Polen', 'pl'),
    'polen': ('Polen', 'pl'),
    'romania': ('Rumänien', 'ro'),
    'rumaenien': ('Rumänien', 'ro'),
    'portugal': ('Portugal', 'pt'),
    'italy': ('Italien', 'it'),
    'italien': ('Italien', 'it'),
    'belgium': ('Belgien', 'be'),
    'belgien': ('Belgien', 'be'),
    'united kingdom': ('England', 'gb'),
    'england': ('England', 'gb'),
    'greece': ('Griechenland', 'gr'),
    'griechenland': ('Griechenland', 'gr'),
    'russia': ('Russland', 'ru'),
    'russland': ('Russland', 'ru'),
    'spain': ('Spanien', 'es'),
    'spanien': ('Spanien', 'es'),
    'sweden': ('Schweden', 'se'),
    'schweden': ('Schweden', 'se'),
    'iran': ('Iran', 'ir'),
    'usa': ('USA', 'us'),
    'united states': ('USA', 'us'),
    'canada': ('Kanada', 'ca'),
    'kanada': ('Kanada', 'ca'),
    'india': ('Indien', 'in'),
    'indien': ('Indien', 'in'),
    'pakistan': ('Pakistan', 'pk'),
    'serbia': ('Serbien', 'rs'),
    'serbien': ('Serbien', 'rs'),
    'croatia': ('Kroatien', 'hr'),
    'kroatien': ('Kroatien', 'hr'),
    'slovenia': ('Slowenien', 'si'),
    'slowenien': ('Slowenien', 'si'),
    'slovakia': ('Slowakei', 'sk'),
    'slowakei': ('Slowakei', 'sk'),
    'czech republic': ('Tschechien', 'cz'),
    'tschechien': ('Tschechien', 'cz'),
    'hungary': ('Ungarn', 'hu'),
    'ungarn': ('Ungarn', 'hu'),
    'ukraine': ('Ukraine', 'ua'),
    'mexico': ('Mexiko', 'mx'),
    'mexiko': ('Mexiko', 'mx'),
    'brazil': ('Brasilien', 'br'),
    'brasilien': ('Brasilien', 'br'),
    'argentina': ('Argentinien', 'ar'),
    'australia': ('Australien', 'au'),
    'australien': ('Australien', 'au'),
    'netherlands antilles': ('Niederlande', 'nl'),
}

GROUP_ORDER = [
    'germany', 'deutschland', 'austria', 'oesterreich', 'switzerland', 'schweiz',
    'turkey', 'tuerkei', 'denmark', 'daenemark', 'sports international',
    'sport international', 'albania', 'albanien', 'balkans', 'balkan',
    'bulgaria', 'bulgarien', 'france', 'frankreich', 'netherlands',
    'niederlande', 'poland', 'polen', 'romania', 'rumaenien', 'portugal',
    'italy', 'italien', 'belgium', 'belgien', 'united kingdom', 'england',
    'greece', 'griechenland', 'russia', 'russland', 'spain', 'spanien',
    'sweden', 'schweden', 'iran',
]

_QUALITY_SUFFIX = re.compile(
    r'\s*(\((?:SD|HD|FHD|UHD|H265|BACKUP|\d+)\)|\b(?:SD|HD|FHD|UHD|H265)\b)\s*$',
    re.IGNORECASE,
)

class LiveError(Exception):
    pass

def _normalise_url(url):
    url = (url or '').strip().rstrip('/')
    if not url:
        return ''
    if 'vavoo.to' in url:
        url = 'http://geil.to'
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    return url

def _detect_portal(base_url, timeout):
    lowered = base_url.lower()
    for domain, cfg in _KNOWN_PORTALS.items():
        if domain in lowered:
            return dict(cfg)
    for discovery, prefix, region in [
        ('/mediaurl.json', '/mediaurl-', 'DE'),
        ('/mediahubmx.json', '/mediahubmx-', 'DE'),
    ]:
        try:
            response = net.post(
                base_url + discovery, data='{}', headers=_HEADERS, timeout=timeout)
            if response.status_code == 200 and 'catalogs' in response.text:
                return {'prefix': prefix, 'region': region,
                        'discovery': discovery, 'api': 'vavoo'}
        except Exception:
            continue
    return {'prefix': '/mediaurl-', 'region': 'DE',
            'discovery': '/mediaurl.json', 'api': 'vavoo'}

class LiveClient(object):

    def __init__(self, portal_url=None, timeout=25):
        self.portal = _normalise_url(portal_url or common.setting('live_portal', 'geil.to'))
        self._timeout = timeout
        self._epg_cache = {}
        cfg = _detect_portal(self.portal, timeout)
        self._api = cfg.get('api', 'vavoo')
        self._region = cfg.get('region', 'DE')
        self._prefix = cfg.get('prefix', '/mediaurl-')
        self._discovery = cfg.get('discovery', '/mediaurl.json')

    def _path(self, name):
        return self.portal + self._prefix + name + '.json'

    def _post(self, url, payload):
        url_t = url + '?_t=%d' % int(time.time() * 1000)
        response = net.post(
            url_t,
            data=json.dumps(payload, separators=(',', ':')),
            headers=_HEADERS,
            timeout=self._timeout,
        )
        response.raise_for_status()
        return response.json()

    def _build_payload(self, cursor=None, adult=True):
        return {
            'language': 'de', 'region': self._region,
            'catalogId': 'iptv', 'id': '',
            'adult': adult, 'search': '',
            'sort': 'trending-region',
            'filter': {}, 'cursor': cursor,
            'clientVersion': '3.1.0',
        }

    def _geil_catalog_url(self, cursor=None):
        url = ('%s/live/catalog/live/channels.json?region=%s&language=de&sort=trending'
               % (self.portal, self._region))
        if cursor is not None:
            url += '&cursor=%s' % cursor
        return url

    def _geil_get(self, url, timeout=None):
        response = net.get(url, headers=_GEIL_HEADERS,
                           timeout=timeout or self._timeout)
        response.raise_for_status()
        return response.json()

    def get_epg(self, name, group=''):

        name = (name or '').strip()
        if not name or self._api != 'geil':
            return None
        cache_key = '%s|%s' % (_fold(channel_key(name)), _fold(group))
        cached = self._epg_cache.get(cache_key)
        if cached and time.time() - cached[0] < 20:
            return [dict(entry) for entry in cached[1]]

        url = (self._geil_catalog_url() + '&search=' +
               urllib.parse.quote(name, safe=''))
        try:
            data = self._geil_get(url, timeout=min(self._timeout, 12))
        except Exception as error:
            common.log('EPG-Abfrage fehlgeschlagen: %s' % error)
            return None
        items = (data.get('items') or []) if isinstance(data, dict) else []
        wanted = _fold(channel_key(name))
        matches = [item for item in items
                   if isinstance(item, dict) and
                   _fold(channel_key(item.get('name'))) == wanted]
        if group:
            grouped = [item for item in matches
                       if _fold(item.get('group') or
                                ((item.get('tags') or [''])[0])) == _fold(group)]
            matches = grouped or matches
        programs = []
        for item in matches:
            programs = _normalise_epg(item.get('epg'))
            if programs:
                break
        self._epg_cache[cache_key] = (time.time(), programs)
        return [dict(entry) for entry in programs]

    def test_connection(self):
        if self._api == 'geil':
            try:
                data = self._geil_get(self._geil_catalog_url())
                return isinstance(data, dict) and 'items' in data
            except Exception:
                return False
        try:
            data = self._post(self._path('catalog'), self._build_payload())
        except Exception:
            return False
        return isinstance(data, dict) and 'items' in data

    def get_all_channels(self, adult=True, progress_callback=None):
        if self._api == 'geil':
            return self._geil_get_all_channels(progress_callback)
        return self._vavoo_get_all_channels(adult, progress_callback)

    def _collect_pages(self, fetcher, progress_callback=None):
        pages = {}
        lock = threading.Lock()
        threads = []
        total_count = [0]

        def fetch_page(cursor, slot):
            try:
                items, next_cursor = fetcher(cursor)
            except Exception:
                items, next_cursor = [], None
            with lock:
                pages[slot] = items
                total_count[0] += len(items)
                if next_cursor is not None:
                    thread = threading.Thread(
                        target=fetch_page, args=(next_cursor, slot + 1))
                    thread.daemon = True
                    threads.append(thread)
                    thread.start()

        first = threading.Thread(target=fetch_page, args=(None, 0))
        first.daemon = True
        threads.append(first)
        first.start()

        deadline = time.time() + self._timeout
        while True:
            with lock:
                alive = [thread for thread in threads if thread.is_alive()]
                found = total_count[0]
            if progress_callback:
                try:
                    progress_callback(found, bool(alive))
                except Exception:
                    pass
            if not alive or time.time() > deadline:
                break
            time.sleep(0.3)

        channels = []
        for slot in sorted(pages):
            channels.extend(pages[slot])
        return channels

    def _geil_get_all_channels(self, progress_callback=None):
        def fetch(cursor):
            data = self._geil_get(self._geil_catalog_url(cursor))
            items = list(data.get('items') or [])
            for item in items:
                if 'group' not in item:
                    tags = item.get('tags') or []
                    item['group'] = tags[0] if tags else ''
            return items, data.get('nextCursor')

        return self._collect_pages(fetch, progress_callback)

    def _vavoo_get_all_channels(self, adult=True, progress_callback=None):
        def fetch(cursor):
            data = self._post(
                self._path('catalog'),
                self._build_payload(cursor=cursor, adult=adult))
            return list(data.get('items') or []), data.get('nextCursor')

        return self._collect_pages(fetch, progress_callback)

    def _resolve_task_request(self, task_id, task_data):
        fetch_url = task_data.get('url', '')
        params = task_data.get('params', {})
        method = params.get('method', 'GET').upper()
        headers = params.get('headers', {})
        try:
            if method == 'POST':
                response = net.post(fetch_url, headers=headers, timeout=self._timeout)
            else:
                response = net.get(fetch_url, headers=headers, timeout=self._timeout)
            payload = {
                'kind': 'taskResponse',
                'id': task_id,
                'data': {'text': response.text, 'status': response.status_code},
            }
        except Exception as error:
            payload = {
                'kind': 'taskResponse',
                'id': task_id,
                'data': {'error': str(error)},
            }
        return self._post(self._path('resolve'), payload)

    def resolve_stream_url(self, play_url):
        if self._api == 'geil':
            return self._geil_resolve(play_url)
        return self._vavoo_resolve(play_url)

    def _geil_resolve(self, play_url):
        try:
            resolve_url = '%s/live/resolve?region=%s&language=de&url=%s' % (
                self.portal, self._region,
                urllib.parse.quote(play_url, safe=''))
            data = self._geil_get(resolve_url)
            if isinstance(data, dict) and data.get('url'):
                return data['url']
        except Exception:
            common.log_exception()
        return play_url

    def _vavoo_resolve(self, play_url):
        payload = {
            'language': 'de',
            'region': self._region,
            'url': play_url,
            'clientVersion': '3.1.0',
        }
        try:
            data = self._post(self._path('resolve'), payload)
        except Exception:
            common.log_exception()
            return ''
        for _ in range(5):
            if isinstance(data, list) and data:
                return data[0].get('url', '')
            if isinstance(data, dict) and data.get('url'):
                return data['url']
            if isinstance(data, dict) and data.get('kind') == 'taskRequest':
                data = self._resolve_task_request(
                    data.get('id', ''), data.get('data', {}))
                continue
            break
        return ''

def _cache_name(portal, adult):
    safe = re.sub(r'[^a-z0-9]+', '_', (portal or '').lower()).strip('_')
    return 'live_%s_%s.json' % (safe or 'portal', 'adult' if adult else 'family')

def _normalise_epg(raw):
    if not isinstance(raw, (list, tuple)):
        return []
    programs = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        title = common.clean(item.get('title') or '', 140)
        start = (item.get('start') or '').strip()
        end = (item.get('end') or '').strip()
        if not title or not start or not end:
            continue
        programs.append({'title': title, 'start': start, 'end': end})
    programs.sort(key=lambda entry: entry['start'])
    return programs

def _normalise_channels(raw):
    channels = []
    seen = set()
    for item in raw or []:
        if not isinstance(item, dict):
            continue
        url = (item.get('url') or '').strip()
        name = (item.get('name') or '').strip()
        if not url or not name:
            continue
        group = (item.get('group') or '').strip()
        if not group:
            tags = item.get('tags') or []
            group = tags[0] if tags else ''
        group = group or 'Sonstige'
        logo = item.get('logo') or ''
        epg = _normalise_epg(item.get('epg'))
        ids = item.get('ids') if isinstance(item.get('ids'), dict) else {}
        key = (group.lower(), url)
        if key in seen:
            continue
        seen.add(key)
        channels.append({'name': name, 'url': url, 'logo': logo, 'group': group,
                         'epg': epg, 'id': str(item.get('id') or ''),
                         'tvg': str(ids.get('tvg') or '')})
    return channels

def load_cached(portal=None, adult=None):
    portal = portal or common.setting('live_portal', 'geil.to')
    adult = common.setting_bool('live_adult', False) if adult is None else adult
    data = common.read_cache(_cache_name(portal, adult))
    if not data:
        return None
    if data.get('portal') != portal or bool(data.get('adult')) != adult:
        return None
    hours = common.setting_int('live_cache_hours', 12)
    if hours > 0 and (time.time() - float(data.get('ts') or 0)) > hours * 3600:
        return None
    channels = data.get('channels') or []
    return channels or None

def get_channels(force=False, progress=None):
    portal = common.setting('live_portal', 'geil.to').strip() or 'geil.to'
    adult = common.setting_bool('live_adult', False)
    if not force:
        cached = load_cached(portal, adult)
        if cached:
            return cached

    candidates = [portal]
    if 'geil.to' not in portal.lower():

        candidates.append('geil.to')

    errors = []
    for candidate in candidates:
        try:
            client = LiveClient(candidate)
            raw = client.get_all_channels(adult=adult, progress_callback=progress)
        except Exception as error:
            common.log_exception()
            errors.append('%s: %s' % (candidate, error))
            continue
        channels = _normalise_channels(raw)
        if not channels:
            errors.append('%s: keine Sender empfangen' % candidate)
            continue
        stamp = time.time()
        common.write_cache(_cache_name(candidate, adult), {
            'ts': stamp,
            'portal': candidate,
            'adult': adult,
            'channels': channels,
        })
        if candidate != portal:

            common.write_cache(_cache_name(portal, adult), {
                'ts': stamp,
                'portal': portal,
                'source': candidate,
                'adult': adult,
                'channels': channels,
            })
        return channels

    raise LiveError(
        'Es konnten keine Sender geladen werden. Bitte später erneut versuchen. '
        '(%s)' % '; '.join(errors[:2]))

def channel_key(name):
    name = (name or '').strip()
    previous = None
    while previous != name:
        previous = name
        name = _QUALITY_SUFFIX.sub('', name).strip()
    name = re.sub(r'\s+', ' ', name).strip()
    return name or 'Unbekannt'

def build_channel_entries(channels):

    entries = {}
    for channel in channels or []:
        key = channel_key(channel.get('name'))
        entry = entries.setdefault(key, {
            'name': key,
            'group': channel.get('group') or '',
            'logo': '',
            'epg': [],
            'streams': [],
        })
        if not entry['logo'] and channel.get('logo'):
            entry['logo'] = channel['logo']
        if not entry['epg'] and channel.get('epg'):
            entry['epg'] = channel['epg']
        urls = {stream['url'] for stream in entry['streams']}
        if channel['url'] not in urls:
            entry['streams'].append(channel)
    return sorted(entries.values(), key=lambda entry: _fold(entry['name']))

def build_groups(channels):
    grouped = {}
    for channel in channels or []:
        grouped.setdefault(channel.get('group') or 'Sonstige', []).append(channel)

    groups = []
    for name, items in grouped.items():
        info = GROUP_INFO.get(name.strip().lower())
        label, code = info if info else (name.strip() or 'Sonstige', 'zz')
        groups.append({
            'group': name,
            'label': label,
            'flag': code,
            'entries': build_channel_entries(items),
        })

    def sort_key(group):
        name = group['group'].strip().lower()
        position = GROUP_ORDER.index(name) if name in GROUP_ORDER else len(GROUP_ORDER)
        return (position, _fold(group['label']))

    groups.sort(key=sort_key)
    return groups

def _fold(text):
    text = (text or '').strip().casefold()
    for source, target in (('ä', 'a'), ('ö', 'o'), ('ü', 'u'), ('ß', 'ss')):
        text = text.replace(source, target)
    return text

def _parse_epg_moment(value):
    try:
        moment = datetime.fromisoformat((value or '').replace('Z', '+00:00'))
    except (TypeError, ValueError):
        return None
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment

def _epg_clock(moment):
    try:
        return moment.astimezone().strftime('%H:%M')
    except Exception:
        return moment.strftime('%H:%M')

def format_epg(programs, now=None):

    parsed = []
    for item in programs or []:
        if not isinstance(item, dict):
            continue
        start = _parse_epg_moment(item.get('start'))
        end = _parse_epg_moment(item.get('end'))
        title = common.clean(item.get('title') or '', 90)
        if not title or start is None or end is None or end <= start:
            continue
        parsed.append({'title': title, 'start': start, 'end': end})
    if not parsed:
        return ''
    parsed.sort(key=lambda entry: entry['start'])
    if now is None:
        now = datetime.now(timezone.utc)
    elif now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)

    current = None
    upcoming = []
    for item in parsed:
        if item['start'] <= now < item['end']:
            if current is None or item['start'] >= current['start']:
                current = item
        elif item['start'] > now:
            upcoming.append(item)

    lines = []
    if current is None and upcoming:
        current = upcoming.pop(0)
        lines.append('JETZT  ab %s' % _epg_clock(current['start']))
        lines.append(current['title'])
    elif current is not None:
        lines.append('JETZT  %s - %s' % (
            _epg_clock(current['start']), _epg_clock(current['end'])))
        lines.append(current['title'])
        remaining = int((current['end'] - now).total_seconds() // 60)
        if remaining > 0:
            lines.append('Noch %d Min.' % remaining)
    else:
        return 'Keine aktuellen Programmdaten.'

    if upcoming:
        following = upcoming[0]
        lines.append('')
        lines.append('DANACH  %s - %s' % (
            _epg_clock(following['start']), _epg_clock(following['end'])))
        lines.append(following['title'])
    return '\n'.join(lines)

def search_channels(channels, query):
    needle = _fold(query)
    if not needle:
        return []
    results = []
    for entry in build_channel_entries(channels):
        group_name = (entry.get('group') or '').strip()
        label, _ = GROUP_INFO.get(group_name.lower(), (group_name, 'zz'))
        haystack = _fold('%s %s' % (entry['name'], label))
        if needle in haystack:
            results.append(entry)
    return results
