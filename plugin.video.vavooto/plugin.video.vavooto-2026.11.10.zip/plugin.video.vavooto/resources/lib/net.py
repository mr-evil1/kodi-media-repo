import requests

DEFAULT_TIMEOUT = 20

_HEADERS = {
    'User-Agent': ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
                   '(KHTML, like Gecko) vavoo/4.2.2 Chrome/146.0.7680.166 '
                   'Electron/41.1.0 Safari/537.36'),
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
}

_SESSION = requests.Session()

def _headers_for(headers):
    merged = dict(_HEADERS)
    if headers:
        for key, value in headers.items():
            merged[key] = value
    return merged

def get(url, headers=None, timeout=DEFAULT_TIMEOUT, **kwargs):
    return _SESSION.get(url, headers=_headers_for(headers), timeout=timeout, **kwargs)

def post(url, headers=None, timeout=DEFAULT_TIMEOUT, **kwargs):
    return _SESSION.post(url, headers=_headers_for(headers), timeout=timeout, **kwargs)

def get_json(url, headers=None, timeout=DEFAULT_TIMEOUT, **kwargs):
    response = get(url, headers=headers, timeout=timeout, **kwargs)
    response.raise_for_status()
    return response.json()

def post_json(url, headers=None, timeout=DEFAULT_TIMEOUT, **kwargs):
    response = post(url, headers=headers, timeout=timeout, **kwargs)
    response.raise_for_status()
    return response.json()
