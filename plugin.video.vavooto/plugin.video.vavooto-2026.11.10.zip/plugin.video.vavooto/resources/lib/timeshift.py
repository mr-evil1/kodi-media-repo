import os
import re
import threading
import time
import uuid
from urllib.parse import parse_qs, urljoin

import requests
import xbmc
import xbmcgui

import common
from live import LIVE_UA

_HEADERS = {'User-Agent': LIVE_UA, 'Accept': '*/*'}
_DEFAULT_BUFFER_MB = 2
_DEFAULT_WAIT = 4.0
_MIN_FILL = 2.0
_MAX_SEGMENTS = 10
_ACTIVE = None
_LOCK = threading.Lock()

def enabled():
    return common.setting_bool('live_timeshift', True)

def _buffer_mb():

    try:
        value = int(common.setting('live_timeshift_buffer',
                                   str(_DEFAULT_BUFFER_MB)))
    except (TypeError, ValueError):
        value = _DEFAULT_BUFFER_MB
    return max(1, min(64, value))

def _buffer_bytes():
    return _buffer_mb() * 1024 * 1024

def _wait_seconds():

    try:
        value = float(common.setting('live_timeshift_wait',
                                     str(int(_DEFAULT_WAIT))))
    except (TypeError, ValueError):
        value = _DEFAULT_WAIT
    return max(3.0, min(60.0, value))

def _fallback_bytes():

    return max(512 * 1024, min(_buffer_bytes(), 1024 * 1024))

def _directory():
    custom = (common.setting('live_timeshift_dir', '') or '').strip()
    path = custom or os.path.join(common.PROFILE, 'timeshift')
    try:
        if not os.path.isdir(path):
            os.makedirs(path)
    except OSError:
        common.log_exception()
    return path

def _split_url(url):

    if not url or '|' not in url:
        return url, {}
    base, query = url.split('|', 1)
    headers = {}
    for key, values in parse_qs(query).items():
        if values:
            headers[key] = values[-1]
    return base, headers

def _is_hls(url):
    return 'm3u8' in (url or '').lower()

def _playlist_url(text, base):

    if '#EXT-X-STREAM-INF' not in (text or ''):
        return base
    expect_url = False
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('#EXT-X-STREAM-INF'):
            expect_url = True
        elif expect_url and line and not line.startswith('#'):
            return urljoin(base, line)
    return base

def _map_uri(text):
    match = re.search(r'#EXT-X-MAP:.*?URI="([^"]+)"', text or '')
    return match.group(1) if match else ''

def _parse_hls(text, base):

    sequence = 0
    match = re.search(r'#EXT-X-MEDIA-SEQUENCE:(\d+)', text or '')
    if match:
        sequence = int(match.group(1))
    segments = []
    for line in (text or '').splitlines():
        line = line.strip()
        if line and not line.startswith('#'):
            segments.append(urljoin(base, line))
    return sequence, segments, _map_uri(text)

class _Recorder(threading.Thread):
    def __init__(self, path, stream_url):
        threading.Thread.__init__(self, name='vavoo-ts-recorder')
        self.daemon = True
        self.path = path
        self.stream_url, self._extra_headers = _split_url(stream_url)
        self._stop_event = threading.Event()

    def stop(self):
        self._stop_event.set()

    def _headers(self):
        headers = dict(_HEADERS)
        headers.update(self._extra_headers or {})
        return headers

    def _get(self, url, **kwargs):
        return requests.get(url, headers=self._headers(), timeout=(10, 45), **kwargs)

    def _write(self, handle, response):
        for chunk in response.iter_content(65536):
            if self._stop_event.is_set():
                return False
            if chunk:
                handle.write(chunk)
        return True

    def _record_direct(self):
        append = False
        failures = 0
        while not self._stop_event.is_set():
            try:
                response = self._get(self.stream_url, stream=True)
                response.raise_for_status()
                with open(self.path, 'ab' if append else 'wb') as handle:
                    self._write(handle, response)
                append = True
                failures = 0
                if self._stop_event.is_set():
                    return
            except Exception as error:
                failures += 1
                common.log('Timeshift-Aufnahme: %s' % error)
                if failures > 15:
                    return
                self._stop_event.wait(min(2 * failures, 10))

    def _record_hls(self):
        media_url = self.stream_url
        try:
            response = self._get(media_url)
            response.raise_for_status()
            media_url = _playlist_url(response.text, media_url)
        except Exception as error:
            common.log('Timeshift-Playlist: %s' % error)
            return

        init_written = False
        failures = 0
        last_sequence = None
        with open(self.path, 'wb') as handle:
            while not self._stop_event.is_set():
                try:
                    response = self._get(media_url)
                    response.raise_for_status()
                    sequence, segments, map_url = _parse_hls(
                        response.text, response.url or media_url)
                    base = response.url or media_url
                    if map_url and not init_written:
                        init = self._get(urljoin(base, map_url), stream=True)
                        init.raise_for_status()
                        if not self._write(handle, init):
                            return
                        init_written = True
                    if not segments:
                        self._stop_event.wait(2.0)
                        continue

                    if last_sequence is None:

                        selected = segments[-_MAX_SEGMENTS:]
                        last_sequence = sequence + len(segments) - 1
                        last_sequence -= len(selected)
                    elif sequence < last_sequence - 5:

                        last_sequence = sequence - 1
                        selected = segments[-_MAX_SEGMENTS:]
                    else:
                        selected = []
                        for offset, segment in enumerate(segments):
                            absolute = sequence + offset
                            if absolute > last_sequence:
                                selected.append(segment)
                        selected = selected[-20:]

                    for segment in selected:
                        if self._stop_event.is_set():
                            return
                        try:
                            segment_response = self._get(segment, stream=True)
                            segment_response.raise_for_status()
                            if not self._write(handle, segment_response):
                                return
                            last_sequence += 1
                        except Exception as error:
                            common.log('Timeshift-Segment: %s' % error)
                    failures = 0
                    self._stop_event.wait(1.0)
                except Exception as error:
                    failures += 1
                    common.log('Timeshift-HLS: %s' % error)
                    if failures > 15:
                        return
                    self._stop_event.wait(min(2 * failures, 10))

    def run(self):
        try:
            if _is_hls(self.stream_url):
                self._record_hls()
            else:
                self._record_direct()
        except Exception:
            common.log_exception()

class _Session(object):
    def __init__(self):
        self.path = os.path.join(
            _directory(), 'ts_%s.ts' % uuid.uuid4().hex)
        self.recorder = None
        self._stopped = threading.Event()

    def start(self, stream_url):
        self.recorder = _Recorder(self.path, stream_url)
        self.recorder.start()

    def wait_for_buffer(self):
        started = time.time()
        deadline = started + _wait_seconds()
        buffer_bytes = _buffer_bytes()
        while time.time() < deadline:
            try:
                size = os.path.getsize(self.path)
            except OSError:
                size = 0

            if (size >= buffer_bytes and
                    time.time() - started >= _MIN_FILL):
                return True
            if self._stopped.is_set():
                return False
            xbmc.sleep(200)
        try:

            return os.path.getsize(self.path) >= _fallback_bytes()
        except OSError:
            return False

    def play(self, title, thumb=''):
        item = xbmcgui.ListItem(title, path=self.path)
        item.setMimeType('video/mp2t')
        item.setContentLookup(False)
        item.setProperty('IsPlayable', 'true')
        if thumb:
            try:
                item.setArt({'thumb': thumb, 'icon': thumb})
            except Exception:
                pass
        try:
            tag = item.getVideoInfoTag()
            tag.setMediaType('movie')
            tag.setTitle(title)
        except Exception:
            pass
        xbmc.Player().play(self.path, item)

    def stop(self):
        if self._stopped.is_set():
            return
        self._stopped.set()
        if self.recorder:
            self.recorder.stop()
        recorder = self.recorder
        path = self.path

        def cleanup():
            if recorder:
                recorder.join(timeout=5)
            try:
                if path and os.path.exists(path):
                    os.remove(path)
            except OSError:
                pass

        cleanup_thread = threading.Thread(target=cleanup, name='vavoo-ts-cleanup')
        cleanup_thread.daemon = True
        cleanup_thread.start()

def _same_file(current, expected):
    if not current or not expected:
        return False
    if current == expected or expected in current or current in expected:
        return True
    try:
        return os.path.basename(current) == os.path.basename(expected)
    except Exception:
        return False

def _guard(session):

    global _ACTIVE
    started = time.time()
    player = xbmc.Player()
    while not session._stopped.is_set():
        if time.time() - started < 8:
            time.sleep(1)
            continue
        try:
            if not player.isPlaying():
                break
            current = player.getPlayingFile()
            if current and not _same_file(current, session.path):
                break
        except Exception:
            pass
        time.sleep(1)

    with _LOCK:
        if _ACTIVE is session:
            _ACTIVE = None
    session.stop()

def current_path():
    with _LOCK:
        return _ACTIVE.path if _ACTIVE else ''

def stop():
    global _ACTIVE
    with _LOCK:
        session = _ACTIVE
        _ACTIVE = None
    if session:
        session.stop()

def prepare(stream_url, title, thumb=''):

    global _ACTIVE
    if not enabled() or not stream_url:
        return None
    common.notify(common.NAME,
                  'Timeshift: Puffer wird aufgebaut (%d MB, max. %d s) ...'
                  % (_buffer_mb(), int(_wait_seconds())), millis=3500)
    stop()
    session = _Session()
    with _LOCK:
        _ACTIVE = session
    session.start(stream_url)
    if not session.wait_for_buffer():
        with _LOCK:
            if _ACTIVE is session:
                _ACTIVE = None
        session.stop()
        common.log('Timeshift: kein Puffer, normaler Stream wird verwendet')
        return None
    common.log('Timeshift-Puffer bereit: %s' % title)
    return session

def start_guard(session):

    if not session:
        return
    guard = threading.Thread(target=_guard, args=(session,), name='vavoo-ts-guard')
    guard.daemon = True
    guard.start()

def play(stream_url, title, thumb=''):

    session = prepare(stream_url, title, thumb)
    if not session:
        return ''
    session.play(title, thumb)
    start_guard(session)
    common.log('Timeshift gestartet: %s' % title)
    return session.path
