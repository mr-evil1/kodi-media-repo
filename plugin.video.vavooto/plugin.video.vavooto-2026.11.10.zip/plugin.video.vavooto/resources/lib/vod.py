import os
import re
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

import common
import net

BASE_URL = 'https://vavoo.to'
URL_ITEM = BASE_URL + '/mediahubmx-item.json'
URL_SOURCE = BASE_URL + '/mediahubmx-source.json'
URL_RESOLVE = BASE_URL + '/mediahubmx-resolve.json'
URL_CATALOG = BASE_URL + '/mediahubmx-catalog.json'
PING_URL = 'https://www.vavoo.tv/api/app/ping'

APP_VERSION = '4.2.2'
APP_PACKAGE = 'tv.vavoo.app'
APP_UA = ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) '
          'vavoo/4.2.2 Chrome/146.0.7680.166 Electron/41.1.0 Safari/537.36')
SIG_TTL = 840
REGION = 'XX'
CLIENT_VERSION = '3.1.0'

SIG_FILE = os.path.join(common.PROFILE, '.vavoo_sig_cache')
UUID_FILE = os.path.join(common.PROFILE, '.vavoo_device_id')

TMDB_BASE = 'https://api.themoviedb.org/3'
TMDB_IMAGE = 'https://image.tmdb.org/t/p/w300'

DIRECT_EXTENSIONS = ('.m3u8', '.mp4', '.mkv', '.ts', '.avi', '.mov', '.mpd')
QUALITY_RANK = {'4K': 0, '1080p': 1, '720p': 2, 'HD': 3}
LANG_CACHE_TTL = 12 * 60 * 60
HOSTER_DOMAINS = (
    'dood.watch', 'doodstream.com', 'dood.to', 'dood.so', 'dood.cx',
    'dood.la', 'dood.ws', 'dood.sh', 'doodstream.co', 'dood.pm',
    'dood.wf', 'dood.re', 'dood.yt', 'dooood.com', 'dood.stream',
    'ds2play.com', 'doods.pro', 'ds2video.com', 'd0o0d.com', 'do0od.com',
    'd0000d.com', 'd000d.com', 'dood.li', 'dood.work', 'dooodster.com',
    'vidply.com', 'all3do.com', 'do7go.com', 'doply.net', 'vide0.net',
    'vvide0.com', 'd-s.io', 'dsvplay.com', 'myvidplay.com', 'playmogo.com',
    'vidoza.net', 'vidoza.co', 'videzz.net', 'veev.to',
    'mixdrop.ps', 'mixdrop.co', 'mixdrop.to', 'mixdrop.club',
    'streamtape.com', 'streamtape.to', 'streamtape.net',
    'streamhide.com', 'streamhide.to', 'streamwish.com', 'streamwish.to',
    'vidhide.com', 'vidhidepro.com', 'filemoon.sx', 'filemoon.to',
    'voe.sx', 'voe.to',
)

CATALOGS = {
    'movie': [
        {'label': 'Trending heute', 'sort': 'trendingDay'},
        {'label': 'Trending diese Woche', 'sort': 'trendingWeek'},
        {'label': 'Beliebt', 'sort': 'popularity'},
    ],
    'series': [
        {'label': 'Trending heute', 'sort': 'trendingDay'},
        {'label': 'Trending diese Woche', 'sort': 'trendingWeek'},
        {'label': 'Beliebt', 'sort': 'popularity'},
    ],
}

class VavooError(Exception):
    pass

def _device_id():
    try:
        if os.path.isfile(UUID_FILE):
            with open(UUID_FILE, 'r', encoding='utf-8') as handle:
                cached = handle.read().strip()
            if re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$',
                        cached, re.I):
                return cached
    except OSError:
        pass

    raw = bytearray(os.urandom(16))
    raw[6] = (raw[6] & 0x0f) | 0x40
    raw[8] = (raw[8] & 0x3f) | 0x80
    hexed = raw.hex()
    device_id = '%s-%s-%s-%s-%s' % (
        hexed[0:8], hexed[8:12], hexed[12:16], hexed[16:20], hexed[20:32])
    try:
        with open(UUID_FILE, 'w', encoding='utf-8') as handle:
            handle.write(device_id + '\n')
    except OSError:
        pass
    return device_id

def _signature(force=False):
    if not force:
        try:
            if os.path.isfile(SIG_FILE):
                age = time.time() - os.path.getmtime(SIG_FILE)
                if age < SIG_TTL:
                    with open(SIG_FILE, 'r', encoding='utf-8') as handle:
                        signature = handle.read().strip()
                    if signature:
                        return signature
        except OSError:
            pass

    now = int(time.time() * 1000)
    payload = {
        'reason': 'app-focus', 'locale': 'de', 'theme': 'dark',
        'metadata': {
            'device': {'type': 'desktop', 'uniqueId': _device_id()},
            'os': {'name': 'linux', 'version': 'x86_64', 'abis': ['x64'],
                   'host': 'localhost'},
            'app': {'platform': 'electron'},
            'version': {'package': APP_PACKAGE, 'binary': APP_VERSION, 'js': APP_VERSION},
        },
        'appFocusTime': 0, 'playerActive': False, 'playDuration': 0,
        'devMode': False, 'hasAddon': True, 'castConnected': False,
        'package': APP_PACKAGE, 'version': APP_VERSION, 'process': 'app',
        'firstAppStart': now, 'lastAppStart': now,
        'ipLocation': None, 'adblockEnabled': True,
        'proxy': {'supported': ['ss'], 'engine': 'Mu', 'enabled': False,
                  'autoServer': True},
        'iap': {'supported': False},
    }
    headers = {
        'User-Agent': APP_UA,
        'Accept': '*/*',
        'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
        'Origin': 'https://vavoo.to',
        'Referer': 'https://vavoo.to/',
        'Connection': 'keep-alive',
        'Content-Type': 'application/json',
    }
    try:
        response = net.post(PING_URL, json=payload, headers=headers, timeout=12)
        response.raise_for_status()
        signature = response.json().get('addonSig', '')
        if signature:
            try:
                with open(SIG_FILE, 'w', encoding='utf-8') as handle:
                    handle.write(signature)
            except OSError:
                pass
            return signature
    except Exception:
        common.log_exception()

    try:
        if os.path.isfile(SIG_FILE):
            with open(SIG_FILE, 'r', encoding='utf-8') as handle:
                return handle.read().strip()
    except OSError:
        pass
    return ''

def _base_payload():
    return {'language': 'de', 'region': REGION, 'clientVersion': CLIENT_VERSION}

def _api_headers(signature):
    return {
        'user-agent': 'MediaHubMX/2',
        'content-type': 'application/json; charset=utf-8',
        'accept-encoding': 'gzip',
        'mediahubmx-signature': signature,
    }

def _api_post(url, payload, signature):
    stamp = str(int(time.time() * 1000))
    try:
        response = net.post(
            url + '?_t=' + stamp,
            json=payload,
            headers=_api_headers(signature),
            timeout=15,
        )
        response.raise_for_status()
        return response.json()
    except Exception:
        common.log_exception()
        return None

def _tmdb_get(path):
    key = common.setting('tmdb_key', '').strip()
    if not key:
        return {}
    try:
        data = net.get_json(
            TMDB_BASE + path,
            params={'api_key': key, 'language': 'de-DE'},
            timeout=10,
        )
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def _item_ids(item):
    ids = {}
    if item.get('imdb'):
        ids['imdb_id'] = item['imdb']
    if item.get('tmdb'):
        ids['tmdb_id'] = str(item['tmdb'])
    return ids

def _quality_label(tag):
    tag = (tag or '').upper()
    if '4K' in tag or '2160' in tag:
        return '4K'
    if '1080' in tag:
        return '1080p'
    if '720' in tag:
        return '720p'
    return tag or 'HD'

def _language_label(languages):
    if 'de' in languages:
        return 'DE'
    if 'en' in languages:
        return 'EN'
    return '?'

def _is_direct(url):
    path = urllib.parse.urlparse((url or '').split('|')[0]).path.lower()
    return any(path.endswith(ext) for ext in DIRECT_EXTENSIONS)

def _host_label(url, fallback=''):
    host = re.sub(r'^www\.', '', urllib.parse.urlparse(url or '').hostname or '')
    if not host:
        return fallback or 'Quelle'
    return host.split('.')[0].capitalize()

def _url_host(url):
    try:
        return (urllib.parse.urlparse((url or '').split('|')[0]).hostname or '').lower()
    except ValueError:
        return ''

def _is_hoster_host(host):
    return any(host == domain or host.endswith('.' + domain)
               for domain in HOSTER_DOMAINS)

def is_playable_resolution(source, resolved):

    if not resolved:
        return False
    if _is_direct(resolved):
        return True
    source_host = _url_host(source)
    resolved_host = _url_host(resolved)
    if not resolved_host or resolved_host == source_host:
        return False
    return not _is_hoster_host(resolved_host)

def sort_mirrors(mirrors, german_only=False):

    selected = [mirror for mirror in (mirrors or [])
                if not german_only or mirror.get('lang') == 'DE']
    return sorted(selected, key=lambda mirror: (
        0 if mirror.get('lang') == 'DE' else 1,
        QUALITY_RANK.get(mirror.get('quality'), 4),
        0 if mirror.get('direct') else 1,
        (mirror.get('name') or '').lower(),
    ))

def _language_cache_name(item):
    key = item.get('tmdb') or item.get('imdb') or item.get('name') or ''
    key = re.sub(r'[^0-9A-Za-z._-]+', '_', str(key)).strip('_')[:60]
    return 'lang_%s_%s.json' % (item.get('type') or 'movie', key or 'unknown')

def has_german_sources(item):

    cache_name = _language_cache_name(item)
    cached = common.read_cache(cache_name)
    if isinstance(cached, dict):
        try:
            age = time.time() - float(cached.get('ts') or 0)
        except (TypeError, ValueError):
            age = LANG_CACHE_TTL
        if 0 <= age < LANG_CACHE_TTL:
            return bool(cached.get('german'))

    found = False
    try:
        if item.get('type') == 'series':
            for season in (1, 2):
                raw = _source(item, season=season, episode=1)
                if raw is None:
                    return True
                if not raw:
                    continue
                if any('de' in (source.get('languages') or [])
                       for source in raw if isinstance(source, dict)):
                    found = True
                    break
        else:
            raw = _source(item, item_type='movie')
            if raw is None:
                return True
            found = any('de' in (source.get('languages') or [])
                        for source in raw if isinstance(source, dict))
    except Exception:
        common.log_exception()
        return True

    common.write_cache(cache_name, {'ts': time.time(), 'german': found})
    return found

def filter_german(items, progress=None):

    items = list(items or [])
    if not items:
        return []
    keep = set()
    total = len(items)
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(has_german_sources, item): index
                   for index, item in enumerate(items)}
        for done, future in enumerate(as_completed(futures), 1):
            index = futures[future]
            try:
                if future.result():
                    keep.add(index)
            except Exception:
                common.log_exception()
                keep.add(index)
            if progress is not None:
                try:
                    progress(done, total)
                except Exception:
                    pass
    return [item for index, item in enumerate(items) if index in keep]

def _catalog_item(raw):
    ids = raw.get('ids') or {}
    name = (raw.get('name') or '').strip()
    if not name:
        return None
    item_type = 'series' if raw.get('type') == 'series' else 'movie'
    return {
        'name': name,
        'type': item_type,
        'imdb': ids.get('imdb_id') or '',
        'tmdb': str(ids.get('tmdb_id') or ''),
        'poster': (raw.get('images') or {}).get('poster') or '',
        'year': str(raw.get('releaseYear') or ''),
        'plot': raw.get('description') or '',
    }

def browse(catalog_id, sort='popularity', cursor=None, search='', adult=False):

    signature = _signature()
    if not signature:
        raise VavooError('Die Vavoo-Signatur konnte nicht geladen werden.')

    payload = _base_payload()
    payload.update({
        'catalogId': catalog_id,
        'id': '',
        'adult': adult,
        'search': search,
        'sort': sort,
        'filter': {},
        'cursor': cursor,
    })
    data = _api_post(URL_CATALOG, payload, signature)
    if not isinstance(data, dict):
        raise VavooError('Der Katalog konnte nicht geladen werden.')

    items = []
    for raw in data.get('items') or []:
        item = _catalog_item(raw)
        if item:
            items.append(item)
    return items, data.get('nextCursor')

def _source(item, season=0, episode=0, item_type=None):
    signature = _signature()
    ids = _item_ids(item)
    if not ids:
        return []
    payload = _base_payload()
    payload.update({
        'type': item_type or ('series' if season else item.get('type') or 'movie'),
        'ids': ids,
        'name': item.get('name') or '',
        'nameTranslations': {},
        'episode': {'season': season, 'episode': episode} if season else {},
    })
    data = _api_post(URL_SOURCE, payload, signature)
    return data if isinstance(data, list) else None

def _tmdb_series(item):
    tmdb = item.get('tmdb') or ''
    if not tmdb or not common.setting('tmdb_key', '').strip():
        return {}
    return _tmdb_get('/tv/%s' % tmdb)

def _tmdb_seasons(item):
    data = _tmdb_series(item)
    seasons = []
    for season in data.get('seasons') or []:
        number = season.get('season_number', 0)
        if not number:
            continue
        poster = season.get('poster_path')
        seasons.append({
            'season': number,
            'label': 'Staffel %d' % number,
            'plot': season.get('overview') or '%d Episoden' % (season.get('episode_count') or 0),
            'thumb': (TMDB_IMAGE + poster) if poster else '',
        })
    return seasons

def _tmdb_episodes(item, season):
    tmdb = item.get('tmdb') or ''
    if not tmdb or not common.setting('tmdb_key', '').strip():
        return []
    data = _tmdb_get('/tv/%s/season/%d' % (tmdb, season))
    episodes = []
    for episode in data.get('episodes') or []:
        number = episode.get('episode_number', 0)
        if not number:
            continue
        still = episode.get('still_path')
        episodes.append({
            'episode': number,
            'label': 'E%02d - %s' % (number, episode.get('name') or ''),
            'plot': episode.get('overview') or '',
            'thumb': (TMDB_IMAGE + still) if still else '',
        })
    return episodes

def seasons(item):

    if item.get('type') != 'series':
        return []
    from_tmdb = _tmdb_seasons(item)
    if from_tmdb:
        return from_tmdb

    if not _item_ids(item):
        return []

    found = []
    misses = 0
    for number in range(1, 31):
        mirrors = _source(item, season=number, episode=1)
        if mirrors:
            misses = 0
            found.append({
                'season': number,
                'label': 'Staffel %d' % number,
                'plot': '%d Quelle(n) verfügbar' % len(mirrors),
                'thumb': item.get('poster') or '',
            })
        else:
            misses += 1
            if number > 1 and misses >= 3:
                break
    return found

def episodes(item, season):

    from_tmdb = _tmdb_episodes(item, season)
    if from_tmdb:
        return from_tmdb

    if not _item_ids(item):
        return []

    found = []
    misses = 0
    for number in range(1, 61):
        mirrors = _source(item, season=season, episode=number)
        if mirrors:
            misses = 0
            found.append({
                'episode': number,
                'label': 'E%02d' % number,
                'plot': '%d Quelle(n) verfügbar' % len(mirrors),
                'thumb': item.get('poster') or '',
            })
        else:
            misses += 1
            if number > 1 and misses >= 4:
                break
    return found

def mirrors(item, season=0, episode=0):

    signature = _signature()
    if not signature:
        raise VavooError('Die Vavoo-Signatur konnte nicht geladen werden.')

    ids = _item_ids(item)
    if not ids:
        raise VavooError('Zu diesem Titel liegen keine IDs vor.')

    item_type = 'series' if (season or item.get('type') == 'series') else 'movie'
    episode_data = {'season': season, 'episode': episode} if season else {}

    payload = _base_payload()
    payload.update({
        'type': item_type,
        'ids': ids,
        'name': item.get('name') or '',
        'nameTranslations': {},
        'episode': episode_data,
    })
    item_data = _api_post(URL_ITEM, payload, signature)
    if isinstance(item_data, dict):
        source_payload = dict(item_data)
        source_payload.update(_base_payload())
        ids = dict(item_data.get('ids') or {}, **ids)
    else:
        source_payload = dict(payload)

    types_to_try = ['series'] if season else (
        ['movie', 'series'] if item_type == 'movie' else [item_type])

    response = None
    for candidate in types_to_try:
        source_payload.update({
            'type': candidate,
            'ids': ids,
            'name': item.get('name') or '',
            'nameTranslations': {},
            'episode': episode_data,
        })
        response = _api_post(URL_SOURCE, source_payload, signature)
        if isinstance(response, list) and response:
            break
        response = None

    if not isinstance(response, list):
        return []

    found = []
    for raw in response:
        if not isinstance(raw, dict):
            continue
        url = raw.get('url') or ''
        if not url:
            continue
        languages = raw.get('languages') or []
        found.append({
            'name': _host_label(url, raw.get('name') or 'Quelle'),
            'url': url,
            'direct': _is_direct(url),
            'quality': _quality_label(raw.get('tag')),
            'lang': _language_label(languages),
        })
    return sort_mirrors(found, german_only=common.german_only())

def resolve(stream_url):

    signature = _signature()
    if not signature:
        return ''

    payload = _base_payload()
    payload['url'] = stream_url
    data = _api_post(URL_RESOLVE, payload, signature)

    for _ in range(6):
        if isinstance(data, list) and data:
            return data[0].get('url', '')
        if isinstance(data, dict) and data.get('url'):
            return data['url']
        if isinstance(data, dict) and isinstance(data.get('data'), dict) \
                and data['data'].get('url'):
            return data['data']['url']
        if isinstance(data, dict) and data.get('kind') == 'taskRequest':
            task_id = data.get('id', '')
            task_data = data.get('data') or {}
            fetch_url = task_data.get('url', '')
            params = task_data.get('params') or {}
            method = (params.get('method') or 'GET').upper()
            headers = params.get('headers') or {}
            try:
                if method == 'POST':
                    response = net.post(fetch_url, headers=headers, timeout=15)
                else:
                    response = net.get(fetch_url, headers=headers, timeout=15)
                follow_up = _base_payload()
                follow_up.update({
                    'kind': 'taskResponse',
                    'id': task_id,
                    'data': {'text': response.text, 'status': response.status_code},
                })
            except Exception as error:
                follow_up = _base_payload()
                follow_up.update({
                    'kind': 'taskResponse',
                    'id': task_id,
                    'data': {'error': str(error)},
                })
            data = _api_post(URL_RESOLVE, follow_up, signature)
            continue
        break
    return ''
