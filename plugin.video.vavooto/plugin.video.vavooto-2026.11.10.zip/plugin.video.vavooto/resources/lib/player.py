import json
import os
import re
import sys
import threading
import time
import urllib.parse
import uuid

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import common
import live
import timeshift

LIVE_UA = live.LIVE_UA
VOD_UA = ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) '
          'vavoo/4.2.2 Chrome/146.0.7680.166 Electron/41.1.0 Safari/537.36')

def _with_headers(url, headers):

    if not headers or '|' in url:
        return url
    return url + '|' + urllib.parse.urlencode(headers)

AUDIO_EXTENSIONS = (
    '.aac', '.flac', '.m4a', '.mka', '.mp3', '.oga', '.ogg', '.opus',
    '.wav', '.wma',
)

AUDIO_HINTS = ('radio', 'audio', 'music', 'musik')

_PREFETCH_LOCK = threading.Lock()
_LIVE_BEHIND = 5
_LIVE_AHEAD = 5

RESOLVER_ADDONS = {
    'resolveurl': 'script.module.resolveurl',
    'urlresolver': 'script.module.urlresolver',
}

VIDOZA_HOSTS = {'vidoza.net', 'vidoza.co', 'videzz.net'}
DOOD_HOSTS = {
    'dood.watch', 'doodstream.com', 'dood.to', 'dood.so', 'dood.cx', 'dood.la',
    'dood.ws', 'dood.sh', 'doodstream.co', 'dood.pm', 'dood.wf', 'dood.re',
    'dood.yt', 'dooood.com', 'dood.stream', 'ds2play.com', 'doods.pro',
    'ds2video.com', 'd0o0d.com', 'do0od.com', 'd0000d.com', 'd000d.com',
    'dood.li', 'dood.work', 'dooodster.com', 'vidply.com', 'all3do.com',
    'do7go.com', 'doodcdn.io', 'doply.net', 'vide0.net', 'vvide0.com',
    'd-s.io', 'dsvplay.com', 'myvidplay.com', 'playmogo.com',
}

def _normalise_resolver_url(url):

    parsed = urllib.parse.urlparse(url or '')
    host = (parsed.netloc or '').lower()
    path = parsed.path or ''
    if host in VIDOZA_HOSTS:
        match = re.search(r'/(?:w/|embed-)?([0-9a-zA-Z]+)(?:\.html)?/?$', path)
        if match:
            return 'https://%s/embed-%s.html' % (parsed.netloc, match.group(1))
    if host in DOOD_HOSTS:
        match = re.search(r'/(?:d|e|w)/([0-9a-zA-Z]+)', path)
        if match:
            return 'https://%s/d/%s' % (parsed.netloc, match.group(1))
    return url

def _resolver_candidates(url):
    normalised = _normalise_resolver_url(url)
    if normalised and normalised != url:
        return [normalised, url]
    return [url]

def _import_resolver(module_name):

    try:
        return __import__(module_name)
    except ImportError:
        pass

    addon_id = RESOLVER_ADDONS.get(module_name)
    if not addon_id:
        return None
    try:
        addon_path = xbmcvfs.translatePath(
            xbmcaddon.Addon(addon_id).getAddonInfo('path'))
    except Exception:
        common.log('%s ist nicht installiert' % addon_id)
        return None

    for candidate in (os.path.join(addon_path, 'lib'), addon_path):
        if not os.path.isdir(candidate):
            continue
        if candidate not in sys.path:
            sys.path.insert(0, candidate)
        try:
            return __import__(module_name)
        except ImportError:
            continue
    return None

def resolve_hoster(url):

    if not url:
        return ''
    for module_name in ('resolveurl', 'urlresolver'):
        module = _import_resolver(module_name)
        if module is None:
            common.log('%s ist nicht importierbar' % module_name)
            continue

        for candidate in _resolver_candidates(url):
            failed = False
            try:
                resolved = module.resolve(candidate)
            except Exception as error:

                common.log('%s: %s' % (module_name, error))
                resolved = ''
                failed = True
            if resolved:
                common.log('%s: Quelle aufgeloest' % module_name)
                return resolved

            if not failed:

                try:
                    hosted = module.HostedMediaFile(candidate)
                    if hosted:
                        resolved = hosted.resolve()
                except Exception as error:
                    common.log('%s: %s' % (module_name, error))
                    resolved = ''
                if resolved:
                    common.log('%s: Quelle ueber HostedMediaFile aufgeloest' % module_name)
                    return resolved
            common.log('%s: keine Loesung fuer %s' % (module_name, candidate[:140]))
    return ''

def _listitem(title, thumb, plot, mediatype):
    item = xbmcgui.ListItem(title, offscreen=True)
    art = {'fanart': common.FANART}
    if thumb:
        art.update({'thumb': thumb, 'icon': thumb, 'poster': thumb})
    try:
        item.setArt(art)
    except Exception:
        pass

    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(title)
        if plot:
            tag.setPlot(common.clean(plot))
        tag.setMediaType(mediatype)
    except Exception:
        pass
    return item

def _audio_listitem(title, thumb=''):

    item = xbmcgui.ListItem(title, offscreen=True)
    art = {'fanart': common.FANART}
    if thumb:
        art.update({'thumb': thumb, 'icon': thumb, 'poster': thumb})
    try:
        item.setArt(art)
    except Exception:
        pass
    try:
        item.setInfo('music', {'title': title})
    except Exception:
        pass
    item.setProperty('IsPlayable', 'true')
    return item

def _live_video_listitem(title, thumb='', path=''):

    item = _listitem(title, thumb, '', 'video')
    item.setProperty('IsPlayable', 'true')
    item.setProperty('IsLive', 'true')
    if path:

        try:
            item.setPath(path)
            item.setMimeType('video/mp2t')
            item.setContentLookup(False)
        except Exception:
            pass
    else:
        item.setProperty('IsNotSeekable', 'true')
        item.setProperty('Seekable', 'false')
    return item

def is_audio_entry(entry):

    if not isinstance(entry, dict):
        return False
    if entry.get('audio'):
        return True
    values = [entry.get('group'), entry.get('name')]
    stream_urls = []
    for stream in entry.get('streams') or []:
        if not isinstance(stream, dict):
            continue
        values.extend([stream.get('name'), stream.get('url')])
        if stream.get('url'):
            stream_urls.append(stream.get('url'))
    for value in values:
        text = str(value or '').lower()
        if any(hint in text for hint in AUDIO_HINTS):
            return True
    for url in stream_urls:
        path = urllib.parse.urlparse(str(url).split('|', 1)[0]).path.lower()
        if path.endswith(AUDIO_EXTENSIONS):
            return True
    return False

def _channel_key(entry):

    if not isinstance(entry, dict):
        return ''
    return live.channel_key(entry.get('name') or '').strip().lower()

def _dedupe_channels(channels):

    unique = []
    seen = set()
    for entry in channels or []:
        key = _channel_key(entry)
        if not key or key in seen:
            continue
        seen.add(key)
        unique.append(entry)
    return unique

def _index_for_key(channels, key, default=0):
    if key:
        for position, entry in enumerate(channels or []):
            if _channel_key(entry) == key:
                return position
    return default

def _live_window(channels, index):

    channels = list(channels or [])
    if not channels:
        return [], 0
    try:
        index = int(index)
    except (TypeError, ValueError):
        index = 0
    index = max(0, min(len(channels) - 1, index))
    size = _LIVE_BEHIND + _LIVE_AHEAD + 1
    if len(channels) <= size:
        return channels, index
    start = max(0, min(index - _LIVE_BEHIND, len(channels) - size))
    return channels[start:start + size], index - start

def _compact_channels(channels):
    compact = []
    for entry in channels or []:
        if not isinstance(entry, dict) or not entry.get('name'):
            continue
        streams = []
        for stream in entry.get('streams') or []:
            if isinstance(stream, dict) and stream.get('url'):
                streams.append({
                    'name': stream.get('name') or '',
                    'url': stream.get('url') or '',
                })
        compact.append({
            'name': entry.get('name') or '',
            'group': entry.get('group') or '',
            'logo': entry.get('logo') or '',
            'audio': is_audio_entry(entry),
            'streams': streams,
        })
    return _dedupe_channels(compact)

def _save_live_context(context, stream_index=0, path='', stream_url=''):

    context = context or {}
    raw_channels = context.get('channels') or []
    try:
        index = int(context.get('index') or 0)
    except (TypeError, ValueError):
        index = 0
    selected_key = ''
    if raw_channels and 0 <= index < len(raw_channels):
        selected_key = _channel_key(raw_channels[index])
    channels = _compact_channels(raw_channels)
    if not channels:
        return {}
    if selected_key:
        index = _index_for_key(channels, selected_key, index)
    index = max(0, min(len(channels) - 1, index))
    try:
        stream_index = int(context.get('stream_index', stream_index) or 0)
    except (TypeError, ValueError):
        stream_index = 0
    state = {
        'ts': time.time(),
        'channels': channels,
        'index': index,
        'stream_index': max(0, stream_index),
        'path': path or '',
        'stream_url': stream_url or '',
    }
    _write_live_state(state)
    return state

def _write_live_state(state):
    path = os.path.join(common.PROFILE, 'live_state.json')
    tmp = path + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(state, handle, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        common.log_exception()

def _read_live_state():
    path = os.path.join(common.PROFILE, 'live_state.json')
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            state = json.load(handle)
    except (OSError, ValueError):
        return {}
    if not isinstance(state, dict) or not state.get('channels'):
        return {}
    return state

def _update_live_state(**changes):
    state = _read_live_state()
    if not state:
        return {}
    state.update(changes)
    _write_live_state(state)
    return state

def _live_queue_path():
    return os.path.join(common.PROFILE, 'live_queue.json')

def _write_live_queue(channels, stream_indices, kind='audio', appended_to=-1):

    queue_id = uuid.uuid4().hex
    state = {
        'id': queue_id,
        'ts': time.time(),
        'kind': kind,
        'channels': channels,
        'stream_indices': stream_indices,
        'appended_to': int(appended_to),
    }
    path = _live_queue_path()
    tmp = path + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(state, handle, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        common.log_exception()
        return ''
    return queue_id

def _read_live_queue(queue_id):
    if not queue_id:
        return {}
    try:
        with open(_live_queue_path(), 'r', encoding='utf-8') as handle:
            state = json.load(handle)
    except (OSError, ValueError):
        return {}
    if not isinstance(state, dict) or state.get('id') != queue_id:
        return {}
    if time.time() - float(state.get('ts') or 0) > 12 * 3600:
        return {}
    if not state.get('channels'):
        return {}
    return state

def _prefetch_path():
    return os.path.join(common.PROFILE, 'live_prefetch.json')

def _write_prefetch(queue_id, index, url, stream_url, stream_index):

    if not queue_id or not url:
        return
    state = {
        'queue': queue_id,
        'index': int(index),
        'url': url,
        'stream_url': stream_url or '',
        'stream_index': int(stream_index),
        'ts': time.time(),
    }
    path = _prefetch_path()
    tmp = path + '.tmp'
    try:
        if not os.path.isdir(common.PROFILE):
            os.makedirs(common.PROFILE)
        with _PREFETCH_LOCK:
            with open(tmp, 'w', encoding='utf-8') as handle:
                json.dump(state, handle, ensure_ascii=False)
            os.replace(tmp, path)
    except OSError:
        common.log_exception()

def _read_prefetch(queue_id, index):
    if not queue_id:
        return {}
    try:
        with _PREFETCH_LOCK:
            with open(_prefetch_path(), 'r', encoding='utf-8') as handle:
                state = json.load(handle)
    except (OSError, ValueError):
        return {}
    if not isinstance(state, dict):
        return {}
    if state.get('queue') != queue_id or state.get('index') != int(index):
        return {}
    if time.time() - float(state.get('ts') or 0) > 15 * 60:
        return {}
    if not state.get('url'):
        return {}
    return state

def _resolve_streams(streams, selected=0):

    try:
        selected = int(selected)
    except (TypeError, ValueError):
        selected = 0
    order = [selected] + [pos for pos in range(len(streams or [])) if pos != selected]
    resolved = ''
    stream_url = ''
    used = selected
    client = live.LiveClient()
    for position in order:
        if position < 0 or position >= len(streams or []):
            continue
        stream_url = streams[position].get('url') or ''
        if not stream_url:
            continue
        try:
            resolved = client.resolve_stream_url(stream_url)
        except Exception:
            common.log_exception()
            resolved = ''
        if resolved:
            used = position
            break
    return resolved, stream_url, used

def _prefetch_worker(queue_id, queue, index):

    channels = (queue or {}).get('channels') or []
    if not channels or index < 0 or index >= len(channels):
        return
    player = xbmc.Player()
    for _ in range(20):
        try:
            if player.isPlaying():
                break
        except Exception:
            pass
        xbmc.sleep(250)
    else:
        return
    stream_indices = (queue or {}).get('stream_indices') or []
    try:
        selected = int(stream_indices[index] if index < len(stream_indices) else 0)
    except (TypeError, ValueError):
        selected = 0
    entry = channels[index] or {}
    resolved, stream_url, used = _resolve_streams(
        entry.get('streams') or [], selected)
    if resolved:
        _write_prefetch(queue_id, index, resolved, stream_url, used)
        common.log('Naechster Sender vorbereitet: %s' %
                   (entry.get('name') or ''))

def _start_prefetch(queue_id, queue, index):

    try:
        thread = threading.Thread(
            target=_prefetch_worker,
            args=(queue_id, queue, index),
            name='vavoo-prefetch')
        thread.daemon = True
        thread.start()
    except Exception:
        common.log_exception()

def _update_live_queue(queue_id, appended_to):

    state = _read_live_queue(queue_id)
    if not state:
        return
    state['appended_to'] = int(appended_to)
    path = _live_queue_path()
    tmp = path + '.tmp'
    try:
        with _PREFETCH_LOCK:
            with open(tmp, 'w', encoding='utf-8') as handle:
                json.dump(state, handle, ensure_ascii=False)
            os.replace(tmp, path)
    except OSError:
        common.log_exception()

def _extend_live_playlist(queue_id, queue, index):

    channels = (queue or {}).get('channels') or []
    if not channels or not queue_id:
        return
    try:
        index = int(index)
        appended_to = int((queue or {}).get('appended_to', -1))
    except (TypeError, ValueError):
        return
    target = min(len(channels) - 1, index + _LIVE_AHEAD)
    if target <= appended_to:
        return
    kind = (queue or {}).get('kind') or 'audio'
    playlist = xbmc.PlayList(
        xbmc.PLAYLIST_VIDEO if kind == 'video' else xbmc.PLAYLIST_MUSIC)
    stream_indices = (queue or {}).get('stream_indices') or []
    for position in range(max(0, appended_to + 1), target + 1):
        if position == index or position >= len(channels):
            continue
        entry = channels[position] or {}
        try:
            selected = int(stream_indices[position]
                           if position < len(stream_indices) else 0)
        except (TypeError, ValueError):
            selected = 0
        item = (_live_video_listitem(entry.get('name') or '',
                                    entry.get('logo') or '')
                if kind == 'video' else
                _audio_listitem(entry.get('name') or '',
                                entry.get('logo') or ''))
        playlist.add(_live_item_url(queue_id, position, selected), item)
    queue['appended_to'] = target
    _update_live_queue(queue_id, target)

def _set_repeat_all(kind='video'):

    playerid = 1 if (kind or 'video') == 'video' else 0
    request = json.dumps({
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'Player.SetRepeat',
        'params': {'playerid': playerid, 'repeat': 'all'},
    })
    try:
        response = xbmc.executeJSONRPC(request)
        if isinstance(response, str) and '"error"' not in response:
            return True
    except Exception:
        pass
    try:
        xbmc.executebuiltin('PlayerControl(RepeatAll)')
        return True
    except Exception:
        return False

def _start_repeat(kind='video'):

    def worker():
        player = xbmc.Player()
        for _ in range(20):
            try:
                if player.isPlaying():
                    _set_repeat_all(kind)
                    return
            except Exception:
                pass
            xbmc.sleep(250)

    try:
        thread = threading.Thread(target=worker, name='vavoo-repeat')
        thread.daemon = True
        thread.start()
    except Exception:
        common.log_exception()

def _live_item_url(queue_id, index, stream_index=0):
    query = urllib.parse.urlencode({
        'action': 'play_live_item',
        'queue': queue_id,
        'index': index,
        'stream': stream_index,
    })
    return 'plugin://%s/?%s' % (common.ADDON_ID, query)

def clear_live_state():
    path = os.path.join(common.PROFILE, 'live_state.json')
    try:
        os.remove(path)
    except OSError:
        pass

def _same_media(current, expected):
    if not current or not expected:
        return False
    expected = expected.split('|', 1)[0]
    if current == expected or expected in current or current in expected:
        return True
    try:
        return os.path.basename(current) == os.path.basename(expected)
    except Exception:
        return False

def _state_matches_player(state):
    if not state or time.time() - float(state.get('ts') or 0) > 8 * 3600:
        return False
    try:
        player = xbmc.Player()
        if not player.isPlaying():
            return False
        current = player.getPlayingFile()
    except Exception:
        return False
    expected = state.get('path') or state.get('stream_url') or ''
    return _same_media(current, expected) if expected and current else True

def _keymap_text():
    base = 'plugin://plugin.video.vavooto/?action=channel_zap'
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!-- plugin.video.vavooto live zap -->\n'
        '<keymap>\n'
        '  <FullscreenVideo>\n'
        '    <keyboard>\n'
        '      <pageup>RunPlugin(%s&amp;dir=1)</pageup>\n'
        '      <pagedown>RunPlugin(%s&amp;dir=-1)</pagedown>\n'
        '    </keyboard>\n'
        '    <remote>\n'
        '      <pageplus>RunPlugin(%s&amp;dir=1)</pageplus>\n'
        '      <pageminus>RunPlugin(%s&amp;dir=-1)</pageminus>\n'
        '    </remote>\n'
        '  </FullscreenVideo>\n'
        '</keymap>\n'
    ) % (base, base, base, base)

def _keymap_path():
    return xbmcvfs.translatePath(
        'special://profile/keymaps/vavooto_live.xml')

def ensure_keymap():

    enabled = common.setting_bool('live_zap', True)
    path = _keymap_path()
    try:
        existing = ''
        if os.path.isfile(path):
            with open(path, 'r', encoding='utf-8') as handle:
                existing = handle.read()
        content = _keymap_text()
        if not enabled:
            if existing and 'plugin.video.vavooto live zap' in existing:
                os.remove(path)
                xbmc.executebuiltin('ReloadKeymaps')
            return
        if existing == content:
            return
        if existing and 'plugin.video.vavooto live zap' not in existing:
            common.log('Keymap existiert bereits und wird nicht ueberschrieben')
            return
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with open(path, 'w', encoding='utf-8') as handle:
            handle.write(content)
        xbmc.executebuiltin('ReloadKeymaps')
        common.log('Senderwechsel-Keymap installiert')
    except Exception:
        common.log_exception()

def play_live(url, title, thumb='', live_context=None):

    if not url:
        return False
    raw_url = url.split('|', 1)[0]
    context = live_context or {}
    state = {}
    if live_context:
        state = _save_live_context(live_context, stream_url=raw_url)
    if state:
        channels = state.get('channels') or []
        index = int(state.get('index') or 0)
        stream_index = int(state.get('stream_index') or 0)
    else:
        channels = _compact_channels(context.get('channels') or [])
        try:
            index = int(context.get('index') or 0)
        except (TypeError, ValueError):
            index = 0
        if channels:
            index = max(0, min(len(channels) - 1, index))
        try:
            stream_index = int(context.get('stream_index') or 0)
        except (TypeError, ValueError):
            stream_index = 0

    session = None
    local_path = ''
    if timeshift.enabled():
        session = timeshift.prepare(raw_url, title, thumb)
        if session:
            local_path = session.path

    playlist_enabled = (bool(channels) and len(channels) > 1 and
                        common.setting_bool('live_zap', True))
    if playlist_enabled:
        window, position = _live_window(channels, index)
        window_start = index - position
        stream_indices = [0] * len(channels)
        stream_indices[index] = max(0, stream_index)
        queue_id = _write_live_queue(
            channels, stream_indices, kind='video',
            appended_to=window_start + len(window) - 1)
        if queue_id:
            full_url = _with_headers(
                url, {'User-Agent': LIVE_UA, 'seekable': '0'})
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            for offset, channel in enumerate(window):
                full_position = window_start + offset
                name = channel.get('name') or ''
                logo = channel.get('logo') or ''
                if full_position == index:
                    item = _live_video_listitem(
                        title or name, thumb or logo, local_path)
                    playlist.add(local_path or full_url, item)
                else:
                    item = _live_video_listitem(name, logo)
                    playlist.add(
                        _live_item_url(queue_id, full_position,
                                       stream_indices[full_position]), item)
            try:
                xbmc.Player().play(playlist, startpos=position)
            except TypeError:
                xbmc.Player().play(playlist)
            _start_repeat('video')
            _start_prefetch(queue_id,
                            {'channels': channels,
                             'stream_indices': stream_indices,
                             'appended_to': window_start + len(window) - 1},
                            (index + 1) % len(channels))
            timeshift.start_guard(session)
            if state:
                _update_live_state(path=local_path or full_url,
                                   stream_url=raw_url,
                                   stream_index=stream_index)
            common.log('Live-Playlist: %s (%d Sender im Fenster)' %
                       (title, len(window)))
            return True

    if local_path:
        session.play(title, thumb)
        timeshift.start_guard(session)
        if state:
            _update_live_state(path=local_path, stream_url=raw_url,
                               stream_index=stream_index)
        common.log('Live-Wiedergabe (Timeshift): %s' % title)
        return True

    url = _with_headers(url, {'User-Agent': LIVE_UA, 'seekable': '0'})
    item = _live_video_listitem(title, thumb)
    if state:
        _update_live_state(path=url, stream_url=raw_url,
                           stream_index=stream_index)
    common.log('Live-Wiedergabe: %s' % title)
    xbmc.Player().play(url, item)
    return True

def play_live_audio(url, title, thumb='', live_context=None):

    if not url or not common.setting_bool('live_zap', True):
        return False
    context = live_context or {}
    state = {}
    if live_context:
        state = _save_live_context(live_context, stream_url=url.split('|', 1)[0])
    if state:
        channels = state.get('channels') or []
        index = int(state.get('index') or 0)
        stream_index = int(state.get('stream_index') or 0)
    else:
        channels = _compact_channels(context.get('channels') or [])
        try:
            index = int(context.get('index') or 0)
        except (TypeError, ValueError):
            index = 0
        if channels:
            index = max(0, min(len(channels) - 1, index))
        try:
            stream_index = int(context.get('stream_index') or 0)
        except (TypeError, ValueError):
            stream_index = 0
    if len(channels) < 2:
        return False

    raw_url = url.split('|', 1)[0]
    full_url = _with_headers(url, {'User-Agent': LIVE_UA, 'seekable': '0'})
    timeshift.stop()
    _update_live_state(path=full_url, stream_url=raw_url,
                       stream_index=stream_index)
    window, position = _live_window(channels, index)
    window_start = index - position
    stream_indices = [0] * len(channels)
    stream_indices[index] = max(0, stream_index)
    queue_id = _write_live_queue(
        channels, stream_indices, kind='audio',
        appended_to=window_start + len(window) - 1)
    if not queue_id:
        return False

    playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    playlist.clear()
    for offset, channel in enumerate(window):
        full_position = window_start + offset
        name = channel.get('name') or ''
        logo = channel.get('logo') or ''
        if full_position == index:
            item = _audio_listitem(title or name, thumb or logo)
            playlist.add(full_url, item)
        else:
            item = _audio_listitem(name, logo)
            playlist.add(
                _live_item_url(queue_id, full_position,
                               stream_indices[full_position]), item)
    try:
        xbmc.Player().play(playlist, startpos=position)
    except TypeError:
        xbmc.Player().play(playlist)
    _start_repeat('audio')
    _start_prefetch(queue_id,
                    {'channels': channels,
                     'stream_indices': stream_indices,
                     'appended_to': window_start + len(window) - 1},
                    (index + 1) % len(channels))
    common.log('Audio-Live-Playlist: %s (%d Sender im Fenster)' %
               (title, len(window)))
    return True

def play_live_item(params, handle):

    queue = _read_live_queue((params or {}).get('queue') or '')
    channels = queue.get('channels') or []
    video = (queue.get('kind') or 'audio') == 'video'

    def failure_item():
        return _listitem('', '', '', 'video') if video else _audio_listitem('')
    try:
        index = int((params or {}).get('index') or 0)
    except (TypeError, ValueError):
        index = 0
    if not channels or index < 0 or index >= len(channels):
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, failure_item())
        return False
    entry = channels[index]
    streams = entry.get('streams') or []
    if not streams:
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, failure_item())
        return False

    queue_id = (params or {}).get('queue') or ''
    prefetched = _read_prefetch(queue_id, index)
    if prefetched:
        resolved = prefetched.get('url') or ''
        stream_url = prefetched.get('stream_url') or ''
        try:
            used = int(prefetched.get('stream_index') or 0)
        except (TypeError, ValueError):
            used = 0
    else:
        stream_indices = queue.get('stream_indices') or []
        try:
            selected = int(stream_indices[index] if index < len(stream_indices) else 0)
        except (TypeError, ValueError):
            selected = 0
        resolved, stream_url, used = _resolve_streams(streams, selected)
    if not resolved:
        common.notify(common.NAME, 'Sender nicht erreichbar: %s' %
                      (entry.get('name') or ''))
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, failure_item())
        return False

    full_url = _with_headers(
        resolved, {'User-Agent': LIVE_UA, 'seekable': '0'})
    local_path = ''
    session = None
    if video and timeshift.enabled():

        session = timeshift.prepare(
            resolved, entry.get('name') or '', entry.get('logo') or '')
        if session:
            local_path = session.path
    else:
        timeshift.stop()
    _update_live_state(index=index, stream_index=used,
                       path=local_path or full_url, stream_url=stream_url)
    _extend_live_playlist(queue_id, queue, index)
    _start_prefetch(queue_id, queue, (index + 1) % len(channels))
    if video:
        item = _live_video_listitem(entry.get('name') or '',
                                    entry.get('logo') or '', local_path)
    else:
        item = _audio_listitem(entry.get('name') or '', entry.get('logo') or '')
    try:
        item.setPath(local_path or full_url)
    except Exception:
        pass
    if handle is not None:
        xbmcplugin.setResolvedUrl(handle, True, item)
    if session:
        timeshift.start_guard(session)
    common.log('Sender gewechselt: %s%s' %
               (entry.get('name') or '',
                ' (Timeshift)' if local_path else ''))
    return True

def play_vod(url, title, thumb='', plot=''):
    timeshift.stop()
    clear_live_state()
    if not url:
        return False
    url = _with_headers(url, {'User-Agent': VOD_UA})
    item = _listitem(title, thumb, plot, 'movie')
    item.setProperty('IsPlayable', 'true')
    common.log('VOD-Wiedergabe: %s' % title)
    xbmc.Player().play(url, item)
    return True

def zap_live(direction=1):

    state = _read_live_state()
    if not _state_matches_player(state):
        return None
    raw_channels = state.get('channels') or []
    try:
        index = int(state.get('index') or 0)
        direction = 1 if int(direction) >= 0 else -1
    except (TypeError, ValueError):
        index, direction = 0, 1
    selected_key = ''
    if raw_channels and 0 <= index < len(raw_channels):
        selected_key = _channel_key(raw_channels[index])
    channels = _dedupe_channels(raw_channels)
    if len(channels) < 2:
        return None
    index = _index_for_key(channels, selected_key, index)
    index = (index + direction) % len(channels)
    entry = channels[index]
    streams = entry.get('streams') or []
    if not streams:
        return None
    try:
        stream_index = int(state.get('stream_index') or 0)
    except (TypeError, ValueError):
        stream_index = 0
    if stream_index >= len(streams):
        stream_index = 0
    stream = streams[stream_index]
    try:
        url = live.LiveClient().resolve_stream_url(stream.get('url') or '')
    except Exception:
        common.log_exception()
        url = ''
    if not url:
        common.notify(common.NAME, 'Naechster Sender nicht erreichbar.')
        return None

    context = {
        'channels': channels,
        'index': index,
        'stream_index': stream_index,
    }
    common.notify(common.NAME, 'Sender: %s' % (entry.get('name') or ''))
    if not play_live(url, entry.get('name') or '', entry.get('logo') or '',
                     live_context=context):
        return None
    return timeshift.current_path() or url

def wait_for_playback(path):

    player = xbmc.Player()
    try:
        while player.isPlaying():
            current = player.getPlayingFile()
            if path and current and not _same_media(current, path):
                break
            time.sleep(0.5)
    except Exception:
        pass
    finally:
        timeshift.stop()
