import sys
import urllib.parse

import xbmc

import common
import player

def _params():

    raw = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2] else ''
    if not raw:

        for candidate in sys.argv[:2]:
            if candidate and '?' in candidate:
                raw = candidate
                break
    if '?' in raw:
        raw = raw.split('?', 1)[1]
    parsed = {}
    for part in raw.split('&'):
        if '=' in part:
            key, value = part.split('=', 1)
            parsed[urllib.parse.unquote_plus(key)] = urllib.parse.unquote_plus(value)
    return parsed

def _handle():
    try:
        return int(sys.argv[1])
    except (IndexError, TypeError, ValueError):
        return None

def _finish_directory():

    handle = _handle()
    if handle is None:
        return
    try:
        import xbmcplugin
        xbmcplugin.endOfDirectory(
            handle, succeeded=False, updateListing=False, cacheToDisc=False)
        common.log('Verzeichnis abgeschlossen (handle=%s)' % handle)
    except Exception:
        common.log_exception()
    try:
        xbmc.executebuiltin('Dialog.Close(busydialog)')
    except Exception:
        pass
    xbmc.sleep(30)

def _open_window():
    try:
        from gui import VavooWindow
        common.log('Oeffne Vavoo-Hauptfenster')

        window = VavooWindow('VavooMain.xml', common.PATH, 'Default', '1080i')
        _finish_directory()
        window.doModal()
        del window
        try:
            xbmc.executebuiltin('ActivateWindow(Home)')
        except Exception:
            pass
        common.log('Vavoo-Hauptfenster geschlossen')
    except Exception:
        common.log_exception()
        common.notify(
            common.NAME,
            'Das Vavoo-Fenster konnte nicht geoeffnet werden. Details im Kodi-Log.')

def main():
    common.log('Start v%s, Argumente=%r' % (common.version(), sys.argv[1:]))
    params = _params()
    action = (params.get('action') or '').lower()

    if action in ('refresh_live', 'clear_cache'):
        common.clear_cache()
        if action == 'refresh_live':
            common.notify(common.NAME, 'Senderliste wird neu geladen.')
        else:
            common.notify(common.NAME, 'Cache geleert.')
        return

    if action == 'play_live_item':
        player.play_live_item(params, _handle())
        return

    if action == 'channel_zap':
        try:
            direction = int(params.get('dir') or 1)
        except (TypeError, ValueError):
            direction = 1
        target = player.zap_live(direction)
        if target:
            player.wait_for_playback(target)
        else:
            try:
                xbmc.executebuiltin(
                    'PlayerControl(Next)' if direction > 0
                    else 'PlayerControl(Previous)')
            except Exception:
                pass
        return

    try:
        player.ensure_keymap()
    except Exception:
        common.log_exception()

    _open_window()
