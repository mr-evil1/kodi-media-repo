import threading
import time

import xbmc
import xbmcgui

import common
import favorites
import live
import player
import vod

MENU = [
    ('LIVE TV', 'menu-live.png'),
    ('FAVORITEN', 'menu-favorites.png'),
    ('FILME', 'menu-movies.png'),
    ('SERIEN', 'menu-series.png'),
    ('SUCHE', 'menu-search.png'),
]

MENU_INDEX = {'live': 0, 'favorites': 1, 'movie': 2, 'series': 3}

_LAST_STATE = {'stack': []}
_EPG_REFRESH_SECONDS = 30

class VavooWindow(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXML.__init__(self, *args)
        self.stack = []
        self.groups = None
        self.live_channels = None
        self.live_client = None
        self.vod = vod
        self.current_items = []
        self._ignore_back_until = 0.0
        self._epg_stop = threading.Event()
        self._epg_wake = threading.Event()
        self._epg_thread = None
        self._epg_target = None
        self._preview_thread = None
        self._preview_index = -1
        self._live_context = None

    def onInit(self):
        try:
            self._progress_visible(False)
            menu = self._control(9000)
            if menu is not None:
                try:
                    menu.reset()
                except Exception:
                    pass
                for label, icon_name in MENU:
                    item = xbmcgui.ListItem(label, offscreen=True)
                    icon = common.media(icon_name)
                    if icon:
                        try:
                            item.setArt({'icon': icon, 'thumb': icon})
                        except Exception:
                            pass
                    menu.addItem(item)
            self._set_label(9008, 'Kodi 22 - v%s' % common.version())
            self._set_label(9102, 'Portal: %s' % common.setting('live_portal', 'geil.to'))
            self._start_epg_worker()
            if not self._restore_last_view(menu):
                self.open_section({'type': 'live_groups'}, 0)
            common.log('Hauptfenster aufgebaut')
        except Exception as error:
            common.log_exception()
            common.notify(common.NAME, 'Fensteraufbau fehlgeschlagen: %s' % error)
            self._close_window()

    def _restore_last_view(self, menu):
        saved = [view for view in (_LAST_STATE.get('stack') or [])
                 if isinstance(view, dict) and view.get('type')]
        if not saved:
            return False
        self.stack = saved
        index = self._menu_index_for(saved[0])
        if menu is not None and index is not None:
            try:
                menu.selectItem(index)
            except Exception:
                pass
        self.render(saved[-1])
        return True

    def _menu_index_for(self, view):
        view_type = (view or {}).get('type')
        if view_type == 'live_groups':
            return 0
        if view_type == 'favorites':
            return 1
        if view_type == 'vod_catalogs':
            return 2 if view.get('kind') == 'movie' else 3
        return None

    def _control(self, control_id):
        try:
            return self.getControl(control_id)
        except Exception:
            return None

    def _set_label(self, control_id, text):
        control = self._control(control_id)
        if control is not None:
            try:
                control.setLabel(text)
            except Exception:
                pass

    def _set_text(self, control_id, text):
        control = self._control(control_id)
        if control is not None:
            try:
                control.setText(text)
            except Exception:
                pass

    def _set_image(self, control_id, path):
        control = self._control(control_id)
        if control is not None:
            try:
                control.setImage(path or '')
            except Exception:
                pass

    def open_section(self, view, menu_index=None):
        self.stack = [view]
        if menu_index is not None:
            menu = self._control(9000)
            if menu is not None:
                try:
                    menu.selectItem(menu_index)
                except Exception:
                    pass
        self.render(view)

    def goto(self, view):
        self.stack.append(view)
        self.render(view)

    def go_back(self):
        if len(self.stack) > 1:
            self.stack.pop()
            self.render(self.stack[-1])
        else:
            self._close_window()

    def _close_window(self):

        self._epg_stop.set()
        self._epg_target = None
        self._epg_wake.set()
        try:
            xbmc.executebuiltin('ActivateWindow(Home)')
        except Exception:
            pass
        self.close()

    def onDeinit(self):
        self._epg_stop.set()
        self._epg_target = None
        self._epg_wake.set()

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (9, 10, 92):

            if time.time() < self._ignore_back_until:
                self._ignore_back_until = 0.0
                return
            self.go_back()
            return
        if action_id == 117:
            self.toggle_favorite()
            return

    def onClick(self, control_id):
        if control_id == 9099:
            self.go_back()
        elif control_id == 9100:
            self._close_window()
        elif control_id == 9101:
            self.open_settings()
        elif control_id == 9000:
            menu = self._control(9000)
            if menu is not None:
                self.on_menu(menu.getSelectedPosition())
        elif control_id == 9001:
            control = self._control(9001)
            if control is not None:
                self.on_select(control.getSelectedPosition())

    def onFocus(self, control_id):
        if control_id == 9001:
            control = self._control(9001)
            if control is not None:
                self.update_preview(control.getSelectedPosition())

    def on_menu(self, index):
        if index == 0:
            self.open_section({'type': 'live_groups'}, 0)
        elif index == 1:
            self.open_section({'type': 'favorites'}, 1)
        elif index == 2:
            self.open_section({'type': 'vod_catalogs', 'kind': 'movie'}, 2)
        elif index == 3:
            self.open_section({'type': 'vod_catalogs', 'kind': 'series'}, 3)
        elif index == 4:
            self.do_search()

    def on_select(self, index):
        if index < 0 or index >= len(self.current_items):
            return
        action = self.current_items[index].get('action') or {}
        kind = action.get('kind')
        try:
            if kind == 'load_live':
                if self.load_live(force=True) is not None:
                    self.open_section({'type': 'live_groups'}, 0)
            elif kind == 'group':
                self.goto({'type': 'live_group', 'group': action.get('group')})
            elif kind == 'live':
                self.play_live(action.get('entry') or {})
            elif kind == 'catalog':
                self.open_catalog(action.get('media') or 'movie',
                                  action.get('catalog'),
                                  action.get('sort'), action.get('label'))
            elif kind == 'more':
                view = action.get('view') or {}
                self.open_catalog(view.get('kind'), view.get('catalog'),
                                  view.get('sort'), view.get('label'),
                                  cursor=view.get('next'))
            elif kind == 'vod':
                self.open_vod_item(action.get('item') or {})
            elif kind == 'season':
                self.open_episodes(action.get('item') or {},
                                   action.get('season') or 1)
            elif kind == 'episode':
                self.play_vod(action.get('item') or {},
                              action.get('season') or 1,
                              action.get('episode') or 1)
            elif kind == 'stream':

                if action.get('stream_kind') == 'live':
                    self.play_live_stream(action.get('entry') or {},
                                          action.get('stream') or {})
                else:
                    self.play_vod_stream(action.get('item') or {},
                                         action.get('season') or 0,
                                         action.get('episode') or 0,
                                         action.get('stream') or {})
        except Exception as error:
            common.log_exception()
            common.notify(common.NAME, str(error) or 'Unbekannter Fehler.')

    def render(self, view):
        try:
            _LAST_STATE['stack'] = list(self.stack)
            view_type = view.get('type')
            if view_type == 'live_groups':
                self.render_groups()
            elif view_type == 'favorites':
                self.render_favorites()
            elif view_type == 'live_group':
                self.render_group(view.get('group'))
            elif view_type == 'vod_catalogs':
                self.render_catalogs(view.get('kind') or 'movie')
            elif view_type == 'vod_list':
                self.render_vod_list(view)
            elif view_type == 'vod_seasons':
                self.render_seasons(view)
            elif view_type == 'vod_episodes':
                self.render_episodes(view)
            elif view_type == 'stream_choice':
                self.render_stream_choice(view)
            elif view_type == 'search':
                self.render_search(view)
        except Exception as error:
            common.log_exception()
            self._set_status('Fehler: %s' % error)

    def render_groups(self):
        self._set_label(9003, 'LIVE TV')
        if self.groups is None:
            cached = live.load_cached()
            if cached:
                self.live_channels = cached
                self.groups = live.build_groups(cached)
        if self.groups is None:
            items = [self._item(
                'Senderliste laden',
                'Live-TV Sender vom Portal holen',
                '', common.media('menu-live.png'),
                {'kind': 'load_live'},
                'Die Senderliste wird einmalig vom gewaehlten Portal geladen '
                'und danach im Cache gehalten. Das kann einige Sekunden dauern.',
                'video')]
            self.set_items(items, 'Noch keine Senderliste vorhanden.')
            return

        items = []
        for group in self.groups:
            count = len(group['entries'])
            items.append(self._item(
                group['label'],
                '%d Sender' % count,
                '', common.flag(group['flag']),
                {'kind': 'group', 'group': group['group']},
                '%d Sender in der Gruppe %s.' % (count, group['label']),
                'video'))
        portal = common.setting('live_portal', 'geil.to')
        self.set_items(items, '%d Gruppen - Portal: %s' % (len(items), portal))

    def render_favorites(self):
        self._set_label(9003, 'FAVORITEN')
        menu = self._control(9000)
        if menu is not None:
            try:
                menu.selectItem(MENU_INDEX['favorites'])
            except Exception:
                pass

        if self.live_channels is None:
            cached = live.load_cached()
            if cached:
                self.live_channels = cached
                self.groups = live.build_groups(cached)

        fresh = {}
        for entry in live.build_channel_entries(self.live_channels or []):
            fresh[(live.channel_key(entry.get('name')),
                   (entry.get('group') or '').lower())] = entry

        stored = favorites.load()
        items = []
        for entry in stored['live']:
            key = (live.channel_key(entry.get('name')),
                   (entry.get('group') or '').lower())
            items.append(self._channel_item(fresh.get(key, entry)))
        for item in stored['vod']:
            items.append(self._vod_item(item))

        if not items:
            self.set_items([], 'Noch keine Favoriten. In einer Liste die '
                              'MENÜ-Taste (oder C) drücken.')
        else:
            self.set_items(items, '%d Favoriten - MENÜ = entfernen' % len(items))

    def render_group(self, group_name):
        group = None
        for candidate in self.groups or []:
            if candidate['group'] == group_name:
                group = candidate
                break
        if not group:
            self.set_items([], 'Diese Gruppe ist nicht mehr vorhanden.')
            return
        self._set_label(9003, group['label'])
        items = []
        for entry in group['entries']:
            streams = entry.get('streams') or []
            items.append(self._item(
                entry['name'],
                '%d Stream(s) - %s' % (len(streams), group['label']),
                entry.get('logo') or '', common.flag(group['flag']),
                {'kind': 'live', 'entry': entry},
                '', 'video'))
        self.set_items(items, '%d Sender in %s' % (len(items), group['label']))

    def render_catalogs(self, kind):
        title = 'FILME' if kind == 'movie' else 'SERIEN'
        self._set_label(9003, title)
        menu_index = MENU_INDEX.get(kind)
        if menu_index is not None:
            menu = self._control(9000)
            if menu is not None:
                try:
                    menu.selectItem(menu_index)
                except Exception:
                    pass
        catalog = 'tmdb.movie' if kind == 'movie' else 'tmdb.series'
        icon = common.media('menu-movies.png' if kind == 'movie' else 'menu-series.png')
        items = []
        for entry in vod.CATALOGS.get(kind) or []:
            items.append(self._item(
                entry['label'],
                title.capitalize(),
                '', icon,
                {'kind': 'catalog', 'media': kind, 'catalog': catalog,
                 'sort': entry['sort'], 'label': entry['label']},
                '', 'video'))
        self.set_items(items, 'Katalog für %s wählen' % title.lower())

    def render_vod_list(self, view):
        self._set_label(9003, view.get('label') or ('Filme' if view.get('kind') == 'movie' else 'Serien'))
        items = []
        for entry in view.get('items') or []:
            items.append(self._vod_item(entry))
        if view.get('next'):
            items.append(self._item(
                'Weiter',
                'Nächste Ergebnisse laden',
                '', common.media('menu-search.png'),
                {'kind': 'more', 'view': view},
                '', 'video'))
        self.set_items(items, '%d Einträge' % len(items))

    def render_seasons(self, view):
        item = view.get('item') or {}
        self._set_label(9003, item.get('name') or 'Staffeln')
        items = []
        for season in view.get('items') or []:
            items.append(self._item(
                season.get('label') or ('Staffel %d' % season.get('season', 0)),
                'Serie',
                season.get('thumb') or item.get('poster') or '',
                common.media('menu-series.png'),
                {'kind': 'season', 'item': item, 'season': season.get('season')},
                season.get('plot') or '',
                'season'))
        self.set_items(items, '%d Staffeln' % len(items))

    def render_episodes(self, view):
        item = view.get('item') or {}
        season = view.get('season') or 1
        self._set_label(9003, '%s - Staffel %d' % (item.get('name') or '', season))
        items = []
        for episode in view.get('items') or []:
            items.append(self._item(
                episode.get('label') or ('E%02d' % episode.get('episode', 0)),
                'Staffel %d' % season,
                episode.get('thumb') or item.get('poster') or '',
                common.media('menu-series.png'),
                {'kind': 'episode', 'item': item, 'season': season,
                 'episode': episode.get('episode')},
                episode.get('plot') or '',
                'episode'))
        self.set_items(items, '%d Episoden' % len(items))

    def render_stream_choice(self, view):
        if view.get('stream_kind') == 'live':
            entry = view.get('entry') or {}
            streams = view.get('items') or []
            self._set_label(9003, 'STREAM WÄHLEN')
            items = []
            for position, stream in enumerate(streams, 1):
                items.append(self._item(
                    stream.get('name') or ('Stream %d' % position),
                    'Stream %d von %d' % (position, len(streams)),
                    entry.get('logo') or '', common.media('menu-live.png'),
                    {'kind': 'stream', 'stream_kind': 'live',
                     'entry': entry, 'stream': stream},
                    '', 'video'))
            self.set_items(
                items, '%s - %d Stream(s)' % (entry.get('name') or '', len(items)))
            return

        item = view.get('item') or {}
        season = view.get('season') or 0
        episode = view.get('episode') or 0
        title = item.get('name') or 'Stream wählen'
        if season:
            title = '%s - S%02dE%02d' % (title, season, episode)
        self._set_label(9003, '%s - Quellen' % title)
        items = []
        for mirror in view.get('items') or []:
            meta = '%s - %s' % (mirror.get('quality') or 'HD',
                                mirror.get('lang') or '?')
            if mirror.get('direct'):
                meta += ' - direkt'
            items.append(self._item(
                mirror.get('name') or 'Quelle', meta,
                item.get('poster') or '', common.media('menu-movies.png'),
                {'kind': 'stream', 'stream_kind': 'vod',
                 'item': item, 'season': season, 'episode': episode,
                 'stream': mirror},
                item.get('plot') or '', 'movie'))
        self.set_items(items, '%d Quellen - OK = abspielen' % len(items))

    def render_search(self, view):
        query = view.get('query') or ''
        self._set_label(9003, 'SUCHE: %s' % query)
        items = view.get('items') or []
        self.set_items(items, 'Keine Treffer für "%s".' % query)

    def open_settings(self):
        try:
            common.ADDON.openSettings()
        except Exception:
            common.log_exception()
        self.live_client = None
        self.groups = None
        self.live_channels = None
        try:
            player.ensure_keymap()
        except Exception:
            common.log_exception()
        self._set_label(9102, 'Portal: %s' % common.setting('live_portal', 'geil.to'))
        if self.stack:
            self.render(self.stack[-1])
        else:
            self.open_section({'type': 'live_groups'}, 0)

    def load_live(self, force=False, silent=False):
        if not silent:
            self._progress_start('Senderliste wird geladen...')

        def progress(count, alive):
            if not silent:
                self._progress_update(
                    min(95, 5 + count // 15),
                    'Senderliste wird geladen... %d Sender' % count)

        try:
            channels = live.get_channels(force=force, progress=progress)
        except Exception as error:
            common.log_exception()
            if not silent:
                self._progress_stop()
                common.notify(common.NAME, str(error))
            return None
        if not silent:
            self._progress_stop()
        self.live_channels = channels
        self.live_client = None
        self.groups = live.build_groups(channels)
        return channels

    def do_search(self):
        query = xbmcgui.Dialog().input('Suche', type=xbmcgui.INPUT_ALPHANUM)
        if not query or not query.strip():
            return
        query = query.strip()

        channels = self.live_channels or live.load_cached()
        if channels is None:
            channels = self.load_live()

        items = []
        for entry in live.search_channels(channels or [], query)[:80]:
            items.append(self._channel_item(entry, prefix='LIVE'))
        items.extend(self.search_vod(query))
        self.goto({'type': 'search', 'query': query, 'items': items})

    def search_vod(self, query):
        self._progress_start('Filme und Serien werden durchsucht...')
        found = []
        try:
            for kind, catalog in (('movie', 'tmdb.movie'), ('series', 'tmdb.series')):
                try:
                    results, _ = vod.browse(catalog, 'popularity', search=query)
                except Exception:
                    results = []
                if common.german_only() and results:
                    self._progress_update(20, 'Deutsche Treffer werden geprüft...')
                    results = vod.filter_german(
                        results, progress=self._language_progress)
                for entry in results[:30]:
                    found.append(self._vod_item(entry))
        finally:
            self._progress_stop()
        return found

    def _language_progress(self, done, total):
        percent = 12 + int(80 * done / max(1, total))
        self._progress_update(
            percent, 'Deutsche Titel werden geprüft... %d/%d' % (done, total))

    def _vod_item(self, entry):
        is_series = entry.get('type') == 'series'
        meta = ' '.join(part for part in (
            '(%s)' % entry['year'] if entry.get('year') else '',
            'Serie' if is_series else 'Film') if part)
        return self._item(
            entry.get('name') or '',
            meta,
            entry.get('poster') or '',
            common.media('menu-series.png' if is_series else 'menu-movies.png'),
            {'kind': 'vod', 'item': entry},
            entry.get('plot') or '',
            'tvshow' if is_series else 'movie')

    def _channel_item(self, entry, prefix=''):
        label = entry.get('name') or ''
        if prefix:
            label = '%s - %s' % (prefix, label)
        streams = entry.get('streams') or []
        group = entry.get('group') or ''
        return self._item(
            label,
            '%d Stream(s)%s' % (len(streams), ' - %s' % group if group else ''),
            entry.get('logo') or '',
            common.media('menu-live.png'),
            {'kind': 'live', 'entry': entry},
            '', 'video')

    def open_catalog(self, kind, catalog, sort, label, cursor=None):
        self._progress_start('%s wird geladen...' % (label or 'Katalog'))
        try:
            items, next_cursor = self.vod.browse(catalog, sort, cursor=cursor)
            if common.german_only() and items:
                self._progress_update(12, 'Deutsche Titel werden geprüft...')
                items = self.vod.filter_german(
                    items, progress=self._language_progress)
        except Exception as error:
            common.log_exception()
            common.notify(common.NAME, str(error))
            return
        finally:
            self._progress_stop()
        self.goto({
            'type': 'vod_list',
            'kind': kind,
            'catalog': catalog,
            'sort': sort,
            'label': label,
            'items': items,
            'next': next_cursor,
        })

    def open_vod_item(self, item):
        if item.get('type') == 'series':
            self._progress_start('Staffeln werden geladen...')
            try:
                found = self.vod.seasons(item)
            except Exception as error:
                common.log_exception()
                found = []
                common.notify(common.NAME, str(error))
            finally:
                self._progress_stop()
            if not found:
                common.notify(common.NAME, 'Keine Staffeln gefunden.')
                return
            self.goto({'type': 'vod_seasons', 'item': item, 'items': found})
        else:
            self.play_vod(item)

    def open_episodes(self, item, season):
        self._progress_start('Episoden werden geladen...')
        try:
            found = self.vod.episodes(item, season)
        except Exception as error:
            common.log_exception()
            found = []
            common.notify(common.NAME, str(error))
        finally:
            self._progress_stop()
        if not found:
            common.notify(common.NAME, 'Keine Episoden gefunden.')
            return
        self.goto({'type': 'vod_episodes', 'item': item,
                   'season': season, 'items': found})

    def play_live(self, entry):
        self._live_context = self._build_live_context(entry)
        streams = entry.get('streams') or []
        if not streams:
            common.notify(common.NAME, 'Kein Stream für diesen Sender.')
            return
        if len(streams) == 1:
            self.play_live_stream(entry, streams[0])
            return
        self.goto({'type': 'stream_choice', 'stream_kind': 'live',
                   'entry': entry, 'items': streams})

    def play_live_stream(self, entry, stream):
        self._progress_start('Stream wird gestartet...')
        try:
            client = self.get_live_client()
            url = client.resolve_stream_url(stream.get('url') or '')
        except Exception:
            common.log_exception()
            url = ''
        finally:
            self._progress_stop()

        if not url:
            common.notify(common.NAME, 'Dieser Sender ist gerade nicht erreichbar.')
            return
        context = dict(self._live_context or self._build_live_context(entry))
        streams = entry.get('streams') or []
        context['stream_index'] = 0
        for position, candidate in enumerate(streams):
            if candidate.get('url') == stream.get('url'):
                context['stream_index'] = position
                break
        self._guard_playback()
        if player.is_audio_entry(entry):
            if player.play_live_audio(
                    url, entry.get('name') or '', entry.get('logo') or '',
                    live_context=context):
                return
        player.play_live(url, entry.get('name') or '', entry.get('logo') or '',
                         live_context=context)

    def _build_live_context(self, entry):
        entries = []
        index = 0
        selected_name = live.channel_key((entry or {}).get('name')).lower()
        selected_group = ((entry or {}).get('group') or '').strip().lower()

        def matches(candidate):
            if not isinstance(candidate, dict):
                return False
            name = live.channel_key(candidate.get('name')).lower()
            group = (candidate.get('group') or '').strip().lower()
            return (name == selected_name and
                    (not selected_group or group == selected_group))

        for data in self.current_items:
            action = data.get('action') or {}
            if action.get('kind') != 'live':
                continue
            candidate = action.get('entry') or {}
            if not entries and (candidate is entry or matches(candidate)):
                index = 0
            entries.append(candidate)

        if self.live_channels:
            known = set()
            for candidate in entries:
                if isinstance(candidate, dict):
                    known.add((live.channel_key(candidate.get('name')).lower(),
                               (candidate.get('group') or '').strip().lower()))
            for candidate in live.build_channel_entries(self.live_channels):
                identity = (live.channel_key(candidate.get('name')).lower(),
                            (candidate.get('group') or '').strip().lower())
                if identity in known:
                    continue
                known.add(identity)
                entries.append(candidate)

        if not entries:
            entries = [entry]
            index = 0
        else:
            index = 0
            for position, candidate in enumerate(entries):
                if candidate is entry or matches(candidate):
                    index = position
                    break
        return {'channels': entries, 'index': index}

    def play_vod(self, item, season=0, episode=0):
        self._progress_start('Quellen werden gesucht...')
        try:
            found = self.vod.mirrors(item, season, episode)
        except Exception as error:
            common.log_exception()
            found = []
            common.notify(common.NAME, str(error))
        finally:
            self._progress_stop()

        if not found:
            if common.german_only():
                common.notify(common.NAME, 'Keine deutsche Quelle für diesen Titel gefunden.')
            else:
                common.notify(common.NAME, 'Keine abspielbare Quelle gefunden.')
            return
        if common.setting_int('vod_stream_select', 0) == 1:
            best = self.best_mirror(found)
            if not best:
                common.notify(common.NAME, 'Keine passende Quelle gefunden.')
                return
            self.play_vod_stream(item, season, episode, best)
            return
        self.goto({'type': 'stream_choice', 'stream_kind': 'vod',
                   'item': item, 'season': season, 'episode': episode,
                   'items': found})

    def play_vod_stream(self, item, season, episode, mirror):
        source = mirror.get('url') or ''
        self._progress_start('Stream wird vorbereitet...')
        try:
            resolved = self.vod.resolve(source) or ''
        except Exception:
            common.log_exception()
            resolved = ''
        finally:
            self._progress_stop()

        if self.vod.is_playable_resolution(source, resolved):

            url = resolved
        elif mirror.get('direct') and resolved:
            url = resolved
        else:
            url = (player.resolve_hoster(resolved or source)
                   or player.resolve_hoster(source) or '')
        if not url:
            common.log('Quelle fehlgeschlagen: %s' % source[:180])
            if common.german_only():
                common.notify(common.NAME, 'Keine deutsche Quelle abspielbar. '
                              'Bitte eine andere Quelle wählen.')
            else:
                common.notify(common.NAME, 'Quelle nicht abspielbar. '
                              'Bitte eine andere Quelle wählen.')
            return

        title = item.get('name') or ''
        if season:
            title += ' - S%02dE%02d' % (season, episode)
        self._guard_playback()
        player.play_vod(url, title, item.get('poster') or '', item.get('plot') or '')

    def best_mirror(self, mirrors):
        ordered = self.vod.sort_mirrors(
            mirrors, german_only=common.german_only())
        return ordered[0] if ordered else {}

    def get_live_client(self):
        if self.live_client is None:
            self.live_client = live.LiveClient()
        return self.live_client

    def set_items(self, items, status=''):
        self.current_items = items
        control = self._control(9001)
        if control is None:
            return
        control.reset()
        for data in items:
            control.addItem(self._listitem(data))
        if items:
            control.selectItem(0)
            self.update_preview(0)
            self.setFocusId(9001)
        else:
            self.update_preview(None)
            self.setFocusId(9000)
        self._set_status(status or 'Keine Einträge gefunden.')

    def _set_status(self, text):
        self._set_label(9004, text)

    def _item(self, label, label2='', thumb='', icon='', action=None,
              plot='', mediatype='video'):
        return {
            'label': common.clean(label),
            'label2': common.clean(label2),
            'thumb': thumb or '',
            'icon': icon or '',
            'plot': common.clean(plot),
            'action': action or {},
            'mediatype': mediatype,
        }

    def _listitem(self, data):
        item = xbmcgui.ListItem(data['label'], offscreen=True)
        try:
            item.setLabel2(data.get('label2') or '')
        except Exception:
            pass

        art = {'fanart': common.FANART}
        for key in ('thumb', 'poster', 'icon'):
            if data.get(key):
                art[key] = data[key]
        try:
            item.setArt(art)
        except Exception:
            pass

        try:
            item.setProperty('plot', data.get('plot') or '')
        except Exception:
            pass

        try:
            tag = item.getVideoInfoTag()
            tag.setTitle(data['label'])
            if data.get('plot'):
                tag.setPlot(data['plot'])
            tag.setMediaType(data.get('mediatype') or 'video')
        except Exception:
            pass
        return item

    def update_preview(self, index):
        if index is None or index < 0 or index >= len(self.current_items):
            self._preview_index = -1
            self._clear_epg()
            self._set_label(9007, '')
            self._set_text(9002, '')
            self._set_image(9006, '')
            return
        self._preview_index = index
        data = self.current_items[index]
        action = data.get('action') or {}
        entry = action.get('entry') if action.get('kind') == 'live' else None
        if entry is not None:
            self._set_label(9007, data.get('label') or '')
            self._set_image(9006, data.get('thumb') or data.get('icon') or '')
            self._begin_epg(entry)
            self._render_epg(self._epg_target)
            return
        self._clear_epg()
        self._set_label(9007, data.get('label') or '')
        self._set_text(9002, data.get('plot') or data.get('label2') or '')
        self._set_image(9006, data.get('thumb') or data.get('icon') or '')

    def _epg_key(self, entry):
        return '%s|%s' % (live.channel_key((entry or {}).get('name')).lower(),
                          ((entry or {}).get('group') or '').strip().lower())

    def _begin_epg(self, entry):
        key = self._epg_key(entry)
        if self._epg_target and self._epg_target.get('key') == key:
            return
        self._epg_target = {
            'key': key,
            'name': (entry or {}).get('name') or '',
            'group': (entry or {}).get('group') or '',
            'epg': list((entry or {}).get('epg') or []),
            'ts': 0.0,
            'rendered': 0.0,
            'fetching': False,
        }
        self._epg_wake.set()

    def _clear_epg(self):
        if self._epg_target is not None:
            self._epg_target = None
            self._epg_wake.set()

    def _start_epg_worker(self):
        if (self._epg_thread and self._epg_thread.is_alive() and
                self._preview_thread and self._preview_thread.is_alive()):
            return
        self._epg_stop.clear()
        if not (self._epg_thread and self._epg_thread.is_alive()):
            self._epg_thread = threading.Thread(target=self._epg_loop)
            self._epg_thread.daemon = True
            self._epg_thread.start()
        if not (self._preview_thread and self._preview_thread.is_alive()):
            self._preview_thread = threading.Thread(target=self._preview_loop)
            self._preview_thread.daemon = True
            self._preview_thread.start()

    def _preview_loop(self):
        while not self._epg_stop.is_set():
            self._sync_preview()
            self._epg_stop.wait(0.4)

    def _sync_preview(self):

        try:
            if self._epg_stop.is_set() or not self.current_items:
                return
            control = self._control(9001)
            if control is None:
                return
            index = control.getSelectedPosition()
            if index >= 0 and index != self._preview_index:
                self.update_preview(index)
        except Exception:
            pass

    def _epg_loop(self):
        while not self._epg_stop.is_set():
            target = self._epg_target
            if target is not None:
                if time.time() - float(target.get('ts') or 0) >= _EPG_REFRESH_SECONDS:
                    self._refresh_epg(target)
                elif time.time() - float(target.get('rendered') or 0) >= 10:
                    self._render_epg(target)
            self._epg_wake.wait(2.0)
            self._epg_wake.clear()

    def _refresh_epg(self, target):
        if self._epg_stop.is_set() or target is not self._epg_target:
            return
        if target.get('fetching'):
            return
        target['fetching'] = True
        try:
            client = self.live_client
            if client is None:
                client = live.LiveClient()
                self.live_client = client
            programs = client.get_epg(target.get('name') or '',
                                      target.get('group') or '')
        except Exception as error:
            common.log('EPG konnte nicht geladen werden: %s' % error)
            programs = None
        finally:
            target['fetching'] = False
        if self._epg_stop.is_set() or target is not self._epg_target:
            return
        if programs is not None:
            target['epg'] = list(programs)
            target['ts'] = time.time()
            for data in self.current_items:
                action = data.get('action') or {}
                entry = action.get('entry') or {}
                if (action.get('kind') == 'live' and
                        self._epg_key(entry) == target['key']):
                    entry['epg'] = list(programs)
        else:
            target['ts'] = time.time()
        target['rendered'] = 0.0
        self._render_epg(target)

    def _render_epg(self, target):
        if target is None or target is not self._epg_target:
            return
        if self._epg_stop.is_set():
            return
        try:
            if target.get('fetching') and not target.get('epg'):
                text = 'EPG wird geladen ...'
            else:
                text = live.format_epg(target.get('epg') or [])
                if not text:
                    text = ('EPG wird geladen ...' if not target.get('ts')
                            else 'Keine Programmdaten für diesen Sender.')
            self._set_text(9002, text)
            target['rendered'] = time.time()
        except Exception:
            pass

    def _preview_move(self, action_id):
        try:
            if self.getFocusId() != 9001:
                return
            control = self._control(9001)
            if control is None:
                return
            index = control.getSelectedPosition()
            count = len(self.current_items)
            if count <= 1:
                return
            step = {4: 1, 3: -1, 6: 4, 5: -4}.get(action_id)
            if not step:
                return
            index = max(0, min(count - 1, index + step))
            self.update_preview(index)
        except Exception:
            pass

    def toggle_favorite(self):
        control = self._control(9001)
        index = control.getSelectedPosition() if control is not None else -1
        if index < 0 or index >= len(self.current_items):
            return
        action = self.current_items[index].get('action') or {}
        kind = action.get('kind')
        if kind == 'live':
            entry = action.get('entry') or {}
            if favorites.has_live(entry):
                favorites.remove_live(entry)
                common.notify(common.NAME, 'Sender aus Favoriten entfernt.')
            else:
                favorites.add_live(entry)
                common.notify(common.NAME, 'Sender zu Favoriten hinzugefügt.')
        elif kind == 'vod':
            item = action.get('item') or {}
            if favorites.has_vod(item):
                favorites.remove_vod(item)
                common.notify(common.NAME, 'Titel aus Favoriten entfernt.')
            else:
                favorites.add_vod(item)
                common.notify(common.NAME, 'Titel zu Favoriten hinzugefügt.')
        else:
            common.notify(common.NAME, 'Dieser Eintrag kann nicht als Favorit gespeichert werden.')
            return
        if self.stack and self.stack[-1].get('type') == 'favorites':
            self.render(self.stack[-1])

    def _guard_playback(self):

        self._ignore_back_until = time.time() + 3.0
        viewer = xbmc.Player()

        def watch():
            try:
                time.sleep(0.5)
                while viewer.isPlaying():
                    time.sleep(0.5)
            except Exception:
                pass
            self._ignore_back_until = time.time() + 1.2

        thread = threading.Thread(target=watch)
        thread.daemon = True
        thread.start()

    def _progress_start(self, message):

        self._set_label(9011, message)
        self._progress_percent(5)
        self._progress_visible(True)

        time.sleep(0.04)

    def _progress_update(self, percent, message=None):
        if message is not None:
            self._set_label(9011, message)
        self._progress_percent(percent)

    def _progress_stop(self):
        self._progress_visible(False)
        self._set_label(9011, '')
        self._progress_percent(0)

    def _progress_percent(self, percent):
        bar = self._control(9010)
        if bar is not None:
            try:
                bar.setPercent(max(0, min(100, int(percent))))
            except Exception:
                pass

    def _progress_visible(self, visible):
        for control_id in (9010, 9011):
            control = self._control(control_id)
            if control is not None:
                try:
                    control.setVisible(visible)
                except Exception:
                    pass
