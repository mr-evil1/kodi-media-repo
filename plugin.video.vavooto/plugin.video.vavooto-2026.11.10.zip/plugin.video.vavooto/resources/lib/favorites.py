import json
import os

import common
import live

_FILE = os.path.join(common.PROFILE, 'favorites.json')

_LIVE_FIELDS = ('name', 'group', 'logo', 'streams')
_VOD_FIELDS = ('name', 'type', 'imdb', 'tmdb', 'poster', 'year', 'plot')

def load():
    data = {}
    try:
        with open(_FILE, 'r', encoding='utf-8') as handle:
            loaded = json.load(handle)
        if isinstance(loaded, dict):
            data = loaded
    except (OSError, ValueError):
        data = {}
    if not isinstance(data.get('live'), list):
        data['live'] = []
    if not isinstance(data.get('vod'), list):
        data['vod'] = []
    return data

def save(data):
    tmp = _FILE + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(data, handle, ensure_ascii=False)
        os.replace(tmp, _FILE)
    except OSError:
        common.log_exception()

def _clean_live(entry):
    cleaned = {key: entry.get(key) for key in _LIVE_FIELDS}
    cleaned['name'] = (cleaned.get('name') or '').strip()
    cleaned['group'] = (cleaned.get('group') or '').strip()
    cleaned['streams'] = list(cleaned.get('streams') or [])
    return cleaned

def _clean_vod(item):
    cleaned = {key: item.get(key) for key in _VOD_FIELDS}
    cleaned['name'] = (cleaned.get('name') or '').strip()
    cleaned['type'] = 'series' if cleaned.get('type') == 'series' else 'movie'
    return cleaned

def live_key(entry):

    return '%s|%s' % ((entry.get('group') or '').strip().lower(),
                      live.channel_key(entry.get('name')).casefold())

def vod_key(item):
    if item.get('imdb'):
        return 'imdb:%s|%s' % (item['imdb'], item.get('type'))
    if item.get('tmdb'):
        return 'tmdb:%s|%s' % (item['tmdb'], item.get('type'))
    return 'name:%s|%s|%s' % (
        (item.get('name') or '').strip().casefold(),
        item.get('year') or '',
        item.get('type'))

def has_live(entry):
    key = live_key(entry)
    return any(live_key(stored) == key for stored in load()['live'])

def add_live(entry):
    data = load()
    key = live_key(entry)
    if any(live_key(stored) == key for stored in data['live']):
        return
    data['live'].append(_clean_live(entry))
    save(data)

def remove_live(entry):
    data = load()
    key = live_key(entry)
    data['live'] = [stored for stored in data['live']
                    if live_key(stored) != key]
    save(data)

def has_vod(item):
    key = vod_key(item)
    return any(vod_key(stored) == key for stored in load()['vod'])

def add_vod(item):
    data = load()
    key = vod_key(item)
    if any(vod_key(stored) == key for stored in data['vod']):
        return
    data['vod'].append(_clean_vod(item))
    save(data)

def remove_vod(item):
    data = load()
    key = vod_key(item)
    data['vod'] = [stored for stored in data['vod']
                   if vod_key(stored) != key]
    save(data)
