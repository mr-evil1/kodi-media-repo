import os
import sys

import xbmc
import xbmcaddon

try:
    xbmc.executebuiltin('ActivateWindow(Home)')
    xbmc.executebuiltin('Dialog.Close(busydialog)')
except Exception:
    pass

_ADDON = xbmcaddon.Addon()
_LIB = os.path.join(_ADDON.getAddonInfo('path'), 'resources', 'lib')

if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

from addon import main

if __name__ == '__main__':
    main()
