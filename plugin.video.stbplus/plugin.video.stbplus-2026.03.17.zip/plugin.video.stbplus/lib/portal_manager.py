# -*- coding: utf-8 -*-
"""
Portal Manager for STBplus
Manages unlimited portal URLs with MAC addresses for switching
"""

import os
import json
import time
import random
import xbmc
import xbmcvfs
import xbmcgui
import xbmcaddon

ADDON = xbmcaddon.Addon()

class PortalManager:
    def __init__(self):
        self.addon_data_dir = xbmcvfs.translatePath('special://profile/addon_data/%s' % ADDON.getAddonInfo('id'))
        self.portals_file = os.path.join(self.addon_data_dir, 'portal_manager.json')
        self.current_portal_file = os.path.join(self.addon_data_dir, 'current_portal.json')
        self.ensure_addon_data_dir()
        
    def ensure_addon_data_dir(self):
        """Ensure addon data directory exists"""
        if not xbmcvfs.exists(self.addon_data_dir):
            xbmcvfs.mkdirs(self.addon_data_dir)
    
    def is_enabled(self):
        """Check if portal manager is enabled"""
        return ADDON.getSetting('portal_manager_enabled') == 'true'
    
    def enable(self, enabled=True):
        """Enable or disable portal manager"""
        ADDON.setSetting('portal_manager_enabled', 'true' if enabled else 'false')
        xbmc.log(f"[STBplus PortalManager] {'Enabled' if enabled else 'Disabled'}", xbmc.LOGINFO)
    
    def load_portals(self):
        """Load all saved portals"""
        if not os.path.exists(self.portals_file):
            return []
        
        try:
            with open(self.portals_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                portals = data.get('portals', [])
                xbmc.log(f"[STBplus PortalManager] Loaded {len(portals)} portals", xbmc.LOGINFO)
                return portals
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error loading portals: {e}", xbmc.LOGERROR)
            return []
    
    def save_portals(self, portals):
        """Save portals to file"""
        try:
            data = {
                'portals': portals,
                'last_updated': time.time()
            }
            with open(self.portals_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            xbmc.log(f"[STBplus PortalManager] Saved {len(portals)} portals", xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error saving portals: {e}", xbmc.LOGERROR)
            return False
    
    def add_portal(self, name, url, mac, description=""):
        """Add a new portal"""
        portals = self.load_portals()
        
        if not name or not url or not mac:
            xbmc.log("[STBplus PortalManager] Cannot add portal: missing required fields", xbmc.LOGWARNING)
            return False
        
        mac = self._normalize_mac_address(mac)
        if not mac:
            xbmc.log("[STBplus PortalManager] Cannot add portal: invalid MAC address", xbmc.LOGWARNING)
            return False
        
        url = self._normalize_portal_url(url)
        
        for portal in portals:
            existing_url = self._normalize_portal_url(portal.get('url', ''))
            existing_mac = self._normalize_mac_address(portal.get('mac', ''))
            
            if existing_url == url and existing_mac == mac:
                xbmc.log(f"[STBplus PortalManager] Portal with URL {url} and MAC {mac} already exists", xbmc.LOGINFO)
                return False
        
        original_name = name
        counter = 1
        while any(portal.get('name') == name for portal in portals):
            name = f"{original_name} ({counter})"
            counter += 1
        
        new_portal = {
            'id': str(int(time.time() * 1000)),  # Unique ID
            'name': name,
            'url': url,
            'mac': mac,
            'description': description,
            'added_at': time.time(),
            'last_used': None,
            'active': True
        }
        
        portals.append(new_portal)
        success = self.save_portals(portals)
        
        if success:
            xbmc.log(f"[STBplus PortalManager] Added portal: {name} ({url})", xbmc.LOGINFO)
        
        return success
    
    def remove_portal(self, portal_id):
        """Remove a portal by ID"""
        portals = self.load_portals()
        original_count = len(portals)
        
        portals = [p for p in portals if p.get('id') != portal_id]
        
        if len(portals) < original_count:
            self.save_portals(portals)
            xbmc.log(f"[STBplus PortalManager] Removed portal with ID {portal_id}", xbmc.LOGINFO)
            return True
        
        xbmc.log(f"[STBplus PortalManager] Portal with ID {portal_id} not found", xbmc.LOGWARNING)
        return False
    
    def update_portal(self, portal_id, **kwargs):
        """Update an existing portal"""
        portals = self.load_portals()
        
        for i, portal in enumerate(portals):
            if portal.get('id') == portal_id:
                for key, value in kwargs.items():
                    if key in ['name', 'url', 'mac', 'description', 'active']:
                        portal[key] = value
                
                portal['updated_at'] = time.time()
                self.save_portals(portals)
                xbmc.log(f"[STBplus PortalManager] Updated portal {portal_id}", xbmc.LOGINFO)
                return True
        
        xbmc.log(f"[STBplus PortalManager] Portal {portal_id} not found for update", xbmc.LOGWARNING)
        return False
    
    def get_active_portals(self):
        """Get all active portals"""
        portals = self.load_portals()
        active_portals = [p for p in portals if p.get('active', True)]
        xbmc.log(f"[STBplus PortalManager] Found {len(active_portals)} active portals", xbmc.LOGINFO)
        return active_portals
    
    def select_random_portal(self):
        """Select a random portal from active portals"""
        active_portals = self.get_active_portals()
        
        if not active_portals:
            xbmc.log("[STBplus PortalManager] No active portals available", xbmc.LOGWARNING)
            return None
        
        selected = random.choice(active_portals)
        
        success = self.set_current_portal(selected['id'])
        
        if success:
            xbmc.log(f"[STBplus PortalManager] Auto-selected random portal: {selected['name']}", xbmc.LOGINFO)
            return selected
        else:
            xbmc.log(f"[STBplus PortalManager] Failed to set random portal: {selected['name']}", xbmc.LOGERROR)
            return None
    
    def get_current_portal(self):
        """Get the currently selected portal"""
        if not os.path.exists(self.current_portal_file):
            return None
        
        try:
            with open(self.current_portal_file, 'r', encoding='utf-8') as f:
                current_data = json.load(f)
                portal_id = current_data.get('current_portal_id')
                
                if portal_id:
                    portals = self.load_portals()
                    for portal in portals:
                        if portal.get('id') == portal_id:
                            xbmc.log(f"[STBplus PortalManager] Current portal: {portal['name']}", xbmc.LOGINFO)
                            return portal
                
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error loading current portal: {e}", xbmc.LOGERROR)
        
        return None
    
    def set_current_portal(self, portal_id):
        """Set the current portal by ID"""
        try:
            portals = self.load_portals()
            for portal in portals:
                if portal.get('id') == portal_id:
                    portal['last_used'] = time.time()
                    self.save_portals(portals)
                    
                    current_data = {
                        'current_portal_id': portal_id,
                        'set_at': time.time()
                    }
                    
                    with open(self.current_portal_file, 'w', encoding='utf-8') as f:
                        json.dump(current_data, f, indent=2)
                    
                    xbmc.log(f"[STBplus PortalManager] Set current portal: {portal['name']}", xbmc.LOGINFO)
                    
                    self._perform_system_refresh(f"Portal '{portal['name']}' ausgewählt")
                    
                    return True
            
            xbmc.log(f"[STBplus PortalManager] Portal {portal_id} not found", xbmc.LOGWARNING)
            return False
            
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error setting current portal: {e}", xbmc.LOGERROR)
            return False
    
    def get_portal_config(self):
        """Get current portal configuration for use in globals.py"""
        xbmc.log("[STBplus PortalManager] get_portal_config() called", xbmc.LOGINFO)
        
        enabled = self.is_enabled()
        xbmc.log(f"[STBplus PortalManager] Portal manager enabled: {enabled}", xbmc.LOGINFO)
        
        if not enabled:
            xbmc.log("[STBplus PortalManager] Portal manager is disabled", xbmc.LOGINFO)
            return None, None
        
        portals = self.load_portals()
        active_portals = self.get_active_portals()
        xbmc.log(f"[STBplus PortalManager] Total portals: {len(portals)}, Active portals: {len(active_portals)}", xbmc.LOGINFO)
        
        if not active_portals:
            xbmc.log("[STBplus PortalManager] No active portals available!", xbmc.LOGWARNING)
            return None, None
        
        current_portal = self.get_current_portal()
        xbmc.log(f"[STBplus PortalManager] Current portal: {current_portal['name'] if current_portal else 'None'}", xbmc.LOGINFO)
        
        if not current_portal:
            xbmc.log("[STBplus PortalManager] No current portal set, auto-selecting random active portal", xbmc.LOGINFO)
            current_portal = self._select_random_portal_quiet()
            
            if current_portal:
                xbmc.log(f"[STBplus PortalManager] Auto-selected portal: {current_portal['name']}", xbmc.LOGINFO)
            else:
                xbmc.log("[STBplus PortalManager] Failed to auto-select portal", xbmc.LOGERROR)
        
        if current_portal:
            url = current_portal['url']
            mac = current_portal['mac']
            xbmc.log(f"[STBplus PortalManager] Providing config: {url}, {mac}", xbmc.LOGINFO)
            
            if not url or not mac:
                xbmc.log(f"[STBplus PortalManager] Invalid portal config - URL: '{url}', MAC: '{mac}'", xbmc.LOGERROR)
                return None, None
            
            return url, mac
        
        xbmc.log("[STBplus PortalManager] No portal configuration available", xbmc.LOGWARNING)
        return None, None
    
    def _select_random_portal_quiet(self):
        """Select a random portal without system refresh (for internal use)"""
        active_portals = self.get_active_portals()
        
        if not active_portals:
            return None
        
        selected = random.choice(active_portals)
        
        try:
            portals = self.load_portals()
            for portal in portals:
                if portal.get('id') == selected['id']:
                    portal['last_used'] = time.time()
                    self.save_portals(portals)
                    
                    current_data = {
                        'current_portal_id': selected['id'],
                        'set_at': time.time()
                    }
                    
                    with open(self.current_portal_file, 'w', encoding='utf-8') as f:
                        json.dump(current_data, f, indent=2)
                    
                    xbmc.log(f"[STBplus PortalManager] Quietly selected portal: {portal['name']}", xbmc.LOGINFO)
                    return portal
            
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error in quiet portal selection: {e}", xbmc.LOGERROR)
        
        return None
    
    def switch_portal(self):
        """Switch to next available portal"""
        active_portals = self.get_active_portals()
        
        if len(active_portals) <= 1:
            xbmc.log("[STBplus PortalManager] Not enough portals to switch", xbmc.LOGINFO)
            return False
        
        current_portal = self.get_current_portal()
        current_index = 0
        
        if current_portal:
            for i, portal in enumerate(active_portals):
                if portal['id'] == current_portal['id']:
                    current_index = i
                    break
        
        next_index = (current_index + 1) % len(active_portals)
        next_portal = active_portals[next_index]
        
        success = self.set_current_portal(next_portal['id'])
        
        if success:
            xbmc.log(f"[STBplus PortalManager] Switched to portal: {next_portal['name']}", xbmc.LOGINFO)
        
        return success
    
    def import_portals_from_text(self, text_data):
        """Import portals from text data (various formats including mr-evil1 UltraV3)"""
        imported_count = 0
        
        try:
            xbmc.log(f"[STBplus PortalManager] Starting import, text_data length: {len(text_data)}", xbmc.LOGINFO)
            xbmc.log(f"[STBplus PortalManager] Text preview: {text_data[:200]}...", xbmc.LOGINFO)
            
            if "mr-evil1 UltraV3" in text_data and "RealUrl ➤" in text_data:
                xbmc.log("[STBplus PortalManager] Detected mr-evil1 UltraV3 format", xbmc.LOGINFO)
                imported_count = self._import_mr_evil1_format(text_data)
            else:
                xbmc.log("[STBplus PortalManager] Using standard format import", xbmc.LOGINFO)
                imported_count = self._import_standard_format(text_data)
        
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error importing portals: {e}", xbmc.LOGERROR)
        
        xbmc.log(f"[STBplus PortalManager] Imported {imported_count} portals", xbmc.LOGINFO)
        return imported_count
    
    def _import_mr_evil1_format(self, text_data):
        """Import from mr-evil1 UltraV3 format"""
        import re
        imported_count = 0
        
        blocks = re.split(r'╭─● Hits by mr-evil1 UltraV3', text_data)
        
        existing_combinations = set()
        
        for block in blocks[1:]:  # Skip first empty block
            try:
                url_match = re.search(r'RealUrl ➤\s*([^\n\r]+)', block)
                if not url_match:
                    continue
                
                url = url_match.group(1).strip()
                
                mac_match = re.search(r'MacAdresse➤\s*([^\n\r]+)', block)
                if not mac_match:
                    continue
                
                mac = mac_match.group(1).strip()
                
                expire_match = re.search(r'Läuft bis➤\s*([^\n\r]+)', block)
                expire_date = expire_match.group(1).strip() if expire_match else "Unbekannt"
                
                channels_match = re.search(r'<<●>>\s*([^\n\r]+)', block)
                channels = channels_match.group(1).strip() if channels_match else ""
                
                url = self._normalize_portal_url(url)
                
                mac = self._normalize_mac_address(mac)
                
                if not url or not mac:
                    continue
                
                combination = f"{url}#{mac}"
                if combination in existing_combinations:
                    xbmc.log(f"[STBplus PortalManager] Skipping duplicate: {mac}", xbmc.LOGINFO)
                    continue
                
                existing_combinations.add(combination)
                
                mac_suffix = mac.split(':')[-2:] if ':' in mac else [mac[-4:]]
                portal_name = f"UltraV3-{'-'.join(mac_suffix)}"
                
                description_parts = [
                    f"mr-evil1 UltraV3",
                    f"Läuft bis: {expire_date}"
                ]
                
                if "VIP" in channels:
                    description_parts.append("VIP Account")
                
                if "DE ✨" in channels:
                    description_parts.append("Deutsche Kanäle")
                
                description = " | ".join(description_parts)
                
                success = self.add_portal(portal_name, url, mac, description)
                if success:
                    imported_count += 1
                    xbmc.log(f"[STBplus PortalManager] Imported: {portal_name} ({mac})", xbmc.LOGINFO)
                
            except Exception as e:
                xbmc.log(f"[STBplus PortalManager] Error processing block: {e}", xbmc.LOGWARNING)
                continue
        
        return imported_count
    
    def _import_standard_format(self, text_data):
        """Import from standard formats (lines, simple text, etc.)"""
        imported_count = 0
        
        lines = text_data.strip().split('\n')
        xbmc.log(f"[STBplus PortalManager] Processing {len(lines)} lines in standard format", xbmc.LOGINFO)
        
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            
            if not line or line.startswith('#'):
                i += 1
                continue
            
            if line.startswith('Server:'):
                url = line.replace('Server:', '').strip()
                xbmc.log(f"[STBplus PortalManager] Found Server line: {url}", xbmc.LOGINFO)
                
                mac = None
                for j in range(i + 1, min(i + 4, len(lines))):  # Check next 3 lines
                    next_line = lines[j].strip()
                    if next_line.startswith('MAC:'):
                        mac = next_line.replace('MAC:', '').strip()
                        xbmc.log(f"[STBplus PortalManager] Found MAC line: {mac}", xbmc.LOGINFO)
                        break
                
                if url and mac:
                    mac = self._normalize_mac_address(mac)
                    name = self._generate_portal_name(url)
                    
                    xbmc.log(f"[STBplus PortalManager] Attempting to add portal: {name}, {url}, {mac}", xbmc.LOGINFO)
                    if self.add_portal(name, url, mac, f"Imported from text"):
                        imported_count += 1
                        xbmc.log(f"[STBplus PortalManager] Successfully added portal {imported_count}", xbmc.LOGINFO)
                    else:
                        xbmc.log(f"[STBplus PortalManager] Failed to add portal (may be duplicate)", xbmc.LOGINFO)
                    
                    i = j + 1 if mac else i + 1
                    continue
            
            url = self._extract_url_from_line(line)
            mac = self._extract_mac_from_line(line)
            
            if url and mac:
                xbmc.log(f"[STBplus PortalManager] Found single-line format: {url}, {mac}", xbmc.LOGINFO)
                mac = self._normalize_mac_address(mac)
                name = self._generate_portal_name(url)
                
                if self.add_portal(name, url, mac, f"Imported from text"):
                    imported_count += 1
                    xbmc.log(f"[STBplus PortalManager] Successfully added portal {imported_count}", xbmc.LOGINFO)
            
            i += 1
        
        xbmc.log(f"[STBplus PortalManager] Standard format import completed: {imported_count} portals", xbmc.LOGINFO)
        return imported_count
    
    def _extract_url_from_line(self, line):
        """Extract URL from a text line"""
        import re
        
        if "RealUrl ➤" in line:
            match = re.search(r'RealUrl ➤\s*([^\n\r]+)', line)
            if match:
                return match.group(1).strip()
        
        url_patterns = [
            r'https?://[^\s<>"\']+(?:portal\.php|stalker_portal|/c/portal\.php|get\.php)[^\s<>"\']*',
            r'https?://[^\s<>"\']+:[0-9]+[^\s<>"\']*(?:/c/|/server/|portal)[^\s<>"\']*',
            r'https?://[^\s<>"\']+:[0-9]+[^\s<>"\']*',
            r'https?://[^\s<>"\']+',
        ]
        
        for pattern in url_patterns:
            match = re.search(pattern, line, re.IGNORECASE)
            if match:
                url = self._normalize_portal_url(match.group(0))
                if any(keyword in url.lower() for keyword in ['portal', 'stalker', 'c/', 'get.php', ':8080', ':8081', ':8000', ':8008']):
                    return url
        
        return None
    
    def _extract_mac_from_line(self, line):
        """Extract MAC address from a text line"""
        import re
        
        if "MacAdresse➤" in line:
            match = re.search(r'MacAdresse➤\s*([^\n\r]+)', line)
            if match:
                return self._normalize_mac_address(match.group(1).strip())
        
        mac_patterns = [
            r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})',  # XX:XX:XX:XX:XX:XX or XX-XX-XX-XX-XX-XX
            r'\b([0-9A-Fa-f]{12})\b',  # XXXXXXXXXXXX (12 hex chars)
            r'([0-9A-Fa-f]{2}\s){5}([0-9A-Fa-f]{2})'  # XX XX XX XX XX XX (space separated)
        ]
        
        for pattern in mac_patterns:
            match = re.search(pattern, line)
            if match:
                mac_candidate = match.group(0)
                normalized = self._normalize_mac_address(mac_candidate)
                if normalized and not all(c in '0:' for c in normalized) and not all(c in 'F:' for c in normalized):
                    return normalized
        
        return None
    
    def _normalize_portal_url(self, url):
        """Normalize portal URL: strip trailing slashes and MAG loader paths (/c, /p)"""
        import re
        if not url:
            return url
        url = url.strip().rstrip('/')
        url = re.sub(r'/[cp]$', '', url, flags=re.IGNORECASE)
        return url

    def _normalize_mac_address(self, mac):
        """Normalize MAC address to XX:XX:XX:XX:XX:XX format"""
        if not mac:
            return None
        
        mac = mac.strip()
        
        import re
        mac = re.sub(r'[^0-9A-Fa-f:-]', '', mac)
        
        if re.match(r'^[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}$', mac):
            return mac.upper()
        
        if ':' in mac:
            return mac.upper()
        elif '-' in mac:
            return mac.replace('-', ':').upper()
        elif len(mac) == 12:
            return ':'.join(mac.upper()[i:i+2] for i in range(0, 12, 2))
        
        return mac.upper()
    
    def _generate_portal_name(self, url):
        """Generate a portal name from URL"""
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            domain = parsed.netloc.split(':')[0]
            return f"Portal {domain}"
        except:
            return f"Portal {int(time.time())}"
    
    def _perform_system_refresh(self, message="Portal gewechselt"):
        """Perform complete system refresh after portal change"""
        import sys
        
        xbmc.log(f"[STBplus PortalManager] Performing system refresh: {message}", xbmc.LOGINFO)
        
        try:
            import xbmcgui
            xbmcgui.Dialog().notification(
                "STBplus Portal Manager",
                f"{message}\nSystem wird aktualisiert...",
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
            
            xbmc.executebuiltin('Container.Refresh')
            xbmc.sleep(1000)
            xbmc.executebuiltin('UpdateLocalAddons()')
            xbmc.sleep(1000)
            xbmc.executebuiltin('ReloadSkin()')
            xbmc.sleep(1000)
            xbmc.executebuiltin('Action(Back)')
            xbmc.sleep(1000)
            
            xbmc.log("[STBplus PortalManager] System refresh completed", xbmc.LOGINFO)
            
            sys.exit()
            
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error during system refresh: {e}", xbmc.LOGERROR)
    
    def debug_status(self):
        """Debug portal manager status - useful for troubleshooting"""
        xbmc.log("=== STBplus Portal Manager Debug Status ===", xbmc.LOGINFO)
        
        enabled = self.is_enabled()
        xbmc.log(f"[DEBUG] Portal Manager enabled: {enabled}", xbmc.LOGINFO)
        
        xbmc.log(f"[DEBUG] Addon data dir: {self.addon_data_dir}", xbmc.LOGINFO)
        xbmc.log(f"[DEBUG] Addon data dir exists: {os.path.exists(self.addon_data_dir)}", xbmc.LOGINFO)
        
        xbmc.log(f"[DEBUG] Portals file: {self.portals_file}", xbmc.LOGINFO)
        xbmc.log(f"[DEBUG] Portals file exists: {os.path.exists(self.portals_file)}", xbmc.LOGINFO)
        
        portals = self.load_portals()
        active_portals = self.get_active_portals()
        xbmc.log(f"[DEBUG] Total portals: {len(portals)}", xbmc.LOGINFO)
        xbmc.log(f"[DEBUG] Active portals: {len(active_portals)}", xbmc.LOGINFO)
        
        for i, portal in enumerate(portals):
            status = "ACTIVE" if portal.get('active', True) else "INACTIVE"
            xbmc.log(f"[DEBUG] Portal {i+1}: {portal['name']} ({status}) - {portal['url']} - {portal['mac']}", xbmc.LOGINFO)
        
        current = self.get_current_portal()
        xbmc.log(f"[DEBUG] Current portal: {current['name'] if current else 'None'}", xbmc.LOGINFO)
        
        url, mac = self.get_portal_config()
        xbmc.log(f"[DEBUG] get_portal_config() result: URL='{url}', MAC='{mac}'", xbmc.LOGINFO)
        
        xbmc.log("=== Portal Manager Debug Status Complete ===", xbmc.LOGINFO)
        
        return {
            'enabled': enabled,
            'total_portals': len(portals),
            'active_portals': len(active_portals),
            'current_portal': current['name'] if current else None,
            'config_url': url,
            'config_mac': mac
        }
    
    def export_portals_to_text(self, format='standard'):
        """Export all portals to text format"""
        try:
            xbmc.log(f"[STBplus PortalManager] Starting export in {format} format", xbmc.LOGINFO)
            
            portals = self.load_portals()
            
            if not portals:
                xbmc.log("[STBplus PortalManager] No portals to export", xbmc.LOGINFO)
                return "# Keine Portale zum Exportieren vorhanden"
            
            xbmc.log(f"[STBplus PortalManager] Exporting {len(portals)} portals", xbmc.LOGINFO)
            
            if format == 'mr-evil1':
                result = self._export_mr_evil1_format(portals)
            elif format == 'json':
                result = self._export_json_format(portals)
            else:
                result = self._export_standard_format(portals)
            
            xbmc.log(f"[STBplus PortalManager] Export successful, text length: {len(result)}", xbmc.LOGINFO)
            return result
                
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error in export_portals_to_text: {e}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"[STBplus PortalManager] Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            return f"# Fehler beim Export: {str(e)}"
    
    def _export_standard_format(self, portals):
        """Export in standard Server:/MAC: format"""
        try:
            lines = []
            lines.append("# STBplus Portal Manager Export")
            lines.append(f"# Exportiert am: {time.strftime('%Y-%m-%d %H:%M:%S')}")
            lines.append(f"# Anzahl Portale: {len(portals)}")
            lines.append("")
            
            for i, portal in enumerate(portals, 1):
                lines.append(f"# Portal {i}: {portal.get('name', 'Unbekannt')}")
                lines.append(f"Server: {portal.get('url', '')}")
                lines.append(f"MAC: {portal.get('mac', '')}")
                
                if portal.get('notes'):
                    lines.append(f"# Notizen: {portal['notes']}")
                
                if portal.get('created_at'):
                    try:
                        created_date = time.strftime('%Y-%m-%d', time.localtime(portal['created_at']))
                        lines.append(f"# Erstellt: {created_date}")
                    except (ValueError, OSError):
                        pass  # Skip invalid timestamps
                
                if portal.get('last_used'):
                    try:
                        last_used_date = time.strftime('%Y-%m-%d %H:%M', time.localtime(portal['last_used']))
                        lines.append(f"# Zuletzt verwendet: {last_used_date}")
                    except (ValueError, OSError):
                        pass  # Skip invalid timestamps
                
                lines.append("")  # Empty line between portals
            
            return '\n'.join(lines)
            
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error in _export_standard_format: {e}", xbmc.LOGERROR)
            return f"# Fehler beim Standard-Export: {str(e)}"
    
    def _export_json_format(self, portals):
        """Export in JSON format"""
        try:
            import json
            
            export_data = {
                'export_info': {
                    'tool': 'STBplus Portal Manager',
                    'version': '1.0',
                    'export_date': time.strftime('%Y-%m-%d %H:%M:%S'),
                    'portal_count': len(portals)
                },
                'portals': []
            }
            
            for portal in portals:
                portal_data = {
                    'name': portal.get('name', 'Unbekannt'),
                    'url': portal.get('url', ''),
                    'mac': portal.get('mac', ''),
                    'active': portal.get('active', True),
                    'notes': portal.get('notes', ''),
                    'created_at': portal.get('created_at'),
                    'last_used': portal.get('last_used')
                }
                export_data['portals'].append(portal_data)
            
            return json.dumps(export_data, indent=2, ensure_ascii=False)
            
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error in _export_json_format: {e}", xbmc.LOGERROR)
            return f"{{\n  \"error\": \"JSON-Export fehlgeschlagen: {str(e)}\"\n}}"
    
    def _export_mr_evil1_format(self, portals):
        """Export in mr-evil1 UltraV3 compatible format"""
        try:
            lines = []
            lines.append("# STBplus Portal Manager Export in mr-evil1 UltraV3 Format")
            lines.append(f"# Exportiert am: {time.strftime('%Y-%m-%d %H:%M:%S')}")
            lines.append("")
            
            for i, portal in enumerate(portals, 1):
                lines.append("╭─● Hits by mr-evil1 UltraV3")
                lines.append(f"RealUrl ➤ {portal.get('url', '')}")
                lines.append(f"MacAdresse➤ {portal.get('mac', '')}")
                
                try:
                    expire_date = time.strftime('%B %d, %Y', time.localtime(time.time() + 365*24*3600))
                    lines.append(f"Läuft bis➤ {expire_date}")
                except (ValueError, OSError):
                    lines.append("Läuft bis➤ December 31, 2025")
                
                lines.append(f"<<●>> {portal.get('name', 'Portal')}")
                
                if portal.get('notes'):
                    lines.append(f"# {portal['notes']}")
                
                lines.append("")  # Empty line between blocks
            
            return '\n'.join(lines)
            
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error in _export_mr_evil1_format: {e}", xbmc.LOGERROR)
            return f"# Fehler beim mr-evil1 Export: {str(e)}"
    
    def import_portals_from_text(self, text_data):
        """Import portals from text data with universal URL-MAC extraction"""
        try:
            xbmc.log("[STBplus PortalManager] Starting portal import from text", xbmc.LOGINFO)
            
            # Extract URL-MAC pairs using multiple parsing methods
            pairs = self._extract_url_mac_pairs_from_text(text_data)
            
            if not pairs:
                xbmc.log("[STBplus PortalManager] No URL-MAC pairs found in text", xbmc.LOGWARNING)
                return 0
            
            xbmc.log(f"[STBplus PortalManager] Extracted {len(pairs)} URL-MAC pairs", xbmc.LOGINFO)
            
            imported_count = 0
            for pair in pairs:
                url = pair.get('url', '').strip()
                mac = pair.get('mac', '').strip()
                
                if url and mac:
                    # Generate portal name from URL
                    portal_name = self._generate_portal_name(url)
                    
                    # Try to add the portal (add_portal handles duplicates)
                    success = self.add_portal(portal_name, url, mac, "Imported from file")
                    if success:
                        imported_count += 1
                        xbmc.log(f"[STBplus PortalManager] Imported: {portal_name} - {url} - {mac}", xbmc.LOGINFO)
                    else:
                        xbmc.log(f"[STBplus PortalManager] Skipped duplicate: {url} - {mac}", xbmc.LOGDEBUG)
            
            xbmc.log(f"[STBplus PortalManager] Successfully imported {imported_count} portals", xbmc.LOGINFO)
            return imported_count
            
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error importing portals from text: {e}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"[STBplus PortalManager] Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            return 0
    
    def _extract_url_mac_pairs_from_text(self, text_data):
        """Universal extraction of URL-MAC pairs from any text format"""
        import re
        
        try:
            # Enhanced URL pattern - captures http/https URLs more reliably
            url_pattern = r'https?://[^\s<>"\'`|(){}[\]]+(?:[^\s<>"\'`|(){}[\].,;!?)])?'
            mac_pattern = r'(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}'
            
            pairs = []
            lines = text_data.split('\n')
            
            xbmc.log("[STBplus PortalManager] Trying same-line pairing...", xbmc.LOGDEBUG)
            
            # Method 1: Same line pairing (highest priority)
            for line in lines:
                urls = re.findall(url_pattern, line, re.IGNORECASE)
                macs = re.findall(mac_pattern, line)
                
                if urls and macs:
                    for i, url in enumerate(urls):
                        if i < len(macs):
                            mac_normalized = self._normalize_mac_address(macs[i])
                            if mac_normalized:
                                pairs.append({'url': url.strip(), 'mac': mac_normalized})
            
            xbmc.log(f"[STBplus PortalManager] Same-line pairs found: {len(pairs)}", xbmc.LOGDEBUG)
            
            # Method 2: Adjacent line pairing (if not enough same-line pairs)
            if len(pairs) < 5:  # Threshold for trying adjacent pairing
                xbmc.log("[STBplus PortalManager] Trying adjacent-line pairing...", xbmc.LOGDEBUG)
                
                for i, line in enumerate(lines):
                    urls = re.findall(url_pattern, line, re.IGNORECASE)
                    
                    if urls:
                        # Look for MAC in surrounding lines (prev, current, next)
                        search_lines = []
                        if i > 0:
                            search_lines.append(lines[i-1])  # Previous line
                        search_lines.append(line)  # Current line
                        if i < len(lines) - 1:
                            search_lines.append(lines[i+1])  # Next line
                        
                        macs_found = []
                        for search_line in search_lines:
                            found_macs = re.findall(mac_pattern, search_line)
                            macs_found.extend(found_macs)
                        
                        for j, url in enumerate(urls):
                            if j < len(macs_found):
                                mac_normalized = self._normalize_mac_address(macs_found[j])
                                if mac_normalized:
                                    pair = {'url': url.strip(), 'mac': mac_normalized}
                                    # Avoid duplicates
                                    pair_key = (pair['url'], pair['mac'])
                                    if not any((p['url'], p['mac']) == pair_key for p in pairs):
                                        pairs.append(pair)
            
            xbmc.log(f"[STBplus PortalManager] After adjacent pairing: {len(pairs)}", xbmc.LOGDEBUG)
            
            # Method 3: Proximity-based pairing (for complex formats)
            if len(pairs) < 3:  # If still not enough pairs
                xbmc.log("[STBplus PortalManager] Trying proximity-based pairing...", xbmc.LOGDEBUG)
                
                all_urls = []
                all_macs = []
                
                # Find all URLs and MACs with their positions
                for match in re.finditer(url_pattern, text_data, re.IGNORECASE):
                    all_urls.append({
                        'url': match.group().strip(),
                        'pos': match.start()
                    })
                
                for match in re.finditer(mac_pattern, text_data):
                    mac_normalized = self._normalize_mac_address(match.group())
                    if mac_normalized:
                        all_macs.append({
                            'mac': mac_normalized,
                            'pos': match.start()
                        })
                
                # Pair by proximity (max 1000 characters apart)
                used_macs = set()
                for url_info in all_urls:
                    closest_mac = None
                    min_distance = float('inf')
                    
                    for mac_info in all_macs:
                        if mac_info['mac'] in used_macs:
                            continue
                            
                        distance = abs(url_info['pos'] - mac_info['pos'])
                        if distance < min_distance and distance < 1000:
                            min_distance = distance
                            closest_mac = mac_info
                    
                    if closest_mac:
                        pair = {'url': url_info['url'], 'mac': closest_mac['mac']}
                        # Avoid duplicates
                        pair_key = (pair['url'], pair['mac'])
                        if not any((p['url'], p['mac']) == pair_key for p in pairs):
                            pairs.append(pair)
                            used_macs.add(closest_mac['mac'])
            
            # Remove duplicates while preserving order
            unique_pairs = []
            seen = set()
            for pair in pairs:
                key = (pair['url'].lower(), pair['mac'].upper())
                if key not in seen:
                    seen.add(key)
                    unique_pairs.append(pair)
            
            xbmc.log(f"[STBplus PortalManager] Final extraction: {len(unique_pairs)} unique pairs", xbmc.LOGINFO)
            
            return unique_pairs
            
        except Exception as e:
            xbmc.log(f"[STBplus PortalManager] Error in URL-MAC extraction: {e}", xbmc.LOGERROR)
            return []

portal_manager = PortalManager()