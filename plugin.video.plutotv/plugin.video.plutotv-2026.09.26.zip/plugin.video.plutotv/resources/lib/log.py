import xbmc

LOGDEBUG   = xbmc.LOGDEBUG
LOGINFO    = xbmc.LOGINFO
LOGWARNING = xbmc.LOGWARNING
LOGERROR   = xbmc.LOGERROR


def log(msg, level=LOGINFO):
    xbmc.log(str(msg), level)
