import sys

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

try:
    from urllib.parse import parse_qsl, urlencode, quote_plus
except ImportError:
    from urlparse import parse_qsl
    from urllib import urlencode, quote_plus

sys.path.insert(0, xbmcaddon.Addon().getAddonInfo('path'))
from resources.lib import plutotv

ADDON   = xbmcaddon.Addon()
HANDLE  = int(sys.argv[1])
BASE    = sys.argv[0]
ICON    = ADDON.getAddonInfo('path') + '/icon.png'
FANART  = ADDON.getAddonInfo('path') + '/fanart.jpg'

def _dbg(msg):
    try:
        xbmc.log('[PlutoTV DEBUG] ' + str(msg), xbmc.LOGINFO)
    except Exception:
        pass

def _url(**kwargs):
    return BASE + '?' + urlencode(
        {k: v for k, v in kwargs.items() if v is not None}
    )

def _params():
    return dict(parse_qsl(sys.argv[2][1:]))

def _add_item(entry, is_folder):
    icon = entry.get('icon') or entry.get('poster') or entry.get('thumb') or ICON
    fanart = entry.get('fanart') or FANART
    title = entry.get('title', '')

    li = xbmcgui.ListItem(label=title)
    li.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})

    infotag = li.getVideoInfoTag()
    infotag.setTitle(title)
    if entry.get('plot'):
        infotag.setPlot(entry['plot'])
    if entry.get('mediatype'):
        infotag.setMediaType(entry['mediatype'])
    if entry.get('year'):
        infotag.setYear(int(entry['year']))
    if entry.get('season') is not None:
        infotag.setSeason(int(entry['season']))
    if entry.get('episode') is not None:
        infotag.setEpisode(int(entry['episode']))

    if not is_folder:
        li.setProperty('IsPlayable', 'true')

    xbmcplugin.addDirectoryItem(
        HANDLE,
        _url(mode=entry.get('next_func', ''), url=entry.get('url', ''), name=title),
        li,
        is_folder,
    )

def root():
    _dbg('root()')
    for entry in plutotv.load():
        _add_item(entry, is_folder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def show_list(items):
    for entry in items:
        is_folder = not entry.get('is_playable', False)
        _add_item(entry, is_folder)
    xbmcplugin.endOfDirectory(HANDLE)

def play(url):
    hosters = plutotv.get_hosters(url=url)
    if not hosters:
        xbmcgui.Dialog().notification('Pluto TV', 'Stream nicht gefunden', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    label, stream_url, drm_info, subtitle, headers, site = hosters[0]
    play_item = xbmcgui.ListItem(label=label, path=stream_url)
    manifest_type = (drm_info or {}).get('manifest_type')
    if manifest_type:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setMimeType('application/dash+xml' if manifest_type == 'mpd' else 'application/vnd.apple.mpegurl')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream.adaptive.manifest_type', manifest_type)
        license_type = (drm_info or {}).get('license_type')
        license_key  = (drm_info or {}).get('license_key')
        if license_type and license_key:
            play_item.setProperty('inputstream.adaptive.license_type', license_type)
            play_item.setProperty('inputstream.adaptive.license_key', license_key)
    xbmcplugin.setResolvedUrl(HANDLE, True, play_item)

def show_search():
    term = xbmcgui.Dialog().input('Pluto TV Suche', type=xbmcgui.INPUT_ALPHANUM)
    if term:
        show_list(plutotv.search(query=term))
    else:
        xbmcplugin.endOfDirectory(HANDLE, False)

def main():
    params = _params()
    mode   = params.get('mode', '')
    url    = params.get('url', '')
    _dbg('main() mode=%r url=%r' % (mode, url))

    if not mode:
        root()
    elif mode == 'showGenres':
        show_list(plutotv.showGenres(url))
    elif mode == 'showCarousels':
        show_list(plutotv.showCarousels(url))
    elif mode == 'showEntries':
        show_list(plutotv.showEntries(url))
    elif mode == 'showSeasons':
        show_list(plutotv.showSeasons(url))
    elif mode == 'showEpisodes':
        show_list(plutotv.showEpisodes(url))
    elif mode == 'get_live':
        show_list(plutotv.get_live(url))
    elif mode == 'get_live_channels':
        show_list(plutotv.get_live_channels(url))
    elif mode == 'play_livefeed':
        hosters = plutotv.play_livefeed(url)
        if not hosters:
            xbmcgui.Dialog().notification('Pluto TV', 'Stream nicht gefunden', xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        else:
            label, stream_url, drm_info, subtitle, headers, site = hosters[0]
            play_item = xbmcgui.ListItem(label=label, path=stream_url)
            manifest_type = (drm_info or {}).get('manifest_type', 'hls')
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setMimeType('application/dash+xml' if manifest_type == 'mpd' else 'application/vnd.apple.mpegurl')
            play_item.setContentLookup(False)
            play_item.setProperty('inputstream.adaptive.manifest_type', manifest_type)
            if manifest_type == 'hls':
                play_item.setProperty('inputstream.adaptive.manifest_config',
                                      '{"hls_ignore_endlist":true,"hls_fix_mediasequence":true}')
            license_type = (drm_info or {}).get('license_type')
            license_key  = (drm_info or {}).get('license_key')
            if license_type and license_key:
                play_item.setProperty('inputstream.adaptive.license_type', license_type)
                play_item.setProperty('inputstream.adaptive.license_key', license_key)
            xbmcplugin.setResolvedUrl(HANDLE, True, play_item)
    elif mode == 'search':
        show_search()
    elif mode == 'get_hosters':
        play(url)
    else:
        _dbg('Unbekannter mode=%r' % mode)
        xbmcplugin.endOfDirectory(HANDLE, False)

if __name__ == '__main__':
    main()
