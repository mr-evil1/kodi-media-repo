import json
import os
import sys

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = "plugin.program.itspossiblewizard"
START_DELAY = 10


def evil_read_config(path):
    userdata = xbmcvfs.translatePath("special://profile/addon_data/%s/itspossible.json" % ADDON_ID)
    target = os.path.join(path, "resources", "itspossible.json")
    legacy = os.path.join(path, "resources", "evil.json")
    if os.path.isfile(userdata):
        read_path = userdata
    elif os.path.isfile(target):
        read_path = target
    elif os.path.isfile(legacy):
        read_path = legacy
    else:
        return None
    try:
        with open(read_path, "r", encoding="utf-8") as handle:
            config = json.load(handle)
    except (OSError, ValueError):
        return None
    return config if isinstance(config, dict) else None


def evil_autostart_enabled(config):
    if not isinstance(config, dict):
        return False
    return config.get("autostart", True) is not False


def evil_manual_build_installed():
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        getter = getattr(addon, "getSettingBool", None)
        if getter:
            try:
                return bool(getter("build_manual_installed"))
            except Exception:
                pass
        value = addon.getSetting("build_manual_installed")
        return str(value or "").strip().lower() in ("true", "1", "yes", "on")
    except Exception:
        return False


def evil_build_installed(path):
    if evil_manual_build_installed():
        return True
    config = evil_read_config(path)
    if config is None:
        return True
    return bool(config.get("installed_build") or config.get("build"))


def evil_run_background_tasks(config, addon_path):
    tasks = config.get("maintenance_autostart") if isinstance(config, dict) else None
    if not isinstance(tasks, list) or not tasks:
        return
    sys.path.insert(0, os.path.join(addon_path, "resources", "lib"))
    try:
        from evil_maintenance import EVIL_BACKGROUND_TASKS
    except Exception as error:
        xbmc.log("[IT'S-POSSIBLE WIZARD] Hintergrundaufgaben nicht ladbar: %s" % error, xbmc.LOGERROR)
        return
    seen = set()
    for task_id in tasks:
        if not isinstance(task_id, str) or task_id in seen:
            continue
        seen.add(task_id)
        task = EVIL_BACKGROUND_TASKS.get(task_id)
        if not task:
            continue
        try:
            task["run"]()
            xbmc.log("[IT'S-POSSIBLE WIZARD] Hintergrundaufgabe ausgeführt: %s" % task["label"], xbmc.LOGINFO)
        except Exception as error:
            xbmc.log("[IT'S-POSSIBLE WIZARD] Hintergrundaufgabe fehlgeschlagen: %s (%s)" % (task["label"], error), xbmc.LOGERROR)


def evil_run_ftp(addon_path):
    sys.path.insert(0, os.path.join(addon_path, "resources", "lib"))
    try:
        from evil_ftp import evil_ftp_service
    except Exception as error:
        xbmc.log("[IT'S-POSSIBLE WIZARD] FTP-Dienst nicht ladbar: %s" % error, xbmc.LOGERROR)
        return
    evil_ftp_service()


def evil_start():
    if xbmc.Monitor().waitForAbort(START_DELAY):
        return
    addon = xbmcaddon.Addon(ADDON_ID)
    addon_path = addon.getAddonInfo("path")
    config = evil_read_config(addon_path)
    if config is not None:
        evil_run_background_tasks(config, addon_path)
        if evil_autostart_enabled(config) and not evil_build_installed(addon_path):
            xbmc.executebuiltin("RunScript(%s,autostart)" % ADDON_ID)
    evil_run_ftp(addon_path)


if __name__ == "__main__":
    evil_start()
