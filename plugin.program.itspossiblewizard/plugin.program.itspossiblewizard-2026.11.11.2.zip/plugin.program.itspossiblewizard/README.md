# IT'S-POSSIBLE WIZARD

Kurzanleitung für Kodi 22. Die vollständige Buildbauer-Anleitung mit allen Funktionen, Formaten und Beispielen öffnest du im Browser über **Einstellungen → HILFE & ANLEITUNG → ANLEITUNG ÖFFNEN**. Oben in der Anleitung schaltest du mit **DE** und **EN** zwischen der deutschen und der englischen Fassung um.

## Installation

1. Die Datei `plugin.program.itspossiblewizard.zip` herunterladen.
2. In Kodi **Add-ons → Add-on-Browser → Aus Zip-Datei installieren** öffnen.
3. Die ZIP auswählen, die Warnung bestätigen und den Wizard unter **Programme** starten.
4. Build-Speicherort unter **Einstellungen → Speicherort** prüfen.

**Kodi 19:** Im Addon-Ordner `resources/settings19.xml` in `settings.xml` umbenennen, die vorhandene Datei vorher sichern und Kodi neu starten.

## Build erstellen

1. Kodi mit dem gewünschten Skin und den gewünschten Addons einrichten.
2. **BUILD ERSTELLEN** öffnen, Name und Version eintragen.
3. Addons und bei Bedarf Addondata markieren.
4. **ERSTELLEN** wählen. Turbo ist schneller; sicher erstellt vorsichtiger.
5. Die ZIP und die optionale TXT-Build-Liste liegen im Build-Speicherort.
6. Build auf einem sauberen Kodi testen, bevor du ihn veröffentlichst.

Die Build-ZIP enthält `addons/`, `userdata/` und weitere Kodi-Ordner. Caches, Pakete, Thumbnails und temporäre Dateien werden automatisch ausgelassen. Der Wizard wird beim Installieren eines Builds nicht überschrieben.

## Build installieren

Unter **BUILD INSTALLIEREN** wählst du Online- oder lokale Builds. Mehrere Build-Quellen können gleichzeitig aktiv sein. **BUILD QUELLEN** verwaltet die Auswahl; **SORTIEREN** sortiert nach Name, Größe, Datum, Quelle, Kodi- oder Build-Version. Vor einer Installation eine Sicherung anlegen. Unter Windows und Android startet Kodi nach der Installation automatisch neu. Auf CoreELEC und LibreELEC übernimmt der systemd-Dienst den Neustart. Auf anderen Linux-Systemen funktioniert das nur mit einem Kodi-Dienst oder Wrapper; sonst Kodi manuell starten.

## Darstellung anpassen

Unter **VERWALTEN → ANPASSEN** lassen sich Haupttitel, Schriftgröße, Titelfarbe, Ausrichtung, Position, Hintergrund-, Panel-, Akzent- und Textfarbe ändern. Der gemeinsame Titel erscheint auch in den Unterfenstern. Die Powered-by-Zeile ist fest und nicht änderbar. **SPEICHERN** ergänzt den Block `appearance` in `itspossible.json` im Userdata-Ordner; die übrigen Einstellungen bleiben erhalten. Die vorhandenen PNGs sind als Graustufen-Masken vorbereitet und werden über `colordiffuse` eingefärbt.

## Theme-Lautstärke

Der senkrechte Regler am rechten Rand läuft über die volle Höhe der linken Box. Er lässt sich per Touch ziehen oder mit der Fernbedienung bedienen. Der Regler reicht von 25 bis 100 Prozent; die Theme-Lautstärke fällt nie unter 25 Prozent. Beim Beenden wird die ursprüngliche Lautstärke wiederhergestellt.

## Quellen installieren

**QUELLEN AUSWÄHLEN** öffnet ein eigenes Wizard-Fenster. Dort sind alle Repository-Quellen aus **VERWALTEN** standardmäßig aktiv. Mit **INSTALLIEREN & AKTIVIEREN** werden alle markierten Repositories installiert und eingeschaltet.

## Addons installieren

Unter **ADDONS AUSWÄHLEN** wird bei Bedarf zuerst das Kodi-Media-Repository installiert und aktiviert und anschließend der Addon-Index aktualisiert. Benötigte Module wie `script.module.resolveurl` werden vor dem eigentlichen Addon installiert. Fehlt eine Abhängigkeit im Repository, startet der Wizard die Installation nicht und zeigt den Grund im Statusfenster statt in einem Kodi-Popup. Das gilt auch für Addons, die direkt aus der Repository installiert werden.

## Musik

Das Wizard-Theme startet standardmäßig bei 50 Prozent Lautstärke. Am rechten Rand des Hauptfensters stellst du sie mit **LAUTER** und **LEISER** ein. Die vorherige Kodi-Lautstärke wird beim Schließen des Wizards wiederhergestellt.

## Wartung

**WARTUNG** enthält Cache, Pakete, Thumbnails, Datenbank, Texturen, Addon-Aktivierung, Log, System, Sicherung, Wiederherstellung und Kodi-Neustart. Die ersten fünf Aufgaben lassen sich für den Hintergrundstart markieren. Dort liegen auch der FTP-Server, der Autostart-Schalter und **ERWEITERTE EINSTELLUNGEN** für die `advancedsettings.xml`. Der Wizard sichert vor Änderungen, bereinigt alte Tags und setzt Cache-Werte nur unter Kodi 19/20; ab Kodi 21 verweist er auf die Kodi-Einstellungen. Die Funktion läuft in eigenen Wizard-Fenstern: links Status, rechts Aktionen; Bestätigungen erscheinen im Wizard, nicht als Kodi-Popup. Zurück bricht ab.

## FTP

**WARTUNG → FTP-SERVER ÖFFNEN** startet die FTP-Verwaltung. Der eigene Reiter **FTP-Server** enthält Autostart, lokalen Modus, Port, Anmeldung und Freigabeordner. Standardmäßig sind Autostart und anonymer Zugang ausgeschaltet.

## Konfiguration

Die aktive Konfiguration liegt unter `userdata/addon_data/plugin.program.itspossiblewizard/itspossible.json`. Jede Änderung wird dort gespeichert; zusätzlich bleibt `resources/itspossible.json` im Addon als Standard- und Fallback-Datei erhalten. Existiert die Userdata-Datei, wird sie beim Start bevorzugt. Beim ersten Laden einer älteren Addon-Konfiguration wird automatisch eine Userdata-Kopie angelegt.

Die zuletzt eingegebene Build-ZIP-Adresse wird als `last_build_url` in der Konfiguration und zusätzlich als Addon-Einstellung gespeichert. Nach einer Wizard-Neuinstallation wird sie wieder ins ZIP-Feld übernommen.

## Einstellungen

- **Speicherort:** Zielordner für Builds.
- **Build-Installation:** Turbo, sichere Installation und **Build manuell installiert**. Ist der Schalter aktiv, geht der Wizard von einem installierten Build aus, startet beim Kodi-Start nicht automatisch und fragt nicht nach einer Build-Installation. Nach einer erfolgreichen Build-Installation wird er automatisch ausgeschaltet.
- **Build-Erstellung:** Turbo und sichere Erstellung.
- **FTP-Server:** Server, Anmeldung und Ordner.
- **Hilfe & Anleitung:** HTML-Anleitung und Browserauswahl.

Die ausführliche HTML-Anleitung erklärt zusätzlich TXT-, JSON- und XML-Build-Listen, `itspossible.json`, alle Wartungsfunktionen, FTP und Fehlerbehebung.
