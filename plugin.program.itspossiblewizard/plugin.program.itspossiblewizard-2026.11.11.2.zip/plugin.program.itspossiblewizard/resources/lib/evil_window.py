import os
import re
import threading
import time

import xbmc
import xbmcgui

import evil_ftp
from evil_appearance import EVIL_COLOR_PALETTE, EVIL_TITLE_ALIGNMENTS, EVIL_TITLE_FONTS, evil_appearance, evil_apply_skin, evil_apply_title, evil_apply_window
from evil_theme import EVIL_THEME_MIN_VOLUME
from evil_installer import (
    EvilCancelled,
    evil_active_build_sources,
    evil_build_addon_entries,
    evil_build_dir,
    evil_addon_enabled,
    evil_disable_foreign_wizards,
    evil_enable,
    evil_force_close,
    evil_installed,
    evil_kodi_major,
    evil_log,
    evil_open_settings,
    evil_normalize_url,
    evil_parse_builds,
    evil_plain_text,
    evil_public_url,
    evil_restart_kodi,
    evil_set_last_build_url,
    evil_turbo_create_enabled,
    evil_turbo_enabled,
)
from evil_maintenance import (
    EVIL_BACKGROUND_TASKS,
    EVIL_BACKUP_OPTIONS,
    evil_advanced_backup,
    evil_advanced_clean,
    evil_advanced_list_backups,
    evil_advanced_remove,
    evil_advanced_remove_cache,
    evil_advanced_restore,
    evil_advanced_status,
    evil_advanced_text,
    evil_advanced_write_cache,
    evil_backup_settings,
    evil_clean_databases,
    evil_clear_cache,
    evil_clear_packages,
    evil_clear_thumbnails,
    evil_enable_disabled_addons,
    evil_list_backups,
    evil_read_log,
    evil_reset_textures,
    evil_restore_addon_data,
    evil_restore_settings,
    evil_system_text,
)

EVIL_TITLE = "IT'S-POSSIBLE WIZARD"
EVIL_BACK_ACTIONS = (9, 10, 92, 110)
EVIL_BACKGROUND_CONTROLS = {
    201: "cache",
    202: "packages",
    203: "thumbnails",
    204: "database",
    205: "textures",
}
EVIL_MAIN_INFO = {
    102: {
        "title": "QUELLEN AUSWÄHLEN",
        "summary": "Repository-Quellen markieren und installieren.",
        "details": (
            "Eine oder mehrere Quellen auswählen.",
            "Der Wizard installiert die passenden Repositories.",
            "Eigene Quellen pflegst du unter VERWALTEN.",
        ),
        "action": "OK: Auswahl öffnen",
    },
    103: {
        "title": "ADDONS AUSWÄHLEN",
        "summary": "Kodi-Media-Addons durchsuchen und installieren.",
        "details": (
            "Addons markieren; mehrere gleichzeitig möglich.",
            "Ist die Liste leer, lädt der Wizard Kodi Media.",
            "Eigene Einträge pflegst du unter VERWALTEN.",
        ),
        "action": "OK: Addon-Liste öffnen",
    },
    107: {
        "title": "BUILD INSTALLIEREN",
        "summary": "Fertigen Build auswählen und installieren.",
        "details": (
            "Online-Liste und lokale Zips mit ONLINE/LOKAL umschalten.",
            "Build-Info, Kodi-Prüfung und Update-Anzeige.",
            "Sicherung und Neustart sind möglich.",
        ),
        "action": "OK: Build-Liste öffnen",
    },
    108: {
        "title": "BUILD ERSTELLEN",
        "summary": "Aktuelle Installation als Build-Zip sichern.",
        "details": (
            "Name und Version eingeben; danach Addons und Addondata auswählen.",
            "Jeden Eintrag einzeln oder mit ALLE WÄHLEN/ABWÄHLEN umschalten.",
            "Gewählte Addons/Addondata und alle übrigen Userdata kommen ins Zip.",
            "Nur Thumbnails, temp, cache, Pakete und Sicherungen bleiben draußen.",
            "Abbrechen über den Button im Hauptfenster.",
        ),
        "action": "OK: Erstellen starten",
    },
    104: {
        "title": "VERWALTEN",
        "summary": "Quellen, Build-Quellen und Addons pflegen.",
        "details": (
            "Einträge hinzufügen oder löschen.",
            "Aktive Build-Quelle festlegen.",
            "Änderungen landen direkt in itspossible.json im Userdata-Ordner.",
        ),
        "action": "OK: Verwaltung öffnen",
    },
    105: {
        "title": "WARTUNG",
        "summary": "Kodi aufräumen und den Wizard einstellen.",
        "details": (
            "Cache, Pakete, Thumbnails, Datenbanken und Texturen.",
            "Deaktivierte Addons aktivieren; Log und Sicherungen.",
            "Autostart des Wizards schalten.",
        ),
        "action": "OK: Wartung öffnen",
    },
    106: {
        "title": "BEENDEN",
        "summary": "Den It's-Possible Wizard schließen.",
        "details": (
            "Das Hauptfenster wird geschlossen.",
            "Keine Änderungen an Quellen, Addons oder Builds.",
        ),
        "action": "OK: schließen",
    },
    109: {
        "title": "README LESEN",
        "summary": "Anleitung und Funktionsübersicht direkt im Wizard lesen.",
        "details": (
            "Öffnet die README.md aus dem Addon-Ordner.",
            "Mit HOCH/RUNTER oder den Pfeiltasten scrollen, mit Zurück schließen.",
            "Enthält Installation, Builds, Wartung und Konfiguration.",
        ),
        "action": "OK: README öffnen",
    },
}


def evil_require_build_storage(status=None):
    if evil_build_dir(True):
        return True
    message = (
        "Es konnte kein Download- oder Ersatzordner für Builds angelegt werden. "
        "Bitte wähle einen beschreibbaren Build-Speicherort aus."
    )
    if status:
        status(message)
    else:
        xbmcgui.Dialog().ok(EVIL_TITLE, message)
    evil_open_settings()
    if evil_build_dir(True):
        return True
    message = "Kein gültiger Build-Speicherort ausgewählt."
    if status:
        status(message)
    else:
        xbmcgui.Dialog().ok(EVIL_TITLE, message)
    return False


def evil_confirm_dialog(addon_path, title, message, yes_label="JA", no_label="NEIN", subtitle=""):
    window = EvilConfirmWindow("script-itspossible-confirm.xml", addon_path, "Default", "1080i")
    window.evil_title = EVIL_TITLE
    window.evil_subtitle = "%s · %s" % (title, subtitle) if subtitle else title
    window.evil_text = message
    window.evil_yes_label = yes_label
    window.evil_no_label = no_label
    window.doModal()
    result = bool(window.evil_result)
    del window
    return result


def evil_text_dialog(addon_path, title, subtitle="", default="", required=True):
    window = EvilInputWindow("script-itspossible-input.xml", addon_path, "Default", "1080i")
    window.evil_title = title
    window.evil_subtitle = subtitle
    window.evil_default = default
    window.evil_required = required
    window.doModal()
    result = window.evil_result
    del window
    return result


def evil_url_dialog(title, default=""):
    default = evil_normalize_url(default)
    result = xbmcgui.Dialog().input(title, default, type=xbmcgui.INPUT_ALPHANUM)
    return evil_normalize_url(result) or None


class EvilMainWindow(xbmcgui.WindowXML):
    evil_config = {}
    evil_installer = None
    evil_addon_path = ""
    evil_theme = None
    evil_busy = False
    evil_abort = False

    def onInit(self):
        evil_apply_window(self)
        self.getControl(20).setLabel("Kodi 22 · It's-Possible Edition")
        self.getControl(21).setLabel("Bereit für böse Taten.")
        self.getControl(30).setVisible(False)
        self.getControl(31).setVisible(False)
        self.evil_refresh_volume()
        self.evil_refresh()
        self.setFocusId(102)
        self.evil_refresh_info(102)


    def evil_refresh_volume(self):
        theme = getattr(self, "evil_theme", None)
        value = int(getattr(theme, "evil_volume", 50) or 0) if theme is not None else 50
        value = max(EVIL_THEME_MIN_VOLUME, min(100, value))
        try:
            self.getControl(904).setInt(value, EVIL_THEME_MIN_VOLUME, 1, 100)
        except Exception:
            pass

    def evil_sync_slider_volume(self):
        theme = getattr(self, "evil_theme", None)
        if theme is None:
            return
        try:
            value = int(self.getControl(904).getInt())
        except Exception:
            return
        value = max(EVIL_THEME_MIN_VOLUME, min(100, value))
        try:
            self.getControl(904).setInt(value, EVIL_THEME_MIN_VOLUME, 1, 100)
        except Exception:
            pass
        theme.evil_set_volume(value)

    def evil_status_lines(self):
        sources = self.evil_config.get("sources", [])
        addons = self.evil_config.get("addons", [])
        build = self.evil_config.get("installed_build") or {}
        build_name = build.get("name") or "keiner"
        active_names = [
            entry.get("name") or entry.get("id") or ""
            for entry in evil_active_build_sources(self.evil_config)
        ]
        source = ", ".join(name for name in active_names if name) or "keine"
        return [
            "Quellen: %d · Addons: %d" % (len(sources), len(addons)),
            "Installierter Build: %s" % build_name,
            "Build-Quellen: %s" % source,
            "Build-Ordner: %s" % (evil_build_dir(False) or "noch nicht gewählt"),
        ]

    def evil_focused_id(self):
        try:
            focused = int(self.getFocusId())
        except Exception:
            focused = 102
        return focused if focused in EVIL_MAIN_INFO else 102

    def evil_refresh(self):
        self.evil_refresh_info()

    def evil_refresh_info(self, control_id=None):
        if control_id not in EVIL_MAIN_INFO:
            control_id = self.evil_focused_id()
        info = EVIL_MAIN_INFO[control_id]
        self.getControl(11).setLabel(info["title"])
        lines = self.evil_status_lines()
        lines.extend(["", info["summary"], ""])
        lines.extend(info["details"])
        lines.extend(["", info["action"]])
        self.getControl(10).setText("\n".join(lines))

    def onFocus(self, control_id):
        if control_id in EVIL_MAIN_INFO:
            self.evil_refresh_info(control_id)

    def evil_progress(self, percent, label=""):
        self.getControl(30).setPercent(int(percent))
        self.getControl(21).setLabel("IT'S-POSSIBLE: %s" % label)
        xbmc.sleep(20)

    def evil_cancelled(self):
        return self.evil_abort

    def evil_start(self, sources, addons):
        self.evil_busy = True
        self.evil_abort = False
        self.getControl(30).setVisible(True)
        self.getControl(30).setPercent(0)
        self.evil_installer.attach(self.evil_progress, self.evil_cancelled)
        failures = []
        try:
            failures = self.evil_installer.run_install(sources, addons)
        except EvilCancelled:
            failures = None
        except Exception as error:
            evil_log("IT'S-POSSIBLE Fehler: %s" % error, xbmc.LOGERROR)
            failures = ["Unbekannter Fehler"]
        finally:
            self.evil_installer.attach(None, None)
            self.evil_busy = False
            self.getControl(30).setVisible(False)
        self.evil_refresh()
        if failures is None:
            self.getControl(21).setLabel("IT'S-POSSIBLE abgebrochen.")
        elif failures:
            detail = ", ".join(failures[:3])
            if len(failures) > 3:
                detail += " und %d weitere" % (len(failures) - 3)
            self.getControl(21).setLabel("Nicht installiert: %s" % detail)
            evil_log("Nicht installiert: %s" % " | ".join(failures), xbmc.LOGWARNING)
        else:
            self.getControl(21).setLabel("IT'S-POSSIBLE fertig. Alles installiert.")

    def evil_create_build(self):
        if self.evil_busy:
            return
        if not evil_require_build_storage(lambda message: self.getControl(21).setLabel(message)):
            return
        turbo = evil_turbo_create_enabled()
        build_dir = evil_build_dir(False)
        name = evil_text_dialog(
            self.evil_addon_path,
            "BUILD ERSTELLEN",
            "Name des Builds",
            "Mein Build",
            True,
        )
        if name is None:
            return
        version = evil_text_dialog(
            self.evil_addon_path,
            "BUILD ERSTELLEN",
            "Version des Builds",
            "1.0",
            False,
        )
        if version is None:
            return
        version = version or "1.0"
        entries = evil_build_addon_entries()
        if not entries:
            self.getControl(21).setLabel("Keine installierten Addons oder Addondata gefunden.")
            return
        select_window = EvilBuildSelectWindow("script-itspossible-buildselect.xml", self.evil_addon_path, "Default", "1080i")
        select_window.evil_entries = entries
        select_window.evil_addon_path = self.evil_addon_path
        select_window.doModal()
        selection = select_window.evil_result
        del select_window
        if selection is None:
            return
        metadata = None
        if evil_confirm_dialog(
            self.evil_addon_path,
            "BUILD-LISTE",
            "Möchtest du zusätzlich eine TXT-Datei für eine Build-Liste erstellen?\n\n"
            "Darin werden Build-Adresse, Kodi-Version, Beschreibung, Icon und Fanart gespeichert.",
            yes_label="JA, TXT ERSTELLEN",
            no_label="OHNE TXT",
            subtitle="%s v%s" % (name, version),
        ):
            window = EvilBuildMetaWindow("script-itspossible-buildmeta.xml", self.evil_addon_path, "Default", "1080i")
            window.doModal()
            metadata = window.evil_result
            del window
        txt_line = "TXT: wird neben der Zip gespeichert.\n" if metadata else "TXT: keine.\n"
        selection_line = (
            "Addons: %d von %d ausgewählt · Addondata: %d von %d ausgewählt.\n"
            "Abgewählte Addons und Addondata werden nicht gepackt.\n"
            % (
                len(selection.get("addons", [])),
                selection.get("addon_total", 0),
                len(selection.get("addon_data", [])),
                selection.get("data_total", 0),
            )
        )
        message = (
            "Build aus der aktuellen Kodi-Installation erstellen?\n\n"
            "Enthalten: alle übrigen Userdata und die ausgewählten Addons/Addondata.\n"
            "Nicht enthalten: Thumbnails, temp, cache, addons/packages, Sicherungen sowie abgewählte Addons/Addondata.\n\n"
            "%s"
            "%s"
            "Ziel: %s\n\nWährend des Erstellens kannst du mit ABBRECHEN stoppen." % (txt_line, selection_line, build_dir)
        )
        if not turbo and not evil_confirm_dialog(
            self.evil_addon_path,
            "BUILD ERSTELLEN",
            message,
            yes_label="BUILD ERSTELLEN",
            no_label="ZURÜCK",
            subtitle="%s v%s" % (name, version),
        ):
            return
        self.evil_busy = True
        self.evil_abort = False
        self.getControl(30).setVisible(True)
        self.getControl(30).setPercent(0)
        self.getControl(31).setVisible(True)
        self.setFocusId(31)
        self.getControl(21).setLabel(
            "IT'S-POSSIBLE: %s" % ("Turbo-Build vorbereiten" if turbo else "Build vorbereiten")
        )
        self.evil_installer.attach(self.evil_progress, self.evil_cancelled)

        def build_worker():
            result = None
            cancelled = False
            error_text = ""
            try:
                result = self.evil_installer.evil_create_build(
                    name, version, metadata, selection, turbo=turbo
                )
            except EvilCancelled:
                cancelled = True
            except Exception as error:
                evil_log("Build erstellen fehlgeschlagen: %s" % error, xbmc.LOGERROR)
                error_text = str(error)
            finally:
                self.evil_installer.attach(None, None)
            self.evil_finish_build(result, cancelled, error_text)

        threading.Thread(target=build_worker, daemon=True).start()

    def evil_finish_build(self, result, cancelled, error_text):
        self.evil_busy = False
        self.evil_abort = False
        self.getControl(30).setVisible(False)
        self.getControl(31).setVisible(False)
        self.setFocusId(102)
        if cancelled:
            self.getControl(21).setLabel("Build-Erstellung abgebrochen.")
            return
        if not result:
            detail = (error_text or "Unbekannter Fehler").replace("\n", " ")[:160]
            self.getControl(21).setLabel("Build fehlgeschlagen: %s" % detail)
            return
        message = "Build erstellt: %s" % os.path.basename(result["path"])
        status = message
        if result.get("list_path"):
            suffix = " · TXT: %s" % os.path.basename(result["list_path"])
            message += suffix
            status += suffix
        elif result.get("list_error"):
            suffix = " · TXT fehlgeschlagen"
            message += suffix
            status += suffix
        if result.get("skipped"):
            message += " (%d übersprungen)" % result["skipped"]
        self.getControl(21).setLabel(status)
        self.evil_refresh_info(102)

    def evil_repository_addons(self):
        self.getControl(30).setVisible(True)
        self.getControl(30).setPercent(5)
        self.getControl(21).setLabel("IT'S-POSSIBLE: Kodi Media Addons laden ...")
        xbmc.sleep(20)
        try:
            entries = self.evil_installer.evil_repository_addons()
        except Exception as error:
            evil_log("Kodi-Media-Addons fehlgeschlagen: %s" % error, xbmc.LOGERROR)
            self.getControl(21).setLabel("Addon-Liste konnte nicht geladen werden.")
            entries = []
        finally:
            self.getControl(30).setVisible(False)
        if not entries:
            self.getControl(21).setLabel("Keine Addons in der Kodi-Media-Liste gefunden.")
        return entries

    def evil_start_addons(self, addons):
        sources = []
        for source in self.evil_config.get("sources", []):
            source_id = source.get("id", "")
            if not source_id:
                continue
            if not evil_installed(source_id) or not evil_addon_enabled(source_id):
                sources.append(source)
            else:
                evil_enable(source_id)
        self.evil_start(sources, addons)

    def evil_open_addons(self, entries):
        window = EvilAddonWindow("script-itspossible-addons.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_entries = entries
        window.evil_config = self.evil_config
        window.evil_parent = self
        window.evil_addon_path = self.evil_addon_path
        window.doModal()
        del window
        self.evil_refresh()

    def evil_choose(self, key):
        entries = self.evil_config.get(key, [])
        if key == "addons" and not entries:
            entries = self.evil_repository_addons()
            if not entries:
                return
        if not entries:
            self.getControl(21).setLabel("Keine Einträge in itspossible.json.")
            return
        if key == "addons":
            self.evil_open_addons(entries)
            return
        window = EvilSourceSelectWindow("script-itspossible-sourceselect.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_entries = entries
        window.evil_addon_path = self.evil_addon_path
        window.doModal()
        picked = window.evil_result
        del window
        if picked:
            self.evil_start(picked, [])

    def evil_open_manage(self):
        window = EvilManageWindow("script-itspossible-manage.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_config = self.evil_config
        window.evil_installer = self.evil_installer
        window.evil_addon_path = self.evil_addon_path
        window.doModal()
        del window
        self.evil_refresh()

    def evil_open_build(self):
        window = EvilBuildWindow("script-itspossible-build.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_config = self.evil_config
        window.evil_installer = self.evil_installer
        window.evil_addon_path = self.evil_addon_path
        window.doModal()
        del window
        self.evil_refresh()

    def evil_open_maintenance(self):
        window = EvilMaintenanceWindow("script-itspossible-maintenance.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_addon_path = self.evil_addon_path
        window.evil_config = self.evil_config
        window.evil_installer = self.evil_installer
        window.doModal()
        del window

    def evil_open_readme(self):
        path = os.path.join(self.evil_addon_path, "README.md")
        try:
            with open(path, "r", encoding="utf-8") as handle:
                text = handle.read()
        except OSError as error:
            evil_log("README nicht lesbar: %s" % error, xbmc.LOGWARNING)
            text = "README.md wurde im Addon-Ordner nicht gefunden.\n\nBitte das Addon neu installieren."
        if not text.strip():
            text = "README.md ist leer."
        window = EvilReadmeWindow("script-itspossible-readme.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_text = text
        window.doModal()
        del window

    def onClick(self, control_id):
        if control_id == 904:
            self.evil_sync_slider_volume()
            return
        if control_id == 999:
            evil_open_settings()
            return
        if self.evil_busy:
            if control_id == 31:
                self.evil_abort = True
                self.getControl(21).setLabel("IT'S-POSSIBLE: Abbruch angefordert ...")
            return
        self.evil_refresh_info(control_id)
        if control_id == 102:
            self.evil_choose("sources")
        elif control_id == 103:
            self.evil_choose("addons")
        elif control_id == 104:
            self.evil_open_manage()
        elif control_id == 105:
            self.evil_open_maintenance()
        elif control_id == 106:
            self.close()
        elif control_id == 107:
            self.evil_open_build()
        elif control_id == 108:
            self.evil_create_build()
        elif control_id == 109:
            self.evil_open_readme()

    def onAction(self, action):
        if self.getFocusId() == 904:
            self.evil_sync_slider_volume()
        if action.getId() not in EVIL_BACK_ACTIONS:
            return
        if self.evil_busy:
            self.evil_abort = True
            return
        self.close()


class EvilManageWindow(xbmcgui.WindowXML):
    evil_config = {}
    evil_installer = None
    evil_addon_path = ""
    evil_mode = "sources"
    evil_modes = ("sources", "build_sources", "addons")

    def evil_entries(self):
        return self.evil_config.setdefault(self.evil_mode, [])

    def evil_mode_name(self):
        return {
            "sources": "REPO-QUELLEN",
            "build_sources": "BUILD-QUELLEN",
            "addons": "ADDONS",
        }.get(self.evil_mode, "QUELLEN")

    def evil_mode_label(self):
        return {
            "sources": "Repository-Quellen",
            "build_sources": "Build-Quellen",
            "addons": "Addons",
        }.get(self.evil_mode, "Quellen")

    def evil_active_ids(self):
        return [
            entry.get("id", "")
            for entry in evil_active_build_sources(self.evil_config)
            if entry.get("id")
        ]

    def evil_restore_active(self, state):
        self.evil_config["active_build_sources"] = list(state)
        self.evil_config["active_build_source"] = state[0] if state else ""

    def evil_set_active(self, entry, active=True):
        source_id = entry.get("id", "")
        active_ids = self.evil_active_ids()
        if active and source_id and source_id not in active_ids:
            active_ids.append(source_id)
        elif not active and source_id in active_ids:
            active_ids.remove(source_id)
        self.evil_config["active_build_sources"] = active_ids
        self.evil_config["active_build_source"] = active_ids[0] if active_ids else ""

    def onInit(self):
        evil_apply_window(self)
        self.evil_refresh()
        self.setFocusId(610)

    def evil_refresh(self):
        container = self.getControl(610)
        container.reset()
        entries = self.evil_entries()
        active_ids = self.evil_active_ids()
        for entry in entries:
            name = entry.get("name") or entry.get("id", "")
            detail = entry.get("id", "")
            if self.evil_mode == "build_sources":
                url = entry.get("url", "")
                if url:
                    detail = "%s · %s" % (detail, url)
                if entry.get("id") in active_ids:
                    detail += " · AKTIV"
            else:
                zip_url = entry.get("zip", "")
                if zip_url:
                    detail = "%s · %s" % (detail, zip_url)
            item = xbmcgui.ListItem(label=name)
            item.setLabel2(detail)
            container.addItem(item)
        count = len(entries)
        noun = "Eintrag" if count == 1 else "Einträge"
        self.getControl(61).setLabel(self.evil_mode_name())
        if self.evil_mode == "build_sources":
            active_count = sum(1 for entry in entries if entry.get("id") in active_ids)
            self.getControl(62).setLabel("%d %s in %s · %d aktiv." % (count, noun, self.evil_mode_label(), active_count))
        else:
            self.getControl(62).setLabel("%d %s in %s." % (count, noun, self.evil_mode_label()))
        self.getControl(605).setVisible(self.evil_mode == "build_sources")

    def evil_switch(self):
        position = self.evil_modes.index(self.evil_mode) if self.evil_mode in self.evil_modes else 0
        self.evil_mode = self.evil_modes[(position + 1) % len(self.evil_modes)]
        self.evil_refresh()
        self.setFocusId(610)

    def evil_open_add(self):
        window = EvilEditWindow("script-itspossible-edit.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_mode = self.evil_mode
        window.evil_config = self.evil_config
        window.doModal()
        result = window.evil_result
        del window
        if result:
            self.evil_store(result)

    def evil_activate(self):
        if self.evil_mode != "build_sources":
            return False
        container = self.getControl(610)
        entries = self.evil_entries()
        position = container.getSelectedPosition()
        if position < 0 or position >= len(entries):
            xbmcgui.Dialog().ok(EVIL_TITLE, "Keine Build-Quelle ausgewählt.")
            return False
        entry = entries[position]
        if not entry.get("url"):
            xbmcgui.Dialog().ok(EVIL_TITLE, "Diese Build-Quelle hat keine Listen-Adresse.")
            return False
        name = entry.get("name") or entry.get("id", "")
        old_state = self.evil_active_ids()
        activate = entry.get("id", "") not in old_state
        self.evil_set_active(entry, active=activate)
        if not self.evil_installer.save_config(self.evil_config):
            self.evil_restore_active(old_state)
            xbmcgui.Dialog().ok(EVIL_TITLE, "Speichern fehlgeschlagen. Ist der Userdata-Ordner beschreibbar?")
            return False
        self.evil_refresh()
        state = "aktiviert" if activate else "deaktiviert"
        self.getControl(62).setLabel("%s %s · %d aktiv." % (name, state, len(self.evil_active_ids())))
        return True

    def evil_store(self, entry):
        entries = self.evil_entries()
        addon_id = entry.get("id", "")
        if any(existing.get("id") == addon_id for existing in entries):
            xbmcgui.Dialog().ok(EVIL_TITLE, "Der Eintrag existiert bereits.")
            return False
        old_state = self.evil_active_ids()
        entries.append(entry)
        if self.evil_mode == "build_sources" and not self.evil_active_ids():
            self.evil_set_active(entry, active=True)
        if not self.evil_installer.save_config(self.evil_config):
            entries.remove(entry)
            self.evil_restore_active(old_state)
            xbmcgui.Dialog().ok(EVIL_TITLE, "Speichern fehlgeschlagen. Ist der Userdata-Ordner beschreibbar?")
            return False
        self.evil_refresh()
        self.getControl(62).setLabel("%s gespeichert." % (entry.get("name") or addon_id))
        return True

    def evil_delete_selected(self):
        container = self.getControl(610)
        entries = self.evil_entries()
        position = container.getSelectedPosition()
        if position < 0 or position >= len(entries):
            xbmcgui.Dialog().ok(EVIL_TITLE, "Kein Eintrag ausgewählt.")
            return False
        entry = entries[position]
        name = entry.get("name") or entry.get("id", "")
        if not xbmcgui.Dialog().yesno(EVIL_TITLE, "%s wirklich löschen?" % name):
            return False
        old_state = self.evil_active_ids()
        source_id = entry.get("id", "")
        was_active = self.evil_mode == "build_sources" and source_id in old_state
        entries.pop(position)
        if was_active:
            self.evil_restore_active([value for value in old_state if value != source_id])
        if not self.evil_installer.save_config(self.evil_config):
            entries.insert(position, entry)
            self.evil_restore_active(old_state)
            xbmcgui.Dialog().ok(EVIL_TITLE, "Speichern fehlgeschlagen. Ist der Userdata-Ordner beschreibbar?")
            return False
        self.evil_refresh()
        return True

    def evil_open_appearance(self):
        window = EvilAppearanceWindow("script-itspossible-appearance.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_config = self.evil_config
        window.evil_installer = self.evil_installer
        window.evil_addon_path = self.evil_addon_path
        window.doModal()
        del window
        evil_apply_skin(self.evil_config)
        evil_apply_window(self)
        self.evil_refresh()

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 601:
            self.evil_open_add()
        elif control_id == 602:
            self.evil_delete_selected()
        elif control_id == 603:
            self.evil_switch()
        elif control_id == 604:
            self.close()
        elif control_id == 605:
            self.evil_activate()
        elif control_id == 606:
            self.evil_open_appearance()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilAppearanceWindow(xbmcgui.WindowXML):
    evil_config = {}
    evil_installer = None
    evil_addon_path = ""
    evil_data = None

    def evil_name(self, value):
        for name, color in EVIL_COLOR_PALETTE:
            if color == value:
                return name
        return str(value or "")

    def evil_cycle(self, values, current):
        try:
            index = values.index(current)
        except ValueError:
            index = -1
        return values[(index + 1) % len(values)]

    def evil_cycle_color(self, key):
        colors = [color for _name, color in EVIL_COLOR_PALETTE]
        self.evil_data[key] = self.evil_cycle(colors, self.evil_data[key])

    def evil_edit_text(self, key, heading):
        value = xbmcgui.Dialog().input(heading, self.evil_data[key])
        if value and value.strip():
            self.evil_data[key] = value.strip()

    def evil_edit_number(self, key, heading, maximum):
        value = xbmcgui.Dialog().numeric(0, heading, str(self.evil_data[key]))
        if value:
            try:
                number = int(value)
            except ValueError:
                return
            self.evil_data[key] = max(0, min(maximum, number))

    def evil_refresh(self):
        data = self.evil_data
        labels = {
            941: "TITEL: %s" % data["title"],
            942: "SCHRIFTGRÖSSE: %s" % data["title_font"],
            943: "TITELFARBE: %s (#%s)" % (self.evil_name(data["title_color"]), data["title_color"][2:]),
            944: "AUSRICHTUNG: %s" % {"left": "LINKS", "center": "MITTE", "right": "RECHTS"}.get(data["title_align"], "MITTE"),
            945: "POSITION X: %d" % data["title_x"],
            946: "POSITION Y: %d" % data["title_y"],
            947: "TITELBREITE: %d" % data["title_width"],
            948: "HINTERGRUNDFARBE: %s" % self.evil_name(data["background"]),
            949: "PANELFARBE: %s" % self.evil_name(data["panel"]),
            950: "AKZENTFARBE: %s" % self.evil_name(data["accent"]),
            951: "TEXTFARBE: %s" % self.evil_name(data["text"]),
            953: "SPEICHERN",
            954: "ZURÜCK",
        }
        for control_id, text in labels.items():
            self.getControl(control_id).setLabel(text)
        try:
            self.getControl(960).setLabel(data["title"])
            self.getControl(961).setLabel(data["powered_text"])
        except Exception:
            pass
        try:
            self.getControl(960).setTextColor("0x" + data["title_color"])
        except Exception:
            pass
        try:
            self.getControl(962).setText(
                "VORSCHAU\n\n"
                "Der Titel erscheint auf der Hauptseite und in allen Unterfenstern.\n"
                "Untertitel und Inhalte bleiben unverändert.\n\n"
                "Farben wirken auf Hintergrund, Panels, Buttons und vorhandene PNGs.\n"
                "Gespeichert wird unter appearance in itspossible.json im Userdata-Ordner."
            )
            self.getControl(963).setLabel("Datei: itspossible.json · Userdata")
        except Exception:
            pass

    def onInit(self):
        evil_apply_window(self)
        self.evil_data = evil_appearance(self.evil_config)
        self.evil_refresh()
        self.setFocusId(941)

    def evil_save(self):
        if not isinstance(self.evil_config, dict):
            xbmcgui.Dialog().ok(EVIL_TITLE, "Die Konfiguration ist nicht verfügbar.")
            return
        if self.evil_installer is None:
            xbmcgui.Dialog().ok(EVIL_TITLE, "Der Installer ist nicht verfügbar.")
            return
        self.evil_config["appearance"] = dict(self.evil_data)
        if not self.evil_installer.save_config(self.evil_config):
            xbmcgui.Dialog().ok(EVIL_TITLE, "Speichern fehlgeschlagen. Ist der Userdata-Ordner beschreibbar?")
            return
        evil_apply_skin(self.evil_config)
        xbmcgui.Dialog().ok(EVIL_TITLE, "Darstellung gespeichert. Öffne den Wizard neu, damit alle Fenster die neuen Werte verwenden.")
        self.close()

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 941:
            self.evil_edit_text("title", "Haupttitel")
        elif control_id == 942:
            self.evil_data["title_font"] = self.evil_cycle(list(EVIL_TITLE_FONTS), self.evil_data["title_font"])
        elif control_id == 943:
            self.evil_cycle_color("title_color")
        elif control_id == 944:
            self.evil_data["title_align"] = self.evil_cycle(list(EVIL_TITLE_ALIGNMENTS), self.evil_data["title_align"])
        elif control_id == 945:
            self.evil_edit_number("title_x", "Position X", 1920)
        elif control_id == 946:
            self.evil_edit_number("title_y", "Position Y", 1080)
        elif control_id == 947:
            self.evil_edit_number("title_width", "Titelbreite", 1920)
        elif control_id == 948:
            self.evil_cycle_color("background")
        elif control_id == 949:
            self.evil_cycle_color("panel")
        elif control_id == 950:
            self.evil_cycle_color("accent")
            self.evil_data["accent_soft"] = self.evil_data["accent"]
        elif control_id == 951:
            self.evil_cycle_color("text")
        elif control_id == 953:
            self.evil_save()
            return
        elif control_id == 954:
            self.close()
            return
        else:
            return
        self.evil_refresh()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilEditWindow(xbmcgui.WindowXML):
    evil_addon_path = ""
    evil_mode = "sources"
    evil_config = {}
    evil_result = None

    def onInit(self):
        evil_apply_window(self)
        self.evil_result = None
        titles = {
            "sources": "NEUE REPO-QUELLE",
            "build_sources": "NEUE BUILD-QUELLE",
            "addons": "NEUES ADDON",
        }
        self.getControl(50).setLabel(titles.get(self.evil_mode, "NEUER EINTRAG"))
        self.getControl(51).setLabel("")
        self.getControl(520).setLabel("NAME")
        self.getControl(521).setLabel("ID")
        if self.evil_mode == "build_sources":
            self.getControl(522).setLabel("LISTEN-ADRESSE")
            self.getControl(523).setLabel("Für Build-Quellen ist die Listen-Adresse Pflicht (JSON, XML oder TXT).")
        elif self.evil_mode == "sources":
            self.getControl(522).setLabel("ZIP-ADRESSE")
            self.getControl(523).setLabel("Bei Repo-Quellen ist die ZIP-Adresse Pflicht.")
        else:
            self.getControl(522).setLabel("ZIP-ADRESSE (OPTIONAL)")
            self.getControl(523).setLabel("Bei Addons ist die ZIP-Adresse optional.")
        self.getControl(501).setText("")
        self.getControl(502).setText("")
        self.getControl(503).setText("")
        self.setFocusId(501)

    def evil_save(self):
        name = self.getControl(501).getText().strip()
        addon_id = self.getControl(502).getText().strip()
        list_url = self.getControl(503).getText().strip()
        if not addon_id:
            self.getControl(51).setLabel("ID ist Pflicht.")
            self.setFocusId(502)
            return
        if self.evil_mode == "build_sources":
            if not list_url:
                self.getControl(51).setLabel("Für Build-Quellen ist eine Listen-Adresse nötig.")
                self.setFocusId(503)
                return
            if not list_url.lower().startswith(("http://", "https://", "file://", "special://")):
                self.getControl(51).setLabel("Ungültige Listen-Adresse. Erlaubt sind http, https, file und special.")
                self.setFocusId(503)
                return
            self.evil_result = {
                "id": addon_id,
                "name": name or addon_id,
                "url": list_url,
            }
        elif self.evil_mode == "sources":
            if not list_url:
                self.getControl(51).setLabel("Für Repo-Quellen ist eine ZIP-Adresse nötig.")
                self.setFocusId(503)
                return
            self.evil_result = {
                "id": addon_id,
                "name": name or addon_id,
                "zip": list_url,
            }
        else:
            self.evil_result = {
                "id": addon_id,
                "name": name or addon_id,
                "zip": list_url,
            }
        self.close()

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 504:
            self.evil_save()
        elif control_id == 505:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilBuildSelectWindow(xbmcgui.WindowXML):
    evil_entries = []
    evil_selected_addons = set()
    evil_selected_addon_data = set()
    evil_result = None
    evil_addon_path = ""
    evil_current = 0

    def onInit(self):
        evil_apply_window(self)
        self.evil_entries = [entry for entry in (self.evil_entries or []) if isinstance(entry, dict)]
        self.evil_selected_addons = {
            entry.get("folder", "")
            for entry in self.evil_entries
            if entry.get("has_addon") and entry.get("folder")
        }
        self.evil_selected_addon_data = {
            entry.get("data_id", "")
            for entry in self.evil_entries
            if entry.get("has_data") and entry.get("data_id")
        }
        self.evil_result = None
        self.evil_refresh_list(0)
        self.setFocusId(920)

    def evil_name(self, entry):
        return evil_plain_text(entry.get("name") or entry.get("id") or "Addon")

    def evil_marks(self, entry):
        addon_mark = "[X]" if entry.get("has_addon") and entry.get("folder") in self.evil_selected_addons else "[ ]"
        data_mark = "[X]" if entry.get("has_data") and entry.get("data_id") in self.evil_selected_addon_data else "[ ]"
        if not entry.get("has_addon"):
            addon_mark = "[-]"
        if not entry.get("has_data"):
            data_mark = "[-]"
        return addon_mark, data_mark

    def evil_update_status(self):
        addon_total = sum(1 for entry in self.evil_entries if entry.get("has_addon"))
        data_total = sum(1 for entry in self.evil_entries if entry.get("has_data"))
        addon_selected = sum(
            1 for entry in self.evil_entries
            if entry.get("has_addon") and entry.get("folder") in self.evil_selected_addons
        )
        data_selected = sum(
            1 for entry in self.evil_entries
            if entry.get("has_data") and entry.get("data_id") in self.evil_selected_addon_data
        )
        self.getControl(924).setLabel(
            "%d von %d Addons · %d von %d Addondata ausgewählt"
            % (addon_selected, addon_total, data_selected, data_total)
        )

    def evil_refresh_list(self, position=0):
        container = self.getControl(920)
        container.reset()
        for entry in self.evil_entries:
            addon_mark, data_mark = self.evil_marks(entry)
            item = xbmcgui.ListItem(label="%s  %s" % (addon_mark, self.evil_name(entry)))
            item.setLabel2(
                "ADDON %s · ADDONDATA %s · %s"
                % (addon_mark, data_mark, entry.get("id") or "?")
            )
            icon = entry.get("icon") or os.path.join(self.evil_addon_path, "icon.png")
            try:
                item.setArt({"icon": icon})
            except Exception:
                pass
            container.addItem(item)
        if self.evil_entries:
            position = max(0, min(int(position), len(self.evil_entries) - 1))
            try:
                container.selectItem(position)
            except Exception:
                pass
            try:
                selected = container.getSelectedPosition()
                self.evil_current = selected if 0 <= selected < len(self.evil_entries) else position
            except Exception:
                self.evil_current = position
        else:
            self.evil_current = 0
        self.evil_update_status()
        self.evil_refresh_preview()

    def evil_position(self):
        try:
            position = self.getControl(920).getSelectedPosition()
        except Exception:
            position = self.evil_current
        if position < 0 or position >= len(self.evil_entries):
            position = max(0, min(self.evil_current, len(self.evil_entries) - 1)) if self.evil_entries else 0
        return position

    def evil_refresh_preview(self):
        if not self.evil_entries:
            self.getControl(923).setText("Keine Addons oder Addondata gefunden.")
            return
        self.evil_current = self.evil_position()
        entry = self.evil_entries[self.evil_current]
        addon_mark, data_mark = self.evil_marks(entry)
        if not entry.get("has_addon"):
            addon_state = "nicht vorhanden"
        else:
            addon_state = "ausgewählt" if addon_mark == "[X]" else "ausgeschlossen"
        if not entry.get("has_data"):
            data_state = "nicht vorhanden"
        else:
            data_state = "ausgewählt" if data_mark == "[X]" else "ausgeschlossen"
        lines = [
            self.evil_name(entry),
            "ID: %s" % (entry.get("id") or "?"),
            "",
            "Addon-Ordner: %s" % (entry.get("folder") or "nicht installiert"),
            "Addon: %s" % addon_state,
            "Addondata: %s" % data_state,
            "",
            "Zeile: Addon und Addondata zusammen.",
            "ADDON UMSCHALTEN / ADDONDATA UMSCHALTEN: getrennt.",
        ]
        self.getControl(923).setText("\n".join(lines))

    def evil_toggle_entry(self):
        if not self.evil_entries:
            return
        self.evil_current = self.evil_position()
        entry = self.evil_entries[self.evil_current]
        has_addon = entry.get("has_addon")
        has_data = entry.get("has_data")
        if not has_addon and not has_data:
            return
        addon_selected = False
        if has_addon:
            folder = entry.get("folder")
            if folder in self.evil_selected_addons:
                self.evil_selected_addons.remove(folder)
            else:
                self.evil_selected_addons.add(folder)
                addon_selected = True
        if has_data:
            data_id = entry.get("data_id")
            if data_id:
                if has_addon:
                    if addon_selected:
                        self.evil_selected_addon_data.add(data_id)
                    else:
                        self.evil_selected_addon_data.discard(data_id)
                elif data_id in self.evil_selected_addon_data:
                    self.evil_selected_addon_data.remove(data_id)
                else:
                    self.evil_selected_addon_data.add(data_id)
        self.evil_refresh_list(self.evil_current)

    def evil_toggle_addon(self):
        if not self.evil_entries:
            return
        self.evil_current = self.evil_position()
        entry = self.evil_entries[self.evil_current]
        if not entry.get("has_addon"):
            self.getControl(924).setLabel("Für %s ist kein Addon-Ordner installiert." % self.evil_name(entry))
            return
        folder = entry.get("folder")
        if folder in self.evil_selected_addons:
            self.evil_selected_addons.remove(folder)
        else:
            self.evil_selected_addons.add(folder)
        self.evil_refresh_list(self.evil_current)

    def evil_toggle_data(self):
        if not self.evil_entries:
            return
        self.evil_current = self.evil_position()
        entry = self.evil_entries[self.evil_current]
        if not entry.get("has_data"):
            self.getControl(924).setLabel("Für %s sind keine Addondata vorhanden." % self.evil_name(entry))
            return
        data_id = entry.get("data_id")
        if data_id in self.evil_selected_addon_data:
            self.evil_selected_addon_data.remove(data_id)
        else:
            self.evil_selected_addon_data.add(data_id)
        self.evil_refresh_list(self.evil_current)

    def evil_select_all(self):
        self.evil_selected_addons = {
            entry.get("folder", "") for entry in self.evil_entries
            if entry.get("has_addon") and entry.get("folder")
        }
        self.evil_selected_addon_data = {
            entry.get("data_id", "") for entry in self.evil_entries
            if entry.get("has_data") and entry.get("data_id")
        }
        self.evil_refresh_list(self.evil_current)

    def evil_deselect_all(self):
        self.evil_selected_addons.clear()
        self.evil_selected_addon_data.clear()
        self.evil_refresh_list(self.evil_current)

    def evil_continue(self):
        addons = sorted(self.evil_selected_addons)
        addon_data = sorted(self.evil_selected_addon_data)
        if not addons and not addon_data:
            self.getControl(924).setLabel("Bitte mindestens ein Addon oder Addondata auswählen.")
            return
        self.evil_result = {
            "addons": addons,
            "addon_data": addon_data,
            "addon_total": sum(1 for entry in self.evil_entries if entry.get("has_addon")),
            "data_total": sum(1 for entry in self.evil_entries if entry.get("has_data")),
        }
        self.close()

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 920:
            self.evil_current = self.evil_position()
            self.evil_toggle_entry()
        elif control_id == 926:
            self.evil_toggle_addon()
        elif control_id == 927:
            self.evil_toggle_data()
        elif control_id == 928:
            self.evil_select_all()
        elif control_id == 929:
            self.evil_deselect_all()
        elif control_id == 930:
            self.evil_continue()
        elif control_id == 931:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()
            return
        self.evil_current = self.evil_position()
        self.evil_refresh_preview()


class EvilBuildMetaWindow(xbmcgui.WindowXML):
    evil_result = None

    def onInit(self):
        evil_apply_window(self)
        self.evil_result = None
        self.getControl(902).setText(str(evil_kodi_major() or 22))
        for control_id in (901, 903, 904, 905):
            self.getControl(control_id).setText("")
        self.getControl(907).setLabel("")
        self.setFocusId(901)

    def evil_save(self):
        address = self.getControl(901).getText().strip()
        kodi = self.getControl(902).getText().strip() or str(evil_kodi_major() or 22)
        description = self.getControl(903).getText().strip()
        icon = self.getControl(904).getText().strip()
        fanart = self.getControl(905).getText().strip()
        if not address:
            self.getControl(907).setLabel("Build-Adresse ist Pflicht; ohne Adresse keine TXT.")
            self.setFocusId(901)
            return
        address = evil_public_url(address)
        if not address:
            self.getControl(907).setLabel("Ungültige Build-Adresse. Erlaubt sind http und https.")
            self.setFocusId(901)
            return
        if not re.match(r"^\d+(?:\.\d+)*$", kodi):
            self.getControl(907).setLabel("Kodi-Version bitte als Zahl eingeben, z. B. 22 oder 21.3.")
            self.setFocusId(902)
            return
        icon_url = evil_public_url(icon) if icon else ""
        if icon and not icon_url:
            self.getControl(907).setLabel("Ungültige Icon-Adresse.")
            self.setFocusId(904)
            return
        fanart_url = evil_public_url(fanart) if fanart else ""
        if fanart and not fanart_url:
            self.getControl(907).setLabel("Ungültige Fanart-Adresse.")
            self.setFocusId(905)
            return
        self.evil_result = {
            "url": address,
            "kodi": kodi,
            "description": description,
            "icon": icon_url,
            "fanart": fanart_url,
        }
        self.close()

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 910:
            self.evil_save()
        elif control_id == 911:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilBuildSourcesWindow(xbmcgui.WindowXML):
    evil_config = {}
    evil_addon_path = ""
    evil_installer = None
    evil_entries = []
    evil_selected = set()
    evil_result = None
    evil_current = 0
    evil_counts = {}
    evil_items = []
    evil_stop = False

    def onInit(self):
        evil_apply_window(self)
        self.evil_entries = [
            source for source in self.evil_config.get("build_sources", [])
            if isinstance(source, dict) and source.get("id") and source.get("url")
        ]
        self.evil_selected = {
            source.get("id") for source in evil_active_build_sources(self.evil_config)
        }
        self.evil_counts = {}
        self.evil_items = []
        self.evil_stop = False
        for entry in self.evil_entries:
            source_id = entry.get("id", "")
            cached = []
            saved = 0
            if self.evil_installer:
                try:
                    cached, saved = self.evil_installer.evil_load_build_cache(entry.get("url", ""))
                except Exception:
                    cached = []
                    saved = 0
            if cached:
                self.evil_counts[source_id] = {
                    "count": len(cached),
                    "state": "cache",
                    "updated": saved,
                }
            else:
                self.evil_counts[source_id] = {
                    "count": None,
                    "state": "loading",
                    "updated": 0,
                }
        self.evil_result = None
        self.evil_refresh_list(0)
        self.setFocusId(950)
        if self.evil_installer and any(
            info.get("count") is None for info in self.evil_counts.values()
        ):
            worker = threading.Thread(
                target=self.evil_count_worker,
                name="ItsPossibleBuildSourceCounts",
            )
            worker.daemon = True
            worker.start()

    def evil_name(self, entry):
        return evil_plain_text(entry.get("name") or entry.get("id") or "Build-Quelle")

    def evil_source_details(self, entry):
        info = self.evil_counts.get(entry.get("id")) or {}
        count = info.get("count")
        if info.get("state") == "error":
            summary = "Build-Anzahl nicht verfügbar"
        elif count is None:
            summary = "Builds werden geladen ..."
        else:
            summary = "%d Build%s" % (count, "" if count == 1 else "s")
            if info.get("state") == "cache":
                summary += " · Cache"
        updated = info.get("updated")
        if updated:
            try:
                summary += " · zuletzt %s" % time.strftime(
                    "%d.%m.%Y %H:%M", time.localtime(int(updated))
                )
            except (TypeError, ValueError, OSError):
                pass
        return "%s · %s" % (summary, entry.get("url") or entry.get("id") or "")

    def evil_update_item(self, source_id):
        if self.evil_stop:
            return
        try:
            index = next(
                index for index, entry in enumerate(self.evil_entries)
                if entry.get("id") == source_id
            )
            if 0 <= index < len(self.evil_items):
                self.evil_items[index].setLabel2(
                    self.evil_source_details(self.evil_entries[index])
                )
        except Exception:
            pass

    def evil_count_worker(self):
        for entry in list(self.evil_entries):
            if self.evil_stop:
                return
            source_id = entry.get("id", "")
            info = self.evil_counts.get(source_id) or {}
            if info.get("count") is not None:
                continue
            name = self.evil_name(entry)
            url = entry.get("url", "")
            try:
                text = self.evil_installer.evil_fetch_text(url, name)
                builds = evil_parse_builds(text, url)
                if self.evil_stop:
                    return
                self.evil_installer.evil_save_build_cache(url, builds)
                self.evil_counts[source_id] = {
                    "count": len(builds),
                    "state": "fresh",
                    "updated": int(time.time()),
                }
            except Exception as error:
                evil_log("Build-Anzahl für %s fehlgeschlagen: %s" % (name, error), xbmc.LOGWARNING)
                cached = []
                saved = 0
                if self.evil_installer:
                    try:
                        cached, saved = self.evil_installer.evil_load_build_cache(url)
                    except Exception:
                        cached = []
                        saved = 0
                if cached:
                    self.evil_counts[source_id] = {
                        "count": len(cached),
                        "state": "cache",
                        "updated": saved,
                    }
                else:
                    self.evil_counts[source_id] = {
                        "count": None,
                        "state": "error",
                        "updated": 0,
                    }
            self.evil_update_item(source_id)
            self.evil_update_status()

    def evil_update_status(self):
        label = "%d von %d Quellen aktiv · Mehrfachauswahl möglich" % (
            len(self.evil_selected), len(self.evil_entries)
        )
        if any(
            info.get("count") is None and info.get("state") != "error"
            for info in self.evil_counts.values()
        ):
            label += " · Builds werden geladen"
        self.getControl(951).setLabel(label)

    def evil_refresh_list(self, position=0):
        container = self.getControl(950)
        container.reset()
        self.evil_items = []
        for entry in self.evil_entries:
            source_id = entry.get("id", "")
            mark = "[X]" if source_id in self.evil_selected else "[ ]"
            item = xbmcgui.ListItem(label="%s  %s" % (mark, self.evil_name(entry)))
            item.setLabel2(self.evil_source_details(entry))
            try:
                item.setArt({"icon": os.path.join(self.evil_addon_path, "icon.png")})
            except Exception:
                pass
            container.addItem(item)
            self.evil_items.append(item)
        if self.evil_entries:
            position = max(0, min(int(position), len(self.evil_entries) - 1))
            try:
                container.selectItem(position)
            except Exception:
                pass
            try:
                selected = container.getSelectedPosition()
                self.evil_current = selected if 0 <= selected < len(self.evil_entries) else position
            except Exception:
                self.evil_current = position
        else:
            self.evil_current = 0
        self.evil_update_status()

    def evil_position(self):
        try:
            position = self.getControl(950).getSelectedPosition()
        except Exception:
            position = self.evil_current
        if position < 0 or position >= len(self.evil_entries):
            position = max(0, min(self.evil_current, len(self.evil_entries) - 1)) if self.evil_entries else 0
        return position

    def evil_toggle_current(self):
        if not self.evil_entries:
            return
        self.evil_current = self.evil_position()
        source_id = self.evil_entries[self.evil_current].get("id", "")
        if not source_id:
            return
        if source_id in self.evil_selected:
            self.evil_selected.remove(source_id)
        else:
            self.evil_selected.add(source_id)
        self.evil_refresh_list(self.evil_current)

    def evil_select_all(self):
        self.evil_selected = {
            entry.get("id", "") for entry in self.evil_entries if entry.get("id")
        }
        self.evil_refresh_list(self.evil_current)

    def evil_deselect_all(self):
        self.evil_selected.clear()
        self.evil_refresh_list(self.evil_current)

    def evil_apply(self):
        self.evil_stop = True
        self.evil_result = [
            entry.get("id", "") for entry in self.evil_entries
            if entry.get("id") in self.evil_selected
        ]
        self.close()

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
        elif control_id == 950:
            self.evil_toggle_current()
        elif control_id == 952:
            self.evil_select_all()
        elif control_id == 953:
            self.evil_deselect_all()
        elif control_id == 954:
            self.evil_apply()
        elif control_id == 955:
            self.evil_stop = True
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.evil_stop = True
            self.close()


EVIL_BUILD_SORTS = [
    ("name", "Name"),
    ("size", "Größe"),
    ("date", "Änderungsdatum"),
    ("source", "Quelle"),
    ("kodi", "Kodi-Version"),
    ("version", "Build-Version"),
]
EVIL_BUILD_SORT_KEYS = {key for key, _label in EVIL_BUILD_SORTS}
EVIL_BUILD_SORT_LABELS = dict(EVIL_BUILD_SORTS)


def evil_numeric_key(value):
    return tuple(int(part) for part in re.findall(r"\d+", str(value or "")))


class EvilBuildSortWindow(xbmcgui.WindowXML):
    evil_addon_path = ""
    evil_sort = "name"
    evil_sort_desc = False
    evil_result = None
    evil_modes = []
    evil_current = 0

    def onInit(self):
        evil_apply_window(self)
        self.evil_modes = list(EVIL_BUILD_SORTS)
        if self.evil_sort not in EVIL_BUILD_SORT_KEYS:
            self.evil_sort = "name"
        self.evil_result = None
        self.evil_refresh_list(0)
        self.setFocusId(960)

    def evil_position(self):
        for index, (key, _label) in enumerate(self.evil_modes):
            if key == self.evil_sort:
                return index
        return 0

    def evil_refresh_list(self, position=None):
        if position is None:
            position = self.evil_position()
        container = self.getControl(960)
        container.reset()
        for key, label in self.evil_modes:
            mark = "[X]" if key == self.evil_sort else "[ ]"
            item = xbmcgui.ListItem(label="%s  %s" % (mark, label))
            item.setLabel2("absteigend" if self.evil_sort_desc else "aufsteigend")
            container.addItem(item)
        if self.evil_modes:
            position = max(0, min(int(position), len(self.evil_modes) - 1))
            try:
                container.selectItem(position)
            except Exception:
                pass
            try:
                selected = container.getSelectedPosition()
                self.evil_current = selected if 0 <= selected < len(self.evil_modes) else position
            except Exception:
                self.evil_current = position
        self.evil_update_status()

    def evil_update_status(self):
        label = EVIL_BUILD_SORT_LABELS.get(self.evil_sort, "Name")
        direction = "absteigend" if self.evil_sort_desc else "aufsteigend"
        next_direction = "aufsteigend" if self.evil_sort_desc else "absteigend"
        self.getControl(961).setLabel("Sortierung: %s · %s" % (label, direction))
        try:
            self.getControl(962).setLabel("RICHTUNG: %s" % next_direction.upper())
        except Exception:
            pass

    def evil_select_current(self):
        try:
            position = self.getControl(960).getSelectedPosition()
        except Exception:
            position = self.evil_current
        if position < 0 or position >= len(self.evil_modes):
            return
        self.evil_sort = self.evil_modes[position][0]
        self.evil_refresh_list(position)

    def evil_toggle_direction(self):
        self.evil_sort_desc = not self.evil_sort_desc
        self.evil_refresh_list(self.evil_position())

    def evil_apply(self):
        self.evil_result = (self.evil_sort, self.evil_sort_desc)
        self.close()

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
        elif control_id == 960:
            self.evil_select_current()
        elif control_id == 962:
            self.evil_toggle_direction()
        elif control_id == 963:
            self.evil_apply()
        elif control_id == 964:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilBuildWindow(xbmcgui.WindowXML):
    evil_config = {}
    evil_installer = None
    evil_addon_path = ""
    evil_builds = []
    evil_all_builds = []
    evil_local_entries = []
    evil_busy = False
    evil_abort = False
    evil_hidden_adult = 0
    evil_source = "gespeichert"
    evil_source_time = 0
    evil_backup_selected = None
    evil_view = "online"
    evil_online_builds = []
    evil_online_loaded = False
    evil_sort = "name"
    evil_sort_desc = False

    def evil_active_sources(self):
        return evil_active_build_sources(self.evil_config)

    def evil_has_build_sources(self):
        return any(
            isinstance(source, dict) and source.get("id") and source.get("url")
            for source in self.evil_config.get("build_sources", [])
        )

    def evil_sort_value(self, entry, mode):
        if mode == "name":
            return evil_plain_text(entry.get("name") or "").casefold()
        if mode == "size":
            try:
                value = float(entry.get("size_mb"))
            except (TypeError, ValueError):
                return None
            return value if value > 0 else None
        if mode == "date":
            try:
                value = int(entry.get("updated") or 0)
            except (TypeError, ValueError):
                return None
            return value if value > 0 else None
        if mode == "source":
            return evil_plain_text(
                entry.get("source_name") or entry.get("source") or ""
            ).casefold() or None
        if mode in ("kodi", "version"):
            return evil_numeric_key(entry.get(mode)) or None
        return None

    def evil_sort_entries(self, entries):
        mode = self.evil_sort if self.evil_sort in EVIL_BUILD_SORT_KEYS else "name"
        reverse = bool(self.evil_sort_desc)
        present = []
        missing = []
        for entry in entries:
            value = self.evil_sort_value(entry, mode)
            if value is None or value == "":
                missing.append(entry)
            else:
                present.append((value, entry))

        def name_key(item):
            return evil_plain_text(item.get("name") or "").casefold()

        present.sort(key=lambda pair: (pair[0], name_key(pair[1])), reverse=reverse)
        missing.sort(key=name_key, reverse=reverse)
        return [entry for _value, entry in present] + missing

    def evil_open_sort(self):
        if self.evil_busy:
            return
        window = EvilBuildSortWindow(
            "script-itspossible-buildsort.xml",
            self.evil_addon_path,
            "Default",
            "1080i",
        )
        window.evil_sort = self.evil_sort
        window.evil_sort_desc = self.evil_sort_desc
        window.evil_addon_path = self.evil_addon_path
        window.doModal()
        result = window.evil_result
        del window
        if result is None:
            return
        self.evil_sort, self.evil_sort_desc = result
        self.evil_config["build_sort"] = self.evil_sort
        self.evil_config["build_sort_desc"] = self.evil_sort_desc
        self.evil_installer.save_config(self.evil_config)
        self.evil_refresh()
        self.setFocusId(812)

    def evil_refresh_sources_button(self):
        try:
            self.getControl(809).setVisible(
                self.evil_view == "online" and self.evil_has_build_sources()
            )
        except Exception:
            pass

    def evil_select_sources(self):
        if self.evil_busy or not self.evil_has_build_sources():
            return
        window = EvilBuildSourcesWindow(
            "script-itspossible-buildsources.xml",
            self.evil_addon_path,
            "Default",
            "1080i",
        )
        window.evil_config = self.evil_config
        window.evil_installer = self.evil_installer
        window.evil_addon_path = self.evil_addon_path
        window.doModal()
        selected = window.evil_result
        del window
        if selected is None:
            return
        self.evil_config["active_build_sources"] = list(selected)
        self.evil_config["active_build_source"] = selected[0] if selected else ""
        if not self.evil_installer.save_config(self.evil_config):
            self.getControl(806).setLabel("Auswahl konnte nicht gespeichert werden.")
            return
        self.evil_online_builds = []
        self.evil_online_loaded = False
        self.evil_source = "Online"
        self.evil_source_time = 0
        self.evil_refresh()
        if selected:
            self.evil_load_list(True)
        else:
            self.getControl(806).setLabel(
                "Online · Keine aktive Build-Quelle · BUILD QUELLEN öffnet die Auswahl"
            )
            self.setFocusId(809)

    def onInit(self):
        evil_apply_window(self)
        self.evil_local_entries = self.evil_installer.evil_local_builds()
        self.evil_online_builds = []
        self.evil_online_loaded = False
        self.evil_all_builds = []
        self.evil_hidden_adult = 0
        self.evil_view = "online"
        sort = self.evil_config.get("build_sort")
        self.evil_sort = sort if sort in EVIL_BUILD_SORT_KEYS else "name"
        self.evil_sort_desc = bool(self.evil_config.get("build_sort_desc", False))
        self.evil_source = "Online" if self.evil_view == "online" else "Build-Ordner"
        self.evil_source_time = 0
        self.getControl(820).setVisible(False)
        self.evil_refresh()
        if self.evil_view == "online" and self.evil_active_sources():
            self.evil_load_list()
        self.setFocusId(810 if self.evil_builds else 801)

    def evil_refresh(self):
        self.evil_all_builds = list(self.evil_online_builds if self.evil_view == "online" else self.evil_local_entries)
        container = self.getControl(810)
        container.reset()
        visible = []
        hidden = 0
        for entry in self.evil_all_builds:
            if entry.get("adult") and not self.evil_config.get("show_adult", False):
                hidden += 1
                continue
            visible.append(entry)
        visible = self.evil_sort_entries(visible)
        self.evil_builds = visible
        self.evil_hidden_adult = hidden
        multi_source = len(self.evil_active_sources()) > 1
        for entry in visible:
            name = entry.get("name") or "Unbekannter Build"
            details = []
            if entry.get("adult"):
                details.append("18+")
            if entry.get("version"):
                details.append("v%s" % entry["version"])
            if entry.get("kodi"):
                details.append("Kodi %s" % entry["kodi"])
            if entry.get("size"):
                details.append(entry["size"])
            if entry.get("description"):
                details.append(entry["description"][:110])
            elif entry.get("url"):
                details.append(entry["url"])
            if multi_source and entry.get("source_name"):
                details.append(entry["source_name"])
            item = xbmcgui.ListItem(label=name)
            item.setLabel2(" · ".join(details))
            art = {"icon": entry.get("icon") or os.path.join(self.evil_addon_path, "icon.png")}
            if entry.get("fanart"):
                art["fanart"] = entry["fanart"]
            elif os.path.isfile(os.path.join(self.evil_addon_path, "fanart.png")):
                art["fanart"] = os.path.join(self.evil_addon_path, "fanart.png")
            try:
                item.setArt(art)
            except Exception:
                pass
            container.addItem(item)
        status = ["Online" if self.evil_view == "online" else "Lokal", "%d Builds" % len(visible)]
        if hidden:
            status.append("%d Adult ausgeblendet" % hidden)
        if self.evil_view == "online":
            if self.evil_active_sources():
                if self.evil_source:
                    status.append(self.evil_source)
                if self.evil_source_time:
                    status.append(time.strftime("%d.%m. %H:%M", time.localtime(self.evil_source_time)))
            else:
                status.append("Keine aktive Build-Quelle")
                if self.evil_has_build_sources():
                    status.append("BUILD QUELLEN öffnet die Auswahl")
                else:
                    status.append("AKTUALISIEREN öffnet die Abfrage")
        else:
            status.append("Build-Ordner")
        sort_label = EVIL_BUILD_SORT_LABELS.get(self.evil_sort, "Name")
        status.append(
            "Sortierung: %s %s"
            % (sort_label, "absteigend" if self.evil_sort_desc else "aufsteigend")
        )
        self.getControl(806).setLabel(" · ".join(status))
        self.evil_refresh_sources_button()
        self.evil_refresh_switch()
        installed = self.evil_config.get("installed_build") or {}
        installed_name = evil_plain_text(installed.get("name") or "")
        found = None
        for entry in list(self.evil_local_entries) + list(self.evil_online_builds):
            if installed_name and evil_plain_text(entry.get("name") or "").lower() == installed_name.lower():
                found = entry
                break
        if installed.get("name"):
            label = "Installiert: %s" % installed["name"]
            if installed.get("version"):
                label += " v%s" % installed["version"]
            if found and found.get("version") and found.get("version") != installed.get("version"):
                label += " · Update: v%s" % found["version"]
            elif found:
                label += " · aktuell"
        else:
            label = "Installiert: keiner"
        self.getControl(840).setLabel(label)

    def evil_refresh_switch(self):
        try:
            self.getControl(807).setLabel("[X] ONLINE" if self.evil_view == "online" else "[ ] ONLINE")
            self.getControl(808).setLabel("[X] LOKAL" if self.evil_view == "local" else "[ ] LOKAL")
        except Exception:
            pass

    def evil_set_view(self, view):
        if self.evil_busy or view not in ("online", "local"):
            return
        if view == self.evil_view:
            self.evil_refresh()
            return
        self.evil_view = view
        self.evil_source_time = 0
        if view == "local":
            self.evil_local_entries = self.evil_installer.evil_local_builds()
            self.evil_source = "Build-Ordner"
            self.evil_refresh()
            return
        self.evil_source = "Online"
        self.evil_refresh()
        if not self.evil_active_sources():
            if self.evil_has_build_sources():
                self.getControl(806).setLabel("Online · Keine aktive Build-Quelle · BUILD QUELLEN öffnet die Auswahl")
            else:
                self.getControl(806).setLabel("Online · Keine Build-Quelle · AKTUALISIEREN öffnet die Abfrage")
            return
        if not self.evil_online_loaded:
            self.evil_load_list()

    def evil_progress(self, percent, label=""):
        self.getControl(820).setPercent(int(percent))
        self.getControl(806).setLabel("IT'S-POSSIBLE: %s" % label)
        xbmc.sleep(20)

    def evil_cancelled(self):
        return self.evil_abort

    def evil_load_list(self, force=False):
        if self.evil_busy:
            return
        self.evil_local_entries = self.evil_installer.evil_local_builds()
        sources = self.evil_active_sources()
        if not sources:
            if self.evil_has_build_sources():
                self.getControl(806).setLabel("Online · Keine aktive Build-Quelle · BUILD QUELLEN öffnet die Auswahl")
                return
            url = evil_url_dialog("BUILD-LISTE")
            if not url:
                return
            source_id = "build-list"
            existing = None
            for entry in self.evil_config.get("build_sources", []):
                if entry.get("id") == source_id:
                    existing = entry
                    break
            if existing:
                existing["url"] = url
                existing["name"] = existing.get("name") or "Build-Liste"
            else:
                self.evil_config.setdefault("build_sources", []).append({
                    "id": source_id,
                    "name": "Build-Liste",
                    "url": url,
                })
            active_ids = self.evil_config.get("active_build_sources")
            if not isinstance(active_ids, list):
                active_ids = []
            if source_id not in active_ids:
                active_ids.append(source_id)
            self.evil_config["active_build_sources"] = active_ids
            self.evil_config["active_build_source"] = active_ids[0] if active_ids else ""
            self.evil_installer.save_config(self.evil_config)
            sources = self.evil_active_sources()
        if not sources:
            if self.evil_has_build_sources():
                self.getControl(806).setLabel("Online · Keine aktive Build-Quelle · BUILD QUELLEN öffnet die Auswahl")
            else:
                self.getControl(806).setLabel("Online · Keine Build-Quelle · AKTUALISIEREN öffnet die Abfrage")
            return
        self.evil_busy = True
        self.evil_abort = False
        self.evil_source_time = 0
        self.getControl(820).setVisible(True)
        self.getControl(820).setPercent(0)
        self.evil_installer.attach(self.evil_progress, self.evil_cancelled)
        merged = []
        seen_urls = set()
        loaded = 0
        cached_count = 0
        failed = []
        total = len(sources)
        try:
            for index, source in enumerate(sources):
                if self.evil_abort:
                    break
                name = source.get("name") or source.get("id") or "Build-Quelle"
                url = source.get("url", "")
                start = int(index * 100 / total)
                end = int((index + 1) * 100 / total)
                builds = []
                if not force:
                    builds, saved = self.evil_installer.evil_load_build_cache(url)
                    if builds:
                        cached_count += 1
                        self.evil_source_time = max(self.evil_source_time, saved)
                if not builds:
                    try:
                        self.evil_progress(start, "%s laden" % name)
                        text = self.evil_installer.evil_fetch_text(url, name, start, end)
                        builds = evil_parse_builds(text, url)
                        if not builds:
                            raise ValueError("Keine Builds in der Liste gefunden.")
                        self.evil_installer.evil_save_build_cache(url, builds)
                    except EvilCancelled:
                        break
                    except Exception as error:
                        evil_log("Build-Quelle %s fehlgeschlagen: %s" % (name, error), xbmc.LOGERROR)
                        cached, saved = self.evil_installer.evil_load_build_cache(url)
                        if cached:
                            builds = cached
                            cached_count += 1
                            self.evil_source_time = max(self.evil_source_time, saved)
                        else:
                            failed.append(name)
                            continue
                for entry in builds:
                    entry = dict(entry)
                    entry["source_name"] = name
                    entry["source_id"] = source.get("id", "")
                    url_key = str(entry.get("url") or "")
                    if url_key and url_key in seen_urls:
                        continue
                    if url_key:
                        seen_urls.add(url_key)
                    merged.append(entry)
                loaded += 1
                self.evil_progress(end, "%s fertig" % name)
            if self.evil_abort:
                self.getControl(806).setLabel("Laden abgebrochen.")
                return
            self.evil_online_builds = merged
            self.evil_online_loaded = True
            self.evil_view = "online"
            if loaded:
                self.evil_source = "%d Quelle%s" % (loaded, "" if loaded == 1 else "n")
                if cached_count:
                    self.evil_source += " · %d Cache" % cached_count
            else:
                self.evil_source = "keine Quelle"
                self.evil_source_time = 0
            self.evil_refresh()
        finally:
            self.evil_installer.attach(None, None)
            self.evil_busy = False
            self.getControl(820).setVisible(False)
        if failed:
            detail = ", ".join(failed[:3])
            if len(failed) > 3:
                detail += " und %d weitere" % (len(failed) - 3)
            self.getControl(806).setLabel("Nicht geladen: %s" % detail)

    def evil_manual(self):
        if self.evil_busy:
            return
        previous_url = str(self.evil_config.get("last_build_url") or "").strip()
        url = evil_url_dialog("ZIP-ADRESSE", previous_url)
        if not url:
            return
        if not url.lower().startswith(("http://", "https://", "file://")):
            self.getControl(806).setLabel("Ungültige Adresse. Erlaubt sind http, https und file.")
            return
        self.evil_config["last_build_url"] = url
        setting_saved = evil_set_last_build_url(url)
        config_saved = self.evil_installer.save_config(self.evil_config)
        if not setting_saved and not config_saved:
            xbmcgui.Dialog().ok(
                EVIL_TITLE,
                "Die ZIP-Adresse konnte nicht dauerhaft gespeichert werden. "
                "Prüfe den Userdata-Ordner und versuche es erneut.",
            )
        name = url.split("?")[0].rstrip("/").rsplit("/", 1)[-1]
        if name.lower().endswith(".zip"):
            name = name[:-4]
        entry = {
            "name": name or "Manueller Build",
            "version": "",
            "url": url,
            "kodi": "",
            "description": "Manuell eingegeben",
            "icon": "",
            "fanart": "",
            "adult": False,
            "source": "manuell",
            "source_name": "Manuell",
        }
        self.evil_install(entry)

    def evil_open_info(self):
        position = self.getControl(810).getSelectedPosition()
        if position < 0 or position >= len(self.evil_builds):
            xbmcgui.Dialog().ok(EVIL_TITLE, "Kein Build ausgewählt.")
            return
        window = EvilBuildInfoWindow("script-itspossible-buildinfo.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_entry = self.evil_builds[position]
        window.evil_config = self.evil_config
        window.evil_installer = self.evil_installer
        window.evil_parent = self
        window.evil_addon_path = self.evil_addon_path
        window.doModal()
        del window
        self.evil_refresh()

    def evil_install_selected(self):
        position = self.getControl(810).getSelectedPosition()
        if position < 0 or position >= len(self.evil_builds):
            xbmcgui.Dialog().ok(EVIL_TITLE, "Kein Build ausgewählt.")
            return
        self.evil_install(self.evil_builds[position])

    def evil_backup_categories(self):
        selected = self.evil_backup_selected
        if isinstance(selected, str):
            selected = [selected]
        valid = {option["id"] for option in EVIL_BACKUP_OPTIONS}
        categories = [value for value in (selected or []) if value in valid]
        return categories or ["gui", "addon_data"]

    def evil_confirm(self, title, message, yes_label="JA", no_label="NEIN", subtitle=""):
        return evil_confirm_dialog(
            self.evil_addon_path,
            title,
            message,
            yes_label,
            no_label,
            subtitle,
        )

    def evil_install(self, entry):
        if self.evil_busy:
            return
        turbo = evil_turbo_enabled()
        name = entry.get("name") or "Build"
        version = entry.get("version") or ""
        if turbo:
            evil_log("Turbo-Build aktiv: Installationsabfragen werden übersprungen.", xbmc.LOGINFO)
            self.evil_start_install(entry, name, version, [], False, True)
            return
        if entry.get("adult"):
            if not self.evil_confirm(
                "BUILD 18+",
                "Dieser Build ist als 18+ markiert.\n\nTrotzdem fortfahren?",
                yes_label="JA, FORTFAHREN",
                no_label="ZURÜCK",
                subtitle=entry.get("name") or "Build",
            ):
                return
        wanted = 0
        match = re.match(r"\s*(\d+)", str(entry.get("kodi") or ""))
        if match:
            wanted = int(match.group(1))
        current = evil_kodi_major()
        if wanted and current and wanted != current:
            message = (
                "Dieser Build ist für Kodi %s gedacht.\n"
                "Installiert ist Kodi %s.\n\n"
                "Skin und Addons können unbrauchbar werden. Trotzdem installieren?"
            ) % (entry.get("kodi"), current)
            if not self.evil_confirm(
                "KODI-VERSION",
                message,
                yes_label="TROTZDEM INSTALLIEREN",
                no_label="ZURÜCK",
                subtitle=entry.get("name") or "Build",
            ):
                return
        name = entry.get("name") or "Build"
        version = entry.get("version") or ""
        title = "%s v%s" % (name, version) if version else name
        message = (
            "Die Dateien werden nach Kodi entpackt. Vorhandene Dateien mit gleichem Namen "
            "werden überschrieben, nichts wird gelöscht.\n\n"
            "Während des Installierens läuft unten im Fenster ein Fortschrittsbalken. "
            "Mit ABBRECHEN kannst du abbrechen; bereits entpackte Dateien bleiben.\n\n"
            "Danach fragt der Wizard, ob vorher gesichert und ob Addons wiederhergestellt "
            "und aktiviert werden sollen.\n\n"
            "Der Wizard wird nach der Installation automatisch aktiviert. "
            "Fremde Wizards werden automatisch deaktiviert."
        )
        if not self.evil_confirm(
            "BUILD INSTALLIEREN",
            message,
            yes_label="INSTALLIEREN",
            no_label="ZURÜCK",
            subtitle=title,
        ):
            return
        selected = self.evil_backup_categories()
        labels = [
            option["label"] for option in EVIL_BACKUP_OPTIONS
            if option["id"] in selected
        ]
        do_backup = self.evil_confirm(
            "SICHERUNG VOR DER INSTALLATION",
            "Vor der Installation eine Sicherung erstellen?\n\n"
            "Gesichert werden: %s.\n\n"
            "Die Sicherung liegt unter userdata/itspossible_backups/." % ", ".join(labels),
            yes_label="JA, SICHERN",
            no_label="NEIN, OHNE SICHERUNG",
            subtitle=title,
        )
        restore_message = (
            "Nach der Installation Addon-Daten aus der Sicherung wiederherstellen "
            "und alle installierten Addons aktivieren?"
            if do_backup else
            "Nach der Installation alle installierten Addons aktivieren?"
        )
        restore_addons = self.evil_confirm(
            "ADDONS AKTIVIEREN",
            restore_message + "\n\nDer Wizard selbst wird in jedem Fall automatisch aktiviert. "
            "Fremde Wizards werden danach deaktiviert.",
            yes_label="JA, ADDONS",
            no_label="NEIN",
            subtitle=title,
        )
        backup_selected = selected if do_backup else []
        if restore_addons and backup_selected and "addon_data" not in backup_selected:
            backup_selected.append("addon_data")
        self.evil_start_install(entry, name, version, backup_selected, restore_addons, False)

    def evil_start_install(self, entry, name, version, backup_selected, restore_addons, turbo=False):
        self.evil_busy = True
        self.evil_abort = False
        self.getControl(820).setVisible(True)
        self.getControl(820).setPercent(0)
        self.getControl(806).setLabel("IT'S-POSSIBLE: %s" % ("Turbo-Build wird installiert" if turbo else "Build vorbereiten"))
        try:
            self.getControl(804).setLabel("ABBRECHEN")
            self.setFocusId(804)
        except Exception:
            pass
        worker = threading.Thread(
            target=self.evil_install_worker,
            args=(dict(entry), name, version, backup_selected, restore_addons, turbo),
            name="ItsPossibleBuildInstall",
        )
        worker.daemon = True
        worker.start()

    def evil_install_worker(self, entry, name, version, backup_selected, restore_addons, turbo=False):
        backup = ""
        result = None
        cancelled = False
        error_text = ""
        restored = 0
        enabled = 0
        activation_failed = []
        try:
            if backup_selected:
                self.evil_progress(1, "Sichere Einstellungen")
                if self.evil_abort:
                    raise EvilCancelled("IT'S-POSSIBLE abgebrochen")
                backup = evil_backup_settings(
                    backup_selected,
                    lambda percent, label="": self.evil_progress(percent, label),
                )
                if self.evil_abort:
                    raise EvilCancelled("IT'S-POSSIBLE abgebrochen")
            else:
                self.evil_progress(2, "Sicherung übersprungen")
            self.evil_installer.attach(self.evil_progress, self.evil_cancelled)
            result = self.evil_installer.evil_install_build(entry.get("url", ""), name, turbo=turbo)
            if result and restore_addons:
                try:
                    if backup:
                        self.evil_progress(96, "Addon-Daten wiederherstellen")
                        restored = evil_restore_addon_data(
                            backup,
                            lambda percent, label="": self.evil_progress(
                                96 + int(percent * 3 / 100), label
                            ),
                        )
                    self.evil_progress(99, "Addons aktivieren")
                    enabled, activation_failed = evil_enable_disabled_addons()
                    try:
                        foreign_after_enable = evil_disable_foreign_wizards()
                        if foreign_after_enable:
                            result["foreign_wizards"] = sorted(
                                set(result.get("foreign_wizards") or []) | set(foreign_after_enable)
                            )
                    except Exception as error:
                        evil_log("Fremde Wizards nach Addon-Aktivierung nicht deaktiviert: %s" % error, xbmc.LOGERROR)
                except Exception as error:
                    evil_log("Addons nach Build nicht vollständig aktiviert: %s" % error, xbmc.LOGERROR)
                    activation_failed = [str(error)]
        except EvilCancelled:
            cancelled = True
        except Exception as error:
            evil_log("Build %s fehlgeschlagen: %s" % (name, error), xbmc.LOGERROR)
            error_text = str(error)
        finally:
            self.evil_installer.attach(None, None)
        self.evil_install_finish(
            result,
            backup,
            cancelled,
            error_text,
            entry,
            name,
            version,
            restore_addons,
            restored,
            enabled,
            activation_failed,
            turbo,
        )

    def evil_install_finish(self, result, backup, cancelled, error_text, entry, name, version, restore_addons, restored, enabled, activation_failed, turbo=False):
        self.evil_busy = False
        self.evil_abort = False
        self.evil_installer.attach(None, None)
        try:
            self.getControl(820).setVisible(False)
            self.getControl(804).setLabel("ZURÜCK")
        except Exception:
            pass
        if cancelled:
            self.getControl(806).setLabel("Build abgebrochen.")
            xbmcgui.Dialog().notification(EVIL_TITLE, "Build abgebrochen", xbmcgui.NOTIFICATION_WARNING, 4000)
            return
        if not result:
            self.getControl(806).setLabel("Build fehlgeschlagen.")
            xbmcgui.Dialog().ok(EVIL_TITLE, "Build fehlgeschlagen.\n%s" % (error_text or "Unbekannter Fehler"))
            return
        self.evil_config["installed_build"] = {
            "name": name,
            "version": version,
            "url": entry.get("url", ""),
            "kodi": entry.get("kodi", ""),
            "icon": entry.get("icon", ""),
            "fanart": entry.get("fanart", ""),
            "source": entry.get("source", ""),
        }
        self.evil_installer.save_config(self.evil_config)
        self.evil_installer.evil_reset_manual_build_installed()
        self.evil_refresh()
        self.getControl(806).setLabel("Build installiert: %s" % name)
        message = "Build %s installiert.\n\n%d Dateien entpackt, %d übersprungen." % (name, result["files"], result["skipped"])
        if result["binaries"]:
            message += "\n\nPlattform-Addons im Build:\n%s" % ", ".join(result["binaries"])
        if backup:
            message += "\n\nSicherung: %s" % os.path.basename(backup)
        if result.get("wizard_enabled"):
            message += "\n\nDer Wizard wurde automatisch aktiviert."
        elif result.get("wizard_autoexec"):
            message += "\n\nDer Wizard wird beim nächsten Kodi-Start automatisch aktiviert."
        else:
            message += "\n\nHinweis: Der Wizard konnte nicht automatisch aktiviert werden."
        if restore_addons:
            if backup:
                message += "\n\nAddon-Daten wiederhergestellt: %d Dateien." % restored
            message += "\n\nAddons aktiviert: %d." % enabled
            if activation_failed:
                message += " %d fehlgeschlagen." % len(activation_failed)
        foreign_wizards = result.get("foreign_wizards") or []
        if foreign_wizards:
            message += "\n\nFremde Wizards deaktiviert: %d." % len(foreign_wizards)
            if result.get("foreign_wizard_autoexec"):
                message += " Beim nächsten Kodi-Start werden sie erneut deaktiviert."
        if turbo:
            message += "\n\nTurbo: ohne Sicherung und ohne Rückfrage installiert."
        auto_restart = (
            xbmc.getCondVisibility("System.Platform.Windows")
            or xbmc.getCondVisibility("System.Platform.Android")
        )
        if auto_restart:
            message += "\n\nKodi wird jetzt beendet und automatisch neu gestartet."
        else:
            message += "\n\nKodi wird jetzt hart geschlossen. Bitte starte Kodi danach neu, damit Addons und Skin geladen werden."
        evil_log(message.replace("\n", " | "), xbmc.LOGINFO)
        notification = (
            "Build %s installiert. Kodi wird neu gestartet ..." % name
            if auto_restart else
            "Build %s installiert. Kodi wird geschlossen ..." % name
        )
        try:
            xbmcgui.Dialog().notification(
                EVIL_TITLE,
                notification,
                xbmcgui.NOTIFICATION_INFO,
                5000,
            )
            xbmc.sleep(500 if turbo else 2500)
        finally:
            evil_force_close(True)

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if self.evil_busy:
            if control_id == 804:
                self.evil_abort = True
                self.getControl(806).setLabel("Abbruch angefordert ...")
            return
        if control_id == 810:
            self.evil_open_info()
        elif control_id == 801:
            if self.evil_view == "local":
                self.evil_local_entries = self.evil_installer.evil_local_builds()
                self.evil_source = "Build-Ordner"
                self.evil_refresh()
            else:
                self.evil_load_list(True)
        elif control_id == 802:
            self.evil_install_selected()
        elif control_id == 803:
            self.evil_manual()
        elif control_id == 809:
            self.evil_select_sources()
        elif control_id == 812:
            self.evil_open_sort()
        elif control_id == 804:
            self.close()
        elif control_id == 807:
            self.evil_set_view("online")
        elif control_id == 808:
            self.evil_set_view("local")

    def onAction(self, action):
        if action.getId() not in EVIL_BACK_ACTIONS:
            return
        if self.evil_busy:
            self.evil_abort = True
            return
        self.close()


class EvilInputWindow(xbmcgui.WindowXML):
    evil_title = "IT'S-POSSIBLE"
    evil_subtitle = ""
    evil_default = ""
    evil_required = True
    evil_result = None

    def onInit(self):
        evil_apply_window(self)
        self.evil_result = None
        self.getControl(940).setLabel(self.evil_title)
        self.getControl(941).setLabel(self.evil_subtitle)
        self.getControl(942).setText(self.evil_default)
        self.getControl(943).setLabel("")
        self.setFocusId(942)

    def evil_save(self):
        text = self.getControl(942).getText().strip()
        if self.evil_required and not text:
            self.getControl(943).setLabel("Bitte eine Eingabe machen.")
            self.setFocusId(942)
            return
        self.evil_result = text
        self.close()

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 944:
            self.evil_save()
        elif control_id == 945:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilConfirmWindow(xbmcgui.WindowXML):
    evil_addon_path = ""
    evil_title = "IT'S-POSSIBLE"
    evil_subtitle = ""
    evil_text = ""
    evil_yes_label = "JA"
    evil_no_label = "NEIN"
    evil_result = False

    def onInit(self):
        evil_apply_window(self)
        self.evil_result = False
        self.getControl(720).setLabel(self.evil_title)
        self.getControl(721).setLabel(self.evil_subtitle)
        self.getControl(722).setText(self.evil_text)
        self.getControl(725).setLabel(self.evil_yes_label)
        self.getControl(726).setLabel(self.evil_no_label)
        self.setFocusId(722)

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 725:
            self.evil_result = True
            self.close()
        elif control_id == 726:
            self.evil_result = False
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.evil_result = False
            self.close()


class EvilBuildInfoWindow(xbmcgui.WindowXML):
    evil_addon_path = ""
    evil_config = {}
    evil_entry = {}
    evil_parent = None

    def onInit(self):
        evil_apply_window(self)
        self.evil_refresh()
        self.setFocusId(856)

    def evil_refresh(self):
        entry = self.evil_entry or {}
        name = evil_plain_text(entry.get("name") or "Unbekannter Build")
        fanart = entry.get("fanart") or os.path.join(self.evil_addon_path, "fanart.png")
        icon = entry.get("icon") or os.path.join(self.evil_addon_path, "icon.png")
        self.getControl(852).setLabel(name)
        meta = []
        if entry.get("adult"):
            meta.append("18+")
        if entry.get("version"):
            meta.append("Version %s" % entry["version"])
        if entry.get("kodi"):
            meta.append("Kodi %s" % entry["kodi"])
        if entry.get("size"):
            meta.append("Größe %s" % entry["size"])
        if entry.get("source_name"):
            meta.append("Quelle: %s" % entry["source_name"])
        self.getControl(853).setLabel(" · ".join(meta) or "Build")
        self.getControl(854).setText(evil_plain_text(entry.get("description") or "Keine Beschreibung vorhanden."))
        self.getControl(855).setLabel("INSTALLIEREN")
        if entry.get("adult"):
            status = "18+ · Bestätigung erforderlich"
        else:
            status = "Bereit zur Installation."
        self.getControl(857).setLabel(status)
        try:
            self.getControl(849).setImage(fanart)
        except Exception:
            pass
        try:
            self.getControl(850).setImage(icon)
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 855 and self.evil_parent is not None:
            entry = self.evil_entry
            self.close()
            self.evil_parent.evil_install(entry)
        elif control_id == 856:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilAddonWindow(xbmcgui.WindowXML):
    evil_entries = []
    evil_selected = set()
    evil_addon_path = ""
    evil_config = {}
    evil_parent = None
    evil_current = 0

    def onInit(self):
        evil_apply_window(self)
        self.evil_entries = list(self.evil_entries or [])
        self.evil_selected = set()
        self.evil_current = 0
        self.evil_refresh_list(0)
        self.evil_refresh_preview()
        self.setFocusId(860)

    def evil_details(self, entry):
        details = []
        if entry.get("version"):
            details.append("v%s" % entry["version"])
        if entry.get("summary"):
            details.append(evil_plain_text(entry["summary"])[:110])
        elif entry.get("description"):
            details.append(evil_plain_text(entry["description"])[:110])
        return " · ".join(details) or "Kodi Media Addon"

    def evil_refresh_list(self, position=0):
        container = self.getControl(860)
        container.reset()
        for index, entry in enumerate(self.evil_entries):
            name = evil_plain_text(entry.get("name") or entry.get("id") or "Addon")
            marker = "[X] " if index in self.evil_selected else "[ ] "
            item = xbmcgui.ListItem(label=marker + name)
            item.setLabel2(self.evil_details(entry))
            art = {"icon": entry.get("icon") or os.path.join(self.evil_addon_path, "icon.png")}
            fanart = entry.get("fanart") or os.path.join(self.evil_addon_path, "fanart.png")
            if fanart:
                art["fanart"] = fanart
            try:
                item.setArt(art)
            except Exception:
                pass
            container.addItem(item)
        if self.evil_entries:
            self.evil_current = min(max(int(position), 0), len(self.evil_entries) - 1)
        else:
            self.evil_current = 0
        try:
            container.selectItem(self.evil_current)
        except Exception:
            pass
        self.evil_update_status()

    def evil_update_status(self):
        self.getControl(866).setLabel("%d von %d ausgewählt" % (len(self.evil_selected), len(self.evil_entries)))

    def evil_position(self):
        try:
            position = self.getControl(860).getSelectedPosition()
        except Exception:
            position = self.evil_current
        if position < 0 or position >= len(self.evil_entries):
            position = self.evil_current
        return position

    def evil_refresh_preview(self):
        if not self.evil_entries:
            self.getControl(863).setLabel("Keine Addons")
            self.getControl(864).setLabel("")
            self.getControl(865).setText("Keine Addons gefunden.")
            return
        self.evil_current = self.evil_position()
        entry = self.evil_entries[self.evil_current]
        name = evil_plain_text(entry.get("name") or entry.get("id") or "Addon")
        meta = []
        if entry.get("version"):
            meta.append("Version %s" % entry["version"])
        if entry.get("source"):
            meta.append(entry["source"])
        self.getControl(863).setLabel(name)
        self.getControl(864).setLabel(" · ".join(meta) or "Kodi Media Addon")
        self.getControl(865).setText(evil_plain_text(entry.get("description") or entry.get("summary") or "Keine Beschreibung vorhanden."))
        self.getControl(867).setLabel("ENTFERNEN" if self.evil_current in self.evil_selected else "MARKIEREN")
        fanart = entry.get("fanart") or os.path.join(self.evil_addon_path, "fanart.png")
        icon = entry.get("icon") or os.path.join(self.evil_addon_path, "icon.png")
        try:
            self.getControl(861).setImage(fanart)
        except Exception:
            pass
        try:
            self.getControl(862).setImage(icon)
        except Exception:
            pass

    def evil_toggle(self):
        if not self.evil_entries:
            return
        self.evil_current = self.evil_position()
        if self.evil_current in self.evil_selected:
            self.evil_selected.remove(self.evil_current)
        else:
            self.evil_selected.add(self.evil_current)
        self.evil_refresh_list(self.evil_current)
        self.evil_refresh_preview()

    def evil_install(self):
        picked = [entry for index, entry in enumerate(self.evil_entries) if index in self.evil_selected]
        if not picked:
            self.getControl(866).setLabel("Mindestens ein Addon markieren.")
            return
        if self.evil_parent is None:
            return
        self.close()
        self.evil_parent.evil_start_addons(picked)

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 860:
            self.evil_current = self.evil_position()
            self.evil_toggle()
        elif control_id == 867:
            self.evil_toggle()
        elif control_id == 868:
            self.evil_install()
        elif control_id == 869:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()
            return
        self.evil_current = self.evil_position()
        self.evil_refresh_preview()


class EvilLogWindow(xbmcgui.WindowXML):
    evil_addon_path = ""
    evil_text = ""

    def onInit(self):
        evil_apply_window(self)
        self.getControl(60).setLabel("kodi.log · letzte %d Zeichen" % len(self.evil_text))
        self.getControl(700).setText(self.evil_text)
        self.setFocusId(700)

    def evil_reload(self):
        self.evil_text = evil_read_log()
        self.getControl(60).setLabel("kodi.log · letzte %d Zeichen" % len(self.evil_text))
        self.getControl(700).setText(self.evil_text)

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 701:
            self.evil_reload()
        elif control_id == 702:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilReadmeWindow(xbmcgui.WindowXML):
    evil_addon_path = ""
    evil_text = ""

    def onInit(self):
        evil_apply_window(self)
        text = self.evil_text or "README.md wurde nicht gefunden."
        self.getControl(60).setLabel("README.md · %d Zeilen" % (text.count("\n") + 1))
        self.getControl(710).setText(text)
        self.setFocusId(710)

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 711:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilSystemWindow(xbmcgui.WindowXML):
    evil_addon_path = ""
    evil_config = {}

    def onInit(self):
        evil_apply_window(self)
        self.evil_refresh()
        self.setFocusId(902)

    def evil_refresh(self):
        self.getControl(900).setText(evil_system_text(self.evil_config))
        self.getControl(901).setLabel("Aktualisiert. Zurück schließt das Fenster.")

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 902:
            self.evil_refresh()
        elif control_id == 903:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilBackupWindow(xbmcgui.WindowXML):
    evil_addon_path = ""
    evil_options = ()
    evil_selected = set()
    evil_result = None
    evil_mode = "backup"

    def onInit(self):
        evil_apply_window(self)
        self.evil_options = tuple(EVIL_BACKUP_OPTIONS)
        self.evil_selected = {"gui", "addon_data"}
        if self.evil_mode == "build":
            self.getControl(8900).setLabel("IT'S-POSSIBLE BUILD")
            self.getControl(887).setLabel("Was soll vor der Build-Installation gesichert werden?")
            self.getControl(883).setLabel("WEITER ZU DEN BUILDS")
            evil_apply_title(self, getattr(self, "evil_config", {}))
        self.evil_refresh(0)
        self.setFocusId(880)

    def evil_refresh(self, position=0):
        container = self.getControl(880)
        container.reset()
        for option in self.evil_options:
            mark = "[X]" if option["id"] in self.evil_selected else "[ ]"
            item = xbmcgui.ListItem(label="%s  %s" % (mark, option["label"]))
            container.addItem(item)
        if self.evil_options:
            position = max(0, min(position, len(self.evil_options) - 1))
            container.selectItem(position)
        all_selected = len(self.evil_selected) == len(self.evil_options) and bool(self.evil_options)
        self.getControl(884).setLabel("AUSWAHL AUFHEBEN" if all_selected else "ALLE AUSWÄHLEN")
        self.evil_preview()

    def evil_preview(self):
        position = self.getControl(880).getSelectedPosition()
        if position < 0 or position >= len(self.evil_options):
            position = 0
        if self.evil_options:
            option = self.evil_options[position]
            text = "%s\n\n%s" % (option["label"], option["description"])
        else:
            text = "Keine Sicherungsoptionen verfügbar."
        count = len(self.evil_selected)
        prefix = "VOR DER INSTALLATION" if self.evil_mode == "build" else "SICHERUNG"
        self.getControl(881).setText(text)
        self.getControl(882).setLabel("%s: %d von %d Kategorien ausgewählt." % (prefix, count, len(self.evil_options)))

    def evil_toggle(self):
        position = self.getControl(880).getSelectedPosition()
        if position < 0 or position >= len(self.evil_options):
            return
        category = self.evil_options[position]["id"]
        if category in self.evil_selected:
            self.evil_selected.remove(category)
        else:
            self.evil_selected.add(category)
        self.evil_refresh(position)

    def evil_select_all(self):
        position = self.getControl(880).getSelectedPosition()
        if len(self.evil_selected) == len(self.evil_options) and self.evil_options:
            self.evil_selected.clear()
        else:
            self.evil_selected = {option["id"] for option in self.evil_options}
        self.evil_refresh(position)

    def evil_backup(self):
        selected = [option["id"] for option in self.evil_options if option["id"] in self.evil_selected]
        if not selected:
            xbmcgui.Dialog().ok(EVIL_TITLE, "Bitte mindestens eine Kategorie auswählen.")
            return
        self.evil_result = selected
        self.close()

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 880:
            self.evil_toggle()
        elif control_id == 883:
            self.evil_backup()
        elif control_id == 884:
            self.evil_select_all()
        elif control_id == 885:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilFtpWindow(xbmcgui.WindowXML):
    evil_addon_path = ""
    evil_message = ""

    def onInit(self):
        evil_apply_window(self)
        self.evil_message = ""
        self.evil_refresh()
        self.setFocusId(975)

    def evil_refresh(self):
        status = evil_ftp.evil_ftp_status()
        running = status["running"]
        if running:
            state = "LÄUFT"
            action = "FTP-SERVER STOPPEN"
        elif status["starting"]:
            state = "STARTET ..."
            action = "FTP-SERVER STARTEN"
        else:
            state = "GESTOPPT"
            action = "FTP-SERVER STARTEN"
        self.getControl(970).setLabel("FTP-SERVER: %s" % state)
        self.getControl(975).setLabel(action)
        if running:
            address = "ftp://%s:%s" % (status["address"] or "127.0.0.1", status["port"] or "?")
            root = "Ordner: %s" % (status["root"] or "unbekannt")
            auth = "Anmeldung: %s" % (status["auth"] or "unbekannt")
        else:
            address = "Adresse: noch nicht gestartet"
            root = "Ordner: wird beim Start ermittelt"
            auth = "Anmeldung: wird beim Start ermittelt"
        self.getControl(971).setLabel(address)
        self.getControl(972).setText(root)
        self.getControl(973).setLabel(auth)
        if status["error"]:
            message = "FEHLER: %s" % status["error"]
        elif self.evil_message:
            message = self.evil_message
        elif not status["service"]:
            message = "Der FTP-Dienst startet zusammen mit Kodi. Bitte einen Moment warten."
        else:
            message = "Einstellungen werden nach einem Neustart des FTP-Servers übernommen."
        self.getControl(974).setLabel(message)

    def evil_wait_for(self, running, timeout=8.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            xbmc.sleep(250)
            self.evil_refresh()
            status = evil_ftp.evil_ftp_status()
            if running and status["running"]:
                return True
            if not running and not status["running"] and not status["starting"]:
                return True
            if status["error"] and not status["starting"]:
                return False
        return False

    def evil_toggle_server(self):
        status = evil_ftp.evil_ftp_status()
        if status["running"]:
            evil_ftp.evil_ftp_send_command("stop")
            self.evil_message = "FTP-Server wird gestoppt ..."
            self.evil_refresh()
            if self.evil_wait_for(False):
                self.evil_message = "FTP-Server gestoppt."
            else:
                self.evil_message = "FTP-Server konnte nicht gestoppt werden."
        else:
            evil_ftp.evil_ftp_send_command("start")
            self.evil_message = "FTP-Server wird gestartet ..."
            self.evil_refresh()
            if self.evil_wait_for(True):
                self.evil_message = "FTP-Server läuft."
            else:
                self.evil_message = "FTP-Server konnte nicht gestartet werden."
        self.evil_refresh()

    def evil_settings(self):
        if evil_open_settings():
            self.evil_message = "Einstellungen geöffnet. Änderungen werden nach einem Server-Neustart übernommen."
        else:
            self.evil_message = "Einstellungen konnten nicht geöffnet werden."
        self.evil_refresh()

    def onClick(self, control_id):
        if control_id == 975:
            self.evil_toggle_server()
        elif control_id in (976, 999):
            self.evil_settings()
        elif control_id == 977:
            self.close()
        elif control_id == 978:
            self.evil_message = ""
            self.evil_refresh()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()




class EvilSourceSelectWindow(xbmcgui.WindowXML):
    evil_entries = []
    evil_selected = set()
    evil_result = None
    evil_addon_path = ""

    def onInit(self):
        evil_apply_window(self)
        self.evil_entries = [entry for entry in (self.evil_entries or []) if isinstance(entry, dict)]
        self.evil_selected = {
            entry.get("id", "")
            for entry in self.evil_entries
            if entry.get("id")
        }
        self.evil_result = None
        self.evil_refresh(0)
        self.setFocusId(700)

    def evil_name(self, entry):
        return evil_plain_text(entry.get("name") or entry.get("id") or "Repository")

    def evil_state(self, entry):
        addon_id = entry.get("id", "")
        if addon_id and evil_installed(addon_id):
            return "installiert · wird aktiviert"
        return "wird installiert und aktiviert"

    def evil_refresh(self, position=0):
        container = self.getControl(700)
        container.reset()
        for entry in self.evil_entries:
            addon_id = entry.get("id", "")
            marker = "[X]" if addon_id in self.evil_selected else "[ ]"
            item = xbmcgui.ListItem(label="%s  %s" % (marker, self.evil_name(entry)))
            item.setLabel2("%s · %s" % (addon_id or "?", self.evil_state(entry)))
            try:
                icon = entry.get("icon") or os.path.join(self.evil_addon_path, "icon.png")
                item.setArt({"icon": icon})
            except Exception:
                pass
            container.addItem(item)
        if self.evil_entries:
            position = max(0, min(int(position), len(self.evil_entries) - 1))
            try:
                container.selectItem(position)
            except Exception:
                pass
        count = sum(1 for entry in self.evil_entries if entry.get("id") in self.evil_selected)
        self.getControl(702).setLabel("%d von %d Quellen ausgewählt" % (count, len(self.evil_entries)))
        self.getControl(701).setText(
            "Aktive Repository-Quellen werden beim Bestätigen installiert und eingeschaltet.\n\n"
            "Bereits installierte Repositories werden erneut aktiviert.\n\n"
            "Mit OK auf der Liste schaltest du eine Quelle um."
        )

    def evil_toggle(self):
        container = self.getControl(700)
        position = container.getSelectedPosition()
        if position < 0 or position >= len(self.evil_entries):
            return
        addon_id = self.evil_entries[position].get("id", "")
        if not addon_id:
            return
        if addon_id in self.evil_selected:
            self.evil_selected.remove(addon_id)
        else:
            self.evil_selected.add(addon_id)
        self.evil_refresh(position)

    def onClick(self, control_id):
        if control_id == 700:
            self.evil_toggle()
        elif control_id == 710:
            picked = [entry for entry in self.evil_entries if entry.get("id") in self.evil_selected]
            if not picked:
                self.getControl(702).setLabel("Bitte mindestens eine Quelle auswählen.")
                return
            self.evil_result = picked
            self.close()
        elif control_id == 711:
            self.evil_selected = {entry.get("id", "") for entry in self.evil_entries if entry.get("id")}
            self.evil_refresh()
        elif control_id == 712:
            self.evil_selected = set()
            self.evil_refresh()
        elif control_id == 713:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilAdvancedRestoreWindow(xbmcgui.WindowXML):
    evil_addon_path = ""
    evil_backups = []
    evil_result = ""

    def onInit(self):
        evil_apply_window(self)
        self.evil_result = ""
        self.evil_refresh()

    def evil_refresh(self):
        self.evil_backups = evil_advanced_list_backups()
        container = self.getControl(720)
        container.reset()
        for path in self.evil_backups:
            item = xbmcgui.ListItem(label=os.path.basename(path))
            item.setLabel2("Advancedsettings-Sicherung")
            container.addItem(item)
        if self.evil_backups:
            container.selectItem(0)
            self.getControl(723).setVisible(True)
            self.evil_selected()
            self.setFocusId(720)
        else:
            self.getControl(723).setVisible(False)
            self.getControl(722).setText("Keine Sicherung gefunden.\n\nUnter ERWEITERTE EINSTELLUNGEN kann eine Sicherung erstellt werden.")
            self.setFocusId(724)

    def evil_selected(self):
        position = self.getControl(720).getSelectedPosition()
        if position < 0 or position >= len(self.evil_backups):
            return
        name = os.path.basename(self.evil_backups[position])
        self.getControl(722).setText("Sicherung:\n%s\n\nKodi danach neu starten.\n\nMit WIEDERHERSTELLEN bestätigen." % name)

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 720:
            self.evil_selected()
        elif control_id == 723:
            position = self.getControl(720).getSelectedPosition()
            if 0 <= position < len(self.evil_backups):
                self.evil_result = self.evil_backups[position]
                self.close()
        elif control_id == 724:
            self.close()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilAdvancedWindow(xbmcgui.WindowXML):
    evil_addon_path = ""
    evil_actions = []
    evil_message = ""

    def onInit(self):
        evil_apply_window(self)
        self.evil_actions = []
        self.evil_message = ""
        self.evil_refresh()
        self.evil_focus()

    def evil_refresh(self):
        status = evil_advanced_status()
        self.getControl(700).setText(evil_advanced_text(status))
        major = status.get("kodi") or 0
        if not major:
            mode = "UNBEKANNT"
        elif major >= 21:
            mode = "GUI-CACHE"
        else:
            mode = "XML-CACHE"
        self.getControl(702).setLabel("KODI %s · %s" % (major or "?", mode))
        actions = []
        if status["exists"] and status["valid"] and (status["legacy"] or (status["cache"] and major >= 21)):
            actions.append(("clean", "ALTE TAGS BEREINIGEN", 0))
        if major and major <= 20 and (not status["exists"] or status["valid"]):
            for memory in (128, 256, 512):
                actions.append(("cache", "CACHE %d MB SETZEN" % memory, memory))
            if status["cache"]:
                actions.append(("removecache", "CACHE-BLOCK ENTFERNEN", 0))
        if status["exists"]:
            actions.append(("backup", "SICHERUNG ERSTELLEN", 0))
        if evil_advanced_list_backups():
            actions.append(("restore", "SICHERUNG WIEDERHERSTELLEN", 0))
        if status["exists"]:
            actions.append(("delete", "DATEI LÖSCHEN", 0))
        self.evil_actions = actions
        for index, control_id in enumerate(range(201, 209)):
            control = self.getControl(control_id)
            if index < len(actions):
                control.setLabel(actions[index][1])
                control.setVisible(True)
            else:
                control.setLabel("")
                control.setVisible(False)
        if self.evil_message:
            message = self.evil_message
        elif not status["exists"]:
            message = "Noch keine advancedsettings.xml vorhanden."
        elif not status["valid"]:
            message = "Die Datei ist nicht lesbar. Bitte sichern, wiederherstellen oder löschen."
        else:
            message = "Bereit. Änderungen werden vorher gesichert."
        self.getControl(705).setText(message)

    def evil_focus(self):
        for index in range(len(self.evil_actions)):
            self.setFocusId(201 + index)
            return
        self.setFocusId(209)

    def evil_confirm(self, message, yes_label="JA"):
        return evil_confirm_dialog(
            self.evil_addon_path,
            "ERWEITERTE EINSTELLUNGEN",
            message,
            yes_label=yes_label,
            no_label="ABBRECHEN",
        )

    def evil_run(self, action, value=0):
        if action == "close":
            self.close()
            return
        message = ""
        if action == "clean":
            current = evil_advanced_status()
            text = "Alte Tags aus der advancedsettings.xml entfernen?"
            if current.get("cache") and (current.get("kodi") or 0) >= 21:
                text = "Alte Tags und den Cache-Block entfernen?"
            text += "\n\nDie Datei wird vorher gesichert."
            if not self.evil_confirm(text):
                return
            count, backup, error = evil_advanced_clean()
            if error:
                message = "Bereinigung fehlgeschlagen: %s" % error
            else:
                message = "Alte Tags entfernt: %d." % count
                if backup:
                    message += " Sicherung: %s." % os.path.basename(backup)
        elif action == "cache":
            if not self.evil_confirm("Cache auf %d MB setzen?\n\nDie Datei wird vorher gesichert.\nKodi danach neu starten." % value):
                return
            ok, backup, error = evil_advanced_write_cache(value)
            if not ok:
                message = "Cache konnte nicht gesetzt werden: %s" % error
            else:
                message = "Cache auf %d MB gesetzt. Kodi danach neu starten." % value
                if backup:
                    message += " Sicherung: %s." % os.path.basename(backup)
        elif action == "removecache":
            if not self.evil_confirm("Cache-Block aus der advancedsettings.xml entfernen?\n\nDie Datei wird vorher gesichert.\nKodi danach neu starten."):
                return
            ok, backup, error = evil_advanced_remove_cache()
            if not ok:
                message = "Cache-Block konnte nicht entfernt werden: %s" % error
            else:
                message = "Cache-Block entfernt. Kodi danach neu starten."
                if backup:
                    message += " Sicherung: %s." % os.path.basename(backup)
        elif action == "backup":
            backup = evil_advanced_backup()
            if backup:
                message = "Sicherung erstellt: %s." % os.path.basename(backup)
            else:
                message = "Sicherung fehlgeschlagen."
        elif action == "restore":
            window = EvilAdvancedRestoreWindow("script-itspossible-advanced-restore.xml", self.evil_addon_path, "Default", "1080i")
            window.evil_addon_path = self.evil_addon_path
            window.doModal()
            path = window.evil_result
            del window
            if not path:
                return
            if not self.evil_confirm("Sicherung %s wiederherstellen?\nKodi danach neu starten." % os.path.basename(path)):
                return
            ok, error = evil_advanced_restore(path)
            if not ok:
                message = "Wiederherstellung fehlgeschlagen: %s" % error
            else:
                message = "Advancedsettings wiederhergestellt. Kodi danach neu starten."
        elif action == "delete":
            if not self.evil_confirm("advancedsettings.xml wirklich löschen?\n\nDie Datei wird vorher gesichert.\nKodi danach neu starten."):
                return
            ok, backup, error = evil_advanced_remove()
            if not ok:
                message = "Löschen fehlgeschlagen: %s" % error
            else:
                message = "advancedsettings.xml gelöscht."
                if backup:
                    message += " Sicherung: %s." % os.path.basename(backup)
        self.evil_message = message
        self.evil_refresh()
        self.evil_focus()

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if control_id == 209:
            self.close()
            return
        index = control_id - 201
        if 0 <= index < len(self.evil_actions):
            action, label, value = self.evil_actions[index]
            self.evil_run(action, value)

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()


class EvilMaintenanceWindow(xbmcgui.WindowXML):
    evil_addon_path = ""
    evil_config = {}
    evil_installer = None
    evil_background_edit = False

    def onInit(self):
        evil_apply_window(self)
        self.evil_background_edit = False
        self.evil_refresh_autostart()
        self.evil_refresh_background_tasks()
        self.evil_refresh_background_button()
        self.evil_refresh_ftp_button()
        self.getControl(40).setLabel("Mit HINTERGRUND-AUFGABEN AUSWÄHLEN die ersten fünf Aufgaben markieren.")
        self.setFocusId(201)

    def evil_background_task_ids(self):
        if not isinstance(self.evil_config, dict):
            return []
        tasks = self.evil_config.get("maintenance_autostart")
        if not isinstance(tasks, list):
            return []
        return [task for task in tasks if task in EVIL_BACKGROUND_TASKS]

    def evil_refresh_background_tasks(self):
        selected = set(self.evil_background_task_ids())
        for control_id, task_id in EVIL_BACKGROUND_CONTROLS.items():
            marker = "[x]" if task_id in selected else "[ ]"
            label = EVIL_BACKGROUND_TASKS[task_id]["label"]
            self.getControl(control_id).setLabel("%s %s" % (marker, label))

    def evil_refresh_background_button(self):
        label = "AUSWAHL BEENDEN" if self.evil_background_edit else "HINTERGRUND-AUFGABEN AUSWÄHLEN"
        self.getControl(214).setLabel(label)

    def evil_toggle_background_edit(self):
        self.evil_background_edit = not self.evil_background_edit
        self.evil_refresh_background_button()
        if self.evil_background_edit:
            self.getControl(40).setLabel("AUSWAHLMODUS: Klicke auf die ersten fünf Aufgaben.")
            self.setFocusId(201)
        else:
            self.getControl(40).setLabel("Hintergrund-Auswahl gespeichert.")

    def evil_toggle_background_task(self, control_id):
        task_id = EVIL_BACKGROUND_CONTROLS.get(control_id)
        if task_id is None:
            self.getControl(40).setLabel("Diese Aktion ist nicht für den Hintergrundstart vorgesehen.")
            return
        if not isinstance(self.evil_config, dict):
            self.getControl(40).setLabel("Hintergrundauswahl konnte nicht geändert werden.")
            return
        tasks = self.evil_background_task_ids()
        if task_id in tasks:
            tasks = [item for item in tasks if item != task_id]
            enabled = False
        else:
            tasks.append(task_id)
            enabled = True
        previous = self.evil_config.get("maintenance_autostart", [])
        self.evil_config["maintenance_autostart"] = tasks
        if self.evil_installer is None or not self.evil_installer.save_config(self.evil_config):
            self.evil_config["maintenance_autostart"] = previous
            self.evil_refresh_background_tasks()
            self.getControl(40).setLabel("Hintergrundauswahl konnte nicht gespeichert werden.")
            return
        self.evil_refresh_background_tasks()
        label = EVIL_BACKGROUND_TASKS[task_id]["label"]
        self.getControl(40).setLabel(
            "%s wird %s." % (label, "beim Kodi-Start ausgeführt" if enabled else "nicht mehr automatisch ausgeführt")
        )

    def evil_autostart_enabled(self):
        return (self.evil_config or {}).get("autostart", True) is not False

    def evil_refresh_autostart(self):
        state = "EIN" if self.evil_autostart_enabled() else "AUS"
        self.getControl(213).setLabel("AUTOSTART BEIM KODI-START: %s" % state)

    def evil_refresh_ftp_button(self):
        status = evil_ftp.evil_ftp_status()
        if status["running"]:
            label = "FTP-SERVER: LÄUFT"
        elif status["starting"]:
            label = "FTP-SERVER: STARTET ..."
        else:
            label = "FTP-SERVER ÖFFNEN"
        self.getControl(215).setLabel(label)

    def evil_toggle_autostart(self):
        if not isinstance(self.evil_config, dict):
            self.getControl(40).setLabel("Autostart konnte nicht geändert werden.")
            return
        previous = self.evil_autostart_enabled()
        self.evil_config["autostart"] = not previous
        if self.evil_installer is None or not self.evil_installer.save_config(self.evil_config):
            self.evil_config["autostart"] = previous
            self.evil_refresh_autostart()
            self.getControl(40).setLabel("Autostart konnte nicht gespeichert werden.")
            return
        self.evil_refresh_autostart()
        self.getControl(40).setLabel(
            "Autostart beim Kodi-Start ist jetzt %s." % ("EIN" if not previous else "AUS")
        )

    def evil_run(self, title, action):
        if not xbmcgui.Dialog().yesno(EVIL_TITLE, "%s?" % title):
            return
        count = action()
        self.getControl(40).setLabel("%s: %d Einträge entfernt." % (title, count))

    def evil_restart_now(self):
        android = xbmc.getCondVisibility("System.Platform.Android")
        windows = xbmc.getCondVisibility("System.Platform.Windows")
        message = "Kodi jetzt neu starten?"
        if android:
            message += (
                "\n\nAuf Android wird Kodi dafür hart geschlossen und anschließend neu gestartet. "
                "Falls Android den automatischen Start blockiert, öffne Kodi bitte manuell."
            )
        elif windows:
            message += (
                "\n\nKodi wird dafür beendet und anschließend automatisch neu gestartet. "
                "Falls Windows den Start blockiert, öffne Kodi bitte manuell."
            )
        if not xbmcgui.Dialog().yesno(EVIL_TITLE, message):
            return
        xbmcgui.Dialog().notification(EVIL_TITLE, "Kodi wird neu gestartet ...", xbmcgui.NOTIFICATION_INFO, 3000)
        evil_restart_kodi()
        xbmc.sleep(700)
        evil_force_close()

    def evil_clean(self):
        if not xbmcgui.Dialog().yesno(EVIL_TITLE, "Videodatenbank jetzt bereinigen?"):
            return
        self.getControl(40).setLabel("Datenbank wird bereinigt ...")
        xbmc.sleep(50)
        if evil_clean_databases():
            self.getControl(40).setLabel("Datenbank bereinigt.")
        else:
            self.getControl(40).setLabel("Datenbank-Bereinigung fehlgeschlagen.")

    def evil_textures(self):
        message = "Thumbnails und Texturen-Datenbank löschen?\nKodi danach neu starten."
        if not xbmcgui.Dialog().yesno(EVIL_TITLE, message):
            return
        count = evil_reset_textures()
        self.getControl(40).setLabel("Texturen entfernt: %d." % count)
        self.evil_restart_now()

    def evil_show_log(self):
        window = EvilLogWindow("script-itspossible-log.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_text = evil_read_log()
        window.doModal()
        del window

    def evil_backup(self):
        window = EvilBackupWindow("script-itspossible-backup.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_addon_path = self.evil_addon_path
        window.doModal()
        selected = window.evil_result
        del window
        if selected:
            self.evil_backup_selected(selected)

    def evil_backup_selected(self, selected):
        progress = xbmcgui.DialogProgress()
        progress.create(EVIL_TITLE, "Sichere ausgewählte Einstellungen")
        path = ""
        try:
            path = evil_backup_settings(selected, lambda percent, label="": progress.update(percent, label))
        finally:
            progress.close()
        if path:
            self.getControl(40).setLabel("Gesichert: %s" % os.path.basename(path))
            xbmcgui.Dialog().ok(EVIL_TITLE, "Sicherung erstellt:\n%s" % os.path.basename(path))
        else:
            self.getControl(40).setLabel("Sicherung fehlgeschlagen.")
            xbmcgui.Dialog().ok(EVIL_TITLE, "Sicherung fehlgeschlagen.")

    def evil_restore(self):
        backups = evil_list_backups()
        if not backups:
            xbmcgui.Dialog().ok(EVIL_TITLE, "Keine Sicherung gefunden.")
            return
        labels = [os.path.basename(path) for path in backups]
        index = xbmcgui.Dialog().select("IT'S-POSSIBLE SICHERUNG", labels)
        if index < 0:
            return
        message = "Einstellungen aus %s wiederherstellen?\nKodi danach neu starten." % labels[index]
        if not xbmcgui.Dialog().yesno(EVIL_TITLE, message):
            return
        progress = xbmcgui.DialogProgress()
        progress.create(EVIL_TITLE, "Stelle Einstellungen wieder her")
        count = 0
        try:
            count = evil_restore_settings(backups[index], lambda percent, label="": progress.update(percent, label))
        finally:
            progress.close()
        if count:
            self.getControl(40).setLabel("%d Dateien wiederhergestellt." % count)
            self.evil_restart_now()
        else:
            self.getControl(40).setLabel("Wiederherstellung fehlgeschlagen.")
            xbmcgui.Dialog().ok(EVIL_TITLE, "Wiederherstellung fehlgeschlagen.")

    def evil_enable_addons(self):
        if not xbmcgui.Dialog().yesno(EVIL_TITLE, "Alle installierten, deaktivierten Addons jetzt aktivieren?"):
            return
        self.getControl(40).setLabel("Addons werden aktiviert ...")
        xbmc.sleep(50)
        enabled, failed = evil_enable_disabled_addons()
        if failed:
            self.getControl(40).setLabel("%d Addons aktiviert, %d fehlgeschlagen." % (enabled, len(failed)))
            xbmcgui.Dialog().ok(EVIL_TITLE, "Aktiviert: %d\nFehlgeschlagen: %d\n\n%s" % (enabled, len(failed), "\n".join(failed[:10])))
        else:
            self.getControl(40).setLabel("%d Addons aktiviert." % enabled)
            xbmcgui.Dialog().ok(EVIL_TITLE, "%d installierte Addons aktiviert." % enabled)

    def evil_system(self):
        window = EvilSystemWindow("script-itspossible-system.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_config = self.evil_config
        window.doModal()
        del window

    def evil_ftp(self):
        window = EvilFtpWindow("script-itspossible-ftp.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_addon_path = self.evil_addon_path
        window.doModal()
        del window
        self.evil_refresh_ftp_button()

    def evil_advanced(self):
        window = EvilAdvancedWindow("script-itspossible-advanced.xml", self.evil_addon_path, "Default", "1080i")
        window.evil_addon_path = self.evil_addon_path
        window.doModal()
        del window
        self.getControl(40).setLabel("Erweiterte Einstellungen geschlossen.")

    def onClick(self, control_id):
        if control_id == 999:
            evil_open_settings()
            return
        if self.evil_background_edit and control_id in EVIL_BACKGROUND_CONTROLS:
            self.evil_toggle_background_task(control_id)
            return
        if control_id == 201:
            self.evil_run("Cache leeren", evil_clear_cache)
        elif control_id == 202:
            self.evil_run("Pakete löschen", evil_clear_packages)
        elif control_id == 203:
            self.evil_run("Thumbnails löschen", evil_clear_thumbnails)
        elif control_id == 204:
            self.evil_clean()
        elif control_id == 205:
            self.evil_textures()
        elif control_id == 206:
            self.evil_enable_addons()
        elif control_id == 207:
            self.evil_show_log()
        elif control_id == 208:
            self.evil_system()
        elif control_id == 209:
            self.evil_backup()
        elif control_id == 210:
            self.evil_restore()
        elif control_id == 211:
            self.evil_restart_now()
        elif control_id == 212:
            self.close()
        elif control_id == 213:
            self.evil_toggle_autostart()
        elif control_id == 214:
            self.evil_toggle_background_edit()
        elif control_id == 215:
            self.evil_ftp()
        elif control_id == 216:
            self.evil_advanced()

    def onAction(self, action):
        if action.getId() in EVIL_BACK_ACTIONS:
            self.close()
