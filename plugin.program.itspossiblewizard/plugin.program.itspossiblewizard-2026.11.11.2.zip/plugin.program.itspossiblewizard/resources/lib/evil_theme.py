import json
import os
import shutil
import threading
from urllib.parse import unquote

import xbmc
import xbmcvfs

EVIL_THEME_ASSET = "ipw_theme.bin"
EVIL_THEME_INTERVAL = 0.5
EVIL_THEME_VOLUME = 50
EVIL_THEME_MIN_VOLUME = 25


def evil_theme_log(message, level=xbmc.LOGINFO):
    xbmc.log("[IT'S-POSSIBLE WIZARD] %s" % message, level)


class EvilTheme:
    def __init__(self, addon_path):
        self.evil_source = os.path.join(str(addon_path or ""), "resources", "assets", EVIL_THEME_ASSET)
        self.evil_path = ""
        self.evil_temp = ""
        self.evil_player = None
        self.evil_thread = None
        self.evil_stop_event = threading.Event()
        self.evil_volume = EVIL_THEME_VOLUME
        self.evil_original_volume = None

    def evil_normalized(self, path):
        value = str(path or "").strip()
        if value.startswith("file://"):
            value = unquote(value[7:])
        return os.path.normcase(os.path.normpath(os.path.abspath(value)))

    def evil_is_ours(self, path):
        if not path or not self.evil_path:
            return False
        return self.evil_normalized(path) == self.evil_normalized(self.evil_path)

    def evil_cleanup(self):
        path = self.evil_temp
        self.evil_temp = ""
        self.evil_path = ""
        if not path:
            return
        try:
            if os.path.isfile(path):
                os.remove(path)
        except OSError as error:
            evil_theme_log("Temporäre Theme-Datei nicht entfernbar: %s" % error, xbmc.LOGWARNING)

    def evil_prepare(self):
        if not os.path.isfile(self.evil_source):
            evil_theme_log("Theme-Datei nicht gefunden: %s" % self.evil_source, xbmc.LOGWARNING)
            return False
        try:
            directory = xbmcvfs.translatePath("special://temp/")
            os.makedirs(directory, exist_ok=True)
            target = os.path.join(directory, "ipw_theme_%s.mp3" % os.getpid())
            shutil.copyfile(self.evil_source, target)
        except (OSError, IOError) as error:
            evil_theme_log("Theme-Datei nicht vorbereitbar: %s" % error, xbmc.LOGWARNING)
            self.evil_cleanup()
            return False
        self.evil_temp = target
        self.evil_path = target
        return True


    def evil_system_volume(self):
        request = {
            "jsonrpc": "2.0",
            "id": 667,
            "method": "Application.GetProperties",
            "params": {"properties": ["volume"]},
        }
        try:
            data = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
            value = (data.get("result") or {}).get("volume")
            if value is not None:
                return max(0, min(100, int(value)))
        except Exception as error:
            evil_theme_log("Lautstärke nicht lesbar: %s" % error, xbmc.LOGWARNING)
        return None

    def evil_set_system_volume(self, volume):
        volume = max(0, min(100, int(volume)))
        request = {
            "jsonrpc": "2.0",
            "id": 667,
            "method": "Application.SetVolume",
            "params": {"volume": volume},
        }
        try:
            data = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
            if "error" not in data:
                return True
        except Exception as error:
            evil_theme_log("Lautstärke nicht per JSON-RPC setzbar: %s" % error, xbmc.LOGWARNING)
        try:
            xbmc.executebuiltin("SetVolume(%d)" % volume)
            return True
        except Exception as error:
            evil_theme_log("Lautstärke nicht setzbar: %s" % error, xbmc.LOGWARNING)
            return False

    def evil_set_volume(self, volume):
        self.evil_volume = max(EVIL_THEME_MIN_VOLUME, min(100, int(volume)))
        self.evil_set_system_volume(self.evil_volume)
        return self.evil_volume

    def evil_start(self):
        if self.evil_thread is not None and self.evil_thread.is_alive():
            return
        if not self.evil_prepare():
            return
        try:
            player = xbmc.Player()
        except Exception as error:
            evil_theme_log("Kodi-Player nicht verfügbar: %s" % error, xbmc.LOGWARNING)
            self.evil_cleanup()
            return
        self.evil_player = player
        if self.evil_original_volume is None:
            self.evil_original_volume = self.evil_system_volume()
        self.evil_set_system_volume(self.evil_volume)
        self.evil_stop_event.clear()
        self.evil_thread = threading.Thread(
            target=self.evil_loop,
            args=(player,),
            name="ItsPossibleTheme",
        )
        self.evil_thread.daemon = True
        self.evil_thread.start()

    def evil_loop(self, player):
        failures = 0
        while not self.evil_stop_event.is_set():
            try:
                if not os.path.isfile(self.evil_path):
                    evil_theme_log("Temporäre Theme-Datei ist verschwunden.", xbmc.LOGWARNING)
                    break
                if player.isPlaying():
                    current = player.getPlayingFile()
                    if not self.evil_is_ours(current):
                        break
                    failures = 0
                else:
                    if self.evil_stop_event.is_set():
                        break
                    player.play(self.evil_path)
                    failures = 0
            except Exception as error:
                failures += 1
                if failures >= 3:
                    evil_theme_log("Theme-Datei konnte nicht fortgesetzt werden: %s" % error, xbmc.LOGWARNING)
                    break
            self.evil_stop_event.wait(EVIL_THEME_INTERVAL)

    def evil_stop(self):
        self.evil_stop_event.set()
        thread = self.evil_thread
        self.evil_thread = None
        if thread is not None and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=2)
        player = self.evil_player
        self.evil_player = None
        try:
            if player is not None:
                current = player.getPlayingFile()
                if self.evil_is_ours(current):
                    player.stop()
        except Exception as error:
            evil_theme_log("Theme-Datei konnte nicht beendet werden: %s" % error, xbmc.LOGWARNING)
        finally:
            original = self.evil_original_volume
            self.evil_original_volume = None
            if original is not None:
                self.evil_set_system_volume(original)
            self.evil_cleanup()
