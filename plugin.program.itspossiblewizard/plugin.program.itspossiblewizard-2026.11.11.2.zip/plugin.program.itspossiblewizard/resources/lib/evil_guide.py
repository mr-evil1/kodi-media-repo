import os
import platform
import secrets
import shlex
import shutil
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import xbmc
import xbmcaddon
import xbmcgui

EVIL_GUIDE_ADDON_ID = "plugin.program.itspossiblewizard"
EVIL_GUIDE_PREFIX = "ItsPossibleGuide"
EVIL_GUIDE_WINDOW_ID = 10000
EVIL_GUIDE_TIMEOUT = 1800
EVIL_GUIDE_LOG_PREFIX = "[IT'S-POSSIBLE WIZARD] GUIDE: "


def evil_guide_window():
    return xbmcgui.Window(EVIL_GUIDE_WINDOW_ID)


def evil_guide_get(key):
    return evil_guide_window().getProperty(EVIL_GUIDE_PREFIX + key)


def evil_guide_set(key, value):
    evil_guide_window().setProperty(EVIL_GUIDE_PREFIX + key, str(value))


def evil_guide_clear(key):
    evil_guide_window().clearProperty(EVIL_GUIDE_PREFIX + key)


def evil_guide_log(message, level=xbmc.LOGINFO):
    xbmc.log(EVIL_GUIDE_LOG_PREFIX + message, level)


def evil_guide_file():
    addon = xbmcaddon.Addon(EVIL_GUIDE_ADDON_ID)
    return os.path.join(addon.getAddonInfo("path"), "resources", "guide", "buildbauer.html")


def evil_guide_en_file():
    addon = xbmcaddon.Addon(EVIL_GUIDE_ADDON_ID)
    return os.path.join(addon.getAddonInfo("path"), "resources", "guide", "buildbauer-en.html")


def evil_guide_notify(message, error=False):
    try:
        icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
        xbmcgui.Dialog().notification("IT'S-POSSIBLE ANLEITUNG", message, icon, 5000)
    except Exception:
        pass


class EvilGuideHttpServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class EvilGuideHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, form, *args):
        return

    def evil_send(self, code, body=b"", content_type="text/plain; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        if body:
            self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        token = getattr(self.server, "guide_token", "")
        if path == "/favicon.ico":
            self.evil_send(204)
            return
        guide_path = ""
        if token and path in ("/" + token, "/" + token + "/", "/" + token + "/buildbauer.html"):
            guide_path = getattr(self.server, "guide_path", "")
        elif token and path == "/" + token + "/buildbauer-en.html":
            guide_path = getattr(self.server, "guide_en_path", "")
        if guide_path:
            try:
                with open(guide_path, "rb") as handle:
                    body = handle.read()
            except OSError:
                self.evil_send(404, b"Anleitung nicht gefunden.")
                return
            self.evil_send(200, body, "text/html; charset=utf-8")
            return
        self.evil_send(404, b"Nicht gefunden.")


class EvilGuideServer:
    def __init__(self, guide_path=None):
        self.guide_path = guide_path or evil_guide_file()
        self.guide_en_path = os.path.join(os.path.dirname(self.guide_path), "buildbauer-en.html")
        self.server = None
        self.thread = None
        self.started = 0
        evil_guide_set("Service", "ready")

    def start(self):
        if self.server is not None:
            return True
        if not os.path.isfile(self.guide_path) or not os.path.isfile(self.guide_en_path):
            evil_guide_set("Error", "Anleitung nicht gefunden: %s" % self.guide_path)
            return False
        try:
            token = secrets.token_urlsafe(18)
            server = EvilGuideHttpServer(("127.0.0.1", 0), EvilGuideHandler)
            server.guide_path = self.guide_path
            server.guide_en_path = self.guide_en_path
            server.guide_token = token
            port = server.server_address[1]
            thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.2}, daemon=True)
            thread.start()
            self.server = server
            self.thread = thread
            self.started = time.time()
            evil_guide_set("Url", "http://127.0.0.1:%d/%s/buildbauer.html" % (port, token))
            evil_guide_set("Active", "true")
            evil_guide_set("Error", "")
            evil_guide_log("Anleitung läuft auf Port %d" % port)
            return True
        except Exception as error:
            evil_guide_set("Active", "false")
            evil_guide_set("Error", str(error))
            evil_guide_log("Start fehlgeschlagen: %s" % error, xbmc.LOGERROR)
            return False

    def stop(self):
        server = self.server
        thread = self.thread
        self.server = None
        self.thread = None
        self.started = 0
        if server is not None:
            try:
                server.shutdown()
            except Exception as error:
                evil_guide_log("Shutdown fehlgeschlagen: %s" % error, xbmc.LOGWARNING)
            try:
                server.server_close()
            except Exception:
                pass
        if thread is not None and thread.is_alive() and thread is not threading.current_thread():
            thread.join(3)
        evil_guide_set("Active", "false")
        evil_guide_clear("Url")
        return True

    def process_command(self):
        command = evil_guide_get("Command")
        if not command:
            return
        evil_guide_clear("Command")
        if command == "start":
            self.start()
        elif command == "stop":
            self.stop()

    def cleanup(self):
        if self.started and time.time() - self.started > EVIL_GUIDE_TIMEOUT:
            self.stop()


def evil_guide_platform():
    if xbmc.getCondVisibility("System.Platform.Android"):
        return "android"
    if xbmc.getCondVisibility("System.Platform.Windows"):
        return "windows"
    if xbmc.getCondVisibility("System.Platform.OSX"):
        return "macos"
    if xbmc.getCondVisibility("System.Platform.Linux"):
        return "linux"
    return platform.system().lower()


def evil_guide_setting(key, default=""):
    try:
        value = xbmcaddon.Addon(EVIL_GUIDE_ADDON_ID).getSetting(key)
    except Exception:
        value = ""
    return value or default


def evil_guide_command_available(command):
    return os.path.isfile(command) or shutil.which(command) is not None


def evil_guide_windows_paths(choice):
    roots = [
        os.environ.get("PROGRAMFILES", ""),
        os.environ.get("PROGRAMFILES(X86)", ""),
        os.environ.get("LOCALAPPDATA", ""),
    ]
    relatives = {
        "chrome": [("Google", "Chrome", "Application", "chrome.exe")],
        "firefox": [("Mozilla Firefox", "firefox.exe")],
        "edge": [("Microsoft", "Edge", "Application", "msedge.exe")],
    }
    paths = []
    for root in roots:
        for parts in relatives.get(choice, []):
            if root:
                paths.append(os.path.join(root, *parts))
    return paths


def evil_guide_run(command):
    try:
        subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception as error:
        evil_guide_log("Browserbefehl fehlgeschlagen: %s" % error, xbmc.LOGERROR)
        return False


def evil_guide_android_package(choice):
    packages = {
        "chrome": "com.android.chrome",
        "firefox": "org.mozilla.firefox",
        "edge": "com.microsoft.emmx",
        "samsung": "com.sec.android.app.sbrowser",
    }
    package = packages.get(choice, "")
    if not package:
        return ""
    try:
        output = subprocess.check_output(
            ["/system/bin/pm", "list", "packages"],
            stderr=subprocess.DEVNULL,
            timeout=3,
        ).decode("utf-8", "replace")
        if "package:" + package in output:
            return package
    except Exception:
        return package
    return ""


def evil_guide_open_android(url, choice):
    package = evil_guide_android_package(choice)
    try:
        xbmc.executebuiltin(
            'StartAndroidActivity(%s,android.intent.action.VIEW,text/html,%s)' % (package, url)
        )
        return True
    except Exception as error:
        evil_guide_log("Android-Browser fehlgeschlagen: %s" % error, xbmc.LOGERROR)
        return False


def evil_guide_open_desktop(url, choice):
    system = evil_guide_platform()
    if choice == "custom":
        command = evil_guide_setting("guide_custom_browser", "").strip()
        if not command:
            choice = "auto"
        else:
            parts = shlex.split(command)
            if parts:
                return evil_guide_run(parts + [url])
    if system == "windows":
        if choice == "auto":
            try:
                os.startfile(url)
                return True
            except Exception:
                return False
        for path in evil_guide_windows_paths(choice):
            if os.path.isfile(path):
                return evil_guide_run([path, url])
        names = {
            "chrome": ["chrome.exe", "chrome"],
            "firefox": ["firefox.exe", "firefox"],
            "edge": ["msedge.exe", "msedge"],
        }
        for name in names.get(choice, []):
            if evil_guide_command_available(name):
                return evil_guide_run([name, url])
        return False
    if system == "macos":
        if choice == "auto":
            return evil_guide_run(["open", url])
        apps = {"chrome": "Google Chrome", "firefox": "Firefox", "safari": "Safari", "edge": "Microsoft Edge"}
        app = apps.get(choice)
        return evil_guide_run(["open", "-a", app, url]) if app else evil_guide_run(["open", url])
    if system == "linux":
        if choice == "auto":
            if evil_guide_command_available("xdg-open"):
                return evil_guide_run(["xdg-open", url])
            return evil_guide_run(["python3", "-m", "webbrowser", url])
        names = {
            "chrome": ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser"],
            "firefox": ["firefox"],
            "edge": ["microsoft-edge", "microsoft-edge-stable"],
        }
        for name in names.get(choice, []):
            if evil_guide_command_available(name):
                return evil_guide_run([name, url])
        return False
    return False


def evil_guide_browser_open(url):
    choice = evil_guide_setting("guide_browser", "auto")
    if choice not in ("auto", "chrome", "firefox", "edge", "safari", "samsung", "custom"):
        choice = "auto"
    if evil_guide_platform() == "android":
        if evil_guide_open_android(url, choice):
            return True
        if choice != "auto" and evil_guide_open_android(url, "auto"):
            evil_guide_notify("Gewählter Browser nicht gefunden, Standardbrowser geöffnet.")
            return True
        return False
    return evil_guide_open_desktop(url, choice)


def evil_guide_open():
    url = evil_guide_get("Url")
    if not url:
        evil_guide_set("Command", "start")
        for _index in range(60):
            xbmc.sleep(250)
            url = evil_guide_get("Url")
            if url:
                break
    if not url:
        error = evil_guide_get("Error") or "Der Anleitungsdienst ist noch nicht bereit."
        evil_guide_notify(error, True)
        return False
    if evil_guide_browser_open(url):
        evil_guide_notify("Buildbauer-Anleitung geöffnet.")
        return True
    evil_guide_notify("Kein Browser gefunden. Bitte den Browser in den Einstellungen wählen.", True)
    return False
