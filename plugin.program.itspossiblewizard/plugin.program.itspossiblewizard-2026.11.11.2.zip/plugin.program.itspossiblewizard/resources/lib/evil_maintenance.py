import glob
import json
import os
import re
import shutil
import time
import zipfile
import xml.etree.ElementTree as ElementTree

import xbmc
import xbmcvfs

EVIL_TEMP_DIR = xbmcvfs.translatePath("special://temp/")
EVIL_PACKAGES_DIR = xbmcvfs.translatePath("special://home/addons/packages/")
EVIL_PROFILE_DIR = xbmcvfs.translatePath("special://profile/")
EVIL_THUMBNAILS_DIR = xbmcvfs.translatePath("special://profile/Thumbnails/")
EVIL_DATABASE_DIR = xbmcvfs.translatePath("special://profile/Database/")
EVIL_ADDON_DATA_DIR = xbmcvfs.translatePath("special://profile/addon_data/")
EVIL_GUI_SETTINGS = xbmcvfs.translatePath("special://profile/guisettings.xml")
EVIL_FAVORITES = xbmcvfs.translatePath("special://profile/favourites.xml")
EVIL_SOURCES = xbmcvfs.translatePath("special://profile/sources.xml")
EVIL_ADVANCED_SETTINGS = xbmcvfs.translatePath("special://profile/advancedsettings.xml")
EVIL_PROFILES = xbmcvfs.translatePath("special://profile/profiles.xml")
EVIL_KEYMAPS_DIR = xbmcvfs.translatePath("special://profile/keymaps/")
EVIL_PLAYLISTS_DIR = xbmcvfs.translatePath("special://profile/playlists/")
EVIL_BACKUP_DIR = xbmcvfs.translatePath("special://profile/itspossible_backups/")
EVIL_LEGACY_BACKUP_DIR = xbmcvfs.translatePath("special://profile/evil_backups/")
EVIL_LOG_DIR = xbmcvfs.translatePath("special://logpath/")
EVIL_LOG_LIMIT = 150000

EVIL_BACKUP_OPTIONS = (
    {
        "id": "gui",
        "label": "GUI-EINSTELLUNGEN",
        "description": "Kodi-Oberfläche, Sprach- und Wiedergabeeinstellungen aus guisettings.xml.",
    },
    {
        "id": "addon_data",
        "label": "ADDON-DATEN",
        "description": "Einstellungen, Zugänge und lokale Daten aller installierten Addons.",
    },
    {
        "id": "skin",
        "label": "SKIN-EINSTELLUNGEN",
        "description": "Nur die Einstellungen der Skins und von Skin Shortcuts.",
    },
    {
        "id": "favorites",
        "label": "FAVORITEN",
        "description": "Die Favoriten aus favourites.xml.",
    },
    {
        "id": "sources",
        "label": "DATEIQUELLEN",
        "description": "Die eingebundenen Dateiquellen und Netzwerkfreigaben.",
    },
    {
        "id": "advanced",
        "label": "ERWEITERTE EINSTELLUNGEN",
        "description": "Die advancedsettings.xml mit Puffern, Netzwerk und Feintuning.",
    },
    {
        "id": "keymaps",
        "label": "KEYMAPS",
        "description": "Eigene Tastenbelegungen aus dem keymaps-Ordner.",
    },
    {
        "id": "playlists",
        "label": "PLAYLISTS",
        "description": "Eigene Wiedergabelisten aus dem playlists-Ordner.",
    },
    {
        "id": "profiles",
        "label": "PROFILE",
        "description": "Kodi-Profile und deren Zuordnung aus profiles.xml.",
    },
    {
        "id": "databases",
        "label": "DATENBANKEN",
        "description": "Filme, Serien, Musik und Texturen. Kann groß werden; Kodi am besten vorher beenden.",
    },
)


def evil_log(message, level=xbmc.LOGINFO):
    xbmc.log("[IT'S-POSSIBLE WIZARD] %s" % message, level)


def evil_clear_folder(path, skip_suffixes=()):
    removed = 0
    if not os.path.isdir(path):
        return removed
    for name in os.listdir(path):
        if name.lower().endswith(skip_suffixes):
            continue
        target = os.path.join(path, name)
        try:
            if os.path.isdir(target):
                shutil.rmtree(target, ignore_errors=True)
            else:
                os.remove(target)
            removed += 1
        except OSError as error:
            evil_log("Konnte %s nicht entfernen: %s" % (target, error), xbmc.LOGWARNING)
    return removed


def evil_clear_cache():
    return evil_clear_folder(EVIL_TEMP_DIR, (".log", ".old"))


def evil_clear_packages():
    return evil_clear_folder(EVIL_PACKAGES_DIR)


def evil_clear_thumbnails():
    return evil_clear_folder(EVIL_THUMBNAILS_DIR)


def evil_rpc(method, params=None):
    request = {"jsonrpc": "2.0", "id": 666, "method": method}
    if params is not None:
        request["params"] = params
    response = xbmc.executeJSONRPC(json.dumps(request))
    try:
        data = json.loads(response)
    except ValueError:
        return None
    return data.get("result")


def evil_clean_databases():
    video = evil_rpc("VideoLibrary.Clean")
    music = evil_rpc("AudioLibrary.Clean")
    return video == "OK" and music == "OK"


def evil_reset_textures():
    removed = evil_clear_folder(EVIL_THUMBNAILS_DIR)
    patterns = ("Textures*.db", "Textures*.db-journal", "Textures*.db-wal", "Textures*.db-shm")
    for pattern in patterns:
        for path in glob.glob(os.path.join(EVIL_DATABASE_DIR, pattern)):
            try:
                os.remove(path)
                removed += 1
            except OSError as error:
                evil_log("Konnte %s nicht entfernen: %s" % (path, error), xbmc.LOGWARNING)
    return removed


def evil_read_log(limit=EVIL_LOG_LIMIT):
    path = os.path.join(EVIL_LOG_DIR, "kodi.log")
    try:
        with open(path, "rb") as handle:
            handle.seek(0, os.SEEK_END)
            size = handle.tell()
            handle.seek(max(0, size - limit))
            data = handle.read()
    except OSError as error:
        evil_log("Log konnte nicht gelesen werden: %s" % error, xbmc.LOGWARNING)
        return "Log nicht lesbar: %s" % error
    text = data.decode("utf-8", "ignore")
    return text or "Log ist leer."


def evil_walk_files(path):
    if os.path.isfile(path):
        return [path]
    if not os.path.isdir(path):
        return []
    files = []
    for root, folders, names in os.walk(path):
        folders[:] = [folder for folder in folders if folder != "__pycache__"]
        for name in names:
            files.append(os.path.join(root, name))
    return files


def evil_backup_category_files(category):
    if category == "gui":
        return evil_walk_files(EVIL_GUI_SETTINGS)
    if category == "addon_data":
        return evil_walk_files(EVIL_ADDON_DATA_DIR)
    if category == "skin":
        files = []
        for pattern in ("skin.*", "script.skinshortcuts"):
            for path in glob.glob(os.path.join(EVIL_ADDON_DATA_DIR, pattern)):
                files.extend(evil_walk_files(path))
        return files
    if category == "favorites":
        return evil_walk_files(EVIL_FAVORITES)
    if category == "sources":
        return evil_walk_files(EVIL_SOURCES)
    if category == "advanced":
        return evil_walk_files(EVIL_ADVANCED_SETTINGS)
    if category == "keymaps":
        return evil_walk_files(EVIL_KEYMAPS_DIR)
    if category == "playlists":
        return evil_walk_files(EVIL_PLAYLISTS_DIR)
    if category == "profiles":
        return evil_walk_files(EVIL_PROFILES)
    if category == "databases":
        return evil_walk_files(EVIL_DATABASE_DIR)
    return []


def evil_backup_files(selected):
    files = []
    seen = set()
    for option in EVIL_BACKUP_OPTIONS:
        if option["id"] not in selected:
            continue
        for path in evil_backup_category_files(option["id"]):
            key = os.path.normcase(os.path.abspath(path))
            if key in seen:
                continue
            seen.add(key)
            files.append(path)
    return files


def evil_backup_settings(selected=None, progress=None):
    if callable(selected) and progress is None:
        progress = selected
        selected = None
    if selected is None:
        selected = ("gui", "addon_data")
    if isinstance(selected, str):
        selected = (selected,)
    selected = set(selected)
    files = evil_backup_files(selected)
    if not files:
        return ""
    try:
        os.makedirs(EVIL_BACKUP_DIR, exist_ok=True)
    except OSError as error:
        evil_log("Sicherungsordner konnte nicht angelegt werden: %s" % error, xbmc.LOGERROR)
        return ""
    stamp = time.strftime("%Y%m%d-%H%M%S")
    base = os.path.join(EVIL_BACKUP_DIR, "itspossible-einstellungen-%s" % stamp)
    target = "%s.zip" % base
    counter = 1
    while os.path.exists(target):
        target = "%s-%d.zip" % (base, counter)
        counter += 1
    total = len(files)
    try:
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
            for index, path in enumerate(files):
                arcname = os.path.relpath(path, EVIL_PROFILE_DIR).replace(os.sep, "/")
                try:
                    archive.write(path, arcname)
                except OSError as error:
                    evil_log("Datei nicht gesichert: %s (%s)" % (path, error), xbmc.LOGWARNING)
                    continue
                if progress is not None:
                    progress(int((index + 1) * 100 / total), os.path.basename(path))
    except OSError as error:
        evil_log("Sicherung fehlgeschlagen: %s" % error, xbmc.LOGERROR)
        try:
            os.remove(target)
        except OSError:
            pass
        return ""
    return target


def evil_list_backups():
    items = []
    for folder in (EVIL_BACKUP_DIR, EVIL_LEGACY_BACKUP_DIR):
        if not os.path.isdir(folder):
            continue
        items.extend(os.path.join(folder, name) for name in os.listdir(folder) if name.endswith(".zip"))
    return sorted(items, reverse=True)


def evil_human_size(value):
    size = float(value or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            if unit == "B":
                return "%d B" % int(size)
            return "%.1f %s" % (size, unit)
        size /= 1024


def evil_info_label(label):
    value = xbmc.getInfoLabel(label)
    text = str(value).strip() if value else ""
    return text or "unbekannt"


def evil_info_size(label):
    text = evil_info_label(label)
    match = re.match(r"([0-9]+(?:\.[0-9]+)?)\s*([KMGTP]?B)", text, re.I)
    if not match:
        return text
    number = float(match.group(1))
    unit = match.group(2).upper()
    factor = {"B": 1, "KB": 1024, "MB": 1024 ** 2, "GB": 1024 ** 3, "TB": 1024 ** 4}.get(unit, 1)
    return evil_human_size(number * factor)


def evil_error_summary(limit=3):
    text = evil_read_log()
    blocks = re.findall(
        r"-->Python callback/script returned the following error<--(.*?)-->End of Python script error report<--",
        text,
        re.S,
    )
    snippets = []
    for block in blocks[-limit:]:
        line = re.sub(r"\s+", " ", block).strip()
        if line:
            snippets.append(line[:240])
    return len(blocks), snippets


def evil_system_text(config=None):
    settings = config or {}
    build = settings.get("installed_build") or settings.get("build") or {}
    error_count, errors = evil_error_summary(2)
    build_name = build.get("name") or "keiner"
    if build.get("version"):
        build_name += " v%s" % build["version"]
    lines = [
        "IT'S-POSSIBLE SYSTEM",
        "",
        "Kodi: %s" % evil_info_label("System.BuildVersion"),
        "Gerät: %s" % evil_info_label("System.FriendlyName"),
        "System: %s" % evil_info_label("System.OSVersionInfo"),
        "Auflösung: %s" % evil_info_label("System.ScreenMode"),
        "CPU: %s" % evil_info_label("System.CpuUsage"),
        "",
        "Arbeitsspeicher frei: %s" % evil_info_size("System.Memory(free)"),
        "Arbeitsspeicher belegt: %s" % evil_info_size("System.Memory(used)"),
        "Arbeitsspeicher gesamt: %s" % evil_info_size("System.Memory(total)"),
        "Speicher frei: %s" % evil_info_size("System.FreeSpace"),
        "Speicher belegt: %s" % evil_info_size("System.UsedSpace"),
        "Speicher gesamt: %s" % evil_info_size("System.TotalSpace"),
        "",
        "IP-Adresse: %s" % evil_info_label("Network.IPAddress"),
        "MAC-Adresse: %s" % evil_info_label("Network.MacAddress"),
        "Netzwerk: %s" % evil_info_label("Network.LinkStatus"),
        "Laufzeit: %s" % evil_info_label("System.Uptime"),
        "Gesamtlaufzeit: %s" % evil_info_label("System.TotalUptime"),
        "",
        "Installierter Build: %s" % build_name,
        "Python-Fehler im Log: %d" % error_count,
    ]
    for error in errors:
        lines.append("  %s" % error)
    return "\n".join(lines)


def evil_enable_disabled_addons():
    result = evil_rpc("Addons.GetAddons", {"enabled": False, "installed": True, "properties": ["name"]})
    if not isinstance(result, dict):
        return 0, ["Addon-Liste nicht lesbar"]
    addons = result.get("addons") or []
    if not isinstance(addons, list):
        return 0, ["Addon-Liste nicht lesbar"]
    enabled = 0
    failed = []
    for addon in addons:
        if not isinstance(addon, dict):
            continue
        addon_id = addon.get("addonid") or ""
        if not addon_id:
            continue
        answer = evil_rpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})
        if answer == "OK":
            enabled += 1
        else:
            failed.append(addon.get("name") or addon_id)
    if enabled:
        xbmc.executebuiltin("UpdateLocalAddons")
    return enabled, failed


def evil_restore_settings(path, progress=None, only=None, exclude=None):
    if not os.path.isfile(path):
        return 0
    base = os.path.normpath(EVIL_PROFILE_DIR)
    allowed_files = {
        "guisettings.xml",
        "favourites.xml",
        "sources.xml",
        "advancedsettings.xml",
        "profiles.xml",
    }
    allowed_dirs = ("addon_data/", "keymaps/", "playlists/", "Database/")
    only_prefixes = tuple(
        prefix if prefix.endswith("/") else prefix + "/"
        for prefix in (only or ())
    )
    exclude_prefixes = tuple(
        prefix if prefix.endswith("/") else prefix + "/"
        for prefix in (exclude or ())
    )
    restored = 0
    try:
        with zipfile.ZipFile(path) as archive:
            members = [member for member in archive.infolist() if not member.is_dir()]
            total = max(len(members), 1)
            for index, member in enumerate(members):
                name = member.filename.replace("\\", "/")
                if name not in allowed_files and not any(name.startswith(prefix) for prefix in allowed_dirs):
                    continue
                if only_prefixes and not any(name.startswith(prefix) for prefix in only_prefixes):
                    continue
                if exclude_prefixes and any(name.startswith(prefix) for prefix in exclude_prefixes):
                    continue
                if name.startswith("/") or "../" in name or name == "..":
                    continue
                target = os.path.normpath(os.path.join(base, name))
                if not target.startswith(base + os.sep):
                    continue
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with archive.open(member) as source, open(target, "wb") as destination:
                    shutil.copyfileobj(source, destination)
                restored += 1
                if progress is not None:
                    progress(int((index + 1) * 100 / total), os.path.basename(name))
    except (OSError, zipfile.BadZipFile) as error:
        evil_log("Wiederherstellung fehlgeschlagen: %s" % error, xbmc.LOGERROR)
        return 0
    return restored


def evil_restore_addon_data(path, progress=None):
    return evil_restore_settings(
        path,
        progress,
        only=("addon_data",),
        exclude=("addon_data/plugin.program.itspossiblewizard", "addon_data/plugin.program.evilwizard"),
    )


EVIL_BACKGROUND_TASKS = {
    "cache": {"label": "CACHE LEEREN", "run": evil_clear_cache},
    "packages": {"label": "PAKETE LÖSCHEN", "run": evil_clear_packages},
    "thumbnails": {"label": "THUMBNAILS LÖSCHEN", "run": evil_clear_thumbnails},
    "database": {"label": "DATENBANK BEREINIGEN", "run": evil_clean_databases},
    "textures": {"label": "TEXTUREN-DATENBANK", "run": evil_reset_textures},
}


EVIL_ADVANCED_NETWORK_TAGS = ("buffermode", "cachemembuffersize", "readbufferfactor")
EVIL_ADVANCED_VIDEO_TAGS = (
    "stagefright",
    "mediacodec",
    "vdpauscaling",
    "enablehighqualityhwscalers",
    "dxvaallowhqscaling",
    "checkdxvacompatibility",
    "skiploopfilter",
)


def evil_advanced_major():
    raw = xbmc.getInfoLabel("System.BuildVersion") or ""
    match = re.match(r"\s*(\d+)", raw)
    return int(match.group(1)) if match else 0


def evil_advanced_backup():
    if not os.path.isfile(EVIL_ADVANCED_SETTINGS):
        return ""
    try:
        os.makedirs(EVIL_BACKUP_DIR, exist_ok=True)
    except OSError as error:
        evil_log("Sicherungsordner konnte nicht angelegt werden: %s" % error, xbmc.LOGERROR)
        return ""
    stamp = time.strftime("%Y%m%d-%H%M%S")
    target = os.path.join(EVIL_BACKUP_DIR, "advancedsettings-%s.xml" % stamp)
    counter = 1
    while os.path.exists(target):
        target = os.path.join(EVIL_BACKUP_DIR, "advancedsettings-%s-%d.xml" % (stamp, counter))
        counter += 1
    try:
        shutil.copy2(EVIL_ADVANCED_SETTINGS, target)
        return target
    except OSError as error:
        evil_log("advancedsettings.xml nicht sicherbar: %s" % error, xbmc.LOGWARNING)
        return ""


def evil_advanced_list_backups():
    if not os.path.isdir(EVIL_BACKUP_DIR):
        return []
    return sorted(
        (os.path.join(EVIL_BACKUP_DIR, name) for name in os.listdir(EVIL_BACKUP_DIR) if name.startswith("advancedsettings-") and name.endswith(".xml")),
        reverse=True,
    )


def evil_advanced_root():
    if not os.path.isfile(EVIL_ADVANCED_SETTINGS):
        return None, "Datei nicht vorhanden"
    try:
        return ElementTree.parse(EVIL_ADVANCED_SETTINGS).getroot(), ""
    except (OSError, ElementTree.ParseError) as error:
        return None, str(error)


def evil_advanced_write_root(root):
    temporary = EVIL_ADVANCED_SETTINGS + ".tmp"
    try:
        ElementTree.ElementTree(root).write(temporary, encoding="utf-8", xml_declaration=True)
        os.replace(temporary, EVIL_ADVANCED_SETTINGS)
        return True
    except (OSError, ElementTree.ParseError) as error:
        evil_log("advancedsettings.xml nicht schreibbar: %s" % error, xbmc.LOGWARNING)
        try:
            if os.path.isfile(temporary):
                os.remove(temporary)
        except OSError:
            pass
        return False


def evil_advanced_status():
    root, error = evil_advanced_root()
    legacy = []
    cache = False
    valid = root is not None
    if root is not None:
        cache = root.find("cache") is not None
        network = root.find("network")
        if network is not None:
            legacy.extend(tag for tag in EVIL_ADVANCED_NETWORK_TAGS if network.find(tag) is not None)
        video = root.find("video")
        if video is not None:
            legacy.extend(tag for tag in EVIL_ADVANCED_VIDEO_TAGS if video.find(tag) is not None)
    return {
        "path": EVIL_ADVANCED_SETTINGS,
        "exists": os.path.isfile(EVIL_ADVANCED_SETTINGS),
        "size": os.path.getsize(EVIL_ADVANCED_SETTINGS) if os.path.isfile(EVIL_ADVANCED_SETTINGS) else 0,
        "valid": valid,
        "error": error,
        "cache": cache,
        "legacy": legacy,
        "kodi": evil_advanced_major(),
    }


def evil_advanced_text(status):
    major = status.get("kodi") or 0
    if not major:
        mode = "unbekannt"
    elif major >= 21:
        mode = "GUI-Cache ab Kodi 21"
    else:
        mode = "Cache per advancedsettings.xml"
    lines = [
        "Kodi: %s" % (major or "unbekannt"),
        "Modus: %s" % mode,
        "Datei: %s" % status.get("path", EVIL_ADVANCED_SETTINGS),
    ]
    if not status.get("exists"):
        lines.extend(["", "Status: noch nicht vorhanden.", "Es werden keine fertigen XML-Presets aus alten Kodi-Versionen übernommen."])
    elif not status.get("valid"):
        lines.extend(["", "Status: XML ist nicht lesbar.", "Fehler: %s" % status.get("error", "")])
    else:
        lines.extend(["", "Status: vorhanden, %.1f KB." % (float(status.get("size") or 0) / 1024.0)])
        lines.append("Cache-Block: %s" % ("vorhanden" if status.get("cache") else "nicht vorhanden"))
    if status.get("legacy"):
        lines.extend(["", "Überholte Tags:", ", ".join(status["legacy"])])
    else:
        lines.extend(["", "Überholte Tags: keine erkannt."])
    lines.extend(["", "Empfehlung:"])
    if not major:
        lines.extend(["Die Kodi-Version konnte nicht erkannt werden.", "Es werden keine Cache-Änderungen angeboten."])
    elif major >= 21:
        lines.extend(["Cache unter Einstellungen > Services > Caching ändern.", "Cache-Tags in der Datei werden von Kodi 21/22 ignoriert."])
    else:
        lines.extend(["Nur bei Bedarf einen kleinen Cache setzen.", "Alte Netzwerk- und Video-Tags bereinigen.", "Werte nicht ungeprüft von alten Presets übernehmen."])
    return "\n".join(lines)


def evil_advanced_clean():
    backup = evil_advanced_backup()
    if os.path.isfile(EVIL_ADVANCED_SETTINGS) and not backup:
        return 0, "", "Sicherung fehlgeschlagen"
    root, error = evil_advanced_root()
    if root is None:
        return 0, backup, error
    removed = 0
    if evil_advanced_major() >= 21:
        for node in root.findall("cache"):
            root.remove(node)
            removed += 1
    network = root.find("network")
    if network is not None:
        for tag in EVIL_ADVANCED_NETWORK_TAGS:
            for node in network.findall(tag):
                network.remove(node)
                removed += 1
    video = root.find("video")
    if video is not None:
        for tag in EVIL_ADVANCED_VIDEO_TAGS:
            for node in video.findall(tag):
                video.remove(node)
                removed += 1
    if removed and not evil_advanced_write_root(root):
        return 0, backup, "Datei konnte nicht geschrieben werden"
    return removed, backup, ""


def evil_advanced_write_cache(memory_mb=128, buffermode=1, readfactor=4):
    major = evil_advanced_major()
    if major >= 21:
        return False, "", "Kodi 21/22 ignoriert Cache-Tags. Bitte Einstellungen > Services > Caching verwenden."
    backup = evil_advanced_backup()
    if os.path.isfile(EVIL_ADVANCED_SETTINGS) and not backup:
        return False, "", "Sicherung fehlgeschlagen"
    root, error = evil_advanced_root()
    if root is None and error != "Datei nicht vorhanden":
        return False, backup, "Die vorhandene Datei ist kein gültiges XML: %s" % error
    if root is None:
        root = ElementTree.Element("advancedsettings", {"version": "1.0"})
    if root.tag != "advancedsettings":
        return False, backup, "Die Datei hat nicht das Root-Element advancedsettings."
    for node in root.findall("cache"):
        root.remove(node)
    cache = ElementTree.SubElement(root, "cache")
    ElementTree.SubElement(cache, "buffermode").text = str(int(buffermode))
    ElementTree.SubElement(cache, "memorysize").text = str(max(16, min(1024, int(memory_mb))) * 1024 * 1024)
    ElementTree.SubElement(cache, "readfactor").text = str(readfactor)
    if not evil_advanced_write_root(root):
        return False, backup, "Datei konnte nicht geschrieben werden"
    return True, backup, ""


def evil_advanced_remove_cache():
    backup = evil_advanced_backup()
    if os.path.isfile(EVIL_ADVANCED_SETTINGS) and not backup:
        return False, "", "Sicherung fehlgeschlagen"
    root, error = evil_advanced_root()
    if root is None:
        return False, backup, error
    nodes = root.findall("cache")
    if nodes:
        for node in nodes:
            root.remove(node)
        if not evil_advanced_write_root(root):
            return False, backup, "Datei konnte nicht geschrieben werden"
    return True, backup, ""


def evil_advanced_remove():
    backup = evil_advanced_backup()
    if os.path.isfile(EVIL_ADVANCED_SETTINGS) and not backup:
        return False, "", "Sicherung fehlgeschlagen"
    try:
        if os.path.isfile(EVIL_ADVANCED_SETTINGS):
            os.remove(EVIL_ADVANCED_SETTINGS)
        return True, backup, ""
    except OSError as error:
        return False, backup, str(error)


def evil_advanced_restore(path):
    if not os.path.isfile(path):
        return False, "Sicherung nicht gefunden"
    if os.path.isfile(EVIL_ADVANCED_SETTINGS) and not evil_advanced_backup():
        return False, "Sicherung der aktuellen Datei fehlgeschlagen"
    try:
        os.makedirs(os.path.dirname(EVIL_ADVANCED_SETTINGS), exist_ok=True)
        shutil.copy2(path, EVIL_ADVANCED_SETTINGS)
        return True, ""
    except OSError as error:
        return False, str(error)
