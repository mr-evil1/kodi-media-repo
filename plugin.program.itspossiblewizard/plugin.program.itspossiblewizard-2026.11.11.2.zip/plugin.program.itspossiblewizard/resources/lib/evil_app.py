import xbmcgui

from evil_appearance import evil_apply_skin
from evil_installer import EvilInstaller, evil_manual_build_installed
from evil_theme import EvilTheme
from evil_window import EvilBackupWindow, EvilBuildWindow, EvilMainWindow

EVIL_TITLE = "IT'S-POSSIBLE WIZARD"


class EvilApp:
    def __init__(self, autostart=False):
        self.evil_installer = EvilInstaller()
        self.evil_path = self.evil_installer.evil_path
        self.evil_config = self.evil_installer.load_config()
        evil_apply_skin(self.evil_config)
        self.evil_autostart = bool(autostart)
        self.evil_theme = EvilTheme(self.evil_path)

    def evil_choose_backup(self):
        window = EvilBackupWindow("script-itspossible-backup.xml", self.evil_path, "Default", "1080i")
        window.evil_mode = "build"
        window.evil_addon_path = self.evil_path
        window.doModal()
        selected = window.evil_result
        del window
        return selected

    def evil_open_build(self, backup_selected):
        window = EvilBuildWindow("script-itspossible-build.xml", self.evil_path, "Default", "1080i")
        window.evil_config = self.evil_config
        window.evil_installer = self.evil_installer
        window.evil_addon_path = self.evil_path
        window.evil_backup_selected = backup_selected
        window.doModal()
        del window

    def run(self):
        if self.evil_config is None:
            xbmcgui.Dialog().ok(EVIL_TITLE, "itspossible.json konnte weder im Userdata-Ordner noch im Addon gelesen werden.")
            return
        try:
            startup_backup = None
            if (
                self.evil_autostart
                and not self.evil_config.get("installed_build")
                and not evil_manual_build_installed()
            ):
                question = (
                    "Es ist noch kein Build installiert.\n\n"
                    "Möchtest du jetzt einen Build installieren?\n\n"
                    "Bei Ja wählst du zuerst, was gesichert werden soll."
                )
                if not xbmcgui.Dialog().yesno(EVIL_TITLE, question):
                    return
                self.evil_theme.evil_start()
                startup_backup = self.evil_choose_backup()
            if startup_backup:
                self.evil_open_build(startup_backup)
            window = EvilMainWindow("script-itspossible-main.xml", self.evil_path, "Default", "1080i")
            window.evil_config = self.evil_config
            window.evil_installer = self.evil_installer
            window.evil_addon_path = self.evil_path
            window.evil_theme = self.evil_theme
            self.evil_theme.evil_start()
            window.doModal()
            del window
        finally:
            self.evil_theme.evil_stop()
