import os
import socket
import threading

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

EVIL_FTP_ADDON_ID = "plugin.program.itspossiblewizard"
EVIL_FTP_PROPERTY_PREFIX = "ItsPossibleFtp"
EVIL_FTP_WINDOW_ID = 10000
EVIL_FTP_DEFAULT_PORT = 2121
EVIL_FTP_FALLBACK_PORTS = (2100, 21212, 21000, 21210)
EVIL_FTP_LOG_PREFIX = "[IT'S-POSSIBLE WIZARD] FTP: "


def evil_ftp_window():
    return xbmcgui.Window(EVIL_FTP_WINDOW_ID)


def evil_ftp_get(key):
    return evil_ftp_window().getProperty(EVIL_FTP_PROPERTY_PREFIX + key)


def evil_ftp_set(key, value):
    evil_ftp_window().setProperty(EVIL_FTP_PROPERTY_PREFIX + key, str(value))


def evil_ftp_clear(key):
    evil_ftp_window().clearProperty(EVIL_FTP_PROPERTY_PREFIX + key)


def evil_ftp_log(message, level=xbmc.LOGINFO):
    xbmc.log(EVIL_FTP_LOG_PREFIX + message, level)


def evil_ftp_setting_bool(addon, key, default=False):
    try:
        value = addon.getSetting(key)
    except Exception:
        value = ""
    if value in (None, ""):
        return default
    return str(value).strip().lower() == "true"


def evil_ftp_setting_text(addon, key, default=""):
    try:
        value = addon.getSetting(key)
    except Exception:
        value = ""
    if value in (None, ""):
        return default
    return str(value)


def evil_ftp_settings():
    addon = xbmcaddon.Addon(EVIL_FTP_ADDON_ID)
    try:
        port = int(evil_ftp_setting_text(addon, "ftp_port", str(EVIL_FTP_DEFAULT_PORT)))
    except (TypeError, ValueError):
        port = EVIL_FTP_DEFAULT_PORT
    if port < 1024 or port > 65535:
        port = EVIL_FTP_DEFAULT_PORT
    return {
        "autostart": evil_ftp_setting_bool(addon, "ftp_autostart", False),
        "localhost_only": evil_ftp_setting_bool(addon, "ftp_localhost_only", False),
        "port": port,
        "anonymous": evil_ftp_setting_bool(addon, "ftp_anonymous", False),
        "user": evil_ftp_setting_text(addon, "ftp_user", "kodi"),
        "password": evil_ftp_setting_text(addon, "ftp_password", "kodi"),
        "root": evil_ftp_setting_text(addon, "ftp_root", "special://home"),
    }


def evil_ftp_status():
    service = evil_ftp_get("Service") == "ready"
    running = evil_ftp_get("Running") == "true"
    starting = evil_ftp_get("Starting") == "true"
    return {
        "service": service,
        "running": running,
        "starting": starting,
        "port": evil_ftp_get("Port"),
        "root": evil_ftp_get("Root"),
        "address": evil_ftp_get("Address"),
        "auth": evil_ftp_get("Auth"),
        "error": evil_ftp_get("Error"),
        "local": evil_ftp_get("Local") == "true",
    }


def evil_ftp_send_command(command):
    evil_ftp_set("Command", command)


def evil_ftp_prepare_root(value):
    path = value or "special://home"
    try:
        path = xbmcvfs.translatePath(path)
    except Exception:
        path = value
    path = os.path.normpath(path)
    if not os.path.isdir(path):
        os.makedirs(path)
    if not os.path.isdir(path):
        raise RuntimeError("FTP-Ordner ist nicht erreichbar: %s" % path)
    return path


def evil_ftp_local_ip():
    label = xbmc.getInfoLabel("Network.IPAddress")
    if label and "." in label and not label.startswith("127."):
        return label
    probe = None
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(("8.8.8.8", 80))
        address = probe.getsockname()[0]
        if address and not address.startswith("127."):
            return address
    except Exception:
        pass
    finally:
        if probe is not None:
            try:
                probe.close()
            except Exception:
                pass
    return "127.0.0.1"


def evil_ftp_root_permissions(path):
    try:
        writable = os.access(path, os.W_OK)
    except Exception:
        writable = False
    return "elradfmwMT" if writable else "elr"


class EvilFtpController:
    def __init__(self):
        self.server = None
        self.thread = None
        self.lock = threading.RLock()

    def start(self, settings=None):
        with self.lock:
            if self.server is not None:
                return True
            evil_ftp_set("Starting", "true")
            evil_ftp_set("Error", "")
            try:
                settings = settings or evil_ftp_settings()
                root = evil_ftp_prepare_root(settings.get("root"))
                from pyftpdlib.authorizers import DummyAuthorizer
                from pyftpdlib.handlers import FTPHandler
                from pyftpdlib.servers import FTPServer

                authorizer = DummyAuthorizer()
                permissions = evil_ftp_root_permissions(root)
                if settings.get("anonymous"):
                    authorizer.add_anonymous(root, perm=permissions)
                    auth_label = "Anonym"
                else:
                    user = settings.get("user") or "kodi"
                    password = settings.get("password") or ""
                    authorizer.add_user(user, password, root, perm=permissions)
                    auth_label = "Benutzer: %s" % user

                handler = FTPHandler
                handler.authorizer = authorizer
                handler.permit_foreign_addresses = True
                handler.banner = "IT'S-POSSIBLE FTP-SERVER"

                bind_address = "127.0.0.1" if settings.get("localhost_only") else "0.0.0.0"
                candidates = [settings.get("port") or EVIL_FTP_DEFAULT_PORT]
                for port in EVIL_FTP_FALLBACK_PORTS:
                    if port not in candidates:
                        candidates.append(port)
                server = None
                selected_port = 0
                for port in candidates:
                    try:
                        server = FTPServer((bind_address, port), handler)
                        selected_port = port
                        break
                    except Exception as error:
                        evil_ftp_log("Port %s nicht verfügbar: %s" % (port, error), xbmc.LOGWARNING)

                if server is None:
                    raise RuntimeError("Kein freier FTP-Port gefunden")

                self.server = server
                self.thread = threading.Thread(target=self._serve, args=(server,), daemon=True)
                self.thread.start()
                address = "127.0.0.1" if settings.get("localhost_only") else evil_ftp_local_ip()
                evil_ftp_set("Running", "true")
                evil_ftp_set("Starting", "false")
                evil_ftp_set("Port", selected_port)
                evil_ftp_set("Root", root)
                evil_ftp_set("Address", address)
                evil_ftp_set("Auth", auth_label)
                evil_ftp_set("Local", "true" if settings.get("localhost_only") else "false")
                evil_ftp_log("Server läuft auf %s:%s" % (address, selected_port))
                return True
            except Exception as error:
                evil_ftp_set("Starting", "false")
                evil_ftp_set("Running", "false")
                evil_ftp_set("Error", str(error))
                evil_ftp_log("Start fehlgeschlagen: %s" % error, xbmc.LOGERROR)
                return False

    def _serve(self, server):
        try:
            server.serve_forever(timeout=0.5, blocking=True, handle_exit=False)
        except Exception as error:
            if self.server is server:
                evil_ftp_set("Error", str(error))
                evil_ftp_log("Serverfehler: %s" % error, xbmc.LOGERROR)
        finally:
            with self.lock:
                if self.server is server:
                    self.server = None
                    self.thread = None
                    evil_ftp_set("Running", "false")
                    evil_ftp_set("Starting", "false")

    def stop(self):
        with self.lock:
            server = self.server
            thread = self.thread
            self.server = None
            self.thread = None
        if server is not None:
            try:
                server.close_all()
            except Exception as error:
                evil_ftp_log("Stoppen fehlgeschlagen: %s" % error, xbmc.LOGWARNING)
        if thread is not None and thread.is_alive() and thread is not threading.current_thread():
            thread.join(3)
        evil_ftp_set("Running", "false")
        evil_ftp_set("Starting", "false")
        evil_ftp_log("Server gestoppt")
        return True

    def restart(self, settings=None):
        self.stop()
        return self.start(settings)


def evil_ftp_service():
    evil_ftp_set("Service", "ready")
    controller = EvilFtpController()
    guide = None
    try:
        from evil_guide import EvilGuideServer
        guide = EvilGuideServer()
    except Exception as error:
        evil_ftp_log("Anleitungsdienst nicht ladbar: %s" % error, xbmc.LOGERROR)
    try:
        settings = evil_ftp_settings()
        if settings.get("autostart"):
            controller.start(settings)
    except Exception as error:
        evil_ftp_set("Error", str(error))
        evil_ftp_log("Autostart fehlgeschlagen: %s" % error, xbmc.LOGERROR)

    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        command = evil_ftp_get("Command")
        if command:
            evil_ftp_clear("Command")
            if command == "start":
                controller.start()
            elif command == "stop":
                controller.stop()
            elif command == "restart":
                controller.restart()
        if guide is not None:
            guide.process_command()
            guide.cleanup()
        if monitor.waitForAbort(1):
            break
    controller.stop()
    if guide is not None:
        guide.stop()
    evil_ftp_clear("Service")
    evil_ftp_clear("Running")
    evil_ftp_clear("Starting")
