import xbmc
import xbmcgui

EVIL_POWERED_TEXT = "powered by  IT('s) POSSIBLE WIZARD "

EVIL_APPEARANCE_DEFAULTS = {
    "title": "IT'S-POSSIBLE WIZARD",
    "title_font": "font52",
    "title_color": "FFFF2B2B",
    "title_x": 520,
    "title_y": 58,
    "title_width": 1080,
    "title_height": 100,
    "title_align": "center",
    "powered_text": EVIL_POWERED_TEXT,
    "powered_font": "font12",
    "powered_color": "FF7A7A7A",
    "powered_x": 120,
    "powered_y": 928,
    "accent": "FFFF0000",
    "accent_soft": "FFFF5555",
    "text": "FFE0E0E0",
    "muted": "FF9A9A9A",
    "background": "FFFF0000",
    "panel": "FFFF0000",
}

EVIL_TITLE_FONTS = ("font45", "font52", "font60", "font32", "font22")
EVIL_TITLE_ALIGNMENTS = ("left", "center", "right")
EVIL_COLOR_PALETTE = (
    ("ROT", "FFFF2B2B"),
    ("ORANGE", "FFFF8A00"),
    ("GELB", "FFFFD200"),
    ("GRÜN", "FF35D07F"),
    ("TÜRKIS", "FF35C7D0"),
    ("BLAU", "FF3D8BFF"),
    ("VIOLETT", "FFB46BFF"),
    ("PINK", "FFFF5FA8"),
    ("WEISS", "FFFFFFFF"),
    ("GRAU", "FF9A9A9A"),
    ("SCHWARZ", "FF111111"),
)

EVIL_COLOR_KEYS = ("title_color", "accent", "accent_soft", "text", "muted", "background", "panel")
EVIL_TITLE_ID = 8900
EVIL_LEGACY_TITLE_IDS = {
    "EvilInputWindow": 940,
    "EvilConfirmWindow": 720,
}
EVIL_POWERED_ID = 8901


def evil_color(value, fallback):
    text = str(value or "").strip().upper()
    if len(text) == 6:
        text = "FF" + text
    if len(text) != 8:
        return fallback
    try:
        int(text, 16)
    except ValueError:
        return fallback
    return text


def evil_int(value, fallback, minimum=None, maximum=None):
    try:
        number = int(value)
    except (TypeError, ValueError):
        number = fallback
    if minimum is not None:
        number = max(minimum, number)
    if maximum is not None:
        number = min(maximum, number)
    return number


def evil_appearance(config):
    raw = config.get("appearance") if isinstance(config, dict) else None
    data = raw if isinstance(raw, dict) else {}
    result = dict(EVIL_APPEARANCE_DEFAULTS)
    result["title"] = str(data.get("title") or result["title"]).strip() or result["title"]
    result["title_font"] = data.get("title_font") if data.get("title_font") in EVIL_TITLE_FONTS else result["title_font"]
    result["title_align"] = data.get("title_align") if data.get("title_align") in EVIL_TITLE_ALIGNMENTS else result["title_align"]
    result["title_x"] = evil_int(data.get("title_x"), result["title_x"], 0, 1920)
    result["title_y"] = evil_int(data.get("title_y"), result["title_y"], 0, 1080)
    result["title_width"] = evil_int(data.get("title_width"), result["title_width"], 120, 1920)
    result["title_height"] = evil_int(data.get("title_height"), result["title_height"], 30, 240)
    result["powered_text"] = EVIL_POWERED_TEXT
    result["powered_font"] = data.get("powered_font") if data.get("powered_font") in EVIL_TITLE_FONTS else result["powered_font"]
    result["powered_x"] = evil_int(data.get("powered_x"), result["powered_x"], 0, 1920)
    result["powered_y"] = evil_int(data.get("powered_y"), result["powered_y"], 0, 1080)
    for key in EVIL_COLOR_KEYS:
        result[key] = evil_color(data.get(key), result[key])
    return result


def evil_appearance_payload(config):
    return dict(evil_appearance(config))


def evil_apply_skin_colors(appearance):
    values = {
        "ipw_accent": appearance.get("accent"),
        "ipw_accent_soft": appearance.get("accent_soft"),
        "ipw_text": appearance.get("text"),
        "ipw_muted": appearance.get("muted"),
        "ipw_background": appearance.get("background"),
        "ipw_panel": appearance.get("panel"),
    }
    for name, value in values.items():
        try:
            xbmc.executebuiltin("Skin.SetString(%s,%s)" % (name, evil_color(value, "FFFFFFFF")))
        except Exception:
            pass


def evil_apply_skin(config):
    appearance = evil_appearance(config)
    evil_apply_skin_colors(appearance)
    return appearance


def evil_alignment(value):
    if value == "right":
        return 1
    if value == "center":
        return 2
    return 0


def evil_label(window, x, y, width, height, text, font, color, align):
    kwargs = {
        "font": font,
        "textColor": "0x" + evil_color(color, "FFFFFFFF"),
        "alignment": evil_alignment(align),
    }
    label = xbmcgui.ControlLabel(int(x), int(y), int(width), int(height), str(text), **kwargs)
    window.addControl(label)
    return label


def evil_apply_title(window, config=None, main=False):
    appearance = evil_appearance(config)
    legacy_id = EVIL_LEGACY_TITLE_IDS.get(window.__class__.__name__)
    for control_id in {EVIL_TITLE_ID, legacy_id}:
        if control_id is None:
            continue
        try:
            window.getControl(control_id).setVisible(False)
        except Exception:
            pass
    if getattr(window, "evil_title_control", None) is not None:
        try:
            window.removeControl(window.evil_title_control)
        except Exception:
            pass
        window.evil_title_control = None
    title_text = appearance["title"]
    try:
        window.evil_title_control = evil_label(
            window,
            appearance["title_x"],
            appearance["title_y"],
            appearance["title_width"],
            appearance["title_height"],
            title_text,
            appearance["title_font"],
            appearance["title_color"],
            appearance["title_align"],
        )
    except Exception:
        window.evil_title_control = None
    if not main:
        return appearance
    try:
        footer = window.getControl(EVIL_POWERED_ID)
        footer.setVisible(False)
    except Exception:
        pass
    if getattr(window, "evil_powered_control", None) is not None:
        try:
            window.removeControl(window.evil_powered_control)
        except Exception:
            pass
        window.evil_powered_control = None
    try:
        window.evil_powered_control = evil_label(
            window,
            appearance["powered_x"],
            appearance["powered_y"],
            760,
            34,
            appearance["powered_text"],
            appearance["powered_font"],
            appearance["powered_color"],
            "left",
        )
    except Exception:
        window.evil_powered_control = None
    return appearance


def evil_apply_window(window, main=False):
    if not main and window.__class__.__name__ == "EvilMainWindow":
        main = True
    config = getattr(window, "evil_config", None)
    appearance = evil_appearance(config)
    if isinstance(config, dict):
        evil_apply_skin_colors(appearance)
    return evil_apply_title(window, config, main=main)
