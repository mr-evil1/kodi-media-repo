import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ElementTree
import zipfile
from urllib.error import URLError
from urllib.parse import quote, urljoin
from urllib.request import ProxyHandler, Request, build_opener, urlopen

import xbmc
import xbmcaddon
import xbmcvfs

EVIL_HOME_DIR = xbmcvfs.translatePath("special://home/")
EVIL_ADDONS_DIR = xbmcvfs.translatePath("special://home/addons/")
EVIL_TEMP_DIR = xbmcvfs.translatePath("special://temp/")
EVIL_PROFILE_DIR = xbmcvfs.translatePath("special://profile/")
EVIL_AGENT = "It's-Possible-Wizard/2026.11.10.34"
EVIL_ADDON_ID = "plugin.program.itspossiblewizard"
EVIL_STORAGE_SETTING = "storage_path"
EVIL_FALLBACK_BUILD_DIR = xbmcvfs.translatePath("special://profile/itspossible_builds/")
EVIL_CHUNK = 65536
EVIL_BUILD_ROOTS = {"addons", "userdata", "media", "sounds", "system", "temp", "backups", "cache"}
EVIL_BUILD_EXCLUDES = (
    "addons/packages",
    "userdata/thumbnails",
    "userdata/temp",
    "userdata/cache",
    "userdata/itspossible_backups",
    "userdata/itspossible_builds",
    "userdata/evil_backups",
    "userdata/evil_builds",
    "addons/plugin.program.evilwizard",
)
EVIL_BUILD_IGNORE_SUFFIXES = (".pyc", ".pyo", ".log", ".old")
EVIL_REPO_ADDONS_URL = "https://mr-evil1.github.io/kodi-media-repo/addons.xml"
EVIL_REPO_BASE_URL = "https://mr-evil1.github.io/kodi-media-repo/"
EVIL_LABEL_TAGS = re.compile(r"\[/?(?:COLOR|B|I|UPPERCASE|LOWERCASE|LIGHT|CAPS|CR|FN|SIZE)[^\]]*\]", re.I)
EVIL_AUTOEXEC_MARKER = "# IT'S-POSSIBLE WIZARD AUTO-ENABLE"
EVIL_AUTOEXEC_BLOCK = (
    EVIL_AUTOEXEC_MARKER + "\n"
    "try:\n"
    "    import json as _evil_json\n"
    "    import os as _evil_os\n"
    "    import sys as _evil_sys\n"
    "    import xbmc as _evil_xbmc\n"
    "    import xbmcvfs as _evil_xbmcvfs\n"
    "    _evil_xbmc.executebuiltin(\"UpdateLocalAddons\")\n"
    "    _evil_xbmc.executeJSONRPC(_evil_json.dumps({\n"
    "        \"jsonrpc\": \"2.0\",\n"
    "        \"id\": 666,\n"
    "        \"method\": \"Addons.SetAddonEnabled\",\n"
    "        \"params\": {\"addonid\": \"plugin.program.itspossiblewizard\", \"enabled\": True},\n"
    "    }))\n"
    "    _evil_xbmc.executebuiltin(\"EnableAddon(plugin.program.itspossiblewizard)\")\n"
    "    _evil_lib = _evil_os.path.join(\n"
    "        _evil_xbmcvfs.translatePath(\"special://home/addons/\"),\n"
    "        \"plugin.program.itspossiblewizard\", \"resources\", \"lib\"\n"
    "    )\n"
    "    _evil_sys.path.insert(0, _evil_lib)\n"
    "    from evil_installer import evil_disable_scheduled_wizards\n"
    "    evil_disable_scheduled_wizards()\n"
    "except Exception:\n"
    "    pass\n"
)
EVIL_FOREIGN_AUTOEXEC_MARKER = "# IT'S-POSSIBLE WIZARD FOREIGN WIZARD AUTO-DISABLE"
EVIL_FOREIGN_AUTOEXEC_BLOCK = (
    EVIL_FOREIGN_AUTOEXEC_MARKER + "\n"
    "try:\n"
    "    import os as _evil_os\n"
    "    import sys as _evil_sys\n"
    "    import xbmcvfs as _evil_xbmcvfs\n"
    "    _evil_lib = _evil_os.path.join(\n"
    "        _evil_xbmcvfs.translatePath(\"special://home/addons/\"),\n"
    "        \"plugin.program.itspossiblewizard\", \"resources\", \"lib\"\n"
    "    )\n"
    "    _evil_sys.path.insert(0, _evil_lib)\n"
    "    from evil_installer import evil_disable_scheduled_wizards\n"
    "    evil_disable_scheduled_wizards()\n"
    "except Exception:\n"
    "    pass\n"
)
EVIL_FOREIGN_WIZARD_MARKER = os.path.join(EVIL_PROFILE_DIR, "itspossible_foreign_wizards.txt")


class EvilCancelled(Exception):
    pass


def evil_log(message, level=xbmc.LOGINFO):
    xbmc.log("[IT'S-POSSIBLE WIZARD] %s" % message, level)


def evil_urlopen(request, timeout=30):
    try:
        return urlopen(request, timeout=timeout)
    except URLError as error:
        reason = getattr(error, "reason", None)
        text = str(reason or error).lower()
        if "refused" not in text and "proxy" not in text:
            raise
        evil_log("Proxy nicht erreichbar, versuche Direktverbindung.", xbmc.LOGWARNING)
        fallback = Request(
            request.full_url,
            data=request.data,
            headers=dict(request.headers),
            method=request.get_method(),
        )
        return build_opener(ProxyHandler({})).open(fallback, timeout=timeout)


def evil_installed(addon_id):
    return xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id)


def evil_wait_until_installed(addon_id, timeout=30):
    end = time.time() + timeout
    while time.time() < end:
        if evil_installed(addon_id):
            return True
        xbmc.sleep(500)
    return False


def evil_enable(addon_id):
    request = {
        "jsonrpc": "2.0",
        "id": 666,
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": True},
    }
    try:
        response = xbmc.executeJSONRPC(json.dumps(request))
        try:
            data = json.loads(response)
        except (TypeError, ValueError):
            data = {}
        if isinstance(data, dict) and data.get("result") == "OK":
            return True
    except Exception as error:
        evil_log("Addon %s konnte nicht per JSON-RPC aktiviert werden: %s" % (addon_id, error), xbmc.LOGWARNING)
    try:
        xbmc.executebuiltin("EnableAddon(%s)" % addon_id)
        return True
    except Exception as error:
        evil_log("Addon %s konnte nicht aktiviert werden: %s" % (addon_id, error), xbmc.LOGERROR)
        return False



def evil_addon_enabled(addon_id):
    request = {
        "jsonrpc": "2.0",
        "id": 668,
        "method": "Addons.GetAddonDetails",
        "params": {"addonid": addon_id, "properties": ["enabled"]},
    }
    try:
        response = xbmc.executeJSONRPC(json.dumps(request))
        data = json.loads(response)
        addon = (data.get("result") or {}).get("addon") or {}
        return bool(addon.get("enabled"))
    except Exception:
        return False

def evil_activate_wizard():
    for _attempt in range(3):
        if evil_enable(EVIL_ADDON_ID):
            evil_log("Wizard automatisch aktiviert.", xbmc.LOGINFO)
            return True
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.sleep(400)
    evil_log("Wizard konnte nach der Build-Installation nicht automatisch aktiviert werden.", xbmc.LOGERROR)
    return False


def evil_write_autoexec_enable():
    path = os.path.join(EVIL_PROFILE_DIR, "autoexec.py")
    existing = ""
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as handle:
                existing = handle.read()
        except (OSError, UnicodeError) as error:
            evil_log("autoexec.py nicht lesbar: %s" % error, xbmc.LOGWARNING)
            return False
    additions = []
    if EVIL_AUTOEXEC_MARKER not in existing:
        additions.append(EVIL_AUTOEXEC_BLOCK)
    if "evil_disable_scheduled_wizards" not in existing and not any(
        "evil_disable_scheduled_wizards" in block for block in additions
    ):
        additions.append(EVIL_FOREIGN_AUTOEXEC_BLOCK)
    if not additions:
        return True
    try:
        with open(path, "a", encoding="utf-8", newline="\n") as handle:
            if existing and not existing.endswith("\n"):
                handle.write("\n")
            for block in additions:
                handle.write(block)
        evil_log("Wizard-Aktivierung und Fremd-Wizard-Sperre in autoexec.py eingetragen.", xbmc.LOGINFO)
        return True
    except OSError as error:
        evil_log("autoexec.py nicht schreibbar: %s" % error, xbmc.LOGWARNING)
        return False


def evil_read_addon_id(folder):
    manifest = os.path.join(folder, "addon.xml")
    try:
        tree = ElementTree.parse(manifest)
    except (OSError, ElementTree.ParseError):
        return ""
    return tree.getroot().get("id", "")


def evil_is_wizard(addon_id, name=""):
    text = ("%s %s" % (addon_id or "", name or "")).lower()
    return "wizard" in text or re.search(r"\bwiz\b", text) is not None


def evil_installed_wizards():
    wizards = []
    try:
        folders = os.listdir(EVIL_ADDONS_DIR)
    except OSError:
        return wizards
    for folder in sorted(folders, key=str.casefold):
        path = os.path.join(EVIL_ADDONS_DIR, folder)
        if os.path.islink(path) or not os.path.isdir(path):
            continue
        manifest_path = os.path.join(path, "addon.xml")
        try:
            manifest = ElementTree.parse(manifest_path).getroot()
        except (OSError, ElementTree.ParseError):
            continue
        addon_id = str(manifest.get("id") or "").strip()
        if not addon_id or addon_id == EVIL_ADDON_ID:
            continue
        name = evil_plain_text(manifest.get("name") or "")
        if evil_is_wizard(addon_id, name):
            wizards.append({"id": addon_id, "name": name or addon_id, "folder": folder})
    return wizards


def evil_disable_addon(addon_id):
    request = {
        "jsonrpc": "2.0",
        "id": 667,
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": False},
    }
    try:
        response = xbmc.executeJSONRPC(json.dumps(request))
        try:
            data = json.loads(response)
        except (TypeError, ValueError):
            data = {}
        if isinstance(data, dict) and data.get("result") == "OK":
            return True
    except Exception as error:
        evil_log("Addon %s konnte nicht per JSON-RPC deaktiviert werden: %s" % (addon_id, error), xbmc.LOGWARNING)
    try:
        xbmc.executebuiltin("DisableAddon(%s)" % addon_id)
        return True
    except Exception as error:
        evil_log("Addon %s konnte nicht deaktiviert werden: %s" % (addon_id, error), xbmc.LOGERROR)
        return False


def evil_disable_foreign_wizards():
    disabled = []
    for wizard in evil_installed_wizards():
        if evil_disable_addon(wizard["id"]):
            disabled.append(wizard["id"])
    if disabled:
        evil_log("Fremde Wizards deaktiviert: %s" % ", ".join(disabled), xbmc.LOGINFO)
    return disabled


def evil_schedule_foreign_wizard_disable(addon_ids):
    values = []
    for addon_id in addon_ids or []:
        value = str(addon_id or "").strip()
        if value and value != EVIL_ADDON_ID and value not in values:
            values.append(value)
    if not values:
        try:
            if os.path.isfile(EVIL_FOREIGN_WIZARD_MARKER):
                os.remove(EVIL_FOREIGN_WIZARD_MARKER)
        except OSError:
            pass
        return False
    try:
        with open(EVIL_FOREIGN_WIZARD_MARKER, "w", encoding="utf-8", newline="\n") as handle:
            for value in values:
                handle.write(value + "\n")
        return True
    except OSError as error:
        evil_log("Fremde-Wizard-Marker nicht schreibbar: %s" % error, xbmc.LOGWARNING)
        return False


def evil_disable_scheduled_wizards():
    if not os.path.isfile(EVIL_FOREIGN_WIZARD_MARKER):
        return []
    values = []
    try:
        with open(EVIL_FOREIGN_WIZARD_MARKER, "r", encoding="utf-8") as handle:
            for line in handle:
                value = line.strip()
                if value and value != EVIL_ADDON_ID and value not in values:
                    values.append(value)
    except (OSError, UnicodeError) as error:
        evil_log("Fremde-Wizard-Marker nicht lesbar: %s" % error, xbmc.LOGWARNING)
        return []
    disabled = []
    for addon_id in values:
        if evil_disable_addon(addon_id):
            disabled.append(addon_id)
    try:
        os.remove(EVIL_FOREIGN_WIZARD_MARKER)
    except OSError:
        pass
    if disabled:
        evil_log("Fremde Wizards beim Start deaktiviert: %s" % ", ".join(disabled), xbmc.LOGINFO)
    return disabled


def evil_unpack(zip_path, target_dir):
    os.makedirs(target_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path) as archive:
        archive.extractall(target_dir)
    for root, folders, files in os.walk(target_dir):
        if "addon.xml" in files:
            return root
    return ""


def evil_copy_into_addons(source):
    addon_id = evil_read_addon_id(source)
    if not addon_id:
        return ""
    target = os.path.join(EVIL_ADDONS_DIR, addon_id)
    if os.path.isdir(target):
        shutil.rmtree(target, ignore_errors=True)
    shutil.copytree(source, target)
    xbmc.executebuiltin("UpdateLocalAddons")
    return addon_id


def evil_safe_zip_name(name):
    cleaned = (name or "").replace("\\", "/").strip()
    if not cleaned or cleaned.startswith("/") or re.match(r"^[A-Za-z]:", cleaned):
        return ""
    parts = []
    for part in cleaned.split("/"):
        if part in ("", "."):
            continue
        if part == "..":
            return ""
        parts.append(part)
    return "/".join(parts)


def evil_build_file_name(name, version=""):
    parts = []
    for value in (name, version):
        text = re.sub(r'[\\/:*?"<>|]+', "-", str(value or "")).strip()
        text = re.sub(r"\s+", "-", text).strip(".-")
        if text:
            parts.append(text)
    return ("-".join(parts).strip(".-") or "Its-Possible-Build")[:120]


def evil_list_value(value):
    return re.sub(r"\s+", " ", str(value or "")).replace('"', "'").strip()


def evil_build_list_text(name, version, address, kodi="", description="", icon="", fanart="", zip_name=""):
    url = evil_public_url(address)
    if not url:
        return ""
    if zip_name and url.endswith("/"):
        url += quote(str(zip_name), safe="")
    icon_url = evil_public_url(icon)
    fanart_url = evil_public_url(fanart)
    return "\n".join([
        'name="%s"' % evil_list_value(name),
        'version="%s"' % evil_list_value(version),
        'url="%s"' % evil_list_value(url),
        'kodi="%s"' % evil_list_value(kodi),
        'icon="%s"' % evil_list_value(icon_url),
        'fanart="%s"' % evil_list_value(fanart_url),
        'adult="No"',
        'description="%s"' % evil_list_value(description),
    ]) + "\n"


def evil_build_excluded(relative):
    lower = (relative or "").replace("\\", "/").strip("/").lower()
    if not lower:
        return False
    for prefix in EVIL_BUILD_EXCLUDES:
        if lower == prefix or lower.startswith(prefix + "/"):
            return True
    parts = lower.split("/")
    if "__pycache__" in parts:
        return True
    if lower.endswith(EVIL_BUILD_IGNORE_SUFFIXES):
        return True
    if parts[-1] in (".ds_store", "thumbs.db"):
        return True
    return False


def evil_active_build_sources(config):
    data = config if isinstance(config, dict) else {}
    sources = [
        source for source in data.get("build_sources", [])
        if isinstance(source, dict) and source.get("id") and source.get("url")
    ]
    active_ids = data.get("active_build_sources")
    if not isinstance(active_ids, list):
        legacy = str(data.get("active_build_source") or "").strip()
        active_ids = [legacy] if legacy else []
    if not active_ids:
        return []
    return [source for source in sources if source.get("id") in active_ids]


def evil_build_addon_entries():
    entries = []
    data_root = os.path.join(EVIL_HOME_DIR, "userdata", "addon_data")
    seen_data = set()
    try:
        folders = sorted(os.listdir(EVIL_ADDONS_DIR), key=str.casefold)
    except OSError:
        folders = []
    for folder in folders:
        path = os.path.join(EVIL_ADDONS_DIR, folder)
        if os.path.islink(path) or not os.path.isdir(path):
            continue
        try:
            manifest = ElementTree.parse(os.path.join(path, "addon.xml")).getroot()
        except (OSError, ElementTree.ParseError):
            continue
        addon_id = str(manifest.get("id") or "").strip()
        if not addon_id:
            continue
        data_id = addon_id
        data_path = os.path.join(data_root, data_id)
        if not os.path.isdir(data_path):
            fallback_data = os.path.join(data_root, folder)
            if os.path.isdir(fallback_data):
                data_id = folder
                data_path = fallback_data
        has_data = os.path.isdir(data_path) and not os.path.islink(data_path)
        if has_data:
            seen_data.add(data_id)
        name = evil_plain_text(manifest.get("name") or "")
        if not name or name.startswith("$"):
            name = folder
        icon = os.path.join(path, "icon.png")
        entries.append({
            "name": name,
            "id": addon_id,
            "folder": folder,
            "data_id": data_id,
            "has_addon": True,
            "has_data": has_data,
            "icon": icon if os.path.isfile(icon) else "",
        })
    if os.path.isdir(data_root):
        try:
            data_folders = sorted(os.listdir(data_root), key=str.casefold)
        except OSError:
            data_folders = []
        for data_id in data_folders:
            path = os.path.join(data_root, data_id)
            if data_id in seen_data or os.path.islink(path) or not os.path.isdir(path):
                continue
            entries.append({
                "name": data_id,
                "id": data_id,
                "folder": "",
                "data_id": data_id,
                "has_addon": False,
                "has_data": True,
                "icon": "",
            })
    entries.sort(key=lambda entry: (entry.get("name") or entry.get("id") or "").casefold())
    return entries


def evil_setting_string(setting_id):
    try:
        addon = xbmcaddon.Addon(EVIL_ADDON_ID)
        getter = getattr(addon, "getSettingString", None)
        value = getter(setting_id) if getter else addon.getSetting(setting_id)
        return str(value or "").strip()
    except Exception as error:
        evil_log("Einstellung %s nicht lesbar: %s" % (setting_id, error), xbmc.LOGWARNING)
        return ""


def evil_set_setting_string(setting_id, value):
    try:
        addon = xbmcaddon.Addon(EVIL_ADDON_ID)
        addon.setSetting(setting_id, str(value or "").strip())
        return True
    except Exception as error:
        evil_log("Einstellung %s nicht schreibbar: %s" % (setting_id, error), xbmc.LOGWARNING)
        return False


def evil_set_setting_bool(setting_id, value):
    try:
        addon = xbmcaddon.Addon(EVIL_ADDON_ID)
        setter = getattr(addon, "setSettingBool", None)
        if setter:
            try:
                setter(setting_id, bool(value))
                return True
            except Exception:
                pass
        addon.setSetting(setting_id, "true" if value else "false")
        return True
    except Exception as error:
        evil_log("Einstellung %s nicht schreibbar: %s" % (setting_id, error), xbmc.LOGWARNING)
        return False


def evil_last_build_url():
    return evil_setting_string("last_build_url")


def evil_set_last_build_url(url):
    return evil_set_setting_string("last_build_url", url)


def evil_setting_bool(setting_id):
    try:
        addon = xbmcaddon.Addon(EVIL_ADDON_ID)
        getter = getattr(addon, "getSettingBool", None)
        if getter:
            try:
                return bool(getter(setting_id))
            except Exception:
                pass
        value = addon.getSetting(setting_id)
        return str(value or "").strip().lower() in ("true", "1", "yes", "on")
    except Exception as error:
        evil_log("Einstellung %s nicht lesbar: %s" % (setting_id, error), xbmc.LOGWARNING)
        return False


def evil_manual_build_installed():
    return evil_setting_bool("build_manual_installed")


def evil_turbo_enabled():
    return evil_setting_bool("turbo_build")


def evil_safe_install_enabled():
    return evil_setting_bool("safe_install")


def evil_turbo_create_enabled():
    return evil_setting_bool("turbo_create")


def evil_safe_create_enabled():
    return evil_setting_bool("safe_create")


def evil_open_settings():
    try:
        addon = xbmcaddon.Addon(EVIL_ADDON_ID)
        addon.openSettings()
        return True
    except Exception as error:
        evil_log("Einstellungen konnten nicht direkt geöffnet werden: %s" % error, xbmc.LOGWARNING)
    try:
        xbmc.executebuiltin("Addon.OpenSettings(%s)" % EVIL_ADDON_ID)
        return True
    except Exception as error:
        evil_log("Einstellungen konnten nicht geöffnet werden: %s" % error, xbmc.LOGERROR)
        return False


def evil_storage_path():
    value = evil_setting_string(EVIL_STORAGE_SETTING)
    if not value:
        return ""
    try:
        return os.path.normpath(xbmcvfs.translatePath(value))
    except Exception as error:
        evil_log("Build-Speicherort ungültig: %s" % error, xbmc.LOGERROR)
        return ""


def evil_valid_build_folder(path):
    target = os.path.normcase(os.path.normpath(path))
    home = os.path.normcase(os.path.normpath(EVIL_HOME_DIR))
    addons = os.path.normcase(os.path.normpath(os.path.join(home, "addons")))
    userdata = os.path.normcase(os.path.normpath(os.path.join(home, "userdata")))
    if target in (home, addons, userdata):
        return False
    if target.startswith(addons + os.sep):
        return False
    return True


def evil_android_platform():
    try:
        return bool(xbmc.getCondVisibility("System.Platform.Android"))
    except Exception:
        return False


def evil_windows_download_dir():
    if os.name != "nt":
        return ""
    try:
        import winreg

        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders",
        )
        try:
            value, _ = winreg.QueryValueEx(
                key, "{374DE290-123F-4565-9164-39C4925E467B}"
            )
        finally:
            winreg.CloseKey(key)
        return os.path.expandvars(str(value or ""))
    except Exception:
        return ""


def evil_system_download_candidates():
    candidates = []

    def add(value):
        value = str(value or "").strip().strip('"')
        if not value:
            return
        value = os.path.expandvars(os.path.expanduser(value))
        if not value:
            return
        value = os.path.normpath(value)
        if value not in candidates:
            candidates.append(value)

    for name in ("XDG_DOWNLOAD_DIR", "DOWNLOAD_DIR"):
        add(os.environ.get(name))

    android = evil_android_platform()
    if android:
        external = os.environ.get("EXTERNAL_STORAGE")
        if external:
            add(os.path.join(external, "Download"))
        for path in (
            "/storage/emulated/0/Download",
            "/storage/self/primary/Download",
            "/sdcard/Download",
            "/storage/emulated/0/Downloads",
            "/sdcard/Downloads",
        ):
            add(path)
    elif os.name == "nt":
        profile = os.environ.get("USERPROFILE") or os.path.expanduser("~")
        add(os.path.join(profile, "Downloads"))
        add(os.path.join(profile, "Download"))
        add(evil_windows_download_dir())
    else:
        home = os.path.expanduser("~")
        add(os.path.join(home, "Downloads"))
        add(os.path.join(home, "Download"))
        config = os.path.join(home, ".config", "user-dirs.dirs")
        try:
            with open(config, "r", encoding="utf-8") as handle:
                for line in handle:
                    line = line.strip()
                    if not line.startswith("XDG_DOWNLOAD_DIR="):
                        continue
                    value = line.split("=", 1)[1].strip().strip('"')
                    value = value.replace("${HOME}", home).replace("$HOME", home)
                    add(value)
        except OSError:
            pass
    return candidates


def evil_writable_build_folder(path, create=False):
    raw = str(path or "").strip()
    if not raw:
        return False
    path = os.path.normpath(raw)
    if not evil_valid_build_folder(path):
        return False
    if create:
        try:
            os.makedirs(path, exist_ok=True)
        except OSError as error:
            evil_log("Build-Ordner nicht anlegbar: %s" % error, xbmc.LOGWARNING)
            return False
    if not os.path.isdir(path):
        return False
    if not create:
        return True
    probe = ""
    try:
        descriptor, probe = tempfile.mkstemp(prefix=".itspossible-", dir=path)
        os.close(descriptor)
        os.remove(probe)
        return True
    except OSError as error:
        evil_log("Build-Ordner nicht beschreibbar: %s" % error, xbmc.LOGWARNING)
        if probe:
            try:
                os.remove(probe)
            except OSError:
                pass
        return False


def evil_default_build_dir(create=False):
    for candidate in evil_system_download_candidates():
        if create:
            if evil_writable_build_folder(candidate, True):
                return candidate
        elif os.path.isdir(candidate) and evil_valid_build_folder(candidate):
            return candidate
    fallback_raw = str(EVIL_FALLBACK_BUILD_DIR or "").strip()
    if not fallback_raw:
        return ""
    fallback = os.path.normpath(fallback_raw)
    if not evil_valid_build_folder(fallback):
        return ""
    if create and not evil_writable_build_folder(fallback, True):
        return ""
    return fallback


def evil_build_dir(create=False):
    path = evil_storage_path()
    if not path:
        return evil_default_build_dir(create)
    if not evil_valid_build_folder(path):
        return ""
    if create:
        try:
            os.makedirs(path, exist_ok=True)
        except OSError as error:
            evil_log("Build-Ordner nicht anlegbar: %s" % error, xbmc.LOGERROR)
            return ""
    return path


def evil_local_file(path):
    candidate = xbmcvfs.translatePath(path) if path.startswith("special://") else path
    return candidate if os.path.isfile(candidate) else ""


def evil_plain_text(value):
    text = EVIL_LABEL_TAGS.sub("", str(value or ""))
    return re.sub(r"\s+", " ", text).strip()


def evil_repository_asset_url(addon_id, path):
    value = str(path or "").strip()
    if not value:
        return ""
    if re.match(r"^https?://", value, re.I):
        return value
    return EVIL_REPO_BASE_URL + quote(str(addon_id or ""), safe="") + "/" + quote(value.lstrip("/"), safe="/")



def evil_repository_zip_url(addon_id, version):
    addon = quote(str(addon_id or ""), safe="")
    release = quote(str(version or ""), safe="+")
    if not addon or not release:
        return ""
    return EVIL_REPO_BASE_URL + addon + "/" + addon + "-" + release + ".zip"

def evil_build_url(value, base=""):
    url = str(value or "").strip()
    if not url:
        return ""
    if base and "://" in base and "://" not in url and not url.startswith("special://"):
        url = urljoin(base, url)
    if url.startswith(("http://", "https://")):
        if url.rstrip("/") in ("http:", "https:"):
            return ""
        return url
    if url.startswith(("file://", "special://")):
        return url
    return ""


def evil_normalize_url(value):
    url = str(value or "").strip().replace("\\", "/")
    if not url:
        return ""
    if os.path.isabs(url) or re.match(r"^[A-Za-z]:/", url):
        return url
    match = re.match(r"^(https?):(.*)$", url, re.I)
    if match:
        rest = match.group(2).lstrip("/")
        return match.group(1).lower() + "://" + rest if rest else ""
    if url.startswith("special://") or re.match(r"^[a-z][a-z0-9+.-]*://", url, re.I):
        return url
    return "https://" + url.lstrip("/")


def evil_public_url(value):
    url = str(value or "").strip()
    if not url:
        return ""
    if "://" not in url:
        url = "https://" + url
    if re.search(r"\s", url):
        return ""
    if not re.match(r"^https?://[^/]+", url, re.I):
        return ""
    return url


def evil_kodi_major():
    raw = xbmc.getInfoLabel("System.BuildVersion") or ""
    match = re.match(r"\s*(\d+)", raw)
    return int(match.group(1)) if match else 0


def evil_size_to_mb(value, unit=""):
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        number = float(value)
    else:
        text = str(value).strip().replace(" ", "").replace(",", ".")
        if not text:
            return None
        match = re.match(r"^([0-9]+(?:\.[0-9]+)?)([A-Za-z]*)$", text)
        if not match:
            return None
        number = float(match.group(1))
        suffix = match.group(2).lower()
        if suffix:
            unit = suffix
    if number < 0:
        return None
    unit = str(unit or "").lower().replace(" ", "")
    if unit in ("mb", "mib"):
        return number
    if unit in ("kb", "kib"):
        return number / 1024.0
    if unit in ("gb", "gib"):
        return number * 1024.0
    if unit in ("tb", "tib"):
        return number * 1024.0 * 1024.0
    if unit in ("b", "byte", "bytes"):
        return number / (1024.0 * 1024.0)
    return number / (1024.0 * 1024.0) if number >= 1024 * 1024 else number


def evil_format_size_mb(value):
    if value is None:
        return ""
    try:
        mb = float(value)
    except (TypeError, ValueError):
        return ""
    if mb <= 0:
        return ""
    if mb >= 1000:
        text = "%.0f" % mb
    elif mb >= 10:
        text = "%.1f" % mb
    else:
        text = "%.2f" % mb
    text = text.rstrip("0").rstrip(".")
    return "%s MB" % text.replace(".", ",")


def evil_timestamp(value):
    if value is None or isinstance(value, bool):
        return 0
    if isinstance(value, (int, float)):
        stamp = float(value)
        while stamp > 100000000000:
            stamp /= 1000.0
        return int(stamp) if stamp > 0 else 0
    text = str(value).strip()
    if not text:
        return 0
    if re.match(r"^\d+(?:\.\d+)?$", text):
        stamp = float(text)
        while stamp > 100000000000:
            stamp /= 1000.0
        return int(stamp) if stamp > 0 else 0
    clean = text.replace("Z", " ").replace("z", " ").strip()[:19]
    for fmt in (
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d",
        "%d.%m.%Y %H:%M:%S",
        "%d.%m.%Y %H:%M",
        "%d.%m.%Y",
    ):
        try:
            return int(time.mktime(time.strptime(clean, fmt)))
        except (OverflowError, ValueError):
            continue
    return 0


def evil_build_entry(data, base=""):
    if not isinstance(data, dict):
        return None
    url = evil_build_url(data.get("url") or data.get("zip"), base)
    if not url:
        return None
    name = evil_plain_text(data.get("name") or data.get("title") or "Unbekannter Build")
    adult = str(data.get("adult", "")).strip().lower()
    size_mb = None
    for key in ("size_mb", "sizeinmb", "size_in_mb", "mb"):
        if data.get(key) not in (None, ""):
            size_mb = evil_size_to_mb(data.get(key), "mb")
            break
    if size_mb is None:
        for key in ("size", "filesize", "file_size", "size_bytes", "sizebytes", "bytes", "content_length", "contentlength"):
            if data.get(key) not in (None, ""):
                unit = "b" if key in ("size_bytes", "sizebytes", "bytes", "content_length", "contentlength") else ""
                size_mb = evil_size_to_mb(data.get(key), unit)
                break
    if size_mb is not None and size_mb <= 0:
        size_mb = None
    updated = 0
    for key in ("updated", "modified", "date", "released", "release_date", "last_updated", "timestamp", "created"):
        if data.get(key) not in (None, ""):
            updated = evil_timestamp(data.get(key))
            if updated:
                break
    return {
        "name": name or "Unbekannter Build",
        "version": str(data.get("version") or "").strip(),
        "url": url,
        "kodi": str(data.get("kodi") or data.get("kodiversion") or data.get("kodi_version") or "").strip(),
        "description": evil_plain_text(data.get("description") or ""),
        "icon": evil_build_url(data.get("icon"), base),
        "fanart": evil_build_url(data.get("fanart"), base),
        "preview": evil_build_url(data.get("preview"), base),
        "info": evil_build_url(data.get("info"), base),
        "theme": str(data.get("theme") or "").strip(),
        "size": evil_format_size_mb(size_mb),
        "size_mb": round(size_mb, 3) if size_mb is not None else None,
        "updated": updated,
        "adult": adult in ("yes", "true", "1", "ja"),
        "source": str(data.get("source") or (base if "://" in base else "")).strip(),
    }


def evil_build_root(members):
    payload = []
    for _member, safe in members:
        parts = safe.split("/")
        if len(parts) > 2 and parts[1].lower() in EVIL_BUILD_ROOTS:
            payload.append(parts)
    if not payload:
        return ""
    first = payload[0][0]
    if first.lower() in EVIL_BUILD_ROOTS:
        return ""
    if all(parts[0] == first for parts in payload):
        return first + "/"
    return ""


def evil_build_install_excluded(relative):
    lower = (relative or "").replace("\\", "/").strip("/").lower()
    if not lower:
        return True
    parts = lower.split("/")
    if "__macosx" in parts:
        return True
    if lower.startswith("addons/plugin.program.itspossiblewizard/") or lower.startswith("addons/plugin.program.evilwizard/"):
        return True
    if lower.startswith("userdata/addon_data/plugin.program.itspossiblewizard/") or lower.startswith("userdata/addon_data/plugin.program.evilwizard/"):
        return True
    if lower.startswith("userdata/database/textures13.db"):
        return True
    if lower.endswith(".csv"):
        return True
    return evil_build_excluded(lower)


def evil_extract_build(zip_path, progress=None, cancelled=None, turbo=False, fast=True):
    def report(percent, label=""):
        if progress is not None:
            progress(int(percent), label)

    def check():
        if cancelled is not None and cancelled():
            raise EvilCancelled()

    with zipfile.ZipFile(zip_path) as archive:
        members = []
        rejected = 0
        for member in archive.infolist():
            safe = evil_safe_zip_name(member.filename)
            if not safe:
                rejected += 1
                continue
            if member.is_dir():
                continue
            members.append((member, safe))
        if not members:
            raise ValueError("Der Build enthält keine Dateien.")
        root = evil_build_root(members)
        binary = set()
        for member, safe in members:
            relative = safe[len(root):] if root and safe.startswith(root) else safe
            parts = relative.split("/")
            if len(parts) == 3 and parts[0] == "addons" and parts[2] == "addon.xml":
                try:
                    manifest = archive.read(member).decode("utf-8", "ignore")
                except (OSError, RuntimeError, zipfile.BadZipFile):
                    continue
                if "kodi.binary" in manifest:
                    binary.add(parts[1])

    home = os.path.normpath(EVIL_HOME_DIR)
    installed = 0
    skipped = rejected
    total = max(len(members), 1)
    created_dirs = set()
    last_report = [0.0]

    def report_limited(percent, label=""):
        now = time.time()
        value = int(percent)
        if value < 100 and now - last_report[0] < 0.2:
            return
        last_report[0] = now
        report(value, label)

    with zipfile.ZipFile(zip_path) as archive:
        for index, (member, safe) in enumerate(members):
            check()
            relative = safe[len(root):] if root and safe.startswith(root) else safe
            if not relative:
                skipped += 1
                continue
            if evil_build_install_excluded(relative):
                skipped += 1
                continue
            target = os.path.normpath(os.path.join(home, relative))
            if target != home and not target.startswith(home + os.sep):
                skipped += 1
                continue
            try:
                if fast:
                    directory = os.path.dirname(target)
                    if directory and directory not in created_dirs:
                        os.makedirs(directory, exist_ok=True)
                        created_dirs.add(directory)
                else:
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                with archive.open(member) as source, open(target, "wb") as destination:
                    if fast:
                        shutil.copyfileobj(source, destination, 1024 * 1024)
                    else:
                        shutil.copyfileobj(source, destination)
                installed += 1
            except (OSError, RuntimeError, zipfile.BadZipFile) as error:
                evil_log("Build-Datei %s fehlgeschlagen: %s" % (relative, error), xbmc.LOGWARNING)
                skipped += 1
            if fast:
                report_limited(45 + int((index + 1) * 50 / total), "Entpacke: %s" % os.path.basename(relative))
            else:
                report(45 + int((index + 1) * 50 / total), "Entpacke: %s" % os.path.basename(relative))
    report(97, "Addons aktualisieren")
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.sleep(250 if turbo and fast else 2500)
    report(100, "Build fertig")
    return {"files": installed, "skipped": skipped, "binaries": sorted(binary)}


def evil_windows_kodi_exe():
    candidates = []
    try:
        candidates.append(os.path.join(xbmcvfs.translatePath("special://xbmc/"), "kodi.exe"))
    except Exception:
        pass
    candidates.append(getattr(sys, "executable", ""))
    for path in candidates:
        if path and os.path.basename(path).lower() == "kodi.exe" and os.path.isfile(path):
            return os.path.abspath(path)
    return ""


def evil_windows_portable_mode():
    try:
        install = os.path.normcase(os.path.abspath(xbmcvfs.translatePath("special://xbmc/")))
        home = os.path.normcase(os.path.abspath(xbmcvfs.translatePath("special://home/")))
        portable = os.path.normcase(os.path.join(install, "portable_data"))
        return home == portable or home.startswith(portable + os.sep)
    except Exception:
        return False


def evil_windows_restart_command(exe, portable=False):
    return 'ping -n 6 127.0.0.1 >nul & start "" "%s"%s' % (exe, " -p" if portable else "")


def evil_schedule_windows_restart():
    exe = evil_windows_kodi_exe()
    if not exe:
        evil_log("Windows-Neustart nicht möglich: kodi.exe nicht gefunden.", xbmc.LOGWARNING)
        return False
    command = evil_windows_restart_command(exe, evil_windows_portable_mode())
    flags = getattr(subprocess, "DETACHED_PROCESS", 0x00000008)
    flags |= getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)
    options = {
        "shell": True,
        "cwd": os.path.dirname(exe),
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "close_fds": True,
        "creationflags": flags,
    }
    try:
        subprocess.Popen(command, **options)
        evil_log("Windows-Neustart angefordert: %s" % exe, xbmc.LOGINFO)
        return True
    except Exception as error:
        evil_log("Windows-Neustart konnte nicht angefordert werden: %s" % error, xbmc.LOGWARNING)
        return False


def evil_force_close(restart=False):
    if restart and (
        xbmc.getCondVisibility("System.Platform.Windows")
        or xbmc.getCondVisibility("System.Platform.Android")
    ):
        evil_restart_kodi()
    log_message = "Kodi wird für den Neustart beendet." if restart else "Kodi wird hart beendet (Force Close)."
    evil_log(log_message, xbmc.LOGINFO)
    try:
        xbmc.sleep(250)
    except Exception:
        pass
    os._exit(1)


def evil_android_package():
    try:
        with open("/proc/self/cmdline", "rb") as handle:
            value = handle.read(256).split(b"\0", 1)[0].decode("utf-8", "ignore").strip()
    except (OSError, UnicodeError):
        value = ""
    if re.match(r"^[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z0-9_]+)+$", value):
        return value
    return "org.xbmc.kodi"


def evil_schedule_android_restart():
    package = evil_android_package()
    command = (
        "sleep 5; "
        "/system/bin/am start -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -n {0}/.Splash >/dev/null 2>&1 || "
        "/system/bin/am start -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -n {0}/.Main >/dev/null 2>&1 || "
        "/system/bin/monkey -p {0} -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1"
    ).format(package)
    arguments = ["/system/bin/sh", "-c", command]
    options = {
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "close_fds": True,
    }
    try:
        try:
            subprocess.Popen(arguments, start_new_session=True, **options)
        except TypeError:
            subprocess.Popen(arguments, **options)
        evil_log("Android-Neustart angefordert: %s" % package, xbmc.LOGINFO)
        return True
    except Exception as error:
        evil_log("Android-Neustart konnte nicht angefordert werden: %s" % error, xbmc.LOGWARNING)
        return False


def evil_restart_kodi():
    if xbmc.getCondVisibility("System.Platform.Android"):
        return evil_schedule_android_restart()
    if xbmc.getCondVisibility("System.Platform.Windows"):
        return evil_schedule_windows_restart()
    xbmc.executebuiltin("RestartApp")
    xbmc.sleep(5000)
    return False


def evil_parse_builds(text, base=""):
    content = (text or "").lstrip("\ufeff").strip()
    if not content:
        return []
    builds = []
    if content.startswith("{") or content.startswith("["):
        try:
            data = json.loads(content)
        except ValueError:
            return []
        if isinstance(data, dict):
            items = data.get("builds")
            if items is None:
                items = data.get("items")
        else:
            items = data
        if isinstance(items, list):
            for item in items:
                entry = evil_build_entry(item, base)
                if entry:
                    builds.append(entry)
        return builds
    try:
        root = ElementTree.fromstring(content)
    except ElementTree.ParseError:
        root = None
    if root is not None:
        for node in root.iter():
            tag = node.tag.split("}")[-1].lower()
            if tag not in ("build", "item"):
                continue
            data = {key.lower(): (value or "").strip() for key, value in node.attrib.items()}
            for child in node:
                child_tag = child.tag.split("}")[-1].lower()
                data[child_tag] = (child.text or "").strip()
            entry = evil_build_entry(data, base)
            if entry:
                builds.append(entry)
        return builds
    if re.search(r"(?m)^\s*name\s*=\s*\"", content):
        for block in re.split(r"(?=^\s*name\s*=\s*\")", content, flags=re.M):
            fields = {}
            for key, value in re.findall(r"(?m)^\s*([A-Za-z_]+)\s*=\s*\"(.*)\"\s*$", block):
                fields[key.lower()] = value
            entry = evil_build_entry(fields, base)
            if entry:
                builds.append(entry)
        return builds
    for line in content.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = [part.strip() for part in re.split(r"[|;]", line)]
        if len(parts) >= 3:
            data = {"name": parts[0], "version": parts[1], "url": parts[2]}
        elif len(parts) == 2:
            data = {"name": parts[0], "url": parts[1]}
        elif len(parts) == 1 and "://" in parts[0]:
            data = {"name": parts[0].rstrip("/").rsplit("/", 1)[-1], "url": parts[0]}
        else:
            continue
        entry = evil_build_entry(data, base)
        if entry:
            builds.append(entry)
    return builds


class EvilInstaller:
    def __init__(self):
        self.evil_addon = xbmcaddon.Addon()
        self.evil_id = self.evil_addon.getAddonInfo("id")
        self.evil_path = self.evil_addon.getAddonInfo("path")
        self.evil_progress = None
        self.evil_cancelled = None
        self.evil_repo_index = None
        self.evil_last_error = ""

    def attach(self, progress, cancelled):
        self.evil_progress = progress
        self.evil_cancelled = cancelled

    def evil_reset_manual_build_installed(self):
        return evil_set_setting_bool("build_manual_installed", False)

    def evil_config_path(self):
        return os.path.join(self.evil_data_path(), "itspossible.json")

    def evil_config_bundled_path(self):
        return os.path.join(self.evil_path, "resources", "itspossible.json")

    def evil_config_paths(self):
        paths = [self.evil_config_path()]
        bundled = self.evil_config_bundled_path()
        if os.path.normcase(os.path.abspath(bundled)) != os.path.normcase(os.path.abspath(paths[0])):
            paths.append(bundled)
        return paths

    def evil_config_read_path(self):
        path = self.evil_config_path()
        if os.path.isfile(path):
            return path
        bundled = self.evil_config_bundled_path()
        if os.path.isfile(bundled):
            return bundled
        legacy = os.path.join(self.evil_path, "resources", "evil.json")
        if os.path.isfile(legacy):
            return legacy
        return path

    def load_config(self):
        path = self.evil_config_read_path()
        try:
            with open(path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError) as error:
            evil_log("%s nicht lesbar: %s" % (os.path.basename(path), error), xbmc.LOGERROR)
            return None
        data.setdefault("sources", [])
        data.setdefault("addons", [])
        data.setdefault("build_sources", [])
        data["active_build_source"] = data.get("active_build_source") or data.get("build_source_id", "")
        data.setdefault("show_adult", False)
        data.setdefault("autostart", True)
        data.setdefault("maintenance_autostart", [])
        data.setdefault("installed_build", data.get("build"))
        data.setdefault("appearance", {})
        if not isinstance(data["appearance"], dict):
            data["appearance"] = {}
        last_url = str(data.get("last_build_url") or "").strip()
        stored_last_url = evil_last_build_url()
        hydrated_last_url = False
        if last_url:
            if last_url != stored_last_url:
                evil_set_last_build_url(last_url)
        elif stored_last_url:
            data["last_build_url"] = stored_last_url
            hydrated_last_url = True
        if not data["build_sources"] and data.get("build_list"):
            source_id = data["active_build_source"] or "build-list"
            data["build_sources"].append({
                "id": source_id,
                "name": "Build-Liste",
                "url": data["build_list"],
            })
            data["active_build_source"] = source_id
        for source in data["build_sources"]:
            if isinstance(source, dict):
                for key in list(source):
                    if key not in ("id", "name", "url"):
                        source.pop(key)
        source_ids = {source.get("id", "") for source in data["build_sources"]}
        configured = data.get("active_build_sources")
        active_ids = []
        if isinstance(configured, list):
            for source_id in configured:
                if source_id in source_ids and source_id not in active_ids:
                    active_ids.append(source_id)
        else:
            if data["active_build_source"] in source_ids:
                active_ids.append(data["active_build_source"])
            if not active_ids and data["build_sources"]:
                active_ids = [data["build_sources"][0].get("id", "")]
        data["active_build_sources"] = active_ids
        data["active_build_source"] = active_ids[0] if active_ids else ""
        allowed = {"name", "sources", "addons", "build_sources", "active_build_source", "active_build_sources", "show_adult", "autostart", "maintenance_autostart", "installed_build", "last_build_url", "build_sort", "build_sort_desc", "appearance"}
        for key in list(data):
            if key not in allowed:
                data.pop(key)
        if path != self.evil_config_path() or hydrated_last_url:
            self.save_config(data)
        return data

    def save_config(self, data):
        paths = self.evil_config_paths()
        data.setdefault("sources", [])
        data.setdefault("addons", [])
        data.setdefault("build_sources", [])
        data.setdefault("show_adult", False)
        data.setdefault("autostart", True)
        data.setdefault("maintenance_autostart", [])
        data.setdefault("installed_build", data.get("build"))
        data.setdefault("appearance", {})
        if not isinstance(data["appearance"], dict):
            data["appearance"] = {}
        last_url = str(data.get("last_build_url") or "").strip()
        if last_url:
            evil_set_last_build_url(last_url)
        for source in data["build_sources"]:
            if isinstance(source, dict):
                for key in list(source):
                    if key not in ("id", "name", "url"):
                        source.pop(key)
        source_ids = {source.get("id", "") for source in data["build_sources"]}
        configured = data.get("active_build_sources")
        active_ids = []
        if isinstance(configured, list):
            for source_id in configured:
                if source_id in source_ids and source_id not in active_ids:
                    active_ids.append(source_id)
        else:
            legacy = data.get("active_build_source", "")
            if legacy in source_ids:
                active_ids.append(legacy)
            if not active_ids and data["build_sources"]:
                active_ids = [data["build_sources"][0].get("id", "")]
        data["active_build_sources"] = active_ids
        data["active_build_source"] = active_ids[0] if active_ids else ""
        allowed = {"name", "sources", "addons", "build_sources", "active_build_source", "active_build_sources", "show_adult", "autostart", "maintenance_autostart", "installed_build", "last_build_url", "build_sort", "build_sort_desc", "appearance"}
        for key in list(data):
            if key not in allowed:
                data.pop(key)
        primary_saved = False
        for path in paths:
            temporary = path + ".tmp"
            try:
                directory = os.path.dirname(path)
                if directory:
                    os.makedirs(directory, exist_ok=True)
                with open(temporary, "w", encoding="utf-8") as handle:
                    json.dump(data, handle, indent=2, ensure_ascii=False)
                    handle.write("\n")
                os.replace(temporary, path)
                if path == paths[0]:
                    primary_saved = True
            except (OSError, ValueError) as error:
                level = xbmc.LOGERROR if path == paths[0] else xbmc.LOGWARNING
                evil_log("itspossible.json konnte nicht gespeichert werden (%s): %s" % (path, error), level)
                if os.path.isfile(temporary):
                    try:
                        os.remove(temporary)
                    except OSError:
                        pass
        return primary_saved

    def evil_data_path(self):
        path = xbmcvfs.translatePath("special://profile/addon_data/%s/" % self.evil_id)
        try:
            os.makedirs(path, exist_ok=True)
        except OSError as error:
            evil_log("Addon-Datenordner nicht anlegbar: %s" % error, xbmc.LOGWARNING)
        return path

    def evil_build_cache_path(self):
        return os.path.join(self.evil_data_path(), "build_cache.json")

    def evil_load_build_cache(self, url):
        path = self.evil_build_cache_path()
        try:
            with open(path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return [], 0
        sources = data.get("sources")
        if isinstance(sources, dict):
            cached = sources.get(url)
            data = cached if isinstance(cached, dict) else {}
        elif str(data.get("url") or "") != str(url or ""):
            return [], 0
        items = data.get("builds")
        if not isinstance(items, list):
            return [], 0
        builds = []
        for item in items:
            entry = evil_build_entry(item, url)
            if entry:
                builds.append(entry)
        try:
            saved = int(data.get("saved") or 0)
        except (TypeError, ValueError):
            saved = 0
        return builds, saved

    def evil_save_build_cache(self, url, builds):
        path = self.evil_build_cache_path()
        temporary = path + ".tmp"
        data = {}
        try:
            with open(path, "r", encoding="utf-8") as handle:
                existing = json.load(handle)
            if isinstance(existing, dict):
                data = existing
        except (OSError, ValueError):
            data = {}
        sources = data.get("sources")
        if not isinstance(sources, dict):
            sources = {}
            if data.get("url"):
                sources[str(data["url"])] = {
                    "saved": data.get("saved", 0),
                    "builds": data.get("builds", []),
                }
        sources[url] = {"saved": int(time.time()), "builds": builds}
        data = {"sources": sources}
        try:
            with open(temporary, "w", encoding="utf-8") as handle:
                json.dump(data, handle, indent=2, ensure_ascii=False)
                handle.write("\n")
            os.replace(temporary, path)
            return True
        except (OSError, ValueError) as error:
            evil_log("Build-Cache nicht speicherbar: %s" % error, xbmc.LOGWARNING)
            if os.path.isfile(temporary):
                try:
                    os.remove(temporary)
                except OSError:
                    pass
            return False

    def evil_clear_build_cache(self):
        path = self.evil_build_cache_path()
        try:
            if os.path.isfile(path):
                os.remove(path)
            return True
        except OSError as error:
            evil_log("Build-Cache nicht löschbar: %s" % error, xbmc.LOGWARNING)
            return False

    def evil_abort_check(self):
        if self.evil_cancelled is not None and self.evil_cancelled():
            raise EvilCancelled("IT'S-POSSIBLE abgebrochen")

    def evil_report(self, percent, label=""):
        if self.evil_progress is not None:
            self.evil_progress(max(0, min(100, int(percent))), label)
        if int(percent) < 100:
            self.evil_abort_check()

    def evil_download(self, url, target, label="", start=0, end=100):
        local = evil_local_file(url)
        if local:
            total = os.path.getsize(local)
            done = 0
            with open(local, "rb") as source, open(target, "wb") as handle:
                while True:
                    self.evil_abort_check()
                    chunk = source.read(EVIL_CHUNK)
                    if not chunk:
                        break
                    handle.write(chunk)
                    done += len(chunk)
                    percent = int(done * 100 / total) if total else 0
                    value = start + int((end - start) * percent / 100)
                    self.evil_report(value, "%s %d%%" % (label, percent))
            self.evil_report(end, "%s fertig" % label)
            return
        request = Request(url, headers={"User-Agent": EVIL_AGENT})
        with evil_urlopen(request, timeout=30) as response, open(target, "wb") as handle:
            total = int(response.headers.get("Content-Length") or 0)
            done = 0
            while True:
                self.evil_abort_check()
                chunk = response.read(EVIL_CHUNK)
                if not chunk:
                    break
                handle.write(chunk)
                done += len(chunk)
                percent = int(done * 100 / total) if total else 0
                value = start + int((end - start) * percent / 100)
                self.evil_report(value, "%s %d%%" % (label, percent))
        self.evil_report(end, "%s fertig" % label)

    def evil_fetch_text(self, url, label="", start=0, end=100):
        self.evil_report(start, "%s laden" % label)
        local = evil_local_file(url)
        if local:
            with open(local, "rb") as handle:
                raw = handle.read(5 * 1024 * 1024 + 1)
        else:
            request = Request(url, headers={"User-Agent": EVIL_AGENT})
            with evil_urlopen(request, timeout=30) as response:
                raw = response.read(5 * 1024 * 1024 + 1)
        if len(raw) > 5 * 1024 * 1024:
            raise ValueError("Die Build-Liste ist zu groß.")
        self.evil_report(end, "%s geladen" % label)
        return raw.decode("utf-8", "ignore")

    def evil_repository_addons(self):
        text = self.evil_fetch_text(EVIL_REPO_ADDONS_URL, "Kodi Media Addons")
        try:
            root = ElementTree.fromstring(text)
        except ElementTree.ParseError as error:
            raise ValueError("Addon-Liste nicht lesbar: %s" % error)
        addons = []
        seen = set()
        for node in root.findall("addon"):
            addon_id = (node.get("id") or "").strip()
            if not addon_id or addon_id in seen or addon_id.startswith(("repository.", "script.module.")):
                continue
            seen.add(addon_id)
            metadata = node.find("extension[@point='xbmc.addon.metadata']")
            summary = ""
            description = ""
            icon = ""
            fanart = ""
            if metadata is not None:
                for language in ("de_DE", "de", "en_GB"):
                    summary = summary or metadata.findtext("summary[@lang='%s']" % language) or ""
                    description = description or metadata.findtext("description[@lang='%s']" % language) or ""
                summary = summary or metadata.findtext("summary") or ""
                description = description or metadata.findtext("description") or ""
                assets = metadata.find("assets")
                if assets is not None:
                    icons = [(value.text or "").strip() for value in assets.findall("icon") if (value.text or "").strip()]
                    root_icons = [value for value in icons if "/" not in value]
                    icon = root_icons[0] if root_icons else (icons[0] if icons else "")
                    fanarts = [(value.text or "").strip() for value in assets.findall("fanart") if (value.text or "").strip()]
                    fanart = fanarts[0] if fanarts else ""
            addons.append({
                "id": addon_id,
                "name": evil_plain_text(node.get("name") or addon_id),
                "version": node.get("version") or "",
                "summary": evil_plain_text(summary),
                "description": evil_plain_text(description or summary or "Keine Beschreibung vorhanden."),
                "icon": evil_repository_asset_url(addon_id, icon),
                "fanart": evil_repository_asset_url(addon_id, fanart),
                "zip": "",
                "source": "Kodi Media Repository",
            })
        return addons


    def evil_repository_index(self):
        if self.evil_repo_index is not None:
            return self.evil_repo_index
        text = self.evil_fetch_text(EVIL_REPO_ADDONS_URL, "Addon-Abhängigkeiten")
        try:
            root = ElementTree.fromstring(text)
        except ElementTree.ParseError as error:
            raise ValueError("Abhängigkeiten nicht lesbar: %s" % error)
        index = {}
        for node in root.findall("addon"):
            addon_id = (node.get("id") or "").strip()
            if not addon_id:
                continue
            requires = []
            for item in node.findall("./requires/import"):
                dependency = (item.get("addon") or "").strip()
                if dependency:
                    requires.append({
                        "id": dependency,
                        "version": item.get("version") or "",
                        "optional": (item.get("optional") or "").lower() == "true",
                    })
            version = (node.get("version") or "").strip()
            index[addon_id] = {
                "requires": requires,
                "version": version,
                "zip": evil_repository_zip_url(addon_id, version),
            }
        self.evil_repo_index = index
        return index

    def evil_install_build(self, url, label="", turbo=False):
        url = evil_normalize_url(url)
        work = tempfile.mkdtemp(prefix="itspossible-build-", dir=EVIL_TEMP_DIR)
        try:
            zip_path = os.path.join(work, "build.zip")
            try:
                self.evil_download(url, zip_path, "%s laden" % label, 0, 40)
            except EvilCancelled:
                raise
            except Exception as error:
                raise ValueError("Build konnte nicht geladen werden: %s\n%s" % (url, error))
            self.evil_report(42, "Build prüfen")
            try:
                fast = not evil_safe_install_enabled()
                result = evil_extract_build(zip_path, self.evil_report, self.evil_abort_check, turbo=turbo, fast=fast)
            except zipfile.BadZipFile as error:
                raise ValueError("Die Build-Zip ist beschädigt: %s" % error)
            try:
                result["wizard_enabled"] = evil_activate_wizard()
            except Exception as error:
                evil_log("Wizard-Aktivierung fehlgeschlagen: %s" % error, xbmc.LOGERROR)
                result["wizard_enabled"] = False
            try:
                result["wizard_autoexec"] = evil_write_autoexec_enable()
            except Exception as error:
                evil_log("autoexec-Aktivierung fehlgeschlagen: %s" % error, xbmc.LOGERROR)
                result["wizard_autoexec"] = False
            try:
                foreign_wizards = evil_disable_foreign_wizards()
                result["foreign_wizards"] = foreign_wizards
                result["foreign_wizard_autoexec"] = evil_schedule_foreign_wizard_disable(foreign_wizards)
            except Exception as error:
                evil_log("Fremde Wizards konnten nicht deaktiviert werden: %s" % error, xbmc.LOGERROR)
                result["foreign_wizards"] = []
                result["foreign_wizard_autoexec"] = False
            return result
        finally:
            shutil.rmtree(work, ignore_errors=True)

    def evil_create_build(self, name, version="1.0", metadata=None, selection=None, turbo=False):
        safe = evil_safe_create_enabled()
        self.evil_report(0, "Turbo-Build vorbereiten" if turbo else "Build vorbereiten")
        build_dir = evil_build_dir(True)
        if not build_dir:
            raise ValueError("Bitte zuerst in den Einstellungen einen gültigen Build-Speicherort auswählen.")
        selected_addons = None
        selected_addon_data = None
        if isinstance(selection, dict):
            addon_values = selection.get("addons")
            data_values = selection.get("addon_data")
            selected_addons = {str(value) for value in addon_values} if isinstance(addon_values, (list, tuple, set)) else set()
            selected_addon_data = {str(value) for value in data_values} if isinstance(data_values, (list, tuple, set)) else set()
        excluded_dir = os.path.normcase(os.path.abspath(build_dir))
        files = []
        for root_name in ("addons", "userdata"):
            source_root = os.path.join(EVIL_HOME_DIR, root_name)
            if not os.path.isdir(source_root):
                continue
            for current, folders, names in os.walk(source_root):
                self.evil_abort_check()
                if os.path.normcase(os.path.abspath(current)) == excluded_dir:
                    folders[:] = []
                    continue
                relative_dir = os.path.relpath(current, EVIL_HOME_DIR).replace(os.sep, "/")
                folders[:] = [
                    folder for folder in folders
                    if not evil_build_excluded(relative_dir + "/" + folder)
                    and (selected_addons is None or relative_dir != "addons" or folder in selected_addons)
                    and (selected_addon_data is None or relative_dir != "userdata/addon_data" or folder in selected_addon_data)
                ]
                if root_name == "userdata" and relative_dir != "userdata":
                    if relative_dir != "userdata/addon_data" or selected_addon_data is None or selected_addon_data:
                        files.append((current, relative_dir + "/", True))
                for file_name in names:
                    self.evil_abort_check()
                    relative = relative_dir + "/" + file_name
                    if evil_build_excluded(relative):
                        continue
                    path = os.path.join(current, file_name)
                    if os.path.islink(path) or not os.path.isfile(path):
                        continue
                    files.append((path, relative, False))
        files.sort(key=lambda item: item[1].lower())
        if not files:
            raise ValueError("Keine Build-Dateien in addons/ oder userdata/ gefunden.")
        base = evil_build_file_name(name, version)
        target = os.path.join(build_dir, base + ".zip")
        counter = 2
        while os.path.exists(target):
            target = os.path.join(build_dir, "%s-%d.zip" % (base, counter))
            counter += 1
        temporary = target + ".tmp"
        total = len(files)
        packed_files = 0
        skipped = 0
        report_interval = None if safe else (1.0 if turbo else 0.2)
        last_report = [0.0]
        archive_options = {"allowZip64": True}
        if not safe:
            archive_options["compresslevel"] = 1
        try:
            with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, **archive_options) as archive:
                for index, (path, relative, is_dir) in enumerate(files):
                    self.evil_abort_check()
                    try:
                        archive.write(path, relative)
                        if not is_dir:
                            packed_files += 1
                    except OSError as error:
                        skipped += 1
                        evil_log("Build-Datei nicht packbar: %s (%s)" % (relative, error), xbmc.LOGWARNING)
                    percent = int((index + 1) * 100 / total)
                    if safe:
                        self.evil_report(percent, "Packe: %s" % os.path.basename(relative))
                    else:
                        now = time.time()
                        if percent >= 100 or now - last_report[0] >= report_interval:
                            last_report[0] = now
                            self.evil_report(percent, "Packe: %s" % os.path.basename(relative))
            if not packed_files:
                raise ValueError("Keine Dateien konnten in den Build gepackt werden.")
            os.replace(temporary, target)
        except Exception:
            if os.path.isfile(temporary):
                try:
                    os.remove(temporary)
                except OSError:
                    pass
            raise
        self.evil_report(100, "Build fertig")
        result = {
            "path": target,
            "files": packed_files,
            "skipped": skipped,
            "bytes": os.path.getsize(target),
            "mode": "safe" if safe else ("turbo" if turbo else "fast"),
        }
        if metadata:
            try:
                result["list_path"] = self.evil_write_build_list(target, name, version, metadata)
            except Exception as error:
                evil_log("Build-TXT nicht erstellbar: %s" % error, xbmc.LOGERROR)
                result["list_error"] = str(error)
        return result

    def evil_write_build_list(self, zip_path, name, version, metadata):
        data = metadata if isinstance(metadata, dict) else {}
        content = evil_build_list_text(
            name,
            version,
            data.get("url", ""),
            kodi=data.get("kodi", ""),
            description=data.get("description", ""),
            icon=data.get("icon", ""),
            fanart=data.get("fanart", ""),
            zip_name=os.path.basename(zip_path),
        )
        if not content:
            raise ValueError("Keine gültige Build-Adresse für die TXT-Datei.")
        list_path = os.path.splitext(zip_path)[0] + ".txt"
        temporary = list_path + ".tmp"
        try:
            with open(temporary, "w", encoding="utf-8", newline="\n") as handle:
                handle.write(content)
            os.replace(temporary, list_path)
            return list_path
        except OSError:
            if os.path.isfile(temporary):
                try:
                    os.remove(temporary)
                except OSError:
                    pass
            raise

    def evil_local_builds(self):
        folder = evil_build_dir(False)
        if not folder or not os.path.isdir(folder):
            return []
        try:
            names = os.listdir(folder)
        except OSError as error:
            evil_log("Build-Ordner nicht lesbar: %s" % error, xbmc.LOGWARNING)
            return []
        entries = []
        for name in names:
            if not name.lower().endswith(".zip"):
                continue
            path = os.path.join(folder, name)
            if not os.path.isfile(path):
                continue
            try:
                modified = os.path.getmtime(path)
                size_bytes = os.path.getsize(path)
            except OSError:
                modified = 0
                size_bytes = 0
            size_mb = size_bytes / (1024.0 * 1024.0) if size_bytes else None
            entries.append({
                "name": name[:-4] or "Lokaler Build",
                "version": "",
                "url": path,
                "kodi": "",
                "description": "Lokal gespeichert",
                "icon": "",
                "fanart": "",
                "size": evil_format_size_mb(size_mb),
                "size_mb": round(size_mb, 3) if size_mb is not None else None,
                "updated": int(modified) if modified else 0,
                "adult": False,
                "source": "Lokal",
                "modified": modified,
            })
        entries.sort(key=lambda entry: entry.get("modified", 0), reverse=True)
        for entry in entries:
            entry.pop("modified", None)
        return entries

    def evil_install_from_zip(self, url, label=""):
        work = tempfile.mkdtemp(prefix="itspossible-", dir=EVIL_TEMP_DIR)
        try:
            zip_path = os.path.join(work, "itspossible.zip")
            self.evil_download(url, zip_path, label)
            source = evil_unpack(zip_path, os.path.join(work, "unpacked"))
            if not source:
                evil_log("Kein addon.xml in %s gefunden" % url, xbmc.LOGERROR)
                return ""
            return evil_copy_into_addons(source)
        finally:
            shutil.rmtree(work, ignore_errors=True)


    def evil_install_repository_zip(self, addon_id, index):
        meta = index.get(addon_id) or {}
        zip_url = meta.get("zip") or ""
        if not zip_url:
            self.evil_last_error = "Addon nicht im Repository: %s" % addon_id
            return False
        try:
            installed = self.evil_install_from_zip(zip_url, "Addon: %s" % addon_id)
        except Exception as error:
            self.evil_last_error = "Download fehlgeschlagen: %s" % error
            return False
        if not installed:
            self.evil_last_error = "Addon konnte nicht geladen werden: %s" % addon_id
            return False
        if not evil_wait_until_installed(installed):
            self.evil_last_error = "Addon wurde nicht erkannt: %s" % addon_id
            return False
        evil_enable(installed)
        return True

    def evil_install_dependencies(self, addon_id, index, stack=None):
        stack = set(stack or ())
        meta = index.get(addon_id) or {}
        for item in meta.get("requires", []):
            dependency = item.get("id") or ""
            if not dependency or item.get("optional") or dependency.startswith("xbmc."):
                continue
            if dependency in stack:
                continue
            if evil_installed(dependency):
                evil_enable(dependency)
                if not self.evil_install_dependencies(dependency, index, stack | {addon_id}):
                    return False
                continue
            if not self.evil_install_dependency(dependency, index, stack | {addon_id}):
                return False
        return True

    def evil_install_dependency(self, addon_id, index, stack):
        if addon_id in stack:
            return True
        if addon_id not in index:
            self.evil_last_error = "Abhängigkeit fehlt: %s" % addon_id
            return False
        if not self.evil_install_dependencies(addon_id, index, stack | {addon_id}):
            return False
        if self.evil_install_repository_zip(addon_id, index):
            return True
        if not self.evil_last_error:
            self.evil_last_error = "Abhängigkeit nicht installierbar: %s" % addon_id
        return False

    def evil_install_from_repository(self, addon_id):
        self.evil_last_error = ""
        if not addon_id.startswith("repository."):
            evil_enable("repository.kodi.media")
        try:
            index = self.evil_repository_index()
        except Exception as error:
            self.evil_last_error = "Abhängigkeiten nicht prüfbar: %s" % error
            return False
        if not self.evil_install_dependencies(addon_id, index):
            return False
        if not self.evil_install_repository_zip(addon_id, index):
            return False
        return True

    def evil_install_entry(self, entry, is_source, label=""):
        zip_url = entry.get("zip", "")
        if zip_url:
            addon_id = self.evil_install_from_zip(zip_url, label)
            return bool(addon_id) and evil_wait_until_installed(addon_id)
        addon_id = entry.get("id", "")
        if not addon_id or is_source:
            return False
        return self.evil_install_from_repository(addon_id)

    def run_install(self, sources, addons):
        failures = []
        total = max(len(sources) + len(addons), 1)
        for position, entry in enumerate(sources):
            label = entry.get("name") or entry.get("id", "")
            self.evil_report(int(position * 100 / total), "Quelle: %s" % label)
            try:
                success = self.evil_install_entry(entry, True, label)
            except EvilCancelled:
                raise
            except Exception as error:
                evil_log("Quelle %s fehlgeschlagen: %s" % (label, error), xbmc.LOGERROR)
                success = False
            if not success:
                failures.append(label)
        for entry in sources:
            source_id = entry.get("id", "")
            if source_id and evil_installed(source_id):
                evil_enable(source_id)
        if sources or addons:
            xbmc.executebuiltin("UpdateAddonRepos")
            xbmc.sleep(2000)
        for index, entry in enumerate(addons):
            position = len(sources) + index
            label = entry.get("name") or entry.get("id", "")
            self.evil_report(int(position * 100 / total), "Addon: %s" % label)
            self.evil_last_error = ""
            try:
                success = self.evil_install_entry(entry, False, label)
            except EvilCancelled:
                raise
            except Exception as error:
                evil_log("Addon %s fehlgeschlagen: %s" % (label, error), xbmc.LOGERROR)
                success = False
                self.evil_last_error = str(error)
            if not success:
                if self.evil_last_error:
                    failures.append("%s: %s" % (label, self.evil_last_error))
                else:
                    failures.append(label)
            self.evil_last_error = ""
        self.evil_report(100, "IT'S-POSSIBLE fertig")
        return failures
