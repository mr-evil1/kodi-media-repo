import os
import sys

import xbmc
import xbmcgui
import xbmcaddon


def evil_start():
    addon = xbmcaddon.Addon()
    sys.path.insert(0, os.path.join(addon.getAddonInfo("path"), "resources", "lib"))
    arguments = [str(argument).lower() for argument in sys.argv[1:]]
    if "guide" in arguments:
        from evil_guide import evil_guide_open
        evil_guide_open()
        return
    from evil_app import EvilApp
    autostart = "autostart" in arguments
    EvilApp(autostart=autostart).run()


try:
    evil_start()
except Exception as error:
    xbmc.log("[IT'S-POSSIBLE WIZARD] Start fehlgeschlagen: %s" % error, xbmc.LOGERROR)
    xbmcgui.Dialog().ok("IT'S-POSSIBLE WIZARD", "Der Wizard konnte nicht gestartet werden.\n\n%s" % error)
