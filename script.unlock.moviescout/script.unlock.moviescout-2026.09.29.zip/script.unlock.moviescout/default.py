import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

_MAIN_ADDON_ID = 'plugin.video.moviescout'


def _main_addon():
    return xbmcaddon.Addon(_MAIN_ADDON_ID)


def is_unlicensed_allowed():
    return _main_addon().getSetting('scraper.allow_unlicensed') == 'true'


def _set_allow(val):
    _main_addon().setSetting('scraper.allow_unlicensed', 'true' if val else 'false')


def mark_asked():
    try:
        profile = xbmcvfs.translatePath(_main_addon().getAddonInfo('profile'))
        os.makedirs(profile, exist_ok=True)
        with open(os.path.join(profile, '.disclaimer_asked'), 'w') as f:
            f.write('1')
    except Exception:
        pass


def is_german():
    lang = xbmc.getInfoLabel('System.Language').lower()
    return 'german' in lang or 'deutsch' in lang or 'austria' in lang or 'oesterreich' in lang


def _show_status():
    german = is_german()
    if is_unlicensed_allowed():
        if german:
            xbmcgui.Dialog().ok(
                'MovieScout Unlock',
                'Nicht lizenzierte Streams sind bereits [B]aktiv[/B].\n\nZum Deaktivieren dieses Script erneut ausführen und ablehnen.'
            )
        else:
            xbmcgui.Dialog().ok(
                'MovieScout Unlock',
                'Non-licensed streams are already [B]active[/B].\n\nRun this script again and decline to deactivate.'
            )
        result = _show_revoke_dialog(german)
        if result:
            _set_allow(False)
            if german:
                xbmcgui.Dialog().notification('MovieScout Unlock', 'Nicht lizenzierte Streams deaktiviert.', xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                xbmcgui.Dialog().notification('MovieScout Unlock', 'Non-licensed streams deactivated.', xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        show_disclaimer(german)


def _show_revoke_dialog(german):
    if german:
        return xbmcgui.Dialog().yesno(
            'MovieScout Unlock',
            'Nicht lizenzierte Streams sind aktuell aktiv.\n\nMöchtest du den Zugang [B]deaktivieren[/B]?',
            nolabel='Abbrechen',
            yeslabel='Ja, deaktivieren'
        )
    else:
        return xbmcgui.Dialog().yesno(
            'MovieScout Unlock',
            'Non-licensed streams are currently active.\n\nDo you want to [B]deactivate[/B] access?',
            nolabel='Cancel',
            yeslabel='Yes, deactivate'
        )


def show_disclaimer(german):
    mark_asked()
    if german:
        title = 'Rechtlicher Hinweis'
        agree = 'Einverstanden'
        decline = 'Ablehnen'
        msg = (
            'RECHTLICHER HINWEIS\n\n'
            'Dieses Script schaltet im MovieScout Addon Streams von nicht lizenzierten Quellen frei.\n'
            'Dies kann in deinem Land illegal sein.\n\n'
            'Der Ersteller übernimmt KEINE Haftung.\n\n'
            'Mit Einverstanden bestätigst du:\n'
            '- Du kennst die Rechtslage in deinem Land\n'
            '- Du trägst die volle Verantwortung\n\n'
            'Möchtest du fortfahren?'
        )
    else:
        title = 'Legal Disclaimer'
        agree = 'I Agree'
        decline = 'Decline'
        msg = (
            'LEGAL DISCLAIMER\n\n'
            'This script unlocks streams from sources that are NOT licensed or authorized in the MovieScout addon.\n'
            'Accessing unlicensed content may be illegal in your country.\n\n'
            'The creator does NOT endorse or take responsibility for unlicensed content.\n\n'
            'By clicking I Agree you confirm that:\n'
            '- You are aware of the legal situation in your country\n'
            '- You accept full personal responsibility\n'
            '- The addon creator bears no liability\n\n'
            'Do you agree and wish to continue?'
        )

    result = xbmcgui.Dialog().yesno(
        'MovieScout Unlock – ' + title,
        msg,
        nolabel=decline,
        yeslabel=agree
    )

    if result:
        if german:
            confirm_title = 'Bitte bestätigen'
            confirm_msg = (
                'Du hast "[B]Einverstanden[/B]" gewählt,\n'
                'auch nicht lizenzierte Streams anzuzeigen.\n\n'
                'Bitte bestätigen.'
            )
            confirm_yes = 'Ja, ich bestätige'
            confirm_no = 'Nein, nur Legales'
        else:
            confirm_title = 'Please Confirm'
            confirm_msg = (
                'You have selected "[B]I Agree[/B]",\n'
                'including non-licensed streams.\n\n'
                'Please confirm.'
            )
            confirm_yes = 'Yes, I confirm'
            confirm_no = 'No, legal only'

        confirmed = xbmcgui.Dialog().yesno(
            'MovieScout Unlock – ' + confirm_title,
            confirm_msg,
            nolabel=confirm_no,
            yeslabel=confirm_yes
        )

        if confirmed:
            _set_allow(True)
            if german:
                xbmcgui.Dialog().notification('MovieScout Unlock', '⚠ Nicht lizenzierte Streams aktiviert – Nutzung auf eigene Gefahr!', xbmcgui.NOTIFICATION_WARNING, 5000)
            else:
                xbmcgui.Dialog().notification('MovieScout Unlock', '⚠ Non-licensed streams activated – use at your own legal risk!', xbmcgui.NOTIFICATION_WARNING, 5000)
        else:
            _set_allow(False)
            if german:
                xbmcgui.Dialog().notification('MovieScout Unlock', 'Nur lizenzierte Inhalte aktiv.', xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                xbmcgui.Dialog().notification('MovieScout Unlock', 'Licensed content only.', xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        _set_allow(False)
        if german:
            xbmcgui.Dialog().notification('MovieScout Unlock', 'Abgelehnt – nur lizenzierte Inhalte aktiv.', xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().notification('MovieScout Unlock', 'Declined – licensed content only.', xbmcgui.NOTIFICATION_INFO, 3000)


if __name__ == '__main__':
    _show_status()
