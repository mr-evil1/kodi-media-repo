import sys
import os
import json
import time
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from urllib.parse import urlencode, parse_qsl, quote

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON_PATH + '/icon.png'
FANART = ADDON_PATH + '/fanart.jpg'
WINDOW_HOME = xbmcgui.Window(10000)
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
DATA_FILE = os.path.join(PROFILE, 'data.json')

YT_ADDON_ID = 'plugin.video.youtube'
NP_ADDON_ID = 'plugin.video.kodi.newpipe'
PLAYER_NAMES = {YT_ADDON_ID: 'YouTube', NP_ADDON_ID: 'NewPipe'}


def _s(string_id):
    return ADDON.getLocalizedString(string_id)


def _addon_state(addon_id):
    request = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'Addons.GetAddonDetails',
        'params': {'addonid': addon_id, 'properties': ['enabled']},
    }
    try:
        result = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        details = result.get('result', {}).get('addon')
    except Exception:
        return 'missing'
    if not details:
        return 'missing'
    return 'enabled' if details.get('enabled') else 'disabled'


def _enable_addon(addon_id):
    request = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'Addons.SetAddonEnabled',
        'params': {'addonid': addon_id, 'enabled': True},
    }
    xbmc.executeJSONRPC(json.dumps(request))


def _detect_player():
    for addon_id in (YT_ADDON_ID, NP_ADDON_ID):
        if _addon_state(addon_id) == 'enabled':
            return addon_id
    return None


PLAYER = _detect_player()


def _check_requirements():
    if PLAYER:
        return True
    dialog = xbmcgui.Dialog()
    for addon_id in (YT_ADDON_ID, NP_ADDON_ID):
        if _addon_state(addon_id) == 'disabled':
            name = PLAYER_NAMES[addon_id]
            if dialog.yesno('KidsTube', _s(30304).format(name)):
                _enable_addon(addon_id)
                dialog.ok('KidsTube', _s(30305).format(name))
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return False
    options = [_s(30301), _s(30302), _s(30303)]
    choice = dialog.select('KidsTube - ' + _s(30300), options)
    if choice in (0, 1):
        addon_id = (YT_ADDON_ID, NP_ADDON_ID)[choice]
        xbmc.executebuiltin('InstallAddon({0})'.format(addon_id))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    return False


def _pin_active():
    return ADDON.getSettingBool('pin_enabled') and bool(ADDON.getSetting('pin_code'))


def _unlocked():
    try:
        stamp = float(WINDOW_HOME.getProperty('KidsTube.unlock') or 0)
    except ValueError:
        stamp = 0
    minutes = ADDON.getSettingInt('pin_unlock_minutes')
    return time.time() - stamp < minutes * 60


def _ask_pin():
    if _unlocked():
        return True
    code = xbmcgui.Dialog().input(
        _s(30400), type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT
    )
    if not code:
        return False
    if code == ADDON.getSetting('pin_code'):
        WINDOW_HOME.setProperty('KidsTube.unlock', str(time.time()))
        return True
    xbmcgui.Dialog().ok('KidsTube', _s(30401))
    return False


def _load_data():
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    data.setdefault('favorites', [])
    return data


def _save_data(data):
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)
    with open(DATA_FILE, 'w', encoding='utf-8') as handle:
        json.dump(data, handle, ensure_ascii=False)


def _build_url(**kwargs):
    return BASE_URL + '?' + urlencode(kwargs)


def _yt_url(raw_id):
    base = 'plugin://{0}/'.format(YT_ADDON_ID)
    if raw_id.startswith('playlist/'):
        return base + 'playlist/?action=default&list=' + raw_id.split('/', 1)[1]
    if raw_id.startswith('channel/'):
        return base + 'channel/' + raw_id.split('/', 1)[1] + '/'
    if raw_id.startswith('user/'):
        return base + 'user/' + raw_id.split('/', 1)[1] + '/'
    if raw_id.startswith('http'):
        return base + '?action=play&videoid=' + quote(raw_id, safe='')
    return base + 'channel/' + raw_id + '/'


def _np_channel(channel_url):
    return 'plugin://{0}/?action=channel&url={1}'.format(NP_ADDON_ID, quote(channel_url, safe=''))


def _np_url(raw_id):
    if raw_id.startswith('playlist/'):
        return 'plugin://{0}/?action=playlist&url={1}'.format(NP_ADDON_ID, raw_id.split('/', 1)[1])
    if raw_id.startswith('channel/'):
        return _np_channel('https://www.youtube.com/channel/' + raw_id.split('/', 1)[1])
    if raw_id.startswith('user/'):
        return _np_channel('https://www.youtube.com/user/' + raw_id.split('/', 1)[1])
    if raw_id.startswith('http'):
        return _np_channel(raw_id)
    return _np_channel('https://www.youtube.com/channel/' + raw_id)


def _plugin_url(raw_id):
    if PLAYER == YT_ADDON_ID:
        return _yt_url(raw_id)
    return _np_url(raw_id)


def _make_item(title, icon, description=''):
    li = xbmcgui.ListItem(label=title)
    thumb = icon if icon else ICON
    li.setArt({
        'thumb': thumb,
        'icon': thumb,
        'poster': thumb,
        'landscape': thumb,
        'fanart': FANART,
    })
    infotag = li.getVideoInfoTag()
    infotag.setTitle(title)
    infotag.setMediaType('video')
    if description:
        infotag.setPlot(description)
    return li


def _add_item(title, url, icon, description='', is_folder=True, context=None):
    li = _make_item(title, icon, description)
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=is_folder)


def _highlight(text):
    return '[COLORyellow]{0}[/COLOR]'.format(text)


CHANNELLIST = [
    (
        "[COLORred]Kinder[/COLOR] – Kanäle",
        "Kanäle",
        "https://yt3.googleusercontent.com/eVEM7kLayi8-pFKQ2jMVMqWMMf-Sj-LFtPD5oD5d4vctMxwa_MxvYkYQOihpO8YxHO3Fo8qHVA=s160-c-k-c0x00ffffff-no-rj",
        "Offizielle Kinder-Sender: KiKA, ZDFtivi, Sesamstraße, Disney Channel, Nickelodeon und viele mehr.",
    ),
    (
        "[COLORred]Kinder[/COLOR] – Filme",
        "Kinder Filme",
        "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",
        "Kinderfilme, Zeichentrickfilme, Familienkino, Pferdefilme, Tier- und Weihnachtsfilme – kostenlos von Netzkino und Nanoki.",
    ),
    (
        "[COLORred]Kinder[/COLOR] – Serien",
        "Kinder Serien",
        "https://yt3.googleusercontent.com/eVEM7kLayi8-pFKQ2jMVMqWMMf-Sj-LFtPD5oD5d4vctMxwa_MxvYkYQOihpO8YxHO3Fo8qHVA=s160-c-k-c0x00ffffff-no-rj",
        "Aktuelle und klassische Kinderserie: Peppa Pig, Feuerwehrmann Sam, Bob der Baumeister, Bibi Blocksberg, Tom & Jerry und viele mehr.",
    ),
    (
        "[COLORred]Kinder[/COLOR] – Klassiker",
        "Kinder Klassiker",
        "https://yt3.googleusercontent.com/m9EMpzxqRblZQ9CuD6_b-KZEbXeGs_fYern_BKeANOTlQTZ-YynVvcUTKpoo3I0gVQ3X_0A1qK4=s160-c-k-c0x00ffffff-no-rj",
        "Zeitlose Klassiker für Kinder: Flipper, Pan Tau, Die rote Zora, DEFA-Trickfilme und Spielfilme zu Weihnachten.",
    ),
    (
        "[COLORred]Kinder[/COLOR] – Märchen & Geschichten",
        "Kinder Geschichten",
        "https://yt3.googleusercontent.com/lARZK6WQ3oS0BX9U7ExdgAdcHSbazCDTHUvLoFF9FpFhY9tIPkBukcEVF2Ng0zknSHTvnj4q=s160-c-k-c0x00ffffff-no-rj",
        "Gutenachtgeschichten, Grimms Märchen, SimsalaGrimm, Sandmännchen und viele weitere Geschichten für Kinder.",
    ),
    (
        "[COLORred]Kinder[/COLOR] – Hörbücher & Hörspiele",
        "Kinder Buch",
        "https://yt3.googleusercontent.com/65wFWDo8cizVOOLeW5hDP7VLDmka6zrpXObnlobNOo8vlPg40skZwYISCtWj5Scg7_qFsDnXmw=s160-c-k-c0x00ffffff-no-rj",
        "Benjamin Blümchen, Bibi Blocksberg, Pumuckl, Grimm-Hörspiele und viele weitere Kinder-Hörspiele zum Zuhören.",
    ),
    (
        "[COLORred]Kinder[/COLOR] – Wissen",
        "Kinder Wissen",
        "https://yt3.googleusercontent.com/ytc/AIdro_nRrCb-aovIu_su17Fed1V8J70QdFKP_f6H_6mc7TOBoJo=s160-c-k-c0x00ffffff-no-rj",
        "Lehrreiche Inhalte für neugierige Kinder: Planet Schule, Checker Welt, ESA Paxi, Experimente und mehr.",
    ),
    (
        "[COLORred]Kinder[/COLOR] – Musik",
        "Kinder Musik",
        "https://yt3.googleusercontent.com/OZ_jeNxvsxe4NG-aefWNxG8NrKJTXoElYRQZ45ISKmXCVhu_RNSboaIMOKRfOWBveo61R9EeCg=s160-c-k-c0x00ffffff-no-rj",
        "Kinderlieder zum Mitsingen, Tanzen und Bewegen: Sing mit mir, Karaoke, Disney-Musik und mehr.",
    ),
    (
        "[COLORred]Kinder[/COLOR] – Nachrichten",
        "Kinder Nachrichten",
        "https://yt3.googleusercontent.com/IgitEsBoWmeD_xSHFMiu8nwOuGvlCSCtOzUQxSm_91VXPa1nzEOnb3lcFfrfZnpe_DWkoWEq6A=s160-c-k-c0x00ffffff-no-rj",
        "Aktuelle Nachrichten kindgerecht erklärt: logo!, WDR Kinder, Checker Tobi und mehr.",
    ),
    (
        "[COLORred]Kinder[/COLOR] – Tiere",
        "Kinder Tiere",
        "https://yt3.googleusercontent.com/ytc/AIdro_nRrCb-aovIu_su17Fed1V8J70QdFKP_f6H_6mc7TOBoJo=s160-c-k-c0x00ffffff-no-rj",
        "Tiere in freier Wildbahn und im Zoo: Dokumentationen, Tierfilme und Wissensformate rund um die Tierwelt.",
    ),
    (
        "[COLORred]Kinder[/COLOR] – Basteln & Kreativität",
        "Kinder Basteln",
        "https://yt3.googleusercontent.com/ytc/AIdro_mXiHnjWsyR6OwXG1zncEa08PxvWKnmVdc5Xo8XohfWLFs=s160-c-k-c0x00ffffff-no-rj",
        "Basteln, Malen, DIY und kreative Projekte für Kinder: Schritt-für-Schritt-Anleitungen zum Mitmachen.",
    ),
    (
        "[COLORred]Kinder[/COLOR] – Sport & Bewegung",
        "Kinder Sport",
        "https://yt3.googleusercontent.com/ytc/AIdro_nRrCb-aovIu_su17Fed1V8J70QdFKP_f6H_6mc7TOBoJo=s160-c-k-c0x00ffffff-no-rj",
        "Sport, Turnen, Yoga und Bewegungsspiele für Kinder – Spaß in Bewegung für drinnen und draußen.",
    ),
]

SUBLISTS = {
    'Kanäle': [
        ("KiKA von ARD & ZDF",                          "user/meinKiKA",                       "https://yt3.googleusercontent.com/eVEM7kLayi8-pFKQ2jMVMqWMMf-Sj-LFtPD5oD5d4vctMxwa_MxvYkYQOihpO8YxHO3Fo8qHVA=s160-c-k-c0x00ffffff-no-rj",   "Der offizielle YouTube-Kanal von KiKA – dem Kinder-Kanal von ARD und ZDF. Sendungen, Clips und mehr."),
        ("KiKANiNCHEN von ARD & ZDF",                   "channel/UCv4Pvhg1LY8U9E-XF8hn6WA",    "https://yt3.googleusercontent.com/PHGbrL1fSJgdN-1S69zDJ7GUVuw9ypSiq8skG1GAzxcESnwCgRYwv0yhe7sTR_5VS-NwjjIxyA=s160-c-k-c0x00ffffff-no-rj",   "KiKANiNCHEN – Sendungen und Lieder für die Kleinsten (0–6 Jahre) von KiKA."),
        ("ZDFtivi von ZDF",                             "user/ZDFtiviKinder",                   "https://yt3.googleusercontent.com/IgitEsBoWmeD_xSHFMiu8nwOuGvlCSCtOzUQxSm_91VXPa1nzEOnb3lcFfrfZnpe_DWkoWEq6A=s160-c-k-c0x00ffffff-no-rj",   "ZDFtivi – der Kinderkanal des ZDF mit Serien, Filmen und Wissensformaten."),
        ("Löwenzahn TV von ZDF",                        "channel/UCOPJAVJeBhqWL8k7K9Wx6SQ",    "https://yt3.googleusercontent.com/ytc/AIdro_lTKpWSboFuBYXfl3EhkZow8Yot6_lnmZRk3hEnvz32nQ0=s160-c-k-c0x00ffffff-no-rj",                    "Löwenzahn mit Fritz Fuchs – Naturwissen und Abenteuer für Kinder vom ZDF."),
        ("Sesamstraße von NDR",                         "user/SesamstrasseNDR",                 "https://yt3.googleusercontent.com/TsFEPe9IC45mP5kMx6fLabeF0vO5IGebWSp8E4AokyT3dyZwpy-3FDi8NIWFgLmBwYQkjiYLBg=s160-c-k-c0x00ffffff-no-rj",   "Die Sesamstraße vom NDR – Ernie, Bert, Elmo und Co. in klassischen und neuen Episoden."),
        ("Kindernetz von SWR",                          "user/Kindernetz",                      "https://yt3.googleusercontent.com/vKDz1wZkfM8HNFaYN7QQQciIJq65bmVAmOt6iKDdKhmtTzW5YJ7A-HpnAZhxMC6xfQoEn_5zXw=s160-c-k-c0x00ffffff-no-rj",  "Kindernetz vom SWR – Serien, Nachrichten und Wissensformate für Kinder."),
        ("Die Sendung mit der Maus von WDR",            "channel/UCRWSxXBnz9IRS4SgRhG2wpQ",    "https://yt3.ggpht.com/AB02vMc3urTNtF1fs8xC_beAkkB__S8J3cLiJpZ4vdMXLf2GOBlkd6RWkNGVqOdFjNkHmTrLaA=s176-c-k-c0x00ffffff-no-rj-mo",      "Die Maus erklärt die Welt – Lach- und Sachgeschichten vom WDR für Kinder jeden Alters."),
        ("Toggolino von SuperRTL",                      "user/TOGGOLINOde",                    "https://yt3.googleusercontent.com/cL_dcEztZBDvVCR5K3JNE3o5K5580xSNaETJonhzE2mK1fN1UdMYsWx5rr1essWmHBbL6a_2OA=s160-c-k-c0x00ffffff-no-rj",  "Toggolino von SuperRTL – Vorschulsendungen und Zeichentrickserien für kleine Kinder."),
        ("Disney Channel Deutschland",                  "user/DisneyChannelGermany",            "https://yt3.googleusercontent.com/c3_JbPq0s5lc_pfXglSsnNTMv4T-oEK6zvmQDBFqxmAmgmKn1yDm5141NzYqudS2qhzt50fDJw=s160-c-k-c0x00ffffff-no-rj",  "Offizieller Disney Channel Deutschland – Serien, Musikvideos und Clips."),
        ("Disney Junior Deutschland",                   "user/DisneyJuniorGermany",             "https://yt3.googleusercontent.com/lP2bAzpPZyCY_mEBPCwpCBRwHV6wc6nePDCjCuK2UoXx6uvnUpWeQ5iGxLmOpADOpFYR9jSbSJ4=s160-c-k-c0x00ffffff-no-rj", "Disney Junior Deutschland – Vorschulserien wie Doc McStuffins, Micky Maus und Co."),
        ("Nickelodeon Deutschland",                     "user/nickelodeonoffiziell",            "https://yt3.googleusercontent.com/mr1Sx4O0oKwfhM3kuRWGpKHU5OGIKgalPIx6HL47L_76MZUbPrCmXGxc4VEB-m_CN1X3-ZEy=s160-c-k-c0x00ffffff-no-rj",    "Nickelodeon Deutschland – SpongeBob, Paw Patrol, Teenage Mutant Ninja Turtles und mehr."),
        ("Cartoonito Deutschland",                      "channel/UChcDNaLm0F8GZY4fRhZEAeQ",    "https://yt3.googleusercontent.com/hvStglMjagBU8hzH2Ke4PYTs05Ock_2ryEK7pwZXRNXnok9hy8UaqsqF3JAgSph9SoI7UOFcYA=s160-c-k-c0x00ffffff-no-rj",  "Cartoonito Deutschland – Zeichentrick und Vorschulsendungen von Warner Bros."),
        ("Cartoon Network Deutschland",                 "user/cartoonnetworkde",                "https://yt3.googleusercontent.com/ytc/AIdro_nXPNGVJ3K15vK1QeDT_k0_3bGTyN7dhAxNm6o0StPVtCU=s160-c-k-c0x00ffffff-no-rj",                    "Cartoon Network Deutschland – Ben 10, The Amazing World of Gumball, Regular Show und mehr."),
        ("Nanoki – Kinderfilme & Lernserien",           "channel/UCF2IFFQyO5gbhvOCObh1WTQ",    "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Nanoki – kostenlose Kinderfilme, Lehrfilme und Lernserien in voller Länge auf Deutsch."),
        ("Karussell KinderTV",                          "channel/UCdT-eMkUGKqvVebDkn1KqlQ",    "https://yt3.googleusercontent.com/95cCyBJIjuANCB5IDAyHvang2jGlPBt_jbY__nNHOz6gFH5ErboDnmqb879peVqKnWrRX4gJxA=s160-c-k-c0x00ffffff-no-rj",  "Karussell – Kinderfernsehen mit Zeichentrick, Serien und Sendungen für junge Zuschauer."),
        ("Kinderlieder zum Mitsingen und Bewegen",      "channel/UCctbi1Jw2jiVhj2ogdwiFdA",    "https://yt3.googleusercontent.com/BGoTUkK-TRjC6fC1fFP700dgrV5cjuHw-O8OcgGnqsHi3RoeU7b0hKm-0eS4dDOg-PWs5lz9Ew=s160-c-k-c0x00ffffff-no-rj",  "Bunte Kinderlieder zum Mitsingen, Tanzen und Bewegen – für Kita und Zuhause."),
        ("Kinderlieder von Volker Rosin",               "channel/UC7HM-Pm3mLzZBvhJKFnL6oA",    "https://yt3.googleusercontent.com/JJrATrwxWPSfcl96xTQqdKCsPoRu-szzn_NTvazvFG9Vx8aAvTHZBT_WuznsbOuiClwdTf0RXw=s160-c-k-c0x00ffffff-no-rj",  "Volker Rosin – der Kinderlieder-König mit Hits wie 'Der Cowboy Joe' und 'Der Zirkus ist da'."),
        ("KIDFLIX",                                     "channel/UCBZZcF8BC0kvZL_-zM7yuFg",    "https://yt3.googleusercontent.com/ZHa7HKjK0Dj9-bg2AlM9Udts_3bItaKWEe7aEkvmvDAf1kDFpqfcTe9a0e8-GhbkiFQd8dm1IHI=s160-c-k-c0x00ffffff-no-rj",  "KIDFLIX – kostenlose Kinder- und Familienfilme in voller Länge."),
        ("Ric TV",                                      "user/RICTVChannel",                   "https://yt3.googleusercontent.com/ytc/AIdro_llzhDC24z43QbBNVmCWEuNP_1cVflbImhBIw2_7np6Bw=s160-c-k-c0x00ffffff-no-rj",                    "Ric TV – Kinderkanal mit Zeichentrickserien und Unterhaltung für Kinder."),
        ("[COLORyellow]Suche[/COLOR]",                  "__search__",                           ICON,                                                                                                                                          "Nach Kinder-Kanälen suchen."),
    ],

    'Kinder Filme': [
        ("Kinderfilme von Netzkino",            "playlist/PLfEblejE-l3k5xxDsBiKVhdNqWAuCIYRr",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Kostenlose Kinderfilme in voller Länge von Netzkino – deutsch synchronisiert."),
        ("Zeichentrickfilme von Netzkino",      "playlist/PLfEblejE-l3l8AwrdcuMp-p31uwBaJJXl",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Animationsfilme und Zeichentrickfilme für Kinder kostenlos von Netzkino."),
        ("Pferdefilme von Netzkino",            "playlist/PLfEblejE-l3k3qM4Q1GlnGdGeRjzlZvRn",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Spannende Pferdefilme für Kinder und Jugendliche – kostenlos von Netzkino."),
        ("Hundefilme von Netzkino",             "playlist/PLfEblejE-l3nIBgJeAv7KO1DPvC2yN8-5",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Hundefilme für die ganze Familie – tierische Abenteuer kostenlos von Netzkino."),
        ("Teenie Komödien von Netzkino",        "playlist/PLfEblejE-l3kyX48AXCaOnKFLxxkasxOM",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Lustige Teenie-Komödien für Jugendliche – kostenlos und werbefinanziert von Netzkino."),
        ("Familienkino von Netzkino",           "playlist/PLfEblejE-l3nta_dpVmIwGomgE_a3sm6g",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Familienfilme zum gemeinsamen Schauen – kostenlos von Netzkino."),
        ("Weihnachtskino von Netzkino",         "playlist/PLfEblejE-l3n9NKla09pwoYVLtnrL2kv3",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Weihnachtsfilme für die ganze Familie – kostenlose Weihnachtsstimmung von Netzkino."),
        ("Kinderkino von Netzkino",             "channel/UCmZUsl5MLqXIhuSTVP6x-EA",              "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Der Kinderkino-Kanal von Netzkino – alle Kinderfilme an einem Ort."),
        ("Kinderfilme von Nanoki",              "playlist/PLAroxwS0jZuS521YByzaxA6ZO5VO-ppXJ",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Kinderfilme in voller Länge – kostenlos und auf Deutsch von Nanoki."),
        ("Zeichentrickfilme von Nanoki",        "playlist/PLAroxwS0jZuQSy2pjwruhzz44-kQ0YHEh",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Animationsfilme und Zeichentrick in voller Länge – kostenlos von Nanoki."),
        ("Tierfilme von Nanoki",                "playlist/PLAroxwS0jZuQQlgJJ3_-imn1abL4A4Zlc",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Tierfilme für Kinder – Abenteuer mit Wildtieren und Haustieren von Nanoki."),
        ("Hundefilme von Nanoki",               "playlist/PLAroxwS0jZuQC6yoU8LJF3USzgQBlrzx5",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Hundeabenteuer für die ganze Familie – kostenlos von Nanoki."),
        ("Familienfilme von Nanoki",            "playlist/PLAroxwS0jZuQUBhbxcAUlfh9qeJGV_tom",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Familienfilme für Jung und Alt – kostenlos von Nanoki."),
        ("Weihnachtsfilme von Nanoki",          "playlist/PLAroxwS0jZuTLDgN-YeW2Yy0trylROSs4",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Weihnachtsfilme für die ganze Familie – kostenlos von Nanoki."),
        ("Kinderfilm Klassiker von Nanoki",     "playlist/PLAroxwS0jZuQUke_UTBPvbyCB27G0NtwA",   "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Unvergessliche Kinderfilm-Klassiker aus vergangenen Jahrzehnten – von Nanoki."),
        ("[COLORyellow]Suche[/COLOR]",          "__search__",                                    ICON,                                                                                                                                         "Nach Kinderfilmen suchen."),
    ],

    'Kinder Serien': [
        ("Feuerwehrmann Sam",                           "playlist/PLK-pDTpRfGThLNOPhnUn_442Sr3X94ehe",   "https://yt3.googleusercontent.com/ofigmXJBP1ws5e5PqlNPpNTHoEjf0CuYa8Wjg4EExWxqsyB_NppwXqSIi34EQGXAiROvzry_=s160-c-k-c0x00ffffff-no-rj",  "Feuerwehrmann Sam rettet das walisische Dorf Pontypandy – Abenteuer für Kinder ab 3 Jahren."),
        ("Bob der Baumeister",                          "channel/UC1gSKVovUYLmXoDnsTY039Q",              "https://yt3.googleusercontent.com/ytc/AIdro_libsJ_qNx01lsU8cqy4G3bQQJGqPQvtqZwQwWPFF0oeA=s160-c-k-c0x00ffffff-no-rj",                    "Bob der Baumeister – Ja, wir schaffen das! Bauprojekte und Teamarbeit für Kleinkinder."),
        ("Bob der Baumeister DVD",                      "playlist/PLiK4BrMh3Fy8z0X2Q1nh9Ts5Uq_XVXoB1",  "https://yt3.googleusercontent.com/ytc/AIdro_libsJ_qNx01lsU8cqy4G3bQQJGqPQvtqZwQwWPFF0oeA=s160-c-k-c0x00ffffff-no-rj",                    "Bob der Baumeister – DVD-Episoden in voller Länge."),
        ("Peppa Pig",                                   "playlist/PLIHhW2rjlyqazX9VsDH3OB_BvXu3y2arK",  "https://yt3.googleusercontent.com/ytc/AIdro_lXig6Qp5KuxzRLn4K_hmZOEzB3o9eI9bz-ALdaOP9wAg=s160-c-k-c0x00ffffff-no-rj",                    "Peppa Wutz und ihre Familie – die beliebte britische Vorschulserie auf Deutsch."),
        ("Die Fixies",                                  "playlist/PLMu5a51zMv6zUI7ydYUdLkwHLyAq9mlw5",  "https://yt3.googleusercontent.com/bsnnz9N70ntIDrDuRaXY4KNU_WKUu94V-MuaXCdqGgsvz17Ekju_1VZRNLzLLvHwSVYi8ZZBaQ=s160-c-k-c0x00ffffff-no-rj",  "Die Fixies – winzige Wesen, die in Maschinen und Geräten leben, und dabei viel Wissen vermitteln."),
        ("Caillou",                                     "playlist/PLYbELRCXraUV5CxUx0VFqALe5B2NOnDM-",  "https://yt3.googleusercontent.com/ytc/AIdro_l30kpdJm0Ir6rselzA8yAhAidkjxmm89coucfOyagQBw=s160-c-k-c0x00ffffff-no-rj",                    "Caillou – der neugierige kleine Junge, der die Welt entdeckt. Vorschulserie auf Deutsch."),
        ("Tom der Abschleppwagen",                      "playlist/PLfrJ8rAzdNSWKpsTGcZGNLyjsVDiwyj90",  "https://yt3.googleusercontent.com/vMiHUQlNXiHl1eJmx1-tErx29DBt4beiSPJ50e0V4MjA1O0VFPUbvIOKW2HbqiG7RKC30rATHg=s160-c-k-c0x00ffffff-no-rj",  "Tom der Abschleppwagen – Abenteuer auf der Baustelle für Kleinkinder."),
        ("Bali",                                        "playlist/PL73AN-YruC-Ah9yKL8v09fB0nI-Ygt5I4",  "https://yt3.googleusercontent.com/ytc/AIdro_kliL7apFXyhzAB7eDHAYELARqUYf0Q1NSIuU1QHJpUvQ=s160-c-k-c0x00ffffff-no-rj",                    "Bali – ein kleiner Bär mit großen Träumen. Zeichentrickserie für Kinder."),
        ("Der kleine Nick",                             "channel/UCzNZ46g2SGaC66WEjxIMYag",              "https://yt3.googleusercontent.com/ytc/AIdro_kMkfp1N13Gecb_TeoNizjvZq_m3qn5GEAtsOsJf3sTZQ=s160-c-k-c0x00ffffff-no-rj",                    "Der kleine Nick – Abenteuer mit dem frechen Schuljungen aus der Comicserie von Goscinny."),
        ("Peter Pan – Spannende Abenteuer",             "playlist/PLEsSrAkc-N6rXexCXeRYvk3m69rYU6LmT",  "https://yt3.googleusercontent.com/ytc/AIdro_kElXO0Ln2cwmXqZECYT3wHnAUun28MduBMkPaFni_cOQ=s160-c-k-c0x00ffffff-no-rj",                    "Peter Pan – Abenteuer im Nimmerland mit dem Jungen, der nie erwachsen wird."),
        ("Barbie",                                      "channel/UCSTlH3dDtCBT94sjO2MTyww",              "https://yt3.googleusercontent.com/J5l0pIYLHcZByl5o70xs_fTVx0gqxN7FSl20UKtyne_EKszZlgsYqNrmnt9oAFUhUra70on8RA=s160-c-k-c0x00ffffff-no-rj",  "Barbie – Animationsserien und Kurzfilme rund um die ikonische Puppe."),
        ("Wendy – Pferde sind ihr Leben",               "playlist/PLAqP3cngI26r65PV1PZbYoSc5sjMHmt2_",  "https://yt3.googleusercontent.com/ytc/AIdro_kk9NKO2oocRNI-ehYC1KtIBaT06bOGBy_0lwxQY-SUVg=s160-c-k-c0x00ffffff-no-rj",                    "Wendy – die Pferdeliebhaberin auf dem Martinshof in aufregenden Reiterabenteuern."),
        ("Justice League DC Kids",                      "playlist/PLWH6DXF9upwP53YyfSKaLD_XbMwwgphuB",  "https://yt3.googleusercontent.com/ytc/AIdro_ny-OEqibjYRcfyTNpP0Gr7zBhthcHZRMYNrc116J4a9Q=s160-c-k-c0x00ffffff-no-rj",                    "Justice League – Superman, Batman, Wonder Woman und Co. in Animationsabenteuern für Kinder."),
        ("Benjamin Blümchen",                           "playlist/PL1SAyTUFBb74hUX32r6aqasGENGL4YShb",  "https://yt3.googleusercontent.com/ytc/AIdro_nxryECurSuDeK6loDsbG2inLuGas2vBWi7zMCEYh-rlmo=s160-c-k-c0x00ffffff-no-rj",                    "Benjamin Blümchen – der sprechende Elefant aus dem Neustadt-Zoo und sein Freund Otto."),
        ("Bibi Blocksberg",                             "playlist/PLOZg6nrLYB7-EgluZK6CuMBzJtKhvFIAU",  "https://yt3.googleusercontent.com/ytc/AIdro_kaXwWIBwqekbuxe6Dhcrgw25Aywv4Ujp824KcTfD0DhxI=s160-c-k-c0x00ffffff-no-rj",                    "Bibi Blocksberg – die junge Hexe und ihre turbulenten Zaubereien in Neustadt."),
        ("Mister Bean",                                 "playlist/PLiDbV9ObbZLV_R9ofcSdJSPP4PSrobk3g",  "https://yt3.googleusercontent.com/ytc/AIdro_kU_LbBWM7nAscqjTm9cu4cxYE8U0u2nvccYpc2iIrHbg=s160-c-k-c0x00ffffff-no-rj",                    "Mister Bean – der komische Tollpatsch in zeitlosen Slapstick-Abenteuern für die ganze Familie."),
        ("Pink Panther – Klassik Serie (1)",            "playlist/PL546904B9DC923B31",                  "https://yt3.googleusercontent.com/ytc/AIdro_lEeZP6Urk3JhCp_BnVamf57KSdAv-ZJb2nJqHmW-8ZIuM=s160-c-k-c0x00ffffff-no-rj",                    "Der rosarote Panther – die originale Zeichentrickserie aus den 1960ern und 70ern."),
        ("Pink Panther – Neue Serie (2)",               "playlist/PL2MVdpCy9PxFMwC6UaXwNOTZMPUxiU6KB",  "https://yt3.googleusercontent.com/ytc/AIdro_lEeZP6Urk3JhCp_BnVamf57KSdAv-ZJb2nJqHmW-8ZIuM=s160-c-k-c0x00ffffff-no-rj",                    "Der rosarote Panther – die neue animierte Serie mit modernem Look."),
        ("Tom & Jerry – Klassik Serie (1)",             "playlist/PLUCHDQsTRtWb1AlJQV0_ojhg5hpLjpdC_",  "https://yt3.googleusercontent.com/l3sgu7fdZPWCiwrMak7lttvETa3QwED1ezhicGLc1kI3Q2ZyKe5bb3gP8OTwKx0aMNAIMy4YXw=s160-c-k-c0x00ffffff-no-rj",  "Tom & Jerry – die legendären Kurzfilme des Katz-und-Maus-Duos aus den 1940ern bis 60ern."),
        ("Tom & Jerry – Neue Serie (2)",                "playlist/PL2MVdpCy9PxFf_BZJfjTtNuXTBdyu1ig9",  "https://yt3.googleusercontent.com/l3sgu7fdZPWCiwrMak7lttvETa3QwED1ezhicGLc1kI3Q2ZyKe5bb3gP8OTwKx0aMNAIMy4YXw=s160-c-k-c0x00ffffff-no-rj",  "Tom & Jerry – die neue animierte Serie mit frischen Abenteuern."),
        ("Wickie und die starken Männer – Klassik (1)", "playlist/PLGP11O3gIZb-CAn5df2AE687pqGLxv2hr",  "https://yt3.googleusercontent.com/ytc/AIdro_kx_tPHk_DdII3m8ZTy6o9nCdp6vuGS6lC9zvZBcXrciCI=s160-c-k-c0x00ffffff-no-rj",                    "Wickie und die starken Männer – die Zeichentrickklassikerserie aus den 1970ern."),
        ("Wickie und die starken Männer – Neu (2)",     "playlist/PLGP11O3gIZb8jsxU_InVjehKgJy1Z1Eyj",  "https://yt3.googleusercontent.com/ytc/AIdro_kx_tPHk_DdII3m8ZTy6o9nCdp6vuGS6lC9zvZBcXrciCI=s160-c-k-c0x00ffffff-no-rj",                    "Wickie und die starken Männer – die neue 3D-Animationsserie."),
        ("Biene Maja – Klassik Serie (1)",              "playlist/PLdHRcaRTf6chVA47IIGwDRJbvgkgBS6Xz",  "https://yt3.googleusercontent.com/ytc/AIdro_k_scJq9HnRuToNP--3iIsRfqAAFa27DZG6X9yRS9C8Ctw=s160-c-k-c0x00ffffff-no-rj",                    "Biene Maja – das tapfere kleine Bienenmädchen in der klassischen Zeichentrickserie."),
        ("Biene Maja – Neue Serie (2)",                 "playlist/PLdHRcaRTf6cie56jn0JUsHVGMMSU4AqY-",  "https://yt3.googleusercontent.com/ytc/AIdro_k_scJq9HnRuToNP--3iIsRfqAAFa27DZG6X9yRS9C8Ctw=s160-c-k-c0x00ffffff-no-rj",                    "Biene Maja – die neue CGI-Animationsserie mit Maja und Willi."),
        ("Heidi – Klassik Serie (1)",                   "playlist/PLwz9HrBqSQF-WEycaVv_2m5o_4rmxICyn",  "https://yt3.googleusercontent.com/ytc/AIdro_k2eKhwRc8WZGXcGEg0LQvZATEqa9IMYrQ039nfznwc15M=s160-c-k-c0x00ffffff-no-rj",                    "Heidi – das Mädchen aus den Alpen in der japanischen Zeichentrickserie von 1974."),
        ("Heidi – Neue Serie (2)",                      "playlist/PLwz9HrBqSQF9Y9W6hf-AwwBxTunNYrFvA",  "https://yt3.googleusercontent.com/ytc/AIdro_k2eKhwRc8WZGXcGEg0LQvZATEqa9IMYrQ039nfznwc15M=s160-c-k-c0x00ffffff-no-rj",                    "Heidi – die neue CGI-Serie aus dem Jahr 2015 nach dem Romanklassiker."),
        ("Das Dschungelbuch – Klassik (1)",             "playlist/PLYekapbFEdMmzDN29jkQwATMx3BgznsdM",  "https://yt3.googleusercontent.com/ytc/AIdro_mvfRl7am0OpQD3Ctwcsl1ks-Y75vNtISY_z0IOJRhHJQ=s160-c-k-c0x00ffffff-no-rj",                    "Das Dschungelbuch – Moglis Abenteuer im Dschungel in der klassischen Zeichentrickserie."),
        ("Das Dschungelbuch – Neue Serie (2)",          "playlist/PL_YOcJJS3cSLJ6-4pXn9SURAkw8Z98FdV",  "https://yt3.googleusercontent.com/ytc/AIdro_mvfRl7am0OpQD3Ctwcsl1ks-Y75vNtISY_z0IOJRhHJQ=s160-c-k-c0x00ffffff-no-rj",                    "Das Dschungelbuch – die neue animierte Serie mit modernem 3D-Look."),
        ("Robin Hood – Klassik Serie (1)",              "playlist/PLYekapbFEdMlSWa8pmtr1EEQGI3lEofb3",  "https://yt3.googleusercontent.com/qcHBiOPL7Tr5VPT17va19m1756JeJ3ekce-UAno-HervduE-uXffo0KBxpdFKKjp2vM-pkCs=s160-c-k-c0x00ffffff-no-rj",  "Robin Hood – der edle Räuber aus Sherwood Forest in der klassischen Zeichentrickserie."),
        ("Robin Hood – Neue Serie (2)",                 "playlist/PLM5esjyCBU_qStUbQ_YqpE--k700AWoG5",  "https://yt3.googleusercontent.com/qcHBiOPL7Tr5VPT17va19m1756JeJ3ekce-UAno-HervduE-uXffo0KBxpdFKKjp2vM-pkCs=s160-c-k-c0x00ffffff-no-rj",  "Robin Hood – die neue Animationsserie mit frischen Geschichten aus Sherwood."),
        ("Die Schlümpfe – Klassik Serie (1)",           "playlist/PLe9POcs8knUCprw4_XXxTm8hkGBVw6NHs",  "https://yt3.googleusercontent.com/ytc/AIdro_lz1JwV2UcYvO3sU4glwAbVK7jXobyldkMW4I8LCyX_hEk=s160-c-k-c0x00ffffff-no-rj",                    "Die Schlümpfe – die kleinen blauen Wesen aus dem Pilzdorf in der Originals-Zeichentrickserie."),
        ("Simba der Löwenkönig – Klassik (1)",          "playlist/PLYekapbFEdMlAfVPEpc9EQxHP4nCIXd3T",  "https://yt3.googleusercontent.com/ytc/AIdro_nT99re9EdPau__EwlwulmRIW4GHKioxyPBsNlh88FBow=s160-c-k-c0x00ffffff-no-rj",                    "Simba der Löwenkönig – Abenteuer aus der afrikanischen Savanne in der Zeichentrickserie."),
        ("Christoph Columbus – Klassik (1)",            "playlist/PLYekapbFEdMnpBAXde80pONK86-k_TPFl",  "https://yt3.googleusercontent.com/ytc/AIdro_kwdQSy_A8r3HQ3nlzl8DZUTSPElLpishRBD2oxszbYig=s160-c-k-c0x00ffffff-no-rj",                    "Christoph Columbus – die Zeichentrickserie über den berühmten Entdecker."),
        ("Meister Eder & sein Pumuckl – Klassik (1)",   "playlist/PLpalD7hdQxE3nzQxRxxfmFk9D33EuPPtO",  "https://yt3.googleusercontent.com/ytc/AIdro_nXpiXiPR937WSN2duuEAg366vba-YUkAahxAOimfDi6w=s160-c-k-c0x00ffffff-no-rj",                    "Meister Eder und sein Pumuckl – der rothaarige Kobold und der alte Schreiner in München."),
        ("Lucky Luke",                                  "playlist/PLbfm0-ETt5G6yq5oFYSlAkaNLQXbOSttk",  "https://yt3.googleusercontent.com/ytc/AIdro_mcGqztk0W5DB34AR7JL0kcv2jmoJk49Re_SG8ZlH8bZA=s160-c-k-c0x00ffffff-no-rj",                    "Lucky Luke – der Cowboy, der schneller schießt als sein Schatten. Zeichentrickserie."),
        ("Die kleinen Strolche",                        "playlist/PLueQL19LT3Kbf6zvCwESHFOS7uPvUeTdr",  "https://yt3.googleusercontent.com/ytc/AIdro_kLWdfVshplzUekAptJLhCnd4vZR9tGVptbs1Jeo3X80w=s160-c-k-c0x00ffffff-no-rj",                    "Die kleinen Strolche (Our Gang) – die originalen Kurzfilme aus den 1920ern bis 1940ern."),
        ("Grisu der kleine Drache – Klassik (1)",       "playlist/PLfbRhPoVa4gNvf3OaRPHcvGpiTv_AJf9U",  "https://yt3.googleusercontent.com/IgitEsBoWmeD_xSHFMiu8nwOuGvlCSCtOzUQxSm_91VXPa1nzEOnb3lcFfrfZnpe_DWkoWEq6A=s160-c-k-c0x00ffffff-no-rj",  "Grisu der kleine Drache – der Drache, der lieber Feuerwehrmann werden will. Zeichentrickklassiker."),
        ("Alfred J Kwak – Klassik Serie (1)",           "playlist/PL58016D15BD79A97F",                  "https://yt3.googleusercontent.com/ytc/AIdro_kTe98feEy_Gbop5bwCS2BEOU2FyBqpvWL5hDNagEGysg=s160-c-k-c0x00ffffff-no-rj",                    "Alfred J. Kwak – die niederländische Zeichentrickserie über die Ente Alfred und seine Freunde."),
        ("Scooby Doo – Klassik Serie (1)",              "playlist/PLJYf0JdTApCqEYfW77tMTtqN-gA65_LPW",  "https://yt3.googleusercontent.com/R297M7jAVBV8_1NIsybn59l5XIvTVygHhrgu8F7iZCblqS-kHRGDWwDlOkR3Lgt13fHpYVvb=s160-c-k-c0x00ffffff-no-rj",  "Scooby-Doo – die Abenteuertruppe mit dem lustigen Hund löst Geheimnisse und jagt Monster."),
        ("Kleo das fliegende Einhorn – Staffel 1",      "playlist/PLx7XyMBfhgopl8zhHyagkK5MZP-CzXZCl",  "https://yt3.googleusercontent.com/m9EMpzxqRblZQ9CuD6_b-KZEbXeGs_fYern_BKeANOTlQTZ-YynVvcUTKpoo3I0gVQ3X_0A1qK4=s160-c-k-c0x00ffffff-no-rj",  "Kleo das fliegende Einhorn – magische Abenteuer mit dem bezaubernden Einhorn."),
        ("Jim Knopf (Zeichentrick) Staffel 1–2",        "playlist/PL3kvPcxZMm3asH5sX_M4kSvdkHCDwZn3h",  "https://yt3.googleusercontent.com/ytc/AIdro_kEiju73Tovm8K3dMsI2Wzhz6j8ZPyHZ6fb20wJDSbejg=s160-c-k-c0x00ffffff-no-rj",                    "Jim Knopf und Lukas der Lokomotivführer – die Zeichentrickserie nach Michael Endes Klassiker."),
        ("Zoes Zauberschrank",                          "playlist/PLPHcQYsAZvMA4PIV8JYR4ZZpJjZ8i4Jjs",  "https://yt3.googleusercontent.com/PHGbrL1fSJgdN-1S69zDJ7GUVuw9ypSiq8skG1GAzxcESnwCgRYwv0yhe7sTR_5VS-NwjjIxyA=s160-c-k-c0x00ffffff-no-rj",  "Zoes Zauberschrank – magische Abenteuer für Vorschulkinder."),
        ("Trotro",                                      "channel/UCAML9huAKtSutHftRbbNmTA",              "https://yt3.googleusercontent.com/tHrYXausgAx1JUVDSaQkxoyJ3YA7TXMNSUIZESsKGDJcrcTpHcpke_uLriqZqh3D9IRP2cs4pQ=s160-c-k-c0x00ffffff-no-rj",  "Trotro – der kleine, vorwitzige Esel, der eine Menge über das Leben lernt."),
        ("Tim & Struppi",                               "playlist/PLY25BVSAuho3YVOUhdzCvpE11y2GGz2Nf",  "https://yt3.googleusercontent.com/ytc/AIdro_m8aufXYahT6M_Ls2moneQrvHYYgZX-65jKnau6_euSbg=s160-c-k-c0x00ffffff-no-rj",                    "Tim und Struppi – der mutige Journalist und sein treuer Hund Milou in spannenden Abenteuern."),
        ("[COLORyellow]Suche[/COLOR]",                  "__search__",                                   ICON,                                                                                                                                          "Nach Kinderserien suchen."),
    ],

    'Kinder Klassiker': [
        ("Flipper – Staffel 1",                     "playlist/PLHEDxAYF32QJmHISru7c-MZn_sYt9MpCL",  "https://yt3.googleusercontent.com/ytc/AIdro_mHgXhrgT5R7YBXCB6jozpG7ASarqCaiT5qKVi5s2fIWA=s160-c-k-c0x00ffffff-no-rj",   "Flipper – der schlaue Delfin und seine Freunde Sandy und Bud in der Klassiker-Serie von 1964."),
        ("Flipper – Staffel 2",                     "playlist/PLHEDxAYF32QIXWcvfBkxxzmfW6xI-i4Gl",  "https://yt3.googleusercontent.com/ytc/AIdro_mHgXhrgT5R7YBXCB6jozpG7ASarqCaiT5qKVi5s2fIWA=s160-c-k-c0x00ffffff-no-rj",   "Flipper Staffel 2 – weitere Unterwasserabenteuer mit dem beliebtesten Delfin der Welt."),
        ("Flipper – Staffel 3",                     "playlist/PLHEDxAYF32QJPtxGimOndyo8VunXLk62Q",  "https://yt3.googleusercontent.com/ytc/AIdro_mHgXhrgT5R7YBXCB6jozpG7ASarqCaiT5qKVi5s2fIWA=s160-c-k-c0x00ffffff-no-rj",   "Flipper Staffel 3 – die letzte Staffel der legendären Delfinshow aus den 1960ern."),
        ("Pan Tau – Staffel 1–3",                   "playlist/PLx7XyMBfhgoo-6tYzBcnVJv4BCZC41q_W",  "https://yt3.googleusercontent.com/m9EMpzxqRblZQ9CuD6_b-KZEbXeGs_fYern_BKeANOTlQTZ-YynVvcUTKpoo3I0gVQ3X_0A1qK4=s160-c-k-c0x00ffffff-no-rj",  "Pan Tau – der geheimnisvolle Herr mit dem Zylinder, der Kindern aus der Patsche hilft. ČSSR-Klassiker."),
        ("Die rote Zora und ihre Bande – Alle Folgen", "playlist/PLx7XyMBfhgookKfFmo-hE7YfMCRA9YJIw", "https://yt3.googleusercontent.com/m9EMpzxqRblZQ9CuD6_b-KZEbXeGs_fYern_BKeANOTlQTZ-YynVvcUTKpoo3I0gVQ3X_0A1qK4=s160-c-k-c0x00ffffff-no-rj", "Die rote Zora und ihre Bande – die tapfere Bande rund um die rothaarige Zora in Senj."),
        ("Die Strandclique – Staffel 1",            "playlist/PLx7XyMBfhgoq2FJuMdl7RNh1TJGzZN7Kj",  "https://yt3.googleusercontent.com/m9EMpzxqRblZQ9CuD6_b-KZEbXeGs_fYern_BKeANOTlQTZ-YynVvcUTKpoo3I0gVQ3X_0A1qK4=s160-c-k-c0x00ffffff-no-rj",  "Die Strandclique – Sommerabenteuer einer Gruppe von Jugendlichen. Deutscher TV-Klassiker."),
        ("Gegen den Wind – Staffel 1",              "playlist/PLx7XyMBfhgoqH3sckwgLRpmSI06VTEWUX",  "https://yt3.googleusercontent.com/m9EMpzxqRblZQ9CuD6_b-KZEbXeGs_fYern_BKeANOTlQTZ-YynVvcUTKpoo3I0gVQ3X_0A1qK4=s160-c-k-c0x00ffffff-no-rj",  "Gegen den Wind – die beliebte Surfer-Serie mit Hardy Krüger jr. aus den 1990ern."),
        ("Trickfilm-Klassiker DEFA",                "playlist/PLx7XyMBfhgoq5obBLDvi58-ljZfZb0qzp",  "https://yt3.googleusercontent.com/m9EMpzxqRblZQ9CuD6_b-KZEbXeGs_fYern_BKeANOTlQTZ-YynVvcUTKpoo3I0gVQ3X_0A1qK4=s160-c-k-c0x00ffffff-no-rj",  "DEFA-Trickfilmklassiker – ostdeutsche Animationsfilme aus den Studios Babelsberg."),
        ("Spielfilmklassiker zu Weihnachten",       "playlist/PLx7XyMBfhgoqJHGE11Dr3oEhWMCDvRFLo",  "https://yt3.googleusercontent.com/m9EMpzxqRblZQ9CuD6_b-KZEbXeGs_fYern_BKeANOTlQTZ-YynVvcUTKpoo3I0gVQ3X_0A1qK4=s160-c-k-c0x00ffffff-no-rj",  "Spielfilmklassiker zu Weihnachten – zeitlose Weihnachtsfilme für die ganze Familie."),
        ("Kinderfilm Klassiker",                    "playlist/PLAroxwS0jZuTN6tscgrR_ubgHM4UaFBPv",  "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Kinderfilm-Klassiker in voller Länge – unvergessliche Filme aus verschiedenen Jahrzehnten."),
        ("[COLORyellow]Suche[/COLOR]",              "__search__",                                   ICON,                                                                                                                                          "Nach Kinder-Klassikern suchen."),
    ],

    'Kinder Geschichten': [
        ("Unser Sandmännchen von RBB",                      "user/sandmannshop",                   "https://yt3.googleusercontent.com/4cfX7kHTycQlmmphdCoFqqMcxBSbFmLZ05QdpjCANri0f0YJInrQwNj-MCH_IZl1onT_Wphvfg=s160-c-k-c0x00ffffff-no-rj",  "Unser Sandmännchen – der RBB-Klassiker bringt Kinder seit 1959 ins Bett. Gutenachtgeschichten."),
        ("German Fairy Tales",                              "playlist/PLYJXC9hVK9ZdUXMrhOTC-kpfIEwJQ2c0u", "https://yt3.googleusercontent.com/ytc/AIdro_m7h0lhnTJCALtmVQpnOTCXLO5ON9OpPIZ3X45mLlmftA=s160-c-k-c0x00ffffff-no-rj",   "Deutsche Märchen – Klassische Märchen auf Deutsch erzählt und animiert."),
        ("Märchen für Kinder – Gutenachtgeschichten",       "playlist/PLRSUQa10y6VFV1kYPPc1hH0kSksmCvGU1", "https://yt3.googleusercontent.com/ytc/AIdro_nLeRvtckO3nepGlumWyHZl8IE2KkUin8Mp3A3YYIHEMQ=s160-c-k-c0x00ffffff-no-rj",   "Beruhigende Gutenachtgeschichten und Märchen zum Einschlafen für Kinder."),
        ("Gute Nacht Geschichten – DE.BedtimeStory.TV",    "playlist/PLSeYZc0WTfTc-eqLP1bZLj0fJ13ZVfzBv", "https://yt3.googleusercontent.com/ytc/AIdro_ljVg3c7DXHAGU3leumLAX6txqgon5D9Re4uGQYzuleFw=s160-c-k-c0x00ffffff-no-rj",   "Gute-Nacht-Geschichten auf Deutsch – perfekt zum Einschlafen für Kleinkinder."),
        ("Deine Märchenwelt – Märchen, Geschichten, Sagen", "playlist/PLvsVeezf83quto2DL-5J4ZPmm2cYgwaFU", "https://yt3.googleusercontent.com/ytc/AIdro_nQkYXLLccuK_7aLuPMjZHAN4TVoiZkmqbleYIoaQHjxQ=s160-c-k-c0x00ffffff-no-rj",   "Märchen, Geschichten und Sagen aus aller Welt – auf Deutsch erzählt und bebildert."),
        ("Geschichten für Kinder",                          "playlist/PLT8zuqWPJkYAJI2jiNa67Q3YaRMOVR-uL", "https://yt3.googleusercontent.com/ytc/AIdro_l_cpO1x5DrRvlYSdq_LaO1q_Epc06e8S5Ofme2kFSdKw=s160-c-k-c0x00ffffff-no-rj",   "Schöne und lehrreiche Kurzgeschichten für Kinder – animiert und vorgelesen."),
        ("SimsalaGrimm",                                    "playlist/PLN5h7nQDQsiNAygibR61TxqtquFrvydt6", "https://yt3.googleusercontent.com/TPSvYLHHLDCNQea0b1viNt6mGEGs1We9vvnZMOeUcoILoektm_BDeVIlpcHNx5S1Gm7LFppZYg=s160-c-k-c0x00ffffff-no-rj", "SimsalaGrimm – die Brüder Grimm erzählen Märchen: Hänsel & Gretel, Rotkäppchen und viele mehr."),
        ("Grimms Märchen – Filme",                          "playlist/PL9A89EE24241DACF2",              "https://yt3.googleusercontent.com/AgKnoiN2B95xJcDsF3wbrIvDaMWNwJ1l4d8VMEOlnMHWLRi2tQfBlLNyPxSjryi6rMhW8NCYug=s160-c-k-c0x00ffffff-no-rj", "Grimms Märchen als Realfilm – Dornröschen, Schneewittchen, Rumpelstilzchen und Co."),
        ("[COLORyellow]Suche[/COLOR]",                      "__search__",                              ICON,                                                                                                                                          "Nach Märchen und Geschichten suchen."),
    ],

    'Kinder Buch': [
        ("Kinder- & Jugend Hörspiele – HoerTalk",  "playlist/PL6IcxBEYItDV7PWjFYdnHF9IsvAAGPaRx",  "https://yt3.googleusercontent.com/ytc/AIdro_lUNtb8xK82q6O4iYTaNYFxj2syawEI_o-iLsngDA7j0g=s160-c-k-c0x00ffffff-no-rj",   "Kinder- und Jugendhörspiele gesammelt von HoerTalk – stundenlanger Hörspaß."),
        ("Hörspiel Guru",                          "channel/UCCT5k5hwaSIRGoJ5vALZuMg",              "https://yt3.googleusercontent.com/65wFWDo8cizVOOLeW5hDP7VLDmka6zrpXObnlobNOo8vlPg40skZwYISCtWj5Scg7_qFsDnXmw=s160-c-k-c0x00ffffff-no-rj",   "Hörspiel Guru – ein breites Sortiment an Kinderhörspielen."),
        ("Jugend Hörspiele – Spooks",              "playlist/PLBCqvaIr4yUkjmEq5okDt5UAcNhqPgbq6",  "https://yt3.googleusercontent.com/3jjA5W1C714Oej9uSA9VcisLgT63t1Kpvssf4cTrflyesf4Du2ZxwjhURMt5QRkbrWf332vE=s160-c-k-c0x00ffffff-no-rj",  "Spannende Jugend-Hörspiele von Spooks – für Kinder und Jugendliche ab 8 Jahren."),
        ("Pumuckl Hörspiele 1960–1975",            "playlist/PLo-9MW9vCL30fO8QcGDyzusOFW3XLRVXB",  "https://yt3.googleusercontent.com/ytc/AIdro_nXpiXiPR937WSN2duuEAg366vba-YUkAahxAOimfDi6w=s160-c-k-c0x00ffffff-no-rj",                    "Pumuckl-Hörspiele aus den Original-Aufnahmen von 1960 bis 1975 – der Kobold vom Schreiner."),
        ("Tim & Struppi Hörspiele",                "playlist/PLkLkiOLu9xekbDC9aYJDftPBqPs8oCa8D",  "https://yt3.googleusercontent.com/65wFWDo8cizVOOLeW5hDP7VLDmka6zrpXObnlobNOo8vlPg40skZwYISCtWj5Scg7_qFsDnXmw=s160-c-k-c0x00ffffff-no-rj",   "Tim und Struppi als Hörspiel – die Abenteuer des Reporters als Audiofassung."),
        ("Benjamin Blümchen Hörspiele",            "playlist/PL1SAyTUFBb762GpJFH19_NvETovF_-NXu",  "https://yt3.googleusercontent.com/ytc/AIdro_nxryECurSuDeK6loDsbG2inLuGas2vBWi7zMCEYh-rlmo=s160-c-k-c0x00ffffff-no-rj",                    "Benjamin Blümchen Hörspiele – die Originalhörspiele mit Otto Gmelin und dem Elefanten."),
        ("Bibi Blocksberg Hörspiele",              "playlist/PLOZg6nrLYB79IpjmXsBPoq2tuW1DjEb1J",  "https://yt3.googleusercontent.com/ytc/AIdro_kaXwWIBwqekbuxe6Dhcrgw25Aywv4Ujp824KcTfD0DhxI=s160-c-k-c0x00ffffff-no-rj",                    "Bibi Blocksberg Hörspiele – die Hexen-Hörspiele für Kinder ab 5 Jahren."),
        ("Barbie Hörspiele",                       "playlist/PLnH8v4sKlmyDprODopPXEZQ3B28MYCkQC",  "https://yt3.googleusercontent.com/J5l0pIYLHcZByl5o70xs_fTVx0gqxN7FSl20UKtyne_EKszZlgsYqNrmnt9oAFUhUra70on8RA=s160-c-k-c0x00ffffff-no-rj",  "Barbie Hörspiele – Geschichten rund um Barbie und ihre Freundinnen zum Zuhören."),
        ("Grimms Märchen Hörspiele – Märchenwelt", "playlist/PL_7pajp36h-R_VBtOQMaFg7SAmlT02fX8",  "https://yt3.googleusercontent.com/lARZK6WQ3oS0BX9U7ExdgAdcHSbazCDTHUvLoFF9FpFhY9tIPkBukcEVF2Ng0zknSHTvnj4q=s160-c-k-c0x00ffffff-no-rj",  "Grimms Märchen als Hörspiel – vertonte Klassiker wie Schneewittchen, Aschenputtel und mehr."),
        ("Märchen Hörspiele – Hörspiel Fuchs",     "playlist/PL49N08rhGF4dp7S5egoLmLT50_MqtTtVD",  "https://yt3.googleusercontent.com/ytc/AIdro_mZpPJSHYcsJQ9rVpJ9-qXbsAvQF5rroosKij8JbP08_A=s160-c-k-c0x00ffffff-no-rj",                    "Märchen-Hörspiele vom Hörspiel Fuchs – wunderschön vertonte Kindergeschichten."),
        ("Klassische Hörspiele – Märchenwelt",     "playlist/PL_7pajp36h-QXzz1ncxNJFtg2GZzHV1dL",  "https://yt3.googleusercontent.com/lARZK6WQ3oS0BX9U7ExdgAdcHSbazCDTHUvLoFF9FpFhY9tIPkBukcEVF2Ng0zknSHTvnj4q=s160-c-k-c0x00ffffff-no-rj",  "Klassische Märchen-Hörspiele – zeitlose Geschichten zum Vorlesen und Zuhören."),
        ("Christliche Hörspiele – die Bibel",      "channel/UCJSF-0y7Pz7VUNH3cCdqwLw",              "https://yt3.googleusercontent.com/ytc/AIdro_m0D75VUeq8rjNhGPl80HH8WMqMhGBHk0p8t61jPzUDWw=s160-c-k-c0x00ffffff-no-rj",                    "Christliche Kinder-Hörspiele – Geschichten aus der Bibel kindgerecht erzählt."),
        ("Urmel Hörspiele",                        "playlist/PLa3cPVZ_c5hhE6mgOvbDAfLzxxiPDWkId",  "https://yt3.googleusercontent.com/65wFWDo8cizVOOLeW5hDP7VLDmka6zrpXObnlobNOo8vlPg40skZwYISCtWj5Scg7_qFsDnXmw=s160-c-k-c0x00ffffff-no-rj",   "Urmel Hörspiele – das Urmel aus dem Eis in den Originalhörspielen nach Max Kruse."),
        ("Tim und Struppi Hörspiel",               "playlist/PLa3cPVZ_c5hisrwl_5GopM5x57xDPauS7",  "https://yt3.googleusercontent.com/65wFWDo8cizVOOLeW5hDP7VLDmka6zrpXObnlobNOo8vlPg40skZwYISCtWj5Scg7_qFsDnXmw=s160-c-k-c0x00ffffff-no-rj",   "Tim und Struppi als Hörspiel-Serie – die vollständige Sammlung aller Abenteuer."),
        ("[COLORyellow]Suche[/COLOR]",             "__search__",                                   ICON,                                                                                                                                          "Nach Hörspielen und Hörbüchern suchen."),
    ],

    'Kinder Wissen': [
        ("KiWi – Schlaue Fragen, schlaue Antworten!",   "playlist/PLVWZ8fAnW6IbmOFpTtp6ImFFW-K4T83YN",  "https://yt3.googleusercontent.com/ytc/AIdro_nRrCb-aovIu_su17Fed1V8J70QdFKP_f6H_6mc7TOBoJo=s160-c-k-c0x00ffffff-no-rj",  "KiWi – das Wissensformat für Kinder: Warum ist der Himmel blau? Und andere spannende Fragen."),
        ("KiWi – Professor Schlaufuchs",                "playlist/PLVWZ8fAnW6IbqKL4j7uaR4RtPsqB6rKc0",  "https://yt3.googleusercontent.com/ytc/AIdro_nRrCb-aovIu_su17Fed1V8J70QdFKP_f6H_6mc7TOBoJo=s160-c-k-c0x00ffffff-no-rj",  "Professor Schlaufuchs von KiWi – Experimente und Erklärungen für neugierige Kinder."),
        ("Planet Schule von ARD",                       "playlist/PL93F091E59FDFDDBF",                  "https://yt3.googleusercontent.com/ytc/AIdro_nkghDj-XHzlJ0CCE1q4BXzL01ufINgm9KUiqfhaWTBjUnZ=s160-c-k-c0x00ffffff-no-rj",   "Planet Schule von ARD – Lehrfilme und Dokumentationen für Schüler aller Klassenstufen."),
        ("Checker Welt – Experimente",                  "playlist/PLXHkZNhCrU2ZGzKXPeq_8NY8ZF3coQyR9",  "https://yt3.googleusercontent.com/lOR8wZvBdSO56a4CXiQm45EPeUoQEUN8ctVFJW75MDgrL_sFJ8SPe5KrW0owlTKQJUcjz1pnQQ=s160-c-k-c0x00ffffff-no-rj", "Checker Welt – der Checker erklärt die Welt mit spannenden Experimenten für Kinder."),
        ("DIY Inspiration Kids Club – Experimente",     "playlist/PLjXEwjXTkbzqewdd_3DTgb0GZ_0LhECPJ",  "https://yt3.googleusercontent.com/ytc/AIdro_mXiHnjWsyR6OwXG1zncEa08PxvWKnmVdc5Xo8XohfWLFs=s160-c-k-c0x00ffffff-no-rj",   "DIY Inspiration Kids Club – Bastelideen, Experimente und kreative Projekte für Kinder."),
        ("PAXI – European Space Agency",                "playlist/PLbyvawxScNbvwcIVrGQV4p6g6cp9pH0To",  "https://yt3.googleusercontent.com/gnGJqh7iQPl66irKn3xdT9BDv2K7LOPMFghqL0MHQKk5XjmK-nD9r7CrdYcIEWFmSC0rlr_a=s160-c-k-c0x00ffffff-no-rj", "PAXI – das Maskottchen der ESA erklärt Weltraum und Astronomie kindgerecht."),
        ("[COLORyellow]Suche[/COLOR]",                  "__search__",                                   ICON,                                                                                                                                         "Nach Wissensinhalten für Kinder suchen."),
    ],

    'Kinder Musik': [
        ("Sing mit Mir – Kinderlieder",                                     "playlist/PLu791Jb5lWoCOzceiS6SDeGW_u1s7x-0h",  "https://yt3.googleusercontent.com/OZ_jeNxvsxe4NG-aefWNxG8NrKJTXoElYRQZ45ISKmXCVhu_RNSboaIMOKRfOWBveo61R9EeCg=s160-c-k-c0x00ffffff-no-rj",  "Sing mit mir – die beliebtesten deutschen Kinderlieder zum Mitsingen und Bewegen."),
        ("Hurra Kinderlieder",                                              "playlist/PLz8hTTrU37YTw06tseX2sHpXMbDK9x_Ds",  "https://yt3.googleusercontent.com/ytc/AIdro_kcnVO0eY6JzCRVjB2AUx7sndCRWLpdPnITOq2t06NaQQ=s160-c-k-c0x00ffffff-no-rj",                    "Hurra Kinderlieder – Spaß und Rhythmus mit bekannten deutschen Kinderliedern."),
        ("Kinderlieder zum Mitsingen und Tanzen",                           "playlist/PLM9BsUcYb5Mn8xN72IX5LUHj25_ssTN5_",  "https://yt3.googleusercontent.com/BGoTUkK-TRjC6fC1fFP700dgrV5cjuHw-O8OcgGnqsHi3RoeU7b0hKm-0eS4dDOg-PWs5lz9Ew=s160-c-k-c0x00ffffff-no-rj",  "Kinderlieder zum Mitsingen und Tanzen – bunte Videos für bewegungsfreudige Kinder."),
        ("Karaoke – Kinderlieder mit Biene Maja, Wickie & Co.",             "playlist/PLCywMP0BLGOk_cTbmLNENN711N3Yw0hRF",  "https://yt3.googleusercontent.com/ytc/AIdro_kQAr8CtbgD9MB9WP-U_AQsSDfAOVsQ4KsQliL2Ztc-T-E=s160-c-k-c0x00ffffff-no-rj",                    "Karaoke-Kinderlieder mit Texteinblendungen – Biene Maja, Wickie, Heidi und mehr."),
        ("Disney Titelmusik",                                               "playlist/PL4BrNFx1j7E6a6IKg8N0IgnkoamHlCHWa",  "https://yt3.ggpht.com/c3_JbPq0s5lc_pfXglSsnNTMv4T-oEK6zvmQDBFqxmAmgmKn1yDm5141NzYqudS2qhzt50fDJw=s176-c-k-c0x00ffffff-no-rj-mo",      "Disney Titelmusik – die Titellieder und Soundtracks der beliebtesten Disney-Filme und -Serien."),
        ("KinderliederTV.de",                                               "playlist/PLmMaywx47bx5w5YJ3uLJz73X81srE4wlQ",  "https://yt3.googleusercontent.com/puwtJUTPtemz8BDpE2ep4NL3RVqqNrwhQ2jBQ-Utkc32r6XJAbVHSXIJZLMWRMsAZhNHRj6fWR8=s160-c-k-c0x00ffffff-no-rj",  "KinderliederTV.de – eine große Sammlung der schönsten deutschen Kinderlieder mit Animation."),
        ("GiraffenaffenTV",                                                 "channel/UCUWTq9Jq97CNE9j28OarHbQ",              "https://yt3.googleusercontent.com/5f81fzOw1sMs0u9zlz8hUqXWrDJ5XWbdsTM3z2VMgoAsPX_cENGCip8_YI8Yx9xsp7BfDjmZyQ=s160-c-k-c0x00ffffff-no-rj",  "GiraffenaffenTV – witzige und interaktive Kinderlieder für Kleinkinder."),
        ("KiKA TanzAlarm",                                                  "playlist/PLIFhkWbVDf6wcorvcRTbQvSYvYemSvJoa",  "https://yt3.googleusercontent.com/eVEM7kLayi8-pFKQ2jMVMqWMMf-Sj-LFtPD5oD5d4vctMxwa_MxvYkYQOihpO8YxHO3Fo8qHVA=s160-c-k-c0x00ffffff-no-rj",  "KiKA TanzAlarm – Tanzen, Bewegen und Mitmachen mit den Liedern aus dem Kinderkanal."),
        ("[COLORyellow]Suche[/COLOR]",                                      "__search__",                                   ICON,                                                                                                                                          "Nach Kinderliedern und Musik suchen."),
    ],

    'Kinder Nachrichten': [
        ("logo! – Kindernachrichten von ZDF",           "user/logoKindernachrichten",              "https://yt3.googleusercontent.com/IgitEsBoWmeD_xSHFMiu8nwOuGvlCSCtOzUQxSm_91VXPa1nzEOnb3lcFfrfZnpe_DWkoWEq6A=s160-c-k-c0x00ffffff-no-rj",   "logo! – die tägliche Kindernachrichtensendung des ZDF, kindgerecht erklärt."),
        ("Die Sendung mit der Maus – Sachgeschichten",  "playlist/PLVRp7HvMtcJrp0y8s0OIQM6MFbTz7L-lf",  "https://yt3.ggpht.com/AB02vMc3urTNtF1fs8xC_beAkkB__S8J3cLiJpZ4vdMXLf2GOBlkd6RWkNGVqOdFjNkHmTrLaA=s176-c-k-c0x00ffffff-no-rj-mo",  "Die Maus erklärt – Sachgeschichten aus Die Sendung mit der Maus für wissbegierige Kinder."),
        ("Checker Tobi – Wissen & Nachrichten",         "channel/UCQlRSLDrQaOzBwbTIlFf1kA",         "https://yt3.googleusercontent.com/lOR8wZvBdSO56a4CXiQm45EPeUoQEUN8ctVFJW75MDgrL_sFJ8SPe5KrW0owlTKQJUcjz1pnQQ=s160-c-k-c0x00ffffff-no-rj", "Checker Tobi – erklärt die Welt für Kinder: Wie funktioniert das? Was steckt dahinter?"),
        ("Checker Kann – Wissen für Kinder",            "channel/UCX3mGCBMlSVBbIFuMkCTm-Q",         "https://yt3.googleusercontent.com/lOR8wZvBdSO56a4CXiQm45EPeUoQEUN8ctVFJW75MDgrL_sFJ8SPe5KrW0owlTKQJUcjz1pnQQ=s160-c-k-c0x00ffffff-no-rj", "Checker Kann – der Checker auf vier Pfoten erklärt Tiergeheimnisse für Kinder."),
        ("Kindernetz – Nachrichten von SWR",            "user/Kindernetz",                         "https://yt3.googleusercontent.com/vKDz1wZkfM8HNFaYN7QQQciIJq65bmVAmOt6iKDdKhmtTzW5YJ7A-HpnAZhxMC6xfQoEn_5zXw=s160-c-k-c0x00ffffff-no-rj",  "Kindernetz vom SWR – Nachrichten, Reportagen und Wissensformate für Kinder."),
        ("Planet Schule – Wissen für die Schule",       "playlist/PL93F091E59FDFDDBF",              "https://yt3.googleusercontent.com/ytc/AIdro_nkghDj-XHzlJ0CCE1q4BXzL01ufINgm9KUiqfhaWTBjUnZ=s160-c-k-c0x00ffffff-no-rj",   "Planet Schule – Lehrfilme und Erklärvideos für Schulkinder von ARD und ZDF."),
        ("[COLORyellow]Suche[/COLOR]",                  "__search__",                               ICON,                                                                                                                                          "Nach Kindernachrichten suchen."),
    ],

    'Kinder Tiere': [
        ("Löwenzahn – Natur & Tiere von ZDF",           "channel/UCOPJAVJeBhqWL8k7K9Wx6SQ",        "https://yt3.googleusercontent.com/ytc/AIdro_lTKpWSboFuBYXfl3EhkZow8Yot6_lnmZRk3hEnvz32nQ0=s160-c-k-c0x00ffffff-no-rj",                    "Löwenzahn mit Fritz Fuchs – Naturwissen und Tiergeheimnisse für Kinder vom ZDF."),
        ("Tierfilme von Nanoki",                        "playlist/PLAroxwS0jZuQQlgJJ3_-imn1abL4A4Zlc",  "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Tierfilme für Kinder – Abenteuer mit Wildtieren und Haustieren von Nanoki."),
        ("Hundefilme von Nanoki",                       "playlist/PLAroxwS0jZuQC6yoU8LJF3USzgQBlrzx5",  "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Hundeabenteuer für die ganze Familie – spannende Hundefilme kostenlos von Nanoki."),
        ("Hundefilme von Netzkino",                     "playlist/PLfEblejE-l3nIBgJeAv7KO1DPvC2yN8-5",  "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Hundefilme für Kinder und Familie – tierische Abenteuer kostenlos von Netzkino."),
        ("Checker Kann – Tiere entdecken",              "channel/UCX3mGCBMlSVBbIFuMkCTm-Q",         "https://yt3.googleusercontent.com/lOR8wZvBdSO56a4CXiQm45EPeUoQEUN8ctVFJW75MDgrL_sFJ8SPe5KrW0owlTKQJUcjz1pnQQ=s160-c-k-c0x00ffffff-no-rj", "Checker Kann – auf Tierspuren: Hunde, Pferde, Tintenfische und viele weitere Tiere."),
        ("PAXI – Natur & Planeten",                     "playlist/PLbyvawxScNbvwcIVrGQV4p6g6cp9pH0To",  "https://yt3.googleusercontent.com/gnGJqh7iQPl66irKn3xdT9BDv2K7LOPMFghqL0MHQKk5XjmK-nD9r7CrdYcIEWFmSC0rlr_a=s160-c-k-c0x00ffffff-no-rj", "PAXI von der ESA – Natur, Weltraum und die Erde erklärt für neugierige Kinder."),
        ("Tierfilme von Netzkino",                      "playlist/PLfEblejE-l3k3qM4Q1GlnGdGeRjzlZvRn",  "https://yt3.googleusercontent.com/OfyylHIKU_TcdZXA8gWLAv2Z7S4BhZtpDhRCDewnzvfgQkTfeSQGkrDeJSPr8CR_8XjlTLSB=s160-c-k-c0x00ffffff-no-rj",  "Tierfilme für Kinder – Pferdefilme, Tierabenteuer und Naturfilme kostenlos von Netzkino."),
        ("[COLORyellow]Suche[/COLOR]",                  "__search__",                               ICON,                                                                                                                                          "Nach Tierfilmen und Tierdokumentationen suchen."),
    ],

    'Kinder Basteln': [
        ("DIY Inspiration Kids Club – Basteln",     "channel/UCiKQpRHUY5GqNGQWDJVS8tg",         "https://yt3.googleusercontent.com/ytc/AIdro_mXiHnjWsyR6OwXG1zncEa08PxvWKnmVdc5Xo8XohfWLFs=s160-c-k-c0x00ffffff-no-rj",   "DIY Inspiration Kids Club – Bastelideen und kreative Projekte Schritt für Schritt für Kinder."),
        ("DIY Inspiration – Experimente & Basteln", "playlist/PLjXEwjXTkbzqewdd_3DTgb0GZ_0LhECPJ",  "https://yt3.googleusercontent.com/ytc/AIdro_mXiHnjWsyR6OwXG1zncEa08PxvWKnmVdc5Xo8XohfWLFs=s160-c-k-c0x00ffffff-no-rj",   "Bastelideen, Experimente und kreative Projekte für Kinder – einfach zum Nachmachen."),
        ("Art Attack – Disney Junior",              "user/DisneyJuniorGermany",                  "https://yt3.googleusercontent.com/lP2bAzpPZyCY_mEBPCwpCBRwHV6wc6nePDCjCuK2UoXx6uvnUpWeQ5iGxLmOpADOpFYR9jSbSJ4=s160-c-k-c0x00ffffff-no-rj", "Art Attack auf Disney Junior – kreative Bastelanleitungen und Kunstprojekte für Kinder."),
        ("KiWi – Basteln & Kreativität",            "playlist/PLVWZ8fAnW6IbmOFpTtp6ImFFW-K4T83YN",  "https://yt3.googleusercontent.com/ytc/AIdro_nRrCb-aovIu_su17Fed1V8J70QdFKP_f6H_6mc7TOBoJo=s160-c-k-c0x00ffffff-no-rj",  "KiWi – kreative Ideen und Bastelinspirationen für neugierige Kinder."),
        ("KiKA – Kreativ & Basteln",                "user/meinKiKA",                             "https://yt3.googleusercontent.com/eVEM7kLayi8-pFKQ2jMVMqWMMf-Sj-LFtPD5oD5d4vctMxwa_MxvYkYQOihpO8YxHO3Fo8qHVA=s160-c-k-c0x00ffffff-no-rj",   "KiKA – Bastelvideos, Kreativformate und Mitmachideen für Kinder aus dem Kinderkanal."),
        ("[COLORyellow]Suche[/COLOR]",              "__search__",                                ICON,                                                                                                                                          "Nach Bastelanleitungen und Kreativideen suchen."),
    ],

    'Kinder Sport': [
        ("KiKA – Sport & Bewegung",                 "user/meinKiKA",                             "https://yt3.googleusercontent.com/eVEM7kLayi8-pFKQ2jMVMqWMMf-Sj-LFtPD5oD5d4vctMxwa_MxvYkYQOihpO8YxHO3Fo8qHVA=s160-c-k-c0x00ffffff-no-rj",   "KiKA – Sportvideos, Bewegungsspiele und Fitness für Kinder aus dem Kinderkanal."),
        ("KiKA TanzAlarm – Tanzen & Bewegen",       "playlist/PLIFhkWbVDf6wcorvcRTbQvSYvYemSvJoa",  "https://yt3.googleusercontent.com/eVEM7kLayi8-pFKQ2jMVMqWMMf-Sj-LFtPD5oD5d4vctMxwa_MxvYkYQOihpO8YxHO3Fo8qHVA=s160-c-k-c0x00ffffff-no-rj",  "KiKA TanzAlarm – Tanzen, Bewegen und Mitmachen – Spaß mit Musik für Kinder."),
        ("Kinderlieder zum Mitsingen und Bewegen",  "channel/UCctbi1Jw2jiVhj2ogdwiFdA",           "https://yt3.googleusercontent.com/BGoTUkK-TRjC6fC1fFP700dgrV5cjuHw-O8OcgGnqsHi3RoeU7b0hKm-0eS4dDOg-PWs5lz9Ew=s160-c-k-c0x00ffffff-no-rj",  "Kinderlieder zum Mitsingen und Bewegen – Tanzen und aktiv sein für Kita und Zuhause."),
        ("Checker Tobi – Sport & Bewegung",         "channel/UCQlRSLDrQaOzBwbTIlFf1kA",           "https://yt3.googleusercontent.com/lOR8wZvBdSO56a4CXiQm45EPeUoQEUN8ctVFJW75MDgrL_sFJ8SPe5KrW0owlTKQJUcjz1pnQQ=s160-c-k-c0x00ffffff-no-rj", "Checker Tobi – testet Sportarten und Bewegungsaktivitäten für Kinder."),
        ("Die Sendung mit der Maus – Bewegen",      "channel/UCRWSxXBnz9IRS4SgRhG2wpQ",           "https://yt3.ggpht.com/AB02vMc3urTNtF1fs8xC_beAkkB__S8J3cLiJpZ4vdMXLf2GOBlkd6RWkNGVqOdFjNkHmTrLaA=s176-c-k-c0x00ffffff-no-rj-mo",      "Die Sendung mit der Maus – Sport und Bewegung kindgerecht erklärt und erlebt."),
        ("[COLORyellow]Suche[/COLOR]",              "__search__",                                ICON,                                                                                                                                          "Nach Sport und Bewegung für Kinder suchen."),
    ],
}


def _build_entry_index():
    index = {}
    for entries in SUBLISTS.values():
        for name, raw_id, icon, desc in entries:
            if raw_id != '__search__' and raw_id not in index:
                index[raw_id] = (name, icon, desc)
    return index


ENTRY_INDEX = _build_entry_index()


def _add_entry(raw_id, favorites):
    name, icon, desc = ENTRY_INDEX[raw_id]
    if raw_id in favorites:
        label = _s(30204)
        action = 'fav_remove'
    else:
        label = _s(30203)
        action = 'fav_add'
    context = [(label, 'RunPlugin({0})'.format(_build_url(action=action, id=raw_id)))]
    _add_item(name, _plugin_url(raw_id), icon, desc, context=context)


def _search_allowed():
    if not ADDON.getSettingBool('search_enabled'):
        xbmcgui.Dialog().ok('KidsTube', _s(30404))
        return False
    if _pin_active() and ADDON.getSettingBool('pin_protect_search'):
        return _ask_pin()
    return True


def _do_search(category):
    keyboard = xbmc.Keyboard('', _s(30402).format(category))
    keyboard.doModal()
    if not keyboard.isConfirmed() or not keyboard.getText():
        return None, None
    text = keyboard.getText()
    encoded = quote(text + ' ' + category + ' deutsch', safe='')
    if PLAYER == YT_ADDON_ID:
        url = 'plugin://{0}/kodion/search/query/?q={1}'.format(YT_ADDON_ID, encoded)
    else:
        url = 'plugin://{0}/?action=search_results&url={1}'.format(NP_ADDON_ID, encoded)
    return url, text


def main_menu():
    xbmcplugin.setPluginCategory(HANDLE, 'KidsTube 2')
    for name, cat, icon, desc in CHANNELLIST:
        _add_item(name, _build_url(action='sublist', category=cat), ICON, desc)
    _add_item(_highlight(_s(30200)), _build_url(action='favorites'), ICON)
    _add_item(_highlight(_s(30202)), _build_url(action='settings'), ICON)
    xbmcplugin.endOfDirectory(HANDLE)


def sub_list(category):
    xbmcplugin.setPluginCategory(HANDLE, category)
    favorites = _load_data()['favorites']
    search_enabled = ADDON.getSettingBool('search_enabled')
    for name, raw_id, icon, desc in SUBLISTS.get(category, []):
        if raw_id == '__search__':
            if search_enabled:
                _add_item(name, _build_url(action='search', category=category), icon, desc)
        else:
            _add_entry(raw_id, favorites)
    xbmcplugin.endOfDirectory(HANDLE)


def favorites_list():
    xbmcplugin.setPluginCategory(HANDLE, _s(30200))
    favorites = _load_data()['favorites']
    shown = [raw_id for raw_id in favorites if raw_id in ENTRY_INDEX]
    if not shown:
        xbmcgui.Dialog().notification('KidsTube', _s(30206), ICON, 4000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    for raw_id in shown:
        _add_entry(raw_id, favorites)
    xbmcplugin.endOfDirectory(HANDLE)


def favorite_add(raw_id):
    data = _load_data()
    if raw_id in data['favorites']:
        message = _s(30212)
    else:
        data['favorites'].append(raw_id)
        _save_data(data)
        message = _s(30208)
    xbmcgui.Dialog().notification('KidsTube', message, ICON, 3000)
    xbmc.executebuiltin('Container.Refresh')


def favorite_remove(raw_id):
    data = _load_data()
    data['favorites'] = [item for item in data['favorites'] if item != raw_id]
    _save_data(data)
    xbmcgui.Dialog().notification('KidsTube', _s(30209), ICON, 3000)
    xbmc.executebuiltin('Container.Refresh')


def show_search(category):
    if not _search_allowed():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    search_url, text = _do_search(category)
    if not search_url:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    label = _s(30403).format(text)
    li = _make_item(label, ICON)
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=search_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)


def open_settings():
    if _pin_active() and not _ask_pin():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    ADDON.openSettings()


def router():
    if not _check_requirements():
        return
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    raw_id = params.get('id', '')

    if action == 'fav_add':
        favorite_add(raw_id)
        return
    if action == 'fav_remove':
        favorite_remove(raw_id)
        return

    if _pin_active() and ADDON.getSettingBool('pin_protect_addon') and not _ask_pin():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if action == 'sublist':
        sub_list(params.get('category', ''))
    elif action == 'search':
        show_search(params.get('category', ''))
    elif action == 'favorites':
        favorites_list()
    elif action == 'settings':
        open_settings()
    else:
        main_menu()


router()
