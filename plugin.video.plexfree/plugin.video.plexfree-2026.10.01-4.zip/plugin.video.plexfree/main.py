# -*- coding: utf-8 -*-
# IT('s) Possible
# Plex Free Movies & Series
# 2026.10.01-4
import sys, html, time, uuid, threading, urllib.parse, requests, json, re, os
from concurrent.futures import ThreadPoolExecutor, as_completed
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

ADDON = xbmcaddon.Addon()
DEFAULT_ICON = ADDON.getAddonInfo('icon')

PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
SETTINGS_FILE = os.path.join(PROFILE_DIR, 'settings.json')

_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124.0.0.0 Safari/537.36'
_CLIENT_ID = str(uuid.uuid4())
_PLEX_MIN_INTERVAL, _PLEX_429_WAIT, _PLEX_TIMEOUT = 0.05, 2.0, 8
_WEB_MIN_INTERVAL, _WEB_TIMEOUT, _WEB_WORKERS = 0.05, 1.5, 12

def _dbg(msg):
    try:
        xbmc.log(f'[PlexFree Addon] {msg}', level=xbmc.LOGINFO)
    except Exception:
        pass

def _mask(token):
    t = str(token or '')
    return f'{t[:4]}...({len(t)})' if t else 'LEER'

def _get_setting(key, default='true'):
    try:
        val = ADDON.getSetting(key)
        if val != '': return val
    except Exception:
        pass
    try:
        if os.path.exists(SETTINGS_FILE):
            with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return str(data.get(key, default))
    except Exception:
        pass
    return default

def _set_setting(key, value):
    val_str = str(value)
    try:
        ADDON.setSetting(key, val_str)
    except Exception:
        pass
    try:
        os.makedirs(PROFILE_DIR, exist_ok=True)
        data = {}
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            except Exception:
                data = {}
        data[key] = val_str
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass

def is_german_filter_enabled():
    val = _get_setting('filter_german', 'true')
    return str(val).lower() == 'true'

def toggle_german_filter():
    current = is_german_filter_enabled()
    new_state = not current
    _set_setting('filter_german', 'true' if new_state else 'false')

    with _AUDIO_CACHE_LOCK:
        _AUDIO_CACHE.clear()
    with _CATEGORY_CACHE_LOCK:
        _CATEGORY_CACHE.clear()

_PLEX_RATE_LOCK, _PLEX_LAST_REQUEST = threading.Lock(), 0.0
_GUEST_TOKEN_LOCK, _GUEST_TOKEN = threading.Lock(), None
_WEB_RATE_LOCK, _WEB_LAST_REQUEST = threading.Lock(), 0.0
_WEB_META_LOCK, _WEB_META_CACHE = threading.Lock(), {}
_AUDIO_CACHE_LOCK, _AUDIO_CACHE = threading.Lock(), {}
_CATEGORY_CACHE_LOCK, _CATEGORY_CACHE = threading.Lock(), {}

def _plex_wait():
    global _PLEX_LAST_REQUEST
    with _PLEX_RATE_LOCK:
        wait = _PLEX_MIN_INTERVAL - (time.monotonic() - _PLEX_LAST_REQUEST)
        if wait > 0: time.sleep(wait)
        _PLEX_LAST_REQUEST = time.monotonic()

def _web_wait():
    global _WEB_LAST_REQUEST
    with _WEB_RATE_LOCK:
        wait = _WEB_MIN_INTERVAL - (time.monotonic() - _WEB_LAST_REQUEST)
        if wait > 0: time.sleep(wait)
        _WEB_LAST_REQUEST = time.monotonic()

def _safe_get(url, headers=None, params=None, timeout=8, retries=2):
    req_headers = dict(headers or {})
    req_headers.setdefault('User-Agent', _UA)
    req_headers.setdefault('Accept-Language', 'de-DE,de;q=0.9')
    shown = {k: (_mask(v) if 'token' in str(k).lower() else v) for k, v in (params or {}).items()}
    is_web = 'watch.plex.tv' in url
    for attempt in range(retries):
        if is_web: _web_wait()
        else: _plex_wait()
        t0 = time.monotonic()
        try:
            r = requests.get(url, headers=req_headers, params=params, timeout=timeout)
            code = getattr(r, 'status_code', None)
            _dbg(f'GET {url} params={shown} try={attempt + 1}/{retries} -> HTTP {code} in {time.monotonic() - t0:.2f}s')
            if code == 429:
                time.sleep(_PLEX_429_WAIT)
                continue
            return r
        except Exception as e:
            _dbg(f'GET {url} try={attempt + 1}/{retries} EXCEPTION {type(e).__name__}: {e}')
            if '404' in str(e) or '401' in str(e) or '403' in str(e): break
            if attempt < retries - 1: time.sleep(0.5)
    return None

def _get_plex_guest_token():
    global _GUEST_TOKEN
    if _GUEST_TOKEN: return _GUEST_TOKEN
    with _GUEST_TOKEN_LOCK:
        if _GUEST_TOKEN: return _GUEST_TOKEN
        headers = {
            'User-Agent': _UA,
            'X-Plex-Product': 'Plex Web',
            'X-Plex-Version': '4.120.1',
            'X-Plex-Client-Identifier': _CLIENT_ID,
            'X-Plex-Language': 'de',
            'Accept': 'application/json'
        }
        try:
            r = requests.post('https://plex.tv/api/v2/users/anonymous', headers=headers, timeout=8)
            code = getattr(r, 'status_code', None)
            if r and code in (200, 201):
                _GUEST_TOKEN = r.json().get('authToken')
                return _GUEST_TOKEN
        except Exception as e:
            _dbg(f'Gast-Token EXCEPTION {type(e).__name__}: {e}')
    return None

def _refresh_guest_token():
    global _GUEST_TOKEN
    with _GUEST_TOKEN_LOCK:
        _GUEST_TOKEN = None
    return _get_plex_guest_token()

def plex_api_get(endpoint, params=None, _retry=True):
    token = _get_plex_guest_token()
    if not token: return None
    url = endpoint if endpoint.startswith('http') else f"https://vod.provider.plex.tv{endpoint}"
    headers = {
        'User-Agent': _UA,
        'X-Plex-Token': token,
        'X-Plex-Client-Identifier': _CLIENT_ID,
        'X-Plex-Language': 'de',
        'Accept': 'application/json'
    }
    q = dict(params or {})
    q['X-Plex-Token'] = token
    q['X-Plex-Client-Identifier'] = _CLIENT_ID
    r = _safe_get(url, headers=headers, params=q, timeout=_PLEX_TIMEOUT)
    if r is None: return None
    code = getattr(r, 'status_code', None)
    if code == 401 and _retry:
        _refresh_guest_token()
        return plex_api_get(endpoint, params, _retry=False)
    if code != 200: return None
    try: return r.json()
    except Exception: return None

def metadata_objects(data):
    if not data or not isinstance(data, dict): return []
    mc = data.get('MediaContainer') or {}
    items = mc.get('Metadata') or []
    return [items] if isinstance(items, dict) else (items if isinstance(items, list) else [])

def hub_objects(data):
    if not data or not isinstance(data, dict): return []
    mc = data.get('MediaContainer') or {}
    hubs = mc.get('Hub') or []
    return [hubs] if isinstance(hubs, dict) else (hubs if isinstance(hubs, list) else [])

def _extract_all_metadata(data):
    if not data or not isinstance(data, dict): return []
    mc = data.get('MediaContainer') or {}
    results = []
    items = mc.get('Metadata') or []
    if isinstance(items, dict): items = [items]
    if isinstance(items, list): results.extend(items)
    hubs = mc.get('Hub') or []
    if isinstance(hubs, dict): hubs = [hubs]
    if isinstance(hubs, list):
        for h in hubs:
            if isinstance(h, dict):
                m_list = h.get('Metadata') or []
                if isinstance(m_list, dict): m_list = [m_list]
                if isinstance(m_list, list): results.extend(m_list)

    def _collect_sr(sr_list):
        if isinstance(sr_list, dict): sr_list = [sr_list]
        if not isinstance(sr_list, list): return
        for sr in sr_list:
            if not isinstance(sr, dict): continue
            m = sr.get('Metadata')
            if isinstance(m, dict): results.append(m)
            elif isinstance(m, list): results.extend(x for x in m if isinstance(x, dict))
            inner = sr.get('SearchResult')
            if inner: _collect_sr(inner)

    _collect_sr(mc.get('SearchResult') or [])
    _collect_sr(mc.get('SearchResults') or [])
    return results

def _get_item_slug(item):
    if not item or not isinstance(item, dict): return ''
    slug = item.get('slug') or item.get('Slug') or ''
    if slug: return str(slug)
    for k in ('key', 'guid'):
        val = str(item.get(k, ''))
        if '/movie/' in val: return val.split('/movie/', 1)[1].split('/', 1)[0]
        if '/show/' in val: return val.split('/show/', 1)[1].split('/', 1)[0]
    return ''

def _get_german_summary(slug, item_type, fetch_if_missing=True):
    if not slug or item_type not in ('movie', 'show', 'series', 'tvshow'): return ''
    page_type = 'movie' if item_type == 'movie' else 'show'
    cache_key = f"{page_type}:{slug}"
    with _WEB_META_LOCK:
        if cache_key in _WEB_META_CACHE:
            return _WEB_META_CACHE[cache_key]

    if not fetch_if_missing:
        return ''

    url = f"https://watch.plex.tv/de/{page_type}/{slug}"
    summary = ''
    try:
        r = _safe_get(url, headers={'Accept-Language': 'de-DE,de;q=0.9'}, timeout=_WEB_TIMEOUT, retries=1)
        if r and getattr(r, 'status_code', None) == 200:
            page = getattr(r, 'text', '') or ''
            
            ld_blocks = re.findall(r'<script[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', page, re.DOTALL | re.IGNORECASE)
            for block in ld_blocks:
                try:
                    js_data = json.loads(block.strip())
                    nodes = js_data if isinstance(js_data, list) else [js_data]
                    for node in nodes:
                        if isinstance(node, dict):
                            cand = node.get('description') or node.get('abstract') or ''
                            if cand and len(cand) > 30:
                                summary = html.unescape(str(cand)).strip()
                                break
                    if summary: break
                except Exception:
                    pass

            if not summary:
                for marker in ('Worum geht es in ', 'Worum geht es bei '):
                    pos = page.find(marker)
                    if pos >= 0:
                        fragment = html.unescape(page[pos:pos + 8000])
                        for sep in ('</h3>', '2>', '<p>', '>'):
                            if sep in fragment:
                                cand = fragment.split(sep, 1)[1].split('<', 1)[0].strip()
                                if len(cand) > 30 and not cand.startswith('Worum'):
                                    summary = cand
                                    break
                        if summary: break

            if not summary:
                for marker in ('"summary":"', '"description":"', '"overview":"'):
                    pos = page.find(marker)
                    if pos >= 0:
                        start = pos + len(marker)
                        end = page.find('"', start)
                        if end > start:
                            cand = html.unescape(page[start:end].replace('\\"', '"').replace('\\n', '\n')).strip()
                            if len(cand) > 30:
                                summary = cand
                                break
    except Exception:
        pass

    with _WEB_META_LOCK:
        _WEB_META_CACHE[cache_key] = summary
    return summary

def _prefetch_german_summaries(items):
    unique = {}
    for item in items or []:
        if not isinstance(item, dict): continue
        item_type = str(item.get('type', 'movie')).lower()
        if item_type not in ('movie', 'show', 'series', 'tvshow'): continue
        slug = _get_item_slug(item)
        if slug:
            page_type = 'movie' if item_type == 'movie' else 'show'
            cache_key = f"{page_type}:{slug}"
            with _WEB_META_LOCK:
                if cache_key not in _WEB_META_CACHE:
                    unique[cache_key] = (slug, item_type)
    if not unique: return
    with ThreadPoolExecutor(max_workers=_WEB_WORKERS) as executor:
        futures = [executor.submit(_get_german_summary, sl, ty, True) for sl, ty in unique.values()]
        for future in as_completed(futures):
            try: future.result()
            except Exception: pass

def _fetch_missing_metadata(item):
    if not item or not isinstance(item, dict):
        return item
    rating_key = str(item.get('ratingKey') or (item.get('key', '').split('/')[-1] if item.get('key') else ''))
    if not rating_key:
        return item
    full_data = plex_api_get(f"/library/metadata/{rating_key}")
    if full_data:
        metas = metadata_objects(full_data)
        if metas and isinstance(metas[0], dict):
            item['Media'] = metas[0].get('Media') or []
    return item

def _prefetch_audio_metadata(items):
    if not is_german_filter_enabled() or not items:
        return
    items_to_fetch = []
    for item in items:
        if isinstance(item, dict):
            rk = str(item.get('ratingKey') or (item.get('key', '').split('/')[-1] if item.get('key') else ''))
            if rk:
                with _AUDIO_CACHE_LOCK:
                    if rk in _AUDIO_CACHE:
                        continue
            items_to_fetch.append(item)
    if items_to_fetch:
        with ThreadPoolExecutor(max_workers=12) as executor:
            list(executor.map(_fetch_missing_metadata, items_to_fetch))

def _has_german_audio(item):
    if not is_german_filter_enabled():
        return True
    if not item or not isinstance(item, dict):
        return True
        
    rating_key = str(item.get('ratingKey') or (item.get('key', '').split('/')[-1] if item.get('key') else ''))
    if rating_key:
        with _AUDIO_CACHE_LOCK:
            if rating_key in _AUDIO_CACHE:
                return _AUDIO_CACHE[rating_key]

    if rating_key:
        full_data = plex_api_get(f"/library/metadata/{rating_key}")
        if full_data:
            metas = metadata_objects(full_data)
            if metas and isinstance(metas[0], dict):
                item['Media'] = metas[0].get('Media') or []

    media_list = item.get('Media') or []
    if isinstance(media_list, dict): 
        media_list = [media_list]

    found_audio = False
    has_german = False
    
    for media in media_list:
        if not isinstance(media, dict): continue
        parts = media.get('Part') or []
        if isinstance(parts, dict): parts = [parts]
        for part in parts:
            if not isinstance(part, dict): continue
            streams = part.get('Stream') or []
            if isinstance(streams, dict): streams = [streams]
            for stream in streams:
                if not isinstance(stream, dict): continue
                if str(stream.get('streamType')) == '2':
                    found_audio = True
                    lang_code = str(stream.get('languageCode') or '').lower()
                    lang = str(stream.get('language') or '').lower()
                    display = str(stream.get('displayTitle') or '').lower()
                    
                    if lang_code in ('ger', 'deu', 'de') or 'deutsch' in lang or 'german' in lang or 'deutsch' in display:
                        has_german = True

    if found_audio:
        res = has_german
    else:
        res = False

    if rating_key:
        with _AUDIO_CACHE_LOCK:
            _AUDIO_CACHE[rating_key] = res
    return res

def _format_plex_item(item, token):
    if not item or not isinstance(item, dict): return None
    if not _has_german_audio(item): return None
    rating_key = item.get('ratingKey') or (item.get('key', '').split('/')[-1] if item.get('key') else None)
    if not rating_key: return None
    item_type = item.get('type', 'movie').lower()
    raw_title = item.get('title') or 'Unbekannt'
    title = html.unescape(raw_title) if isinstance(raw_title, str) else str(raw_title)
    year = str(item.get('year') or item.get('parentYear') or '')
    raw_summary = item.get('summary') or item.get('tagline') or item.get('overview') or ''
    summary = html.unescape(raw_summary) if isinstance(raw_summary, str) else str(raw_summary)
    
    de_summary = _get_german_summary(_get_item_slug(item), item_type, fetch_if_missing=False)
    if de_summary: summary = de_summary

    try: rating = float(item.get('rating') or item.get('audienceRating') or 0.0)
    except (ValueError, TypeError): rating = 0.0
    thumb = item.get('thumb') or item.get('art') or item.get('grandparentThumb')
    poster = f"https://vod.provider.plex.tv{thumb}?X-Plex-Token={token}" if thumb and not str(thumb).startswith('http') else (thumb or '')
    directors_data = item.get('Director') or []
    if isinstance(directors_data, dict): directors_data = [directors_data]
    directors = [d.get('tag') for d in directors_data if isinstance(d, dict) and d.get('tag')]
    genres_data = item.get('Genre') or []
    if isinstance(genres_data, dict): genres_data = [genres_data]
    genres = [g.get('tag') for g in genres_data if isinstance(g, dict) and g.get('tag')]
    meta_plot = f"[COLOR yellow]★ {rating:.1f}[/COLOR]\n" if rating > 0 else ""
    if directors: meta_plot += f"[B]Regie:[/B] {', '.join(directors)}\n"
    if genres: meta_plot += f"[B]Genre:[/B] {', '.join(genres)}\n"
    if meta_plot and summary: meta_plot += "--------------------------------------------------------\n"
    meta_plot += summary

    if item_type == 'movie':
        return {'title': title, 'url': f"{title}||metadata:{rating_key}", 'mediatype': 'movie', 'is_playable': True, 'next_func': 'get_hosters', 'plot': meta_plot, 'poster': poster, 'year': year}
    elif item_type in ('show', 'series', 'tvshow'):
        return {'title': f"[Serie] {title}", 'url': f"show_seasons||{rating_key}", 'mediatype': 'tvshow', 'is_playable': False, 'next_func': 'load', 'plot': meta_plot, 'poster': poster, 'year': year}
    elif item_type == 'season':
        s_num = item.get('index', 1)
        s_title = item.get('title') or f"Staffel {s_num}"
        return {'title': s_title, 'url': f"season_episodes||{rating_key}", 'mediatype': 'season', 'is_playable': False, 'next_func': 'load', 'plot': meta_plot, 'poster': poster, 'year': year}
    elif item_type == 'episode':
        ep_num = item.get('index', 1)
        s_num = item.get('parentIndex', 1)
        ep_display = f"S{int(s_num):02d}E{int(ep_num):02d} - {title}"
        return {'title': ep_display, 'url': f"{ep_display}||metadata:{rating_key}", 'mediatype': 'episode', 'is_playable': True, 'next_func': 'get_hosters', 'plot': meta_plot, 'poster': poster, 'year': year}
    return None

_LIVE_HOST = 'https://epg.provider.plex.tv'
_LIVE_PROVIDER_VERSION = '7.0.0'
_LIVE_PRODUCT, _LIVE_PLATFORM = 'Plex Web', 'Chrome'

def _live_headers(token):
    return {
        'User-Agent': _UA, 'Accept': 'application/json', 'Accept-Language': 'de-DE,de;q=0.9',
        'X-Plex-Token': token, 'X-Plex-Product': _LIVE_PRODUCT, 'X-Plex-Version': '4.120.1',
        'X-Plex-Client-Identifier': _CLIENT_ID, 'X-Plex-Platform': _LIVE_PLATFORM,
        'X-Plex-Provider-Version': _LIVE_PROVIDER_VERSION, 'X-Plex-Language': 'de',
    }

def _live_channels():
    token = _get_plex_guest_token()
    if not token: return []
    r = _safe_get(f"{_LIVE_HOST}/lineups/plex/channels", headers=_live_headers(token), timeout=8)
    if r is not None and getattr(r, 'status_code', None) in (401, 403):
        token = _refresh_guest_token()
        if not token: return []
        r = _safe_get(f"{_LIVE_HOST}/lineups/plex/channels", headers=_live_headers(token), timeout=8)
    if r is None or getattr(r, 'status_code', None) != 200: return []
    try: data = r.json()
    except Exception: return []
    container = data.get('MediaContainer', data) if isinstance(data, dict) else {}
    items = (container.get('Channel') or container.get('Metadata') or []) if isinstance(container, dict) else []
    if isinstance(items, dict): items = [items]
    out = []
    for ch in items if isinstance(items, list) else []:
        if not isinstance(ch, dict): continue
        cid = str(ch.get('id') or '').strip()
        title = html.unescape(str(ch.get('title') or ch.get('name') or ch.get('callSign') or '')).strip()
        if not cid or not title: continue
        logo = ch.get('thumb') or ch.get('logo') or ''
        if logo and not str(logo).startswith('http'): logo = ''
        lang = str(ch.get('language') or ch.get('languageCode') or '')
        out.append({
            'id': cid,
            'title': title,
            'plot': html.unescape(str(ch.get('summary') or ch.get('description') or '')),
            'logo': logo,
            'language': lang
        })
    return out

def _live_items(german_only):
    results = []
    for ch in _live_channels():
        results.append({
            'title': ch['title'],
            'url': f"{ch['title']}||live:{ch['id']}",
            'mediatype': 'movie',
            'is_playable': True,
            'next_func': 'get_hosters',
            'plot': ch['plot'],
            'poster': ch['logo'],
            'year': ''
        })
    results.sort(key=lambda x: x['title'].lower())
    return results

def _resolve_live(channel_id):
    part_url = f"{_LIVE_HOST}/library/parts/{channel_id}.m3u8"
    play_headers = {
        'User-Agent': _UA,
        'Referer': 'https://watch.plex.tv/',
        'Origin': 'https://watch.plex.tv'
    }
    token = _get_plex_guest_token()
    if not token: return None
    
    params = {
        'includeAllStreams': '1',
        'X-Plex-Product': _LIVE_PRODUCT,
        'X-Plex-Client-Identifier': _CLIENT_ID,
        'X-Plex-Client-Platform': _LIVE_PLATFORM,
        'X-Plex-Platform': _LIVE_PLATFORM,
        'X-Plex-Device': 'Windows',
        'X-Plex-Session-Id': str(uuid.uuid4()),
        'X-Plex-Token': token,
    }
    
    query_str = urllib.parse.urlencode(params)
    resolved = f"{part_url}?{query_str}"
    
    return f"{resolved}|{urllib.parse.urlencode(play_headers)}"

def _search_params(query, endpoint=''):
    p = {'query': query, 'limit': 40}
    if 'discover.provider' in endpoint:
        p.update({'searchTypes': 'movies,tv', 'searchProviders': 'discover', 'includeMetadata': 1})
    return p

def search(query='', params=None):
    _dbg(f'search() query={query!r}')
    if not query: return []
    token = _get_plex_guest_token()
    if not token: return []
    endpoints = ['https://discover.provider.plex.tv/library/search']
    results = []
    seen_keys = set()
    for ep in endpoints:
        data = plex_api_get(ep, params=_search_params(query, ep))
        if not data: continue
        metas = _extract_all_metadata(data)
        _prefetch_audio_metadata(metas)
        _prefetch_german_summaries(metas)
        for meta in metas:
            rk = meta.get('ratingKey') or (meta.get('key', '').split('/')[-1] if meta.get('key') else None)
            if rk and rk not in seen_keys:
                seen_keys.add(rk)
                parsed = _format_plex_item(meta, token)
                if parsed: results.append(parsed)
    return results

def load(url='', params=None):
    token = _get_plex_guest_token()

    if url:
        with _CATEGORY_CACHE_LOCK:
            if url in _CATEGORY_CACHE:
                return _CATEGORY_CACHE[url]

    results = []
    if not url:
        filter_status = "[B][COLOR white]Nur Deutsch[/COLOR][/B]" if is_german_filter_enabled() else "[B][COLOR white]Alle Sprachen[/COLOR][/B]"
        results = [
            {'title': '[ Live TV - Deutsch ]', 'url': 'live_de', 'plot': 'Plex Live TV (ohne Anmeldung), deutschsprachige Sender', 'is_playable': False, 'next_func': 'load'},
            {'title': '[ Live TV - Alle Sender ]', 'url': 'live_all', 'plot': 'Plex Live TV (ohne Anmeldung), alle Sender', 'is_playable': False, 'next_func': 'load'},
            {'title': '[ Suche ]', 'url': 'search_input', 'plot': 'Plex Free durchsuchen', 'is_playable': False, 'next_func': 'load'},
            {'title': '[ Entdecken & Kategorien ]', 'url': 'hubs', 'plot': 'Plex On-Demand Hubs durchstöbern', 'is_playable': False, 'next_func': 'load'},
            {'title': f'[ Sprachfilter: {filter_status} ]', 'url': '', 'plot': 'Klicken, um den Sprachfilter "Nur Deutsch" ein-/auszuschalten', 'is_playable': False, 'is_folder': False, 'next_func': 'toggle_filter'}
        ]
    elif url in ('live_de', 'live_all'):
        results = _live_items(german_only=(url == 'live_de'))
    elif url == 'search_input':
        query = xbmcgui.Dialog().input('Plex Free - Suche', type=xbmcgui.INPUT_ALPHANUM)
        if query and query.strip():
            results = search(query.strip())
        else:
            results = []
    elif url == 'hubs':
        data = plex_api_get('/hubs')
        promoted = plex_api_get('/hubs/promoted')
        seen_keys = set()
        for hub in hub_objects(data) + hub_objects(promoted):
            hub_title, hub_key = hub.get('title'), hub.get('key')
            if hub_title and hub_key and hub_key not in seen_keys:
                seen_keys.add(hub_key)
                results.append({'title': f"[ {hub_title} ]", 'url': f"hub_key||{hub_key}", 'plot': f"Inhalte aus {hub_title}", 'is_playable': False, 'next_func': 'load'})
    elif url.startswith('hub_key||'):
        key = url.split('||', 1)[1]
        data = plex_api_get(key)
        seen_keys = set()
        meta_list = _extract_all_metadata(data)
        _prefetch_audio_metadata(meta_list)
        _prefetch_german_summaries(meta_list)
        for meta in meta_list:
            rk = meta.get('ratingKey') or (meta.get('key', '').split('/')[-1] if meta.get('key') else None)
            if rk and rk not in seen_keys:
                seen_keys.add(rk)
                parsed = _format_plex_item(meta, token)
                if parsed: results.append(parsed)
    elif url.startswith('show_seasons||'):
        rating_key = url.split('||', 1)[1]
        data = plex_api_get(f"/library/metadata/{rating_key}/children")
        meta_list = metadata_objects(data)
        if not meta_list:
            data_leaves = plex_api_get(f"/library/metadata/{rating_key}/allLeaves")
            meta_list = metadata_objects(data_leaves)
        _prefetch_audio_metadata(meta_list)
        for meta in meta_list:
            parsed = _format_plex_item(meta, token)
            if parsed: results.append(parsed)
    elif url.startswith('season_episodes||'):
        rating_key = url.split('||', 1)[1]
        data = plex_api_get(f"/library/metadata/{rating_key}/children")
        meta_list = metadata_objects(data)
        _prefetch_audio_metadata(meta_list)
        for meta in meta_list:
            parsed = _format_plex_item(meta, token)
            if parsed: results.append(parsed)

    if url:
        with _CATEGORY_CACHE_LOCK:
            _CATEGORY_CACHE[url] = results

    return results

def resolve_stream(url_param):
    if not url_param: return None

    metadata_id = None
    if '||' in url_param:
        for part in url_param.split('||'):
            if part.startswith('live:'):
                return _resolve_live(part.split('live:', 1)[1].strip())
            if part.startswith('metadata:'):
                metadata_id = part.split('metadata:', 1)[1].strip()
    else:
        metadata_id = url_param.strip()

    if metadata_id:
        token = _get_plex_guest_token()
        if not token: return None
        
        data = plex_api_get(f"/library/metadata/{metadata_id}")
        if data:
            for item in metadata_objects(data):
                media_list = item.get('Media') or []
                if isinstance(media_list, dict): media_list = [media_list]
                for media in media_list:
                    if isinstance(media, dict):
                        for part in (media.get('Part') or []):
                            if isinstance(part, dict):
                                key = part.get('key')
                                if key:
                                    return key if key.startswith('http') else f"https://vod.provider.plex.tv{key}?X-Plex-Token={token}"
    return None

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ''

def build_url(query):
    return BASE_URL + '?' + urllib.parse.urlencode(query)

def render_items(item_list):
    if not item_list:
        item_list = [{
            'title': '[COLOR red]Keine Inhalte gefunden[/COLOR]',
            'url': '',
            'plot': 'In dieser Kategorie sind aktuell keine kompatiblen (oder deutschsprachigen) Inhalte verfügbar.',
            'is_playable': False,
            'is_folder': False,
            'next_func': 'load'
        }]

    for item in item_list:
        title, is_playable = item.get('title', ''), item.get('is_playable', False)
        next_func, raw_url = item.get('next_func', 'load'), item.get('url', '')
        is_folder = item.get('is_folder', not is_playable)
        li = xbmcgui.ListItem(label=title)
        itag = li.getVideoInfoTag()
        if item.get('plot'): itag.setPlot(item['plot'])
        if item.get('year'):
            try: itag.setYear(int(item['year']))
            except (ValueError, TypeError): pass
        if item.get('mediatype'): itag.setMediaType(item['mediatype'])
        poster = item.get('poster') or DEFAULT_ICON
        li.setArt({'poster': poster, 'thumb': poster, 'icon': DEFAULT_ICON, 'fanart': poster})
        if is_playable:
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'play', 'url': raw_url}), li, isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': next_func, 'url': raw_url}), li, isFolder=is_folder)
            
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 and sys.argv[2] else {}
    action, url_param = params.get('action', 'root'), params.get('url', '')
    
    if action == 'toggle_filter':
        toggle_german_filter()
        xbmc.executebuiltin('Container.Refresh')
    elif action in ('root', 'load'):
        render_items(load(url_param))
    elif action == 'search':
        if url_param == 'search_input':
            query = xbmcgui.Dialog().input('Plex Free - Suche', type=xbmcgui.INPUT_ALPHANUM)
            if query and query.strip(): render_items(search(query.strip()))
            else: xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        else: render_items(search(url_param))
    elif action == 'play':
        stream_url = resolve_stream(url_param)
        if stream_url:
            headers_str = ''
            play_path = stream_url
            if '|' in stream_url:
                play_path, headers_str = stream_url.split('|', 1)

            li = xbmcgui.ListItem(path=play_path)
            li.setContentLookup(False)
            li.setMimeType('application/vnd.apple.mpegurl')
            
            try:
                if xbmcaddon.Addon('inputstream.adaptive'):
                    li.setProperty('inputstream', 'inputstream.adaptive')
                    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
                    if headers_str:
                        li.setProperty('inputstream.adaptive.stream_headers', headers_str)
            except Exception:
                pass
                
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
        else:
            xbmcgui.Dialog().notification('Plex Free', 'Stream konnte nicht geladen werden', xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

if __name__ == '__main__':
    main()
