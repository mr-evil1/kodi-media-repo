import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, urlencode, urlunparse, parse_qs

import requests

_CHUNK = 65536
_IDLE_TIMEOUT = 60
_MAX_REDIRECTS = 10
_PERMANENT_ERROR_CODES = (400, 401, 403, 404, 405, 410)


def _free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]


def _strip_play_token(url):
    p = urlparse(url)
    qs = parse_qs(p.query, keep_blank_values=True)
    qs.pop('play_token', None)
    return urlunparse(p._replace(query=urlencode({k: v[0] for k, v in qs.items()})))


def _follow_redirects(session, url, headers, log=None, max_hops=_MAX_REDIRECTS):
    visited = set()
    for _ in range(max_hops):
        if url in visited:
            if log:
                log(f'StreamProxy: Redirect-Schleife bei {url[:80]}')
            return None
        visited.add(url)
        try:
            resp = session.get(url, headers=headers, stream=True,
                               timeout=(10, 60), allow_redirects=False)
        except Exception as e:
            if log:
                log(f'StreamProxy: Verbindungsfehler {url[:80]}: {e}')
            return None
        if resp.status_code in (301, 302, 303, 307, 308):
            location = resp.headers.get('Location', '')
            resp.close()
            if location:
                if log:
                    log(f'StreamProxy: Redirect {resp.status_code} → {location[:80]}')
                url = location
                continue
            return None
        return resp
    if log:
        log('StreamProxy: Zu viele Redirects')
    return None


def _url_variants(primary, fallback=None):
    yield primary
    if 'play_token' in primary:
        stripped = _strip_play_token(primary)
        if stripped != primary:
            yield stripped
    if fallback and fallback != primary and fallback != _strip_play_token(primary):
        yield fallback


def _is_host_reachable(url, timeout=3):
    try:
        p = urlparse(url)
        host = p.hostname
        port = p.port or (443 if p.scheme == 'https' else 80)
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self._proxy()

    def do_HEAD(self):
        self._proxy(head_only=True)

    def _proxy(self, head_only=False):
        srv = self.server
        srv.last_activity = time.time()

        if srv.permanently_failed:
            try:
                self.send_error(502)
            except Exception:
                pass
            return

        fwd_headers = dict(srv.stream_headers)
        rang = self.headers.get('Range')
        if rang:
            fwd_headers['Range'] = rang

        r = self._resolve_stream(srv, fwd_headers)
        if r is None:
            srv.permanently_failed = True
            try:
                self.send_error(502)
            except Exception:
                pass
            return

        try:
            self.send_response(r.status_code)
            for k, v in r.headers.items():
                if k.lower() in (
                    'content-type', 'content-length',
                    'transfer-encoding', 'content-range', 'accept-ranges',
                ):
                    self.send_header(k, v)
            self.end_headers()
        except Exception:
            try:
                r.close()
            except Exception:
                pass
            srv.last_activity = time.time()
            return

        if not head_only:
            self._stream_with_reconnect(srv, fwd_headers, r)
        else:
            try:
                r.close()
            except Exception:
                pass

        srv.last_activity = time.time()

    def _resolve_stream(self, srv, fwd_headers):
        for try_url in _url_variants(srv.target_url, srv.fallback_url):
            r = _follow_redirects(srv.session, try_url, fwd_headers, log=srv._log)
            if r is None:
                continue
            if r.status_code < 400:
                srv._log(f'StreamProxy: OK {r.status_code} {try_url[:80]}')
                srv.target_url = try_url
                return r
            srv._log(f'StreamProxy: {r.status_code} bei {try_url[:80]}, versuche nächste Variante...')
            r.close()
        return None

    def _stream_with_reconnect(self, srv, fwd_headers, initial_response):
        r = initial_response
        bytes_sent = 0
        while True:
            try:
                for chunk in r.iter_content(chunk_size=_CHUNK):
                    if chunk:
                        try:
                            self.wfile.write(chunk)
                            self.wfile.flush()
                        except (BrokenPipeError, ConnectionResetError, OSError):
                            try:
                                r.close()
                            except Exception:
                                pass
                            return
                        bytes_sent += len(chunk)
                        srv.last_activity = time.time()
                try:
                    r.close()
                except Exception:
                    pass
                break
            except Exception as e:
                srv._log(f'StreamProxy: Upstream unterbrochen nach {bytes_sent} Bytes: {e}')
                try:
                    r.close()
                except Exception:
                    pass
                if not srv.renew_func or bytes_sent == 0:
                    break
                try:
                    new_url = srv.renew_func()
                    if not new_url:
                        break
                    srv._log(f'StreamProxy: Token erneuert → {new_url[:80]}')
                    srv.target_url = new_url
                    r = _follow_redirects(srv.session, new_url, fwd_headers, log=srv._log)
                    if r is None or r.status_code >= 400:
                        if r:
                            r.close()
                        break
                except Exception as ex:
                    srv._log(f'StreamProxy: Token-Erneuerung fehlgeschlagen: {ex}')
                    break

    def log_message(self, *args):
        pass

    def log_request(self, *args):
        pass


class StreamProxy:
    def __init__(self, target_url, stream_headers, session=None,
                 fallback_url=None, log_func=None, renew_func=None):
        self._url = target_url
        self._headers = stream_headers
        self._session = session or requests.Session()
        self._fallback = self._validate_fallback(fallback_url, log_func)
        self._log = log_func or (lambda m: None)
        self._renew_func = renew_func
        self._server = None
        self._thread = None
        self.port = None

    def _validate_fallback(self, fallback_url, log_func):
        if not fallback_url:
            return None
        try:
            p = urlparse(fallback_url)
            if p.hostname in ('localhost', '127.0.0.1', '::1'):
                if not _is_host_reachable(fallback_url):
                    if log_func:
                        log_func(f'StreamProxy: Fallback {fallback_url[:60]} nicht erreichbar, wird ignoriert')
                    return None
        except Exception:
            pass
        return fallback_url

    def start(self):
        self.port = _free_port()
        server = HTTPServer(('127.0.0.1', self.port), _Handler)
        server.target_url = self._url
        server.stream_headers = self._headers
        server.session = self._session
        server.fallback_url = self._fallback
        server.last_activity = time.time()
        server.timeout = 2
        server._log = self._log
        server.permanently_failed = False
        server.renew_func = self._renew_func
        self._server = server
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        self._log(f'StreamProxy gestartet: 127.0.0.1:{self.port} → {self._url[:80]}')
        if self._fallback:
            self._log(f'StreamProxy Fallback: {self._fallback[:80]}')
        return self

    def _run(self):
        srv = self._server
        while True:
            srv.handle_request()
            if srv.permanently_failed:
                break
            if time.time() - srv.last_activity > _IDLE_TIMEOUT:
                break
        srv.server_close()
        self._log(f'StreamProxy beendet: port={self.port}')

    def stop(self):
        if self._server:
            try:
                self._server.server_close()
            except Exception:
                pass

    @property
    def url(self):
        return f'http://127.0.0.1:{self.port}/'
