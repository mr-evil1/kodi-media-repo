import os
import threading
import time
import uuid
from urllib.parse import urljoin

import xbmc
import xbmcgui

from resources.lib import kodi_utils as ku

_STATE_IDLE      = 'idle'
_STATE_BUFFERING = 'buffering'
_STATE_PLAYING   = 'playing'
_STATE_DONE      = 'done'

_MIN_BUFFER_BYTES = 524288   # 512 KB vor erstem Play
_MIN_BUFFER_WAIT  = 5.0      # max Sekunden warten auf Mindestpuffer
_TS_SUBDIR        = 'timeshift'

_active_session = None
_session_lock   = threading.Lock()


# ──────────────────────────────────────────────
# Verzeichnis
# ──────────────────────────────────────────────
def _ts_temp_dir():
    d = ku.get_setting('timeshift_dir', '') or ''
    if not d:
        d = os.path.join(ku.PROFILE_DIR, _TS_SUBDIR)
    os.makedirs(d, exist_ok=True)
    return d


# ──────────────────────────────────────────────
# Startup-Cleanup
# ──────────────────────────────────────────────
def cleanup_on_startup():
    for d in [os.path.join(ku.PROFILE_DIR, _TS_SUBDIR),
              ku.get_setting('timeshift_dir', '') or '']:
        if d and os.path.isdir(d):
            for fn in os.listdir(d):
                if fn.startswith('ts_') and fn.endswith('.ts'):
                    try:
                        os.remove(os.path.join(d, fn))
                    except Exception:
                        pass
    try:
        from resources.lib.database import Database
        db = Database(ku.db_path())
        db.cleanup_timeshift_sessions()
        db.close()
    except Exception as e:
        ku.log(f'Timeshift: startup cleanup DB-Fehler: {e}', xbmc.LOGWARNING)
    ku.log_debug('Timeshift: Startup-Cleanup abgeschlossen')


# ──────────────────────────────────────────────
# Recorder-Thread
# ──────────────────────────────────────────────
class _RecordThread(threading.Thread):
    def __init__(self, ts_path, stream_url, headers):
        super().__init__(daemon=True, name='ts_recorder')
        self._ts_path     = ts_path
        self._stream_url  = stream_url
        self._headers     = dict(headers or {})
        self._stop_event  = threading.Event()
        self.bytes_written = 0

    def stop(self):
        self._stop_event.set()

    def _hdrs(self):
        h = dict(self._headers)
        ua = ku.get_setting('user_agent_global', '') or ''
        if ua and 'User-Agent' not in h:
            h['User-Agent'] = ua
        return h

    @staticmethod
    def _is_hls(url):
        return '.m3u8' in url.lower()

    def run(self):
        try:
            if self._is_hls(self._stream_url):
                self._record_hls(self._hdrs())
            else:
                self._record_stream(self._hdrs())
        except Exception as e:
            ku.log(f'Timeshift Recorder: {e}', xbmc.LOGERROR)

    def _record_stream(self, headers):
        import requests
        retries = 0
        append  = False
        while not self._stop_event.is_set():
            try:
                mode = 'ab' if append else 'wb'
                with requests.get(self._stream_url, stream=True,
                                  headers=headers, timeout=(10, 60)) as r:
                    r.raise_for_status()
                    with open(self._ts_path, mode) as f:
                        for chunk in r.iter_content(chunk_size=65536):
                            if self._stop_event.is_set():
                                return
                            if chunk:
                                f.write(chunk)
                                self.bytes_written += len(chunk)
                if self._stop_event.is_set():
                    return
                append  = True
                retries += 1
                if retries > 20:
                    break
                time.sleep(min(2 * retries, 15))
            except Exception as e:
                if self._stop_event.is_set():
                    return
                retries += 1
                append   = True
                if retries > 20:
                    break
                ku.log(f'Timeshift: Reconnect {retries}/20 ({e})', xbmc.LOGWARNING)
                time.sleep(min(2 * retries, 15))

    def _record_hls(self, headers):
        import requests
        seen      = set()
        media_url = self._stream_url
        try:
            r = requests.get(self._stream_url, headers=headers, timeout=(10, 30))
            r.raise_for_status()
            if '#EXT-X-STREAM-INF' in r.text:
                for line in r.text.splitlines():
                    line = line.strip()
                    if line and not line.startswith('#'):
                        media_url = line if line.startswith('http') else urljoin(self._stream_url, line)
                        break
        except Exception as e:
            ku.log(f'Timeshift HLS Master-Fehler: {e}', xbmc.LOGWARNING)
            return
        try:
            with open(self._ts_path, 'wb') as f:
                while not self._stop_event.is_set():
                    try:
                        r = requests.get(media_url, headers=headers, timeout=(10, 30))
                        r.raise_for_status()
                        new_segs = []
                        for line in r.text.splitlines():
                            line = line.strip()
                            if line and not line.startswith('#'):
                                su = line if line.startswith('http') else urljoin(media_url, line)
                                if su not in seen:
                                    new_segs.append(su)
                        for su in new_segs:
                            if self._stop_event.is_set():
                                break
                            try:
                                sr = requests.get(su, headers=headers,
                                                  timeout=(5, 30), stream=True)
                                sr.raise_for_status()
                                for chunk in sr.iter_content(65536):
                                    if chunk:
                                        f.write(chunk)
                                        self.bytes_written += len(chunk)
                                seen.add(su)
                            except Exception as se:
                                ku.log(f'Timeshift HLS Segment {su}: {se}', xbmc.LOGWARNING)
                        time.sleep(1 if new_segs else 2)
                    except Exception as e:
                        if self._stop_event.is_set():
                            break
                        ku.log(f'Timeshift HLS Playlist-Fehler: {e}', xbmc.LOGWARNING)
                        time.sleep(3)
        except Exception as e:
            ku.log(f'Timeshift HLS Schreibfehler: {e}', xbmc.LOGERROR)




# ── Stop-Monitor: beendet Recording wenn Wiedergabe stoppt ──────────────────

class _StopMonitor(xbmc.Player):
    """Beobachtet Wiedergabe und ruft stop_active_session() beim Beenden auf."""
    def activate(self):
        # Referenz halten damit GC ihn nicht löscht
        _active_monitors.append(self)

    def onPlayBackStopped(self):
        self._on_end()

    def onPlayBackEnded(self):
        self._on_end()

    def onPlayBackError(self):
        self._on_end()

    def _on_end(self):
        ku.log_debug('Timeshift: Wiedergabe beendet → Recording stoppen & löschen')
        stop_active_session()
        try:
            _active_monitors.remove(self)
        except ValueError:
            pass

_active_monitors = []

# ──────────────────────────────────────────────
# Session
# ──────────────────────────────────────────────
class _TimeshiftSession:
    def __init__(self):
        self.session_id  = uuid.uuid4().hex
        self.ts_path     = os.path.join(_ts_temp_dir(), f'ts_{self.session_id}.ts')
        self._rec_thread = None
        self._state      = _STATE_IDLE
        self._lock       = threading.Lock()

    def start_recording(self, stream_url, channel_name, provider_id, channel_id, headers):
        # Unbegrenzt aufnehmen — StopMonitor beendet beim Stoppen der Wiedergabe
        t = _RecordThread(self.ts_path, stream_url, headers)
        self._rec_thread = t
        self._state      = _STATE_BUFFERING

        try:
            from resources.lib.database import Database
            db = Database(ku.db_path())
            db.add_timeshift_session(self.session_id, channel_name, stream_url,
                                     self.ts_path, provider_id, channel_id)
            db.close()
        except Exception as e:
            ku.log(f'Timeshift: DB-Eintrag fehlgeschlagen: {e}', xbmc.LOGWARNING)

        t.start()
        ku.log_debug(f'Timeshift: Recording gestartet → {self.ts_path}')

    def wait_for_buffer(self):
        """Wartet bis Mindestpuffer da ist. Gibt True zurück wenn bereit."""
        deadline = time.time() + _MIN_BUFFER_WAIT
        while time.time() < deadline:
            try:
                if (self.ts_path and os.path.exists(self.ts_path)
                        and os.path.getsize(self.ts_path) >= _MIN_BUFFER_BYTES):
                    return True
            except OSError:
                pass
            xbmc.sleep(200)
        # Auch mit weniger Daten versuchen
        try:
            return os.path.exists(self.ts_path) and os.path.getsize(self.ts_path) > 0
        except OSError:
            return False

    def play_ts(self, channel_name):
        """Spielt die TS-Datei als Movie ab (volle Kodi-Player-Steuerung)."""
        self._state = _STATE_PLAYING
        li = xbmcgui.ListItem(channel_name, path=self.ts_path)
        li.setContentLookup(False)
        try:
            tag = li.getVideoInfoTag()
            tag.setMediaType('movie')
            tag.setTitle(channel_name)
        except Exception:
            li.setInfo('video', {'mediatype': 'movie', 'title': channel_name})
        xbmc.Player().play(self.ts_path, li)
        ku.log_debug(f'Timeshift: TS-Wiedergabe gestartet: {self.ts_path}')

    def stop(self):
        with self._lock:
            self._state = _STATE_DONE
        if self._rec_thread:
            self._rec_thread.stop()
        rec  = self._rec_thread
        path = self.ts_path
        sid  = self.session_id

        def _cleanup():
            if rec:
                rec.join(timeout=5)
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                    ku.log_debug(f'Timeshift: TS gelöscht: {path}')
                except Exception as e:
                    ku.log(f'Timeshift: Löschfehler: {e}', xbmc.LOGWARNING)
            try:
                from resources.lib.database import Database
                db = Database(ku.db_path())
                db.delete_timeshift_session(sid)
                db.close()
            except Exception:
                pass

        threading.Thread(target=_cleanup, daemon=True, name='ts_cleanup').start()


# ──────────────────────────────────────────────
# Öffentliche API
# ──────────────────────────────────────────────
def play_channel_via_timeshift(stream_url, channel_name, provider_id, channel_id, headers=None):
    """
    Haupteinstiegspunkt: Startet Recording, wartet auf Puffer, spielt TS-Datei.
    Gibt True zurück wenn erfolgreich gestartet.
    """
    global _active_session
    with _session_lock:
        if _active_session is not None:
            _active_session.stop()
        session = _TimeshiftSession()
        _active_session = session

    session.start_recording(stream_url, channel_name, provider_id, channel_id, headers or {})

    # StopMonitor: beendet Recording + löscht TS wenn Wiedergabe stoppt
    _StopMonitor().activate()

    ku.notify('⏺ Timeshift: Puffer wird aufgebaut…', time=3000)
    if not session.wait_for_buffer():
        ku.notify('Timeshift: Kein Puffer — direkt abspielen',
                  icon=xbmcgui.NOTIFICATION_WARNING, time=3000)
        with _session_lock:
            if _active_session is session:
                _active_session = None
        session.stop()
        return False

    session.play_ts(channel_name)
    return True


def stop_active_session():
    global _active_session
    with _session_lock:
        s = _active_session
        _active_session = None
    if s:
        s.stop()


# Legacy-Kompatibilität (wird von router.py noch aufgerufen)
def start_monitor(stream_url, channel_name, provider_id, channel_id):
    pass  # nicht mehr benötigt — play_channel_via_timeshift übernimmt alles


def trigger_switch():
    ku.notify('Timeshift läuft bereits im Puffer-Modus', time=2000)
