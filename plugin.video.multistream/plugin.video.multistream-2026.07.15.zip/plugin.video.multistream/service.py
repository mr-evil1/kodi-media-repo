import os
import time
import xbmc
import xbmcvfs
from resources.lib import kodi_utils as ku
from resources.lib.router import get_db
from resources.lib import recorder as _recorder
from resources.lib import touch_overlay as _touch
from resources.lib import timeshift as _timeshift

_KEYMAP_SRC = os.path.join(os.path.dirname(__file__), 'resources', 'keymap', 'multistream_record.xml')
_KEYMAP_DEST = xbmcvfs.translatePath('special://userdata/keymaps/multistream_record.xml')


def _install_keymap():
    try:
        if not xbmcvfs.exists(_KEYMAP_DEST):
            xbmcvfs.copy(_KEYMAP_SRC, _KEYMAP_DEST)
            xbmc.executebuiltin('Action(reloadkeymaps)')
            ku.log_debug('Service: Keymap installiert')
    except Exception as e:
        ku.log(f'Service: Keymap-Installation fehlgeschlagen: {e}', xbmc.LOGWARNING)


def _uninstall_keymap():
    try:
        if xbmcvfs.exists(_KEYMAP_DEST):
            xbmcvfs.delete(_KEYMAP_DEST)
            xbmc.executebuiltin('Action(reloadkeymaps)')
            ku.log_debug('Service: Keymap entfernt')
    except Exception as e:
        ku.log(f'Service: Keymap-Entfernung fehlgeschlagen: {e}', xbmc.LOGWARNING)


class MultiStreamService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self._last_recording_check = 0
        self._last_epg_sync_check = 0
        self._last_touch_check = 0

    def run(self):
        ku.log_debug('MultiStream Service gestartet')
        _install_keymap()
        _timeshift.cleanup_on_startup()
        self._sync_touch_overlay()
        self._maybe_autostart_wizard()
        while not self.abortRequested():
            now = time.time()
            if now - self._last_touch_check >= 5:
                self._sync_touch_overlay()
                self._last_touch_check = now
            if now - self._last_recording_check >= 30:
                self._check_recordings()
                self._last_recording_check = now
            if now - self._last_epg_sync_check >= 300:
                self._check_epg_sync()
                self._last_epg_sync_check = now
            if self.waitForAbort(5):
                break
        _touch.stop_touch_service()
        _uninstall_keymap()
        ku.log_debug('MultiStream Service gestoppt')

    def _sync_touch_overlay(self):
        enabled = ku.get_setting_bool('touch_overlay_enabled', False)
        running = _touch.is_touch_service_running()
        if enabled and not running:
            _touch.start_touch_service()
        elif not enabled and running:
            _touch.stop_touch_service()

    def _maybe_autostart_wizard(self):
        try:
            if ku.get_setting_bool('setup_wizard_done', False):
                return
            db = get_db()
            has_providers = bool(db.get_providers())
            db.close()
            if has_providers:
                ku.set_setting('setup_wizard_done', 'true')
                return
            if self.waitForAbort(3):
                return
            xbmc.executebuiltin(f'RunPlugin(plugin://{ku.ADDON_ID}/?action=setup_wizard)')
        except Exception as e:
            ku.log(f'Service: Fehler beim Start des Assistenten: {e}', xbmc.LOGERROR)

    def _check_recordings(self):
        try:
            db = get_db()
            _recorder.check_scheduled_recordings(db)
            db.close()
        except Exception as e:
            ku.log(f'Service: Fehler beim Prüfen geplanter Aufnahmen: {e}', xbmc.LOGERROR)

    def _check_epg_sync(self):
        try:
            db = get_db()
            providers = db.get_providers(only_enabled=True)
            now = int(time.time())
            for p in providers:
                interval_h = int(p.get('epgSyncInterval', 0) or 0)
                if interval_h <= 0:
                    continue
                last_sync = int(p.get('lastSyncedAt', 0) or 0)
                if now - last_sync >= interval_h * 3600:
                    ku.log_debug(f'Service: Auto-EPG-Sync für provider {p["id"]} ({p["name"]})')
                    from resources.lib import sync as sync_mod
                    sync_mod.sync_provider(db, p)
            db.close()
        except Exception as e:
            ku.log(f'Service: Fehler beim EPG-Auto-Sync: {e}', xbmc.LOGERROR)


if __name__ == '__main__':
    MultiStreamService().run()
