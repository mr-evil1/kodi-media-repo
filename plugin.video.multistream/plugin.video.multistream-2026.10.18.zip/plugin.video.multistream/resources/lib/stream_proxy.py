import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, urlencode, urlunparse, parse_qs

import requests

_CHUNK = 65536
_IDLE_TIMEOUT = 60
_REDIRECT_CODES = (301, 302, 303, 307, 308)


def _free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]


def _strip_play_token(url):
    p = urlparse(url)
    qs = parse_qs(p.query, keep_blank_values=True)
    qs.pop('play_token', None)
    return urlunparse(p._replace(query=urlencode({k: v[0] for k, v in qs.items()})))


def _url_variants(primary, fallback=None):
    yield primary
    if 'play_token' in primary:
        stripped = _strip_play_token(primary)
        if stripped != primary:
            yield stripped
    if fallback and fallback != primary and fallback != _strip_play_token(primary):
        yield fallback


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self._proxy()

    def do_HEAD(self):
        self._proxy(head_only=True)

    def _proxy(self, head_only=False):
        srv = self.server
        srv.last_activity = time.time()
        fwd_headers = dict(srv.stream_headers)
        rang = self.headers.get('Range')
        if rang:
            fwd_headers['Range'] = rang

        r = None
        for try_url in _url_variants(srv.target_url, srv.fallback_url):
            try:
                resp = srv.session.get(
                    try_url, headers=fwd_headers, stream=True,
                    timeout=(10, None), allow_redirects=False,
                )
                if resp.status_code in _REDIRECT_CODES:
                    location = resp.headers.get('Location', '')
                    resp.close()
                    if location:
                        srv._log(f'StreamProxy: Redirect {resp.status_code} → {location[:80]}')
                        try:
                            self.send_response(resp.status_code)
                            self.send_header('Location', location)
                            self.end_headers()
                        except Exception:
                            pass
                        srv.last_activity = time.time()
                        return
                    continue
                if resp.status_code < 400:
                    srv._log(f'StreamProxy: OK {resp.status_code} {try_url[:80]}')
                    r = resp
                    break
                srv._log(f'StreamProxy: {resp.status_code} bei {try_url[:80]}, nächster Versuch...')
                resp.close()
            except Exception as e:
                srv._log(f'StreamProxy: Fehler {try_url[:80]}: {e}')

        if r is None:
            try:
                self.send_error(502)
            except Exception:
                pass
            return

        try:
            self.send_response(r.status_code)
            for k, v in r.headers.items():
                if k.lower() in (
                    'content-type', 'content-length',
                    'transfer-encoding', 'content-range', 'accept-ranges',
                ):
                    self.send_header(k, v)
            self.end_headers()
            if not head_only:
                for chunk in r.iter_content(chunk_size=_CHUNK):
                    if chunk:
                        try:
                            self.wfile.write(chunk)
                            self.wfile.flush()
                        except (BrokenPipeError, ConnectionResetError, OSError):
                            break
        except Exception:
            pass
        finally:
            r.close()
            srv.last_activity = time.time()

    def log_message(self, *args):
        pass

    def log_request(self, *args):
        pass


class StreamProxy:
    def __init__(self, target_url, stream_headers, session=None,
                 fallback_url=None, log_func=None):
        self._url = target_url
        self._headers = stream_headers
        self._session = session or requests.Session()
        self._fallback = fallback_url
        self._log = log_func or (lambda m: None)
        self._server = None
        self._thread = None
        self.port = None

    def start(self):
        self.port = _free_port()
        server = HTTPServer(('127.0.0.1', self.port), _Handler)
        server.target_url = self._url
        server.stream_headers = self._headers
        server.session = self._session
        server.fallback_url = self._fallback
        server.last_activity = time.time()
        server.timeout = 2
        server._log = self._log
        self._server = server
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        self._log(f'StreamProxy gestartet: 127.0.0.1:{self.port} → {self._url[:80]}')
        if self._fallback:
            self._log(f'StreamProxy Fallback: {self._fallback[:80]}')
        return self

    def _run(self):
        srv = self._server
        while True:
            srv.handle_request()
            if time.time() - srv.last_activity > _IDLE_TIMEOUT:
                break
        srv.server_close()
        self._log(f'StreamProxy beendet: port={self.port}')

    def stop(self):
        if self._server:
            try:
                self._server.server_close()
            except Exception:
                pass

    @property
    def url(self):
        return f'http://127.0.0.1:{self.port}/'
