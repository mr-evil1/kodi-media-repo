import sys
from urllib.parse import parse_qsl

from resources.lib.router import router

if __name__ == '__main__':
    query = sys.argv[2][1:] if len(sys.argv) > 2 else ''
    params = dict(parse_qsl(query))
    router(params)
