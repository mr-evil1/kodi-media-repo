import xbmcaddon
import xbmc
import contextlib

_ADDON_ID = 'plugin.video.multistream'


class RequestException(Exception):
    def __init__(self, *args, response=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.response = response


class HTTPError(RequestException):
    pass


def _reraise(e):
    try:
        import requests as _rq
        if isinstance(e, _rq.exceptions.HTTPError):
            raise HTTPError(str(e), response=e.response) from e
        if isinstance(e, _rq.exceptions.RequestException):
            raise RequestException(str(e)) from e
    except ImportError:
        pass
    try:
        import httpx as _hx
        if isinstance(e, _hx.HTTPStatusError):
            raise HTTPError(str(e), response=e.response) from e
        if isinstance(e, _hx.RequestError):
            raise RequestException(str(e)) from e
    except ImportError:
        pass
    raise e


class _Response:
    __slots__ = ('_r',)

    def __init__(self, resp):
        object.__setattr__(self, '_r', resp)

    def __setattr__(self, name, value):
        setattr(object.__getattribute__(self, '_r'), name, value)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, '_r'), name)

    def raise_for_status(self):
        try:
            object.__getattribute__(self, '_r').raise_for_status()
        except Exception as e:
            _reraise(e)


def _adapt_timeout(timeout):
    import httpx
    if isinstance(timeout, tuple):
        c = timeout[0] if len(timeout) > 0 else None
        r = timeout[1] if len(timeout) > 1 else None
        return httpx.Timeout(r, connect=c)
    return timeout


class _Session:
    def __init__(self, backend, is_httpx=False):
        self._b = backend
        self._is_httpx = is_httpx
        self.headers = backend.headers

    @property
    def auth(self):
        return self._b.auth

    @auth.setter
    def auth(self, value):
        self._b.auth = value

    def _kw(self, kwargs):
        if self._is_httpx:
            kwargs = {k: v for k, v in kwargs.items() if k != 'verify'}
            if 'timeout' in kwargs:
                kwargs['timeout'] = _adapt_timeout(kwargs['timeout'])
        return kwargs

    def get(self, url, **kwargs):
        try:
            return _Response(self._b.get(url, **self._kw(kwargs)))
        except Exception as e:
            _reraise(e)

    def post(self, url, **kwargs):
        try:
            if not self._is_httpx:
                kwargs.setdefault('allow_redirects', True)
            return _Response(self._b.post(url, **self._kw(kwargs)))
        except Exception as e:
            _reraise(e)

    def mount(self, prefix, adapter):
        if not self._is_httpx:
            self._b.mount(prefix, adapter)

    def close(self):
        self._b.close()


def _use_httpx():
    try:
        if xbmcaddon.Addon(_ADDON_ID).getSetting('use_httpx') != 'true':
            return False
    except Exception:
        return False
    try:
        import httpx
        return True
    except ImportError:
        xbmc.log(f'[{_ADDON_ID}] httpx nicht verfuegbar, nutze requests', xbmc.LOGWARNING)
        return False


def new_session(pool_connections=None, pool_maxsize=None, verify=True):
    if _use_httpx():
        import httpx
        if pool_connections or pool_maxsize:
            limits = httpx.Limits(
                max_connections=pool_maxsize or 10,
                max_keepalive_connections=pool_connections or 10,
            )
            return _Session(httpx.Client(follow_redirects=True, limits=limits, verify=verify), is_httpx=True)
        return _Session(httpx.Client(follow_redirects=True, verify=verify), is_httpx=True)
    import requests
    session = requests.Session()
    session.verify = verify
    if pool_connections or pool_maxsize:
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=pool_connections or 10,
            pool_maxsize=pool_maxsize or 10,
        )
        session.mount('http://', adapter)
        session.mount('https://', adapter)
    return _Session(session)


def get(url, **kwargs):
    if _use_httpx():
        import httpx
        if 'timeout' in kwargs:
            kwargs = dict(kwargs)
            kwargs['timeout'] = _adapt_timeout(kwargs['timeout'])
        try:
            return _Response(httpx.get(url, follow_redirects=True, **kwargs))
        except Exception as e:
            _reraise(e)
    import requests
    try:
        return _Response(requests.get(url, **kwargs))
    except Exception as e:
        _reraise(e)


class _StreamResponse:
    def __init__(self, resp, is_httpx):
        self._resp = resp
        self._is_httpx = is_httpx

    @property
    def headers(self):
        return self._resp.headers

    def iter_chunks(self, chunk_size):
        if self._is_httpx:
            return self._resp.iter_bytes(chunk_size=chunk_size)
        return self._resp.iter_content(chunk_size=chunk_size)


@contextlib.contextmanager
def stream_get(session, url, headers=None):
    if session._is_httpx:
        with session._b.stream('GET', url, headers=headers) as resp:
            yield _StreamResponse(resp, True)
    else:
        resp = session._b.get(url, headers=headers, stream=True)
        try:
            yield _StreamResponse(resp, False)
        finally:
            resp.close()
