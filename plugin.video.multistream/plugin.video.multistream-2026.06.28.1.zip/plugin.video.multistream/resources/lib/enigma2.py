from resources.lib import http_client
import xml.etree.ElementTree as ET


class Enigma2Client:
    def __init__(self, server_url, username='', password='', stream_port=8001, timeout=15, log_func=None):
        self.server_url = server_url.rstrip('/')
        if self.server_url and not self.server_url.startswith(('http://', 'https://')):
            self.server_url = 'http://' + self.server_url
        self.username = username
        self.password = password
        self.stream_port = stream_port
        self.timeout = timeout
        self._log = log_func or (lambda msg: None)
        self.session = http_client.new_session()
        if username:
            self.session.auth = (username, password)

    def _get(self, path, params=None):
        url = f'{self.server_url}{path}'
        self._log(f'Enigma2 request GET {path}')
        r = self.session.get(url, params=params, timeout=self.timeout)
        self._log(f'Enigma2 response GET {path} -> {r.status_code}')
        r.raise_for_status()
        return r.text

    def test_connection(self):
        text = self._get('/web/getservices')
        return '<e2servicelistrecursive>' in text or '<e2service' in text

    def get_bouquets(self):
        text = self._get('/web/getservices')
        root = ET.fromstring(text)
        bouquets = []
        for service in root.findall('.//e2service'):
            ref = service.findtext('e2servicereference', '')
            name = service.findtext('e2servicename', '')
            if 'FROM BOUQUET' in ref:
                bouquets.append({'ref': ref, 'name': name})
        return bouquets

    def get_channels(self, bouquet_ref):
        text = self._get('/web/getservices', params={'sRef': bouquet_ref})
        root = ET.fromstring(text)
        channels = []
        for service in root.findall('.//e2service'):
            ref = service.findtext('e2servicereference', '')
            name = service.findtext('e2servicename', '')
            if not ref or not name or ref.startswith('1:64'):
                continue
            channels.append({'ref': ref, 'name': name})
        return channels

    def stream_url(self, service_ref):
        host = self.server_url.split('://')[-1].split(':')[0].split('/')[0]
        scheme = 'http'
        ref = service_ref.replace(':', '%3a')
        return f'{scheme}://{host}:{self.stream_port}/{ref}'
