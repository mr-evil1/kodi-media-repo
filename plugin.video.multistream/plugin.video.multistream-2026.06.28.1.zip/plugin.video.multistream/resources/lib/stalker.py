import concurrent.futures
import hashlib
import json
import random
import re
import string
import time
import urllib.parse

from resources.lib import http_client

EPISODE_CMD_SEP = '\x1f'

MAG_UA = ('Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 '
           '(KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3')

CHROME_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
             '(KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36')


def _random_serial(length=13):
    return ''.join(random.choices(string.digits, k=length))


def _device_id(mac):
    return hashlib.md5(mac.encode()).hexdigest().upper()


def _device_id2(mac):
    return hashlib.md5((mac + 'extra').encode()).hexdigest().upper()


def _normalise_host(host):
    if not host.startswith(('http://', 'https://')):
        host = 'http://' + host
    return host.rstrip('/')


def _strip_portal_suffix(host):
    for sfx in ('/stalker_portal/c/', '/stalker_portal/c',
                 '/stalker_portal/', '/stalker_portal',
                 '/c/', '/c'):
        if host.endswith(sfx):
            return host[:-len(sfx)]
    return host


def _clean_url(raw):
    if not raw:
        return ''
    raw = raw.strip()
    for pfx in ('ffmpeg ', 'shell ', 'vlc ', 'FFMPEG ', 'VLC '):
        if raw.startswith(pfx):
            raw = raw[len(pfx):].strip()
    if raw.startswith('http%3A') or raw.startswith('rtmp%3A'):
        raw = urllib.parse.unquote(raw)
    return raw


def _normalize_itv_cmd(cmd):
    clean = _clean_url(cmd)
    if urllib.parse.urlsplit(clean).hostname == 'localhost':
        return cmd
    m = re.search(r'(\d+)[^\d/]*$', clean)
    if not m:
        return cmd
    return 'ffmpeg http://localhost/ch/' + m.group(1)


class StalkerClient:
    PORTAL_PATH = '/portal.php'
    PAGE_WORKERS = 4

    def __init__(self, server_url, mac_address, device_profile='MAG250',
                 timezone='Europe/Berlin', locale='de', timeout=15, log_func=None,
                 user_agent=None, connect_timeout=None, read_timeout=None, page_workers=None):
        base = _strip_portal_suffix(_normalise_host(server_url))
        self.server_url = base
        self._portal_url = base + self.PORTAL_PATH
        self.mac_address = mac_address.upper().strip()
        self.device_profile = device_profile
        self.timezone = timezone
        self.locale = locale
        if connect_timeout or read_timeout:
            self.timeout = (connect_timeout or 10, read_timeout or timeout)
        else:
            self.timeout = timeout
        self.user_agent = user_agent or MAG_UA
        self._token = None
        self._serial = _random_serial()
        self._dev_id = _device_id(self.mac_address)
        self._dev_id2 = _device_id2(self.mac_address)
        self._authed = False
        self._log = log_func or (lambda msg: None)
        self._page_workers = page_workers if page_workers else self.PAGE_WORKERS
        self.session = http_client.new_session(pool_connections=20, pool_maxsize=20)

    def _headers(self, with_auth=True):
        h = {
            'User-Agent': self.user_agent,
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate',
            'X-User-Agent': f'Model: {self.device_profile}; Link: WiFi',
            'Cookie': (f'mac={self.mac_address}; stb_lang={self.locale}; '
                       f'timezone={self.timezone}; token={self._token or ""}'),
        }
        if with_auth and self._token:
            h['Authorization'] = f'Bearer {self._token}'
        return h

    def stream_headers(self):
        return {
            'User-Agent': MAG_UA,
            'Cookie': f'mac={self.mac_address}',
            'Referer': self.server_url + '/',
        }

    def _request(self, params, authorized=True):
        p = dict(params)
        p['JsHttpRequest'] = '1-xml'
        action = f"{p.get('type')}/{p.get('action')}"
        self._log(f'Stalker request {action}')
        r = self.session.get(self._portal_url, params=p,
                             headers=self._headers(with_auth=authorized),
                             timeout=self.timeout)
        self._log(f'Stalker response {action} -> {r.status_code}')
        r.raise_for_status()
        try:
            js = r.json().get('js', {})
            return js if js is not None else {}
        except ValueError:
            self._log(f'Stalker response {action} -> invalid JSON')
            return {}

    def handshake(self):
        self._log(f'Stalker handshake MAC={self.mac_address}')
        r = self.session.get(self._portal_url,
                             params={
                                 'type': 'stb', 'action': 'handshake',
                                 'prehash': '0', 'token': '',
                                 'JsHttpRequest': '1-xml',
                             },
                             headers=self._headers(with_auth=False),
                             timeout=self.timeout)
        r.raise_for_status()
        js = r.json().get('js', {})
        token = js.get('token', '')
        if not token:
            self._log('Stalker handshake: no token in response')
            raise ConnectionError('Stalker handshake fehlgeschlagen - ungueltige MAC oder URL')
        self._token = token
        try:
            self._request({
                'type': 'stb', 'action': 'get_profile',
                'hd': '1', 'num_banks': '2',
                'sn': self._serial,
                'stb_type': self.device_profile,
                'image_version': '218',
                'device_id': self._dev_id,
                'device_id2': self._dev_id2,
                'signature': '',
                'auth_second_step': '1',
                'hw_version': '1.7-BD-00',
                'ver': ('ImageDescription: 0.2.18-r23-pub-250; '
                        'ImageDate: Wed Mar 9 17:28:54 EET 2022; '
                        'PORTAL version: 6.2.0; API Version: JS API version: 343'),
            })
        except Exception as e:
            self._log(f'Stalker get_profile fehlgeschlagen (nicht kritisch): {e}')
        self._authed = True
        return token

    def test_connection(self):
        self.handshake()
        return self._authed

    def get_account_info(self):
        try:
            js = self._request({'type': 'account_info', 'action': 'get_main_info'})
            expiry_str = js.get('phone', '').strip()
            if expiry_str:
                import datetime
                for fmt in (
                    '%B %d, %Y, %I:%M %p',
                    '%B %d, %Y, %I %p',
                    '%B %d, %Y',
                    '%Y-%m-%d %H:%M:%S',
                    '%Y-%m-%d',
                    '%d.%m.%Y',
                ):
                    try:
                        dt = datetime.datetime.strptime(expiry_str, fmt)
                        return int(dt.timestamp())
                    except ValueError:
                        continue
                try:
                    return int(expiry_str)
                except ValueError:
                    pass
        except Exception as e:
            self._log(f'Stalker get_account_info fehlgeschlagen: {e}')
        return 0

    def _throttle(self):
        if self._page_workers > 1:
            self._page_workers = max(1, self._page_workers // 2)
            self._log(f'Stalker: 429 erkannt, reduziere Parallelitaet auf {self._page_workers}')

    def _fetch_with_retry(self, fetch_func, *args, fallback=None, retries=3, base_delay=1.5):
        last_exc = None
        for attempt in range(retries + 1):
            try:
                return fetch_func(*args)
            except http_client.RequestException as e:
                last_exc = e
                is_429 = (isinstance(e, http_client.HTTPError)
                         and e.response is not None and e.response.status_code == 429)
                if is_429:
                    self._throttle()
                if attempt < retries:
                    delay = base_delay * (2 ** attempt) if is_429 else base_delay * (attempt + 1)
                    self._log(f'Stalker fetch retry {attempt + 1} ({"429" if is_429 else "error"}): {e}')
                    time.sleep(delay)
        self._log(f'Stalker fetch fehlgeschlagen nach Retries: {last_exc}')
        return fallback if fallback is not None else {}

    def get_genres(self):
        js = self._request({'type': 'itv', 'action': 'get_genres'})
        return js if isinstance(js, list) else []

    def get_all_channels(self):
        js = self._request({'type': 'itv', 'action': 'get_all_channels'})
        if isinstance(js, dict):
            return js.get('data', [])
        return js if isinstance(js, list) else []

    def get_short_epg(self, ch_id, size=4):
        js = self._request({'type': 'itv', 'action': 'get_short_epg',
                            'ch_id': ch_id, 'size': size})
        return js.get('data', []) if isinstance(js, dict) else []

    def get_epg_info(self, period=5):
        js = self._request({'type': 'itv', 'action': 'get_epg_info', 'period': str(period)})
        if isinstance(js, dict) and 'data' in js:
            js = js['data']
        return js if isinstance(js, dict) else {}

    def get_epg_batch(self, channel_ids, size=4, max_workers=5):
        if not channel_ids:
            return {}
        workers = min(max_workers, self._page_workers, len(channel_ids))
        if workers <= 1:
            return {cid: self._fetch_with_retry(self.get_short_epg, cid, size, fallback=[])
                   for cid in channel_ids}
        results = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(self._fetch_with_retry, self.get_short_epg, cid, size, fallback=[]): cid
                       for cid in channel_ids}
            for future in concurrent.futures.as_completed(futures):
                cid = futures[future]
                results[cid] = future.result()
        return results

    def get_vod_categories(self):
        js = self._request({'type': 'vod', 'action': 'get_categories'})
        return js if isinstance(js, list) else []

    def get_vod_page(self, page=0, category_id=None):
        params = {'type': 'vod', 'action': 'get_ordered_list',
                  'p': page, 'sortby': 'name', 'fav': '0'}
        params['category'] = category_id if category_id else '*'
        return self._request(params)

    def get_all_vod(self, category_id=None, max_pages=200):
        first = self.get_vod_page(0, category_id)
        data = first.get('data', []) if isinstance(first, dict) else []
        if not data:
            return []
        total_items = int(first.get('total_items', first.get('total', len(data))) or len(data))
        items = list(data)
        items_per_page = len(data)
        if total_items <= items_per_page:
            return items
        collected = items_per_page
        pages = []
        page = 1
        while collected < total_items and page <= max_pages:
            pages.append(page)
            collected += items_per_page
            page += 1
        if not pages:
            return items
        workers = min(self._page_workers, len(pages))
        if workers <= 1:
            for pg in pages:
                js = self._fetch_with_retry(self.get_vod_page, pg, category_id, fallback={})
                page_data = js.get('data', []) if isinstance(js, dict) else []
                if not page_data:
                    break
                items.extend(page_data)
            return items
        results = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(self._fetch_with_retry, self.get_vod_page, p, category_id, fallback={}): p
                       for p in pages}
            for future in concurrent.futures.as_completed(futures):
                pg = futures[future]
                js = future.result()
                results[pg] = js.get('data', []) if isinstance(js, dict) else []
        for pg in pages:
            items.extend(results.get(pg, []))
        return items

    def get_series_categories(self):
        js = self._request({'type': 'series', 'action': 'get_categories'})
        return js if isinstance(js, list) else []

    def get_series_page(self, page=0, category_id=None):
        params = {'type': 'series', 'action': 'get_ordered_list',
                  'p': page, 'sortby': 'name', 'fav': '0'}
        params['category'] = category_id if category_id else '*'
        return self._request(params)

    def get_all_series(self, category_id=None, max_pages=200):
        first = self.get_series_page(0, category_id)
        data = first.get('data', []) if isinstance(first, dict) else []
        if not data:
            return []
        total_items = int(first.get('total_items', first.get('total', len(data))) or len(data))
        items = list(data)
        items_per_page = len(data)
        if total_items <= items_per_page:
            return items
        collected = items_per_page
        pages = []
        page = 1
        while collected < total_items and page <= max_pages:
            pages.append(page)
            collected += items_per_page
            page += 1
        if not pages:
            return items
        workers = min(self._page_workers, len(pages))
        if workers <= 1:
            for pg in pages:
                js = self._fetch_with_retry(self.get_series_page, pg, category_id, fallback={})
                page_data = js.get('data', []) if isinstance(js, dict) else []
                if not page_data:
                    break
                items.extend(page_data)
            return items
        results = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(self._fetch_with_retry, self.get_series_page, p, category_id, fallback={}): p
                       for p in pages}
            for future in concurrent.futures.as_completed(futures):
                pg = futures[future]
                js = future.result()
                results[pg] = js.get('data', []) if isinstance(js, dict) else []
        for pg in pages:
            items.extend(results.get(pg, []))
        return items

    def get_series_seasons(self, series_id):
        js = self._request({'type': 'series', 'action': 'get_ordered_list',
                            'movie_id': series_id, 'season_id': '0', 'episode_id': '0'})
        return js.get('data', []) if isinstance(js, dict) else []

    def create_link(self, content_type, cmd, series=None, archive_utc=None):
        send_cmd = _normalize_itv_cmd(cmd) if content_type == 'itv' else cmd
        params = {
            'type': content_type, 'action': 'create_link',
            'cmd': send_cmd, 'series': '0',
            'forced_storage': 'undefined', 'disable_ad': '0',
            'download': '0', 'force_ch_link_check': '0',
        }
        if series is not None and series != '':
            params['series'] = series
        if archive_utc:
            params['cmd'] = f'{send_cmd}&utc={int(archive_utc)}&lutc={int(time.time())}'
        js = self._request(params)
        raw = js.get('cmd', '') if isinstance(js, dict) else ''
        url = _clean_url(raw)
        if not url:
            fallback = _clean_url(cmd)
            if fallback.startswith(('http://', 'https://', 'rtmp://')):
                return fallback
        self._log(f'Stalker create_link -> {url[:80]}')
        return url

    @staticmethod
    def _extract_url(raw):
        if not raw:
            return ''
        m = re.search(r'(https?://[^\s]+)', raw)
        return m.group(1) if m else raw


class StalkerClientCompat(StalkerClient):
    """
    Fuer Portale die keinen MAG-Handshake wollen (z.B. SorglosTV):
    - Chrome User-Agent
    - MAC als URL-Query-Parameter statt Cookie/Authorization-Header
    - Kein Handshake / get_profile
    - Minimale create_link-Parameter
    """
    PAGE_WORKERS = 1

    def _headers(self, with_auth=True):
        ua = self.user_agent if self.user_agent != MAG_UA else CHROME_UA
        return {
            'User-Agent': ua,
            'Accept': ('text/html,application/xhtml+xml,application/xml;'
                       'q=0.9,image/avif,image/webp,*/*;q=0.8'),
            'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
        }

    def stream_headers(self):
        ua = self.user_agent if self.user_agent != MAG_UA else CHROME_UA
        return {
            'User-Agent': ua,
            'Referer': self.server_url + '/',
            'Connection': 'keep-alive',
        }

    def _request(self, params, authorized=True):
        p = dict(params)
        p['mac'] = self.mac_address
        p['JsHttpRequest'] = '1-xml'
        action = f"{p.get('type')}/{p.get('action')}"
        self._log(f'Stalker compat request {action}')
        r = self.session.get(self._portal_url, params=p,
                             headers=self._headers(),
                             timeout=self.timeout)
        self._log(f'Stalker compat response {action} -> {r.status_code}')
        r.raise_for_status()
        try:
            js = r.json().get('js', {})
            return js if js is not None else {}
        except ValueError:
            self._log(f'Stalker compat response {action} -> invalid JSON')
            return {}

    def handshake(self):
        self._authed = True
        self._log('Stalker compat: kein Handshake noetig')
        return ''

    def test_connection(self):
        self._authed = True
        return True

    def get_short_epg(self, ch_id, size=4):
        js = self._request({'type': 'itv', 'action': 'get_short_epg',
                            'ch_id': ch_id, 'periode': size})
        if isinstance(js, list):
            return js
        if isinstance(js, dict):
            return js.get('data', [])
        return []

    def get_epg_info(self, period=5):
        js = self._request({'type': 'itv', 'action': 'get_epg_info', 'period': str(period)})
        if isinstance(js, dict) and 'data' in js:
            js = js['data']
        return js if isinstance(js, dict) else {}

    def create_link(self, content_type, cmd, series=None, archive_utc=None):
        send_cmd = _normalize_itv_cmd(cmd) if content_type == 'itv' else cmd
        if archive_utc:
            send_cmd = f'{send_cmd}&utc={int(archive_utc)}&lutc={int(time.time())}'
        params = {
            'type': content_type, 'action': 'create_link',
            'cmd': send_cmd, 'mac': self.mac_address, 'JsHttpRequest': '1-xml',
        }
        if series is not None and series != '':
            params['series'] = series
        r = self.session.get(self._portal_url, params=params,
                             headers=self._headers(), timeout=self.timeout)
        r.raise_for_status()
        try:
            js = r.json().get('js', {})
        except ValueError:
            return ''
        raw = js.get('cmd', '') if isinstance(js, dict) else ''
        url = _clean_url(raw)
        self._log(f'Stalker compat create_link -> {url[:80]}')
        return url


def make_stalker_client(server_url, mac_address, device_profile='MAG250',
                        timezone='Europe/Berlin', locale='de',
                        timeout=15, log_func=None, compat_mode=None,
                        user_agent=None, connect_timeout=None, read_timeout=None,
                        page_workers=None):
    """
    Erstellt den passenden StalkerClient.

    compat_mode=None  -> automatisch erkennen: erst Standard-Handshake versuchen,
                         schlaegt er fehl -> Compat-Modus
    compat_mode=True  -> immer Compat (kein Handshake, Chrome-UA, MAC als Query)
    compat_mode=False -> immer Standard-Handshake
    """
    log = log_func or (lambda msg: None)
    kwargs = {'user_agent': user_agent, 'connect_timeout': connect_timeout,
             'read_timeout': read_timeout, 'page_workers': page_workers}

    if compat_mode is True:
        log('Stalker: erzwinge Compat-Modus')
        return StalkerClientCompat(server_url, mac_address, device_profile,
                                   timezone, locale, timeout, log_func, **kwargs)

    if compat_mode is False:
        return StalkerClient(server_url, mac_address, device_profile,
                             timezone, locale, timeout, log_func, **kwargs)

    client = StalkerClient(server_url, mac_address, device_profile,
                           timezone, locale, timeout, log_func, **kwargs)
    try:
        client.handshake()
        log('Stalker: Standard-Handshake erfolgreich')
        return client
    except Exception as e:
        log(f'Stalker: Standard-Handshake fehlgeschlagen ({e}), wechsle zu Compat-Modus')
        return StalkerClientCompat(server_url, mac_address, device_profile,
                                   timezone, locale, timeout, log_func, **kwargs)
