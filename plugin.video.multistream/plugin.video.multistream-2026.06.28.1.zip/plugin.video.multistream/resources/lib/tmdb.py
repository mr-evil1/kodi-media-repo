from resources.lib import http_client

BASE_URL = 'https://api.themoviedb.org/3'
IMAGE_BASE = 'https://image.tmdb.org/t/p/w500'


class TmdbClient:
    def __init__(self, api_key, timeout=10, log_func=None, language=None, region=None):
        self.api_key = api_key
        self.timeout = timeout
        self._log = log_func or (lambda msg: None)
        self.session = http_client.new_session()
        self.language = language or 'de-DE'
        self.region = region or 'DE'

    def enabled(self):
        return bool(self.api_key)

    def _get(self, path, params=None):
        if not self.api_key:
            return {}
        p = {'api_key': self.api_key, 'language': self.language}
        if params:
            p.update(params)
        try:
            r = self.session.get(f'{BASE_URL}{path}', params=p, timeout=self.timeout)
            r.raise_for_status()
            return r.json()
        except http_client.RequestException as e:
            self._log(f'TMDB request failed {path}: {e}')
            return {}

    def search_movie(self, title, year=None):
        params = {'query': title}
        if year:
            params['year'] = year
        data = self._get('/search/movie', params)
        results = data.get('results', [])
        return results[0] if results else None

    def search_tv(self, title, year=None):
        params = {'query': title}
        if year:
            params['first_air_date_year'] = year
        data = self._get('/search/tv', params)
        results = data.get('results', [])
        return results[0] if results else None

    def get_movie_details(self, tmdb_id):
        return self._get(f'/movie/{tmdb_id}', {'append_to_response': 'credits'})

    def get_tv_details(self, tmdb_id):
        return self._get(f'/tv/{tmdb_id}', {'append_to_response': 'credits'})

    @staticmethod
    def image_url(path):
        return f'{IMAGE_BASE}{path}' if path else ''
