import threading
import xbmc
import xbmcgui

from resources.lib import kodi_utils as ku

ADDON_ID = ku.ADDON_ID

_window = None
_lock = threading.Lock()
_stop_event = threading.Event()
_service_obj = None
_service_thread = None


class RecordOverlay(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def onControl(self, control):
        pass

    def onClick(self, control_id):
        pass

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (9, 10, 92):
            _close_overlay()


def _show_overlay():
    global _window
    with _lock:
        if _window is not None:
            return
        try:
            _window = RecordOverlay(
                'RecordOverlay.xml',
                ku.ADDON_PATH,
                'Default',
                '720p',
            )
            _window.show()
            ku.log_debug('TouchOverlay: Aufnahme-Zone eingeblendet')
        except Exception as e:
            ku.log(f'TouchOverlay: show fehlgeschlagen: {e}', xbmc.LOGWARNING)
            _window = None


def _close_overlay():
    global _window
    with _lock:
        if _window is None:
            return
        try:
            _window.close()
            ku.log_debug('TouchOverlay: Aufnahme-Zone ausgeblendet')
        except Exception as e:
            ku.log(f'TouchOverlay: close fehlgeschlagen: {e}', xbmc.LOGWARNING)
        finally:
            _window = None


class RecordTouchService(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._was_playing = False
        self._grace = 0

    def _is_multistream_live(self):
        try:
            if not xbmc.Player().isPlayingVideo():
                return False
            state = ku.load_json(ku.current_channel_state_path(), {})
            return bool(state.get('channel_id'))
        except Exception:
            return False

    def onPlayBackStarted(self):
        xbmc.sleep(1200)
        if self._is_multistream_live():
            _show_overlay()
            self._was_playing = True
            self._grace = 0

    def onAVStarted(self):
        if self._is_multistream_live() and not self._was_playing:
            _show_overlay()
            self._was_playing = True
            self._grace = 0

    def onPlayBackStopped(self):
        self._grace = 4
        self._was_playing = False

    def onPlayBackEnded(self):
        self._grace = 4
        self._was_playing = False

    def onPlayBackError(self):
        self._grace = 0
        self._was_playing = False
        _close_overlay()

    def run(self):
        monitor = xbmc.Monitor()
        ku.log_debug('TouchOverlay: Service gestartet')
        while not monitor.abortRequested() and not _stop_event.is_set():
            if self._grace > 0:
                self._grace -= 1
                if self._grace == 0:
                    _close_overlay()
            if monitor.waitForAbort(1):
                break
            if _stop_event.is_set():
                break
        _close_overlay()
        ku.log_debug('TouchOverlay: Service gestoppt')


def close_overlay():
    _close_overlay()


def start_touch_service():
    global _service_obj, _service_thread
    if _service_thread is not None and _service_thread.is_alive():
        return _service_obj
    _stop_event.clear()
    _service_obj = RecordTouchService()
    _service_thread = threading.Thread(target=_service_obj.run, daemon=True, name='multistream_touch_overlay')
    _service_thread.start()
    return _service_obj


def stop_touch_service():
    global _service_obj, _service_thread
    _stop_event.set()
    _close_overlay()
    _service_obj = None
    _service_thread = None


def is_touch_service_running():
    return _service_thread is not None and _service_thread.is_alive()
