import gzip
import io
from resources.lib import http_client
import xml.etree.ElementTree as ET
from datetime import datetime, timezone


def _parse_time(value):
    value = value.strip()
    main = value[:14]
    offset = value[14:].strip()
    dt = datetime.strptime(main, '%Y%m%d%H%M%S')
    if offset:
        sign = 1 if offset[0] == '+' else -1
        hours = int(offset[1:3])
        minutes = int(offset[3:5])
        delta_seconds = sign * (hours * 3600 + minutes * 60)
        dt = dt.replace(tzinfo=timezone.utc)
        ts = dt.timestamp() - delta_seconds
        return int(ts)
    return int(dt.replace(tzinfo=timezone.utc).timestamp())


class XmltvParser:
    @staticmethod
    def fetch(url, timeout=30):
        r = http_client.get(url, timeout=timeout)
        r.raise_for_status()
        data = r.content
        if url.endswith('.gz') or data[:2] == b'\x1f\x8b':
            data = gzip.decompress(data)
        return data

    @staticmethod
    def parse(xml_bytes, channel_filter=None):
        channels = {}
        events_by_channel = {}
        root = ET.fromstring(xml_bytes)
        for ch in root.findall('channel'):
            cid = ch.get('id', '')
            if not cid:
                continue
            if channel_filter and cid not in channel_filter:
                continue
            name = ch.findtext('display-name', cid)
            channels[cid] = name
        for prog in root.findall('programme'):
            cid = prog.get('channel', '')
            if not cid:
                continue
            if channel_filter and cid not in channel_filter:
                continue
            try:
                start = _parse_time(prog.get('start', ''))
                stop = _parse_time(prog.get('stop', ''))
            except (ValueError, IndexError):
                continue
            title = prog.findtext('title', '')
            desc = prog.findtext('desc', '')
            events_by_channel.setdefault(cid, []).append({
                'title': title,
                'description': desc,
                'startTime': start,
                'endTime': stop,
            })
        return channels, events_by_channel
