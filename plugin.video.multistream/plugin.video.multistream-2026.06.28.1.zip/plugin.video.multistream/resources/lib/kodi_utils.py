import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import os
import json
from urllib.parse import urlencode

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_ICON = ADDON.getAddonInfo('icon')
ADDON_FANART = ADDON.getAddonInfo('fanart')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ''
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

if not os.path.exists(PROFILE_DIR):
    os.makedirs(PROFILE_DIR)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


def is_debug_enabled():
    return get_setting_bool('debug_enabled', False)


def log_debug(msg):
    if is_debug_enabled():
        xbmc.log(f'[{ADDON_ID}][DEBUG] {msg}', xbmc.LOGINFO)


def log_error(msg):
    xbmc.log(f'[{ADDON_ID}][ERROR] {msg}', xbmc.LOGERROR)


def notify(msg, heading=None, icon=xbmcgui.NOTIFICATION_INFO, time=3000):
    xbmcgui.Dialog().notification(heading or ADDON_NAME, msg, icon, time)


def get_setting(key, default=''):
    val = ADDON.getSetting(key)
    return val if val != '' else default


def get_setting_bool(key, default=False):
    val = ADDON.getSetting(key)
    if val == '':
        return default
    return val.lower() == 'true'


def get_setting_int(key, default=0):
    val = ADDON.getSetting(key)
    if val == '':
        return default
    try:
        return int(val)
    except ValueError:
        return default


def set_setting(key, value):
    ADDON.setSetting(key, str(value))


def build_url(**kwargs):
    return f'{BASE_URL}?{urlencode(kwargs)}'


def input_dialog(heading, default='', hidden=False):
    keyboard_type = xbmcgui.INPUT_PASSWORD if hidden else xbmcgui.INPUT_ALPHANUM
    result = xbmcgui.Dialog().input(heading, defaultt=default, type=keyboard_type)
    return result


def password_dialog(heading, default=''):
    if default:
        result = xbmcgui.Dialog().input(heading, defaultt=default, type=xbmcgui.INPUT_ALPHANUM)
    else:
        result = xbmcgui.Dialog().input(heading, defaultt='', type=xbmcgui.INPUT_PASSWORD)
    return result


def select_dialog(heading, options):
    return xbmcgui.Dialog().select(heading, options)


def multiselect_dialog(heading, options, preselect=None):
    return xbmcgui.Dialog().multiselect(heading, options, preselect=preselect or [])


def yesno_dialog(heading, message, autoclose_ms=0):
    if autoclose_ms:
        return xbmcgui.Dialog().yesno(heading, message, autoclose=autoclose_ms)
    return xbmcgui.Dialog().yesno(heading, message)


def ok_dialog(heading, message):
    return xbmcgui.Dialog().ok(heading, message)


def progress_dialog():
    return xbmcgui.DialogProgress()


def browse_dialog(heading):
    result = xbmcgui.Dialog().browse(1, heading, 'files')
    return result if result else ''


def browse_folder_dialog(heading):
    result = xbmcgui.Dialog().browse(3, heading, 'files')
    return result if result else ''


def browse_file_dialog(heading, mask=''):
    result = xbmcgui.Dialog().browse(1, heading, 'files', mask)
    return result if result else ''


def addon_settings_path():
    addon_data_dir = xbmcvfs.translatePath('special://masterprofile/addon_data/' + ADDON_ID)
    return os.path.join(addon_data_dir, 'settings.xml')


def db_path():
    return os.path.join(PROFILE_DIR, 'multistream.db')


def epg_db_path():
    return os.path.join(PROFILE_DIR, 'multistream_epg.db')


def active_downloads_path():
    return os.path.join(PROFILE_DIR, 'active_downloads.json')


def providers_path():
    return os.path.join(PROFILE_DIR, 'providers.json')


def current_channel_state_path():
    return os.path.join(PROFILE_DIR, 'current_channel.json')


def load_json(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        log(f'load_json error {path}: {e}', xbmc.LOGERROR)
        return default


def save_json(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def end_directory(content_type='', cacheToTime=True):
    xbmcplugin.setContent(HANDLE, content_type)
    xbmcplugin.setPluginFanart(HANDLE, ADDON_FANART)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cacheToTime)


def add_dir_item(label, url, is_folder=True, is_action=False, art=None, info=None, context_menu=None, props=None):
    li = xbmcgui.ListItem(label=label)
    merged_art = {'thumb': ADDON_ICON, 'icon': ADDON_ICON}
    if art:
        merged_art.update(art)
    li.setArt(merged_art)
    if info:
        video_info = li.getVideoInfoTag()
        if 'title' in info:
            video_info.setTitle(info['title'])
        if 'plot' in info:
            video_info.setPlot(info['plot'])
        if 'year' in info and info['year']:
            try:
                video_info.setYear(int(info['year']))
            except (ValueError, TypeError):
                pass
        if 'genre' in info and info['genre']:
            genres = info['genre'] if isinstance(info['genre'], list) else [info['genre']]
            video_info.setGenres(genres)
        if 'cast' in info and info['cast']:
            cast_list = info['cast'] if isinstance(info['cast'], list) else [info['cast']]
            video_info.setCast([xbmc.Actor(name=c) for c in cast_list])
        if 'director' in info and info['director']:
            video_info.setDirectors([info['director']] if isinstance(info['director'], str) else info['director'])
        if 'rating' in info and info['rating']:
            try:
                video_info.setRating(float(info['rating']))
            except (ValueError, TypeError):
                pass
        if 'duration' in info and info['duration']:
            try:
                video_info.setDuration(int(info['duration']))
            except (ValueError, TypeError):
                pass
        if 'mediatype' in info:
            video_info.setMediaType(info['mediatype'])
        if 'season' in info and info['season'] is not None:
            video_info.setSeason(int(info['season']))
        if 'episode' in info and info['episode'] is not None:
            video_info.setEpisode(int(info['episode']))
        if 'tvshowtitle' in info:
            video_info.setTvShowTitle(info['tvshowtitle'])
        if 'tagline' in info and info['tagline']:
            try:
                video_info.setTagLine(info['tagline'])
            except AttributeError:
                pass
    if not is_folder and not is_action:
        li.setProperty('IsPlayable', 'true')
    if props:
        for k, v in props.items():
            li.setProperty(k, str(v))
    if context_menu:
        li.addContextMenuItems(context_menu)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=is_folder)


def resolve_url(url, succeeded=True):
    li = xbmcgui.ListItem(path=url)
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, succeeded, li)
