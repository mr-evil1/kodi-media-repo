import json
import os

import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib import http_client

PAGE_SIZE = 200

BASE_ITEM_FIELDS = [
    'Genres', 'ProductionYear', 'CommunityRating',
    'PremiereDate', 'ImageTags', 'BackdropImageTags',
    'ParentBackdropImageTags', 'ParentBackdropItemId',
    'SeriesId', 'SeriesPrimaryImageTag', 'UserData',
]


def _item_fields():
    fields = list(BASE_ITEM_FIELDS)
    try:
        addon = xbmcaddon.Addon('plugin.video.multistream')
        if addon.getSetting('include_overview') != 'false':
            fields.append('Overview')
        if addon.getSetting('include_people') == 'true':
            fields.append('People')
    except Exception:
        fields.append('Overview')
    return ','.join(fields)


def _addon_data_dir():
    try:
        return xbmcvfs.translatePath(xbmcaddon.Addon('plugin.video.multistream').getAddonInfo('profile'))
    except Exception:
        return ''


def _auth_json_path():
    return os.path.join(_addon_data_dir(), 'auth.json')


def _load_auth_cache():
    try:
        with open(_auth_json_path(), 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save_auth_cache(cache):
    try:
        path = _auth_json_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(cache, f, sort_keys=True, indent=4, ensure_ascii=False)
    except Exception:
        pass


def _cache_key(server_url, username):
    return f'{server_url}::{username}'


class JellyfinClient:
    def __init__(self, server_url, username, password, timeout=None, log_func=None):
        self.server_url = server_url.rstrip('/')
        if self.server_url and not self.server_url.startswith(('http://', 'https://')):
            self.server_url = 'http://' + self.server_url
        self.username = username
        self.password = password
        self._log = log_func or (lambda msg: None)
        self.access_token = None
        self.user_id = None
        try:
            addon = xbmcaddon.Addon('plugin.video.multistream')
            self.verify_ssl = addon.getSetting('jellyfin_verify_ssl') != 'false'
            cfg_timeout = addon.getSetting('http_timeout')
            self.timeout = int(cfg_timeout) if cfg_timeout else 60
            self.device_name = addon.getSetting('jellyfin_device_name') or 'Multistream'
            self._addon_version = addon.getAddonInfo('version') or '1.0.0'
            self._max_bitrate = int(addon.getSetting('max_stream_bitrate') or 0)
            self._force_bitrate = addon.getSetting('force_max_stream_bitrate') == 'true'
            self._max_width = int(addon.getSetting('playback_max_width') or 0)
            self._max_audio_channels = int(addon.getSetting('audio_max_channels') or 0)
        except Exception:
            self.verify_ssl = True
            self.timeout = 60
            self.device_name = 'Multistream'
            self._addon_version = '1.0.0'
            self._max_bitrate = 0
            self._force_bitrate = False
            self._max_width = 0
            self._max_audio_channels = 0
        if timeout is not None:
            self.timeout = timeout
        self.session = http_client.new_session(verify=self.verify_ssl)
        self._apply_auth_headers()

    def _auth_header(self, token=''):
        header = (
            f'MediaBrowser Client="Multistream", '
            f'Device="{self.device_name}", '
            f'DeviceId="multistream-kodi-client-id", '
            f'Version="{self._addon_version}"'
        )
        if token:
            header += f', Token={token}'
        return header

    def _apply_auth_headers(self, token=''):
        self.session.headers.update({
            'Authorization': self._auth_header(token),
        })

    @staticmethod
    def _parse_response(r, context=''):
        import re as _re

        body = r.text.strip() if r.text else ''
        ct = r.headers.get('Content-Type', '')
        ctx = f' {context}' if context else ''

        if not body:
            if r.status_code in (200, 204):
                return {}
            raise ConnectionError(
                f'Jellyfin{ctx}: Server antwortete mit leerem Body '
                f'(HTTP {r.status_code}, URL: {r.url}). '
                'Bitte Server-URL und Reverse-Proxy-Konfiguration pruefen.'
            )

        is_html = (
            'html' in ct.lower()
            or body.lower().lstrip().startswith('<!')
            or ('<html' in body.lower()[:200])
        )
        if is_html:
            title_m = _re.search(r'<title[^>]*>(.*?)</title>', body, _re.I | _re.S)
            title = title_m.group(1).strip() if title_m else ''
            plain = _re.sub(r'<[^>]+>', ' ', body)
            plain = _re.sub(r'\s+', ' ', plain).strip()[:200]
            hint = title or plain or '(kein lesbarer Inhalt)'
            raise ConnectionError(
                f'Jellyfin{ctx}: Server antwortete mit HTML statt JSON – '
                f'moeglicherweise Proxy-Login oder falsche URL. '
                f'Seiteninhalt: "{hint}"'
            )

        try:
            return r.json()
        except ValueError as exc:
            raise ConnectionError(
                f'Jellyfin{ctx}: Ungueltige JSON-Antwort '
                f'(Content-Type: {ct}). '
                f'Body (erste 200 Zeichen): {body[:200]}'
            ) from exc

    def _load_cached_token(self):
        cache = _load_auth_cache()
        key = _cache_key(self.server_url, self.username)
        entry = cache.get(key, {})
        return entry.get('token'), entry.get('user_id')

    def _save_token_to_cache(self):
        cache = _load_auth_cache()
        key = _cache_key(self.server_url, self.username)
        cache[key] = {
            'token': self.access_token,
            'user_id': self.user_id,
        }
        _save_auth_cache(cache)

    def _do_authenticate(self):
        self._log('Jellyfin request authenticate')
        self._apply_auth_headers()
        r = self.session.post(
            f'{self.server_url}/Users/AuthenticateByName',
            json={'Username': self.username, 'Pw': self.password},
            timeout=(5, self.timeout),
        )
        self._log(f'Jellyfin response authenticate -> {r.status_code}')
        r.raise_for_status()
        data = self._parse_response(r, context='Authentifizierung')
        self.access_token = data.get('AccessToken')
        self.user_id = data.get('User', {}).get('Id')
        if not self.access_token or not self.user_id:
            raise ConnectionError('Jellyfin Authentifizierung fehlgeschlagen')
        self._apply_auth_headers(self.access_token)
        self._save_token_to_cache()
        self._log(f'Jellyfin auth erfolgreich, token gecacht fuer {self.username}@{self.server_url}')

    def authenticate(self):
        token, user_id = self._load_cached_token()
        if token and user_id:
            self._log(f'Jellyfin auth: gecachter token fuer {self.username}@{self.server_url}')
            self.access_token = token
            self.user_id = user_id
            self._apply_auth_headers(token)
            return self.access_token
        self._do_authenticate()
        return self.access_token

    def test_connection(self):
        self._do_authenticate()
        return bool(self.access_token and self.user_id)

    def _get(self, path, params=None):
        self._log(f'Jellyfin request GET {path}')
        r = self.session.get(f'{self.server_url}{path}', params=params, timeout=(5, self.timeout))
        self._log(f'Jellyfin response GET {path} -> {r.status_code}')
        if r.status_code == 401:
            self._log('Jellyfin token abgelaufen, re-authentifiziere...')
            self._do_authenticate()
            r = self.session.get(f'{self.server_url}{path}', params=params, timeout=(5, self.timeout))
            self._log(f'Jellyfin response GET {path} (retry) -> {r.status_code}')
        r.raise_for_status()
        return self._parse_response(r, context=f'GET {path}')

    def _get_page(self, path, params, start_index):
        p = dict(params)
        p['StartIndex'] = start_index
        p['Limit'] = PAGE_SIZE
        data = self._get(path, p)
        return data.get('Items', [])

    def _get_all(self, path, params=None, page_cb=None):
        import concurrent.futures
        params = dict(params or {})
        params['Limit'] = PAGE_SIZE
        params['StartIndex'] = 0

        first = self._get(path, params)
        total = first.get('TotalRecordCount', 0)
        items = first.get('Items', [])
        if page_cb:
            page_cb(len(items), total)

        if len(items) >= total:
            return items

        start_indices = list(range(PAGE_SIZE, total, PAGE_SIZE))
        lock = __import__('threading').Lock()
        loaded = [len(items)]

        def fetch(start):
            page = self._get_page(path, params, start)
            with lock:
                loaded[0] += len(page)
                if page_cb:
                    page_cb(loaded[0], total)
            return (start, page)

        all_pages = {0: items}
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
            for start, page in ex.map(fetch, start_indices):
                all_pages[start] = page

        result = []
        for key in sorted(all_pages):
            result.extend(all_pages[key])
        self._log(f'Jellyfin parallel fetch {path}: {len(result)}/{total}')
        return result

    def get_movies(self, page_cb=None):
        return self._get_all(f'/Users/{self.user_id}/Items', {
            'IncludeItemTypes': 'Movie',
            'Recursive': 'true',
            'Fields': _item_fields(),
        }, page_cb=page_cb)

    def get_series(self, page_cb=None):
        return self._get_all(f'/Users/{self.user_id}/Items', {
            'IncludeItemTypes': 'Series',
            'Recursive': 'true',
            'Fields': _item_fields(),
        }, page_cb=page_cb)

    def get_movie_genres(self):
        genres_data = self._get('/Genres', {
            'IncludeItemTypes': 'Movie',
            'UserId': self.user_id,
            'Recursive': 'true',
        })
        genres = [g['Name'] for g in genres_data.get('Items', [])]
        count_data = self._get(f'/Users/{self.user_id}/Items', {
            'IncludeItemTypes': 'Movie',
            'Recursive': 'true',
            'Limit': 0,
        })
        total = count_data.get('TotalRecordCount', 0)
        return genres, total

    def get_series_genres(self):
        genres_data = self._get('/Genres', {
            'IncludeItemTypes': 'Series',
            'UserId': self.user_id,
            'Recursive': 'true',
        })
        genres = [g['Name'] for g in genres_data.get('Items', [])]
        count_data = self._get(f'/Users/{self.user_id}/Items', {
            'IncludeItemTypes': 'Series',
            'Recursive': 'true',
            'Limit': 0,
        })
        total = count_data.get('TotalRecordCount', 0)
        return genres, total

    def get_movies_by_genre(self, genre=None, page_cb=None):
        params = {
            'IncludeItemTypes': 'Movie',
            'Recursive': 'true',
            'Fields': _item_fields(),
            'SortBy': 'SortName',
            'SortOrder': 'Ascending',
        }
        if genre:
            params['Genres'] = genre
        return self._get_all(f'/Users/{self.user_id}/Items', params, page_cb=page_cb)

    def get_series_by_genre(self, genre=None, page_cb=None):
        params = {
            'IncludeItemTypes': 'Series',
            'Recursive': 'true',
            'Fields': _item_fields(),
            'SortBy': 'SortName',
            'SortOrder': 'Ascending',
        }
        if genre:
            params['Genres'] = genre
        return self._get_all(f'/Users/{self.user_id}/Items', params, page_cb=page_cb)

    def get_seasons(self, series_id):
        data = self._get(f'/Shows/{series_id}/Seasons', {
            'userId': self.user_id,
            'Fields': _item_fields(),
        })
        return data.get('Items', [])

    def get_episodes(self, series_id, season_id=None):
        params = {'userId': self.user_id, 'Fields': _item_fields()}
        if season_id:
            params['seasonId'] = season_id
        data = self._get(f'/Shows/{series_id}/Episodes', params)
        return data.get('Items', [])

    def image_url(self, item_id, image_type='Primary', tag=None, index=0):
        url = f'{self.server_url}/Items/{item_id}/Images/{image_type}/{index}?Format=original'
        if tag:
            url += f'&Tag={tag}'
        return url

    def art_for_item(self, item):
        item_id = item.get('Id', '')
        image_tags = item.get('ImageTags', {}) or {}
        backdrop_tags = item.get('BackdropImageTags', []) or []
        parent_backdrop_id = item.get('ParentBackdropItemId', '')
        parent_backdrop_tags = item.get('ParentBackdropImageTags', []) or []
        series_id = item.get('SeriesId', '')
        series_primary_tag = item.get('SeriesPrimaryImageTag', '')
        item_type = item.get('Type', '')

        art = {
            'thumb': '', 'poster': '', 'fanart': '', 'banner': '',
            'clearlogo': '', 'clearart': '', 'landscape': '',
            'tvshow.poster': '', 'tvshow.fanart': '', 'tvshow.banner': '',
            'tvshow.clearart': '', 'tvshow.clearlogo': '', 'tvshow.landscape': '',
        }

        if image_tags.get('Primary'):
            art['thumb'] = self.image_url(item_id, 'Primary', image_tags['Primary'])

        if item_type in ('Movie', 'BoxSet'):
            if image_tags.get('Primary'):
                art['poster'] = self.image_url(item_id, 'Primary', image_tags['Primary'])
            if image_tags.get('Thumb'):
                art['landscape'] = self.image_url(item_id, 'Thumb', image_tags['Thumb'])
            if image_tags.get('Banner'):
                art['banner'] = self.image_url(item_id, 'Banner', image_tags['Banner'])
            if image_tags.get('Logo'):
                art['clearlogo'] = self.image_url(item_id, 'Logo', image_tags['Logo'])
            if image_tags.get('Art'):
                art['clearart'] = self.image_url(item_id, 'Art', image_tags['Art'])

        elif item_type == 'Series':
            if image_tags.get('Primary'):
                art['poster'] = self.image_url(item_id, 'Primary', image_tags['Primary'])
                art['tvshow.poster'] = art['poster']
            if image_tags.get('Thumb'):
                art['landscape'] = self.image_url(item_id, 'Thumb', image_tags['Thumb'])
                art['tvshow.landscape'] = art['landscape']
            if image_tags.get('Banner'):
                art['banner'] = self.image_url(item_id, 'Banner', image_tags['Banner'])
                art['tvshow.banner'] = art['banner']
            if image_tags.get('Logo'):
                art['clearlogo'] = self.image_url(item_id, 'Logo', image_tags['Logo'])
                art['tvshow.clearlogo'] = art['clearlogo']
            if image_tags.get('Art'):
                art['clearart'] = self.image_url(item_id, 'Art', image_tags['Art'])
                art['tvshow.clearart'] = art['clearart']

        elif item_type in ('Episode', 'Season'):
            if series_id and series_primary_tag:
                art['tvshow.poster'] = self.image_url(series_id, 'Primary', series_primary_tag)
            if image_tags.get('Primary'):
                art['poster'] = self.image_url(item_id, 'Primary', image_tags['Primary'])
            fanart_id = parent_backdrop_id or item_id
            fanart_tag = parent_backdrop_tags[0] if parent_backdrop_tags else None
            if fanart_id and fanart_tag:
                art['tvshow.fanart'] = self.image_url(fanart_id, 'Backdrop', fanart_tag)

        if backdrop_tags:
            art['fanart'] = self.image_url(item_id, 'Backdrop', backdrop_tags[0])
        elif parent_backdrop_id and parent_backdrop_tags:
            art['fanart'] = self.image_url(parent_backdrop_id, 'Backdrop', parent_backdrop_tags[0])

        if not art['tvshow.fanart'] and art['fanart']:
            art['tvshow.fanart'] = art['fanart']

        return art

    def _device_profile(self):
        try:
            max_bitrate = self._max_bitrate
            max_width = self._max_width
            max_audio_channels = self._max_audio_channels
        except Exception:
            max_bitrate, max_width, max_audio_channels = 0, 0, 0

        direct_play_profiles = [
            {'Container': 'mp4,m4v', 'Type': 'Video', 'VideoCodec': 'h264,hevc,h265,vp9,av1', 'AudioCodec': 'aac,ac3,eac3,mp3,flac,opus'},
            {'Container': 'mkv', 'Type': 'Video', 'VideoCodec': 'h264,hevc,h265,vp9,av1,mpeg4', 'AudioCodec': 'aac,ac3,eac3,mp3,flac,opus,dts,truehd'},
            {'Container': 'avi', 'Type': 'Video', 'VideoCodec': 'h264,mpeg4', 'AudioCodec': 'aac,ac3,mp3'},
            {'Container': 'ts,mpegts', 'Type': 'Video', 'VideoCodec': 'h264,hevc,h265,mpeg2video', 'AudioCodec': 'aac,ac3,eac3,mp3'},
            {'Container': 'webm', 'Type': 'Video', 'VideoCodec': 'vp8,vp9,av1', 'AudioCodec': 'vorbis,opus'},
        ]
        if max_width > 0:
            for p in direct_play_profiles:
                p['MaxWidth'] = max_width

        transcoding_profiles = [{
            'Container': 'ts',
            'Type': 'Video',
            'VideoCodec': 'h264',
            'AudioCodec': 'aac',
            'Context': 'Streaming',
            'Protocol': 'hls',
            'MaxAudioChannels': str(max_audio_channels) if max_audio_channels > 0 else '6',
            'MinSegments': '1',
            'BreakOnNonKeyFrames': True,
        }]

        codec_profiles = []
        if max_audio_channels > 0:
            codec_profiles.append({
                'Type': 'VideoAudio',
                'Codec': 'aac,ac3,eac3,dts,truehd,flac',
                'Conditions': [{
                    'Condition': 'LessThanEqual',
                    'Property': 'AudioChannels',
                    'Value': str(max_audio_channels),
                    'IsRequired': False,
                }],
            })

        profile = {
            'Name': 'Multistream Kodi Profile',
            'MaxStreamingBitrate': max_bitrate * 1000 if max_bitrate > 0 else 140000000,
            'MaxStaticBitrate': max_bitrate * 1000 if max_bitrate > 0 else 140000000,
            'MusicStreamingTranscodingBitrate': 192000,
            'DirectPlayProfiles': direct_play_profiles,
            'TranscodingProfiles': transcoding_profiles,
            'CodecProfiles': codec_profiles,
            'SubtitleProfiles': [
                {'Format': 'srt', 'Method': 'External'},
                {'Format': 'vtt', 'Method': 'External'},
                {'Format': 'ass', 'Method': 'External'},
                {'Format': 'subrip', 'Method': 'External'},
            ],
            'ResponseProfiles': [],
        }
        return profile, max_bitrate

    def get_playback_info(self, item_id):
        if not self.access_token:
            self.authenticate()
        device_profile, max_bitrate = self._device_profile()
        body = {
            'DeviceProfile': device_profile,
            'UserId': self.user_id,
            'AutoOpenLiveStream': True,
            'AllowVideoStreamCopy': True,
            'AllowAudioStreamCopy': True,
        }
        if max_bitrate > 0:
            body['MaxStreamingBitrate'] = max_bitrate * 1000
        self._log(f'Jellyfin request POST /Items/{item_id}/PlaybackInfo')
        r = self.session.post(
            f'{self.server_url}/Items/{item_id}/PlaybackInfo',
            params={'UserId': self.user_id},
            json=body,
            timeout=(5, self.timeout),
        )
        self._log(f'Jellyfin response PlaybackInfo -> {r.status_code}')
        if r.status_code == 401:
            self._do_authenticate()
            r = self.session.post(
                f'{self.server_url}/Items/{item_id}/PlaybackInfo',
                params={'UserId': self.user_id},
                json=body,
                timeout=(5, self.timeout),
            )
        r.raise_for_status()
        return r.json()

    def resolve_playback_url(self, item_id):
        info = self.get_playback_info(item_id)
        sources = info.get('MediaSources', []) or []
        play_session_id = info.get('PlaySessionId', '')
        if not sources:
            xbmc.log(f'[Multistream] PlaybackInfo: keine MediaSources fuer item_id={item_id}, Fallback auf stream_url', xbmc.LOGWARNING)
            return self.stream_url(item_id), play_session_id, None

        source = sources[0]
        media_source_id = source.get('Id', item_id)
        container = source.get('Container', 'mp4')

        if source.get('SupportsDirectPlay'):
            url = (f'{self.server_url}/Videos/{item_id}/stream.{container}'
                   f'?Static=true&MediaSourceId={media_source_id}&api_key={self.access_token}')
            xbmc.log(f'[Multistream] PlaybackInfo: Direct Play ({container})', xbmc.LOGDEBUG)
            return url, play_session_id, media_source_id

        if source.get('SupportsDirectStream'):
            url = (f'{self.server_url}/Videos/{item_id}/stream.{container}'
                   f'?MediaSourceId={media_source_id}&PlaySessionId={play_session_id}&api_key={self.access_token}')
            xbmc.log(f'[Multistream] PlaybackInfo: Direct Stream/Remux ({container})', xbmc.LOGDEBUG)
            return url, play_session_id, media_source_id

        transcoding_url = source.get('TranscodingUrl', '')
        if transcoding_url:
            sep = '&' if '?' in transcoding_url else '?'
            url = f'{self.server_url}{transcoding_url}{sep}api_key={self.access_token}'
            xbmc.log('[Multistream] PlaybackInfo: Server-Transcoding (HLS)', xbmc.LOGDEBUG)
            return url, play_session_id, media_source_id

        xbmc.log('[Multistream] PlaybackInfo: kein DirectPlay/Stream/Transcode verfuegbar, Fallback', xbmc.LOGWARNING)
        return self.stream_url(item_id), play_session_id, media_source_id

    def resolve_download_url(self, item_id):
        if not self.access_token:
            self.authenticate()
        r = self.session.get(
            f'{self.server_url}/Items/{item_id}',
            params={'UserId': self.user_id, 'Fields': 'MediaSources'},
            timeout=(5, self.timeout),
        )
        if r.status_code == 401:
            self._do_authenticate()
            r = self.session.get(
                f'{self.server_url}/Items/{item_id}',
                params={'UserId': self.user_id, 'Fields': 'MediaSources'},
                timeout=(5, self.timeout),
            )
        r.raise_for_status()
        data = r.json()
        sources = data.get('MediaSources') or []
        if sources:
            source = sources[0]
            media_source_id = source.get('Id', item_id)
            container = source.get('Container', 'mp4')
            url = (f'{self.server_url}/Videos/{item_id}/stream.{container}'
                   f'?Static=true&MediaSourceId={media_source_id}&api_key={self.access_token}')
            return url, container
        container = 'mp4'
        url = f'{self.server_url}/Videos/{item_id}/stream.{container}?Static=true&api_key={self.access_token}'
        return url, container

    def report_playback_stopped(self, item_id, play_session_id, position_ticks=0):
        try:
            self.session.post(
                f'{self.server_url}/Sessions/Playing/Stopped',
                json={
                    'ItemId': item_id,
                    'PlaySessionId': play_session_id,
                    'PositionTicks': int(position_ticks),
                },
                timeout=(5, self.timeout),
            )
        except Exception as e:
            self._log(f'Jellyfin report_playback_stopped fehlgeschlagen: {e}')

    def stream_url(self, item_id, container='mp4'):
        if not self.access_token:
            self.authenticate()
        max_bitrate = self._max_bitrate
        force_bitrate = self._force_bitrate
        max_width = self._max_width
        max_audio_channels = self._max_audio_channels

        params = []
        needs_transcode = force_bitrate and max_bitrate > 0
        if max_bitrate > 0:
            params.append(f'VideoBitRate={max_bitrate}')
        if max_width > 0:
            params.append(f'MaxWidth={max_width}')
            needs_transcode = True
        if max_audio_channels > 0:
            params.append(f'AudioChannels={max_audio_channels}')

        params.append(f'api_key={self.access_token}')
        query = '&'.join(params)
        if needs_transcode:
            xbmc.log(f'[Multistream] stream_url: erzwinge Transcoding (Bitrate={max_bitrate}, MaxWidth={max_width})', xbmc.LOGDEBUG)
            return f'{self.server_url}/Videos/{item_id}/stream.{container}?{query}'
        return f'{self.server_url}/Videos/{item_id}/stream.{container}?Static=true&{query}'
