import sqlite3
import time
import os

SCHEMA = """
CREATE TABLE IF NOT EXISTS providers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    serverUrl TEXT NOT NULL DEFAULT '',
    username TEXT NOT NULL DEFAULT '',
    password TEXT NOT NULL DEFAULT '',
    m3uUrl TEXT NOT NULL DEFAULT '',
    epgUrl TEXT NOT NULL DEFAULT '',
    stalkerMacAddress TEXT NOT NULL DEFAULT '',
    stalkerDeviceProfile TEXT NOT NULL DEFAULT 'MAG250',
    stalkerDeviceTimezone TEXT NOT NULL DEFAULT 'Europe/Berlin',
    stalkerDeviceLocale TEXT NOT NULL DEFAULT 'de',
    stalkerCompatMode INTEGER NOT NULL DEFAULT -1,
    userAgent TEXT NOT NULL DEFAULT '',
    isEnabled INTEGER NOT NULL DEFAULT 1,
    lastSyncedAt INTEGER NOT NULL DEFAULT 0,
    lastSyncError TEXT NOT NULL DEFAULT '',
    createdAt INTEGER NOT NULL DEFAULT 0,
    epgOffset INTEGER NOT NULL DEFAULT 0,
    epgSyncInterval INTEGER NOT NULL DEFAULT 0,
    catchupType TEXT NOT NULL DEFAULT '',
    altEpgUrls TEXT NOT NULL DEFAULT '',
    lineExpiry INTEGER NOT NULL DEFAULT 0,
    useInternalEpg INTEGER NOT NULL DEFAULT -1
);

CREATE TABLE IF NOT EXISTS channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    providerId INTEGER NOT NULL,
    streamId TEXT NOT NULL DEFAULT '',
    name TEXT NOT NULL,
    logoUrl TEXT NOT NULL DEFAULT '',
    streamUrl TEXT NOT NULL DEFAULT '',
    categoryName TEXT NOT NULL DEFAULT '',
    channelNumber TEXT NOT NULL DEFAULT '',
    epgChannelId TEXT NOT NULL DEFAULT '',
    sortOrder INTEGER NOT NULL DEFAULT 0,
    tvArchive INTEGER NOT NULL DEFAULT 0,
    tvArchiveDuration INTEGER NOT NULL DEFAULT 0,
    catchupSource TEXT NOT NULL DEFAULT '',
    epgOffset INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS movies (
    id INTEGER NOT NULL,
    providerId INTEGER NOT NULL,
    streamId TEXT NOT NULL DEFAULT '',
    name TEXT NOT NULL,
    overview TEXT NOT NULL DEFAULT '',
    posterUrl TEXT NOT NULL DEFAULT '',
    backdropUrl TEXT NOT NULL DEFAULT '',
    thumbUrl TEXT NOT NULL DEFAULT '',
    bannerUrl TEXT NOT NULL DEFAULT '',
    clearlogoUrl TEXT NOT NULL DEFAULT '',
    landscapeUrl TEXT NOT NULL DEFAULT '',
    releaseDate TEXT NOT NULL DEFAULT '',
    tmdbId TEXT,
    rating REAL NOT NULL DEFAULT 0,
    streamUrl TEXT NOT NULL DEFAULT '',
    categoryName TEXT NOT NULL DEFAULT '',
    director TEXT NOT NULL DEFAULT '',
    cast TEXT NOT NULL DEFAULT '',
    genre TEXT NOT NULL DEFAULT '',
    duration TEXT NOT NULL DEFAULT '',
    containerExt TEXT NOT NULL DEFAULT '',
    watched INTEGER NOT NULL DEFAULT 0,
    resumePositionTicks INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (providerId, id)
);

CREATE TABLE IF NOT EXISTS series (
    id INTEGER NOT NULL,
    providerId INTEGER NOT NULL,
    streamId TEXT NOT NULL DEFAULT '',
    name TEXT NOT NULL,
    overview TEXT NOT NULL DEFAULT '',
    posterUrl TEXT NOT NULL DEFAULT '',
    backdropUrl TEXT NOT NULL DEFAULT '',
    thumbUrl TEXT NOT NULL DEFAULT '',
    bannerUrl TEXT NOT NULL DEFAULT '',
    clearlogoUrl TEXT NOT NULL DEFAULT '',
    landscapeUrl TEXT NOT NULL DEFAULT '',
    releaseDate TEXT NOT NULL DEFAULT '',
    tmdbId TEXT,
    rating REAL NOT NULL DEFAULT 0,
    categoryName TEXT NOT NULL DEFAULT '',
    director TEXT NOT NULL DEFAULT '',
    cast TEXT NOT NULL DEFAULT '',
    genre TEXT NOT NULL DEFAULT '',
    watched INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (providerId, id)
);

CREATE TABLE IF NOT EXISTS episodes (
    id TEXT NOT NULL,
    providerId INTEGER NOT NULL,
    seriesId INTEGER NOT NULL,
    title TEXT NOT NULL,
    overview TEXT NOT NULL DEFAULT '',
    streamUrl TEXT NOT NULL DEFAULT '',
    posterUrl TEXT NOT NULL DEFAULT '',
    backdropUrl TEXT NOT NULL DEFAULT '',
    seasonNumber INTEGER NOT NULL DEFAULT 0,
    episodeNumber INTEGER NOT NULL DEFAULT 0,
    containerExt TEXT NOT NULL DEFAULT '',
    watched INTEGER NOT NULL DEFAULT 0,
    resumePositionTicks INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (providerId, seriesId, id)
);

CREATE TABLE IF NOT EXISTS jellyfin_categories (
    providerId INTEGER NOT NULL,
    contentType TEXT NOT NULL,
    categoryName TEXT NOT NULL,
    itemCount INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (providerId, contentType, categoryName)
);

CREATE INDEX IF NOT EXISTS idx_channels_provider ON channels(providerId);
CREATE INDEX IF NOT EXISTS idx_movies_provider ON movies(providerId);
CREATE INDEX IF NOT EXISTS idx_series_provider ON series(providerId);
CREATE INDEX IF NOT EXISTS idx_episodes_series ON episodes(providerId, seriesId);

CREATE TABLE IF NOT EXISTS vod_favorites (
    providerId INTEGER NOT NULL,
    contentType TEXT NOT NULL,
    itemId TEXT NOT NULL,
    addedAt INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (providerId, contentType, itemId)
);

CREATE TABLE IF NOT EXISTS watch_history (
    providerId INTEGER NOT NULL,
    contentType TEXT NOT NULL,
    itemId TEXT NOT NULL,
    watchedAt INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (providerId, contentType, itemId)
);

CREATE TABLE IF NOT EXISTS continue_watching (
    providerId INTEGER NOT NULL,
    contentType TEXT NOT NULL,
    itemId TEXT NOT NULL,
    resumePositionTicks INTEGER NOT NULL DEFAULT 0,
    updatedAt INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (providerId, contentType, itemId)
);

CREATE INDEX IF NOT EXISTS idx_continue_watching_updated ON continue_watching(updatedAt);
CREATE INDEX IF NOT EXISTS idx_watch_history_watched ON watch_history(watchedAt);

CREATE TABLE IF NOT EXISTS recordings (
    id TEXT PRIMARY KEY,
    providerId INTEGER NOT NULL,
    channelId INTEGER NOT NULL,
    channelName TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    startTime INTEGER NOT NULL DEFAULT 0,
    endTime INTEGER NOT NULL DEFAULT 0,
    destPath TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'scheduled',
    pid INTEGER NOT NULL DEFAULT 0,
    errorMsg TEXT NOT NULL DEFAULT '',
    createdAt INTEGER NOT NULL DEFAULT 0,
    durationSecs INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_recordings_status ON recordings(status);
CREATE INDEX IF NOT EXISTS idx_recordings_start ON recordings(startTime);
"""


class Database:
    def __init__(self, path):
        self.path = path
        first_run = not os.path.exists(path)
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = lambda cursor, row: dict(zip([c[0] for c in cursor.description], row))
        self.conn.execute('PRAGMA journal_mode=WAL')
        self.conn.execute('PRAGMA cache_size=-32000')
        self.conn.execute('PRAGMA synchronous=NORMAL')
        self.conn.execute('PRAGMA temp_store=MEMORY')
        self.conn.executescript(SCHEMA)
        self._migrate()
        self.conn.commit()

    def _migrate(self):
        existing_tables = {r['name'] for r in self.conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        if 'jellyfin_categories' not in existing_tables:
            self.conn.execute("""CREATE TABLE IF NOT EXISTS jellyfin_categories (
                providerId INTEGER NOT NULL,
                contentType TEXT NOT NULL,
                categoryName TEXT NOT NULL,
                itemCount INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (providerId, contentType, categoryName)
            )""")
        cols = [r['name'] for r in self.conn.execute('PRAGMA table_info(providers)').fetchall()]
        if 'lastSyncError' not in cols:
            self.conn.execute("ALTER TABLE providers ADD COLUMN lastSyncError TEXT NOT NULL DEFAULT ''")
        if 'stalkerCompatMode' not in cols:
            self.conn.execute("ALTER TABLE providers ADD COLUMN stalkerCompatMode INTEGER NOT NULL DEFAULT -1")
        if 'userAgent' not in cols:
            self.conn.execute("ALTER TABLE providers ADD COLUMN userAgent TEXT NOT NULL DEFAULT ''")
        for table in ('movies', 'series'):
            tcols = [r['name'] for r in self.conn.execute(f'PRAGMA table_info({table})').fetchall()]
            for col in ('thumbUrl', 'bannerUrl', 'clearlogoUrl', 'landscapeUrl'):
                if col not in tcols:
                    self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} TEXT NOT NULL DEFAULT ''")
        epcols = [r['name'] for r in self.conn.execute('PRAGMA table_info(episodes)').fetchall()]
        if 'backdropUrl' not in epcols:
            self.conn.execute("ALTER TABLE episodes ADD COLUMN backdropUrl TEXT NOT NULL DEFAULT ''")
        if 'watched' not in epcols:
            self.conn.execute('ALTER TABLE episodes ADD COLUMN watched INTEGER NOT NULL DEFAULT 0')
        if 'resumePositionTicks' not in epcols:
            self.conn.execute('ALTER TABLE episodes ADD COLUMN resumePositionTicks INTEGER NOT NULL DEFAULT 0')
        if 'streamId' not in epcols:
            self.conn.execute("ALTER TABLE episodes ADD COLUMN streamId TEXT NOT NULL DEFAULT ''")
        for table in ('movies', 'series'):
            tcols = [r['name'] for r in self.conn.execute(f'PRAGMA table_info({table})').fetchall()]
            if 'watched' not in tcols:
                self.conn.execute(f'ALTER TABLE {table} ADD COLUMN watched INTEGER NOT NULL DEFAULT 0')
        mvcols = [r['name'] for r in self.conn.execute('PRAGMA table_info(movies)').fetchall()]
        if 'resumePositionTicks' not in mvcols:
            self.conn.execute('ALTER TABLE movies ADD COLUMN resumePositionTicks INTEGER NOT NULL DEFAULT 0')
        chcols = [r['name'] for r in self.conn.execute('PRAGMA table_info(channels)').fetchall()]
        if 'tvArchive' not in chcols:
            self.conn.execute('ALTER TABLE channels ADD COLUMN tvArchive INTEGER NOT NULL DEFAULT 0')
        if 'tvArchiveDuration' not in chcols:
            self.conn.execute('ALTER TABLE channels ADD COLUMN tvArchiveDuration INTEGER NOT NULL DEFAULT 0')
        if 'catchupSource' not in chcols:
            self.conn.execute("ALTER TABLE channels ADD COLUMN catchupSource TEXT NOT NULL DEFAULT ''")
        if 'epgOffset' not in chcols:
            self.conn.execute('ALTER TABLE channels ADD COLUMN epgOffset INTEGER NOT NULL DEFAULT 0')
        prcols = [r['name'] for r in self.conn.execute('PRAGMA table_info(providers)').fetchall()]
        if 'epgOffset' not in prcols:
            self.conn.execute('ALTER TABLE providers ADD COLUMN epgOffset INTEGER NOT NULL DEFAULT 0')
        if 'epgSyncInterval' not in prcols:
            self.conn.execute('ALTER TABLE providers ADD COLUMN epgSyncInterval INTEGER NOT NULL DEFAULT 0')
        if 'catchupType' not in prcols:
            self.conn.execute("ALTER TABLE providers ADD COLUMN catchupType TEXT NOT NULL DEFAULT ''")
        if 'altEpgUrls' not in prcols:
            self.conn.execute("ALTER TABLE providers ADD COLUMN altEpgUrls TEXT NOT NULL DEFAULT ''")
        if 'lineExpiry' not in prcols:
            self.conn.execute('ALTER TABLE providers ADD COLUMN lineExpiry INTEGER NOT NULL DEFAULT 0')
        if 'useInternalEpg' not in prcols:
            self.conn.execute('ALTER TABLE providers ADD COLUMN useInternalEpg INTEGER NOT NULL DEFAULT -1')

        new_table_ddl = {
            'vod_favorites': """CREATE TABLE IF NOT EXISTS vod_favorites (
                providerId INTEGER NOT NULL, contentType TEXT NOT NULL, itemId TEXT NOT NULL,
                addedAt INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (providerId, contentType, itemId))""",
            'watch_history': """CREATE TABLE IF NOT EXISTS watch_history (
                providerId INTEGER NOT NULL, contentType TEXT NOT NULL, itemId TEXT NOT NULL,
                watchedAt INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (providerId, contentType, itemId))""",
            'continue_watching': """CREATE TABLE IF NOT EXISTS continue_watching (
                providerId INTEGER NOT NULL, contentType TEXT NOT NULL, itemId TEXT NOT NULL,
                resumePositionTicks INTEGER NOT NULL DEFAULT 0, updatedAt INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (providerId, contentType, itemId))""",
            'recordings': """CREATE TABLE IF NOT EXISTS recordings (
                id TEXT PRIMARY KEY, providerId INTEGER NOT NULL, channelId INTEGER NOT NULL,
                channelName TEXT NOT NULL DEFAULT '', title TEXT NOT NULL DEFAULT '',
                description TEXT NOT NULL DEFAULT '', startTime INTEGER NOT NULL DEFAULT 0,
                endTime INTEGER NOT NULL DEFAULT 0, destPath TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'scheduled', pid INTEGER NOT NULL DEFAULT 0,
                errorMsg TEXT NOT NULL DEFAULT '', createdAt INTEGER NOT NULL DEFAULT 0,
                durationSecs INTEGER NOT NULL DEFAULT 0)""",
        }
        for tbl, ddl in new_table_ddl.items():
            if tbl not in existing_tables:
                self.conn.execute(ddl)
        self.conn.commit()

    def close(self):
        self.conn.close()

    def reset_database(self):
        tables = ['providers', 'channels', 'movies', 'series', 'episodes',
                  'jellyfin_categories', 'vod_favorites', 'watch_history',
                  'continue_watching', 'recordings']
        for table in tables:
            self.conn.execute(f'DELETE FROM {table}')
        self.conn.commit()
        self.conn.execute('VACUUM')

    def add_provider(self, name, ptype, **kwargs):
        cur = self.conn.cursor()
        cur.execute(
            """INSERT INTO providers
            (name, type, serverUrl, username, password, m3uUrl, epgUrl,
             stalkerMacAddress, stalkerDeviceProfile, stalkerDeviceTimezone,
             stalkerDeviceLocale, userAgent, isEnabled, lastSyncedAt, createdAt)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                name, ptype,
                kwargs.get('serverUrl', ''),
                kwargs.get('username', ''),
                kwargs.get('password', ''),
                kwargs.get('m3uUrl', ''),
                kwargs.get('epgUrl', ''),
                kwargs.get('stalkerMacAddress', ''),
                kwargs.get('stalkerDeviceProfile', 'MAG250'),
                kwargs.get('stalkerDeviceTimezone', 'Europe/Berlin'),
                kwargs.get('stalkerDeviceLocale', 'de'),
                kwargs.get('userAgent', ''),
                1, 0, int(time.time())
            )
        )
        self.conn.commit()
        return cur.lastrowid

    def update_provider(self, provider_id, **kwargs):
        fields = []
        values = []
        for key in ('name', 'serverUrl', 'username', 'password', 'm3uUrl', 'epgUrl',
                    'stalkerMacAddress', 'stalkerDeviceProfile', 'stalkerDeviceTimezone',
                    'stalkerDeviceLocale', 'userAgent', 'isEnabled',
                    'epgOffset', 'epgSyncInterval', 'catchupType', 'altEpgUrls', 'useInternalEpg'):
            if key in kwargs:
                fields.append(f'{key} = ?')
                values.append(kwargs[key])
        if not fields:
            return
        values.append(provider_id)
        self.conn.execute(f'UPDATE providers SET {", ".join(fields)} WHERE id = ?', values)
        self.conn.commit()

    def set_provider_synced(self, provider_id, line_expiry=None):
        if line_expiry is not None:
            self.conn.execute(
                "UPDATE providers SET lastSyncedAt = ?, lastSyncError = '', lineExpiry = ? WHERE id = ?",
                (int(time.time()), int(line_expiry), provider_id)
            )
        else:
            self.conn.execute(
                "UPDATE providers SET lastSyncedAt = ?, lastSyncError = '' WHERE id = ?",
                (int(time.time()), provider_id)
            )
        self.conn.commit()

    def set_provider_sync_error(self, provider_id, error):
        self.conn.execute(
            'UPDATE providers SET lastSyncError = ? WHERE id = ?',
            (str(error)[:500], provider_id)
        )
        self.conn.commit()

    def delete_provider(self, provider_id):
        self.conn.execute('DELETE FROM providers WHERE id = ?', (provider_id,))
        self.conn.execute('DELETE FROM channels WHERE providerId = ?', (provider_id,))
        self.conn.execute('DELETE FROM movies WHERE providerId = ?', (provider_id,))
        self.conn.execute('DELETE FROM series WHERE providerId = ?', (provider_id,))
        self.conn.execute('DELETE FROM episodes WHERE providerId = ?', (provider_id,))
        self.conn.execute('DELETE FROM jellyfin_categories WHERE providerId = ?', (provider_id,))
        self.conn.execute('DELETE FROM vod_favorites WHERE providerId = ?', (provider_id,))
        self.conn.execute('DELETE FROM watch_history WHERE providerId = ?', (provider_id,))
        self.conn.execute('DELETE FROM continue_watching WHERE providerId = ?', (provider_id,))
        self.conn.commit()

    def get_providers(self, only_enabled=False):
        q = 'SELECT * FROM providers'
        if only_enabled:
            q += ' WHERE isEnabled = 1'
        q += ' ORDER BY name'
        return self.conn.execute(q).fetchall()

    def get_provider(self, provider_id):
        return self.conn.execute('SELECT * FROM providers WHERE id = ?', (provider_id,)).fetchone()

    def clear_content(self, provider_id, table):
        self.conn.execute(f'DELETE FROM {table} WHERE providerId = ?', (provider_id,))

    def insert_channels(self, provider_id, channels):
        self.conn.execute('DELETE FROM channels WHERE providerId = ?', (provider_id,))
        self.conn.executemany(
            """INSERT INTO channels
            (providerId, streamId, name, logoUrl, streamUrl, categoryName, channelNumber, epgChannelId, sortOrder,
             tvArchive, tvArchiveDuration, catchupSource, epgOffset)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            [
                (provider_id, c.get('streamId', ''), c['name'], c.get('logoUrl', ''),
                 c.get('streamUrl', ''), c.get('categoryName', ''), c.get('channelNumber', ''),
                 c.get('epgChannelId', ''), idx,
                 1 if c.get('tvArchive') else 0, c.get('tvArchiveDuration', 0) or 0, c.get('catchupSource', ''),
                 c.get('epgOffset', 0) or 0)
                for idx, c in enumerate(channels)
            ]
        )
        self.conn.commit()

    def insert_movies(self, provider_id, movies, category=None):
        if category is not None:
            self.conn.execute('DELETE FROM movies WHERE providerId = ? AND categoryName = ?', (provider_id, category))
        else:
            self.conn.execute('DELETE FROM movies WHERE providerId = ?', (provider_id,))
        self.conn.executemany(
            """INSERT OR REPLACE INTO movies
            (id, providerId, streamId, name, overview, posterUrl, backdropUrl,
             thumbUrl, bannerUrl, clearlogoUrl, landscapeUrl,
             releaseDate, tmdbId, rating, streamUrl, categoryName,
             director, cast, genre, duration, containerExt, watched, resumePositionTicks)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            [
                (m['id'], provider_id, m.get('streamId', ''), m['name'], m.get('overview', ''),
                 m.get('posterUrl', ''), m.get('backdropUrl', ''),
                 m.get('thumbUrl', ''), m.get('bannerUrl', ''), m.get('clearlogoUrl', ''), m.get('landscapeUrl', ''),
                 m.get('releaseDate', ''), m.get('tmdbId'), m.get('rating', 0),
                 m.get('streamUrl', ''), m.get('categoryName', ''),
                 m.get('director', ''), m.get('cast', ''), m.get('genre', ''), m.get('duration', ''),
                 m.get('containerExt', ''), 1 if m.get('watched') else 0, m.get('resumePositionTicks', 0))
                for m in movies
            ]
        )
        self.conn.commit()

    def insert_series(self, provider_id, series_list, category=None):
        if category is not None:
            self.conn.execute('DELETE FROM series WHERE providerId = ? AND categoryName = ?', (provider_id, category))
        else:
            self.conn.execute('DELETE FROM series WHERE providerId = ?', (provider_id,))
        self.conn.executemany(
            """INSERT OR REPLACE INTO series
            (id, providerId, streamId, name, overview, posterUrl, backdropUrl,
             thumbUrl, bannerUrl, clearlogoUrl, landscapeUrl,
             releaseDate, tmdbId, rating, categoryName, director, cast, genre, watched)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            [
                (s['id'], provider_id, s.get('streamId', ''), s['name'], s.get('overview', ''),
                 s.get('posterUrl', ''), s.get('backdropUrl', ''),
                 s.get('thumbUrl', ''), s.get('bannerUrl', ''), s.get('clearlogoUrl', ''), s.get('landscapeUrl', ''),
                 s.get('releaseDate', ''), s.get('tmdbId'), s.get('rating', 0), s.get('categoryName', ''),
                 s.get('director', ''), s.get('cast', ''), s.get('genre', ''), 1 if s.get('watched') else 0)
                for s in series_list
            ]
        )
        self.conn.commit()

    def insert_episodes(self, provider_id, series_id, episodes):
        self.conn.execute('DELETE FROM episodes WHERE providerId = ? AND seriesId = ?', (provider_id, series_id))
        self.conn.executemany(
            """INSERT OR REPLACE INTO episodes
            (id, providerId, seriesId, title, overview, streamUrl, posterUrl, backdropUrl,
             seasonNumber, episodeNumber, containerExt, watched, resumePositionTicks, streamId)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            [
                (e['id'], provider_id, series_id, e['title'], e.get('overview', ''),
                 e.get('streamUrl', ''), e.get('posterUrl', ''), e.get('backdropUrl', ''),
                 e.get('seasonNumber', 0), e.get('episodeNumber', 0), e.get('containerExt', ''),
                 1 if e.get('watched') else 0, e.get('resumePositionTicks', 0), e.get('streamId', ''))
                for e in episodes
            ]
        )
        self.conn.commit()

    def get_movie_categories(self, provider_ids):
        if not provider_ids:
            return []
        placeholders = ','.join('?' * len(provider_ids))
        return self.conn.execute(
            f"""SELECT providerId, categoryName, COUNT(*) as cnt FROM movies
            WHERE providerId IN ({placeholders}) GROUP BY providerId, categoryName ORDER BY categoryName""",
            provider_ids
        ).fetchall()

    def get_movies(self, provider_ids, category=None, hide_watched=False):
        if not provider_ids:
            return []
        placeholders = ','.join('?' * len(provider_ids))
        q = f'SELECT * FROM movies WHERE providerId IN ({placeholders})'
        params = list(provider_ids)
        if category:
            q += ' AND categoryName = ?'
            params.append(category)
        if hide_watched:
            q += ' AND watched = 0'
        q += ' ORDER BY name'
        return self.conn.execute(q, params).fetchall()

    def get_movie(self, provider_id, movie_id):
        return self.conn.execute(
            'SELECT * FROM movies WHERE providerId = ? AND id = ?', (provider_id, movie_id)
        ).fetchone()

    def get_series_categories(self, provider_ids):
        if not provider_ids:
            return []
        placeholders = ','.join('?' * len(provider_ids))
        return self.conn.execute(
            f"""SELECT providerId, categoryName, COUNT(*) as cnt FROM series
            WHERE providerId IN ({placeholders}) GROUP BY providerId, categoryName ORDER BY categoryName""",
            provider_ids
        ).fetchall()

    def get_series_list(self, provider_ids, category=None, hide_watched=False):
        if not provider_ids:
            return []
        placeholders = ','.join('?' * len(provider_ids))
        q = f'SELECT * FROM series WHERE providerId IN ({placeholders})'
        params = list(provider_ids)
        if category:
            q += ' AND categoryName = ?'
            params.append(category)
        if hide_watched:
            q += ' AND watched = 0'
        q += ' ORDER BY name'
        return self.conn.execute(q, params).fetchall()

    def get_series_item(self, provider_id, series_id):
        return self.conn.execute(
            'SELECT * FROM series WHERE providerId = ? AND id = ?', (provider_id, series_id)
        ).fetchone()

    def get_seasons(self, provider_id, series_id):
        return self.conn.execute(
            """SELECT DISTINCT seasonNumber FROM episodes
            WHERE providerId = ? AND seriesId = ? ORDER BY seasonNumber""",
            (provider_id, series_id)
        ).fetchall()

    def get_episodes(self, provider_id, series_id, season_number):
        return self.conn.execute(
            """SELECT * FROM episodes WHERE providerId = ? AND seriesId = ? AND seasonNumber = ?
            ORDER BY episodeNumber""",
            (provider_id, series_id, season_number)
        ).fetchall()

    def get_next_episode(self, provider_id, series_id, season_number, episode_number):
        row = self.conn.execute(
            """SELECT * FROM episodes WHERE providerId = ? AND seriesId = ? AND seasonNumber = ? AND episodeNumber > ?
            ORDER BY episodeNumber LIMIT 1""",
            (provider_id, series_id, season_number, episode_number)
        ).fetchone()
        if row:
            return row
        row = self.conn.execute(
            """SELECT * FROM episodes WHERE providerId = ? AND seriesId = ? AND seasonNumber > ?
            ORDER BY seasonNumber, episodeNumber LIMIT 1""",
            (provider_id, series_id, season_number)
        ).fetchone()
        return row

    def get_episode(self, provider_id, episode_id):
        return self.conn.execute(
            'SELECT * FROM episodes WHERE providerId = ? AND id = ?', (provider_id, episode_id)
        ).fetchone()
        self.conn.execute(
            'DELETE FROM episodes WHERE providerId = ? AND seriesId = ?', (provider_id, series_id)
        )
        self.conn.commit()

    def get_channel_categories(self, provider_ids):
        if not provider_ids:
            return []
        placeholders = ','.join('?' * len(provider_ids))
        return self.conn.execute(
            f"""SELECT providerId, categoryName, COUNT(*) as cnt FROM channels
            WHERE providerId IN ({placeholders}) GROUP BY providerId, categoryName ORDER BY categoryName""",
            provider_ids
        ).fetchall()

    def get_channels(self, provider_ids, category=None):
        if not provider_ids:
            return []
        placeholders = ','.join('?' * len(provider_ids))
        q = f'SELECT * FROM channels WHERE providerId IN ({placeholders})'
        params = list(provider_ids)
        if category:
            q += ' AND categoryName = ?'
            params.append(category)
        q += ' ORDER BY sortOrder, name'
        return self.conn.execute(q, params).fetchall()

    def get_channel(self, channel_id):
        return self.conn.execute('SELECT * FROM channels WHERE id = ?', (channel_id,)).fetchone()

    def find_channels_by_name(self, name, provider_ids):
        if not provider_ids:
            return []
        placeholders = ','.join('?' * len(provider_ids))
        return self.conn.execute(
            f'SELECT * FROM channels WHERE name = ? AND providerId IN ({placeholders}) ORDER BY providerId',
            [name] + list(provider_ids)
        ).fetchall()

    def find_movies_by_name(self, name, provider_ids):
        if not provider_ids:
            return []
        placeholders = ','.join('?' * len(provider_ids))
        return self.conn.execute(
            f'SELECT * FROM movies WHERE name = ? AND providerId IN ({placeholders}) ORDER BY providerId',
            [name] + list(provider_ids)
        ).fetchall()

    def find_episodes_by_title(self, title, provider_ids):
        if not provider_ids:
            return []
        placeholders = ','.join('?' * len(provider_ids))
        return self.conn.execute(
            f'SELECT * FROM episodes WHERE title = ? AND providerId IN ({placeholders}) ORDER BY providerId',
            [title] + list(provider_ids)
        ).fetchall()

    def set_jellyfin_categories(self, provider_id, content_type, categories):
        self.conn.execute(
            'DELETE FROM jellyfin_categories WHERE providerId = ? AND contentType = ?',
            (provider_id, content_type)
        )
        self.conn.executemany(
            'INSERT INTO jellyfin_categories (providerId, contentType, categoryName, itemCount) VALUES (?,?,?,?)',
            [(provider_id, content_type, name, count) for name, count in categories]
        )
        self.conn.commit()

    def get_jellyfin_categories(self, provider_id, content_type):
        return self.conn.execute(
            'SELECT categoryName, itemCount FROM jellyfin_categories WHERE providerId = ? AND contentType = ? ORDER BY categoryName',
            (provider_id, content_type)
        ).fetchall()

    def clear_jellyfin_categories(self, provider_id):
        self.conn.execute('DELETE FROM jellyfin_categories WHERE providerId = ?', (provider_id,))
        self.conn.commit()

    def search_all(self, provider_ids, query):
        if not provider_ids:
            return [], [], []
        placeholders = ','.join('?' * len(provider_ids))
        like = f'%{query}%'
        channels = self.conn.execute(
            f'SELECT * FROM channels WHERE providerId IN ({placeholders}) AND name LIKE ? ORDER BY name LIMIT 200',
            list(provider_ids) + [like]
        ).fetchall()
        movies = self.conn.execute(
            f'SELECT * FROM movies WHERE providerId IN ({placeholders}) AND name LIKE ? ORDER BY name LIMIT 200',
            list(provider_ids) + [like]
        ).fetchall()
        series = self.conn.execute(
            f'SELECT * FROM series WHERE providerId IN ({placeholders}) AND name LIKE ? ORDER BY name LIMIT 200',
            list(provider_ids) + [like]
        ).fetchall()
        return channels, movies, series

    def add_favorite(self, provider_id, content_type, item_id):
        import time
        self.conn.execute(
            'INSERT OR REPLACE INTO vod_favorites (providerId, contentType, itemId, addedAt) VALUES (?,?,?,?)',
            (provider_id, content_type, str(item_id), int(time.time()))
        )
        self.conn.commit()

    def remove_favorite(self, provider_id, content_type, item_id):
        self.conn.execute(
            'DELETE FROM vod_favorites WHERE providerId = ? AND contentType = ? AND itemId = ?',
            (provider_id, content_type, str(item_id))
        )
        self.conn.commit()

    def is_favorite(self, provider_id, content_type, item_id):
        row = self.conn.execute(
            'SELECT 1 FROM vod_favorites WHERE providerId = ? AND contentType = ? AND itemId = ?',
            (provider_id, content_type, str(item_id))
        ).fetchone()
        return row is not None

    def get_favorites(self, content_type, provider_ids=None):
        if provider_ids:
            placeholders = ','.join('?' * len(provider_ids))
            return self.conn.execute(
                f'SELECT * FROM vod_favorites WHERE contentType = ? AND providerId IN ({placeholders}) ORDER BY addedAt DESC',
                [content_type] + list(provider_ids)
            ).fetchall()
        return self.conn.execute(
            'SELECT * FROM vod_favorites WHERE contentType = ? ORDER BY addedAt DESC',
            (content_type,)
        ).fetchall()

    def add_watch_history(self, provider_id, content_type, item_id):
        import time
        self.conn.execute(
            'INSERT OR REPLACE INTO watch_history (providerId, contentType, itemId, watchedAt) VALUES (?,?,?,?)',
            (provider_id, content_type, str(item_id), int(time.time()))
        )
        self.conn.commit()

    def get_watch_history(self, content_type=None, provider_ids=None, limit=50):
        q = 'SELECT * FROM watch_history'
        params = []
        conditions = []
        if content_type:
            conditions.append('contentType = ?')
            params.append(content_type)
        if provider_ids:
            placeholders = ','.join('?' * len(provider_ids))
            conditions.append(f'providerId IN ({placeholders})')
            params.extend(provider_ids)
        if conditions:
            q += ' WHERE ' + ' AND '.join(conditions)
        q += f' ORDER BY watchedAt DESC LIMIT {int(limit)}'
        return self.conn.execute(q, params).fetchall()

    def update_continue_watching(self, provider_id, content_type, item_id, resume_ticks):
        import time
        self.conn.execute(
            'INSERT OR REPLACE INTO continue_watching (providerId, contentType, itemId, resumePositionTicks, updatedAt) VALUES (?,?,?,?,?)',
            (provider_id, content_type, str(item_id), resume_ticks, int(time.time()))
        )
        rows = self.conn.execute(
            'SELECT providerId, contentType, itemId FROM continue_watching ORDER BY updatedAt DESC'
        ).fetchall()
        if len(rows) > 5:
            for old in rows[5:]:
                self.conn.execute(
                    'DELETE FROM continue_watching WHERE providerId = ? AND contentType = ? AND itemId = ?',
                    (old[0], old[1], old[2])
                )
        self.conn.commit()

    def remove_continue_watching(self, provider_id, content_type, item_id):
        self.conn.execute(
            'DELETE FROM continue_watching WHERE providerId = ? AND contentType = ? AND itemId = ?',
            (provider_id, content_type, str(item_id))
        )
        self.conn.commit()

    def get_continue_watching(self, provider_ids=None, limit=50):
        q = 'SELECT * FROM continue_watching'
        params = []
        if provider_ids:
            placeholders = ','.join('?' * len(provider_ids))
            q += f' WHERE providerId IN ({placeholders})'
            params.extend(provider_ids)
        q += f' ORDER BY updatedAt DESC LIMIT {int(limit)}'
        return self.conn.execute(q, params).fetchall()

    def add_recording(self, rec_id, provider_id, channel_id, channel_name, title, description,
                      start_time, end_time, dest_path, status='scheduled'):
        import time
        self.conn.execute(
            '''INSERT OR REPLACE INTO recordings
            (id, providerId, channelId, channelName, title, description,
             startTime, endTime, destPath, status, pid, errorMsg, createdAt, durationSecs)
            VALUES (?,?,?,?,?,?,?,?,?,?,0,'',?,?)''',
            (rec_id, provider_id, channel_id, channel_name, title, description,
             start_time, end_time, dest_path, status, int(time.time()),
             max(0, int(end_time) - int(start_time)))
        )
        self.conn.commit()

    def update_recording(self, rec_id, **kwargs):
        fields, values = [], []
        for k in ('status', 'pid', 'errorMsg', 'destPath', 'durationSecs'):
            if k in kwargs:
                fields.append(f'{k} = ?')
                values.append(kwargs[k])
        if not fields:
            return
        values.append(rec_id)
        self.conn.execute(f'UPDATE recordings SET {", ".join(fields)} WHERE id = ?', values)
        self.conn.commit()

    def update_recording_schedule(self, rec_id, title, start_time, end_time):
        self.conn.execute(
            'UPDATE recordings SET title = ?, startTime = ?, endTime = ?, durationSecs = ? WHERE id = ?',
            (title, start_time, end_time, max(0, int(end_time) - int(start_time)), rec_id)
        )
        self.conn.commit()

    def get_recordings(self, status=None):
        if status:
            if isinstance(status, (list, tuple)):
                placeholders = ','.join('?' * len(status))
                return self.conn.execute(
                    f'SELECT * FROM recordings WHERE status IN ({placeholders}) ORDER BY startTime DESC',
                    list(status)
                ).fetchall()
            return self.conn.execute(
                'SELECT * FROM recordings WHERE status = ? ORDER BY startTime DESC', (status,)
            ).fetchall()
        return self.conn.execute('SELECT * FROM recordings ORDER BY startTime DESC').fetchall()

    def get_recording(self, rec_id):
        return self.conn.execute('SELECT * FROM recordings WHERE id = ?', (rec_id,)).fetchone()

    def delete_recording(self, rec_id):
        self.conn.execute('DELETE FROM recordings WHERE id = ?', (rec_id,))
        self.conn.commit()

    def get_scheduled_recordings(self, before_ts):
        return self.conn.execute(
            "SELECT * FROM recordings WHERE status = 'scheduled' AND startTime <= ?",
            (before_ts,)
        ).fetchall()


EPG_SCHEMA = """
CREATE TABLE IF NOT EXISTS epg_channels (
    providerId INTEGER NOT NULL,
    channelId TEXT NOT NULL,
    displayName TEXT NOT NULL,
    PRIMARY KEY (providerId, channelId)
);

CREATE TABLE IF NOT EXISTS epg_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    providerId INTEGER NOT NULL,
    channelId TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    startTime INTEGER NOT NULL,
    endTime INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS epg_reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    providerId INTEGER NOT NULL,
    channelId TEXT NOT NULL,
    eventTitle TEXT NOT NULL DEFAULT '',
    startTime INTEGER NOT NULL,
    endTime INTEGER NOT NULL,
    alarmId TEXT NOT NULL DEFAULT '',
    createdAt INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS epg_channel_map (
    providerId INTEGER NOT NULL,
    channelDbId INTEGER NOT NULL,
    epgChannelId TEXT NOT NULL,
    PRIMARY KEY (providerId, channelDbId)
);

CREATE INDEX IF NOT EXISTS idx_epg_events_channel ON epg_events(providerId, channelId, startTime);
CREATE INDEX IF NOT EXISTS idx_epg_reminders_start ON epg_reminders(startTime);
"""


class EpgDatabase:
    def __init__(self, path):
        self.path = path
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = lambda cursor, row: dict(zip([c[0] for c in cursor.description], row))
        self.conn.execute('PRAGMA journal_mode=WAL')
        self.conn.execute('PRAGMA cache_size=-16000')
        self.conn.execute('PRAGMA synchronous=NORMAL')
        self.conn.execute('PRAGMA temp_store=MEMORY')
        self.conn.executescript(EPG_SCHEMA)
        self.conn.commit()

    def close(self):
        self.conn.close()

    def clear_epg_for_provider(self, provider_id):
        self.conn.execute('DELETE FROM epg_channels WHERE providerId = ?', (provider_id,))
        self.conn.execute('DELETE FROM epg_events WHERE providerId = ?', (provider_id,))
        self.conn.execute('DELETE FROM epg_channel_map WHERE providerId = ?', (provider_id,))
        self.conn.commit()

    def delete_provider(self, provider_id):
        self.clear_epg_for_provider(provider_id)
        self.conn.execute('DELETE FROM epg_reminders WHERE providerId = ?', (provider_id,))
        self.conn.commit()

    def insert_epg_batch(self, provider_id, entries):
        with self.conn:
            for channel_id, display_name, events in entries:
                self.conn.execute(
                    'INSERT OR REPLACE INTO epg_channels (providerId, channelId, displayName) VALUES (?,?,?)',
                    (provider_id, channel_id, display_name)
                )
                self.conn.execute(
                    'DELETE FROM epg_events WHERE providerId = ? AND channelId = ?',
                    (provider_id, channel_id)
                )
                if events:
                    self.conn.executemany(
                        'INSERT INTO epg_events (providerId, channelId, title, description, startTime, endTime) VALUES (?,?,?,?,?,?)',
                        [(provider_id, channel_id, e['title'], e.get('description', ''), e['startTime'], e['endTime'])
                         for e in events]
                    )

    def insert_epg(self, provider_id, channel_id, display_name, events):
        self.insert_epg_batch(provider_id, [(channel_id, display_name, events)])

    def get_current_epg(self, provider_id, channel_id, now_ts):
        return self.conn.execute(
            """SELECT * FROM epg_events WHERE providerId = ? AND channelId = ?
            AND startTime <= ? AND endTime >= ? ORDER BY startTime LIMIT 1""",
            (provider_id, channel_id, now_ts, now_ts)
        ).fetchone()

    def get_current_or_next_epg(self, provider_id, channel_id, now_ts):
        row = self.conn.execute(
            """SELECT * FROM epg_events WHERE providerId = ? AND channelId = ?
            AND startTime <= ? AND endTime >= ? ORDER BY startTime LIMIT 1""",
            (provider_id, channel_id, now_ts, now_ts)
        ).fetchone()
        if row:
            return row, False
        row = self.conn.execute(
            """SELECT * FROM epg_events WHERE providerId = ? AND channelId = ?
            AND startTime > ? ORDER BY startTime LIMIT 1""",
            (provider_id, channel_id, now_ts)
        ).fetchone()
        return row, True

    def get_upcoming_epg(self, provider_id, channel_id, now_ts, limit=3):
        return self.conn.execute(
            """SELECT * FROM epg_events WHERE providerId = ? AND channelId = ?
            AND startTime > ? ORDER BY startTime LIMIT ?""",
            (provider_id, channel_id, now_ts, limit)
        ).fetchall()

    def get_epg_for_channel(self, provider_id, channel_id, start_ts, end_ts):
        return self.conn.execute(
            """SELECT * FROM epg_events WHERE providerId = ? AND channelId = ?
            AND endTime >= ? AND startTime <= ? ORDER BY startTime""",
            (provider_id, channel_id, start_ts, end_ts)
        ).fetchall()

    def prune_old_epg_events(self, before_ts):
        self.conn.execute('DELETE FROM epg_events WHERE endTime < ?', (before_ts,))
        self.conn.commit()
        return self.conn.execute('SELECT changes()').fetchone()

    def add_epg_reminder(self, provider_id, channel_id, event_title, start_time, end_time, alarm_id=''):
        self.conn.execute(
            'INSERT INTO epg_reminders (providerId, channelId, eventTitle, startTime, endTime, alarmId, createdAt) VALUES (?,?,?,?,?,?,?)',
            (provider_id, channel_id, event_title, start_time, end_time, alarm_id, int(time.time()))
        )
        self.conn.commit()

    def remove_epg_reminder(self, reminder_id):
        self.conn.execute('DELETE FROM epg_reminders WHERE id = ?', (reminder_id,))
        self.conn.commit()

    def get_epg_reminders(self, provider_id=None):
        if provider_id:
            return self.conn.execute(
                'SELECT * FROM epg_reminders WHERE providerId = ? ORDER BY startTime',
                (provider_id,)
            ).fetchall()
        return self.conn.execute('SELECT * FROM epg_reminders ORDER BY startTime').fetchall()

    def find_epg_reminder(self, provider_id, channel_id, start_time):
        return self.conn.execute(
            'SELECT * FROM epg_reminders WHERE providerId = ? AND channelId = ? AND startTime = ?',
            (provider_id, channel_id, start_time)
        ).fetchone()

    def set_epg_channel_map(self, provider_id, channel_db_id, epg_channel_id):
        self.conn.execute(
            'INSERT OR REPLACE INTO epg_channel_map (providerId, channelDbId, epgChannelId) VALUES (?,?,?)',
            (provider_id, channel_db_id, epg_channel_id)
        )
        self.conn.commit()

    def get_epg_channel_map(self, provider_id):
        rows = self.conn.execute(
            'SELECT channelDbId, epgChannelId FROM epg_channel_map WHERE providerId = ?',
            (provider_id,)
        ).fetchall()
        return {r['channelDbId']: r['epgChannelId'] for r in rows}

    def get_epg_channel_id_for_channel(self, provider_id, channel_db_id):
        row = self.conn.execute(
            'SELECT epgChannelId FROM epg_channel_map WHERE providerId = ? AND channelDbId = ?',
            (provider_id, channel_db_id)
        ).fetchone()
        return row['epgChannelId'] if row else None

    def fuzzy_match_epg_channels(self, provider_id, channels):
        epg_channels = self.conn.execute(
            'SELECT channelId, displayName FROM epg_channels WHERE providerId = ?', (provider_id,)
        ).fetchall()
        if not channels or not epg_channels:
            return 0, []
        import difflib
        epg_names = {r['channelId']: r['displayName'].lower() for r in epg_channels}
        epg_ids = list(epg_names.keys())
        epg_display = list(epg_names.values())
        matched = 0
        updates = []
        for ch in channels:
            if ch['epgChannelId']:
                continue
            best = difflib.get_close_matches(ch['name'].lower(), epg_display, n=1, cutoff=0.6)
            if best:
                idx = epg_display.index(best[0])
                updates.append((epg_ids[idx], ch['id']))
                matched += 1
        return matched, updates

    def reset_database(self):
        for table in ('epg_channels', 'epg_events', 'epg_reminders', 'epg_channel_map'):
            self.conn.execute(f'DELETE FROM {table}')
        self.conn.commit()
        self.conn.execute('VACUUM')
