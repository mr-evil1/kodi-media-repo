import re

XTREAM_GET_RE = re.compile(r'(https?://[^/\s]+)/get\.php\?[^\s]*username=([^&\s]+)[^\s]*password=([^&\s]+)', re.IGNORECASE)
XTREAM_STREAM_RE = re.compile(r'(https?://[^/\s]+)/(?:live|movie|series)/([^/\s]+)/([^/\s]+)/', re.IGNORECASE)
XTREAM_KV_URL_RE = re.compile(r'^(?:(?:url|host|server|portal)\s*[=:]\s*(https?://\S+)|(https?://[^\s/]+(?::\d+)?/?)\s*$)', re.IGNORECASE | re.MULTILINE)
XTREAM_KV_USER_RE = re.compile(r'^(?:username|user|login|benutzername|benutzer)\s*[=:]\s*(\S+)', re.IGNORECASE | re.MULTILINE)
XTREAM_KV_PASS_RE = re.compile(r'^(?:password|pass|pw|passwort|kennwort)\s*[=:]\s*(\S+)', re.IGNORECASE | re.MULTILINE)
MAC_RE = re.compile(r'((?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2})')
URL_RE = re.compile(r'(https?://[^\s\'"<>]+)')
TVG_URL_RE = re.compile(r'(?:url-tvg|x-tvg-url)="([^"]+)"', re.IGNORECASE)
HOST_RE = re.compile(r'(https?://[^/\s]+)')

JELLYFIN_TYPE_RE = re.compile(r'(?:^|\n)\s*jellyfine?\b', re.IGNORECASE)
JELLYFIN_URL_RE = re.compile(r'^(?:url|server|serverurl|adresse)\s*[=:]\s*(https?://\S+)', re.IGNORECASE | re.MULTILINE)
JELLYFIN_USER_RE = re.compile(r'^(?:username|user|benutzername|benutzer)\s*[=:]\s*(\S+)', re.IGNORECASE | re.MULTILINE)
JELLYFIN_PASS_RE = re.compile(r'^(?:password|pass|pw|passwort|kennwort)\s*[=:]\s*(.*)', re.IGNORECASE | re.MULTILINE)


def _find_jellyfin_candidates(text):
    found = []
    if not JELLYFIN_TYPE_RE.search(text):
        return found
    um = JELLYFIN_URL_RE.search(text)
    nm = JELLYFIN_USER_RE.search(text)
    pm = JELLYFIN_PASS_RE.search(text)
    if um and nm:
        server = um.group(1).rstrip('/')
        username = nm.group(1).strip()
        password = pm.group(1).strip() if pm else ''
        found.append({'serverUrl': server, 'username': username, 'password': password})
    return found


def _find_xtream_candidates(text):
    found = []
    seen = set()

    for regex in (XTREAM_GET_RE, XTREAM_STREAM_RE):
        for m in regex.finditer(text):
            key = (m.group(1).lower(), m.group(2), m.group(3))
            if key not in seen:
                seen.add(key)
                found.append({'serverUrl': m.group(1), 'username': m.group(2), 'password': m.group(3)})

    if not found:
        um = XTREAM_KV_URL_RE.search(text)
        nm = XTREAM_KV_USER_RE.search(text)
        pm = XTREAM_KV_PASS_RE.search(text)
        if um and nm and pm:
            server = (um.group(1) or um.group(2) or '').rstrip('/')
            hm = HOST_RE.match(server)
            if hm:
                server = hm.group(1)
            key = (server.lower(), nm.group(1), pm.group(1))
            if key not in seen:
                seen.add(key)
                found.append({'serverUrl': server, 'username': nm.group(1), 'password': pm.group(1)})

    return found


def _find_stalker_candidates(text):
    global_url = None
    gm = URL_RE.search(text)
    if gm:
        hm = HOST_RE.match(gm.group(1))
        if hm:
            global_url = hm.group(1)

    found = []
    seen = set()
    for line in text.splitlines():
        macs = MAC_RE.findall(line)
        if not macs:
            continue
        url = None
        um = URL_RE.search(line)
        if um:
            hm = HOST_RE.match(um.group(1))
            if hm:
                url = hm.group(1)
        url = url or global_url
        if not url:
            continue
        for mac in macs:
            key = (url.lower(), mac.upper())
            if key not in seen:
                seen.add(key)
                found.append({'serverUrl': url, 'stalkerMacAddress': mac})
    return found


def detect_epg_url(text):
    m = TVG_URL_RE.search(text)
    return m.group(1) if m else ''


def is_m3u(content):
    stripped = content.lstrip()
    return stripped.startswith('#EXTM3U') or '#EXTINF' in content


def detect_providers(source, content):
    jellyfin_candidates = _find_jellyfin_candidates(content)
    if jellyfin_candidates:
        return [('jellyfin', c) for c in jellyfin_candidates]

    xtream_candidates = _find_xtream_candidates(content) or _find_xtream_candidates(source)
    if xtream_candidates:
        return [('xtream', c) for c in xtream_candidates]

    if is_m3u(content):
        data = {'m3uUrl': source}
        epg = detect_epg_url(content)
        if epg:
            data['epgUrl'] = epg
        return [('m3u', data)]

    stalker_candidates = _find_stalker_candidates(content) or _find_stalker_candidates(source)
    if stalker_candidates:
        return [('stalker', c) for c in stalker_candidates]

    return []

