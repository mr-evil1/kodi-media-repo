import re
from resources.lib import http_client

EXTINF_RE = re.compile(r'#EXTINF:(-?\d+)\s*(.*?),(.*)')
ATTR_RE = re.compile(r'([a-zA-Z0-9_-]+)="([^"]*)"')
EXTM3U_EPG_RE = re.compile(r'(?:url-tvg|x-tvg-url)="([^"]*)"', re.IGNORECASE)


class M3uParser:
    @staticmethod
    def fetch(url_or_path, timeout=20, user_agent=None):
        if url_or_path.startswith('http://') or url_or_path.startswith('https://'):
            headers = {'User-Agent': user_agent} if user_agent else {}
            r = http_client.get(url_or_path, timeout=timeout, headers=headers)
            r.raise_for_status()
            r.encoding = r.encoding or 'utf-8'
            return r.text
        with open(url_or_path, 'r', encoding='utf-8', errors='replace') as f:
            return f.read()

    @staticmethod
    def extract_epg_url(content):
        for line in content.splitlines():
            line = line.strip()
            if line.startswith('#EXTM3U'):
                m = EXTM3U_EPG_RE.search(line)
                if m:
                    return m.group(1).strip()
                return ''
        return ''

    @staticmethod
    def parse(content):
        lines = content.splitlines()
        channels = []
        current = None
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#EXTM3U'):
                continue
            if line.startswith('#EXTINF'):
                match = EXTINF_RE.match(line)
                if not match:
                    continue
                attrs_str, name = match.group(2), match.group(3)
                attrs = dict(ATTR_RE.findall(attrs_str))
                current = {
                    'name': name.strip(),
                    'logoUrl': attrs.get('tvg-logo', ''),
                    'epgChannelId': attrs.get('tvg-id', ''),
                    'categoryName': attrs.get('group-title', 'Allgemein'),
                    'channelNumber': attrs.get('tvg-chno', ''),
                    'streamId': attrs.get('tvg-id', '') or name.strip(),
                    'tvArchive': 1 if attrs.get('catchup', attrs.get('tvg-rec', '')) else 0,
                    'tvArchiveDuration': int(attrs.get('catchup-days', attrs.get('tvg-rec', 0)) or 0),
                    'catchupSource': attrs.get('catchup-source', ''),
                }
            elif line.startswith('#'):
                continue
            else:
                if current is not None:
                    current['streamUrl'] = line
                    channels.append(current)
                    current = None
        return channels
