from resources.lib import http_client


class XtreamClient:
    def __init__(self, server_url, username, password, timeout=15, log_func=None,
                 user_agent=None, connect_timeout=None, read_timeout=None):
        self.server_url = server_url.rstrip('/')
        if self.server_url and not self.server_url.startswith(('http://', 'https://')):
            self.server_url = 'http://' + self.server_url
        self.username = username
        self.password = password
        if connect_timeout or read_timeout:
            self.timeout = (connect_timeout or 10, read_timeout or timeout)
        else:
            self.timeout = timeout
        self._log = log_func or (lambda msg: None)
        self.session = http_client.new_session()
        if user_agent:
            self.session.headers.update({'User-Agent': user_agent})

    def _api(self, action, extra=None):
        params = {
            'username': self.username,
            'password': self.password,
            'action': action,
        }
        if extra:
            params.update(extra)
        url = f'{self.server_url}/player_api.php'
        self._log(f'Xtream request {action} {extra or {}}')
        r = self.session.get(url, params=params, timeout=self.timeout)
        self._log(f'Xtream response {action} -> {r.status_code}')
        r.raise_for_status()
        return r.json()

    def test_connection(self):
        params = {'username': self.username, 'password': self.password}
        url = f'{self.server_url}/player_api.php'
        self._log('Xtream request test_connection')
        r = self.session.get(url, params=params, timeout=self.timeout)
        self._log(f'Xtream response test_connection -> {r.status_code}')
        r.raise_for_status()
        data = r.json()
        return data.get('user_info', {}).get('auth') == 1

    def get_account_info(self):
        try:
            params = {'username': self.username, 'password': self.password}
            url = f'{self.server_url}/player_api.php'
            r = self.session.get(url, params=params, timeout=self.timeout)
            r.raise_for_status()
            exp = r.json().get('user_info', {}).get('exp_date')
            if exp:
                return int(exp)
        except Exception as e:
            self._log(f'Xtream get_account_info fehlgeschlagen: {e}')
        return 0

    def get_live_categories(self):
        return self._api('get_live_categories') or []

    def get_live_streams(self, category_id=None):
        extra = {'category_id': category_id} if category_id else None
        return self._api('get_live_streams', extra) or []

    def get_vod_categories(self):
        return self._api('get_vod_categories') or []

    def get_vod_streams(self, category_id=None):
        extra = {'category_id': category_id} if category_id else None
        return self._api('get_vod_streams', extra) or []

    def get_vod_info(self, vod_id):
        return self._api('get_vod_info', {'vod_id': vod_id}) or {}

    def get_series_categories(self):
        return self._api('get_series_categories') or []

    def get_series(self, category_id=None):
        extra = {'category_id': category_id} if category_id else None
        return self._api('get_series', extra) or []

    def get_series_info(self, series_id):
        return self._api('get_series_info', {'series_id': series_id}) or {}

    def live_stream_url(self, stream_id, ext='m3u8'):
        return f'{self.server_url}/live/{self.username}/{self.password}/{stream_id}.{ext}'

    def movie_stream_url(self, stream_id, ext='mp4'):
        return f'{self.server_url}/movie/{self.username}/{self.password}/{stream_id}.{ext}'

    def series_stream_url(self, episode_id, ext='mp4'):
        return f'{self.server_url}/series/{self.username}/{self.password}/{episode_id}.{ext}'

    def catchup_url(self, stream_id, start_dt, duration_minutes, ext='ts'):
        start_str = start_dt.strftime('%Y-%m-%d:%H-%M')
        return (f'{self.server_url}/timeshift.php'
                f'?username={self.username}&password={self.password}'
                f'&stream={stream_id}&start={start_str}&duration={int(duration_minutes)}')
