import time
import os
import uuid
import datetime
import zipfile
import shutil
import xbmc
import xbmcgui
from urllib.parse import urlparse

from resources.lib import kodi_utils as ku
from resources.lib.database import Database, EpgDatabase
from resources.lib.tmdb import TmdbClient
from resources.lib.sync import (
    sync_provider, sync_epg_only, fetch_xtream_episodes, fetch_stalker_episodes, fetch_jellyfin_episodes,
    fetch_jellyfin_movies_for_category, fetch_jellyfin_series_for_category,
    make_stalker, make_xtream, make_enigma2, make_jellyfin,
)
from resources.lib.stalker import EPISODE_CMD_SEP, make_stalker_client
from resources.lib.m3u import M3uParser
from resources.lib.detect import detect_providers
from resources.lib import recorder as _recorder
from resources.lib import touch_overlay as _touch_overlay

_LAST_JELLYFIN_SESSION = {'provider_id': None, 'item_id': None, 'play_session_id': None}

PROVIDER_TYPES = [
    ('xtream', 'Xtream Codes'),
    ('stalker', 'Stalker Portal'),
    ('enigma2', 'Enigma2'),
    ('jellyfin', 'Jellyfin'),
    ('m3u', 'M3U Playlist'),
]

USER_AGENT_PRESETS = [
    ('', 'Standard (leer)'),
    ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 'Chrome 120 (Windows)'),
    ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36', 'Chrome 91 (Windows)'),
    ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0', 'Edge 122 (Windows)'),
    ('Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0', 'Firefox 121 (Windows)'),
    ('Mozilla/5.0 (Windows NT 10.0 ; Win64 ; x64) AppleWebKit/537.36 (KHTML, comme Gecko) Chrome/120.0.0.0 Safari/537.36', 'Chrome 120 (Windows FR)'),
    ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, come Gecko) Chrome/120.0.0.0 Safari/537.36', 'Chrome 120 (Windows IT)'),
    ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, como Gecko) Chrome/120.0.0.0 Safari/537.36', 'Chrome 120 (Windows ES)'),
    ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, Gecko gibi) Chrome/120.0.0.0 Safari/537.36', 'Chrome 120 (Windows TR)'),
    ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15', 'Safari 17 (macOS)'),
    ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/70.0.3538.77 Chrome/70.0.3538.77 Safari/537.36', 'Chromium 70 (Ubuntu)'),
    ('Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1', 'iPhone iOS 16 (Safari)'),
    ('Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Mobile Safari/537.36', 'Samsung Galaxy (Chrome 110)'),
    ('Mozilla/5.0 (Linux; Android 11; Fire TV Stick 4K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36', 'Fire TV Stick 4K (Chrome 113)'),
    ('Mozilla/5.0 (SmartHub; TIZEN; Linux) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/x.x TV Safari/537.36', 'Samsung Tizen Smart TV'),
    ('Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', 'LG webOS Smart TV'),
    ('Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3', 'MAG200 STB'),
    ('Mozilla/5.0 (PlayStation 5 7.20) AppleWebKit/605.1.15 (KHTML, like Gecko) Java/1.8.0_212', 'PlayStation 5'),
    ('AppleTV14,1/16.6', 'Apple TV'),
    ('AppleCoreMedia/1.0.0.19C56 (iPhone; U; CPU iPhone OS 15_3_1 like Mac OS X; en_US)', 'AppleCoreMedia (iPhone iOS 15)'),
    ('MacAppStore/3.0 (Macintosh; OS X 10.15.7)', 'Mac App Store'),
    ('Amazon Fire TV', 'Amazon Fire TV'),
    ('Nvidia Shield', 'Nvidia Shield'),
    ('Roku', 'Roku'),
    ('Enigma2 HbbTV/1.1', 'Enigma2 HbbTV'),
    ('Dreambox/7020HD', 'Dreambox 7020HD'),
    ('VuPlus/Solose', 'VuPlus Solose'),
    ('Formuler/Z8', 'Formuler Z8'),
    ('SmartTV/1.0', 'SmartTV Generic'),
    ('SmartSTB', 'SmartSTB'),
    ('MAG', 'MAG'),
    ('Ministra', 'Ministra'),
    ('Geniatech', 'Geniatech'),
    ('NovaTV', 'NovaTV'),
    ('WebTV', 'WebTV'),
    ('NETFLIX', 'Netflix'),
    ('kodi', 'Kodi'),
    ('ExoPlayer', 'ExoPlayer'),
    ('MXPlayer', 'MXPlayer'),
    ('VLC/3.0.18 LibVLC/3.0.18', 'VLC 3.0.18'),
    ('VLC/3.0.16 LibVLC/3.0.16', 'VLC 3.0.16 + LibVLC 3.0.16'),
    ('VLC/3.0.7 LibVLC/3.0.20', 'VLC 3.0.7 + LibVLC 3.0.20'),
    ('VLC', 'VLC (kurz)'),
    ('Lavf/58.29.100', 'Lavf 58.29.100'),
    ('Lavf/57.25.100', 'Lavf 57.25.100'),
    ('libmpv', 'libmpv'),
    ('GStreamer/1.16.2', 'GStreamer 1.16.2'),
    ('ffmpeg', 'ffmpeg'),
    ('ASS IPTV/1.0 (Linux;Android 9) ExoPlayerLib/2.0.4 LibVLC/3.0.0-git', 'SS IPTV (Android 9 + ExoPlayer)'),
    ('SS IPTV/1.0 (Linux;Android 9) ExoPlayerLib/2.0.4 LibVLC/3.0.0-git', 'SS IPTV alt'),
    ('TiviMate/5.0.0 (Linux; Google TV)', 'TiviMate 5.0 (Google TV)'),
    ('TiviMate', 'TiviMate'),
    ('IPTVSmartersPro', 'IPTV Smarters Pro'),
    ('IPTV Smarters', 'IPTV Smarters'),
    ('IptvSmarters', 'IptvSmarters'),
    ('XCIPTV', 'XCIPTV'),
    ('GSESmartIPTV', 'GSE Smart IPTV'),
    ('OTT-Navigator', 'OTT-Navigator'),
    ('OttPlay', 'OttPlay'),
    ('Televizo', 'Televizo'),
    ('PerfectPlayer/1.5.8', 'PerfectPlayer 1.5.8'),
    ('PurplePlayer', 'PurplePlayer'),
    ('ProPlayer', 'ProPlayer'),
    ('ImPlayer', 'ImPlayer'),
    ('SimpleTV', 'SimpleTV'),
    ('ProgTV', 'ProgTV'),
    ('IP-TV Player', 'IP-TV Player'),
    ('Wink/1.31', 'Wink 1.31'),
    ('Clappr/0.3.5', 'Clappr 0.3.5'),
    ('Stalker/5.0', 'Stalker 5.0'),
    ('Dalvik/2.1.0 (Linux; U; Android 11)', 'Android 11 (Dalvik)'),
    ('Android-async-http/1.4.9', 'Android Async HTTP'),
    ('okhttp/4.12.0', 'OkHttp 4.12.0'),
    ('okhttp/4.9.3', 'OkHttp 4.9.3'),
    ('okhttp/3.12.12', 'OkHttp 3.12.12'),
    ('NSPlayer/12.0.19041.3570', 'Windows NSPlayer 12'),
    ('Aria2/1.35.0', 'Aria2 1.35'),
    ('Transmission/3.00', 'Transmission 3.00'),
    ('python-requests/2.31.0', 'Python Requests 2.31'),
    ('curl/7.81.0', 'curl 7.81'),
    ('curl/7.61.0', 'curl 7.61'),
    ('Wget/1.21', 'Wget 1.21'),
]


def get_db():
    return Database(ku.db_path())


def get_epg_db():
    return EpgDatabase(ku.epg_db_path())


def get_tmdb():
    key = ku.get_setting('tmdb_api_key')
    if not key:
        return None
    lang = ku.get_setting('tmdb_language', '') or 'de-DE'
    region = ku.get_setting('tmdb_region', '') or 'DE'
    return TmdbClient(key, log_func=ku.log_debug, language=lang, region=region)


def enabled_provider_ids(db, ptype_filter=None):
    rows = db.get_providers(only_enabled=True)
    if ptype_filter:
        rows = [r for r in rows if r['type'] in ptype_filter]
    return [r['id'] for r in rows]


def _guess_name(value):
    if not value:
        return ''
    host = urlparse(value).netloc
    if host:
        return host
    return os.path.basename(value)


def _menu_enabled(key):
    val = ku.get_setting(key)
    return val is None or val == '' or val == 'true' or val is True

def _count_scheduled_timers():
    try:
        db = get_db()
        count = len(db.get_recordings(status='scheduled'))
        db.close()
        return count
    except Exception:
        return 0


def _parse_timer_times(start_str, end_str):
    import datetime
    try:
        sh, sm = [int(x) for x in start_str.strip().split(':')]
        eh, em = [int(x) for x in end_str.strip().split(':')]
        now = datetime.datetime.now()
        start_dt = now.replace(hour=sh, minute=sm, second=0, microsecond=0)
        if start_dt <= now:
            start_dt += datetime.timedelta(days=1)
        end_dt = start_dt.replace(hour=eh, minute=em, second=0, microsecond=0)
        if end_dt <= start_dt:
            end_dt += datetime.timedelta(days=1)
        return int(start_dt.timestamp()), int(end_dt.timestamp())
    except Exception:
        return None, None


def main_menu():
    art = {'thumb': ku.ADDON_ICON, 'icon': ku.ADDON_ICON, 'fanart': ku.ADDON_FANART}
    if _menu_enabled('menu_show_livetv'):
        ku.add_dir_item('Live TV', ku.build_url(action='channel_categories'), art=art)
    if _menu_enabled('menu_show_movies'):
        ku.add_dir_item('Filme', ku.build_url(action='movie_categories'), art=art)
    if _menu_enabled('menu_show_series'):
        ku.add_dir_item('Serien', ku.build_url(action='series_categories'), art=art)
    if _menu_enabled('menu_show_search'):
        ku.add_dir_item('Suche', ku.build_url(action='search_menu'), art=art)
    if _menu_enabled('menu_show_continue_watching'):
        ku.add_dir_item('Weiter schauen', ku.build_url(action='continue_watching'), art=art)
    if _menu_enabled('menu_show_favorites'):
        ku.add_dir_item('Favoriten', ku.build_url(action='favorites_menu'), art=art)
    if _menu_enabled('menu_show_watch_history'):
        ku.add_dir_item('Zuletzt geschaut', ku.build_url(action='watch_history'), art=art)
    if _menu_enabled('menu_show_epg_reminders'):
        ku.add_dir_item('EPG-Erinnerungen', ku.build_url(action='epg_reminders'), art=art)
    if _menu_enabled('menu_show_recordings'):
        ku.add_dir_item('Aufnahmen', ku.build_url(action='recordings'), art=art)
    timer_count = _count_scheduled_timers()
    if timer_count:
        ku.add_dir_item(f'Timer ({timer_count})', ku.build_url(action='timers'), art=art)
    if _menu_enabled('menu_show_providers'):
        ku.add_dir_item('Anbieter verwalten', ku.build_url(action='providers'), art=art)
    if _menu_enabled('menu_show_settings'):
        ku.add_dir_item('Einstellungen', ku.build_url(action='open_settings'), is_folder=False, is_action=True, art=art)
    active = _load_active_downloads()
    if active:
        ku.add_dir_item(f'Downloads ({len(active)})', ku.build_url(action='downloads'), art=art)
    ku.end_directory(cacheToTime=False)


def downloads_folder():
    art = {'thumb': ku.ADDON_ICON, 'icon': ku.ADDON_ICON, 'fanart': ku.ADDON_FANART}
    active = _load_active_downloads()
    for download_id, entry in active.items():
        status = entry.get('status', 'running')
        status_label = 'Pausiert' if status == 'paused' else 'Laeuft'
        label = (f"{entry.get('name', 'Download')} - {entry.get('percent', 0)}% [{status_label}]"
                  f" ({entry.get('speed_line', '')}, Rest: {entry.get('eta_line', '--:--')})")
        url = ku.build_url(action='download_status', download_id=download_id)
        context = []
        if status == 'paused':
            context.append(('Fortsetzen', f"RunPlugin({ku.build_url(action='download_resume', download_id=download_id)})"))
        else:
            context.append(('Pause', f"RunPlugin({ku.build_url(action='download_pause', download_id=download_id)})"))
        context.append(('Abbrechen', f"RunPlugin({ku.build_url(action='download_cancel', download_id=download_id)})"))
        ku.add_dir_item(label, url, is_folder=False, is_action=True, art=art, context_menu=context)
    ku.end_directory(cacheToTime=False)


TYPE_NAMES = {
    'xtream': 'Xtream Codes',
    'stalker': 'Stalker / Ministra Portal',
    'enigma2': 'Enigma2',
    'jellyfin': 'Jellyfin',
    'm3u': 'M3U Playlist',
}


def _fmt_hhmm(ts):
    import datetime
    try:
        return datetime.datetime.fromtimestamp(int(ts)).strftime('%H:%M')
    except Exception:
        return ''


def _build_channel_epg_plot(tag, current_epg, upcoming, is_next=False):
    lines = [] if current_epg else [f'[{tag}]', '']
    if current_epg:
        t_from = _fmt_hhmm(current_epg['startTime'])
        t_to = _fmt_hhmm(current_epg['endTime'])
        time_part = f'{t_from} - {t_to}:  ' if t_from and t_to else ''
        now_label = '[COLOR=orange][B]DEMNÄCHST[/B][/COLOR]' if is_next else '[COLOR=yellow][B]JETZT[/B][/COLOR]'
        lines.append(now_label)
        lines.append(f'{time_part}{current_epg["title"]}')
        if current_epg['description']:
            lines.append(current_epg['description'])
        if upcoming:
            lines.append('')
            lines.append('[COLOR=cyan][B]Danach:[/B][/COLOR]')
            for u in upcoming:
                t_from = _fmt_hhmm(u['startTime'])
                t_to = _fmt_hhmm(u['endTime'])
                tp = f'{t_from} - {t_to}:  ' if t_from and t_to else ''
                lines.append(f'{tp}{u["title"]}')
    return '\n'.join(lines)


def _provider_plot(p):
    ptype = p['type']
    lines = [
        f"Typ: {TYPE_NAMES.get(ptype, ptype)}",
    ]
    if ptype == 'xtream':
        lines.append(f"Server: {p['serverUrl']}")
        lines.append(f"Benutzer: {p['username']}")
    elif ptype == 'stalker':
        lines.append(f"Portal: {p['serverUrl']}")
        lines.append(f"MAC: {p['stalkerMacAddress']}")
        if p['stalkerDeviceProfile']:
            lines.append(f"Geraet: {p['stalkerDeviceProfile']}")
        compat = dict(p).get('stalkerCompatMode', -1)
        if compat == 1:
            lines.append('Modus: Compat (kein Handshake)')
        elif compat == 0:
            lines.append('Modus: Standard (MAG-Handshake)')
        else:
            lines.append('Modus: Automatisch')
    elif ptype == 'enigma2':
        lines.append(f"Receiver: {p['serverUrl']}")
        if p['username']:
            lines.append(f"Benutzer: {p['username']}")
    elif ptype == 'jellyfin':
        lines.append(f"Server: {p['serverUrl']}")
        lines.append(f"Benutzer: {p['username']}")
    elif ptype == 'm3u':
        lines.append(f"Playlist: {p['m3uUrl']}")
        if p['epgUrl']:
            lines.append(f"EPG: {p['epgUrl']}")
    status = 'Aktiv' if p['isEnabled'] else 'Deaktiviert'
    lines.append(f"Status: {status}")
    last = time.strftime('%d.%m.%Y %H:%M', time.localtime(p['lastSyncedAt'])) if p['lastSyncedAt'] else 'noch nie'
    lines.append(f"Letzter Sync: {last}")
    if ptype in ('stalker', 'xtream'):
        expiry_ts = dict(p).get('lineExpiry', 0) or 0
        if expiry_ts:
            expiry_str = time.strftime('%d.%m.%Y', time.localtime(expiry_ts))
            lines.append(f"Ablaufdatum: {expiry_str}")
    return '\n'.join(lines)


def providers_menu():
    db = get_db()
    for p in db.get_providers():
        ptype = p['type']
        has_error = bool(p['lastSyncError'])
        status = 'aktiv' if p['isEnabled'] else 'deaktiviert'
        name_part = f"[COLOR red]{p['name']}[/COLOR]" if has_error else p['name']
        label = f"{name_part}  [{TYPE_NAMES.get(ptype, ptype)}]  ({status})"
        plot = _provider_plot(p)
        if has_error:
            plot += f"\n\nSync-Fehler: {p['lastSyncError']}"
        context = [
            ('Bearbeiten', f"RunPlugin({ku.build_url(action='edit_provider', id=p['id'])})"),
            ('Synchronisieren', f"RunPlugin({ku.build_url(action='sync_provider', id=p['id'])})"),
            ('EPG aktualisieren', f"RunPlugin({ku.build_url(action='sync_epg_only', id=p['id'])})"),
            ('Verbindung testen', f"RunPlugin({ku.build_url(action='test_provider', id=p['id'])})"),
            ('EPG-Quelle zurücksetzen', f"RunPlugin({ku.build_url(action='reset_epg_source', id=p['id'])})"),
            ('EPG automatisch zuordnen', f"RunPlugin({ku.build_url(action='fuzzy_epg_match', provider_id=p['id'])})"),
            ('Loeschen', f"RunPlugin({ku.build_url(action='delete_provider', id=p['id'])})"),
            ('Datenbank zuruecksetzen', f"RunPlugin({ku.build_url(action='reset_database')})"),
        ]
        ku.add_dir_item(
            label,
            ku.build_url(action='edit_provider', id=p['id']),
            is_folder=False,
            is_action=True,
            info={'title': p['name'], 'plot': plot},
            context_menu=context,
        )
    ku.add_dir_item('+ Neuer Anbieter', ku.build_url(action='select_provider_type'))
    ku.add_dir_item('+ Anbieter aus Datei/URL importieren', ku.build_url(action='import_provider'))
    ku.add_dir_item('Alle Anbieter synchronisieren', ku.build_url(action='sync_all'), is_folder=False, is_action=True)
    ku.add_dir_item('EPG-Datenbank bereinigen', ku.build_url(action='prune_epg'), is_folder=False, is_action=True)
    ku.end_directory()
    db.close()


def select_provider_type():
    labels = [t[1] for t in PROVIDER_TYPES]
    idx = ku.select_dialog('Anbieter-Typ wählen', labels)
    if idx < 0:
        return
    ptype = PROVIDER_TYPES[idx][0]
    add_provider_dialog(ptype)


def _candidate_label(ptype, data):
    type_label = dict(PROVIDER_TYPES).get(ptype, ptype)
    if ptype == 'xtream':
        return f"{type_label}: {data.get('serverUrl', '')} ({data.get('username', '')})"
    if ptype == 'stalker':
        return f"{type_label}: {data.get('serverUrl', '')} (MAC {data.get('stalkerMacAddress', '')})"
    if ptype == 'm3u':
        return f"{type_label}: {data.get('m3uUrl', '')}"
    return type_label


def _extract_prefill(source, content):
    from resources.lib.detect import (
        XTREAM_KV_URL_RE, XTREAM_KV_USER_RE, XTREAM_KV_PASS_RE, HOST_RE, URL_RE
    )
    prefill = {}
    text = content or source
    um = XTREAM_KV_URL_RE.search(text)
    if um:
        server = (um.group(1) or um.group(2) or '').rstrip('/')
        hm = HOST_RE.match(server)
        if hm:
            prefill['serverUrl'] = hm.group(1)
    elif source.startswith('http'):
        hm = HOST_RE.match(source)
        if hm:
            prefill['serverUrl'] = hm.group(1)
    nm = XTREAM_KV_USER_RE.search(text)
    if nm:
        prefill['username'] = nm.group(1)
    pm = XTREAM_KV_PASS_RE.search(text)
    if pm:
        prefill['password'] = pm.group(1)
    return prefill


def import_provider():
    choice = ku.select_dialog('Anbieter importieren', ['Datei auswählen', 'URL eingeben'])
    if choice < 0:
        return
    if choice == 0:
        source = ku.browse_dialog('Datei wählen')
    else:
        source = ku.input_dialog('M3U-/Stalker-/Xtream-Link eingeben')
    if not source:
        return

    ku.log_debug(f'import_provider: Quelle={source}')
    try:
        content = M3uParser.fetch(source)
    except Exception as e:
        ku.log(f'import_provider: Lesefehler bei {source}: {e}', xbmc.LOGERROR)
        ku.notify(f'Datei konnte nicht gelesen werden: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
        return

    candidates = detect_providers(source, content)
    if not candidates:
        ku.log(f'import_provider: Typ nicht erkannt für Quelle={source}', xbmc.LOGWARNING)
        ku.notify('Anbieter-Typ konnte nicht erkannt werden')
        if ku.yesno_dialog('Nicht erkannt', 'Typ manuell auswählen?'):
            prefill = _extract_prefill(source, content)
            labels = [t[1] for t in PROVIDER_TYPES]
            idx = ku.select_dialog('Anbieter-Typ wählen', labels)
            if idx >= 0:
                add_provider_dialog(PROVIDER_TYPES[idx][0], prefill=prefill)
        return

    ku.log_debug(f'import_provider: {len(candidates)} Anbieter erkannt: {candidates}')

    if len(candidates) > 1:
        labels = [_candidate_label(t, d) for t, d in candidates]
        indices = ku.multiselect_dialog(f'{len(candidates)} Anbieter gefunden - auswählen', labels)
        if not indices:
            return
        candidates = [candidates[i] for i in indices]
    else:
        ptype, data = candidates[0]
        type_label = dict(PROVIDER_TYPES).get(ptype, ptype)
        details = '\n'.join(f'{k}: {v}' for k, v in data.items())
        choice = ku.select_dialog(
            'Anbieter erkannt',
            [f'Hinzufügen  (Typ: {type_label})', 'Manuell bearbeiten', 'Abbrechen']
        )
        if choice < 0 or choice == 2:
            return
        if choice == 1:
            prefill = {**data, 'serverUrl': data.get('serverUrl', '')}
            labels = [t[1] for t in PROVIDER_TYPES]
            type_idx = ku.select_dialog('Anbieter-Typ wählen', labels)
            if type_idx < 0:
                return
            add_provider_dialog(PROVIDER_TYPES[type_idx][0], prefill=prefill)
            return

    first_type, first_data = candidates[0]
    default_name = _guess_name(first_data.get('serverUrl') or source) or dict(PROVIDER_TYPES).get(first_type, first_type)
    heading = 'Name des Anbieters' if len(candidates) == 1 else f'Name für alle {len(candidates)} Anbieter'
    name = ku.input_dialog(heading, default=default_name)
    if not name:
        return

    db = get_db()
    created_ids = []
    for ptype, data in candidates:
        pid = db.add_provider(name, ptype, **data)
        created_ids.append(pid)
        ku.log_debug(f'import_provider: Anbieter angelegt id={pid} type={ptype} name={name} data={data}')

    ku.notify(f'{len(created_ids)} Anbieter importiert' if len(created_ids) > 1 else 'Anbieter importiert')
    if ku.yesno_dialog('Synchronisieren', 'Jetzt synchronisieren?'):
        for pid in created_ids:
            do_sync(db, pid)
    db.close()
    xbmc.executebuiltin('Container.Refresh')


def add_provider_dialog(ptype, existing=None, prefill=None):
    if prefill is None:
        prefill = {}
    name = ku.input_dialog('Name des Anbieters', default=existing['name'] if existing else '')
    if not name:
        return
    data = {'name': name}
    if ptype in ('xtream', 'stalker', 'enigma2', 'jellyfin'):
        data['serverUrl'] = ku.input_dialog('Server-URL (http://host:port)',
                                             default=existing['serverUrl'] if existing else prefill.get('serverUrl', ''))
    if ptype in ('xtream', 'jellyfin'):
        data['username'] = ku.input_dialog('Benutzername', default=existing['username'] if existing else prefill.get('username', ''))
        data['password'] = ku.password_dialog('Passwort', default=existing['password'] if existing else prefill.get('password', ''))
    elif ptype == 'stalker':
        data['stalkerMacAddress'] = ku.input_dialog('MAC-Adresse (00:1A:79:...)',
                                                      default=existing['stalkerMacAddress'] if existing else '00:1A:79:')
        data['stalkerDeviceProfile'] = ku.input_dialog('Geraeteprofil', default='MAG250')
        data['stalkerDeviceTimezone'] = ku.input_dialog('Zeitzone', default='Europe/Berlin')
        data['stalkerDeviceLocale'] = ku.input_dialog('Sprache', default='de')
        compat_idx = ku.select_dialog(
            'Verbindungsmodus',
            ['Automatisch erkennen', 'Standard (MAG-Handshake)', 'Compat (kein Handshake, fuer SorglosTV u.a.)']
        )
        data['stalkerCompatMode'] = {0: -1, 1: 0, 2: 1}.get(compat_idx, -1)
    elif ptype == 'enigma2':
        data['username'] = ku.input_dialog('Benutzername (optional)', default=prefill.get('username', ''))
        data['password'] = ku.password_dialog('Passwort (optional)', default=prefill.get('password', ''))
    elif ptype == 'm3u':
        data['m3uUrl'] = ku.input_dialog('M3U Playlist URL / Pfad', default=existing['m3uUrl'] if existing else prefill.get('serverUrl', ''))
        data['epgUrl'] = ku.input_dialog('XMLTV EPG URL (optional)', default=existing['epgUrl'] if existing else '')
        data['altEpgUrls'] = ku.input_dialog('Alternative EPG-URLs (| getrennt, optional)', default=existing.get('altEpgUrls', '') if existing else '')
        offset_str = ku.input_dialog('EPG-Zeitversatz in Stunden (z.B. -1, 0, 2)', default=str(existing.get('epgOffset', 0)) if existing else '0')
        try:
            data['epgOffset'] = int(offset_str or 0)
        except ValueError:
            data['epgOffset'] = 0
        catchup_idx = ku.select_dialog('Catchup-Typ', ['Standard (auto)', 'shift', 'archive', 'xc_catchup'])
        data['catchupType'] = {0: '', 1: 'shift', 2: 'archive', 3: 'xc_catchup'}.get(catchup_idx, '')
        interval_str = ku.input_dialog('EPG-Sync-Intervall in Stunden (0 = manuell)', default=str(existing.get('epgSyncInterval', 0)) if existing else '0')
        try:
            data['epgSyncInterval'] = int(interval_str or 0)
        except ValueError:
            data['epgSyncInterval'] = 0

    ua_labels = [label for _, label in USER_AGENT_PRESETS]
    ua_idx = ku.select_dialog('User-Agent wählen', ua_labels)
    if ua_idx is not None and ua_idx >= 0:
        data['userAgent'] = USER_AGENT_PRESETS[ua_idx][0]
    else:
        data['userAgent'] = existing.get('userAgent', '') if existing else ''

    db = get_db()
    if existing:
        db.update_provider(existing['id'], **data)
        ku.log_debug(f"Anbieter aktualisiert: id={existing['id']} name={name}")
        ku.notify('Anbieter aktualisiert')
    else:
        add_kwargs = {k: v for k, v in data.items() if k != 'name'}
        pid = db.add_provider(name, ptype, **add_kwargs)
        ku.log_debug(f'Anbieter hinzugefügt: id={pid} name={name} type={ptype}')
        ku.notify('Anbieter hinzugefügt')
        if ku.yesno_dialog('Synchronisieren', 'Jetzt synchronisieren?'):
            do_sync(db, pid)
    db.close()
    xbmc.executebuiltin('Container.Refresh')


WIZARD_EXPLAIN = {
    'url_file': 'Kopiere jetzt den Link von deinem Anbieter (beginnt meist mit http) oder wähle die Datei aus, die du von ihm bekommen hast.',
    'xtream': 'Du brauchst: Server-Adresse (z.B. http://anbieter.tv:8080), Benutzername und Passwort. Diese Daten hast du von deinem Anbieter erhalten.',
    'stalker': 'Du brauchst: die Portal-Adresse und die MAC-Adresse deiner Box. Beides findest du meist auf der Box selbst oder in einer Nachricht deines Anbieters.',
    'enigma2': 'Du brauchst die Adresse deines Receivers im Heimnetzwerk, z.B. http://192.168.1.50.',
    'jellyfin': 'Du brauchst die Server-Adresse, Benutzername und Passwort deines Jellyfin-Servers.',
}


def _wizard_explain(key):
    text = WIZARD_EXPLAIN.get(key)
    if text:
        ku.ok_dialog('Start-Assistent', text)


def _wizard_tmdb_step():
    if ku.get_setting('tmdb_api_key', ''):
        return
    if not ku.yesno_dialog(
        'Start-Assistent',
        'Möchtest du schöne Poster-Bilder und Beschreibungen für Filme und Serien? Dafür brauchst du einen kostenlosen Code von der Webseite themoviedb.org.'
    ):
        return
    ku.ok_dialog(
        'Start-Assistent',
        '1. Gehe auf themoviedb.org und erstelle ein kostenloses Konto.\n'
        '2. Öffne die Kontoeinstellungen und wähle "API".\n'
        '3. Erstelle einen Schlüssel (API-Key) und kopiere ihn.'
    )
    key = ku.input_dialog('TMDB API-Key einfügen')
    if key:
        ku.set_setting('tmdb_api_key', key)
        ku.notify('TMDB-Schlüssel gespeichert')


def _wizard_finish():
    ku.set_setting('setup_wizard_done', 'true')
    ku.ok_dialog(
        'Fertig!',
        'Im Hauptmenü findest du jetzt:\n'
        '- Filme, Serien, Live TV: deine Inhalte\n'
        '- Weiter schauen: dort weitermachen, wo du aufgehört hast\n'
        '- Favoriten und Zuletzt geschaut\n'
        '- Anbieter verwalten: weitere Anbieter hinzufügen oder bearbeiten\n\n'
        'Viel Spaß!'
    )


def setup_wizard():
    if not ku.yesno_dialog(
        'Willkommen bei Multistream',
        'Möchtest du jetzt in wenigen Schritten deinen ersten Anbieter einrichten?'
    ):
        ku.set_setting('setup_wizard_done', 'true')
        ku.notify("Du findest den Assistenten jederzeit in den Einstellungen unter 'Allgemein'.")
        return

    options = [
        'Ich habe einen Link oder eine Datei',
        'Benutzername + Passwort + Server-Adresse (Xtream Codes)',
        'MAC-Adresse + Portal-Adresse (Stalker-Box / MAG)',
        'Enigma2-Receiver (Vu+, Dreambox, ...)',
        'Jellyfin-Server',
        'Ich weiß es nicht / habe noch keine Zugangsdaten',
    ]
    idx = ku.select_dialog('Was hast du von deinem Anbieter bekommen?', options)
    if idx < 0:
        ku.set_setting('setup_wizard_done', 'true')
        return

    db = get_db()
    count_before = len(db.get_providers())
    db.close()

    if idx == 0:
        _wizard_explain('url_file')
        import_provider()
    elif idx == 1:
        _wizard_explain('xtream')
        add_provider_dialog('xtream')
    elif idx == 2:
        _wizard_explain('stalker')
        add_provider_dialog('stalker')
    elif idx == 3:
        _wizard_explain('enigma2')
        add_provider_dialog('enigma2')
    elif idx == 4:
        _wizard_explain('jellyfin')
        add_provider_dialog('jellyfin')
    else:
        ku.ok_dialog(
            'Start-Assistent',
            'Frag deinen Anbieter nach einem Link (M3U) oder nach Benutzername und Passwort (Xtream Codes).\n\n'
            "Du kannst den Assistenten danach jederzeit in den Einstellungen unter 'Allgemein' erneut starten."
        )
        ku.set_setting('setup_wizard_done', 'true')
        return

    db = get_db()
    count_after = len(db.get_providers())
    db.close()

    if count_after <= count_before:
        ku.set_setting('setup_wizard_done', 'true')
        return

    _wizard_tmdb_step()
    _wizard_finish()


def maybe_autostart_wizard():
    if ku.get_setting_bool('setup_wizard_done', False):
        return
    db = get_db()
    has_providers = bool(db.get_providers())
    db.close()
    if has_providers:
        ku.set_setting('setup_wizard_done', 'true')
        return
    setup_wizard()


def do_sync(db, provider_id):
    provider = db.get_provider(provider_id)
    if not provider:
        ku.log(f'Sync abgebrochen: provider_id={provider_id} nicht gefunden', xbmc.LOGWARNING)
        return
    ptype = provider['type']
    if int(provider.get('useInternalEpg', -1)) == -1 and ptype in ('stalker', 'xtream', 'm3u'):
        use_internal = ku.yesno_dialog(
            'EPG-Quelle',
            f'Soll das integrierte EPG des Anbieters "{provider["name"]}" verwendet werden?\n'
            'Ja = Anbieter-EPG (empfohlen)\n'
            'Nein = nur manuell eingetragene XMLTV-URLs'
        )
        db.update_provider(provider_id, useInternalEpg=1 if use_internal else 0)
        provider = db.get_provider(provider_id)
    dialog = ku.progress_dialog()
    dialog.create(f"Multistream - {provider['name']}", 'Starte Synchronisierung...')
    ku.log_debug(f"Sync gestartet: {provider['name']} ({provider['type']}, id={provider_id})")
    start = time.time()

    def cb(percent, message):
        dialog.update(percent, f"{provider['name']}[CR]{message}")

    try:
        tmdb_client = get_tmdb()
        epg_db = get_epg_db()
        sync_provider(db, epg_db, provider, tmdb_client, cb)
        epg_db.close()
        duration = time.time() - start
        db.set_provider_synced(provider['id'])
        ku.log_debug(f"Sync erfolgreich: {provider['name']} in {duration:.1f}s")
        ku.notify(f"{provider['name']} synchronisiert")
    except Exception as e:
        db.set_provider_sync_error(provider['id'], str(e))
        ku.log(f"Sync error fuer {provider['name']} (id={provider_id}): {e}", xbmc.LOGERROR)
        ku.notify(f'Fehler: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
    finally:
        dialog.close()


def do_sync_epg_only(db, provider_id):
    provider = db.get_provider(provider_id)
    if not provider:
        ku.log(f'EPG-Sync abgebrochen: provider_id={provider_id} nicht gefunden', xbmc.LOGWARNING)
        return
    ptype = provider['type']
    if ptype not in ('stalker', 'xtream', 'm3u'):
        ku.notify(f'{provider["name"]}: EPG-Aktualisierung für Typ {ptype} nicht unterstützt')
        return
    if int(provider.get('useInternalEpg', -1)) == -1:
        use_internal = ku.yesno_dialog(
            'EPG-Quelle',
            f'Soll das integrierte EPG des Anbieters "{provider["name"]}" verwendet werden?\n'
            'Ja = Anbieter-EPG (empfohlen)\n'
            'Nein = nur manuell eingetragene XMLTV-URLs'
        )
        db.update_provider(provider_id, useInternalEpg=1 if use_internal else 0)
        provider = db.get_provider(provider_id)
    dialog = ku.progress_dialog()
    dialog.create(f"Multistream – EPG {provider['name']}", 'EPG wird aktualisiert...')

    def cb(percent, message):
        dialog.update(percent, f"{provider['name']}[CR]{message}")

    try:
        epg_db = get_epg_db()
        sync_epg_only(db, epg_db, dict(provider), progress_cb=cb)
        epg_db.close()
        ku.notify(f"EPG aktualisiert: {provider['name']}")
    except Exception as e:
        ku.log(f"EPG-Sync Fehler {provider['name']}: {e}", xbmc.LOGERROR)
        ku.notify(f'EPG Fehler: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
    finally:
        dialog.close()
    xbmc.executebuiltin('Container.Refresh')


def _is_fav_quick(db, provider_id, content_type, item_id):
    try:
        return db.is_favorite(provider_id, content_type, item_id)
    except Exception:
        return False


def _country_filter_categories(cats):
    filter_kw = ku.get_setting('country_filter_keywords', '') or ''
    if not filter_kw.strip():
        return cats
    kws = [k.strip().upper() for k in filter_kw.split(',') if k.strip()]
    if not kws:
        return cats
    mode_idx = ku.get_setting_int('country_filter_mode', 0)
    mode = 'show' if mode_idx == 0 else 'hide'
    result = []
    for c in cats:
        name_upper = c.get('categoryName', '').upper()
        has_kw = any(k in name_upper for k in kws)
        if mode == 'show' and not has_kw:
            continue
        if mode == 'hide' and has_kw:
            continue
        result.append(c)
    return result


def _quality_filter_channels(channels):
    filter_kw = ku.get_setting('quality_filter_keywords', '') or ''
    if not filter_kw.strip():
        return channels
    kws = [k.strip().upper() for k in filter_kw.split(',') if k.strip()]
    if not kws:
        return channels
    mode_idx = ku.get_setting_int('quality_filter_mode', 0)
    mode = 'show' if mode_idx == 1 else 'hide'
    result = []
    for ch in channels:
        name_upper = ch.get('name', '').upper()
        has_kw = any(k in name_upper for k in kws)
        if mode == 'hide' and has_kw:
            continue
        if mode == 'show' and not has_kw:
            continue
        result.append(ch)
    return result


def movie_categories():
    db = get_db()
    pids = enabled_provider_ids(db)
    providers = {p['id']: p for p in db.get_providers(only_enabled=True)}
    found = False
    for pid in pids:
        provider = providers.get(pid)
        if not provider:
            continue
        tag = _provider_tag(provider)
        if provider['type'] == 'jellyfin':
            cats = db.get_jellyfin_categories(pid, 'movie')
            cats = _country_filter_categories(cats)
            for c in cats:
                found = True
                label = c['categoryName']
                url = ku.build_url(action='movies', category=c['categoryName'], provider_id=pid)
                ku.add_dir_item(label, url, info={'title': label, 'plot': tag})
        else:
            cats = db.get_movie_categories([pid])
            cats = _country_filter_categories(cats)
            for c in cats:
                found = True
                label = f"{c['categoryName']} ({c['cnt']})"
                url = ku.build_url(action='movies', category=c['categoryName'], provider_id=c['providerId'])
                ku.add_dir_item(label, url, info={'title': label, 'plot': tag})
    if not found:
        ku.notify('Keine Filme gefunden - bitte zuerst synchronisieren')
    ku.end_directory()
    db.close()


def _provider_tag(provider):
    name = provider['name'] if provider else ''
    ptype = TYPE_NAMES.get(provider['type'], provider['type']) if provider else ''
    return f"{name} ({ptype})"


def movies(category, provider_id=None):
    db = get_db()
    pids = [int(provider_id)] if provider_id else enabled_provider_ids(db)
    providers = {p['id']: p for p in db.get_providers(only_enabled=True)}
    for pid in pids:
        provider = providers.get(pid)
        if provider and provider['type'] == 'jellyfin':
            existing = db.get_movies([pid], category)
            if not existing:
                dialog = ku.progress_dialog()
                dialog.create('Multistream', f'Lade Filme: {category}...')
                try:
                    fetch_jellyfin_movies_for_category(db, provider, category, progress_cb=lambda p, m: dialog.update(p, m))
                except Exception as e:
                    ku.notify(f'Fehler beim Laden: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
                finally:
                    dialog.close()
    hide_watched = ku.get_setting_bool('hide_watched', False)
    items = db.get_movies(pids, category, hide_watched=hide_watched)
    for m in items:
        provider = providers.get(m['providerId'])
        tag = _provider_tag(provider)
        plot = f"[{tag}]\n\n{m['overview']}" if m['overview'] else f"[{tag}]"
        info = {
            'title': m['name'], 'plot': plot, 'year': m['releaseDate'][:4] if m['releaseDate'] else None,
            'genre': m['genre'], 'director': m['director'], 'rating': m['rating'], 'mediatype': 'movie',
        }
        art = {
            'poster': m['posterUrl'],
            'fanart': m.get('backdropUrl') or m['posterUrl'],
            'thumb': m.get('thumbUrl') or m['posterUrl'],
            'banner': m.get('bannerUrl', ''),
            'clearlogo': m.get('clearlogoUrl', ''),
            'landscape': m.get('landscapeUrl', ''),
        }
        resume_ticks = m.get('resumePositionTicks', 0) or 0
        props = {'ResumeTime': str(resume_ticks // 10000000)} if resume_ticks > 0 else None
        label = m['name']
        if ku.get_setting_bool('add_resume_percent', False) and resume_ticks > 0:
            label += f" ({resume_ticks // 10000000}s)"
        url = ku.build_url(action='play', type='movie', provider_id=m['providerId'], id=m['id'])
        context = [
            ('Download', f"RunPlugin({ku.build_url(action='download', type='movie', provider_id=m['providerId'], id=m['id'])})"),
            ('Zu Favoriten' if not _is_fav_quick(db, m['providerId'], 'movie', m['id']) else 'Aus Favoriten', f"RunPlugin({ku.build_url(action='toggle_favorite', content_type='movie', provider_id=m['providerId'], item_id=m['id'])})"),
        ]
        ku.add_dir_item(label, url, is_folder=False, art=art, info=info, props=props, context_menu=context)
    ku.end_directory()
    db.close()


def series_categories():
    db = get_db()
    pids = enabled_provider_ids(db)
    providers = {p['id']: p for p in db.get_providers(only_enabled=True)}
    found = False
    for pid in pids:
        provider = providers.get(pid)
        if not provider:
            continue
        tag = _provider_tag(provider)
        if provider['type'] == 'jellyfin':
            cats = db.get_jellyfin_categories(pid, 'series')
            cats = _country_filter_categories(cats)
            for c in cats:
                found = True
                label = c['categoryName']
                url = ku.build_url(action='series_list', category=c['categoryName'], provider_id=pid)
                ku.add_dir_item(label, url, info={'title': label, 'plot': tag})
        else:
            cats = db.get_series_categories([pid])
            cats = _country_filter_categories(cats)
            for c in cats:
                found = True
                label = f"{c['categoryName']} ({c['cnt']})"
                url = ku.build_url(action='series_list', category=c['categoryName'], provider_id=c['providerId'])
                ku.add_dir_item(label, url, info={'title': label, 'plot': tag})
    if not found:
        ku.notify('Keine Serien gefunden - bitte zuerst synchronisieren')
    ku.end_directory()
    db.close()


def series_list(category, provider_id=None):
    db = get_db()
    pids = [int(provider_id)] if provider_id else enabled_provider_ids(db)
    providers = {p['id']: p for p in db.get_providers(only_enabled=True)}
    for pid in pids:
        provider = providers.get(pid)
        if provider and provider['type'] == 'jellyfin':
            existing = db.get_series_list([pid], category)
            if not existing:
                dialog = ku.progress_dialog()
                dialog.create('Multistream', f'Lade Serien: {category}...')
                try:
                    fetch_jellyfin_series_for_category(db, provider, category, progress_cb=lambda p, m: dialog.update(p, m))
                except Exception as e:
                    ku.notify(f'Fehler beim Laden: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
                finally:
                    dialog.close()
    hide_watched = ku.get_setting_bool('hide_watched', False)
    items = db.get_series_list(pids, category, hide_watched=hide_watched)
    for s in items:
        provider = providers.get(s['providerId'])
        tag = _provider_tag(provider)
        plot = f"[{tag}]\n\n{s['overview']}" if s['overview'] else f"[{tag}]"
        info = {
            'title': s['name'], 'plot': plot, 'year': s['releaseDate'][:4] if s['releaseDate'] else None,
            'genre': s['genre'], 'director': s['director'], 'rating': s['rating'], 'mediatype': 'tvshow',
        }
        art = {
            'poster': s['posterUrl'],
            'fanart': s.get('backdropUrl') or s['posterUrl'],
            'thumb': s.get('thumbUrl') or s['posterUrl'],
            'banner': s.get('bannerUrl', ''),
            'clearlogo': s.get('clearlogoUrl', ''),
            'landscape': s.get('landscapeUrl', ''),
            'tvshow.poster': s['posterUrl'],
            'tvshow.fanart': s.get('backdropUrl') or s['posterUrl'],
            'tvshow.banner': s.get('bannerUrl', ''),
            'tvshow.clearlogo': s.get('clearlogoUrl', ''),
            'tvshow.landscape': s.get('landscapeUrl', ''),
        }
        url = ku.build_url(action='seasons', provider_id=s['providerId'], series_id=s['id'])
        context = [
            ('Episoden neu laden', f"RunPlugin({ku.build_url(action='refresh_episodes', provider_id=s['providerId'], series_id=s['id'])})"),
            ('Zu Favoriten' if not _is_fav_quick(db, s['providerId'], 'series', s['id']) else 'Aus Favoriten', f"RunPlugin({ku.build_url(action='toggle_favorite', content_type='series', provider_id=s['providerId'], item_id=s['id'])})"),
        ]
        ku.add_dir_item(s['name'], url, art=art, info=info, context_menu=context)
    ku.end_directory()
    db.close()


def refresh_episodes(provider_id, series_id):
    db = get_db()
    db.clear_episodes(provider_id, series_id)
    db.close()
    ku.log_debug(f'Episoden-Cache geleert: provider_id={provider_id} series_id={series_id}')
    ku.notify('Episoden-Cache geleert - wird neu geladen')
    xbmc.executebuiltin('Container.Refresh')


def seasons(provider_id, series_id):
    db = get_db()
    provider = db.get_provider(provider_id)
    series_row = db.get_series_item(provider_id, series_id)
    existing = db.get_seasons(provider_id, series_id)
    if not existing:
        dialog = ku.progress_dialog()
        dialog.create('Multistream', 'Lade Episoden...')
        try:
            if provider['type'] == 'xtream':
                fetch_xtream_episodes(db, provider, series_id)
            elif provider['type'] == 'stalker':
                fetch_stalker_episodes(db, provider, series_id, series_row['streamId'])
            elif provider['type'] == 'jellyfin':
                fetch_jellyfin_episodes(db, provider, series_id, series_row['streamId'])
        except Exception as e:
            ku.notify(f'Fehler beim Laden: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
        finally:
            dialog.close()
        existing = db.get_seasons(provider_id, series_id)
    if len(existing) == 1 and ku.get_setting_bool('flatten_single_season', True):
        db.close()
        episodes(provider_id, series_id, existing[0]['seasonNumber'])
        return
    for s in existing:
        season_num = s['seasonNumber']
        url = ku.build_url(action='episodes', provider_id=provider_id, series_id=series_id, season=season_num)
        ku.add_dir_item(f'Staffel {season_num}', url)
    ku.end_directory()
    db.close()


def _format_episode_title(fmt, series_name, episode_title, season_num, episode_num):
    return (fmt
            .replace('{SeriesName}', series_name or '')
            .replace('{ItemName}', episode_title or '')
            .replace('{SeasonIndex}', str(season_num).zfill(2))
            .replace('{EpisodeIndex}', str(episode_num).zfill(2)))


def episodes(provider_id, series_id, season):
    db = get_db()
    items = db.get_episodes(provider_id, series_id, season)
    series_row = db.get_series_item(provider_id, series_id)
    series_name = series_row['name'] if series_row else ''
    name_format = ku.get_setting('episode_name_format', '') or '{SeriesName} - {ItemName}'
    show_all = ku.get_setting_bool('show_all_episodes', True)
    add_resume_percent = ku.get_setting_bool('add_resume_percent', False)
    for e in items:
        if not show_all and e.get('watched'):
            continue
        label = _format_episode_title(name_format, series_name, e['title'], e['seasonNumber'], e['episodeNumber'])
        if add_resume_percent:
            resume_ticks = e.get('resumePositionTicks', 0) or 0
            if resume_ticks > 0:
                label += f' ({resume_ticks // 10000000}s)'
        info = {
            'title': e['title'], 'plot': e['overview'], 'season': e['seasonNumber'],
            'episode': e['episodeNumber'], 'mediatype': 'episode',
        }
        art = {
            'thumb': e['posterUrl'],
            'poster': e['posterUrl'],
            'fanart': e.get('backdropUrl', ''),
            'tvshow.fanart': e.get('backdropUrl', ''),
        }
        url = ku.build_url(action='play', type='episode', provider_id=provider_id, id=e['id'])
        context = [('Download', f"RunPlugin({ku.build_url(action='download', type='episode', provider_id=provider_id, id=e['id'])})")]
        ku.add_dir_item(label, url, is_folder=False, art=art, info=info, context_menu=context)
    ku.end_directory()
    db.close()


def channel_categories():
    db = get_db()
    pids = enabled_provider_ids(db)
    providers = {p['id']: p for p in db.get_providers(only_enabled=True)}
    cats = db.get_channel_categories(pids)
    cats = _country_filter_categories(cats)
    for c in cats:
        provider = providers.get(c['providerId'])
        tag = _provider_tag(provider) if provider else ''
        label = f"{c['categoryName']} ({c['cnt']})"
        url = ku.build_url(action='channels', category=c['categoryName'], provider_id=c['providerId'])
        ku.add_dir_item(label, url, info={'title': label, 'plot': tag})
    if not cats:
        ku.notify('Keine Kanaele gefunden - bitte zuerst synchronisieren')
    ku.end_directory()
    db.close()


def channels(category, provider_id=None):
    db = get_db()
    epg_db = get_epg_db()
    pids = [int(provider_id)] if provider_id else enabled_provider_ids(db)
    providers = {p['id']: p for p in db.get_providers(only_enabled=True)}
    items = db.get_channels(pids, category)
    items = _quality_filter_channels(items)
    now = int(time.time())
    for c in items:
        provider = providers.get(c['providerId'])
        tag = _provider_tag(provider)
        epg_key = c['epgChannelId'] or c['streamId']
        epg, is_next = epg_db.get_current_or_next_epg(c['providerId'], epg_key, now) if epg_key else (None, False)
        upcoming_from = epg['startTime'] if (epg and is_next) else now
        upcoming = epg_db.get_upcoming_epg(c['providerId'], epg_key, upcoming_from, limit=3) if epg_key else []
        label = c['name']
        label2 = ''
        if epg:
            t_from = _fmt_hhmm(epg['startTime'])
            t_to = _fmt_hhmm(epg['endTime'])
            label2 = f'{t_from} - {t_to}:  {epg["title"]}' if t_from and t_to else epg['title']
            label = f"{c['name']} - {epg['title']}"
        plot = _build_channel_epg_plot(tag, epg, upcoming, is_next)
        art = {'thumb': c['logoUrl'], 'icon': c['logoUrl']}
        info = {'title': c['name'], 'plot': plot, 'tagline': label2, 'mediatype': 'video'}
        url = ku.build_url(action='play', type='channel', provider_id=c['providerId'], id=c['id'])
        context = []
        if c['epgChannelId']:
            context.append((
                'EPG-Programm',
                f"Container.Update({ku.build_url(action='channel_epg', provider_id=c['providerId'], id=c['id'])})"
            ))
        epg_title_param = epg['title'] if (epg and not is_next) else ''
        context.append((
            'Aufnahme starten',
            f"RunPlugin({ku.build_url(action='start_recording', provider_id=c['providerId'], channel_id=c['id'], epg_title=epg_title_param)})"
        ))
        context.append((
            'Timeraufnahme hinzufügen',
            f"RunPlugin({ku.build_url(action='add_timer', provider_id=c['providerId'], channel_id=c['id'])})"
        ))
        ku.add_dir_item(label, url, is_folder=False, art=art, info=info, context_menu=context)
    ku.end_directory()
    epg_db.close()
    db.close()


def channel_epg(provider_id, channel_id):
    db = get_db()
    epg_db = get_epg_db()
    channel = db.get_channel(channel_id)
    if not channel:
        ku.notify('Kanal nicht gefunden')
        ku.end_directory()
        epg_db.close()
        db.close()
        return
    now = int(time.time())
    epg_offset_ch = int(channel.get('epgOffset', 0) or 0)
    provider = db.get_provider(provider_id)
    epg_offset_prov = int(provider.get('epgOffset', 0) or 0) if provider else 0
    epg_offset = epg_offset_ch if epg_offset_ch != 0 else epg_offset_prov
    archive_days = channel['tvArchiveDuration'] or 0
    window_start = now - max(archive_days, 1) * 86400
    window_end = now + 2 * 86400
    epg_key = channel['epgChannelId'] or channel['streamId']
    events = epg_db.get_epg_for_channel(channel['providerId'], epg_key, window_start, window_end)
    can_catchup = bool(channel['tvArchive']) and archive_days > 0
    for e in events:
        display_start = e['startTime'] + epg_offset * 3600
        display_end = e['endTime'] + epg_offset * 3600
        start_dt = time.localtime(display_start)
        label = f"{time.strftime('%d.%m. %H:%M', start_dt)} - {e['title']}"
        if display_end < now:
            label = f"[Vergangen] {label}"
        info = {'title': e['title'], 'plot': e['description'], 'mediatype': 'video'}
        context = []
        is_past_within_archive = display_end < now and display_start >= window_start
        if can_catchup and is_past_within_archive:
            context.append((
                'Catchup abspielen',
                f"RunPlugin({ku.build_url(action='play_catchup', provider_id=channel['providerId'], channel_id=channel_id, start=e['startTime'], end=e['endTime'])})"
            ))
        existing_reminder = epg_db.find_epg_reminder(provider_id, channel['epgChannelId'], e['startTime'])
        if existing_reminder:
            context.append((
                'Erinnerung entfernen',
                f"RunPlugin({ku.build_url(action='remove_epg_reminder', reminder_id=existing_reminder['id'])})"
            ))
        elif display_start > now:
            context.append((
                'Erinnerung setzen',
                f"RunPlugin({ku.build_url(action='add_epg_reminder', provider_id=provider_id, channel_id=channel_id, epg_channel_id=channel['epgChannelId'], start=e['startTime'], end=e['endTime'], title=e['title'])})"
            ))
            context.append((
                'Aufnahme planen',
                f"RunPlugin({ku.build_url(action='schedule_recording', provider_id=provider_id, channel_id=channel_id, epg_channel_id=channel['epgChannelId'], start=e['startTime'], end=e['endTime'], title=e['title'])})"
            ))
        url = ku.build_url(action='noop')
        ku.add_dir_item(label, url, is_folder=False, info=info, context_menu=context)
    if not events:
        ku.notify('Keine EPG-Daten fuer diesen Kanal verfuegbar')
    ku.end_directory()
    epg_db.close()
    db.close()


def play_catchup(provider_id, channel_id, start_ts, end_ts):
    db = get_db()
    provider = db.get_provider(provider_id)
    channel = db.get_channel(channel_id)
    db.close()
    if not provider or not channel:
        ku.notify('Kanal/Anbieter nicht gefunden', icon=xbmcgui.NOTIFICATION_ERROR)
        return
    duration_minutes = max(1, (int(end_ts) - int(start_ts)) // 60)
    start_ts = int(start_ts)

    if provider['type'] == 'xtream':
        client = make_xtream(provider)
        start_dt = datetime.datetime.fromtimestamp(start_ts)
        url = client.catchup_url(channel['streamId'], start_dt, duration_minutes)
    elif provider['type'] == 'stalker':
        client = make_stalker(provider)
        url = client.create_link('itv', channel['streamUrl'], archive_utc=start_ts)
    else:
        ku.notify('Catchup wird fuer diesen Anbietertyp nicht unterstuetzt', icon=xbmcgui.NOTIFICATION_ERROR)
        return

    if not url:
        ku.notify('Catchup-Stream konnte nicht aufgeloest werden', icon=xbmcgui.NOTIFICATION_ERROR)
        return
    ku.log_debug(f'play_catchup: provider_id={provider_id} channel_id={channel_id} start={start_ts} -> {url}')
    li = xbmcgui.ListItem(channel['name'])
    li.setPath(url)
    xbmc.Player().play(url, li)


def noop():
    ku.end_directory()


def resolve_play_url(db, provider_id, content_type, raw_id):
    provider = db.get_provider(provider_id)
    if not provider:
        raise ValueError(f'Provider nicht gefunden: provider_id={provider_id}')
    if content_type == 'movie':
        row = db.get_movie(provider_id, raw_id)
        if not row:
            raise ValueError(f'Film nicht gefunden: provider_id={provider_id} id={raw_id}')
        raw_url = row['streamUrl']
        stream_id = row['streamId']
    elif content_type == 'episode':
        row = db.conn.execute(
            'SELECT * FROM episodes WHERE providerId = ? AND id = ?', (provider_id, raw_id)
        ).fetchone()
        if not row:
            raise ValueError(f'Episode nicht gefunden: provider_id={provider_id} id={raw_id}')
        raw_url = row['streamUrl']
        stream_id = row['streamId']
    else:
        row = db.get_channel(raw_id)
        if not row:
            raise ValueError(f'Kanal nicht gefunden: id={raw_id}')
        raw_url = row['streamUrl']
        stream_id = None

    if provider['type'] == 'jellyfin' and content_type in ('movie', 'episode') and stream_id:
        client = make_jellyfin(provider)
        url, play_session_id, media_source_id = client.resolve_playback_url(stream_id)
        ku.log_debug(f'resolve_play_url: jellyfin PlaybackInfo {content_type} stream_id={stream_id} -> {url}')
        _LAST_JELLYFIN_SESSION['provider_id'] = provider_id
        _LAST_JELLYFIN_SESSION['item_id'] = stream_id
        _LAST_JELLYFIN_SESSION['play_session_id'] = play_session_id
        return url

    if provider['type'] == 'stalker' and raw_url and not raw_url.startswith('http'):
        client = make_stalker(provider)
        link_type = 'itv' if content_type == 'channel' else 'vod'
        cmd = raw_url
        series_num = None
        if content_type == 'episode' and EPISODE_CMD_SEP in raw_url:
            cmd, _, series_num = raw_url.partition(EPISODE_CMD_SEP)
        resolved = client.create_link(link_type, cmd, series=series_num)
        ku.log_debug(f'resolve_play_url: stalker {content_type} cmd={cmd} series={series_num} -> {resolved}')
        return resolved
    return raw_url


def collect_play_candidates(db, provider_id, content_type, raw_id):
    if content_type == 'movie':
        original = db.get_movie(provider_id, raw_id)
        if not original:
            return []
        name = original['name']
        siblings = db.find_movies_by_name(name, enabled_provider_ids(db))
    elif content_type == 'episode':
        original = db.conn.execute(
            'SELECT * FROM episodes WHERE providerId = ? AND id = ?', (provider_id, raw_id)
        ).fetchone()
        if not original:
            return []
        name = original['title']
        siblings = db.find_episodes_by_title(name, enabled_provider_ids(db))
    else:
        original = db.get_channel(raw_id)
        if not original:
            return []
        name = original['name']
        siblings = db.find_channels_by_name(name, enabled_provider_ids(db))

    candidates = [(provider_id, raw_id, name)]
    seen = {(provider_id, str(raw_id))}
    for row in siblings:
        key = (row['providerId'], str(row['id']))
        if key in seen:
            continue
        seen.add(key)
        candidates.append((row['providerId'], row['id'], name))
    return candidates


def _get_resume_seconds(db, provider_id, content_type, raw_id):
    row_ticks = 0
    if content_type == 'movie':
        row = db.get_movie(provider_id, raw_id)
        if row:
            row_ticks = row.get('resumePositionTicks', 0) or 0
    elif content_type == 'episode':
        row = db.conn.execute(
            'SELECT * FROM episodes WHERE providerId = ? AND id = ?', (provider_id, raw_id)
        ).fetchone()
        if row:
            row_ticks = row.get('resumePositionTicks', 0) or 0
    cw = db.conn.execute(
        'SELECT resumePositionTicks FROM continue_watching WHERE providerId = ? AND contentType = ? AND itemId = ?',
        (provider_id, content_type, str(raw_id))
    ).fetchone()
    cw_ticks = cw['resumePositionTicks'] if cw else 0
    best_ticks = max(row_ticks, cw_ticks)
    return max(0, best_ticks // 10000000)


class NextEpisodeMonitor(xbmc.Player):
    def __init__(self, provider_id, series_id, season_number, episode_number, percentage,
                 jellyfin_item_id=None, jellyfin_play_session_id=None,
                 content_type=None, raw_id=None):
        super().__init__()
        self.provider_id = provider_id
        self.series_id = series_id
        self.season_number = season_number
        self.episode_number = episode_number
        self.percentage = percentage
        self.prompted = False
        self.active = True
        self.jellyfin_item_id = jellyfin_item_id
        self.jellyfin_play_session_id = jellyfin_play_session_id
        self._content_type = content_type
        self._raw_id = raw_id
        self._last_position = 0
        self._total = 0

    def onPlayBackStopped(self):
        self._save_position()
        self.active = False

    def onPlayBackEnded(self):
        self._save_position()
        self.active = False

    def onPlayBackError(self):
        self.active = False

    def _save_position(self):
        current = self._last_position
        total = self._total
        if not self._content_type or not self._raw_id:
            return
        if current < 10:
            return
        try:
            db = get_db()
            provider = db.get_provider(self.provider_id)
            if self.jellyfin_item_id and provider:
                try:
                    client = make_jellyfin(provider)
                    client.report_playback_stopped(
                        self.jellyfin_item_id, self.jellyfin_play_session_id,
                        position_ticks=int(current * 10000000)
                    )
                except Exception as e:
                    ku.log(f'Jellyfin report_stopped fehlgeschlagen: {e}', xbmc.LOGWARNING)
            ticks = int(current * 10000000)
            watched_threshold = total * 0.9 if total > 0 else float('inf')
            if current >= watched_threshold:
                db.add_watch_history(self.provider_id, self._content_type, str(self._raw_id))
                db.remove_continue_watching(self.provider_id, self._content_type, str(self._raw_id))
                ku.log_debug(f'watch_history: {self._content_type} id={self._raw_id} als gesehen markiert')
            else:
                db.update_continue_watching(self.provider_id, self._content_type, str(self._raw_id), ticks)
                ku.log_debug(f'continue_watching: {self._content_type} id={self._raw_id} position={current:.0f}s')
            db.close()
        except Exception as e:
            ku.log(f'_save_position Fehler: {e}', xbmc.LOGERROR)

    def run(self):
        monitor = xbmc.Monitor()

        for _ in range(60):
            if monitor.waitForAbort(1):
                return
            try:
                if self.isPlayingVideo():
                    break
            except Exception:
                pass
        else:
            ku.log_debug(f'playmon: Timeout beim Warten auf Playback-Start (provider={self.provider_id} id={self._raw_id})')
            return

        ku.log_debug(f'playmon: Playback erkannt, starte Tracking ({self._content_type} id={self._raw_id})')

        while not monitor.abortRequested():
            if monitor.waitForAbort(5):
                self._save_position()
                break
            try:
                playing = self.isPlayingVideo()
            except Exception:
                playing = False

            if not playing:
                self._save_position()
                ku.log_debug(f'playmon: Playback beendet, Position gespeichert')
                break

            try:
                self._total = self.getTotalTime()
                self._last_position = self.getTime()
            except Exception:
                continue

            if self._total <= 0:
                continue

            if self.percentage and not self.prompted:
                pct = (self._last_position / self._total) * 100
                if pct >= self.percentage:
                    self.prompted = True
                    self._prompt_next()

    def _prompt_next(self):
        db = get_db()
        next_ep = db.get_next_episode(self.provider_id, self.series_id, self.season_number, self.episode_number)
        db.close()
        if not next_ep:
            return
        silent_autoplay = ku.get_setting_bool('autoplay_next_episode', False)
        if silent_autoplay:
            self.stop()
            xbmc.executebuiltin(
                f"RunPlugin({ku.build_url(action='play', type='episode', provider_id=self.provider_id, id=next_ep['id'])})"
            )
        elif ku.yesno_dialog('Naechste Episode', f"Naechste Episode \"{next_ep['title']}\" abspielen?", autoclose_ms=15000):
            self.stop()
            xbmc.executebuiltin(
                f"RunPlugin({ku.build_url(action='play', type='episode', provider_id=self.provider_id, id=next_ep['id'])})"
            )


def _maybe_start_playback_monitor(content_type, provider_id, raw_id):
    jellyfin_item_id = None
    jellyfin_play_session_id = None
    if (_LAST_JELLYFIN_SESSION.get('provider_id') == provider_id
            and _LAST_JELLYFIN_SESSION.get('item_id')):
        jellyfin_item_id = _LAST_JELLYFIN_SESSION['item_id']
        jellyfin_play_session_id = _LAST_JELLYFIN_SESSION['play_session_id']

    percentage = 0
    series_id = season_number = episode_number = None
    if content_type == 'episode':
        percentage = ku.get_setting_int('prompt_play_next_percentage', 0)
        if 0 < percentage < 100:
            db = get_db()
            episode = db.get_episode(provider_id, raw_id)
            db.close()
            if episode:
                series_id = episode['seriesId']
                season_number = episode['seasonNumber']
                episode_number = episode['episodeNumber']
        else:
            percentage = 0

    monitor = NextEpisodeMonitor(
        provider_id, series_id, season_number, episode_number, percentage,
        jellyfin_item_id=jellyfin_item_id, jellyfin_play_session_id=jellyfin_play_session_id,
        content_type=content_type, raw_id=raw_id,
    )

    import threading
    t = threading.Thread(target=monitor.run, daemon=True, name=f'playmon_{provider_id}_{raw_id}')
    t.start()


def _apply_subtitle_language():
    lang = ku.get_setting('default_subtitle_lang', '') or ''
    if not lang:
        return
    try:
        player = xbmc.Player()
        monitor = xbmc.Monitor()
        for _ in range(20):
            if monitor.waitForAbort(0.5):
                break
            if player.isPlayingVideo():
                subs = player.getAvailableSubtitleStreams()
                for i, s in enumerate(subs):
                    if lang.lower() in s.lower():
                        player.setSubtitleStream(i)
                        player.showSubtitles(True)
                        break
                break
    except Exception:
        pass


def play(provider_id, content_type, raw_id):
    db = get_db()
    ku.log_debug(f'play: provider_id={provider_id} type={content_type} id={raw_id}')

    resume_seconds = 0
    if content_type in ('movie', 'episode') and ku.get_setting_bool('force_auto_resume', True):
        resume_seconds = _get_resume_seconds(db, provider_id, content_type, raw_id)
        if resume_seconds > 0:
            jump_back = ku.get_setting_int('jump_back_amount', 15)
            resume_seconds = max(0, resume_seconds - jump_back)
            ku.log_debug(f'play: auto-resume bei {resume_seconds}s (jump_back={jump_back}s)')

    candidates = collect_play_candidates(db, provider_id, content_type, raw_id)
    if not candidates:
        candidates = [(provider_id, raw_id, str(raw_id))]
    if len(candidates) > 1:
        ku.log_debug(f'play: {len(candidates)} Quellen mit gleichem Namen gefunden, löse alle auf')

    resolved = []
    for cand_provider_id, cand_raw_id, label in candidates:
        try:
            url = resolve_play_url(db, cand_provider_id, content_type, cand_raw_id)
        except Exception as e:
            ku.log(f'play: Auflösung fehlgeschlagen ({label}, provider_id={cand_provider_id}): {e}', xbmc.LOGWARNING)
            continue
        if not url:
            ku.log(f'play: leere URL ({label}, provider_id={cand_provider_id})', xbmc.LOGWARNING)
            continue
        resolved.append((url, label))
    if resolved and content_type in ('movie', 'episode', 'channel'):
        db.add_watch_history(provider_id, content_type, str(raw_id))
    if resolved and content_type == 'channel':
        _save_current_channel_state(provider_id, raw_id)
    db.close()

    if not resolved:
        ku.log(f'play: kein abspielbarer Stream für provider_id={provider_id} id={raw_id}', xbmc.LOGERROR)
        ku.notify('Kein funktionierender Stream gefunden', icon=xbmcgui.NOTIFICATION_ERROR)
        ku.resolve_url('', succeeded=False)
        return

    if len(resolved) == 1:
        ku.log_debug(f'play: resolved url={resolved[0][0]}')
        if resume_seconds > 0:
            ku.resolve_url(resolved[0][0])
            player = xbmc.Player()
            for _ in range(20):
                if player.isPlaying():
                    break
                xbmc.sleep(500)
            if player.isPlaying():
                player.seekTime(resume_seconds)
        else:
            ku.resolve_url(resolved[0][0])
        _apply_subtitle_language()
        _maybe_start_playback_monitor(content_type, provider_id, raw_id)
        return

    ku.log_debug(f'play: {len(resolved)} Quellen aufgelöst, starte mit automatischem Fallback bei Fehler')
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    for url, label in resolved:
        li = xbmcgui.ListItem(label)
        li.setPath(url)
        li.setContentLookup(False)
        playlist.add(url, li)
    ku.resolve_url('', succeeded=False)
    xbmc.Player().play(playlist)


def favorites_menu():
    art = {'thumb': ku.ADDON_ICON, 'icon': ku.ADDON_ICON, 'fanart': ku.ADDON_FANART}
    ku.add_dir_item('Film-Favoriten', ku.build_url(action='favorites', content_type='movie'), art=art)
    ku.add_dir_item('Serien-Favoriten', ku.build_url(action='favorites', content_type='series'), art=art)
    ku.end_directory()


def favorites(content_type):
    db = get_db()
    pids = enabled_provider_ids(db)
    providers = {p['id']: p for p in db.get_providers(only_enabled=True)}
    favs = db.get_favorites(content_type, pids)
    if not favs:
        db.close()
        ku.notify('Keine Favoriten vorhanden')
        ku.end_directory()
        return
    for fav in favs:
        pid = fav['providerId']
        item_id = fav['itemId']
        provider = providers.get(pid)
        tag = _provider_tag(provider) if provider else ''
        if content_type == 'movie':
            row = db.get_movie(pid, int(item_id))
            if not row:
                continue
            info = {'title': row['name'], 'plot': f"[{tag}]\n\n{row['overview']}", 'mediatype': 'movie'}
            art = {'poster': row['posterUrl'], 'fanart': row.get('backdropUrl') or row['posterUrl']}
            url = ku.build_url(action='play', type='movie', provider_id=pid, id=item_id)
            context = [('Aus Favoriten entfernen', f"RunPlugin({ku.build_url(action='toggle_favorite', content_type='movie', provider_id=pid, item_id=item_id)})")]
            ku.add_dir_item(row['name'], url, is_folder=False, art=art, info=info, context_menu=context)
        elif content_type == 'series':
            row = db.conn.execute('SELECT * FROM series WHERE providerId = ? AND id = ?', (pid, int(item_id))).fetchone()
            if not row:
                continue
            info = {'title': row['name'], 'plot': f"[{tag}]\n\n{row.get('overview', '')}", 'mediatype': 'tvshow'}
            art = {'poster': row['posterUrl'], 'fanart': row.get('backdropUrl') or row['posterUrl']}
            url = ku.build_url(action='seasons', provider_id=pid, series_id=item_id)
            context = [('Aus Favoriten entfernen', f"RunPlugin({ku.build_url(action='toggle_favorite', content_type='series', provider_id=pid, item_id=item_id)})")]
            ku.add_dir_item(row['name'], url, art=art, info=info, context_menu=context)
    db.close()
    ku.end_directory()


def toggle_favorite(content_type, provider_id, item_id):
    db = get_db()
    if db.is_favorite(provider_id, content_type, item_id):
        db.remove_favorite(provider_id, content_type, item_id)
        ku.notify('Aus Favoriten entfernt')
    else:
        db.add_favorite(provider_id, content_type, item_id)
        ku.notify('Zu Favoriten hinzugefügt')
    db.close()
    xbmc.executebuiltin('Container.Refresh')


def watch_history():
    db = get_db()
    pids = enabled_provider_ids(db)
    providers = {p['id']: p for p in db.get_providers(only_enabled=True)}
    history = db.get_watch_history(provider_ids=pids, limit=100)
    if not history:
        db.close()
        ku.notify('Noch keine Wiedergabe-Historie')
        ku.end_directory()
        return
    for entry in history:
        pid = entry['providerId']
        provider = providers.get(pid)
        tag = _provider_tag(provider) if provider else ''
        ctype = entry['contentType']
        item_id = entry['itemId']
        label = f"[{ctype}] {item_id}"
        url = ku.build_url(action='noop')
        art = {}
        if ctype == 'movie':
            row = db.get_movie(pid, int(item_id))
            if row:
                label = f"{row['name']} [{tag}]"
                url = ku.build_url(action='play', type='movie', provider_id=pid, id=item_id)
        elif ctype == 'episode':
            row = db.conn.execute('SELECT * FROM episodes WHERE providerId = ? AND id = ?', (pid, item_id)).fetchone()
            if row:
                label = f"{row['title']} [{tag}]"
                url = ku.build_url(action='play', type='episode', provider_id=pid, id=item_id)
        elif ctype == 'channel':
            row = db.get_channel(int(item_id))
            if row:
                label = f"{row['name']} [{tag}]"
                art = {'thumb': row['logoUrl'], 'icon': row['logoUrl']}
                url = ku.build_url(action='play', type='channel', provider_id=pid, id=item_id)
        ku.add_dir_item(label, url, is_folder=False, art=art)
    db.close()
    ku.end_directory()


def continue_watching():
    db = get_db()
    pids = enabled_provider_ids(db)
    providers = {p['id']: p for p in db.get_providers(only_enabled=True)}
    items = db.get_continue_watching(pids, limit=5)
    if not items:
        db.close()
        ku.notify('Nichts zum Weiter-Schauen')
        ku.end_directory()
        return
    added = 0
    for entry in items:
        pid = entry['providerId']
        provider = providers.get(pid)
        tag = _provider_tag(provider) if provider else ''
        ctype = entry['contentType']
        item_id = entry['itemId']
        resume_secs = (entry['resumePositionTicks'] or 0) // 10000000
        label = None
        art = {}
        info = {}
        url = ku.build_url(action='noop')
        if ctype == 'movie':
            row = db.get_movie(pid, int(item_id))
            if row:
                label = f"{row['name']} [{tag}] ({resume_secs}s)"
                art = {'poster': row['posterUrl'], 'fanart': row.get('backdropUrl') or row['posterUrl']}
                info = {'title': row['name'], 'mediatype': 'movie'}
                url = ku.build_url(action='play', type='movie', provider_id=pid, id=item_id)
        elif ctype == 'episode':
            row = db.conn.execute('SELECT * FROM episodes WHERE providerId = ? AND id = ?', (pid, item_id)).fetchone()
            if row:
                label = f"{row['title']} [{tag}] ({resume_secs}s)"
                art = {'thumb': row['posterUrl']}
                info = {'title': row['title'], 'mediatype': 'episode'}
                url = ku.build_url(action='play', type='episode', provider_id=pid, id=item_id)
        if label is None:
            db.remove_continue_watching(pid, ctype, item_id)
            continue
        context = [('Aus Liste entfernen', f"RunPlugin({ku.build_url(action='remove_continue_watching', provider_id=pid, content_type=ctype, item_id=item_id)})")]
        ku.add_dir_item(label, url, is_folder=False, art=art, info=info, context_menu=context)
        added += 1
    db.close()
    if added == 0:
        ku.notify('Nichts zum Weiter-Schauen')
    ku.end_directory()


def remove_continue_watching(provider_id, content_type, item_id):
    db = get_db()
    db.remove_continue_watching(provider_id, content_type, item_id)
    db.close()
    xbmc.executebuiltin('Container.Refresh')


def epg_reminders():
    epg_db = get_epg_db()
    reminders = epg_db.get_epg_reminders()
    now = int(time.time())
    if not reminders:
        epg_db.close()
        ku.notify('Keine EPG-Erinnerungen gesetzt')
        ku.end_directory()
        return
    for r in reminders:
        start_dt = time.localtime(r['startTime'])
        label = f"{time.strftime('%d.%m. %H:%M', start_dt)} - {r['eventTitle']}"
        if r['startTime'] < now:
            label = f"[Vergangen] {label}"
        context = [('Erinnerung löschen', f"RunPlugin({ku.build_url(action='remove_epg_reminder', reminder_id=r['id'])})")]
        ku.add_dir_item(label, ku.build_url(action='noop'), is_folder=False, context_menu=context)
    epg_db.close()
    ku.end_directory()


def add_epg_reminder(provider_id, channel_id, epg_channel_id, start_ts, end_ts, title):
    epg_db = get_epg_db()
    existing = epg_db.find_epg_reminder(provider_id, epg_channel_id, int(start_ts))
    if existing:
        ku.notify('Erinnerung bereits gesetzt')
        epg_db.close()
        return
    minutes_before = 5
    alarm_time = int(start_ts) - minutes_before * 60
    now = int(time.time())
    if alarm_time <= now:
        ku.notify('Sendung startet zu bald oder bereits vorbei')
        epg_db.close()
        return
    alarm_id = f"epg_{provider_id}_{channel_id}_{start_ts}"
    epg_db.add_epg_reminder(provider_id, epg_channel_id, title, int(start_ts), int(end_ts), alarm_id)
    epg_db.close()
    ku.notify(f'Erinnerung gesetzt: {title} um {time.strftime("%H:%M", time.localtime(int(start_ts)))}')


def remove_epg_reminder(reminder_id):
    epg_db = get_epg_db()
    epg_db.remove_epg_reminder(int(reminder_id))
    epg_db.close()
    ku.notify('Erinnerung entfernt')
    xbmc.executebuiltin('Container.Refresh')


def fuzzy_epg_match(provider_id):
    db = get_db()
    epg_db = get_epg_db()
    provider = db.get_provider(provider_id)
    if not provider:
        ku.notify('Anbieter nicht gefunden')
        epg_db.close()
        db.close()
        return
    ku.log_debug(f'Fuzzy EPG Matching für provider_id={provider_id}')
    channels = db.get_channels([provider_id])
    matched, updates = epg_db.fuzzy_match_epg_channels(provider_id, channels)
    for epg_channel_id, channel_db_id in updates:
        db.conn.execute('UPDATE channels SET epgChannelId = ? WHERE id = ?', (epg_channel_id, channel_db_id))
    if updates:
        db.conn.commit()
    epg_db.close()
    db.close()
    ku.notify(f'EPG-Zuordnung: {matched} Kanäle automatisch zugeordnet')
    xbmc.executebuiltin('Container.Refresh')



_SEARCH_HISTORY_FILE = None

def _search_history_path():
    global _SEARCH_HISTORY_FILE
    if _SEARCH_HISTORY_FILE is None:
        _SEARCH_HISTORY_FILE = os.path.join(ku.PROFILE_DIR, 'search_history.json')
    return _SEARCH_HISTORY_FILE

def _load_search_history():
    return ku.load_json(_search_history_path(), [])

def _save_search_history(history):
    ku.save_json(_search_history_path(), history)

def _add_to_search_history(query):
    history = _load_search_history()
    if query in history:
        history.remove(query)
    history.insert(0, query)
    _save_search_history(history[:20])

def search_menu():
    art = {"thumb": ku.ADDON_ICON, "icon": ku.ADDON_ICON, "fanart": ku.ADDON_FANART}
    history = _load_search_history()
    ku.add_dir_item("[B]Suche starten...[/B]", ku.build_url(action="search_input"), art=art)
    if history:
        ku.add_dir_item("[Verlauf löschen]", ku.build_url(action="search_clear_history"), is_folder=False, is_action=True, art=art)
        for q in history:
            ku.add_dir_item(q, ku.build_url(action="search_run", query=q), art=art)
    ku.end_directory(cacheToTime=False)

def search_input():
    query = ku.input_dialog("Suche")
    if not query or not query.strip():
        return
    query = query.strip()
    _add_to_search_history(query)
    xbmc.executebuiltin(f"Container.Update({ku.build_url(action="search_run", query=query)})")

def search_clear_history():
    _save_search_history([])
    ku.notify("Suchverlauf gelöscht")
    xbmc.executebuiltin("Container.Refresh")

def search_run(query):
    db = get_db()
    epg_db = get_epg_db()
    pids = enabled_provider_ids(db)
    providers = {p["id"]: p for p in db.get_providers(only_enabled=True)}
    channels, movies, series = db.search_all(pids, query)

    art = {"thumb": ku.ADDON_ICON, "icon": ku.ADDON_ICON, "fanart": ku.ADDON_FANART}
    total = len(channels) + len(movies) + len(series)
    if total == 0:
        epg_db.close()
        db.close()
        ku.notify(f"Keine Ergebnisse für: {query}")
        ku.end_directory(cacheToTime=False)
        return

    now = int(time.time())

    if channels:
        for c in channels:
            provider = providers.get(c["providerId"])
            tag = _provider_tag(provider)
            epg_key = c["epgChannelId"] or c["streamId"]
            epg, is_next = epg_db.get_current_or_next_epg(c["providerId"], epg_key, now) if epg_key else (None, False)
            upcoming_from = epg["startTime"] if (epg and is_next) else now
            upcoming = epg_db.get_upcoming_epg(c["providerId"], epg_key, upcoming_from, limit=3) if epg_key else []
            label = c["name"]
            label2 = ""
            if epg:
                t_from = _fmt_hhmm(epg["startTime"])
                t_to = _fmt_hhmm(epg["endTime"])
                label2 = "{} - {}:  {}".format(t_from, t_to, epg["title"]) if t_from and t_to else epg["title"]
                label = "{} - {}".format(c["name"], epg["title"])
            plot = _build_channel_epg_plot(tag, epg, upcoming, is_next)
            ch_art = {"thumb": c["logoUrl"], "icon": c["logoUrl"]}
            info = {"title": c["name"], "plot": plot, "tagline": label2, "mediatype": "video"}
            url = ku.build_url(action="play", type="channel", provider_id=c["providerId"], id=c["id"])
            ku.add_dir_item(f"[📺] {label}", url, is_folder=False, art=ch_art, info=info)

    if movies:
        for m in movies:
            tag = _provider_tag(providers.get(m["providerId"]))
            plot = "[{}]\n\n{}".format(tag, m["overview"]) if m["overview"] else "[{}]".format(tag)
            m_art = {"thumb": m["posterUrl"], "icon": m["posterUrl"]}
            year = int(m["releaseDate"][:4]) if m.get("releaseDate") and len(m["releaseDate"]) >= 4 else None
            info = {"title": m["name"], "plot": plot, "year": year, "mediatype": "movie"}
            url = ku.build_url(action="play", type="movie", provider_id=m["providerId"], id=m["id"])
            ku.add_dir_item("[🎬] " + m["name"], url, is_folder=False, art=m_art, info=info)

    if series:
        for s in series:
            tag = _provider_tag(providers.get(s["providerId"]))
            plot = "[{}]\n\n{}".format(tag, s["overview"]) if s["overview"] else "[{}]".format(tag)
            s_art = {"thumb": s["posterUrl"], "icon": s["posterUrl"]}
            year = int(s["releaseDate"][:4]) if s.get("releaseDate") and len(s["releaseDate"]) >= 4 else None
            info = {"title": s["name"], "plot": plot, "year": year, "mediatype": "tvshow"}
            url = ku.build_url(action="series_seasons", provider_id=s["providerId"], series_id=s["id"])
            ku.add_dir_item("[📺] " + s["name"], url, art=s_art, info=info)

    epg_db.close()
    db.close()
    ku.end_directory(cacheToTime=False)

def prune_epg():
    epg_db = get_epg_db()
    now = int(time.time())
    cutoff = now - 7 * 86400
    epg_db.prune_old_epg_events(cutoff)
    epg_db.close()
    ku.notify('Alte EPG-Einträge gelöscht (älter als 7 Tage)')


def recordings():
    db = get_db()
    art = {'thumb': ku.ADDON_ICON, 'icon': ku.ADDON_ICON, 'fanart': ku.ADDON_FANART}
    active = _recorder.get_active_recordings()
    all_recs = db.get_recordings(status=('recording', 'done', 'error', 'cancelled'))
    db.close()
    if not all_recs and not active:
        ku.notify('Keine Aufnahmen vorhanden')
        ku.end_directory(cacheToTime=False)
        return
    for rec in all_recs:
        status = rec['status']
        status_labels = {
            'scheduled': '[Geplant]',
            'recording': '[Läuft]',
            'done': '[Fertig]',
            'error': '[Fehler]',
            'cancelled': '[Abgebrochen]',
        }
        status_label = status_labels.get(status, f'[{status}]')
        start_str = time.strftime('%d.%m. %H:%M', time.localtime(rec['startTime']))
        label = f"{status_label} {start_str} - {rec['channelName']}"
        if rec['title']:
            label += f" - {rec['title']}"
        plot_lines = [
            f"Status: {status_label}",
            f"Kanal: {rec['channelName']}",
        ]
        if rec['title']:
            plot_lines.append(f"Titel: {rec['title']}")
        plot_lines += [
            f"Start: {time.strftime('%d.%m.%Y %H:%M', time.localtime(rec['startTime']))}",
            f"Ende: {time.strftime('%H:%M', time.localtime(rec['endTime']))}",
            f"Dauer: {rec['durationSecs'] // 60} min",
            f"Datei: {rec['destPath']}",
        ]
        if rec['errorMsg']:
            plot_lines.append(f"Fehler: {rec['errorMsg']}")
        info = {'title': label, 'plot': '\n'.join(plot_lines)}
        context = []
        if status == 'recording':
            context.append(('Aufnahme stoppen', f"RunPlugin({ku.build_url(action='stop_recording', rec_id=rec['id'])})"))
        if status in ('done', 'error', 'cancelled'):
            context.append(('Eintrag löschen', f"RunPlugin({ku.build_url(action='delete_recording', rec_id=rec['id'])})"))
        if status == 'done' and rec['destPath'] and os.path.exists(rec['destPath']):
            play_url = ku.build_url(action='play_recording', rec_id=rec['id'])
            ku.add_dir_item(label, play_url, is_folder=False, info=info, art=art, context_menu=context)
        else:
            ku.add_dir_item(label, ku.build_url(action='noop'), is_folder=False, info=info, art=art, context_menu=context)
    ku.end_directory(cacheToTime=False)


def _save_current_channel_state(provider_id, channel_id):
    try:
        db = get_db()
        channel = db.get_channel(int(channel_id))
        db.close()
        if not channel:
            return
        now_ts = int(time.time())
        epg_title = ''
        try:
            epg_db = get_epg_db()
            epg_key = channel.get('epgChannelId') or ''
            if not epg_key:
                mapped = epg_db.get_epg_channel_id_for_channel(int(provider_id), int(channel_id))
                if mapped:
                    epg_key = mapped
            epg_row = epg_db.get_current_epg(int(provider_id), epg_key, now_ts) if epg_key else None
            epg_db.close()
            if epg_row:
                epg_title = f"{channel['name']} - {epg_row['title']}"
        except Exception:
            pass
        ku.save_json(ku.current_channel_state_path(), {
            'provider_id': int(provider_id),
            'channel_id': int(channel_id),
            'epg_title': epg_title,
        })
    except Exception as e:
        ku.log(f'_save_current_channel_state: {e}', xbmc.LOGWARNING)


def record_current_channel():
    _touch_overlay.close_overlay()
    xbmc.sleep(200)
    state = ku.load_json(ku.current_channel_state_path(), {})
    if not state or not state.get('channel_id'):
        ku.notify('Kein aktiver Live-Kanal gefunden', icon=xbmcgui.NOTIFICATION_WARNING)
        return
    start_recording_from_channel(
        state['provider_id'],
        state['channel_id'],
        epg_title_hint=state.get('epg_title', ''),
    )


def start_recording_from_channel(provider_id, channel_id, epg_title_hint=''):
    db = get_db()
    channel = db.get_channel(int(channel_id))
    provider = db.get_provider(int(provider_id))
    if not channel:
        ku.notify('Kanal nicht gefunden', icon=xbmcgui.NOTIFICATION_ERROR)
        db.close()
        return
    stream_url = channel['streamUrl']
    if provider and provider['type'] == 'stalker' and stream_url and not stream_url.startswith('http'):
        try:
            client = make_stalker(provider)
            stream_url = client.create_link('itv', stream_url)
        except Exception as e:
            ku.log(f'start_recording: Stalker URL-Auflösung fehlgeschlagen: {e}', xbmc.LOGERROR)
            ku.notify('Stream-URL konnte nicht aufgelöst werden', icon=xbmcgui.NOTIFICATION_ERROR)
            db.close()
            return
    if not stream_url or not stream_url.startswith('http'):
        ku.notify('Keine gültige Stream-URL für diesen Kanal', icon=xbmcgui.NOTIFICATION_ERROR)
        db.close()
        return
    now_ts = int(time.time())
    epg_title = epg_title_hint or ''
    epg_description = ''
    try:
        epg_db = get_epg_db()
        epg_key = channel.get('epgChannelId') or ''
        if not epg_key:
            mapped = epg_db.get_epg_channel_id_for_channel(int(provider_id), int(channel_id))
            if mapped:
                epg_key = mapped
        epg_row = epg_db.get_current_epg(int(provider_id), epg_key, now_ts) if epg_key else None
        epg_db.close()
        if epg_row:
            if not epg_title:
                epg_title = epg_row['title']
            epg_description = epg_row.get('description', '')
        else:
            ku.log(f'start_recording: kein EPG gefunden fuer provider={provider_id} epg_key={epg_key!r}', xbmc.LOGWARNING)
    except Exception as e:
        ku.log(f'start_recording: EPG-Abfrage fehlgeschlagen: {e}', xbmc.LOGWARNING)
    if not epg_title:
        manual_title = ku.input_dialog(f'Aufnahmetitel für "{channel["name"]}" (leer = nur Sendername)', default='')
        if manual_title is None:
            db.close()
            return
        epg_title = manual_title.strip()
    dialog_label = f'Aufnahmedauer in Minuten'
    if epg_title:
        dialog_label = f'Aufnahme: "{epg_title}" – Dauer in Minuten'
    dur_str = ku.input_dialog(dialog_label, default='60')
    if dur_str is None or dur_str == '':
        db.close()
        return
    try:
        dur_min = max(1, int(dur_str))
    except ValueError:
        dur_min = 60
    dest_dir = ku.get_setting('recording_dest_dir', '') or ''
    if not dest_dir:
        dest_dir = ku.browse_folder_dialog('Aufnahmeordner wählen')
        if not dest_dir:
            db.close()
            return
    user_agent = (provider.get('userAgent', '') or '') if provider else ''
    rec_headers = {}
    if provider and provider['type'] == 'stalker':
        try:
            client = make_stalker(provider)
            rec_headers = client._headers(with_auth=True)
            rec_headers.pop('User-Agent', None)
        except Exception:
            pass
    _recorder.start_recording(
        db, int(provider_id), int(channel_id), channel['name'],
        stream_url, title=epg_title, description=epg_description,
        duration_secs=dur_min * 60,
        dest_dir=dest_dir, user_agent=user_agent, headers=rec_headers
    )
    db.close()
    xbmc.executebuiltin('Container.Refresh')


def schedule_recording_from_epg(provider_id, channel_id, epg_channel_id, start_ts, end_ts, title, description=''):
    db = get_db()
    channel = db.get_channel(int(channel_id))
    provider = db.get_provider(int(provider_id))
    if not channel:
        ku.notify('Kanal nicht gefunden', icon=xbmcgui.NOTIFICATION_ERROR)
        db.close()
        return
    dest_dir = ku.get_setting('recording_dest_dir', '') or ''
    if not dest_dir:
        dest_dir = ku.browse_folder_dialog('Aufnahmeordner wählen')
        if not dest_dir:
            db.close()
            return
    _recorder.schedule_recording(
        db, int(provider_id), int(channel_id), channel['name'],
        channel['streamUrl'], title, description,
        int(start_ts), int(end_ts), dest_dir=dest_dir
    )
    db.close()


def timers():
    db = get_db()
    art = {'thumb': ku.ADDON_ICON, 'icon': ku.ADDON_ICON, 'fanart': ku.ADDON_FANART}
    recs = db.get_recordings(status='scheduled')
    db.close()
    if not recs:
        ku.notify('Keine Timer vorhanden')
        ku.end_directory(cacheToTime=False)
        return
    for rec in recs:
        start_str = time.strftime('%d.%m. %H:%M', time.localtime(rec['startTime']))
        end_str = time.strftime('%H:%M', time.localtime(rec['endTime']))
        label = f"{start_str}-{end_str} - {rec['channelName']}"
        if rec['title']:
            label += f" - {rec['title']}"
        plot_lines = [
            f"Kanal: {rec['channelName']}",
            f"Titel: {rec['title'] or '-'}",
            f"Start: {time.strftime('%d.%m.%Y %H:%M', time.localtime(rec['startTime']))}",
            f"Ende: {time.strftime('%d.%m.%Y %H:%M', time.localtime(rec['endTime']))}",
        ]
        info = {'title': label, 'plot': '\n'.join(plot_lines)}
        context = [
            ('Timer bearbeiten', f"RunPlugin({ku.build_url(action='edit_timer', rec_id=rec['id'])})"),
            ('Timer entfernen', f"RunPlugin({ku.build_url(action='delete_timer', rec_id=rec['id'])})"),
        ]
        ku.add_dir_item(label, ku.build_url(action='noop'), is_folder=False, info=info, art=art, context_menu=context)
    ku.end_directory(cacheToTime=False)


def add_timer(provider_id, channel_id):
    db = get_db()
    channel = db.get_channel(int(channel_id))
    db.close()
    if not channel:
        ku.notify('Kanal nicht gefunden', icon=xbmcgui.NOTIFICATION_ERROR)
        return
    title = ku.input_dialog(f'Titel für Timeraufnahme "{channel["name"]}"', default=channel['name'])
    if title is None:
        return
    start_str = ku.input_dialog('Startzeit (HH:MM)', default='20:15')
    if not start_str:
        return
    end_str = ku.input_dialog('Endzeit (HH:MM)', default='21:00')
    if not end_str:
        return
    start_ts, end_ts = _parse_timer_times(start_str, end_str)
    if start_ts is None:
        ku.notify('Ungültige Zeitangabe', icon=xbmcgui.NOTIFICATION_ERROR)
        return
    schedule_recording_from_epg(provider_id, channel_id, '', start_ts, end_ts, title.strip() or channel['name'])
    ku.notify(
        f'Timer gesetzt: {time.strftime("%d.%m. %H:%M", time.localtime(start_ts))}'
        f'-{time.strftime("%H:%M", time.localtime(end_ts))}'
    )
    xbmc.executebuiltin('Container.Refresh')


def edit_timer(rec_id):
    db = get_db()
    rec = db.get_recording(rec_id)
    if not rec or rec['status'] != 'scheduled':
        db.close()
        ku.notify('Timer nicht gefunden', icon=xbmcgui.NOTIFICATION_ERROR)
        return
    title = ku.input_dialog('Titel', default=rec['title'] or rec['channelName'])
    if title is None:
        db.close()
        return
    start_default = time.strftime('%H:%M', time.localtime(rec['startTime']))
    end_default = time.strftime('%H:%M', time.localtime(rec['endTime']))
    start_str = ku.input_dialog('Startzeit (HH:MM)', default=start_default)
    if not start_str:
        db.close()
        return
    end_str = ku.input_dialog('Endzeit (HH:MM)', default=end_default)
    if not end_str:
        db.close()
        return
    start_ts, end_ts = _parse_timer_times(start_str, end_str)
    if start_ts is None:
        db.close()
        ku.notify('Ungültige Zeitangabe', icon=xbmcgui.NOTIFICATION_ERROR)
        return
    db.update_recording_schedule(rec_id, title.strip(), start_ts, end_ts)
    db.close()
    ku.notify('Timer aktualisiert')
    xbmc.executebuiltin('Container.Refresh')


def delete_timer(rec_id):
    db = get_db()
    if ku.yesno_dialog('Timer entfernen', 'Diesen Timer wirklich entfernen?'):
        _recorder.cancel_recording(rec_id)
        db.delete_recording(rec_id)
        ku.notify('Timer entfernt')
    db.close()
    xbmc.executebuiltin('Container.Refresh')


def stop_recording(rec_id):
    db = get_db()
    cancelled = _recorder.cancel_recording(rec_id)
    if cancelled:
        db.update_recording(rec_id, status='cancelled')
        ku.notify('Aufnahme gestoppt')
    else:
        ku.notify('Aufnahme konnte nicht gestoppt werden')
    db.close()
    xbmc.executebuiltin('Container.Refresh')


def cancel_recording_entry(rec_id):
    db = get_db()
    _recorder.cancel_recording(rec_id)
    db.update_recording(rec_id, status='cancelled')
    db.close()
    ku.notify('Aufnahme storniert')
    xbmc.executebuiltin('Container.Refresh')


def delete_recording_entry(rec_id):
    db = get_db()
    rec = db.get_recording(rec_id)
    if rec:
        if rec['status'] == 'recording':
            _recorder.cancel_recording(rec_id)
        if ku.yesno_dialog('Aufnahme löschen', 'Datenbankeinrag löschen?\n(Datei bleibt erhalten)'):
            db.delete_recording(rec_id)
            ku.notify('Eintrag gelöscht')
    db.close()
    xbmc.executebuiltin('Container.Refresh')


def play_recording(rec_id):
    db = get_db()
    rec = db.get_recording(rec_id)
    db.close()
    if not rec:
        ku.notify('Aufnahme nicht gefunden', icon=xbmcgui.NOTIFICATION_ERROR)
        return
    if not os.path.exists(rec['destPath']):
        ku.notify(f'Datei nicht gefunden: {rec["destPath"]}', icon=xbmcgui.NOTIFICATION_ERROR)
        return
    ku.log_debug(f'play_recording: {rec["destPath"]}')
    ku.resolve_url(rec['destPath'])


def check_scheduled_recordings():
    db = get_db()
    try:
        _recorder.check_scheduled_recordings(db)
    finally:
        db.close()


def open_settings():
    ku.ADDON.openSettings()


def sync_all():
    db = get_db()
    providers = db.get_providers(only_enabled=True)
    skipped = [p for p in providers if dict(p).get('lastSyncError', '')]
    to_sync = [p for p in providers if not dict(p).get('lastSyncError', '')]
    ku.log_debug(f'sync_all: {len(to_sync)} Anbieter, {len(skipped)} uebersprungen (Fehler)')
    if skipped:
        names = ', '.join(p['name'] for p in skipped)
        ku.notify(f'Uebersprungen (Fehler): {names}')
    for p in to_sync:
        do_sync(db, p['id'])
    db.close()
    xbmc.executebuiltin('Container.Refresh')


def test_provider(provider_id):
    db = get_db()
    provider = db.get_provider(provider_id)
    server_url = provider.get('serverUrl', '')
    if provider['type'] in ('xtream', 'stalker', 'enigma2', 'jellyfin'):
        if not server_url or not server_url.startswith('http'):
            ku.notify('Keine gültige Server-URL konfiguriert', icon=xbmcgui.NOTIFICATION_ERROR)
            db.close()
            return
    try:
        if provider['type'] == 'xtream':
            ok = make_xtream(provider).test_connection()
        elif provider['type'] == 'stalker':
            ok = make_stalker(provider).test_connection()
        elif provider['type'] == 'enigma2':
            ok = make_enigma2(provider).test_connection()
        elif provider['type'] == 'jellyfin':
            ok = make_jellyfin(provider).test_connection()
        else:
            ok = True
        ku.log_debug(f"test_provider: {provider['name']} ({provider['type']}) -> {'ok' if ok else 'fehlgeschlagen'}")
        ku.notify('Verbindung erfolgreich' if ok else 'Verbindung fehlgeschlagen')
    except Exception as e:
        ku.log(f"test_provider: Fehler bei {provider['name']}: {e}", xbmc.LOGERROR)
        ku.notify(f'Fehler: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
    db.close()


def delete_provider(provider_id):
    db = get_db()
    epg_db = get_epg_db()
    provider = db.get_provider(provider_id)
    if provider and ku.yesno_dialog('Löschen', f"\"{provider['name']}\" wirklich löschen?"):
        db.delete_provider(provider_id)
        epg_db.delete_provider(provider_id)
        ku.log_debug(f"Anbieter gelöscht: id={provider_id} name={provider['name']}")
        ku.notify('Anbieter gelöscht')
        xbmc.executebuiltin('Container.Refresh')
    epg_db.close()
    db.close()


def _format_size(num_bytes):
    value = float(num_bytes)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if value < 1024 or unit == 'TB':
            return f'{value:.0f} {unit}' if unit == 'B' else f'{value:.1f} {unit}'
        value /= 1024


def _format_speed(bytes_per_second):
    return f'{_format_size(bytes_per_second)}/s'


def _format_eta(seconds):
    seconds = int(max(seconds, 0))
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours > 0:
        return f'{hours:02d}:{minutes:02d}:{secs:02d}'
    return f'{minutes:02d}:{secs:02d}'


def _load_active_downloads():
    data = ku.load_json(ku.active_downloads_path(), {})
    stale_ids = [did for did, entry in data.items() if time.time() - entry.get('started_at', 0) > 6 * 3600]
    if stale_ids:
        for did in stale_ids:
            del data[did]
        _save_active_downloads(data)
    return data


def _save_active_downloads(data):
    ku.save_json(ku.active_downloads_path(), data)


def _set_download_entry(download_id, **fields):
    data = _load_active_downloads()
    entry = data.get(download_id, {})
    entry.update(fields)
    data[download_id] = entry
    _save_active_downloads(data)


def _remove_download_entry(download_id):
    data = _load_active_downloads()
    if download_id in data:
        del data[download_id]
        _save_active_downloads(data)


def download_status(download_id):
    data = _load_active_downloads()
    entry = data.get(download_id)
    if not entry:
        ku.notify('Download nicht mehr aktiv')
        return
    status = entry.get('status', 'running')
    status_label = 'Pausiert' if status == 'paused' else 'Laeuft'
    message = (f"Status: {status_label}\n"
               f"{entry.get('size_line', '')}\n"
               f"Geschwindigkeit: {entry.get('speed_line', '')}\n"
               f"Restzeit: {entry.get('eta_line', '')}")
    ku.ok_dialog(f"{entry.get('name', 'Download')} - {entry.get('percent', 0)}%", message)


def download_pause(download_id):
    _set_download_entry(download_id, control='pause')
    xbmc.executebuiltin('Container.Refresh')


def download_resume(download_id):
    _set_download_entry(download_id, control='resume')
    xbmc.executebuiltin('Container.Refresh')


def download_cancel(download_id):
    _set_download_entry(download_id, control='cancel')
    xbmc.executebuiltin('Container.Refresh')


def _wait_while_paused(download_id):
    while True:
        xbmc.sleep(1000)
        data = _load_active_downloads()
        entry = data.get(download_id)
        if entry is None:
            return True
        control = entry.get('control')
        if control == 'cancel':
            return True
        if control == 'resume':
            entry['status'] = 'running'
            entry['control'] = None
            data[download_id] = entry
            _save_active_downloads(data)
            return False


def _process_download_control(download_id, reporter=None):
    data = _load_active_downloads()
    entry = data.get(download_id)
    if entry is None:
        return 'cancel'
    control = entry.get('control')
    if control == 'cancel':
        return 'cancel'
    if control == 'pause':
        entry['status'] = 'paused'
        entry['control'] = None
        data[download_id] = entry
        _save_active_downloads(data)
        if reporter is not None:
            reporter.set_paused(True)
        canceled = _wait_while_paused(download_id)
        if reporter is not None:
            reporter.set_paused(False)
        return 'cancel' if canceled else 'resumed'
    return None


class _DialogReporter:
    def __init__(self, heading, label):
        self.label = label
        self.dialog = ku.progress_dialog()
        self.dialog.create(heading, f'Lade {label}...')
        self.paused = False

    def update(self, percent, size_line, speed_line, eta_line):
        if self.paused:
            return
        message = f'Lade {self.label}...\n{size_line}  ({speed_line})\nRestzeit: {eta_line}'
        self.dialog.update(percent, message)

    def set_paused(self, paused):
        self.paused = paused
        if paused:
            self.dialog.update(self.dialog.getPercent() if hasattr(self.dialog, 'getPercent') else 0,
                                f'Lade {self.label}...\nPausiert')

    def iscanceled(self):
        return self.dialog.iscanceled()

    def close(self):
        self.dialog.close()


class _BackgroundReporter:
    def __init__(self, heading, label):
        self.heading = heading
        self.label = label
        self.last_notified_step = -1

    def update(self, percent, size_line, speed_line, eta_line):
        step = percent // 10
        if step != self.last_notified_step:
            self.last_notified_step = step
            ku.notify(f'{self.label}: {percent}%  {size_line}  ({speed_line})  Rest: {eta_line}',
                      heading=self.heading, time=3000)

    def set_paused(self, paused):
        if paused:
            ku.notify(f'{self.label}: pausiert', heading=self.heading, time=3000)
        else:
            ku.notify(f'{self.label}: fortgesetzt', heading=self.heading, time=3000)

    def iscanceled(self):
        return False

    def close(self):
        pass


def download(content_type, provider_id, raw_id):
    db = get_db()
    try:
        if content_type == 'movie':
            row = db.get_movie(provider_id, int(raw_id))
            name = row['name'] if row else 'film'
            stream_id = row.get('streamId', '') if row else ''
            ext_hint = row.get('containerExt', '') if row else ''
        elif content_type == 'episode':
            row = db.conn.execute(
                'SELECT * FROM episodes WHERE providerId = ? AND id = ?', (provider_id, raw_id)
            ).fetchone()
            name = row['title'] if row else 'episode'
            stream_id = row.get('streamId', '') if row else ''
            ext_hint = row.get('containerExt', '') if row else ''
        else:
            ku.notify('Download nur fuer Filme und Serien verfuegbar', icon=xbmcgui.NOTIFICATION_WARNING)
            db.close()
            return

        provider = db.get_provider(provider_id)
        db.close()

        stream_url = None
        container = ext_hint or 'mp4'

        if provider and provider['type'] == 'jellyfin' and stream_id:
            try:
                client = make_jellyfin(provider)
                stream_url, container = client.resolve_download_url(stream_id)
                ku.log_debug(f'download: Jellyfin direct download url={stream_url} container={container}')
            except Exception as e:
                ku.log_error(f'download: Jellyfin resolve_download_url fehlgeschlagen: {e}')
        
        if not stream_url:
            db2 = get_db()
            try:
                stream_url = resolve_play_url(db2, provider_id, content_type, raw_id)
            finally:
                db2.close()

        if not stream_url:
            ku.notify('Stream-URL konnte nicht aufgeloest werden', icon=xbmcgui.NOTIFICATION_ERROR)
            return

        if stream_url.endswith('.m3u8') or '.m3u8?' in stream_url:
            ku.ok_dialog('Download nicht moeglich',
                         'Der Server liefert nur einen HLS-Stream (m3u8). '
                         'Bitte in den Einstellungen Transcoding deaktivieren oder '
                         'Bitrate/MaxWidth-Begrenzung entfernen.')
            return

        mode_choice = ku.select_dialog('Download', ['Mit Fortschrittsanzeige', 'Im Hintergrund (Benachrichtigung alle 10%)'])
        if mode_choice == -1:
            return
        background_mode = (mode_choice == 1)

        dest_dir = ku.browse_folder_dialog('Download-Ordner waehlen')
        if not dest_dir:
            return

        safe_name = ''.join(c for c in name if c.isalnum() or c in ' ._-()[]').strip()
        if not container.startswith('.'):
            container = '.' + container
        filename = safe_name + container
        dest_path = os.path.join(dest_dir, filename)

        ku.log_debug(f'download: {content_type} url={stream_url} -> {dest_path}')

        download_id = uuid.uuid4().hex

        try:
            from resources.lib import http_client
            session = http_client.new_session()
            if background_mode:
                reporter = _BackgroundReporter('Download', safe_name)
            else:
                reporter = _DialogReporter('Download', safe_name)
            _set_download_entry(download_id, name=safe_name, percent=0, size_line='', speed_line='',
                                 eta_line='--:--', started_at=time.time(), status='running', control=None)
            last_update = 0.0
            last_downloaded = 0
            speed_bps = 0.0
            with session._b.stream('GET', stream_url) as resp:
                total = int(resp.headers.get('content-length', 0))
                downloaded = 0
                with open(dest_path, 'wb') as f:
                    for chunk in resp.iter_bytes(chunk_size=1024 * 512):
                        if reporter.iscanceled():
                            reporter.close()
                            _remove_download_entry(download_id)
                            try:
                                os.remove(dest_path)
                            except Exception:
                                pass
                            ku.notify('Download abgebrochen')
                            return
                        f.write(chunk)
                        downloaded += len(chunk)
                        now = time.monotonic()
                        elapsed_since_update = now - last_update
                        if elapsed_since_update >= 0.5 or downloaded == total:
                            interval_bytes = downloaded - last_downloaded
                            if elapsed_since_update > 0:
                                instant_speed = interval_bytes / elapsed_since_update
                                speed_bps = (speed_bps * 0.7) + (instant_speed * 0.3) if speed_bps else instant_speed
                            last_update = now
                            last_downloaded = downloaded
                            percent = int(downloaded * 100 / total) if total > 0 else 0
                            size_line = f'{_format_size(downloaded)} / {_format_size(total)}' if total > 0 else _format_size(downloaded)
                            speed_line = _format_speed(speed_bps)
                            if total > 0 and speed_bps > 0:
                                remaining_bytes = max(total - downloaded, 0)
                                eta_seconds = remaining_bytes / speed_bps
                                eta_line = _format_eta(eta_seconds)
                            else:
                                eta_line = '--:--'
                            reporter.update(percent, size_line, speed_line, eta_line)
                            _set_download_entry(download_id, percent=percent, size_line=size_line,
                                                 speed_line=speed_line, eta_line=eta_line)
                            control_result = _process_download_control(download_id, reporter)
                            if control_result == 'cancel':
                                reporter.close()
                                _remove_download_entry(download_id)
                                try:
                                    os.remove(dest_path)
                                except Exception:
                                    pass
                                ku.notify('Download abgebrochen')
                                return
                            if control_result == 'resumed':
                                last_update = time.monotonic()
                                last_downloaded = downloaded
                                speed_bps = 0.0
            reporter.close()
            _remove_download_entry(download_id)
            ku.notify(f'Download abgeschlossen: {filename}', time=5000)
            ku.log_debug(f'download: Datei gespeichert unter {dest_path}')
        except Exception as e:
            try:
                reporter.close()
            except Exception:
                pass
            _remove_download_entry(download_id)
            try:
                os.remove(dest_path)
            except Exception:
                pass
            ku.log_error(f'download: Fehler: {e}')
            ku.notify(f'Download fehlgeschlagen: {e}', icon=xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        try:
            db.close()
        except Exception:
            pass
        ku.log_error(f'download: Fehler beim Vorbereiten: {e}')
        ku.notify(f'Download fehlgeschlagen: {e}', icon=xbmcgui.NOTIFICATION_ERROR)


def backup_data():
    src_dir = ku.PROFILE_DIR
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    default_name = f'multistream_backup_{timestamp}.zip'
    dest_dir = ku.browse_folder_dialog('Backup-Ordner wählen')
    if not dest_dir:
        return
    zip_path = os.path.join(dest_dir, default_name)
    try:
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(src_dir):
                for fname in files:
                    fpath = os.path.join(root, fname)
                    arcname = os.path.relpath(fpath, src_dir)
                    zf.write(fpath, arcname)
        ku.notify(f'Backup erstellt: {default_name}', time=5000)
        ku.log_debug(f'backup_data: Backup gespeichert unter {zip_path}')
    except Exception as e:
        ku.log_error(f'backup_data: Fehler beim Erstellen des Backups: {e}')
        ku.notify('Backup fehlgeschlagen', icon=xbmcgui.NOTIFICATION_ERROR)


def restore_data():
    zip_path = ku.browse_file_dialog('Backup-ZIP wählen', mask='.zip')
    if not zip_path or not zip_path.endswith('.zip'):
        return
    if not ku.yesno_dialog('Backup einspielen', 'Alle aktuellen Anbieter-Daten und Einstellungen werden überschrieben. Fortfahren?'):
        return
    dest_dir = ku.PROFILE_DIR
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            names = zf.namelist()
            if not names:
                ku.ok_dialog('Fehler', 'Ungültige Backup-Datei.')
                return
            zf.extractall(dest_dir)
        ku.log_debug(f'restore_data: Backup eingespielt von {zip_path}')
        ku.notify('Backup erfolgreich eingespielt. Kodi neu starten empfohlen.', time=6000)
    except Exception as e:
        ku.log_error(f'restore_data: Fehler beim Einspielen: {e}')
        ku.notify('Wiederherstellen fehlgeschlagen', icon=xbmcgui.NOTIFICATION_ERROR)


def reset_database():
    if not ku.yesno_dialog('Datenbank zurücksetzen', 'Wirklich ALLE Anbieter und Daten löschen? Dies kann nicht rückgängig gemacht werden!'):
        return
    db = get_db()
    db.reset_database()
    db.close()
    ku.log_debug('Datenbank wurde komplett zurückgesetzt')
    ku.notify('Datenbank wurde zurückgesetzt')
    xbmc.executebuiltin('Container.Refresh')


def edit_provider_dialog(provider_id):
    db = get_db()
    provider = db.get_provider(provider_id)
    options = ['Bearbeiten', 'Synchronisieren', 'EPG aktualisieren', 'Verbindung testen',
               'Aktivieren' if not provider['isEnabled'] else 'Deaktivieren', 'Löschen']
    idx = ku.select_dialog(provider['name'], options)
    if idx == 0:
        add_provider_dialog(provider['type'], existing=provider)
    elif idx == 1:
        do_sync(db, provider_id)
        xbmc.executebuiltin('Container.Refresh')
    elif idx == 2:
        db.close()
        do_sync_epg_only(db, provider_id)
        return
    elif idx == 3:
        db.close()
        test_provider(provider_id)
        return
    elif idx == 4:
        db.update_provider(provider_id, isEnabled=0 if provider['isEnabled'] else 1)
        xbmc.executebuiltin('Container.Refresh')
    elif idx == 5:
        db.close()
        delete_provider(provider_id)
        return
    db.close()


def router(params):
    action = params.get('action')
    ku.log_debug(f'router: action={action} params={params}')
    if not action:
        maybe_autostart_wizard()
        main_menu()
        return

    if action == 'providers':
        providers_menu()
    elif action == 'setup_wizard':
        setup_wizard()
    elif action == 'select_provider_type':
        select_provider_type()
    elif action == 'import_provider':
        import_provider()
    elif action == 'edit_provider':
        edit_provider_dialog(int(params['id']))
    elif action == 'delete_provider':
        delete_provider(int(params['id']))
    elif action == 'reset_database':
        reset_database()
    elif action == 'backup_data':
        backup_data()
    elif action == 'restore_data':
        restore_data()
    elif action == 'favorites_menu':
        favorites_menu()
    elif action == 'favorites':
        favorites(params.get('content_type', 'movie'))
    elif action == 'toggle_favorite':
        toggle_favorite(params.get('content_type'), int(params['provider_id']), params['item_id'])
    elif action == 'watch_history':
        watch_history()
    elif action == 'continue_watching':
        continue_watching()
    elif action == 'remove_continue_watching':
        remove_continue_watching(int(params['provider_id']), params.get('content_type'), params.get('item_id'))
    elif action == 'epg_reminders':
        epg_reminders()
    elif action == 'add_epg_reminder':
        add_epg_reminder(int(params['provider_id']), int(params['channel_id']), params['epg_channel_id'],
                         int(params['start']), int(params['end']), params.get('title', ''))
    elif action == 'remove_epg_reminder':
        remove_epg_reminder(int(params['reminder_id']))
    elif action == 'reset_epg_source':
        db = get_db()
        db.update_provider(int(params['id']), useInternalEpg=-1)
        db.close()
        ku.notify('EPG-Quelle zurückgesetzt – wird beim nächsten Sync neu gefragt')
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'sync_epg_only':
        db = get_db()
        do_sync_epg_only(db, int(params['id']))
        db.close()
    elif action == 'fuzzy_epg_match':
        fuzzy_epg_match(int(params['provider_id']))
    elif action == 'search_menu':
        search_menu()
    elif action == 'search_input':
        search_input()
    elif action == 'search_run':
        search_run(params.get('query', ''))
    elif action == 'search_clear_history':
        search_clear_history()
    elif action == 'recordings':
        recordings()
    elif action == 'timers':
        timers()
    elif action == 'add_timer':
        add_timer(int(params['provider_id']), int(params['channel_id']))
    elif action == 'edit_timer':
        edit_timer(params['rec_id'])
    elif action == 'delete_timer':
        delete_timer(params['rec_id'])
    elif action == 'start_recording':
        start_recording_from_channel(int(params['provider_id']), int(params['channel_id']), epg_title_hint=params.get('epg_title', ''))
    elif action == 'record_current_channel':
        record_current_channel()
    elif action == 'schedule_recording':
        schedule_recording_from_epg(
            int(params['provider_id']), int(params['channel_id']),
            params.get('epg_channel_id', ''),
            int(params['start']), int(params['end']),
            params.get('title', ''), params.get('description', '')
        )
    elif action == 'stop_recording':
        stop_recording(params['rec_id'])
    elif action == 'cancel_recording':
        cancel_recording_entry(params['rec_id'])
    elif action == 'delete_recording':
        delete_recording_entry(params['rec_id'])
    elif action == 'play_recording':
        play_recording(params['rec_id'])
    elif action == 'check_scheduled_recordings':
        check_scheduled_recordings()
    elif action == 'prune_epg':
        prune_epg()
    elif action == 'download':
        download(params.get('type'), int(params['provider_id']), params['id'])
    elif action == 'downloads':
        downloads_folder()
    elif action == 'download_status':
        download_status(params['download_id'])
    elif action == 'download_pause':
        download_pause(params['download_id'])
    elif action == 'download_resume':
        download_resume(params['download_id'])
    elif action == 'download_cancel':
        download_cancel(params['download_id'])
    elif action == 'test_provider':
        test_provider(int(params['id']))
    elif action == 'sync_provider':
        db = get_db()
        do_sync(db, int(params['id']))
        db.close()
    elif action == 'sync_all':
        sync_all()
    elif action == 'open_settings':
        open_settings()
    elif action == 'movie_categories':
        movie_categories()
    elif action == 'movies':
        movies(params.get('category'), params.get('provider_id'))
    elif action == 'series_categories':
        series_categories()
    elif action == 'series_list':
        series_list(params.get('category'), params.get('provider_id'))
    elif action == 'seasons':
        seasons(int(params['provider_id']), int(params['series_id']))
    elif action == 'refresh_episodes':
        refresh_episodes(int(params['provider_id']), int(params['series_id']))
    elif action == 'episodes':
        episodes(int(params['provider_id']), int(params['series_id']), int(params['season']))
    elif action == 'channel_categories':
        channel_categories()
    elif action == 'channels':
        channels(params.get('category'), params.get('provider_id'))
    elif action == 'channel_epg':
        channel_epg(int(params['provider_id']), int(params['id']))
    elif action == 'play_catchup':
        play_catchup(int(params['provider_id']), int(params['channel_id']), int(params['start']), int(params['end']))
    elif action == 'noop':
        noop()
    elif action == 'play':
        content_type = params['type']
        provider_id = int(params['provider_id'])
        raw_id = params['id']
        if content_type == 'movie':
            raw_id = int(raw_id)
        elif content_type == 'channel':
            raw_id = int(raw_id)
        play(provider_id, content_type, raw_id)
    else:
        main_menu()
