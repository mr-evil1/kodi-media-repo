import hashlib
import time
import xbmcgui
from resources.lib import kodi_utils as ku

_SESSION_UNLOCK_TS = 0
_SESSION_UNLOCK_DURATION = 300


def _hash_pin(pin):
    return hashlib.sha256(pin.encode()).hexdigest()


def is_enabled():
    return ku.get_setting_bool('parental_control_enabled', False)


def has_pin():
    return bool(ku.get_setting('parental_control_pin', ''))


def set_pin(pin):
    ku.set_setting('parental_control_pin', _hash_pin(pin))


def clear_pin():
    ku.set_setting('parental_control_pin', '')


def _is_session_unlocked():
    global _SESSION_UNLOCK_TS
    return time.time() - _SESSION_UNLOCK_TS < _SESSION_UNLOCK_DURATION


def _mark_session_unlocked():
    global _SESSION_UNLOCK_TS
    _SESSION_UNLOCK_TS = time.time()


def lock_session():
    global _SESSION_UNLOCK_TS
    _SESSION_UNLOCK_TS = 0


def verify_pin(pin):
    stored = ku.get_setting('parental_control_pin', '')
    if not stored:
        return False
    return stored == _hash_pin(pin)


def _prompt_pin(heading):
    return xbmcgui.Dialog().input(heading, type=xbmcgui.INPUT_NUMERIC)


def require_pin(heading='Kindersicherung'):
    if not is_enabled():
        return True
    if _is_session_unlocked():
        return True
    if not has_pin():
        new_pin = _prompt_pin('Neuen PIN festlegen (4 Stellen)')
        if not new_pin:
            return False
        confirm = _prompt_pin('PIN bestätigen')
        if new_pin != confirm:
            ku.notify('PINs stimmen nicht überein', icon=xbmcgui.NOTIFICATION_ERROR)
            return False
        set_pin(new_pin)
        _mark_session_unlocked()
        ku.notify('Kindersicherungs-PIN gesetzt')
        return True
    pin = _prompt_pin(heading)
    if not pin:
        return False
    if verify_pin(pin):
        _mark_session_unlocked()
        return True
    ku.notify('Falscher PIN', icon=xbmcgui.NOTIFICATION_ERROR)
    return False


def change_pin():
    if has_pin():
        old = _prompt_pin('Aktuellen PIN eingeben')
        if not old:
            return False
        if not verify_pin(old):
            ku.notify('Falscher PIN', icon=xbmcgui.NOTIFICATION_ERROR)
            return False
    new_pin = _prompt_pin('Neuen PIN eingeben (4 Stellen)')
    if not new_pin:
        return False
    confirm = _prompt_pin('Neuen PIN bestätigen')
    if new_pin != confirm:
        ku.notify('PINs stimmen nicht überein', icon=xbmcgui.NOTIFICATION_ERROR)
        return False
    set_pin(new_pin)
    ku.notify('PIN wurde geändert')
    return True


def is_adult_category(name):
    kw_str = ku.get_setting('parental_adult_keywords', 'adult,xxx,18+,erotik,porn,sex,erotic,hentai')
    if not kw_str:
        return False
    keywords = [k.strip().lower() for k in kw_str.split(',') if k.strip()]
    return any(kw in (name or '').lower() for kw in keywords)
