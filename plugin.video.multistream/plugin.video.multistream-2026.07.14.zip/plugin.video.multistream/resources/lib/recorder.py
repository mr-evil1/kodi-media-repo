import os
import re
import threading
import time
import uuid
from urllib.parse import urljoin, urlparse
from xml.sax.saxutils import escape as xml_escape

import xbmc
import xbmcgui

from resources.lib import kodi_utils as ku

MAX_RECONNECT_ATTEMPTS = 10

RECORDINGS_STATE_FILE = None
_lock = threading.Lock()


def _state_path():
    global RECORDINGS_STATE_FILE
    if RECORDINGS_STATE_FILE is None:
        RECORDINGS_STATE_FILE = os.path.join(ku.PROFILE_DIR, 'active_recordings.json')
    return RECORDINGS_STATE_FILE


def _load_state():
    return ku.load_json(_state_path(), {})


def _save_state(data):
    ku.save_json(_state_path(), data)


def _set_state(rec_id, **fields):
    with _lock:
        data = _load_state()
        entry = data.get(rec_id, {})
        entry.update(fields)
        data[rec_id] = entry
        _save_state(data)


def _remove_state(rec_id):
    with _lock:
        data = _load_state()
        if rec_id in data:
            del data[rec_id]
            _save_state(data)


def get_active_recordings():
    data = _load_state()
    now = time.time()
    stale = [rid for rid, e in data.items() if now - e.get('started_at', now) > 12 * 3600]
    if stale:
        with _lock:
            data2 = _load_state()
            for rid in stale:
                data2.pop(rid, None)
            _save_state(data2)
            data = data2
    return data


def _use_httpx():
    if ku.get_setting('use_httpx', 'false') != 'true':
        return False
    try:
        import httpx
        return True
    except ImportError:
        ku.log('Recorder: httpx nicht verfuegbar, nutze requests', xbmc.LOGWARNING)
        return False


def _sanitize(text, max_len=60):
    replacements = {'ä': 'ae', 'ö': 'oe', 'ü': 'ue', 'Ä': 'Ae', 'Ö': 'Oe', 'Ü': 'Ue', 'ß': 'ss'}
    for src, dst in replacements.items():
        text = text.replace(src, dst)
    text = ''.join(c for c in text if c.isalnum() or c in ' _-()[]').strip()
    text = ' '.join(text.split())
    return text[:max_len].strip()


def _make_dest_path(dest_dir, channel_name, title, start_time):
    ts = time.strftime('%Y%m%d_%H%M', time.localtime(start_time))
    if title:
        chan_lower = channel_name.lower().strip()
        title_lower = title.lower().strip()
        if title_lower.startswith(chan_lower):
            combined = title
        else:
            combined = f'{channel_name} - {title}'
        safe = _sanitize(combined, max_len=80)
        filename = f'{ts}_{safe}.ts' if safe else f'{ts}_{_sanitize(channel_name, max_len=40)}.ts'
    else:
        filename = f'{ts}_{_sanitize(channel_name, max_len=40)}.ts'
    return os.path.join(dest_dir, filename)


def _write_nfo(dest_path, title, description, channel_name, start_time):
    if not title:
        return
    nfo_path = os.path.splitext(dest_path)[0] + '.nfo'
    aired = time.strftime('%Y-%m-%d', time.localtime(start_time))
    lines = [
        '<movie>',
        f'  <title>{xml_escape(title)}</title>',
        f'  <studio>{xml_escape(channel_name)}</studio>',
        f'  <aired>{aired}</aired>',
    ]
    if description:
        lines.append(f'  <plot>{xml_escape(description)}</plot>')
    lines.append('</movie>')
    try:
        with open(nfo_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines))
    except Exception as e:
        ku.log(f'NFO konnte nicht geschrieben werden ({nfo_path}): {e}', xbmc.LOGWARNING)


class RecordingThread(threading.Thread):
    def __init__(self, rec_id, db_path_val, stream_url, dest_path, duration_secs,
                 channel_name, title, user_agent='', headers=None):
        super().__init__(daemon=True, name=f'rec_{rec_id[:8]}')
        self.rec_id = rec_id
        self.db_path_val = db_path_val
        self.stream_url = stream_url
        self.dest_path = dest_path
        self.duration_secs = duration_secs
        self.channel_name = channel_name
        self.title = title
        self.user_agent = user_agent
        self.headers = dict(headers or {})
        self._stop = threading.Event()
        self._manual_cancel = False
        self._timer = None

    def _build_headers(self):
        headers = dict(self.headers)
        ua = self.user_agent or ku.get_setting('user_agent_global', '') or ''
        if ua and 'User-Agent' not in headers:
            headers['User-Agent'] = ua
        return headers

    @staticmethod
    def _is_hls(url, content_type=''):
        if '.m3u8' in url.lower():
            return True
        if 'application/vnd.apple.mpegurl' in content_type.lower():
            return True
        if 'application/x-mpegurl' in content_type.lower():
            return True
        return False

    @staticmethod
    def _parse_m3u8_segments(base_url, text):
        lines = text.splitlines()
        segments = []
        for line in lines:
            line = line.strip()
            if line and not line.startswith('#'):
                if line.startswith('http://') or line.startswith('https://'):
                    segments.append(line)
                else:
                    segments.append(urljoin(base_url, line))
        return segments

    @staticmethod
    def _get_media_playlist(base_url, text):
        for line in text.splitlines():
            line = line.strip()
            if line and not line.startswith('#'):
                if line.startswith('http://') or line.startswith('https://'):
                    return line
                return urljoin(base_url, line)
        return None

    def _record_hls(self):
        import requests
        headers = self._build_headers()
        bytes_written = 0
        seen_segments = set()
        deadline = time.time() + self.duration_secs

        r = requests.get(self.stream_url, headers=headers, timeout=(10, 30))
        r.raise_for_status()
        content_type = r.headers.get('Content-Type', '')
        text = r.text

        media_url = self.stream_url
        if '#EXT-X-STREAM-INF' in text:
            candidate = self._get_media_playlist(self.stream_url, text)
            if candidate:
                media_url = candidate
                r2 = requests.get(media_url, headers=headers, timeout=(10, 30))
                r2.raise_for_status()
                text = r2.text

        ku.log_debug(f'HLS recorder: media playlist={media_url}')

        with open(self.dest_path, 'wb') as f:
            while not self._stop.is_set() and time.time() < deadline:
                try:
                    r3 = requests.get(media_url, headers=headers, timeout=(10, 30))
                    r3.raise_for_status()
                    segments = self._parse_m3u8_segments(media_url, r3.text)
                    new_segs = [s for s in segments if s not in seen_segments]
                    for seg_url in new_segs:
                        if self._stop.is_set() or time.time() >= deadline:
                            break
                        try:
                            sr = requests.get(seg_url, headers=headers, timeout=(5, 30), stream=True)
                            sr.raise_for_status()
                            for chunk in sr.iter_content(65536):
                                if chunk:
                                    f.write(chunk)
                                    bytes_written += len(chunk)
                            seen_segments.add(seg_url)
                        except Exception as seg_e:
                            ku.log(f'HLS: Segment-Fehler {seg_url}: {seg_e}', xbmc.LOGWARNING)
                    if not new_segs:
                        time.sleep(2)
                    else:
                        time.sleep(1)
                except Exception as e:
                    if self._stop.is_set():
                        break
                    ku.log(f'HLS: Playlist-Fehler: {e}', xbmc.LOGWARNING)
                    time.sleep(3)
        return bytes_written

    def _record_requests(self, append=False):
        import requests
        headers = self._build_headers()
        mode = 'ab' if append else 'wb'
        bytes_written = 0
        with requests.get(self.stream_url, stream=True, headers=headers, timeout=(10, 60)) as r:
            r.raise_for_status()
            with open(self.dest_path, mode) as f:
                for chunk in r.iter_content(chunk_size=65536):
                    if self._stop.is_set():
                        break
                    if chunk:
                        f.write(chunk)
                        bytes_written += len(chunk)
        return bytes_written

    def _record_httpx(self, append=False):
        import httpx
        headers = self._build_headers()
        mode = 'ab' if append else 'wb'
        bytes_written = 0
        timeout = httpx.Timeout(60.0, connect=10.0)
        with httpx.stream('GET', self.stream_url, headers=headers, timeout=timeout) as r:
            r.raise_for_status()
            with open(self.dest_path, mode) as f:
                for chunk in r.iter_bytes(65536):
                    if self._stop.is_set():
                        break
                    if chunk:
                        f.write(chunk)
                        bytes_written += len(chunk)
        return bytes_written

    def run(self):
        from resources.lib.database import Database
        db = Database(self.db_path_val)
        db.update_recording(self.rec_id, status='recording', pid=os.getpid())
        _set_state(self.rec_id, status='recording', started_at=time.time(),
                   channel=self.channel_name, title=self.title,
                   dest=self.dest_path, duration=self.duration_secs)

        self._timer = threading.Timer(self.duration_secs, self._stop.set)
        self._timer.daemon = True
        self._timer.start()

        is_hls = self._is_hls(self.stream_url)
        backend = 'hls' if is_hls else ('httpx' if _use_httpx() else 'requests')
        ku.log_debug(f'Recording start ({backend}): {self.stream_url} -> {self.dest_path}')

        bytes_written = 0
        append = False
        retries = 0
        gave_up = False

        try:
            if is_hls:
                try:
                    bytes_written = self._record_hls()
                except Exception as e:
                    ku.log(f'Recording {self.rec_id}: HLS Fehler: {e}', xbmc.LOGERROR)
            else:
                while not self._stop.is_set():
                    try:
                        if backend == 'httpx':
                            bytes_written += self._record_httpx(append)
                        else:
                            bytes_written += self._record_requests(append)
                        if self._stop.is_set():
                            break
                        retries += 1
                        append = True
                        if retries > MAX_RECONNECT_ATTEMPTS:
                            gave_up = True
                            ku.log(f'Recording {self.rec_id}: Stream wiederholt vorzeitig beendet, gebe auf', xbmc.LOGERROR)
                            break
                        ku.log_debug(f'Recording {self.rec_id}: Stream vorzeitig beendet, Reconnect {retries}/{MAX_RECONNECT_ATTEMPTS}')
                        time.sleep(min(2 * retries, 10))
                    except ImportError:
                        ku.log(f'Recording {self.rec_id}: httpx nicht verfuegbar, falle auf requests zurueck', xbmc.LOGWARNING)
                        backend = 'requests'
                        continue
                    except Exception as e:
                        if self._stop.is_set():
                            break
                        retries += 1
                        append = True
                        if retries > MAX_RECONNECT_ATTEMPTS:
                            gave_up = True
                            ku.log(f'Recording {self.rec_id}: zu viele Verbindungsabbrueche, gebe auf: {e}', xbmc.LOGERROR)
                            break
                        ku.log(f'Recording {self.rec_id}: Verbindungsabbruch ({type(e).__name__}: {e}), Reconnect {retries}/{MAX_RECONNECT_ATTEMPTS}', xbmc.LOGWARNING)
                        time.sleep(min(2 * retries, 10))

            if bytes_written <= 0:
                db.update_recording(self.rec_id, status='error', errorMsg='Keine Daten empfangen')
                _remove_state(self.rec_id)
                ku.log(f'Recording {self.rec_id}: keine Daten empfangen', xbmc.LOGERROR)
                ku.notify(f'Aufnahme-Fehler: {self.channel_name}', icon=xbmcgui.NOTIFICATION_ERROR)
            elif gave_up:
                db.update_recording(self.rec_id, status='error', errorMsg='Verbindung wiederholt abgebrochen')
                _remove_state(self.rec_id)
                ku.notify(f'Aufnahme unvollstaendig: {self.channel_name}', icon=xbmcgui.NOTIFICATION_WARNING)
            elif self._manual_cancel:
                db.update_recording(self.rec_id, status='cancelled')
                _remove_state(self.rec_id)
                ku.log_debug(f'Recording {self.rec_id}: abgebrochen, {bytes_written} Bytes')
            else:
                db.update_recording(self.rec_id, status='done', durationSecs=self.duration_secs)
                _remove_state(self.rec_id)
                ku.log_debug(f'Recording {self.rec_id}: fertig, {bytes_written} Bytes -> {self.dest_path}')
                ku.notify(f'Aufnahme fertig: {self.title or self.channel_name}', time=5000)
        except Exception as e:
            db.update_recording(self.rec_id, status='error', errorMsg=str(e)[:200])
            _remove_state(self.rec_id)
            ku.log(f'Recording {self.rec_id}: Exception {e}', xbmc.LOGERROR)
            ku.notify(f'Aufnahme-Fehler: {self.channel_name}', icon=xbmcgui.NOTIFICATION_ERROR)
        finally:
            self._timer.cancel()
            db.close()

    def cancel(self):
        self._manual_cancel = True
        self._stop.set()


_recording_threads = {}


def start_recording(db, provider_id, channel_id, channel_name, stream_url, title='',
                    description='', duration_secs=3600, dest_dir=None, user_agent='', headers=None):
    if not dest_dir:
        dest_dir = ku.get_setting('recording_dest_dir', '') or ''
    if not dest_dir:
        ku.notify('Kein Aufnahmeordner konfiguriert — bitte in Einstellungen festlegen', icon=2)
        return None

    os.makedirs(dest_dir, exist_ok=True)
    rec_id = uuid.uuid4().hex
    now = int(time.time())
    dest_path = _make_dest_path(dest_dir, channel_name, title, now)
    _write_nfo(dest_path, title, description, channel_name, now)

    db.add_recording(
        rec_id, provider_id, channel_id, channel_name, title, description,
        now, now + duration_secs, dest_path, status='recording'
    )

    t = RecordingThread(
        rec_id, ku.db_path(), stream_url, dest_path, duration_secs,
        channel_name, title, user_agent=user_agent, headers=headers
    )
    _recording_threads[rec_id] = t
    t.start()
    ku.log_debug(f'Recording gestartet: id={rec_id} kanal={channel_name} ziel={dest_path}')
    ku.notify(f'Aufnahme gestartet: {channel_name}')
    return rec_id


def schedule_recording(db, provider_id, channel_id, channel_name, stream_url, title,
                        description, start_time, end_time, dest_dir=None):
    if not dest_dir:
        dest_dir = ku.get_setting('recording_dest_dir', '') or ''
    if not dest_dir:
        ku.notify('Kein Aufnahmeordner konfiguriert', icon=2)
        return None

    os.makedirs(dest_dir, exist_ok=True)
    rec_id = uuid.uuid4().hex
    duration_secs = max(60, int(end_time) - int(start_time))
    dest_path = _make_dest_path(dest_dir, channel_name, title, int(start_time))
    _write_nfo(dest_path, title, description, channel_name, int(start_time))

    db.add_recording(
        rec_id, provider_id, channel_id, channel_name, title, description,
        int(start_time), int(end_time), dest_path, status='scheduled'
    )
    ku.log_debug(f'Aufnahme geplant: id={rec_id} start={start_time} kanal={channel_name}')
    ku.notify(f'Aufnahme geplant: {title or channel_name} um {time.strftime("%H:%M", time.localtime(int(start_time)))}')
    return rec_id


def cancel_recording(rec_id):
    t = _recording_threads.get(rec_id)
    if t and t.is_alive():
        t.cancel()
        return True
    _remove_state(rec_id)
    return False


def check_scheduled_recordings(db):
    now = int(time.time())
    due = db.get_scheduled_recordings(now)
    for rec in due:
        if rec['id'] in _recording_threads:
            t = _recording_threads[rec['id']]
            if t.is_alive():
                continue
        channel = db.get_channel(rec['channelId'])
        if not channel:
            db.update_recording(rec['id'], status='error', errorMsg='Kanal nicht gefunden')
            continue
        provider = db.get_provider(rec['providerId'])
        user_agent = provider.get('userAgent', '') if provider else ''
        rec_headers = {}
        stream_url = channel['streamUrl']
        if provider and provider['type'] == 'stalker':
            try:
                from resources.lib.sync import make_stalker
                client = make_stalker(provider)
                if stream_url and not stream_url.startswith('http'):
                    stream_url = client.create_link('itv', stream_url)
                rec_headers = client._headers(with_auth=True)
                rec_headers.pop('User-Agent', None)
            except Exception as e:
                ku.log(f'check_scheduled_recordings: Stalker URL-Aufloesung fehlgeschlagen {rec["id"]}: {e}', xbmc.LOGERROR)
                db.update_recording(rec['id'], status='error', errorMsg=f'URL-Aufloesung fehlgeschlagen: {e}')
                continue
        if provider and provider['type'] == 'vavoo' and stream_url:
            try:
                from resources.lib.vavoo import VavooClient
                client = VavooClient(provider['serverUrl'], log_func=ku.log)
                stream_url = client.resolve_stream_url(stream_url)
            except Exception as e:
                ku.log(f'check_scheduled_recordings: Vavoo URL-Aufloesung fehlgeschlagen {rec["id"]}: {e}', xbmc.LOGERROR)
                db.update_recording(rec['id'], status='error', errorMsg=f'URL-Aufloesung fehlgeschlagen: {e}')
                continue
        if not stream_url or not stream_url.startswith('http'):
            ku.log(f'check_scheduled_recordings: ungueltige stream_url {rec["id"]}: {stream_url!r}', xbmc.LOGERROR)
            db.update_recording(rec['id'], status='error', errorMsg='Keine gueltige Stream-URL')
            continue
        duration_secs = max(60, rec['endTime'] - rec['startTime'])

        db.update_recording(rec['id'], status='recording', pid=os.getpid())
        t = RecordingThread(
            rec['id'], ku.db_path(), stream_url, rec['destPath'], duration_secs,
            rec['channelName'], rec['title'], user_agent=user_agent, headers=rec_headers
        )
        _recording_threads[rec['id']] = t
        t.start()
        ku.log_debug(f'Geplante Aufnahme gestartet: id={rec["id"]} kanal={rec["channelName"]}')
