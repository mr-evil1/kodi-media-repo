import zlib
import concurrent.futures

from resources.lib.xtream import XtreamClient
from resources.lib.stalker import make_stalker_client, EPISODE_CMD_SEP
from resources.lib.enigma2 import Enigma2Client
from resources.lib.jellyfin import JellyfinClient
from resources.lib.m3u import M3uParser
from resources.lib.xmltv import XmltvParser
from resources.lib import kodi_utils as ku
from resources.lib.database import Database, EpgDatabase
import xbmc

import time as _time

MAX_WORKERS = 10
MAX_WORKERS_RATELIMITED = 2
RETRY_429_DELAYS = [1, 2, 4, 8]


def stable_id(text):
    return zlib.crc32(text.encode('utf-8'))


def parallel_map(func, items, max_workers=MAX_WORKERS):
    if not items:
        return []
    workers = min(max_workers, len(items))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        return list(executor.map(func, items))


def parallel_map_safe(func, items, default=None, max_workers=MAX_WORKERS):
    if not items:
        return []
    if default is None:
        default = []

    from resources.lib import http_client as _http_client

    def guarded_with_retry(item):
        for attempt, delay in enumerate([0] + RETRY_429_DELAYS):
            if delay:
                _time.sleep(delay)
            try:
                return func(item)
            except _http_client.HTTPError as e:
                if e.response is not None and e.response.status_code == 429:
                    if attempt < len(RETRY_429_DELAYS):
                        ku.log_debug(f'429 fuer Kategorie {item}, retry in {RETRY_429_DELAYS[attempt]}s')
                        continue
                ku.log(f'Kategorie uebersprungen ({item}): {e}', xbmc.LOGWARNING)
                return default
            except Exception as e:
                ku.log(f'Kategorie uebersprungen ({item}): {e}', xbmc.LOGWARNING)
                return default
        ku.log(f'Kategorie {item} nach allen Retries uebersprungen', xbmc.LOGWARNING)
        return default

    workers = min(max_workers, len(items))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        return list(executor.map(guarded_with_retry, items))


def make_xtream(provider):
    user_agent = provider.get('userAgent', '') or ku.get_setting('user_agent_global', '') or None
    connect_timeout = ku.get_setting_int('connect_timeout', 0) or None
    read_timeout = ku.get_setting_int('read_timeout', 0) or None
    return XtreamClient(
        provider['serverUrl'], provider['username'], provider['password'], log_func=ku.log_debug,
        user_agent=user_agent, connect_timeout=connect_timeout, read_timeout=read_timeout,
    )


def make_jellyfin(provider):
    return JellyfinClient(provider['serverUrl'], provider['username'], provider['password'], log_func=ku.log_debug)


def make_stalker(provider):
    compat = dict(provider).get('stalkerCompatMode')
    if compat == 1:
        compat_mode = True
    elif compat == 0:
        compat_mode = False
    else:
        compat_mode = None
    user_agent = provider.get('userAgent', '') or ku.get_setting('user_agent_global', '') or None
    connect_timeout = ku.get_setting_int('connect_timeout', 0) or None
    read_timeout = ku.get_setting_int('read_timeout', 0) or None
    page_workers = ku.get_setting_int('stalker_page_workers', 0) or None
    serial_number = dict(provider).get('stalkerSerialNumber') or None
    return make_stalker_client(
        provider['serverUrl'],
        provider['stalkerMacAddress'],
        provider['stalkerDeviceProfile'] or 'MAG250',
        provider['stalkerDeviceTimezone'] or 'Europe/Berlin',
        provider['stalkerDeviceLocale'] or 'de',
        log_func=ku.log_debug,
        compat_mode=compat_mode,
        user_agent=user_agent, connect_timeout=connect_timeout, read_timeout=read_timeout,
        page_workers=page_workers,
        serial_number=serial_number,
    )


def build_epg_urls(provider):
    urls = []
    ptype = provider.get('type', '')
    if ptype in ('m3u', 'xtream', 'stalker'):
        p_url = provider.get('epgUrl', '') or ''
        if p_url:
            urls.append(p_url)
        for u in (provider.get('altEpgUrls', '') or '').split('|'):
            u = u.strip()
            if u and u not in urls:
                urls.append(u)
    if ku.get_setting_bool('global_epg_enabled', False):
        g_url = ku.get_setting('global_epg_url', '').strip()
        if g_url and g_url not in urls:
            urls.append(g_url)
        for u in ku.get_setting('global_epg_alt_urls', '').split('|'):
            u = u.strip()
            if u and u not in urls:
                urls.append(u)
    return urls


def _xtream_xmltv_url(provider):
    base = provider.get('serverUrl', '').rstrip('/')
    u = provider.get('username', '')
    p = provider.get('password', '')
    return f'{base}/xmltv.php?username={u}&password={p}'


def apply_epg(epg_db, provider_id, channels, epg_urls, epg_offset, progress_cb=None, label=''):
    if not epg_urls:
        return
    if progress_cb:
        progress_cb(60, f'Lade XMLTV EPG{" (" + label + ")" if label else ""}...')
    for epg_url in epg_urls:
        try:
            xml_data = XmltvParser.fetch(epg_url)
            names, events_by_channel = XmltvParser.parse(xml_data)
            entries = []
            for cid, events in events_by_channel.items():
                if epg_offset:
                    shift = epg_offset * 3600
                    events = [dict(e, startTime=e['startTime'] + shift, endTime=e['endTime'] + shift) for e in events]
                entries.append((cid, names.get(cid, cid), events))
            if entries:
                epg_db.insert_epg_batch(provider_id, entries)
            ku.log_debug(f'EPG: {len(events_by_channel)} Kanäle geladen von {epg_url}')
            return
        except Exception as e:
            ku.log(f'XMLTV EPG konnte nicht geladen werden ({epg_url}): {e}', xbmc.LOGWARNING)
    ku.log('Alle EPG-URLs fehlgeschlagen', xbmc.LOGWARNING)


def _probe_stalker_xmltv(base_url, timeout=2):
    import threading as _threading
    from resources.lib import http_client as _hc
    candidates = [
        base_url.rstrip('/') + '/xmltv.php',
        base_url.rstrip('/') + '/stalker_portal/xmltv.php',
        base_url.rstrip('/') + '/server/api/xmltv.php',
    ]
    result = [None]
    lock = _threading.Lock()

    def _try(url):
        try:
            r = _hc.get(url, timeout=timeout)
            if r.status_code == 200 and b'<tv' in r.content[:512]:
                with lock:
                    if result[0] is None:
                        result[0] = url
                        ku.log_debug(f'Stalker: XMLTV gefunden: {url}')
        except Exception:
            pass

    with concurrent.futures.ThreadPoolExecutor(max_workers=len(candidates)) as ex:
        list(ex.map(_try, candidates))
    return result[0] or ''


def _to_int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None

def _parse_hhmm(s):
    s = (s or '').strip()
    if not s or ':' not in s:
        return None
    try:
        parts = s.split(':')
        h = int(parts[0])
        m = int(parts[1])
        sec = int(parts[2]) if len(parts) >= 3 else 0
        if not (0 <= h <= 23 and 0 <= m <= 59 and 0 <= sec <= 59):
            return None
        return h, m, sec
    except (ValueError, IndexError):
        return None


def _stb_event_to_timestamps(e):
    import datetime
    start = (
        _to_int(e.get('start_timestamp')) or
        _to_int(e.get('start')) or
        _to_int(e.get('begin_timestamp')) or
        _to_int(e.get('t_start'))
    )
    stop = (
        _to_int(e.get('stop_timestamp')) or
        _to_int(e.get('end_timestamp')) or
        _to_int(e.get('stop')) or
        _to_int(e.get('finish_timestamp')) or
        _to_int(e.get('t_stop'))
    )
    if start and stop:
        return start, stop
    t_from_str = None
    t_to_str = None
    for k in ('t_time', 'time', 'start_time'):
        v = e.get(k)
        if isinstance(v, str) and ':' in v:
            t_from_str = v
            break
    for k in ('t_time_to', 'time_to', 'end_time', 'stop_time'):
        v = e.get(k)
        if isinstance(v, str) and ':' in v:
            t_to_str = v
            break
    p_from = _parse_hhmm(t_from_str) if t_from_str else None
    p_to = _parse_hhmm(t_to_str) if t_to_str else None
    if p_from and p_to:
        now_local = datetime.datetime.now()
        dt_from = now_local.replace(hour=p_from[0], minute=p_from[1], second=p_from[2], microsecond=0)
        dt_to = now_local.replace(hour=p_to[0], minute=p_to[1], second=p_to[2], microsecond=0)
        if dt_to <= dt_from:
            dt_to += datetime.timedelta(days=1)
        return int(dt_from.timestamp()), int(dt_to.timestamp())
    return None, None


def _parse_epg_info_bulk(bulk_data, channels_by_sid, epg_offset):
    shift = (epg_offset or 0) * 3600
    result = {}
    for ch_id_str, entries in bulk_data.items():
        if not isinstance(entries, list):
            continue
        ch = channels_by_sid.get(str(ch_id_str))
        epg_key = (ch.get('epgChannelId') or ch_id_str) if ch else ch_id_str
        ch_name = ch['name'] if ch else ch_id_str
        events = []
        for e in entries:
            if not isinstance(e, dict):
                continue
            start, stop = _stb_event_to_timestamps(e)
            if not start or not stop:
                continue
            if shift:
                start += shift
                stop += shift
            events.append({
                'title': e.get('name', e.get('title', '')),
                'description': e.get('descr', e.get('description', '')),
                'startTime': start,
                'endTime': stop,
            })
        if events:
            result[epg_key] = (ch_name, events)
    return result


def _apply_stalker_native_epg(epg_db, provider_id, channels, client, epg_offset, progress_cb=None):
    import threading as _threading
    channels_by_sid = {str(c['streamId']): c for c in channels}

    if progress_cb:
        progress_cb(62, 'Stalker EPG: prüfe XMLTV-Endpoint...')
    xmltv_url = _probe_stalker_xmltv(client.server_url)
    if xmltv_url:
        try:
            xml_data = XmltvParser.fetch(xmltv_url)
            names, events_by_channel = XmltvParser.parse(xml_data)
            shift = (epg_offset or 0) * 3600
            entries = []
            for cid, events in events_by_channel.items():
                if shift:
                    events = [dict(e, startTime=e['startTime'] + shift, endTime=e['endTime'] + shift) for e in events]
                entries.append((cid, names.get(cid, cid), events))
            if entries:
                epg_db.insert_epg_batch(provider_id, entries)
            ku.log_debug(f'Stalker: XMLTV-EPG: {len(events_by_channel)} Kanäle von {xmltv_url}')
            return
        except Exception as e:
            ku.log(f'Stalker: XMLTV laden fehlgeschlagen ({xmltv_url}): {e}', xbmc.LOGWARNING)

    if progress_cb:
        progress_cb(65, 'Stalker EPG: lade get_epg_info (bulk)...')
    try:
        bulk = client.get_epg_info(period=5)
        if bulk:
            parsed = _parse_epg_info_bulk(bulk, channels_by_sid, epg_offset)
            entries = [(epg_key, ch_name, events) for epg_key, (ch_name, events) in parsed.items()]
            if entries:
                epg_db.insert_epg_batch(provider_id, entries)
            ku.log_debug(f'Stalker: get_epg_info bulk: {len(parsed)} Kanäle gespeichert')
            return
    except Exception as e:
        ku.log(f'Stalker: get_epg_info fehlgeschlagen: {e}', xbmc.LOGWARNING)

    ku.log_debug('Stalker: starte get_short_epg als Hintergrund-Thread')
    epg_db_path = ku.epg_db_path()

    def _short_epg_bg():
        bg_epg_db = EpgDatabase(epg_db_path)
        try:
            count = 0
            shift = (epg_offset or 0) * 3600
            bg_lock = _threading.Lock()
            collected = []

            def _fetch(ch):
                sid = str(ch.get('streamId', ''))
                entries = client.get_short_epg(sid, size=10)
                if not entries:
                    return
                events = []
                for e in entries:
                    start, stop = _stb_event_to_timestamps(e)
                    if not start or not stop:
                        continue
                    if shift:
                        start += shift
                        stop += shift
                    events.append({
                        'title': e.get('name', e.get('title', '')),
                        'description': e.get('descr', e.get('description', '')),
                        'startTime': start,
                        'endTime': stop,
                    })
                if events:
                    epg_key = ch.get('epgChannelId') or sid
                    with bg_lock:
                        collected.append((epg_key, ch['name'], events))

            workers = min(20, len(channels))
            with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
                list(ex.map(_fetch, channels))
            if collected:
                bg_epg_db.insert_epg_batch(provider_id, collected)
                count = len(collected)
            ku.log_debug(f'Stalker: get_short_epg Hintergrund fertig: {count} Kanäle')
        except Exception as e:
            ku.log(f'Stalker: get_short_epg Hintergrund Fehler: {e}', xbmc.LOGWARNING)
        finally:
            bg_epg_db.close()

    _threading.Thread(target=_short_epg_bg, daemon=True, name=f'stalker_epg_{provider_id}').start()



def make_enigma2(provider):
    port = ku.get_setting_int('enigma2_stream_port', 8001)
    return Enigma2Client(provider['serverUrl'], provider['username'], provider['password'], stream_port=port, log_func=ku.log_debug)


def enrich_movie(tmdb_client, name, year):
    if not tmdb_client or not tmdb_client.enabled():
        return {}
    result = tmdb_client.search_movie(name, year)
    if not result:
        return {}
    return {
        'tmdbId': str(result.get('id', '')),
        'overview': result.get('overview', ''),
        'posterUrl': tmdb_client.image_url(result.get('poster_path', '')),
        'backdropUrl': tmdb_client.image_url(result.get('backdrop_path', '')),
        'rating': result.get('vote_average', 0),
    }


def enrich_series(tmdb_client, name, year):
    if not tmdb_client or not tmdb_client.enabled():
        return {}
    result = tmdb_client.search_tv(name, year)
    if not result:
        return {}
    return {
        'tmdbId': str(result.get('id', '')),
        'overview': result.get('overview', ''),
        'posterUrl': tmdb_client.image_url(result.get('poster_path', '')),
        'backdropUrl': tmdb_client.image_url(result.get('backdrop_path', '')),
        'rating': result.get('vote_average', 0),
    }


def sync_xtream(db, epg_db, provider, tmdb_client=None, progress_cb=None):
    pid = provider['id']
    client = make_xtream(provider)

    def cb(pct, msg):
        if progress_cb:
            progress_cb(pct, msg)

    cb(5, 'Lade Live-Kategorien...')
    live_cats = {str(c['category_id']): c['category_name'] for c in client.get_live_categories()}
    cb(10, f'Live-Kategorien: {len(live_cats)} - lade Kanaele...')
    live_streams = client.get_live_streams()
    channels = []
    for s in live_streams:
        channels.append({
            'streamId': str(s.get('stream_id', '')),
            'name': s.get('name', ''),
            'logoUrl': s.get('stream_icon', ''),
            'streamUrl': client.live_stream_url(s.get('stream_id'), 'm3u8'),
            'categoryName': live_cats.get(str(s.get('category_id', '')), 'Allgemein'),
            'channelNumber': str(s.get('num', '')),
            'epgChannelId': s.get('epg_channel_id', '') or '',
            'tvArchive': 1 if str(s.get('tv_archive', 0)) == '1' else 0,
            'tvArchiveDuration': int(s.get('tv_archive_duration', 0) or 0),
        })
    db.insert_channels(pid, channels)
    ku.log_debug(f'Xtream: {len(channels)} Kanäle geladen')
    cb(25, f'Kanaele: {len(channels)} gespeichert')

    cb(30, 'Lade Film-Kategorien...')
    vod_cats = {str(c['category_id']): c['category_name'] for c in client.get_vod_categories()}
    cb(33, f'Film-Kategorien: {len(vod_cats)} - lade Filme...')
    vod_streams = client.get_vod_streams()
    cb(40, f'Filme: {len(vod_streams)} gefunden - reichere Metadaten an...')
    metas = parallel_map(
        lambda s: enrich_movie(tmdb_client, s.get('name', ''),
                                (s.get('release_date') or '')[:4] if s.get('release_date') else None),
        vod_streams,
    )
    movies = []
    for s, meta in zip(vod_streams, metas):
        name = s.get('name', '')
        ext = s.get('container_extension', 'mp4') or 'mp4'
        movies.append({
            'id': int(s.get('stream_id', 0)),
            'streamId': str(s.get('stream_id', '')),
            'name': name,
            'overview': meta.get('overview', ''),
            'posterUrl': meta.get('posterUrl') or s.get('stream_icon', ''),
            'backdropUrl': meta.get('backdropUrl', ''),
            'releaseDate': s.get('release_date', '') or '',
            'tmdbId': meta.get('tmdbId'),
            'rating': meta.get('rating') or s.get('rating', 0) or 0,
            'streamUrl': client.movie_stream_url(s.get('stream_id'), ext),
            'categoryName': vod_cats.get(str(s.get('category_id', '')), 'Allgemein'),
            'containerExt': ext,
        })
    db.insert_movies(pid, movies)
    ku.log_debug(f'Xtream: {len(movies)} Filme geladen')
    cb(55, f'Filme: {len(movies)} gespeichert')

    cb(58, 'Lade Serien-Kategorien...')
    series_cats = {str(c['category_id']): c['category_name'] for c in client.get_series_categories()}
    cb(62, f'Serien-Kategorien: {len(series_cats)} - lade Serien...')
    series_items = client.get_series()
    cb(70, f'Serien: {len(series_items)} gefunden - reichere Metadaten an...')
    series_metas = parallel_map(
        lambda s: enrich_series(tmdb_client, s.get('name', ''),
                                 (s.get('release_date') or '')[:4] if s.get('release_date') else None),
        series_items,
    )
    series_list = []
    for s, meta in zip(series_items, series_metas):
        name = s.get('name', '')
        series_list.append({
            'id': int(s.get('series_id', 0)),
            'streamId': str(s.get('series_id', '')),
            'name': name,
            'overview': meta.get('overview') or s.get('plot', '') or '',
            'posterUrl': meta.get('posterUrl') or s.get('cover', ''),
            'backdropUrl': meta.get('backdropUrl') or s.get('backdrop_path', [''])[0] if s.get('backdrop_path') else '',
            'releaseDate': s.get('release_date', '') or '',
            'tmdbId': meta.get('tmdbId'),
            'rating': meta.get('rating') or s.get('rating', 0) or 0,
            'categoryName': series_cats.get(str(s.get('category_id', '')), 'Allgemein'),
            'director': s.get('director', '') or '',
            'cast': s.get('cast', '') or '',
            'genre': s.get('genre', '') or '',
        })
    db.insert_series(pid, series_list)
    expiry_ts = 0
    try:
        expiry_ts = client.get_account_info()
        if expiry_ts:
            ku.log_debug(f'Xtream: Ablaufdatum ermittelt: {expiry_ts}')
    except Exception as e:
        ku.log(f'Xtream: Ablaufdatum konnte nicht abgerufen werden: {e}', xbmc.LOGWARNING)
    epg_offset = int(provider.get('epgOffset', 0) or 0)
    use_internal = int(provider.get('useInternalEpg', -1))
    if use_internal != 0:
        xmltv_url = _xtream_xmltv_url(provider)
        epg_urls = [xmltv_url] + build_epg_urls(provider)
        ku.log_debug(f'Xtream: nutze natives XMLTV-EPG: {xmltv_url}')
    else:
        epg_urls = build_epg_urls(provider)
    apply_epg(epg_db, pid, channels, epg_urls, epg_offset, progress_cb=progress_cb, label='Xtream')
    db.set_provider_synced(pid, line_expiry=expiry_ts)
    ku.log_debug(f'Xtream: {len(series_list)} Serien geladen, Sync abgeschlossen')
    cb(100, f'Fertig - {len(channels)} Kanaele, {len(movies)} Filme, {len(series_list)} Serien')


def fetch_xtream_episodes(db, provider, series_id):
    client = make_xtream(provider)
    info = client.get_series_info(series_id)
    episodes_by_season = info.get('episodes', {}) or {}
    episodes = []
    for season_num, eps in episodes_by_season.items():
        for e in eps:
            ext = e.get('container_extension', 'mp4') or 'mp4'
            info_obj = e.get('info', {}) or {}
            episodes.append({
                'id': str(e.get('id', '')),
                'title': e.get('title', ''),
                'overview': info_obj.get('plot', '') or '',
                'streamUrl': client.series_stream_url(e.get('id'), ext),
                'posterUrl': info_obj.get('movie_image', '') or '',
                'seasonNumber': int(e.get('season', season_num) or 0),
                'episodeNumber': int(e.get('episode_num', 0) or 0),
                'containerExt': ext,
            })
    db.insert_episodes(provider['id'], series_id, episodes)
    ku.log_debug(f'Xtream: {len(episodes)} Episoden geladen für series_id={series_id}')
    return episodes


def sync_stalker(db, epg_db, provider, tmdb_client=None, progress_cb=None):
    pid = provider['id']

    def cb(pct, msg):
        if progress_cb:
            progress_cb(pct, msg)

    cb(2, 'Verbindung wird hergestellt...')
    client = make_stalker(provider)
    ku.log_debug(f'Stalker: Verbindung hergestellt fuer provider_id={pid}')

    compat = dict(provider).get('stalkerCompatMode', -1)
    workers = MAX_WORKERS_RATELIMITED if compat == 1 else MAX_WORKERS
    ku.log_debug(f'Stalker sync: workers={workers} compat_mode={compat}')

    cb(8, 'Lade Kanal-Kategorien...')
    genres = client.get_genres()
    genre_map = {str(g.get('id')): g.get('title', 'Allgemein') for g in genres} if isinstance(genres, list) else {}

    cb(12, 'Lade alle Kanaele...')
    raw_channels = client.get_all_channels()
    channels = []
    for c in raw_channels:
        channels.append({
            'streamId': str(c.get('id', '')),
            'name': c.get('name', ''),
            'logoUrl': c.get('logo', '') or '',
            'streamUrl': c.get('cmd', '') or '',
            'categoryName': genre_map.get(str(c.get('tv_genre_id', '')), 'Allgemein'),
            'channelNumber': str(c.get('number', '')),
            'epgChannelId': str(c.get('xmltv_id', '') or ''),
            'tvArchive': 1 if str(c.get('tv_archive', 0)) == '1' else 0,
            'tvArchiveDuration': int(c.get('tv_archive_duration', 0) or 0),
        })
    db.insert_channels(pid, channels)
    ku.log_debug(f'Stalker: {len(channels)} Kanaele geladen')
    cb(18, f'Kanaele: {len(channels)} geladen')

    cb(20, 'Lade Film-Kategorien...')
    vod_cats = client.get_vod_categories()
    vod_cat_map = {str(c.get('id')): c.get('title', 'Allgemein') for c in vod_cats} if isinstance(vod_cats, list) else {}
    vod_cat_ids = [c.get('id') for c in vod_cats if c.get('id') not in (None, '*')] if isinstance(vod_cats, list) else []
    ku.log_debug(f'Stalker: {len(vod_cat_ids)} VOD-Kategorien gefunden')
    cb(22, f'Film-Kategorien: {len(vod_cat_ids)} gefunden - lade Inhalte...')

    done_vod = [0]
    total_vod = len(vod_cat_ids)

    def fetch_vod_cat(cid):
        result = client.get_all_vod(category_id=cid)
        done_vod[0] += 1
        pct = 22 + int((done_vod[0] / max(total_vod, 1)) * 28)
        cat_name = vod_cat_map.get(str(cid), str(cid))
        cb(pct, f'Filme: Kategorie {done_vod[0]}/{total_vod} - {cat_name}')
        return result

    vod_pages = parallel_map_safe(fetch_vod_cat, vod_cat_ids, max_workers=workers)
    raw_vod = []
    seen_vod_ids = set()
    for items in vod_pages:
        for item in items:
            item_id = item.get('id')
            if item_id in seen_vod_ids:
                continue
            seen_vod_ids.add(item_id)
            raw_vod.append(item)
    ku.log_debug(f'Stalker: {len(raw_vod)} Filme (dedupliziert) gefunden')
    cb(50, f'Filme: {len(raw_vod)} geladen - reichere Metadaten an...')

    metas = parallel_map(lambda v: enrich_movie(tmdb_client, v.get('name', ''), v.get('year') or ''), raw_vod)
    movies = []
    for v, meta in zip(raw_vod, metas):
        name = v.get('name', '')
        year = (v.get('year') or '')
        movies.append({
            'id': int(v.get('id', 0)) if str(v.get('id', '0')).isdigit() else abs(hash(v.get('id', ''))) % (10 ** 8),
            'streamId': str(v.get('id', '')),
            'name': name,
            'overview': meta.get('overview') or v.get('description', '') or '',
            'posterUrl': meta.get('posterUrl') or v.get('screenshot_uri', '') or '',
            'backdropUrl': meta.get('backdropUrl', ''),
            'releaseDate': str(year),
            'tmdbId': meta.get('tmdbId'),
            'rating': meta.get('rating') or 0,
            'streamUrl': v.get('cmd', '') or '',
            'categoryName': vod_cat_map.get(str(v.get('category_id', '')), 'Allgemein'),
            'containerExt': '',
        })
    db.insert_movies(pid, movies)
    cb(53, f'Filme: {len(movies)} gespeichert')

    cb(55, 'Lade Serien-Kategorien...')
    series_cats = client.get_series_categories()
    series_cat_map = {str(c.get('id')): c.get('title', 'Allgemein') for c in series_cats} if isinstance(series_cats, list) else {}
    series_cat_ids = [c.get('id') for c in series_cats if c.get('id') not in (None, '*')] if isinstance(series_cats, list) else []
    ku.log_debug(f'Stalker: {len(series_cat_ids)} Serien-Kategorien gefunden')
    cb(57, f'Serien-Kategorien: {len(series_cat_ids)} gefunden - lade Inhalte...')

    done_ser = [0]
    total_ser = len(series_cat_ids)

    def fetch_series_cat(cid):
        result = client.get_all_series(category_id=cid)
        done_ser[0] += 1
        pct = 57 + int((done_ser[0] / max(total_ser, 1)) * 33)
        cat_name = series_cat_map.get(str(cid), str(cid))
        cb(pct, f'Serien: Kategorie {done_ser[0]}/{total_ser} - {cat_name}')
        return result

    series_pages = parallel_map_safe(fetch_series_cat, series_cat_ids, max_workers=workers)
    raw_series = []
    seen_series_ids = set()
    for items in series_pages:
        for item in items:
            item_id = item.get('id')
            if item_id in seen_series_ids:
                continue
            seen_series_ids.add(item_id)
            raw_series.append(item)
    ku.log_debug(f'Stalker: {len(raw_series)} Serien gefunden')
    cb(90, f'Serien: {len(raw_series)} geladen - reichere Metadaten an...')

    series_metas = parallel_map(lambda s: enrich_series(tmdb_client, s.get('name', ''), s.get('year') or ''), raw_series)
    series_list = []
    for s, meta in zip(raw_series, series_metas):
        name = s.get('name', '')
        year = (s.get('year') or '')
        sid = s.get('id', 0)
        try:
            sid_int = int(sid)
        except (TypeError, ValueError):
            sid_int = abs(hash(str(sid))) % (10 ** 8)
        series_list.append({
            'id': sid_int,
            'streamId': str(s.get('id', '')),
            'name': name,
            'overview': meta.get('overview') or s.get('description', '') or '',
            'posterUrl': meta.get('posterUrl') or s.get('screenshot_uri', '') or '',
            'backdropUrl': meta.get('backdropUrl', ''),
            'releaseDate': str(year),
            'tmdbId': meta.get('tmdbId'),
            'rating': meta.get('rating') or 0,
            'categoryName': series_cat_map.get(str(s.get('category_id', '')), 'Allgemein'),
            'director': s.get('director', '') or '',
            'cast': s.get('actors', '') or '',
            'genre': s.get('genres_str', '') or '',
        })
    db.insert_series(pid, series_list)
    expiry_ts = 0
    try:
        expiry_ts = client.get_account_info()
        if expiry_ts:
            ku.log_debug(f'Stalker: Ablaufdatum ermittelt: {expiry_ts}')
    except Exception as e:
        ku.log(f'Stalker: Ablaufdatum konnte nicht abgerufen werden: {e}', xbmc.LOGWARNING)
    epg_offset = int(provider.get('epgOffset', 0) or 0)
    use_internal = int(provider.get('useInternalEpg', -1))
    if use_internal == 1:
        _apply_stalker_native_epg(epg_db, pid, channels, client, epg_offset, progress_cb=progress_cb)
    else:
        epg_urls = build_epg_urls(provider)
        apply_epg(epg_db, pid, channels, epg_urls, epg_offset, progress_cb=progress_cb, label='Stalker')
    db.set_provider_synced(pid, line_expiry=expiry_ts)
    ku.log_debug(f'Stalker: Sync abgeschlossen, {len(movies)} Filme, {len(series_list)} Serien')
    cb(100, f'Fertig - {len(channels)} Kanaele, {len(movies)} Filme, {len(series_list)} Serien')


def _stalker_season_number(item):
    raw = item.get('season_number')
    if raw not in (None, ''):
        try:
            return int(raw)
        except (TypeError, ValueError):
            pass
    season_id = str(item.get('id', ''))
    if ':' in season_id:
        tail = season_id.rsplit(':', 1)[-1]
        if tail.isdigit():
            return int(tail)
    return 1


def fetch_stalker_episodes(db, provider, series_id, stream_id):
    client = make_stalker(provider)
    seasons_data = client.get_series_seasons(stream_id)
    ku.log_debug(f'Stalker: {len(seasons_data)} Staffel-Einträge für series_id={series_id} geladen')
    episodes = []
    for item in seasons_data:
        season_id = str(item.get('id', ''))
        season_num = _stalker_season_number(item)
        series_field = item.get('series')
        if isinstance(series_field, list) and series_field:
            for ep_num in series_field:
                cmd = item.get('cmd', '') or ''
                episodes.append({
                    'id': f"{season_id}:{ep_num}",
                    'title': f"{item.get('name', '')} - Folge {ep_num}",
                    'overview': item.get('description', '') or '',
                    'streamUrl': f"{cmd}{EPISODE_CMD_SEP}{ep_num}" if cmd else '',
                    'posterUrl': item.get('screenshot_uri', '') or '',
                    'seasonNumber': season_num,
                    'episodeNumber': int(ep_num),
                    'containerExt': '',
                })
        else:
            episodes.append({
                'id': season_id,
                'title': item.get('name', ''),
                'overview': item.get('description', '') or '',
                'streamUrl': item.get('cmd', '') or '',
                'posterUrl': item.get('screenshot_uri', '') or '',
                'seasonNumber': season_num,
                'episodeNumber': int(item.get('episode_number', 1) or 1),
                'containerExt': '',
            })
    db.insert_episodes(provider['id'], series_id, episodes)
    ku.log_debug(f'Stalker: {len(episodes)} Episoden gespeichert für series_id={series_id}')
    return episodes


def sync_enigma2(db, provider, progress_cb=None):
    pid = provider['id']
    client = make_enigma2(provider)
    if progress_cb:
        progress_cb(10, 'Lade Enigma2 Bouquets...')
    bouquets = client.get_bouquets()
    ku.log_debug(f'Enigma2: {len(bouquets)} Bouquets gefunden')
    channels = []
    for b in bouquets:
        ch_list = client.get_channels(b['ref'])
        for c in ch_list:
            channels.append({
                'streamId': c['ref'],
                'name': c['name'],
                'logoUrl': '',
                'streamUrl': client.stream_url(c['ref']),
                'categoryName': b['name'],
                'channelNumber': '',
                'epgChannelId': '',
            })
    db.insert_channels(pid, channels)
    db.set_provider_synced(pid)
    ku.log_debug(f'Enigma2: Sync abgeschlossen, {len(channels)} Kanäle')
    if progress_cb:
        progress_cb(100, 'Fertig')


def sync_m3u(db, epg_db, provider, progress_cb=None):
    pid = provider['id']
    if progress_cb:
        progress_cb(10, 'Lade M3U Playlist...')
    ku.log_debug(f"M3U: Lade Playlist von {provider['m3uUrl']}")
    user_agent = provider.get('userAgent', '') or ku.get_setting('user_agent_global', '') or None
    read_timeout = ku.get_setting_int('read_timeout', 0) or 20
    content = M3uParser.fetch(provider['m3uUrl'], timeout=read_timeout, user_agent=user_agent)
    parsed = M3uParser.parse(content)
    channels = []
    for idx, c in enumerate(parsed):
        channels.append({
            'streamId': c.get('streamId', str(idx)),
            'name': c['name'],
            'logoUrl': c.get('logoUrl', ''),
            'streamUrl': c.get('streamUrl', ''),
            'categoryName': c.get('categoryName', 'Allgemein'),
            'channelNumber': c.get('channelNumber', ''),
            'epgChannelId': c.get('epgChannelId', ''),
            'tvArchive': c.get('tvArchive', 0),
            'tvArchiveDuration': c.get('tvArchiveDuration', 0),
            'catchupSource': c.get('catchupSource', ''),
        })
    db.insert_channels(pid, channels)
    ku.log_debug(f'M3U: {len(channels)} Kanäle geladen')

    epg_offset = int(provider.get('epgOffset', 0) or 0)
    use_internal = int(provider.get('useInternalEpg', -1))
    if use_internal == 1:
        playlist_epg_url = M3uParser.extract_epg_url(content)
        if playlist_epg_url:
            ku.log_debug(f'M3U: nutze EPG-URL aus Playlist-Header: {playlist_epg_url}')
            epg_urls = [playlist_epg_url] + build_epg_urls(provider)
        else:
            ku.log_debug('M3U: keine EPG-URL im Playlist-Header gefunden, nutze externe URLs')
            epg_urls = build_epg_urls(provider)
    else:
        epg_urls = build_epg_urls(provider)
    apply_epg(epg_db, pid, channels, epg_urls, epg_offset, progress_cb=progress_cb, label='M3U')
    db.set_provider_synced(pid)
    ku.log_debug('M3U: Sync abgeschlossen')
    if progress_cb:
        progress_cb(100, 'Fertig')


def jellyfin_people(item):
    people = item.get('People', []) or []
    director = next((p['Name'] for p in people if p.get('Type') == 'Director'), '')
    cast = ', '.join(p['Name'] for p in people if p.get('Type') == 'Actor')
    return director, cast


def sync_jellyfin(db, provider, tmdb_client=None, progress_cb=None):
    pid = provider['id']
    client = make_jellyfin(provider)
    if progress_cb:
        progress_cb(5, 'Jellyfin: Verbinde...')
    client.authenticate()
    ku.log_debug(f'Jellyfin: Authentifizierung erfolgreich für provider_id={pid}')

    if progress_cb:
        progress_cb(20, 'Lade Film-Kategorien...')
    movie_genres, movie_total = client.get_movie_genres()
    movie_cats = [(g, 0) for g in movie_genres]
    if not movie_genres:
        movie_cats = [('Allgemein', movie_total)]
    db.set_jellyfin_categories(pid, 'movie', movie_cats)
    ku.log_debug(f'Jellyfin: {len(movie_cats)} Film-Kategorien, {movie_total} Filme gesamt')

    if progress_cb:
        progress_cb(60, 'Lade Serien-Kategorien...')
    series_genres, series_total = client.get_series_genres()
    series_cats = [(g, 0) for g in series_genres]
    if not series_genres:
        series_cats = [('Allgemein', series_total)]
    db.set_jellyfin_categories(pid, 'series', series_cats)
    ku.log_debug(f'Jellyfin: {len(series_cats)} Serien-Kategorien, {series_total} Serien gesamt')

    db.set_provider_synced(pid)
    if progress_cb:
        progress_cb(100, f'Fertig - {len(movie_cats)} Film-Kategorien, {len(series_cats)} Serien-Kategorien')


def fetch_jellyfin_movies_for_category(db, provider, genre, progress_cb=None):
    pid = provider['id']
    client = make_jellyfin(provider)
    client.authenticate()

    def page_cb(loaded, total):
        if progress_cb:
            progress_cb(int((loaded / max(total, 1)) * 90), f'Filme: {loaded} / {total}...')

    raw_movies = client.get_movies_by_genre(genre=genre if genre != 'Allgemein' else None, page_cb=page_cb)

    movies = []
    for m in raw_movies:
        director, cast = jellyfin_people(m)
        genres = m.get('Genres', []) or []
        art = client.art_for_item(m)
        user_data = m.get('UserData', {}) or {}
        movies.append({
            'id': stable_id(m['Id']),
            'streamId': m['Id'],
            'name': m.get('Name', ''),
            'overview': m.get('Overview', '') or '',
            'posterUrl': art.get('poster') or art.get('thumb') or client.image_url(m['Id'], 'Primary'),
            'backdropUrl': art.get('fanart') or client.image_url(m['Id'], 'Backdrop'),
            'thumbUrl': art.get('thumb', ''),
            'bannerUrl': art.get('banner', ''),
            'clearlogoUrl': art.get('clearlogo', ''),
            'landscapeUrl': art.get('landscape', ''),
            'releaseDate': m.get('PremiereDate', '') or '',
            'tmdbId': None,
            'rating': m.get('CommunityRating', 0) or 0,
            'streamUrl': client.stream_url(m['Id']),
            'categoryName': genre,
            'director': director,
            'cast': cast,
            'genre': ', '.join(genres),
            'containerExt': 'mp4',
            'watched': user_data.get('Played', False),
            'resumePositionTicks': user_data.get('PlaybackPositionTicks', 0),
        })
    db.insert_movies(pid, movies, category=genre)
    if progress_cb:
        progress_cb(100, f'{len(movies)} Filme geladen')
    ku.log_debug(f'Jellyfin: {len(movies)} Filme für Kategorie "{genre}" geladen')
    return movies


def fetch_jellyfin_series_for_category(db, provider, genre, progress_cb=None):
    pid = provider['id']
    client = make_jellyfin(provider)
    client.authenticate()

    def page_cb(loaded, total):
        if progress_cb:
            progress_cb(int((loaded / max(total, 1)) * 90), f'Serien: {loaded} / {total}...')

    raw_series = client.get_series_by_genre(genre=genre if genre != 'Allgemein' else None, page_cb=page_cb)

    series_list = []
    for s in raw_series:
        director, cast = jellyfin_people(s)
        genres = s.get('Genres', []) or []
        art = client.art_for_item(s)
        user_data = s.get('UserData', {}) or {}
        series_list.append({
            'id': stable_id(s['Id']),
            'streamId': s['Id'],
            'name': s.get('Name', ''),
            'overview': s.get('Overview', '') or '',
            'posterUrl': art.get('poster') or art.get('thumb') or client.image_url(s['Id'], 'Primary'),
            'backdropUrl': art.get('fanart') or client.image_url(s['Id'], 'Backdrop'),
            'thumbUrl': art.get('thumb', ''),
            'bannerUrl': art.get('banner', ''),
            'clearlogoUrl': art.get('clearlogo', ''),
            'landscapeUrl': art.get('landscape', ''),
            'releaseDate': s.get('PremiereDate', '') or '',
            'tmdbId': None,
            'rating': s.get('CommunityRating', 0) or 0,
            'categoryName': genre,
            'director': director,
            'cast': cast,
            'genre': ', '.join(genres),
            'watched': user_data.get('Played', False),
        })
    db.insert_series(pid, series_list, category=genre)
    if progress_cb:
        progress_cb(100, f'{len(series_list)} Serien geladen')
    ku.log_debug(f'Jellyfin: {len(series_list)} Serien für Kategorie "{genre}" geladen')
    return series_list


def fetch_jellyfin_episodes(db, provider, series_id, stream_id):
    client = make_jellyfin(provider)
    client.authenticate()
    episodes = []
    for season in client.get_seasons(stream_id):
        season_num = season.get('IndexNumber', 0) or 0
        for ep in client.get_episodes(stream_id, season.get('Id')):
            art = client.art_for_item(ep)
            user_data = ep.get('UserData', {}) or {}
            episodes.append({
                'id': stable_id(ep['Id']),
                'streamId': ep['Id'],
                'title': ep.get('Name', ''),
                'overview': ep.get('Overview', '') or '',
                'streamUrl': client.stream_url(ep['Id']),
                'posterUrl': art.get('thumb') or client.image_url(ep['Id'], 'Primary'),
                'backdropUrl': art.get('tvshow.fanart') or art.get('fanart', ''),
                'seasonNumber': season_num,
                'episodeNumber': ep.get('IndexNumber', 0) or 0,
                'containerExt': 'mp4',
                'watched': user_data.get('Played', False),
                'resumePositionTicks': user_data.get('PlaybackPositionTicks', 0),
            })
    db.insert_episodes(provider['id'], series_id, episodes)
    ku.log_debug(f'Jellyfin: {len(episodes)} Episoden geladen für series_id={series_id}')
    return episodes


def sync_vavoo(db, epg_db, provider, progress_cb=None):
    from resources.lib.vavoo import VavooClient
    pid = provider['id']
    portal_url = provider['serverUrl']
    if progress_cb:
        progress_cb(5, 'Vavoo: Verbinde mit Portal...')
    ku.log_debug(f'Vavoo sync: Portal={portal_url}')
    client = VavooClient(portal_url, log_func=ku.log_debug)
    if progress_cb:
        progress_cb(15, 'Vavoo: Lade Kanalliste...')
    try:
        items = client.get_all_channels(adult=True)
    except Exception as e:
        ku.log(f'Vavoo sync_vavoo fehlgeschlagen: {e}')
        raise
    ku.log_debug(f'Vavoo: {len(items)} Kanäle geladen')
    if progress_cb:
        progress_cb(60, f'Vavoo: {len(items)} Kanäle gefunden, speichere...')
    channels = []
    for item in items:
        item_id = (item.get('ids') or {}).get('id', '')
        if not item_id:
            continue
        name = item.get('name', '').strip()
        group = item.get('group', '') or ''
        logo = item.get('logo', '') or ''
        stream_url = item.get('url', '') or client.resolve_stream_url(item_id)
        channels.append({
            'id': item_id,
            'name': name,
            'categoryName': group,
            'logoUrl': logo,
            'streamUrl': stream_url,
            'epgChannelId': '',
            'catchupSource': '',
        })
    db.insert_channels(pid, channels)
    if progress_cb:
        progress_cb(85, 'Vavoo: Kanäle gespeichert')
    epg_urls = build_epg_urls(provider)
    if epg_urls:
        apply_epg(epg_db, pid, [], epg_urls, int(provider.get('epgOffset', 0) or 0),
                  progress_cb=progress_cb, label='Vavoo')
    if progress_cb:
        progress_cb(100, f'Vavoo: {len(channels)} Kanäle synchronisiert')


def sync_provider(db, epg_db, provider, tmdb_client=None, progress_cb=None):
    ptype = provider['type']
    ku.log_debug(f"sync_provider start: id={provider['id']} name={provider['name']} type={ptype}")
    if ptype == 'xtream':
        sync_xtream(db, epg_db, provider, tmdb_client, progress_cb)
    elif ptype == 'stalker':
        sync_stalker(db, epg_db, provider, tmdb_client, progress_cb)
    elif ptype == 'enigma2':
        sync_enigma2(db, provider, progress_cb)
    elif ptype == 'm3u':
        sync_m3u(db, epg_db, provider, progress_cb)
    elif ptype == 'vavoo':
        sync_vavoo(db, epg_db, provider, progress_cb)
    elif ptype == 'jellyfin':
        sync_jellyfin(db, provider, tmdb_client, progress_cb)
    else:
        ku.log(f'Unbekannter Provider-Typ: {ptype}', xbmc.LOGERROR)
        raise ValueError(f'Unbekannter Provider-Typ: {ptype}')
    ku.log_debug(f"sync_provider done: id={provider['id']} name={provider['name']} type={ptype}")


def sync_epg_only(db, epg_db, provider, progress_cb=None):
    pid = provider['id']
    ptype = provider['type']
    epg_offset = int(provider.get('epgOffset', 0) or 0)
    use_internal = int(provider.get('useInternalEpg', -1))

    if progress_cb:
        progress_cb(5, 'EPG: lösche alte Einträge...')
    epg_db.clear_epg_for_provider(pid)

    if ptype == 'stalker':
        if use_internal == 1:
            client = make_stalker(provider)
            channels = list(db.get_channels([pid]))
            ch_dicts = [dict(c) for c in channels]
            _apply_stalker_native_epg(epg_db, pid, ch_dicts, client, epg_offset, progress_cb=progress_cb)
        else:
            epg_urls = build_epg_urls(provider)
            apply_epg(epg_db, pid, [], epg_urls, epg_offset, progress_cb=progress_cb, label='Stalker')

    elif ptype == 'xtream':
        if use_internal != 0:
            xmltv_url = _xtream_xmltv_url(provider)
            epg_urls = [xmltv_url] + build_epg_urls(provider)
        else:
            epg_urls = build_epg_urls(provider)
        apply_epg(epg_db, pid, [], epg_urls, epg_offset, progress_cb=progress_cb, label='Xtream')

    elif ptype == 'm3u':
        if use_internal == 1:
            user_agent = provider.get('userAgent', '') or ku.get_setting('user_agent_global', '') or None
            read_timeout = ku.get_setting_int('read_timeout', 0) or 20
            content = M3uParser.fetch(provider['m3uUrl'], timeout=read_timeout, user_agent=user_agent)
            playlist_epg_url = M3uParser.extract_epg_url(content)
            epg_urls = ([playlist_epg_url] if playlist_epg_url else []) + build_epg_urls(provider)
        else:
            epg_urls = build_epg_urls(provider)
        apply_epg(epg_db, pid, [], epg_urls, epg_offset, progress_cb=progress_cb, label='M3U')

    elif ptype == 'vavoo':
        epg_urls = build_epg_urls(provider)
        apply_epg(epg_db, pid, [], epg_urls, epg_offset, progress_cb=progress_cb, label='Vavoo')

    else:
        ku.log_debug(f'sync_epg_only: Typ {ptype} hat keine EPG-Unterstützung')
        if progress_cb:
            progress_cb(100, 'Kein EPG verfügbar für diesen Anbieter-Typ')
        return

    if progress_cb:
        progress_cb(100, 'EPG aktualisiert')
