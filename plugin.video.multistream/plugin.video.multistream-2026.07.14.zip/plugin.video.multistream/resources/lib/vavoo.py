import json
import time

from resources.lib import http_client, kodi_utils as ku

VAVOO_UA = 'TiviMate/5.0.0 (Linux; Google TV)'

_KNOWN_PORTALS = {
    'oha.to':   {'prefix': '/mediaurl-',   'region': 'DE', 'discovery': '/mediaurl.json'},
    'huhu.to':  {'prefix': '/mediaurl-',   'region': 'DE', 'discovery': '/mediaurl.json'},
    'kool.to':  {'prefix': '/mediahubmx-', 'region': 'AT', 'discovery': '/mediahubmx.json'},
    'vavoo.to': {'prefix': '/mediahubmx-', 'region': 'XX', 'discovery': '/mediahubmx.json'},
    'vavoo.top':{'prefix': '/mediahubmx-', 'region': 'XX', 'discovery': '/mediahubmx.json'},
    'vavoo.net':{'prefix': '/mediahubmx-', 'region': 'XX', 'discovery': '/mediahubmx.json'},
}

MOVIE_CATALOGS = [
    ('Trending Heute',  'tmdb.movie', 'movie/trending', 'trendingDay',  None),
    ('Trending Woche',  'tmdb.movie', 'movie/trending', 'trendingWeek', None),
    ('Beliebt',         'tmdb.movie', 'movie/popular',  'popularity',   None),
    ('A-Z',             'tmdb.movie', 'movie/popular',  'popularity',   'alpha'),
    ('Nach Jahr',       'tmdb.movie', 'movie/trending', 'trendingDay',  'year'),
    ('Genre',           'tmdb.movie', 'movie/trending', 'trendingDay',  'genre'),
]
SERIES_CATALOGS = [
    ('Trending Heute',  'tmdb.series', 'series/trending', 'trendingDay',  None),
    ('Trending Woche',  'tmdb.series', 'series/trending', 'trendingWeek', None),
    ('Beliebt',         'tmdb.series', 'series/popular',  'popularity',   None),
    ('A-Z',             'tmdb.series', 'series/popular',  'popularity',   'alpha'),
    ('Nach Jahr',       'tmdb.series', 'series/trending', 'trendingDay',  'year'),
    ('Genre',           'tmdb.series', 'series/trending', 'trendingDay',  'genre'),
]

MOVIE_GENRES = [
    'Action', 'Abenteuer', 'Animation', 'Komödie', 'Krimi', 'Dokumentation',
    'Drama', 'Familie', 'Fantasy', 'History', 'Horror', 'Musik', 'Mystery',
    'Romantik', 'Sci-Fi', 'Thriller', 'Kriegsfilm', 'Western',
]
SERIES_GENRES = [
    'Action & Abenteuer', 'Animation', 'Komödie', 'Krimi', 'Dokumentation',
    'Drama', 'Familie', 'Kids', 'Mystery', 'News', 'Reality',
    'Sci-Fi & Fantasy', 'Soap', 'Talk', 'War & Politics', 'Western',
]

YEARS = [str(y) for y in range(2026, 1979, -1)]


def _normalise_url(url):
    url = url.strip().rstrip('/')
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    return url


def _detect_portal(base_url, session, timeout):
    for domain, cfg in _KNOWN_PORTALS.items():
        if domain in base_url:
            return cfg['prefix'], cfg['region'], cfg['discovery']
    for discovery, prefix, region in [
        ('/mediaurl.json',   '/mediaurl-',   'DE'),
        ('/mediahubmx.json', '/mediahubmx-', 'DE'),
    ]:
        try:
            r = session.post(
                base_url + discovery,
                data='{}',
                headers={'Content-Type': 'application/json', 'User-Agent': VAVOO_UA},
                timeout=timeout,
            )
            if r.status_code == 200 and 'catalogs' in r.text:
                return prefix, region, discovery
        except Exception:
            pass
    return '/mediaurl-', 'DE', '/mediaurl.json'


class VavooClient:
    def __init__(self, portal_url, log_func=None, timeout=20):
        self._base = _normalise_url(portal_url)
        self._timeout = timeout
        self._log = log_func or (lambda m: None)
        self._session = http_client.new_session()
        self._prefix, self._region, self._discovery = _detect_portal(
            self._base, self._session, timeout
        )
        self._log(f'Vavoo portal={self._base} prefix={self._prefix} region={self._region}')

    def _path(self, name):
        return self._base + self._prefix + name + '.json'

    def _headers(self):
        return {
            'User-Agent': VAVOO_UA,
            'Accept': 'application/json',
            'Accept-Charset': 'UTF-8',
            'Content-Type': 'application/json',
        }

    def _post(self, url, payload):
        url_t = url + f'?_t={int(time.time() * 1000)}'
        r = self._session.post(
            url_t,
            data=json.dumps(payload, separators=(',', ':')),
            headers=self._headers(),
            timeout=self._timeout,
        )
        r.raise_for_status()
        return r.json()

    def test_connection(self):
        payload = {
            'language': 'de', 'region': self._region,
            'catalogId': 'iptv', 'id': '',
            'adult': True, 'search': '',
            'sort': 'trending-region',
            'filter': {}, 'cursor': None,
            'clientVersion': '3.1.0',
        }
        data = self._post(self._path('catalog'), payload)
        return isinstance(data, dict) and 'items' in data

    def get_all_channels(self, adult=True):
        channels = []
        cursor = None
        page = 0
        while True:
            payload = {
                'language': 'de', 'region': self._region,
                'catalogId': 'iptv', 'id': '',
                'adult': adult, 'search': '',
                'sort': 'trending-region',
                'filter': {}, 'cursor': cursor,
                'clientVersion': '3.1.0',
            }
            try:
                data = self._post(self._path('catalog'), payload)
            except Exception as e:
                self._log(f'Vavoo get_all_channels Fehler (page={page}): {e}')
                break
            items = data.get('items') or []
            channels.extend(items)
            cursor = data.get('nextCursor')
            self._log(f'Vavoo page={page} items={len(items)} nextCursor={cursor}')
            page += 1
            if not cursor or not items:
                break
        return channels

    def get_catalog_page(self, catalog_id, cat_id, sort, cursor=None, adult=False,
                         genre_name=None, year=None):
        filt = {}
        if genre_name:
            filt['genre'] = [genre_name]
        if year:
            filt['year'] = [str(year)]
        payload = {
            'language': 'de', 'region': self._region,
            'catalogId': catalog_id,
            'id': cat_id or '',
            'adult': adult,
            'search': '',
            'sort': sort or 'popularity',
            'filter': filt,
            'cursor': cursor,
            'clientVersion': '3.1.0',
        }
        return self._post(self._path('catalog'), payload)

    def get_sources(self, item_type, ids, name, name_translations=None,
                    original_name=None, release_date=None):
        payload = {
            'language': 'de', 'region': self._region,
            'type': item_type,
            'ids': ids,
            'name': name,
            'nameTranslations': name_translations or {},
            'episode': {},
            'clientVersion': '3.1.0',
        }
        if original_name:
            payload['originalName'] = original_name
        if release_date:
            payload['releaseDate'] = release_date
        return self._post(self._path('source'), payload)

    def get_episode_sources(self, item_type, ids, name, season, episode,
                            name_translations=None, original_name=None, release_date=None):
        payload = {
            'language': 'de', 'region': self._region,
            'type': item_type,
            'ids': ids,
            'name': name,
            'nameTranslations': name_translations or {},
            'episode': {'season': season, 'episode': episode},
            'clientVersion': '3.1.0',
        }
        if original_name:
            payload['originalName'] = original_name
        if release_date:
            payload['releaseDate'] = release_date
        return self._post(self._path('source'), payload)

    def _resolve_task_request(self, task_id, task_data):
        fetch_url = task_data.get('url', '')
        params = task_data.get('params', {})
        method = params.get('method', 'GET').upper()
        headers = params.get('headers', {})
        try:
            r = self._session.request(method, fetch_url, headers=headers, timeout=self._timeout)
            response_payload = {
                'kind': 'taskResponse',
                'id': task_id,
                'data': {'text': r.text, 'status': r.status_code},
            }
        except Exception as e:
            response_payload = {
                'kind': 'taskResponse',
                'id': task_id,
                'data': {'error': str(e)},
            }
        return self._post(self._path('resolve'), response_payload)

    def resolve_stream_url(self, play_url):
        payload = {
            'language': 'de',
            'region': self._region,
            'url': play_url,
            'clientVersion': '3.1.0',
        }
        self._log(f'Vavoo resolve: {play_url}')
        data = self._post(self._path('resolve'), payload)
        for _ in range(5):
            if isinstance(data, list) and data:
                resolved = data[0].get('url', '')
                self._log(f'Vavoo resolved -> {resolved}')
                return resolved
            if isinstance(data, dict) and data.get('url'):
                resolved = data['url']
                self._log(f'Vavoo resolved (dict) -> {resolved}')
                return resolved
            if isinstance(data, dict) and data.get('kind') == 'taskRequest':
                task_id = data.get('id', '')
                task_data = data.get('data', {})
                self._log(f'Vavoo taskRequest id={task_id} url={task_data.get("url","")}')
                data = self._resolve_task_request(task_id, task_data)
                continue
            break
        raise ValueError(f'Vavoo resolve fehlgeschlagen für {play_url}')
