# -*- coding: utf-8 -*-
import json
import hashlib
import random
import re
import threading
import time
from urllib.parse import unquote

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_USER_AGENT = (
    'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 '
    '(KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3'
)

_TG_CHANNEL_DEFAULT = 'StbEmucodesStalkerPortal'
_TG_MAX_PAGES = 30

_MAC_RE = re.compile(r'(?:(?:mac\s*(?:addr(?:ess)?\s*)?[=:\s"\'+]+)|(?<![0-9A-Fa-f:]))([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})(?![0-9A-Fa-f:])', re.IGNORECASE)
_URL_RE = re.compile(
    r'(https?://[^\s\'"<>,;]+?(?:portal\.php|/c/?))',
    re.IGNORECASE,
)
_URL_BARE_RE = re.compile(
    r'(https?://[0-9A-Za-z._:\-]+(?::\d+)?(?:/[^\s\'"<>,;]*)?)',
    re.IGNORECASE,
)
_CDN_RE = re.compile(
    r'https?://cdn\d*\.telesco\.pe/file/[A-Za-z0-9_\-]+',
    re.IGNORECASE,
)
_DOC_TIMESTAMP_RE = re.compile(r'-\d{8,12}$')
_XTREAM_RE = re.compile(
    r'https?://[^\s\'"<>,;]+/get\.php\?[^\s\'"<>]*username=[^&\s\'"<>]+[^\s\'"<>]*password=[^&\s\'"<>]+',
    re.IGNORECASE,
)


class HunterClient:

    def __init__(self, portal_url='', mac='', log_func=None, debug=False, tg_channel=''):
        self.portal_url = portal_url.rstrip('/') if portal_url else ''
        self.mac = mac or ''
        self._log = log_func or (lambda msg: None)
        self._debug = debug
        self._session = requests.Session()
        self._session.verify = False
        self._token = None
        tg_ch = (tg_channel or '').strip().lstrip('@') or _TG_CHANNEL_DEFAULT
        self._tg_base = f'https://t.me/s/{tg_ch}'

    def _dbg(self, msg):
        if self._debug:
            self._log(f'[DBG] {msg}')

    def _api_url(self, base=None):
        base = (base or self.portal_url).rstrip('/')
        if base.endswith('/portal.php'):
            return base
        return base + '/portal.php'

    def _headers(self, base=None):
        base = base or self.portal_url
        hostname = base.split('//')[-1].split('/')[0].split(':')[0]
        h = {
            'User-Agent': _USER_AGENT,
            'X-User-Agent': 'Model: MAG254; Link: Ethernet',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Referer': base + '/c/',
            'Connection': 'Keep-Alive',
            'Host': hostname,
            'X-Requested-With': 'XMLHttpRequest',
        }
        if self._token:
            h['Authorization'] = 'Bearer ' + self._token
        return h

    def _cookies(self, mac=None):
        return {
            'mac': mac or self.mac,
            'stb_lang': 'en',
            'timezone': 'Europe%2FBerlin',
        }

    def _calc_device_strings(self, mac):
        sn = hashlib.md5(mac.encode('utf-8')).hexdigest().upper()[13:]
        device_id = hashlib.sha256(sn.encode('utf-8')).hexdigest().upper()
        device_id2 = hashlib.sha256(mac.encode('utf-8')).hexdigest().upper()
        signature = hashlib.sha256((sn + mac).encode('utf-8')).hexdigest().upper()
        return sn, device_id, device_id2, signature

    def _handshake(self, mac, base=None):
        url = self._api_url(base)
        self._dbg(f'handshake: {url} MAC={mac}')
        try:
            r = self._session.get(
                url,
                headers=self._headers(base),
                cookies={'mac': mac, 'stb_lang': 'en', 'timezone': 'Europe%2FBerlin'},
                params={'type': 'stb', 'action': 'handshake', 'JsHttpRequest': '1-xml'},
                timeout=3,
            )
            self._dbg(f'handshake response: HTTP {r.status_code} len={len(r.text)} body={r.text[:200]}')
            if r.status_code != 200:
                return None
            data = r.json()
            token = data.get('js', {}).get('token') if isinstance(data.get('js'), dict) else None
            self._dbg(f'handshake token: {token[:20] + "..." if token and len(token) > 20 else token}')
            return token
        except Exception as e:
            self._dbg(f'handshake exception: {e}')
            return None

    def _check_mac(self, mac, base=None):
        token = self._handshake(mac, base)
        if not token:
            self._dbg(f'check_mac: kein Token fuer MAC={mac} base={base}')
            return False
        sn, device_id, device_id2, signature = self._calc_device_strings(mac)
        cookies = {'mac': mac, 'stb_lang': 'en', 'timezone': 'Europe%2FBerlin'}
        headers = self._headers(base)
        headers['Authorization'] = 'Bearer ' + token
        api = self._api_url(base)
        try:
            self._session.get(
                api,
                headers=headers,
                cookies=cookies,
                params={
                    'type': 'stb', 'action': 'get_profile', 'hd': '1',
                    'num_banks': '1', 'stb_type': 'MAG254',
                    'sn': sn, 'device_id': device_id, 'device_id2': device_id2,
                    'signature': signature, 'JsHttpRequest': '1-xml',
                },
                timeout=3,
            )
            r = self._session.get(
                api,
                headers=headers,
                cookies=cookies,
                params={'type': 'account_info', 'action': 'get_main_info', 'JsHttpRequest': '1-xml'},
                timeout=3,
            )
            self._dbg(f'check_mac account_info: HTTP {r.status_code} body={r.text[:300]}')
            if r.status_code != 200 or 'expired' in r.text.lower():
                return False
            rc = self._session.get(
                api,
                headers=headers,
                cookies=cookies,
                params={
                    'type': 'itv', 'action': 'get_all_channels',
                    'genre': '*', 'force_ch_link_check': '', 'fav': '0',
                    'sortby': 'number', 'p': '1', 'JsHttpRequest': '1-xml',
                },
                timeout=4,
            )
            if rc.status_code == 200:
                try:
                    js = rc.json().get('js', {})
                    if isinstance(js, list):
                        total = len(js)
                    elif isinstance(js, dict):
                        total = int(js.get('total_items', len(js.get('data', []))))
                    else:
                        total = 0
                    self._dbg(f'check_mac channels total={total}')
                    if total > 0:
                        return True
                except Exception:
                    pass
            return False
        except Exception as e:
            self._dbg(f'check_mac exception: {e}')
        return False

    def _fetch_raw(self, url):
        self._dbg(f'fetch_raw: {url}')
        try:
            r = requests.get(url, timeout=4, headers={'User-Agent': 'Mozilla/5.0'})
            self._dbg(f'fetch_raw response: HTTP {r.status_code} len={len(r.text)}')
            if r.status_code == 200:
                return r.text
        except Exception as e:
            self._dbg(f'fetch_raw exception: {e}')
        return ''

    def _portal_from_filename(self, name):
        base = re.sub(r'\.(txt|m3u8?|lst|conf|csv)$', '', name, flags=re.IGNORECASE)
        base = _DOC_TIMESTAMP_RE.sub('', base)
        parts = base.rsplit('.', 1)
        if len(parts) == 2:
            host, port = parts
            if port.isdigit() and 1 <= int(port) <= 65535 and host:
                return f'http://{host}:{port}'
        return ''

    def _fetch_tg_file(self, file_url):
        self._dbg(f'fetch_tg_file: {file_url}')
        if 't.me/' in file_url and 'cdn' not in file_url.lower():
            try:
                r = requests.get(
                    file_url,
                    timeout=8,
                    headers={
                        'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36',
                        'Accept': 'text/html,application/xhtml+xml,*/*',
                    },
                    allow_redirects=True,
                )
                self._dbg(f'fetch_tg_file single-page: HTTP {r.status_code} len={len(r.text)}')
                if r.status_code == 200:
                    m = _CDN_RE.search(r.text)
                    if m:
                        cdn_url = m.group(0)
                        self._dbg(f'fetch_tg_file: CDN-URL gefunden: {cdn_url}')
                        return self._fetch_raw(cdn_url)
            except Exception as e:
                self._dbg(f'fetch_tg_file single-page exception: {e}')
            return ''
        try:
            r = requests.get(
                file_url,
                timeout=10,
                headers={
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36',
                    'Accept': 'text/plain,*/*',
                },
                allow_redirects=True,
            )
            self._dbg(f'fetch_tg_file response: HTTP {r.status_code} len={len(r.text)}')
            if r.status_code == 200:
                ct = r.headers.get('Content-Type', '')
                if 'text' in ct or 'json' in ct or not ct:
                    return r.text
                try:
                    return r.content.decode('utf-8', errors='replace')
                except Exception:
                    pass
        except Exception as e:
            self._dbg(f'fetch_tg_file exception: {e}')
        return ''

    def _extract_pairs(self, text, source=''):
        pairs = []
        macs = _MAC_RE.findall(text)
        urls = _URL_RE.findall(text) or _URL_BARE_RE.findall(text)
        self._dbg(f'extract_pairs {source}: {len(macs)} MACs={macs[:5]} {len(urls)} URLs={urls[:5]}')
        if not macs or not urls:
            return pairs
        for mac in macs:
            mac_norm = mac.upper()
            for url in urls:
                base = url.rstrip('/')
                if base.endswith('/portal.php'):
                    base = base[:-len('/portal.php')]
                if base.endswith('/c'):
                    base = base[:-2]
                pairs.append((base, mac_norm))
        self._dbg(f'extract_pairs {source}: {len(pairs)} Paare -> {pairs[:3]}')
        return pairs

    def _tg_fetch_page(self, before_id=None):
        url = self._tg_base if before_id is None else f'{self._tg_base}?before={before_id}'
        self._dbg(f'tg_fetch_page: {url} ({"POST" if before_id else "GET"})')
        headers = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36',
            'Accept': 'text/html,application/xhtml+xml,*/*',
            'Accept-Language': 'de-DE,de;q=0.9',
        }
        try:
            r = requests.get(url, headers=headers, timeout=6)
            self._dbg(f'tg_fetch_page response: HTTP {r.status_code} len={len(r.text)}')
            if r.status_code == 200:
                text = r.text
                ct = r.headers.get('Content-Type', '')
                if 'json' in ct or (text.lstrip().startswith('"') and text.rstrip().endswith('"')):
                    try:
                        decoded = json.loads(text)
                        if isinstance(decoded, str):
                            text = decoded
                    except Exception:
                        text = text.replace('\\"', '"').replace('\\/', '/').replace('\\n', '\n').replace('\\t', '\t')
                        if text.startswith('"') and text.endswith('"'):
                            text = text[1:-1]
                self._dbg(f'tg_fetch_page decoded len={len(text)}')
                return text
        except Exception as e:
            self._dbg(f'tg_fetch_page exception: {e}')
        return ''

    def _tg_extract_doc_urls(self, block):
        wrap_re = re.compile(
            r'<a[^>]+class=["\']tgme_widget_message_document_wrap["\'][^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            re.DOTALL | re.IGNORECASE,
        )
        title_re = re.compile(r'tgme_widget_message_document_title[^>]*>(.*?)<', re.DOTALL)
        results = []
        for m in wrap_re.finditer(block):
            href = m.group(1)
            content = m.group(2)
            tm = title_re.search(content)
            title = re.sub(r'<[^>]+>', '', tm.group(1)).strip() if tm else ''
            if href:
                results.append((href, title))
        return results

    def _tg_extract_messages(self, html):
        block_re = re.compile(
            r'<div class="tgme_widget_message\b[^"]*"[^>]*data-post="[^/]+/(\d+)"[^>]*>(.*?)'
            r'(?=<div class="tgme_widget_message\b|$)',
            re.DOTALL,
        )
        text_re = re.compile(
            r'<div class="tgme_widget_message_text[^"]*"[^>]*>(.*?)</div>\s*</div>',
            re.DOTALL,
        )
        text_re_fallback = re.compile(
            r'<div class="tgme_widget_message_text[^"]*"[^>]*>(.*?)</div>',
            re.DOTALL,
        )
        href_re = re.compile(r'href="([^"]+)"', re.IGNORECASE)
        _DOC_EXTS = {'txt', 'csv', 'm3u', 'm3u8', 'lst', 'conf'}

        results = []
        for bm in block_re.finditer(html):
            msg_id = int(bm.group(1))
            block = bm.group(2)

            tm = text_re.search(block) or text_re_fallback.search(block)
            if tm:
                raw = tm.group(1)
                hrefs = href_re.findall(raw)
                text = re.sub(r'<br\s*/?>', '\n', raw)
                text = re.sub(r'<[^>]+>', ' ', text).strip()
                text = re.sub(r' +', ' ', text)
                text = (text
                    .replace('&amp;', '&')
                    .replace('&lt;', '<')
                    .replace('&gt;', '>')
                    .replace('&quot;', '"')
                    .replace('&#39;', "'"))
                for href in hrefs:
                    if href.startswith('http'):
                        full = href.strip()
                        if full not in text:
                            text = full + '\n' + text
                if text:
                    results.append((msg_id, text))

            doc_pairs = self._tg_extract_doc_urls(block)
            for doc_href, doc_title in doc_pairs:
                ext = doc_title.rsplit('.', 1)[-1].lower() if '.' in doc_title else ''
                if ext not in _DOC_EXTS:
                    self._dbg(f'tg_extract_messages: Anhang {doc_title!r} übersprungen')
                    continue
                self._dbg(f'tg_extract_messages: Datei-Anhang Msg {msg_id}: {doc_href} title={doc_title!r}')
                portal_from_name = self._portal_from_filename(doc_title)
                file_text = self._fetch_tg_file(doc_href)
                if file_text:
                    combined = (portal_from_name + '\n' + file_text) if portal_from_name else file_text
                    results.append((msg_id, combined))
                elif portal_from_name:
                    self._dbg(f'tg_extract_messages: nur Portal aus Dateiname: {portal_from_name}')
                    results.append((msg_id, portal_from_name))

        return results

    def _tg_window_pairs(self, messages, window=5):
        pairs = []
        texts = [t for _, t in messages]
        seen = set()
        for i, (msg_id, text) in enumerate(messages):
            xtream_urls = _XTREAM_RE.findall(text)
            for xurl in xtream_urls:
                key = (xurl, '')
                if key not in seen:
                    seen.add(key)
                    pairs.append(key)

            macs = _MAC_RE.findall(text)
            raw_urls = _URL_RE.findall(text) or _URL_BARE_RE.findall(text)
            urls = [u for u in raw_urls if 'get.php' not in u]

            if not macs:
                start = max(0, i - window)
                end = min(len(texts), i + window + 1)
                for j in range(start, end):
                    if j == i:
                        continue
                    macs += _MAC_RE.findall(texts[j])

            if not urls:
                start = max(0, i - window)
                end = min(len(texts), i + window + 1)
                for j in range(start, end):
                    if j == i:
                        continue
                    candidate = _URL_RE.findall(texts[j]) or _URL_BARE_RE.findall(texts[j])
                    urls += [u for u in candidate if 'get.php' not in u]

            if not macs or not urls:
                continue

            for mac in macs:
                mac_norm = mac.upper()
                for url in urls:
                    base = url.rstrip('/')
                    if base.endswith('/portal.php'):
                        base = base[:-len('/portal.php')]
                    if base.endswith('/c'):
                        base = base[:-2]
                    key = (base, mac_norm)
                    if key not in seen:
                        seen.add(key)
                        pairs.append(key)

        self._dbg(f'tg_window_pairs: {len(pairs)} Paare')
        return pairs

    def collect_telegram_candidates(self, max_results=9999, progress_cb=None):
        self._log('Telegram Hunter Modus: sammle Kandidaten...')
        seen_ids = set()
        seen_pairs = set()
        candidates = []
        before_id = None
        all_messages = []

        try:
            for page in range(_TG_MAX_PAGES):
                if progress_cb:
                    pct = int((page / _TG_MAX_PAGES) * 90)
                    progress_cb(pct, f'Telegram Hunter Modus: Seite {page + 1} wird geladen...')
                html = self._tg_fetch_page(before_id)
                if not html:
                    break

                messages = self._tg_extract_messages(html)
                self._dbg(f'tg page {page+1}: {len(messages)} Nachrichten')

                new_this_page = 0
                for msg_id, text in messages:
                    if msg_id not in seen_ids:
                        seen_ids.add(msg_id)
                        all_messages.append((msg_id, text))
                        new_this_page += 1

                m_before = re.search(r'data-before="(\d+)"', html)
                if not m_before:
                    break
                next_before = int(m_before.group(1))
                if next_before <= 1 or next_before == before_id:
                    break
                before_id = next_before
                time.sleep(0.5)
        except InterruptedError:
            self._log(f'Telegram Hunter Modus: Abgebrochen nach {len(all_messages)} Nachrichten – zeige bisherige Kandidaten')

        if progress_cb:
            try:
                progress_cb(95, 'Telegram Hunter Modus: analysiere Nachrichten...')
            except InterruptedError:
                pass

        for url, mac in self._tg_window_pairs(all_messages):
            if url.startswith('https://t.me/') and '/s/' not in url:
                continue
            key = (url, mac)
            if key not in seen_pairs:
                seen_pairs.add(key)
                candidates.append(key)

        self._log(f'Telegram Hunter Modus: {len(candidates)} Kandidaten gesammelt')
        self._dbg(f'Kandidaten gesamt: {candidates}')
        return candidates

    def _check_xtream(self, get_php_url):
        from urllib.parse import urlparse, parse_qs
        url_clean = get_php_url.replace('&amp;', '&').replace('&amp', '&')
        parsed = urlparse(url_clean)
        qs = parse_qs(parsed.query, keep_blank_values=True)
        username = (qs.get('username') or [''])[0]
        password = (qs.get('password') or [''])[0]
        if not username or not password:
            self._dbg(f'check_xtream: kein username/password in {url_clean}')
            return False
        base = f'{parsed.scheme}://{parsed.netloc}'
        api_url = f'{base}/player_api.php?username={username}&password={password}'
        self._dbg(f'check_xtream: {api_url}')
        try:
            r = requests.get(
                api_url,
                timeout=8,
                headers={'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36'},
                allow_redirects=True,
            )
            self._dbg(f'check_xtream: HTTP {r.status_code} len={len(r.text)}')
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, dict) and data.get('user_info', {}).get('status') == 'Active':
                    self._log(f'Xtream: Treffer {base} user={username}')
                    self.portal_url = base
                    self._xtream_username = username
                    self._xtream_password = password
                    return True
        except Exception as e:
            self._dbg(f'check_xtream exception: {e}')
        return False

    def check_candidate(self, base_url, mac):
        if 'get.php' in base_url:
            return self._check_xtream(base_url)
        return self._check_mac(mac, base=base_url)

    def telegram_hunt(self, max_results=30, progress_cb=None):
        candidates = self.collect_telegram_candidates()
        total = len(candidates)

        for i, (base_url, mac) in enumerate(candidates):
            self._log(f'Telegram Hunter Modus: teste {base_url} MAC={mac}')
            if progress_cb:
                pct = 20 + int(i / max(total, 1) * 60)
                progress_cb(pct, f'Prüfe MAC {i+1}/{total}: {mac}')
            if 'get.php' in base_url:
                if self._check_xtream(base_url):
                    self._log(f'Telegram Hunter Modus: Xtream-Treffer: {base_url}')
                    return base_url, mac
            elif self._check_mac(mac, base=base_url):
                self._log(f'Telegram Hunter Modus: Telegram-Treffer: {base_url} MAC={mac}')
                self.portal_url = base_url
                self.mac = mac
                token = self._handshake(mac, base=base_url)
                if token:
                    self._token = token
                return base_url, mac

        self._log('Telegram Hunter Modus: kein Telegram-Treffer')
        return None, None

    def ensure_valid_mac(self, scan_threads=5, max_attempts=500, progress_cb=None):
        self._dbg(f'ensure_valid_mac: portal_url="{self.portal_url}" mac="{self.mac}"')
        if self.mac and self._check_mac(self.mac):
            self._log(f'Telegram Hunter Modus: gespeicherte MAC gültig: {self.mac}')
            token = self._handshake(self.mac)
            if token:
                self._token = token
            return self.mac

        if progress_cb:
            progress_cb(10, 'Telegram: lade Nachrichten...')
        found_url, found_mac = self.telegram_hunt(progress_cb=progress_cb)
        if found_url is not None:
            return found_mac

        if not self.portal_url:
            self._log('Telegram Hunter Modus: keine URL – Random-Scan übersprungen')
            return None

        self._log('Telegram Hunter Modus: starte MAC-Scan...')
        chars = '0123456789ABCDEF'
        state = {'active': True, 'found': None, 'attempts': 0, 'lock': threading.Lock()}

        def _scan():
            while state['active']:
                with state['lock']:
                    if state['attempts'] >= max_attempts:
                        state['active'] = False
                        return
                    state['attempts'] += 1
                    attempt_num = state['attempts']
                suffix = ':'.join(''.join(random.choice(chars) for _ in range(2)) for _ in range(3))
                mac = f'00:1A:79:{suffix}'
                self._dbg(f'MAC-Scan Versuch #{attempt_num}: {mac}')
                if self._check_mac(mac):
                    with state['lock']:
                        state['found'] = mac
                        state['active'] = False
                    return
                time.sleep(0.05)

        threads = [threading.Thread(target=_scan, daemon=True) for _ in range(scan_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self._dbg(f'MAC-Scan abgeschlossen: {state["attempts"]} Versuche, found={state["found"]}')

        if state['found']:
            self.mac = state['found']
            token = self._handshake(self.mac)
            if token:
                self._token = token
            self._log(f'Telegram Hunter Modus: neue MAC gefunden: {self.mac}')
            return self.mac

        return None
