# -*- coding: utf-8 -*-
# IT('s) Possible
# Tube8.com XXX
# 2026.10.01-3
import sys, re, json, html, unicodedata, urllib.request, urllib.parse, urllib.error
from urllib.parse import parse_qsl, urlencode, urljoin
from concurrent.futures import ThreadPoolExecutor
import xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')
ICON_PATH = xbmcvfs.translatePath('special://home/addons/{}/icon.png'.format(ADDON_ID))
HOME = DOMAIN = 'https://www.tube8.com'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'

def log(message): xbmc.log('TUBE8 - ' + str(message), xbmc.LOGINFO)
def log_error(message): xbmc.log('TUBE8 ERROR - ' + str(message), xbmc.LOGERROR)

try:
    xbmc.log('TUBE8 - ADDON PATH: {}'.format(ADDON_PATH), xbmc.LOGINFO)
    xbmc.log('TUBE8 - ICON PATH: {}'.format(ICON_PATH), xbmc.LOGINFO)
    xbmc.log('TUBE8 - ICON EXISTS: {}'.format(xbmcvfs.exists(ICON_PATH)), xbmc.LOGINFO)
except Exception as exc:
    xbmc.log('TUBE8 - Icon-Prüfung Fehler: {}'.format(exc), xbmc.LOGERROR)

def build_url(params): return base_url + '?' + urlencode(params)

def page_url(url, page):
    try:
        parsed = urllib.parse.urlsplit(url)
        query = dict(parse_qsl(parsed.query, keep_blank_values=True))
        query['page'] = str(page)
        return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(query), ''))
    except Exception:
        return url + ('&' if '?' in url else '?') + 'page=' + str(page)

def http_request(url, referer=None, accept='*/*', timeout=20):
    headers = {
        'User-Agent': UA, 'Referer': referer or HOME, 'Accept': accept,
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8', 'Connection': 'keep-alive'
    }
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            data = response.read()
            charset = response.headers.get_content_charset() or 'utf-8'
            try: return data.decode(charset, errors='replace')
            except Exception: return data.decode('utf-8', errors='replace')
    except Exception as exc:
        log_error('HTTP Fehler: {} -> {}'.format(url, exc))
        return ''

def get_html(url, referer=None):
    return http_request(url, referer=referer, accept='text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')

def get_json(url, referer=None):
    raw = http_request(url, referer=referer, accept='application/json,text/plain,*/*')
    if not raw: return None
    raw = raw.lstrip('\ufeff').strip()
    try: return json.loads(raw)
    except Exception: pass
    try: return json.loads(html.unescape(raw))
    except Exception: pass
    return None

def clean_text(value):
    if not value: return ''
    val = html.unescape(str(value))
    val = re.sub(r'<[^>]+>', ' ', val)
    return re.sub(r'\s+', ' ', val).strip()

def absolute_url(url):
    if not url: return ''
    url = html.unescape(url).replace('\\/', '/')
    if url.startswith('//'): return 'https:' + url
    if url.startswith('/'): return urljoin(DOMAIN, url)
    if url.startswith(('http://', 'https://')): return url
    return urljoin(DOMAIN + '/', url)

def natural_key(value):
    val = str(value).casefold()
    return [int(p) if p.isdigit() else p for p in re.split(r'(\d+)', val)]

def create_folder_item(label, thumb=None):
    item = xbmcgui.ListItem(label=label)
    art = {'icon': ICON_PATH, 'thumb': ICON_PATH, 'poster': ICON_PATH, 'fanart': ICON_PATH}
    if thumb:
        art.update({'thumb': thumb, 'poster': thumb, 'icon': thumb})
    item.setArt(art)
    item.setProperty('IsPlayable', 'false')
    return item

def add_folder(label, params, thumb=None):
    xbmcplugin.addDirectoryItem(addon_handle, build_url(params), create_folder_item(label, thumb), True)

def add_directory_item(label, action, **params):
    p = dict(params)
    p['action'] = action
    add_folder(label, p)

def seconds_from_duration(value):
    if not value: return 0
    val = str(value).strip()
    m = re.match(r'^(\d+):(\d{2})$', val)
    if m: return int(m.group(1)) * 60 + int(m.group(2))
    m = re.match(r'^(\d+):(\d{2}):(\d{2})$', val)
    if m: return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))
    return 0

def format_duration(seconds):
    try: seconds = int(seconds)
    except Exception: return ''
    if seconds <= 0: return ''
    h, r = divmod(seconds, 3600)
    m, s = divmod(r, 60)
    return '{}:{:02d}:{:02d}'.format(h, m, s) if h else '{}:{:02d}'.format(m, s)

def parse_iso_duration(value):
    if not value: return 0
    val = str(value).upper().strip()
    m = re.match(r'^P(?:([0-9]+)D)?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?$', val)
    if not m: return 0
    d, h, min_val, s = m.groups()
    return int(int(d or 0) * 86400 + int(h or 0) * 3600 + int(min_val or 0) * 60 + float(s or 0))

def pornstar_initial(name, path=''):
    text = ''.join(c for c in unicodedata.normalize('NFKD', name or '') if not unicodedata.combining(c))
    match = re.search(r'[A-Za-z]', text)
    if match: return match.group(0).lower()
    slug = ''.join(c for c in unicodedata.normalize('NFKD', path.rstrip('/').split('/')[-1]) if not unicodedata.combining(c))
    match = re.search(r'[A-Za-z]', slug)
    return match.group(0).lower() if match else ''

def extract_pornstars(page_html, wanted_letter):
    wanted_letter = (wanted_letter or '').casefold()
    results, seen = [], set()
    pattern = re.compile(r'<a\b[^>]*href\s*=\s*["\']([^"\']*?/pornstar/[^"\']+)["\'][^>]*>(.*?)</a>', re.I | re.S)
    for match in pattern.finditer(page_html):
        path = html.unescape(match.group(1)).strip()
        block = match.group(2)
        if not path: continue
        name = clean_text(block)
        if not name:
            alt_match = re.search(r'(?:alt|title)\s*=\s*["\']([^"\']+)["\']', block, re.I)
            if alt_match: name = clean_text(alt_match.group(1))
        if not name or pornstar_initial(name, path) != wanted_letter: continue
        full_path = absolute_url(path)
        key = full_path.casefold()
        if key in seen: continue
        seen.add(key)
        results.append({'name': name, 'path': full_path})
    return sorted(results, key=lambda item: natural_key(item['name']))

def extract_channels(page_html):
    results, seen = [], set()
    pattern = re.compile(r'<a\b[^>]*href\s*=\s*["\']([^"\']*?/channel/[^"\']+)["\'][^>]*>(.*?)</a>', re.I | re.S)
    thumb_attrs = ('data-image', 'data-thumb', 'data-thumb_url', 'data-master_thumb', 'data-poster', 'data-src', 'data-original', 'data-lazy-src', 'poster', 'src')

    for match in pattern.finditer(page_html):
        path = html.unescape(match.group(1)).strip()
        block = match.group(2)
        if not path: continue
        
        full_path = absolute_url(path)
        key = full_path.casefold()
        if key in seen: continue

        name = ''
        title_match = re.search(r'(?:title|alt)\s*=\s*["\']([^"\']+)["\']', block, re.I)
        if title_match: name = clean_text(title_match.group(1))
        if not name: name = clean_text(block)
        if not name or len(name) < 2: continue

        thumb = ''
        for attr in thumb_attrs:
            thumb_match = re.search(r'{}\s*=\s*["\']([^"\']+)["\']'.format(attr), block, re.I)
            if thumb_match:
                cand = absolute_url(thumb_match.group(1))
                if cand and not cand.startswith('data:image') and 'blank' not in cand.lower():
                    thumb = cand
                    break
        
        if thumb and not thumb.startswith('data:image'):
            thumb = '{}|Referer={}/'.format(thumb, DOMAIN)

        seen.add(key)
        results.append({'name': name, 'path': full_path, 'thumb': thumb})
    return results

def extract_video_metadata(page_html):
    if not page_html:
        return [], [], ''

    pornstars = []
    ps_area = page_html
    wrapper_match = re.search(r'<div[^>]*class=["\'][^"\']*suggest-pornstars-wrapper[^"\']*["\'][^>]*>(.*?)</div>\s*(?:</div>|$)', page_html, re.I | re.S)
    if wrapper_match:
        ps_area = wrapper_match.group(1)
    else:
        span_match = re.search(r'<span[^>]*id=["\']metaDataPornstarInfo["\'][^>]*>(.*?)</span>', page_html, re.I | re.S)
        if span_match:
            ps_area = span_match.group(1)

    ps_matches = re.findall(r'<a\b[^>]*href\s*=\s*["\'][^"\']*?/pornstar/[^"\']+["\'][^>]*>(.*?)</a>', ps_area, re.I | re.S)
    for m in ps_matches:
        name = clean_text(m)
        if name and name not in pornstars:
            pornstars.append(name)

    categories = []
    cat_matches = re.findall(r'<a\b[^>]*href\s*=\s*["\'][^"\']*?/cat/[^"\']+["\'][^>]*>(.*?)</a>', page_html, re.I | re.S)
    for m in cat_matches:
        cname = clean_text(m)
        if cname and cname not in categories and len(cname) > 1:
            categories.append(cname)

    published = ''
    pub_patterns = [
        r'itemprop=["\']uploadDate["\'][^>]*content=["\']([^"\']+)["\']',
        r'["\']datePublished["\']\s*:\s*["\']([^"\']+)["\']',
        r'(?:Published|Uploaded|Added)\s*(?:On)?[:]?\s*(?:<[^>]+>\s*)*([^<>\n]+)'
    ]
    
    for pat in pub_patterns:
        pub_match = re.search(pat, page_html, re.I)
        if pub_match:
            val = clean_text(pub_match.group(1))
            date_match = re.search(r'(\d{4}-\d{2}-\d{2}(?:[T\s]\d{2}:\d{2}:\d{2})?)', val)
            if date_match:
                published = date_match.group(1)
                break
            elif val and len(val) < 30 and not val.lower().startswith('published'):
                published = val
                break

    return pornstars, categories, published

def extract_duration_from_block(block):
    patterns = [
        r'itemprop\s*=\s*["\']duration["\'][^>]*content\s*=\s*["\']([^"\']+)["\']',
        r'content\s*=\s*["\']([^"\']+)["\'][^>]*itemprop\s*=\s*["\']duration["\']',
        r'["\']duration["\']\s*:\s*["\']([^"\']+)["\']',
        r'data-duration\s*=\s*["\']([^"\']+)["\']'
    ]
    for pattern in patterns:
        match = re.search(pattern, block, re.I | re.S)
        if match:
            val = html.unescape(match.group(1))
            secs = parse_iso_duration(val) or seconds_from_duration(val)
            if secs: return secs
    matches = re.findall(r'(?<!\d)(\d{1,2}:\d{2}(?::\d{2})?)(?!\d)', clean_text(block))
    if matches:
        matches.sort(key=seconds_from_duration, reverse=True)
        return seconds_from_duration(matches[0])
    return 0

def extract_video_entries(page_html):
    results, main_content = [], page_html
    container_match = re.search(r'(<div[^>]*class=["\'][^"\']*(?:video-list|main-content|blogs-list|section_videos|search-results)[^"\']*["\'].*?)</section>|(</div>\s*<div class=["\']sidebar)', page_html, re.I | re.S)
    if container_match: 
        main_content = container_match.group(1) or container_match.group(2) or page_html

    videos_map, ordered_urls = {}, []
    pattern = re.compile(r'<a\b[^>]*href\s*=\s*["\']([^"\']*?/porn-video/[^"\']+)["\'][^>]*>(.*?)</a>', re.I | re.S)
    
    for match in pattern.finditer(main_content):
        full_tag, path = match.group(0), html.unescape(match.group(1)).strip()
        if not path: continue
        full_url = absolute_url(path)
        if '/porn-video/' not in full_url: continue
        key = full_url.casefold()
        if key not in videos_map:
            videos_map[key] = {'path': path, 'url': full_url, 'blocks': []}
            ordered_urls.append(key)
        videos_map[key]['blocks'].append(full_tag)

    thumb_attrs = ('data-image', 'data-thumb', 'data-thumb_url', 'data-master_thumb', 'data-poster', 'data-src', 'data-original', 'data-lazy-src', 'data-mediabook', 'data-bkg', 'poster', 'src')
    for key in ordered_urls:
        data = videos_map[key]
        combined_block = " ".join(data['blocks'])
        title = ''
        title_match = re.search(r'(?:title|data-title|alt)\s*=\s*["\']([^"\']+)["\']', combined_block, re.I)
        if title_match: title = clean_text(title_match.group(1))
        if not title:
            inner_texts = re.findall(r'>([^<]+)</a>', combined_block)
            title = clean_text(" ".join(inner_texts).strip())
        if not title or len(title) < 3: continue

        thumb = ''
        for attr in thumb_attrs:
            thumb_match = re.search(r'{}\s*=\s*["\']([^"\']+)["\']'.format(attr), combined_block, re.I)
            if thumb_match:
                cand = absolute_url(thumb_match.group(1))
                if cand and not cand.startswith('data:image') and 'blank' not in cand.lower():
                    thumb = cand; break
        if not thumb:
            bg_match = re.search(r'background(?:-image)?\s*:\s*url\([\'"]?([^\'"()]+)[\'"]?\)', combined_block, re.I)
            if bg_match:
                cand = absolute_url(bg_match.group(1))
                if cand and not cand.startswith('data:image'): thumb = cand
        if not thumb:
            escaped_path = re.escape(data['path'])
            context_match = re.search(r'.{0,350}' + escaped_path + r'.{0,350}', main_content, re.I | re.S)
            if context_match:
                for attr in thumb_attrs:
                    thumb_match = re.search(r'{}\s*=\s*["\']([^"\']+)["\']'.format(attr), context_match.group(0), re.I)
                    if thumb_match:
                        cand = absolute_url(thumb_match.group(1))
                        if cand and not cand.startswith('data:image') and 'blank' not in cand.lower():
                            thumb = cand; break

        duration = extract_duration_from_block(combined_block)
        if thumb and not thumb.startswith('data:image'):
            thumb = '{}|Referer={}/'.format(thumb, DOMAIN)
        results.append({'path': data['path'], 'url': data['url'], 'title': title, 'thumb': thumb, 'duration': duration})

    log('Videoeinträge gefunden: {}'.format(len(results)))
    return results

def extract_pagination_pages(page_html, current_url):
    pages = set()
    patterns = [r'href\s*=\s*["\']([^"\']*?[?&]page=(\d+)[^"\']*)["\']', r'href\s*=\s*["\']([^"\']*?/page/(\d+)[^"\']*)["\']']
    for pattern in patterns:
        for match in re.finditer(pattern, page_html, re.I):
            try:
                if int(match.group(2)) > 0: pages.add(int(match.group(2)))
            except Exception: pass
    for match in re.finditer(r'(?:https?:)?//[^"\'>\s]+[?&]page=(\d+)', page_html, re.I):
        try:
            if int(match.group(1)) > 0: pages.add(int(match.group(1)))
        except Exception: pass
    return sorted(pages)

def find_media_resolvers(page_html):
    page_html = html.unescape(page_html).replace('\\/', '/')
    found, seen = [], set()
    pattern = re.compile(r'(?:https?:)?//www\.tube8\.com/media/(hls|mp4)/\?s=([^"\'<>\s]+)', re.I)
    for match in pattern.finditer(page_html):
        mtype, token = match.group(1).lower(), match.group(2)
        url = 'https://www.tube8.com/media/' + mtype + '/?s=' + token
        if url not in seen:
            seen.add(url)
            found.append({'type': mtype, 'url': url})
    return sorted(found, key=lambda x: 0 if x['type'] == 'hls' else 1)

def collect_video_sources(obj, result=None):
    if result is None: result = []
    if isinstance(obj, list):
        for item in obj: collect_video_sources(item, result)
        return result
    if not isinstance(obj, dict): return result
    video_url = obj.get('videoUrl') or obj.get('videoURL') or obj.get('url')
    if video_url:
        video_url = absolute_url(video_url)
        if video_url.startswith(('http://', 'https://')):
            result.append({
                'url': video_url, 'format': str(obj.get('format') or '').lower(),
                'quality': str(obj.get('quality') or ''), 'width': obj.get('width'),
                'height': obj.get('height'), 'default': bool(obj.get('defaultQuality'))
            })
    for v in obj.values():
        if isinstance(v, (dict, list)): collect_video_sources(v, result)
    return result

def quality_number(source):
    q = str(source.get('quality') or '')
    m = re.search(r'(\d{3,4})', q)
    if m: return int(m.group(1))
    url = source.get('url', '')
    m = re.search(r'[_-](\d{3,4})P(?:[_-]|/)', url, re.I)
    if m: return int(m.group(1))
    try: return int(source.get('height') or 0)
    except Exception: return 0

def choose_hls_source(sources):
    hls = [s for s in sources if '.m3u8' in s.get('url', '').lower() or s.get('format', '').lower() == 'hls']
    if not hls: return None
    hls.sort(key=lambda s: (quality_number(s), 1 if s.get('default') else 0), reverse=True)
    return hls[0]

def choose_mp4_source(sources):
    mp4 = []
    for s in sources:
        url = s.get('url', '')
        fmt = s.get('format', '').lower()
        if fmt == 'mp4' or '.mp4' in url.lower():
            if any(bad in url.lower() for bad in ('_fb.mp4', 'preview', 'thumb', 'thumbnail')): continue
            mp4.append(s)
    if not mp4: return None
    mp4.sort(key=lambda s: (quality_number(s), 1 if s.get('default') else 0), reverse=True)
    return mp4[0]

def resolve_tube8_stream(page_url, page_html):
    resolvers = find_media_resolvers(page_html)
    if not resolvers:
        log_error('Keine Tube8 Media-Resolver auf Videoseite gefunden')
        return None, None
    log('Gefundene Resolver: {}'.format(len(resolvers)))
    mp4_fallback = None
    for resolver in resolvers:
        rtype, rurl = resolver['type'], resolver['url']
        log('Resolver {}: {}'.format(rtype.upper(), rurl))
        data = get_json(rurl, referer=page_url)
        if data is None:
            log_error('Resolver lieferte kein JSON')
            continue
        sources = collect_video_sources(data)
        if not sources: continue
        if rtype == 'hls':
            selected = choose_hls_source(sources)
            if selected:
                log('ECHTER HLS STREAM: {} ({}p)'.format(selected['url'], quality_number(selected)))
                return selected['url'], 'hls'
        elif rtype == 'mp4':
            selected = choose_mp4_source(sources)
            if selected: mp4_fallback = (selected['url'], 'mp4')
    if mp4_fallback:
        log('HLS nicht verfügbar - MP4 Fallback: {}'.format(mp4_fallback[0]))
        return mp4_fallback
    log_error('Resolver enthielt keine verwendbare Video-URL')
    return None, None

def play_stream(stream_url, stream_type, page_url, title='Tube8'):
    if not stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification('Tube8', 'Kein Stream gefunden', xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    header_string = 'User-Agent={}&Referer={}&Origin={}'.format(
        urllib.parse.quote(UA, safe=''), urllib.parse.quote(page_url, safe=''), urllib.parse.quote(DOMAIN, safe='')
    )
    kodi_url = stream_url + '|' + header_string

    item = xbmcgui.ListItem(label=title)
    item.setPath(kodi_url)
    item.setContentLookup(False)

    if stream_type == 'hls':
        item.setMimeType('application/vnd.apple.mpegurl')
        try: adaptive_available = xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')
        except Exception: adaptive_available = False

        if adaptive_available:
            item.setProperty('inputstream', 'inputstream.adaptive')
            item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            item.setProperty('inputstream.adaptive.manifest_headers', header_string)
            item.setProperty('inputstream.adaptive.stream_headers', header_string)
    else:
        item.setMimeType('video/mp4')

    try: item.getVideoInfoTag().setTitle(title)
    except Exception as exc: log('InfoTag Fehler: {}'.format(exc))

    log('RESOLVED PLAY - Typ: {}'.format(stream_type))
    log('RESOLVED PLAY - URL: {}'.format(stream_url))
    
    xbmcplugin.setResolvedUrl(addon_handle, True, item)

def main_menu():
    xbmcplugin.setPluginCategory(addon_handle, 'Tube8')
    add_directory_item('Neueste Videos', 'listing', url=DOMAIN + '/newest.html', title='Neueste Videos', page='1')
    add_directory_item('Suchen', 'search')
    add_directory_item('Pornstars', 'pornstars_alphabet')
    add_directory_item('Channels', 'channels_list', page='1')
    add_directory_item('Kategorien', 'cat')
    add_directory_item('Filter', 'set_filter')
    xbmcplugin.endOfDirectory(addon_handle)

def search_menu():
    keyboard = xbmc.Keyboard('', 'Tube8 Suche')
    keyboard.doModal()
    if not keyboard.isConfirmed(): 
        return
    query = keyboard.getText().strip()
    if query:
        formatted_query = urllib.parse.quote_plus(query.lower())
        search_url = DOMAIN + '/searches.html?q=' + formatted_query
        listing(search_url, 'Suchergebnisse: ' + query, page=1)

def channels_list(page=1):
    try: page = int(page)
    except Exception: page = 1

    url = DOMAIN + '/top-channels/?orderBy=al'
    if page > 1: url = page_url(url, page)
    
    log('Channels Seite: {}'.format(url))
    page_html = get_html(url, referer=DOMAIN + '/')
    if not page_html:
        xbmcgui.Dialog().notification('Tube8', 'Channels konnten nicht geladen werden', xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    channels = extract_channels(page_html)
    log('Channels Seite {}: {} Treffer'.format(page, len(channels)))
    for ch in channels:
        add_folder(ch['name'], {'action': 'listing', 'url': ch['path'], 'title': ch['name'], 'page': '1'}, thumb=ch['thumb'])

    pages = extract_pagination_pages(page_html, url)
    next_page = next((n for n in pages if n > page), None)
    if next_page is None and len(channels) >= 20: next_page = page + 1
    
    if next_page: add_folder('Nächste Seite', {'action': 'channels_list', 'page': str(next_page)})
    if page > 1: add_folder('Vorherige Seite', {'action': 'channels_list', 'page': str(page - 1)})

    xbmcplugin.setPluginCategory(addon_handle, 'Channels - Seite {}'.format(page))
    xbmcplugin.endOfDirectory(addon_handle)

def pornstars_alphabet():
    for letter in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
        add_folder(letter, {'action': 'pornstars_list', 'letter': letter, 'page': '1'})
    xbmcplugin.endOfDirectory(addon_handle)

def pornstars_list(letter, page=1):
    try: page = int(page)
    except Exception: page = 1
    letter = (letter or '').strip().upper()
    if len(letter) != 1 or letter not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ': return
    url = DOMAIN + '/pornstars/alphabetical/' + letter.lower() + '/'
    if page > 1: url = page_url(url, page)
    log('Pornstar Seite: {}'.format(url))
    page_html = get_html(url, referer=DOMAIN + '/')
    if not page_html:
        xbmcgui.Dialog().notification('Tube8', 'Pornstars konnten nicht geladen werden', xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    stars = extract_pornstars(page_html, letter)
    log('Pornstars {} Seite {}: {} Treffer'.format(letter, page, len(stars)))
    for star in stars:
        add_folder(star['name'], {'action': 'listing', 'url': star['path'], 'title': star['name'], 'page': '1'})
    pages = extract_pagination_pages(page_html, url)
    next_page = next((n for n in pages if n > page), None)
    if next_page is None and len(stars) >= 30: next_page = page + 1
    if next_page: add_folder('Nächste Seite', {'action': 'pornstars_list', 'letter': letter, 'page': str(next_page)})
    xbmcplugin.endOfDirectory(addon_handle)

def set_filter():
    labels = ['5 Minuten (Standard)', '10 Minuten', '15 Minuten', '20 Minuten', '30 Minuten', '45 Minuten']
    values = ['5', '10', '15', '20', '30', '45']
    window = xbmcgui.Window(10000)
    current = window.getProperty('tube8_filter')
    current_index = values.index(current) if current in values else 0
    selected = xbmcgui.Dialog().select('Mindestdauer', labels, preselect=current_index)
    if selected >= 0:
        window.setProperty('tube8_filter', values[selected])
        xbmcgui.Dialog().notification('Tube8', 'Filter: ' + labels[selected], xbmcgui.NOTIFICATION_INFO, 2500)

def categories():
    cats = [
        ('18-25', '/cat/teens/'), ('Amateur', '/cat/amateur/'), ('Anal', '/cat/anal/'), ('Arab', '/cat/arab/'), ('Asian', '/cat/asian/'),
        ('BBW', '/cat/bbw/'), ('Big Ass', '/cat/bigass/'), ('Big Dick', '/cat/bigdick/'), ('Big Tits', '/cat/bigtits/'), ('Blonde', '/cat/blonde/'),
        ('Blowjob', '/cat/blowjob/'), ('Bondage', '/cat/bondage/'), ('Brazilian', '/cat/brazilian/'), ('Brunette', '/cat/brunette/'), ('Bukkake', '/cat/bukkake/'),
        ('Cartoon', '/cat/cartoon/'), ('Casting', '/cat/casting/'), ('Celebrity', '/cat/celebrity/'), ('College (18+)', '/cat/college/'), ('Compilation', '/cat/compilation/'),
        ('Cosplay', '/cat/cosplay/'), ('Creampie', '/cat/creampie/'), ('Cuckold', '/cat/cuckold/'), ('Cumshot', '/cat/cumshot/'), ('Double Penetration', '/cat/doublepenetration/'),
        ('Ebony', '/cat/ebony/'), ('Erotic', '/cat/erotic/'), ('Feet', '/cat/feet/'), ('Female Orgasm', '/cat/femaleorgasm/'), ('Fetish', '/cat/fetish/'),
        ('Fingering', '/cat/fingering/'), ('Fisting', '/cat/fisting/'), ('French', '/cat/french/'), ('Funny', '/cat/funny/'), ('Gangbang', '/cat/gangbang/'),
        ('German', '/cat/german/'), ('Group', '/cat/group/'), ('HD', '/cat/hd/'), ('Handjob', '/cat/handjob/'), ('Hardcore', '/cat/hardcore/'),
        ('Hentai', '/cat/hentai/'), ('Indian', '/cat/indian/'), ('Interracial', '/cat/interracial/'), ('Japanese', '/cat/japanese/'), ('Latina', '/cat/latina/'),
        ('Lesbian', '/cat/lesbian/'), ('MILF', '/cat/milf/'), ('Massage', '/cat/massage/'), ('Masturbation', '/cat/masturbation/'), ('Mature', '/cat/mature/'),
        ('Orgy', '/cat/orgy/'), ('POV', '/cat/pov/'), ('Parody', '/cat/parody/'), ('Party', '/cat/party/'), ('Pissing', '/cat/pissing/'),
        ('Popular With Women', '/cat/popular-with-women/'), ('Public', '/cat/public/'), ('Pussy Licking', '/cat/pussy-licking/'), ('Reality', '/cat/reality/'), ('Redhead', '/cat/redhead/'),
        ('Rough', '/cat/rough/'), ('Small Tits', '/cat/small-tits/'), ('Solo Male', '/cat/solomale/'), ('Squirting', '/cat/squirting/'), ('Step Fantasy', '/cat/stepfantasy/'),
        ('Strip', '/cat/strip/'), ('Striptease', '/cat/striptease/'), ('Threesome', '/cat/threesome/'), ('Toys', '/cat/toys/'), ('Transgender', '/cat/transgender/'),
        ('Verified Amateurs', '/cat/verifiedamateurs/'), ('Vintage', '/cat/vintage/'), ('Virtual Reality', '/cat/virtualreality/'), ('Webcam', '/cat/webcam/'), ('Young (18+) and Old', '/cat/youngandold/')
    ]
    for label, path in cats:
        add_folder(label, {'action': 'listing', 'url': DOMAIN + path, 'title': label, 'page': '1'})
    xbmcplugin.endOfDirectory(addon_handle)

def listing(url, title='Tube8', page=1):
    if not url: return
    try: page = int(page)
    except Exception: page = 1

    window = xbmcgui.Window(10000)
    try: min_minutes = int(window.getProperty('tube8_filter') or '5')
    except Exception: min_minutes = 5
    min_seconds = min_minutes * 60

    valid_videos, current_fetch_page, last_page_html = [], page, ""
    max_fetch_depth, fetched_count = (5 if min_seconds > 0 else 1), 0

    while fetched_count < max_fetch_depth:
        fetch_url = page_url(url, current_fetch_page) if current_fetch_page > 1 else url
        log('LISTING Abruf Seite {}: {}'.format(current_fetch_page, fetch_url))
        page_html = get_html(fetch_url, referer=DOMAIN + '/')
        if not page_html: break
        last_page_html = page_html
        raw_videos = extract_video_entries(page_html)
        if not raw_videos: break

        for video in raw_videos:
            duration = video['duration']
            if min_seconds > 0 and 0 < duration < min_seconds: continue
            valid_videos.append(video)

        if len(valid_videos) >= 30 or min_seconds == 0: break
        current_fetch_page += 1
        fetched_count += 1

    if not valid_videos:
        log_error('Keine passenden Videos in Listing gefunden: {}'.format(url))
        xbmcgui.Dialog().notification('Tube8', 'Keine Videos gefunden', xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(addon_handle)
        return

    def fetch_and_enrich(video):
        detail_html = get_html(video['url'], referer=url)
        pornstars, categories, published = extract_video_metadata(detail_html)
        video['pornstars'] = pornstars
        video['categories'] = categories
        video['published'] = published
        return video

    with ThreadPoolExecutor(max_workers=10) as executor:
        enriched_videos = list(executor.map(fetch_and_enrich, valid_videos))

    for video in enriched_videos:
        duration = video['duration']
        item = xbmcgui.ListItem(label=video['title'])
        if video['thumb']:
            item.setArt({'thumb': video['thumb'], 'poster': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        else:
            item.setArt({'icon': ICON_PATH, 'thumb': ICON_PATH})
        item.setProperty('IsPlayable', 'true')
        
        pornstars = video.get('pornstars', [])
        categories = video.get('categories', [])
        published = video.get('published', '')
        
        plot_lines = []
        if pornstars:
            plot_lines.append('Pornstars: ' + ', '.join(pornstars))
        if categories:
            plot_lines.append('Kategorien: ' + ', '.join(categories))
        if published:
            plot_lines.append('Published: ' + published)
        
        plot_text = '\n\n'.join(plot_lines) if plot_lines else ''

        try:
            tag = item.getVideoInfoTag()
            tag.setTitle(video['title'])
            if duration: tag.setDuration(duration)
            if plot_text: tag.setPlot(plot_text)
            if pornstars: tag.setCast([xbmcgui.Actor(star) for star in pornstars])
            if categories: tag.setGenres(categories)
            if published: tag.setFirstAired(published)
        except Exception as exc:
            log('Listing InfoTag Fehler: {}'.format(exc))

        if duration: item.setProperty('TotalTime', str(duration))

        play_url = build_url({'action': 'play', 'url': video['url'], 'duration': str(duration)})
        xbmcplugin.addDirectoryItem(addon_handle, play_url, item, False)

    pages = extract_pagination_pages(last_page_html, url)
    next_page = next((n for n in pages if n > current_fetch_page), None)
    if next_page is None and len(valid_videos) >= 15: next_page = current_fetch_page + 1

    if next_page: add_folder('Nächste Seite', {'action': 'listing', 'url': url, 'title': title, 'page': str(next_page)})
    if page > 1: add_folder('Vorherige Seite', {'action': 'listing', 'url': url, 'title': title, 'page': str(page - 1)})

    log('LISTING Seite {}: {} Videos angezeigt'.format(page, len(valid_videos)))
    xbmcplugin.setPluginCategory(addon_handle, '{} - Seite {}'.format(title, page))
    xbmcplugin.setContent(addon_handle, 'movies')
    xbmcplugin.endOfDirectory(addon_handle)

def play(page_url, expected_duration=0):
    if not page_url:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return
    try: expected_duration = int(expected_duration or 0)
    except Exception: expected_duration = 0
    log('PLAY - Seite: {}'.format(page_url))
    if expected_duration: log('PLAY - Erwartete Dauer: {}'.format(format_duration(expected_duration)))

    page_html = get_html(page_url, referer=DOMAIN + '/')
    if not page_html:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification('Tube8', 'Videoseite konnte nicht geladen werden', xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    stream_url, stream_type = resolve_tube8_stream(page_url, page_html)
    if not stream_url:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification('Tube8', 'Kein echter Videostream gefunden', xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    title = 'Tube8'
    title_match = re.search(r'<title[^>]*>(.*?)</title>', page_html, re.I | re.S)
    if title_match:
        title = clean_text(title_match.group(1))
        title = re.sub(r'\s*\|\s*Tube8.*$', '', title, flags=re.I).strip()

    log('PLAY - Gewählter echter Stream: {}'.format(stream_url))
    play_stream(stream_url, stream_type, page_url, title)

def router():
    query = sys.argv[2] if len(sys.argv) > 2 else ''
    params = dict(parse_qsl(query.lstrip('?'), keep_blank_values=True))
    action = params.get('action', 'main')

    if action == 'main': main_menu()
    elif action == 'search': search_menu()
    elif action == 'channels_list': channels_list(params.get('page', '1'))
    elif action == 'pornstars_alphabet': pornstars_alphabet()
    elif action == 'pornstars_list': pornstars_list(params.get('letter', 'A'), params.get('page', '1'))
    elif action == 'set_filter': set_filter()
    elif action == 'cat': categories()
    elif action == 'listing': listing(params.get('url', ''), params.get('title', 'Tube8'), params.get('page', '1'))
    elif action == 'play': play(params.get('url', ''), params.get('duration', '0'))
    else: main_menu()

if __name__ == '__main__':
    try: router()
    except Exception as exc:
        log_error('Unbehandelter Fehler: {}'.format(exc))
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)
