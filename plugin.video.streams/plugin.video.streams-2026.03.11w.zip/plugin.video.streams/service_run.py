 
# -*- coding: UTF-8 -*-
if __name__=='__main__':
    from sys import argv
    import service