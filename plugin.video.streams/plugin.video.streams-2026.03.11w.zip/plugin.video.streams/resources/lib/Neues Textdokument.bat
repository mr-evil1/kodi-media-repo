@echo off
setlocal enabledelayedexpansion

:: Loop durch alle .pyc Dateien im aktuellen Ordner
for %%f in (*.cpython-38.opt-1.pyc) do (
    set "filename=%%f"
    
    :: Ersetze den spezifischen Teil durch nichts
    set "newname=!filename:.cpython-38.opt-1=!"
    
    echo Benenne um: "%%f" -^> "!newname!"
    ren "%%f" "!newname!"
)

pause