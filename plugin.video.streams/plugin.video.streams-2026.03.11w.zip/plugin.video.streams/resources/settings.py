# -*- coding: utf-8 -*-
import sys
import os

# sys.path um das Addon-Stammverzeichnis ergaenzen, damit 'resources' gefunden wird.
# RunScript() setzt das Arbeitsverzeichnis nicht automatisch auf das Addon-Verzeichnis.
_addon_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _addon_dir not in sys.path:
    sys.path.insert(0, _addon_dir)

from xbmcgui import NOTIFICATION_INFO, Dialog
from resources.lib import control

dialog = Dialog()
name = control.addonInfo('name')

_params = dict(control.parse_qsl(sys.argv[1].replace('?', '')))
_action = _params.get('action')
mode = None
query = None

def window(title='', content='', filename=''):
    import xbmc, xbmcgui, time, os
    if content == '' and filename == '': return
    if content == '' and filename != '':
        file = os.path.join(control.py2_decode(control.translatePath(control.addonInfo('path'))), 'resources', filename)
        if sys.version_info[0] == 2:
            with open(file, 'r') as f:
                content = f.read()
        else:
            with open(file, 'rb') as f:
                content = f.read().decode('utf8')

        window_id = 10147
        control_label = 1
        control_textbox = 5
        timeout = 1
        xbmc.executebuiltin("ActivateWindow({})".format(window_id))
        w = xbmcgui.Window(window_id)
        # Wait for window to open
        start_time = time.time()
        while (not xbmc.getCondVisibility("Window.IsVisible({})".format(window_id)) and
               time.time() - start_time < timeout):
            xbmc.sleep(100)
        # noinspection PyUnresolvedReferences
        w.getControl(control_label).setLabel(title)
        # noinspection PyUnresolvedReferences
        w.getControl(control_textbox).setText(content)


def _get_all_providers():
    """Alle Provider-IDs aus der pluginDB lesen."""
    import json
    from resources.lib import control as _ctrl
    db_file = os.path.join(_ctrl.dataPath, 'pluginDB')
    try:
        with open(db_file, 'r', encoding='utf-8') as f:
            db = json.load(f)
        return list(db.keys())
    except Exception:
        return []


def _get_german_providers():
    """Deutsche Provider: alle Provider deren Name kein reines Englisch ist
    bzw. die keine '.to'/'.com' Englisch-only-Domains haben.
    Da scrapers_source nicht mehr existiert, werden einfach alle Provider
    zurueckgegeben (konservativ – kein Datenverlust)."""
    return _get_all_providers()


def run(params):
    action = params.get('subaction')

    if action == 'Defaults':
        dialog.notification(name, 'Einstellungen wurden übernommen', NOTIFICATION_INFO, 500, sound=False)
        for i in _get_all_providers():
            control.setSetting('provider.' + i, 'true')

    elif action == 'toggleAll':
        dialog.notification(name, 'Einstellungen wurden übernommen', NOTIFICATION_INFO, 500, sound=False)
        value = params.get('setting', 'true')
        for i in _get_all_providers():
            control.setSetting('provider.' + i, value)

    elif action == 'defaultsGerman':
        dialog.notification(name, 'Einstellungen wurden übernommen', NOTIFICATION_INFO, 500, sound=False)
        for i in _get_german_providers():
            control.setSetting('provider.' + i, 'true')

    elif action == 'toggleGerman':
        dialog.notification(name, 'Einstellungen wurden übernommen', NOTIFICATION_INFO, 500, sound=False)
        value = params.get('setting', 'true')
        for i in _get_german_providers():
            control.setSetting('provider.' + i, value)

    elif action == 'downloadInfo':
        window('Hilfe zum Syntax für den Ordnerpfad', '', 'downloadinfo.txt')
        


if _action == 'run':
    run(_params)
