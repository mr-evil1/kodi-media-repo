import os
import re
import shutil
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from urllib.parse import parse_qs, parse_qsl, urlparse

import xbmcgui
import xbmcvfs

from . import kodi, logger, mp4mux, player

_DEFAULT_PATH = '/storage/emulated/0/Download/NewPipe_Download'
_CHUNK = 1024 * 1024
_MAX_FAILS = 8
_MAX_CANDIDATES = 4
_PACE_FACTOR = 3.0
_BURST_SECONDS = 20.0
_TIMEOUT = 60
_NS = {'m': 'urn:mpeg:dash:schema:mpd:2011'}
_TAG = 'download'
_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'


class DownloadError(Exception):
    pass


class Cancelled(Exception):
    pass


def _sanitize(name):
    name = re.sub(r'[\\/*?:"<>|\r\n\t]', '_', name or '').strip().strip('.')
    return name[:100] or 'video'


def _get_path():
    path = kodi.setting('download_path') or _DEFAULT_PATH
    try:
        if not xbmcvfs.exists(path.rstrip('/') + '/'):
            xbmcvfs.mkdirs(path)
    except Exception as e:
        logger.debug('xbmcvfs mkdirs failed: {0}'.format(e), _TAG)
    try:
        os.makedirs(path, exist_ok=True)
    except Exception as e:
        logger.debug('os.makedirs failed: {0}'.format(e), _TAG)
    return path


def _unique(path):
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    i = 1
    while os.path.exists('{0} ({1}){2}'.format(base, i, ext)):
        i += 1
    return '{0} ({1}){2}'.format(base, i, ext)


def _int_setting(key, default):
    try:
        return int(kodi.setting(key))
    except (TypeError, ValueError):
        return default


class _Progress:
    def __init__(self, heading, line):
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create(heading, line)
        self.total = 0
        self.done = 0
        self.line = line
        self.last = 0.0

    def set_total(self, total):
        self.total = max(total, 1)

    def set_line(self, line):
        self.line = line
        self._push(force=True)

    def add(self, n):
        self.done += n
        self._push()

    def _push(self, force=False):
        now = time.time()
        if not force and now - self.last < 0.5:
            return
        self.last = now
        pct = int(min(self.done, self.total) * 100 / self.total) if self.total else 0
        mb = '{0:.1f}/{1:.1f} MB'.format(self.done / 1048576.0, self.total / 1048576.0) if self.total > 1 else ''
        self.dialog.update(pct, '{0}\n{1}'.format(self.line, mb))

    def cancelled(self):
        return self.dialog.iscanceled()

    def close(self):
        try:
            self.dialog.close()
        except Exception:
            pass


def _http(url, headers=None, timeout=_TIMEOUT):
    h = {'User-Agent': _UA}
    h.update(headers or {})
    return urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=timeout)


def _fetch_text(url):
    with _http(url, timeout=30) as resp:
        return resp.read().decode('utf-8', 'replace')


def _content_length(url, headers):
    qs = parse_qs(urlparse(url).query)
    clen = (qs.get('clen') or [''])[0]
    if clen.isdigit():
        return int(clen)
    h = dict(headers)
    h['Range'] = 'bytes=0-0'
    with _http(url, h) as resp:
        cr = resp.headers.get('Content-Range') or ''
        m = re.search(r'/(\d+)$', cr)
        if m:
            return int(m.group(1))
        length = resp.headers.get('Content-Length')
        if length and length.isdigit() and resp.status == 200:
            return int(length)
    raise DownloadError('content length unknown')


def _with_range_param(url, start, end):
    base, sep, query = url.partition('?')
    parts = [q for q in query.split('&') if q and not q.startswith('range=')]
    parts.append('range={0}-{1}'.format(start, end))
    return base + '?' + '&'.join(parts)


def _fetch_range(url, headers, start, end, use_param):
    h = dict(headers)
    target = url
    if use_param:
        target = _with_range_param(url, start, end)
    else:
        h['Range'] = 'bytes={0}-{1}'.format(start, end)
    with _http(target, h) as resp:
        data = resp.read()
        status = resp.status
    expected = end - start + 1
    if status == 200 and not use_param and len(data) > expected:
        data = data[start:end + 1]
    elif status not in (200, 206):
        raise DownloadError('http status {0}'.format(status))
    if len(data) != expected:
        raise DownloadError('short chunk {0}/{1}'.format(len(data), expected))
    return data


def _wait(seconds, progress):
    end = time.time() + seconds
    while time.time() < end:
        if progress.cancelled():
            raise Cancelled()
        time.sleep(min(0.5, max(0.0, end - time.time())))


def _download_file(rep, dest, progress, headers, refresh=None):
    url = rep['url']
    total = _content_length(url, headers)
    bps = max(rep.get('bandwidth') or 0, 64000) / 8.0
    logger.debug('downloading {0} bytes ({1}) to {2}'.format(total, rep.get('id'), dest), _TAG)
    progress.set_total(progress.total or total)
    pos = 0
    fails = 0
    use_param = False
    pace = not rep.get('nopace')
    started = time.time()
    with open(dest, 'wb') as f:
        while pos < total:
            if progress.cancelled():
                raise Cancelled()
            allowed = bps * _BURST_SECONDS + (time.time() - started) * bps * _PACE_FACTOR
            if pace and pos > allowed:
                _wait(min(2.0, (pos - allowed) / (bps * _PACE_FACTOR)), progress)
                continue
            end = min(pos + _CHUNK, total) - 1
            try:
                data = _fetch_range(url, headers, pos, end, use_param)
            except Cancelled:
                raise
            except Exception as e:
                fails += 1
                logger.debug('chunk {0}-{1} failed ({2}) mode={3} fails={4}'.format(
                    pos, end, e, 'param' if use_param else 'header', fails), _TAG)
                if fails >= _MAX_FAILS:
                    raise DownloadError('chunk failed: {0}'.format(e))
                use_param = not use_param
                if fails % 2 == 0 and refresh:
                    fresh = refresh()
                    if fresh:
                        logger.debug('url refreshed', _TAG)
                        url = fresh
                _wait(min(2 ** fails, 15), progress)
                continue
            fails = 0
            f.write(data)
            pos += len(data)
            progress.add(len(data))
    return total


def _fetch_with_fallback(cands, dest, progress, headers, refresher, limit=_MAX_CANDIDATES):
    last = None
    for rep in cands[:limit]:
        before = progress.done
        try:
            _download_file(rep, dest, progress, headers, refresher(rep))
            return rep
        except Cancelled:
            raise
        except Exception as e:
            last = e
            logger.error('representation {0} ({1}) failed: {2}'.format(rep.get('id'), rep.get('height') or rep.get('codecs'), e), _TAG)
            progress.done = before
    raise DownloadError('all representations failed: {0}'.format(last))


def _parse_mpd(text):
    root = ET.fromstring(text)
    result = {'video': [], 'audio': []}
    for aset in root.iter('{%s}AdaptationSet' % _NS['m']):
        ctype = aset.get('contentType') or (aset.get('mimeType') or '').split('/')[0]
        if ctype not in result:
            continue
        roles = [r.get('value') for r in aset.findall('m:Role', _NS)]
        for rep in aset.findall('m:Representation', _NS):
            base = rep.find('m:BaseURL', _NS)
            if base is None or not (base.text or '').strip():
                continue
            mime = rep.get('mimeType') or aset.get('mimeType') or ''
            result[ctype].append({
                'id': rep.get('id') or '',
                'url': base.text.strip(),
                'mime': mime,
                'codecs': rep.get('codecs') or aset.get('codecs') or '',
                'bandwidth': int(rep.get('bandwidth') or 0),
                'height': int(rep.get('height') or aset.get('height') or 0),
                'width': int(rep.get('width') or aset.get('width') or 0),
                'lang': aset.get('lang') or '',
                'main': 'main' in roles,
                'order': len(result[ctype]),
            })
    return result


def _video_candidates(reps, max_height):
    pool = [r for r in reps if r['mime'] == 'video/mp4' and r['codecs'].startswith('avc1')]
    if not pool:
        pool = [r for r in reps if r['mime'] == 'video/mp4']
    if not pool:
        pool = list(reps)
    if max_height:
        fit = [r for r in pool if 0 < r['height'] <= max_height]
        if fit:
            pool = fit
        else:
            pool = sorted(pool, key=lambda r: r['height'] or 10 ** 6)[:1]
    return sorted(pool, key=lambda r: (r['height'], r['bandwidth']), reverse=True)


def _audio_candidates(reps):
    pool = [r for r in reps if r['mime'] == 'audio/mp4']
    if not pool:
        pool = list(reps)
    if not pool:
        return []
    main = [r for r in pool if r['main']]
    if main:
        pool = main
    else:
        first = min(pool, key=lambda r: r['order'])
        pool = [r for r in pool if r['lang'] == first['lang']]
    return sorted(pool, key=lambda r: r['bandwidth'], reverse=True)


def _ext(rep):
    mime = rep['mime']
    if mime == 'video/webm':
        return '.webm'
    if mime == 'audio/webm':
        return '.webm'
    if mime.startswith('audio/'):
        return '.m4a'
    return '.mp4'


def _publish(src, dest_dir, name):
    dest = _unique(os.path.join(dest_dir, name))
    try:
        shutil.copyfile(src, dest)
    except Exception as e:
        logger.debug('copyfile failed ({0}), trying xbmcvfs'.format(e), _TAG)
        if not xbmcvfs.copy(src, dest):
            raise DownloadError('cannot write to ' + dest_dir)
    logger.info('saved {0} ({1} bytes)'.format(dest, os.path.getsize(src)), _TAG)
    return dest


def _cleanup(folder):
    try:
        shutil.rmtree(folder, ignore_errors=True)
    except Exception:
        pass


def _load_manifest(video_id, audio_only=False):
    stream = player.resolve(video_id, audio_only=audio_only)
    if not stream:
        raise DownloadError('resolve returned nothing (live stream or unavailable)')
    headers = {}
    if '|' in stream:
        stream, _, hdr = stream.rpartition('|')
        headers = dict(parse_qsl(hdr))
    return stream, headers


def _run(video_id, title, prog, work, mode):
    max_height = _int_setting('download_max_height', 0)
    safe = _sanitize(title or video_id)
    logger.info('start id={0} mode={1} max_height={2}'.format(video_id, mode, max_height), _TAG)

    prog.set_line(kodi.i18n(30066))
    stream, headers = _load_manifest(video_id, audio_only=(mode == 1))
    logger.debug('resolved: {0}'.format(stream), _TAG)

    if '.m3u8' in stream:
        raise DownloadError('hls streams not supported')

    dest_dir = _get_path()

    if not stream.split('?')[0].endswith('.mpd'):
        part = os.path.join(work, 'single.bin')
        prog.set_line(kodi.i18n(30068 if mode == 1 else 30067))
        _download_file({'url': stream, 'bandwidth': 0, 'id': 'single', 'nopace': True}, part, prog, headers)
        return [_publish(part, dest_dir, safe + ('.m4a' if mode == 1 else '.mp4'))]

    manifest = _parse_mpd(_fetch_text(stream))
    logger.debug('manifest: {0} video, {1} audio representations'.format(
        len(manifest['video']), len(manifest['audio'])), _TAG)
    audio_c = _audio_candidates(manifest['audio'])
    video_c = [] if mode == 1 else _video_candidates(manifest['video'], max_height)
    if mode == 1 and not audio_c:
        raise DownloadError('no audio representation')
    if mode != 1 and not video_c:
        raise DownloadError('no video representation')

    def refresher(kind):
        def make(rep):
            def refresh():
                try:
                    new_stream, _h = _load_manifest(video_id)
                    fresh = _parse_mpd(_fetch_text(new_stream))
                    for r in fresh[kind]:
                        if r['id'] == rep['id'] and r['mime'] == rep['mime']:
                            return r['url']
                except Exception as e:
                    logger.debug('refresh failed: {0}'.format(e), _TAG)
                return None
            return refresh
        return make

    total = 0
    for cands in (video_c, audio_c):
        if cands:
            try:
                total += _content_length(cands[0]['url'], headers)
            except Exception as e:
                logger.debug('size probe failed: {0}'.format(e), _TAG)
    prog.set_total(total + total // 20)

    video = audio = None
    v_path = a_path = None
    if video_c:
        v_path = os.path.join(work, 'video.part')
        prog.set_line(kodi.i18n(30067))
        video = _fetch_with_fallback(video_c, v_path, prog, headers, refresher('video'))
        logger.info('video: {0}p {1} {2} bw={3}'.format(
            video['height'], video['mime'], video['codecs'], video['bandwidth']), _TAG)
    if audio_c:
        a_path = os.path.join(work, 'audio.part')
        prog.set_line(kodi.i18n(30068))
        audio = _fetch_with_fallback(audio_c, a_path, prog, headers, refresher('audio'))
        logger.info('audio: {0} {1} bw={2}'.format(
            audio['mime'], audio['codecs'], audio['bandwidth']), _TAG)

    if not video:
        return [_publish(a_path, dest_dir, safe + _ext(audio))]

    if audio and video['mime'] == 'video/mp4' and audio['mime'] == 'audio/mp4':
        merged = os.path.join(work, 'merged.mp4')
        prog.set_line(kodi.i18n(30069))
        try:
            mp4mux.merge(v_path, a_path, merged, progress=prog.add)
            return [_publish(merged, dest_dir, safe + '.mp4')]
        except mp4mux.MuxError as e:
            logger.error('merge failed: {0}, saving separate files'.format(e), _TAG)

    saved = [_publish(v_path, dest_dir, safe + ' (video)' + _ext(video))]
    if a_path:
        saved.append(_publish(a_path, dest_dir, safe + ' (audio)' + _ext(audio)))
    return saved


def _choose_mode():
    mode = _int_setting('download_mode', 0)
    if kodi.setting('download_ask') == 'false':
        return mode
    labels = [kodi.i18n(30073), kodi.i18n(30074)]
    choice = xbmcgui.Dialog().select(kodi.i18n(30072), labels, preselect=mode if mode in (0, 1) else 0)
    return choice if choice >= 0 else None


def start(video_id, title=''):
    mode = _choose_mode()
    if mode is None:
        return
    work = os.path.join(kodi.transPath(kodi.cacheDirectory), 'download_' + _sanitize(video_id))
    _cleanup(work)
    os.makedirs(work, exist_ok=True)
    prog = _Progress(kodi.i18n(30060), kodi.i18n(30066))
    started = time.time()
    try:
        saved = _run(video_id, title, prog, work, mode)
        prog.close()
        logger.info('finished in {0:.1f}s'.format(time.time() - started), _TAG)
        kodi.infoDialog(kodi.i18n(30064) + ': ' + os.path.basename(saved[0]))
    except Cancelled:
        prog.close()
        logger.info('cancelled by user', _TAG)
        kodi.infoDialog(kodi.i18n(30071))
    except Exception as e:
        prog.close()
        logger.exception('download failed: {0}'.format(e), _TAG)
        kodi.infoDialog(kodi.i18n(30062))
    finally:
        _cleanup(work)
