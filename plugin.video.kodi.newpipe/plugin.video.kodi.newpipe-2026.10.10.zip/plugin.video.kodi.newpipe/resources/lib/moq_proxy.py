

import base64
import collections
import errno
import http.server
import json
import os
import queue
import re
import socketserver
import threading
import time
import urllib.parse
import urllib.error
import urllib.request

try:
    import xbmc
    import xbmcaddon
except ImportError:
    xbmc = None
    xbmcaddon = None

try:
    import websocket
except ImportError:
    websocket = None

DEFAULT_PORT = 50199
PROXY_VERSION = '2026.10.14-r4'
PORT_SPAN = 30
DEFAULT_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
)

ADDON_ID = 'script.module.resolveurl.pluginsgr'

_YT_ENGINE_TEMP = 'special://temp/plugin.video.youtube'


def _yt_mpd_path(video_id):
    try:
        from ytresolver.kodion.constants import TEMP_PATH as _engine_temp
        base = _engine_temp
    except Exception:
        base = _YT_ENGINE_TEMP
    try:
        import xbmcvfs
        translated = xbmcvfs.translatePath(base)
        if translated:
            base = translated
    except Exception:
        pass
    if base.startswith('special://'):
        return None
    return os.path.join(base, video_id + '.mpd')


g_proxy_server = None
g_proxy_thread = None
g_stream_manager = None
g_external_port = None
g_yt_mpds = {}
_YT_MPD_MAX = 50
_YT_CHUNK = 4 * 1024 * 1024
g_failed_hosts = {}
g_variant = [0]
g_source_pref = {}
_FAILED_HOST_TTL = 300.0
_YT_ORIGIN_RE = re.compile(r'https?://[^/"\'\s]+(/youtube/(?:stream|manifest)[^"\'\s]*)')
_shutdown = threading.Event()
_lock = threading.Lock()


def _log(msg, level=None):
    try:
        try:
            from resources.lib import logger as _lg
        except ImportError:
            import logger as _lg
        text = str(msg)
        if text.lower().startswith(('error', 'timeout')) or ' failed' in text.lower():
            _lg.error(text, 'proxy')
        else:
            _lg.debug(text, 'proxy')
    except Exception:
        pass


def _get_ua():
    try:
        from resolveurl import common
        ua = getattr(common, 'RAND_UA', None)
        if ua:
            return ua
    except Exception:
        pass
    return DEFAULT_UA


def get_proxy_port(default=DEFAULT_PORT):
    if xbmcaddon is not None:
        try:
            value = xbmcaddon.Addon(ADDON_ID).getSetting('proxy_port')
            if value not in (None, ''):
                return int(value)
        except Exception:
            pass
    return default


class StreamManager:

    def __init__(self, ws_url, origin=None):

        self.ws_url = ws_url
        self.origin = origin
        self.ws = None
        self.audio_ids = set()
        self.video_ids = set()

        self.video_init_tag = None
        self.audio_init_tag = None
        self.media_buffer = collections.deque(maxlen=150)
        self.clients = []
        self.stop_event = threading.Event()
        self.init_ready = threading.Event()
        self.first_ts = None

        self.last_active_time = time.time()

        self.thread = threading.Thread(target=self._ws_reader, daemon=True)
        self.ping_thread = None
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.ws:
            try:
                self.ws.close()
            except Exception:
                pass

    def write_flv_tag(self, tag_type, timestamp_ms, payload):
        tag = bytearray()
        tag.append(tag_type)
        tag.extend(len(payload).to_bytes(3, 'big'))
        tag.extend((timestamp_ms & 0xFFFFFF).to_bytes(3, 'big'))
        tag.append((timestamp_ms >> 24) & 0xFF)
        tag.extend(b'\x00\x00\x00')
        tag.extend(payload)
        tag.extend((11 + len(payload)).to_bytes(4, 'big'))
        return tag

    def _pinger(self):

        while not self.stop_event.is_set():
            if self.stop_event.wait(5.0):
                break
            try:
                if self.ws and getattr(self.ws, 'connected', True):
                    self.ws.send(json.dumps({"type": "ping"}))
            except Exception:
                break

    def _ws_reader(self):
        _log(f'Connecting MoQ WSS... {self.ws_url}')
        if websocket is None:
            _log('websocket module not available, cannot proxy MoQ stream')
            self.init_ready.set()
            return

        headers = {
            'User-Agent': _get_ua(),
            'Origin': self.origin
        }

        try:

            self.ws = websocket.create_connection(self.ws_url, header=headers, timeout=15)
            _log('MoQ connected. Awaiting handshakes...')

            self.ping_thread = threading.Thread(target=self._pinger, daemon=True)
            self.ping_thread.start()

            while not self.stop_event.is_set():

                if len(self.clients) > 0:
                    self.last_active_time = time.time()
                elif time.time() - self.last_active_time > 10.0:
                    _log('No clients active for 10s. Auto-closing stream.')
                    self.stop()
                    break

                msg = self.ws.recv()
                if not msg:
                    continue

                if isinstance(msg, str):
                    try:
                        data = json.loads(msg)
                        msg_type = data.get('type')

                        if msg_type in ('ping', 'pong'):
                            continue

                        if msg_type == 'renditions':
                            for r in data.get('renditions', []):
                                codec = r.get('codec', '')
                                if codec in ('aac', 'mp3', 'opus'):
                                    self.audio_ids.add(r['id'])
                                elif codec in ('h264', 'h265', 'av1'):
                                    self.video_ids.add(r['id'])
                            _log(f'Mapped Video IDs {self.video_ids}, Audio IDs {self.audio_ids}')
                    except Exception:
                        pass
                    continue

                elif isinstance(msg, bytes):
                    if len(msg) < 17:
                        continue

                    offset = int.from_bytes(msg[1:3], 'big')
                    flags = msg[3]
                    rend_id = msg[4]
                    timestamp = int.from_bytes(msg[5:13], 'big')
                    timescale = int.from_bytes(msg[13:17], 'big')
                    if timescale == 0:
                        timescale = 1000

                    if self.first_ts is None:
                        self.first_ts = timestamp
                    ts_ms = max(0, int((timestamp - self.first_ts) * 1000 / timescale))

                    comp_time = 0
                    if flags & 16 and len(msg) >= 19:
                        comp_time = int.from_bytes(msg[17:19], 'big', signed=True)
                    comp_time_ms = int(comp_time * 1000 / timescale)

                    payload = msg[offset:]
                    is_init = bool(flags & 2)
                    is_sync = bool(flags & 1)

                    tag = None

                    if rend_id in self.video_ids:
                        payload_wrap = bytearray()
                        if is_init:
                            payload_wrap.extend(b'\x17\x00\x00\x00\x00')
                        else:
                            payload_wrap.append(0x17 if is_sync else 0x27)
                            payload_wrap.append(0x01)
                            payload_wrap.extend((comp_time_ms & 0xFFFFFF).to_bytes(3, 'big'))

                        payload_wrap.extend(payload)
                        tag = self.write_flv_tag(9, ts_ms, payload_wrap)

                        if is_init:
                            if not self.video_init_tag:
                                _log('Captured H.264 INIT.')
                            self.video_init_tag = tag

                    elif rend_id in self.audio_ids:
                        payload_wrap = bytearray()
                        payload_wrap.append(0xAF)
                        payload_wrap.append(0x00 if is_init else 0x01)
                        payload_wrap.extend(payload)
                        tag = self.write_flv_tag(8, ts_ms, payload_wrap)

                        if is_init:
                            if not self.audio_init_tag:
                                _log('Captured AAC INIT.')
                            self.audio_init_tag = tag

                    if tag:
                        if is_init:
                            if self.video_init_tag:
                                self.init_ready.set()
                        else:
                            self.media_buffer.append(tag)
                            for client_q in list(self.clients):
                                try:
                                    client_q.put_nowait(tag)
                                except queue.Full:
                                    pass

        except Exception as e:
            if not self.stop_event.is_set():
                _log(f'WSS Loop Error: {e}')
        finally:
            self.init_ready.set()
            _log('WSS Background Thread Closed')


class ProxyRequestHandler(http.server.BaseHTTPRequestHandler):

    def end_headers(self):
        self.send_header('X-Proxy-Version', PROXY_VERSION)
        super().end_headers()

    def do_HEAD(self):

        path = urllib.parse.urlparse(self.path).path
        if path.endswith('.mpd'):
            self.send_response(200)
            self.send_header('Content-Type', 'application/dash+xml')
            self.end_headers()
            return

        if '.m3u8' in self.path:
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.end_headers()
            return

        self.send_response(200)
        self.send_header('Content-Type', 'video/x-flv')
        self.end_headers()

    def _serve_yt_mpd(self, video_id):
        with _lock:
            xml = g_yt_mpds.get(video_id)
        if not xml:
            path = _yt_mpd_path(video_id)
            if path:
                try:
                    with open(path, 'rb') as f:
                        xml = f.read()
                except OSError:
                    xml = None
        if not xml:
            self.send_error(404, 'Unknown MPD')
            return
        try:
            port = self.server.server_address[1]
            text = xml.decode('utf-8')
            text = _YT_ORIGIN_RE.sub(
                lambda m: 'http://127.0.0.1:{0}{1}'.format(port, m.group(1)), text)
            body = text.encode('utf-8')
        except Exception:
            self.send_error(500, 'MPD rewrite failed')
            return
        self.send_response(200)
        self.send_header('Content-Type', 'application/dash+xml')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:
            pass

    def _relay_yt_stream(self, query):
        headers_b64 = ''
        hosts = []
        path = '/videoplayback'
        method = 'POST'
        keep = []
        alt_values = []
        for part in (query or '').split('&'):
            if not part or '=' not in part:
                continue
            raw_key, raw_value = part.split('=', 1)
            key = urllib.parse.unquote(raw_key)
            if key == '__headers':
                headers_b64 = raw_value
            elif key == '__host':
                hosts.append(urllib.parse.unquote(raw_value))
            elif key == '__path':
                path = urllib.parse.unquote(raw_value) or path
            elif key == '__method':
                method = (urllib.parse.unquote(raw_value) or method).upper()
            elif key == '__alt':
                alt_values.append(raw_value)
            elif key.startswith('__'):
                continue
            elif key == 'range':
                continue
            else:
                keep.append(part)

        if not hosts:
            self.send_error(400, 'No upstream host')
            return

        sources = [{
            'hosts': hosts,
            'path': path,
            'keep': keep,
            'headers': _clean_headers(_decode_b64_json(headers_b64)),
            'method': method,
            'total': _clen(keep),
        }]
        for value in alt_values:
            data = _decode_b64_json(value)
            alt_url = data.get('u')
            if not alt_url:
                continue
            source = _source_from_url(alt_url, _clean_headers(data.get('h') or {}), (data.get('m') or 'GET').upper())
            if source and (sources[0]['total'] is None or source['total'] is None or source['total'] == sources[0]['total']):
                sources.append(source)

        total = sources[0]['total']
        pref_key = '|'.join(p for p in keep if p.startswith(('id=', 'itag=')))

        req_start, req_end, ranged = _parse_range(self.headers.get('Range'), total)
        if req_end is None:
            if total is not None:
                req_end = total - 1
            else:
                req_end = req_start + _YT_CHUNK - 1
        if total is not None and req_start >= total:
            self.send_response(416)
            self.send_header('Content-Range', 'bytes */{0}'.format(total))
            self.send_header('Content-Length', '0')
            self.end_headers()
            return

        sent_headers = False
        pos = req_start
        final_end = req_end
        content_type = 'video/mp4'

        while pos <= final_end:
            if _shutdown.is_set():
                return
            chunk_end = min(final_end, pos + _YT_CHUNK - 1)
            body = None

            order = list(range(len(sources)))
            pref = g_source_pref.get(pref_key, 0)
            if 0 < pref < len(order):
                order.insert(0, order.pop(pref))

            for si in order:
                src = sources[si]
                now = time.time()
                with _lock:
                    for h in [h for h, ts in g_failed_hosts.items() if now - ts >= _FAILED_HOST_TTL]:
                        del g_failed_hosts[h]
                    alive = [h for h in src['hosts'] if h not in g_failed_hosts]
                    failed = [h for h in src['hosts'] if h in g_failed_hosts]
                ordered_hosts = alive + failed

                variants = [
                    (src['method'], True, True),
                    (src['method'], False, True),
                    ('GET' if src['method'] == 'POST' else 'POST', True, True),
                    ('GET' if src['method'] == 'POST' else 'POST', False, True),
                    (src['method'], True, False),
                ]
                first = g_variant[0] % len(variants)
                variant_order = [variants[first]] + [v for i, v in enumerate(variants) if i != first]

                for idx, host in enumerate(ordered_hosts):
                    is_last = (idx == len(ordered_hosts) - 1)
                    for variant in variant_order:
                        v_method, use_param, use_header = variant
                        qs = list(src['keep'])
                        if use_param:
                            qs.append('range={0}-{1}'.format(pos, chunk_end))
                        url = 'https://{0}{1}?{2}'.format(host, src['path'], '&'.join(qs))
                        req_headers = dict(src['headers'])
                        if use_header:
                            req_headers['Range'] = 'bytes={0}-{1}'.format(pos, chunk_end)
                        try:
                            status, body, resp_headers = _fetch_upstream(
                                url, req_headers, v_method, timeout=20 if is_last else 8)
                            lowered = {k.lower(): v for k, v in resp_headers.items()}
                            got_range = lowered.get('content-range', '')
                            match = re.match(r'bytes (\d+)-(\d+)/(\d+|\*)', got_range)
                            if match:
                                got_start = int(match.group(1))
                                if got_start != pos:
                                    raise ValueError('range mismatch {0} != {1}'.format(got_start, pos))
                                if match.group(3) != '*':
                                    total = int(match.group(3))
                            elif len(body) > chunk_end - pos + 1:
                                body = body[pos:chunk_end + 1]
                            if not body:
                                raise ValueError('empty body')
                            content_type = lowered.get('content-type', content_type)
                            with _lock:
                                g_failed_hosts.pop(host, None)
                                g_variant[0] = variants.index(variant)
                                g_source_pref[pref_key] = si
                            break
                        except Exception as e:
                            body = None
                            _log(f'YT relay failed: source={si} host={host} variant={variant} range={pos}-{chunk_end} error={e}')
                    if body is not None:
                        break
                    with _lock:
                        g_failed_hosts[host] = time.time()
                if body is not None:
                    break

            if body is None:
                if not sent_headers:
                    self.send_error(502, 'Upstream fetch failed')
                return

            if total is not None:
                final_end = min(final_end, total - 1)
            body = body[:final_end - pos + 1]

            if not sent_headers:
                length = final_end - req_start + 1
                if ranged:
                    self.send_response(206)
                    self.send_header('Content-Range', 'bytes {0}-{1}/{2}'.format(
                        req_start, final_end, total if total is not None else '*'))
                else:
                    self.send_response(200)
                self.send_header('Content-Type', content_type)
                self.send_header('Accept-Ranges', 'bytes')
                self.send_header('Content-Length', str(length))
                self.end_headers()
                sent_headers = True

            try:
                self.wfile.write(body)
            except Exception:
                return
            pos += len(body)

    def do_GET(self):

        global g_stream_manager

        if _shutdown.is_set():
            self.send_error(503, 'Proxy is shutting down')
            return

        parsed = urllib.parse.urlparse(self.path)

        mpd_match = re.match(r'/yt/([\w-]{11})\.mpd$', parsed.path)
        if mpd_match:
            self._serve_yt_mpd(mpd_match.group(1))
            return

        if parsed.path.startswith('/youtube/stream'):
            self._relay_yt_stream(parsed.query)
            return

        if '.m3u8' in self.path:
            try:
                query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                vid_b64 = query['stream'][0]
                vid_url_with_headers = base64.urlsafe_b64decode(vid_b64).decode('utf-8')

                parts = vid_url_with_headers.split('|', 1)
                url = parts[0]
                headers = {'User-Agent': _get_ua()}
                if len(parts) > 1 and parts[1]:
                    header_pairs = parts[1].split('&')
                    for pair in header_pairs:
                        if '=' in pair:
                            key, value = pair.split('=', 1)
                            headers[key] = urllib.parse.unquote(value)

                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=15) as response:
                    content = response.read()

                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Content-Length', str(len(content)))
                self.end_headers()
                self.wfile.write(content)

            except Exception as e:

                _log(f'M3U8 proxy error: {e}')
                self.send_error(500, f"M3U8 proxy error: {e}")

            return

        elif '?ws=' in self.path:
            try:
                parsed = urllib.parse.urlparse(self.path)
                qs = urllib.parse.parse_qs(parsed.query)
                ws_b64 = qs['ws'][0]
                ws_url = base64.urlsafe_b64decode(ws_b64).decode('utf-8')
                origin = qs.get('origin', [None])[0]

                if not g_stream_manager or g_stream_manager.ws_url != ws_url or g_stream_manager.stop_event.is_set():
                    if g_stream_manager:
                        g_stream_manager.stop()
                    _log('Booting Stream Manager...')
                    g_stream_manager = StreamManager(ws_url, origin)
            except Exception as e:
                self.send_error(400, f"Invalid WSS parameter: {e}")
                return

        manager = g_stream_manager
        if manager is None:
            self.send_error(404, "Stream not initialized")
            return

        self.send_response(200)
        self.send_header('Content-Type', 'video/x-flv')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

        deadline = time.time() + 15.0
        while not manager.init_ready.is_set():
            if _shutdown.is_set():
                return
            if time.time() >= deadline:
                _log('Timeout waiting for MoQ Media.')
                return
            manager.init_ready.wait(0.25)

        try:
            self.wfile.write(b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00')

            if manager.video_init_tag:
                self.wfile.write(manager.video_init_tag)
            if manager.audio_init_tag:
                self.wfile.write(manager.audio_init_tag)

            for tag in list(manager.media_buffer):
                self.wfile.write(tag)
        except (ConnectionResetError, BrokenPipeError):
            _log('Probe check finished.')
            return
        except Exception:
            return

        client_q = queue.Queue(maxsize=300)
        manager.clients.append(client_q)
        _log('FLV muxing live to player...')

        idle_deadline = time.time() + 15.0
        try:
            while not _shutdown.is_set():
                try:
                    tag = client_q.get(timeout=0.25)
                except queue.Empty:
                    if time.time() >= idle_deadline:
                        break
                    continue
                idle_deadline = time.time() + 15.0
                self.wfile.write(tag)
        except Exception:
            pass
        finally:
            if manager and client_q in manager.clients:
                manager.clients.remove(client_q)

    def log_message(self, format, *args):
        return


class ThreadedHttpServer(socketserver.ThreadingMixIn, http.server.HTTPServer):

    allow_reuse_address = True
    daemon_threads = True


def _probe_existing(port):
    try:
        req = urllib.request.Request(f'http://127.0.0.1:{port}/', method='HEAD')
        try:
            resp = urllib.request.urlopen(req, timeout=1.0)
        except urllib.error.HTTPError as e:
            try:
                e.close()
            except Exception:
                pass
            return False
        try:
            return resp.status == 200 and resp.headers.get('X-Proxy-Version') == PROXY_VERSION
        finally:
            try:
                resp.close()
            except Exception:
                pass
    except Exception:
        return False


def start_server(port=None):

    global g_proxy_server, g_proxy_thread, g_external_port

    with _lock:
        if g_proxy_server:
            try:
                return g_proxy_server.server_address[1]
            except Exception:
                pass
        if g_external_port is not None:
            return g_external_port

        base_port = get_proxy_port() if port is None else port

        for bind_port in range(base_port, base_port + PORT_SPAN):
            try:
                server = ThreadedHttpServer(('', bind_port), ProxyRequestHandler)
            except OSError as e:
                if getattr(e, 'errno', None) == errno.EADDRINUSE:
                    if _probe_existing(bind_port):
                        _log(f'Port {bind_port} is already served by a current proxy')
                        g_external_port = bind_port
                        return bind_port
                    continue
                _log(f'Failed to start proxy on port {bind_port}: {e}')
                return None
            except Exception as e:
                _log(f'Failed to start proxy on port {bind_port}: {e}')
                return None

            _shutdown.clear()
            g_proxy_server = server
            actual_port = server.server_address[1]
            g_proxy_thread = threading.Thread(
                target=server.serve_forever, kwargs={'poll_interval': 0.25},
                daemon=True, name='PluginsGRProxyServe'
            )
            g_proxy_thread.start()

            _log(f'Listening on {actual_port} version {PROXY_VERSION}')
            return actual_port

        _log(f'No free proxy port in {base_port}-{base_port + PORT_SPAN - 1}')
        return None


def stop_server():

    global g_proxy_server, g_proxy_thread, g_stream_manager, g_external_port, g_yt_mpds, g_failed_hosts

    _shutdown.set()

    with _lock:
        manager, g_stream_manager = g_stream_manager, None
        server, g_proxy_server = g_proxy_server, None
        thread, g_proxy_thread = g_proxy_thread, None
        g_external_port = None
        g_yt_mpds = {}
        g_failed_hosts = {}

    if manager is not None:
        try:
            manager.stop()
        except Exception:
            pass
        try:
            if manager.thread is not None:
                manager.thread.join(timeout=3.0)
        except Exception:
            pass
        try:
            if manager.ping_thread is not None:
                manager.ping_thread.join(timeout=3.0)
        except Exception:
            pass

    if server is not None:
        try:
            server.shutdown()
        except Exception:
            pass
        try:
            server.server_close()
        except Exception:
            pass

    if thread is not None:
        try:
            thread.join(timeout=3.0)
        except Exception:
            pass


def run_service():

    monitor = xbmc.Monitor() if xbmc is not None and hasattr(xbmc, 'Monitor') else None

    start_server()

    if monitor is None:
        return

    try:
        while not monitor.abortRequested():
            if monitor.waitForAbort(1.0):
                break
    finally:
        _log('Service stopping proxy')
        stop_server()


def stop_stream():
    global g_stream_manager

    with _lock:
        if g_stream_manager:
            g_stream_manager.stop()
            g_stream_manager = None


def _fetch_upstream(url, headers, method='GET', timeout=20):
    data = b'' if method == 'POST' else None
    req = urllib.request.Request(url, data=data, headers=dict(headers or {}), method=method)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, resp.read(), dict(resp.headers)


def _decode_b64_json(value):
    try:
        raw = urllib.parse.unquote(value or '')
        raw += '=' * (-len(raw) % 4)
        data = json.loads(base64.urlsafe_b64decode(raw.encode('utf-8')).decode('utf-8'))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _clean_headers(headers):
    out = {str(k): str(v) for k, v in (headers or {}).items()
           if str(k).lower() not in ('range', 'content-length', 'accept-encoding', 'host')}
    out['Accept-Encoding'] = 'identity'
    return out


def _clen(keep):
    for part in keep:
        if part.startswith('clen='):
            try:
                return int(part.split('=', 1)[1])
            except ValueError:
                return None
    return None


def _hosts_for(hostname, query):
    hosts = [hostname]
    params = dict(urllib.parse.parse_qsl(query, keep_blank_values=True))
    if 'mn' in params and 'fvip' in params and hostname:
        primary, _, secondary = params['mn'].partition(',')
        prefix, separator, server = hostname.partition('---')
        if primary and secondary and separator:
            hosts.append(separator.join((
                re.sub(r'\d+', params['fvip'], prefix),
                server.replace(primary, secondary))))
    return hosts


def _source_from_url(url, headers, method):
    parts = urllib.parse.urlsplit(url)
    if not parts.hostname:
        return None
    keep = [p for p in parts.query.split('&') if p and not p.startswith('range=')]
    return {
        'hosts': _hosts_for(parts.hostname, parts.query),
        'path': parts.path or '/videoplayback',
        'keep': keep,
        'headers': headers,
        'method': method,
        'total': _clen(keep),
    }


def _b64_json(data):
    return base64.urlsafe_b64encode(json.dumps(data).encode('utf-8')).decode('utf-8')


def build_relay_url(url, headers=None, method='GET', alternates=None, port=None):
    bound_port = _bound_port(port)
    parts = urllib.parse.urlsplit(url)
    query = [p for p in parts.query.split('&') if p and not p.startswith('range=')]
    for host in _hosts_for(parts.hostname, parts.query):
        query.append('__host=' + urllib.parse.quote(host, safe=''))
    query.append('__path=' + urllib.parse.quote(parts.path or '/videoplayback', safe=''))
    query.append('__method=' + method)
    query.append('__headers=' + urllib.parse.quote(_b64_json(dict(headers or {})), safe=''))
    for alt in (alternates or [])[:3]:
        query.append('__alt=' + urllib.parse.quote(_b64_json({
            'u': alt.get('url'), 'h': dict(alt.get('headers') or {}), 'm': alt.get('method') or method,
        }), safe=''))
    return 'http://127.0.0.1:{0}/youtube/stream?{1}'.format(bound_port, '&'.join(query))


def _parse_range(value, total):
    if not value:
        return 0, (total - 1 if total is not None else None), False
    match = re.match(r'\s*bytes\s*=\s*(\d*)\s*-\s*(\d*)', value)
    if not match:
        return 0, (total - 1 if total is not None else None), False
    first, last = match.group(1), match.group(2)
    if first == '' and last != '' and total is not None:
        length = int(last)
        return max(0, total - length), total - 1, True
    start = int(first) if first else 0
    end = int(last) if last else None
    if end is not None and total is not None:
        end = min(end, total - 1)
    return start, end, True


def _open_upstream(url, headers, method='GET', timeout=20):
    data = b'' if method == 'POST' else None
    req = urllib.request.Request(url, data=data, headers=dict(headers or {}), method=method)
    resp = urllib.request.urlopen(req, timeout=timeout)
    return resp, dict(resp.headers)


def serve_yt_mpd(video_id, xml_bytes=None):
    if xml_bytes is not None:
        if isinstance(xml_bytes, str):
            xml_bytes = xml_bytes.encode('utf-8')
        with _lock:
            g_yt_mpds.pop(video_id, None)
            g_yt_mpds[video_id] = xml_bytes or b''
            while len(g_yt_mpds) > _YT_MPD_MAX:
                g_yt_mpds.pop(next(iter(g_yt_mpds)))
    return build_yt_mpd_url(video_id)


def build_yt_mpd_url(video_id):
    bound_port = _bound_port(None)
    return f'http://127.0.0.1:{bound_port}/yt/{video_id}.mpd'


def _bound_port(port):
    bound = start_server(port=port)
    if bound is not None:
        return bound
    return get_proxy_port() if port is None else port


def build_ws_proxy_url(ws_url, origin=None, port=None, path='live.flv'):
    bound_port = _bound_port(port)
    ws_b64 = base64.urlsafe_b64encode(ws_url.encode('utf-8')).decode('utf-8')
    if origin:
        origin_q = urllib.parse.quote(origin, safe='')
        return f'http://127.0.0.1:{bound_port}/{path}?ws={ws_b64}&origin={origin_q}'
    return f'http://127.0.0.1:{bound_port}/{path}?ws={ws_b64}'


def build_m3u8_proxy_url(target_url, headers=None, port=None):
    bound_port = _bound_port(port)
    payload = target_url
    if headers:
        pairs = '&'.join(f'{k}={urllib.parse.quote(str(v), safe="")}' for k, v in headers.items())
        payload = f'{target_url}|{pairs}'
    stream_b64 = base64.urlsafe_b64encode(payload.encode('utf-8')).decode('utf-8')
    return f'http://127.0.0.1:{bound_port}/proxy.m3u8?stream={stream_b64}'


def build_yt_stream_url(url, port=None):
    bound_port = _bound_port(port)
    return _YT_ORIGIN_RE.sub(
        lambda m: f'http://127.0.0.1:{bound_port}{m.group(1)}', url)

