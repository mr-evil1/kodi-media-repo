import inspect
import os
import sys
from urllib.parse import parse_qsl, urlencode

from resolveurl import add_plugin_dirs
from resolveurl.hmf import HostedMediaFile
from . import directory, kodi
from .kodi import log
from . import logger
from .constants import YT_WATCH

_LIB_DIR = os.path.dirname(os.path.abspath(__file__))
_PLUGINS_DIR = os.path.join(_LIB_DIR, 'resolveurl_plugins')


def _ensure_lib_path():
    if _LIB_DIR not in sys.path:
        sys.path.insert(0, _LIB_DIR)


def _audio_stream(resolver, url):
    spec = inspect.getfullargspec(resolver.get_media_url)
    if 'audio_only' not in (spec.args or []) + (spec.kwonlyargs or []):
        return None
    host, media_id = resolver.get_host_and_id(url)
    res = resolver.get_media_url(host, media_id, audio_only=True)
    if isinstance(res, (tuple, list)):
        res = res[0]
    return res


def resolve(video_id, audio_only=False):
    _ensure_lib_path()
    url = video_id if (video_id or '').startswith('http') else YT_WATCH + video_id
    logger.debug('resolve {0} audio_only={1}'.format(url, audio_only), 'player')
    add_plugin_dirs(kodi.transPath(_PLUGINS_DIR))
    hmf = HostedMediaFile(url)
    if not hmf.valid_url():
        return None
    if audio_only:
        try:
            for resolver in hmf.get_resolvers(validated=True):
                stream = _audio_stream(resolver, url)
                if stream:
                    return stream
        except Exception as e:
            logger.exception('audio-only resolve failed: {0}'.format(e), 'player')
    try:
        result = hmf.resolve() or None
        logger.debug('resolve result: {0}'.format(result), 'player')
        return result
    except Exception as e:
        logger.exception('resolve failed: {0}'.format(e), 'player')
        return None


def _isa_enabled():
    try:
        return kodi.addon_details('inputstream.adaptive').get('enabled')
    except Exception:
        return False


def play(video_id, title='', image=''):
    audio_only = kodi.setting('audio_only') == 'true'
    stream = resolve(video_id, audio_only=audio_only)

    if not stream:
        kodi.infoDialog('No playable stream found')
        import sys as _sys
        kodi.resolve(int(_sys.argv[1]), False, kodi.item())
        return

    if '|' in stream:
        stream, _, headers = stream.rpartition('|')
        stream = '|'.join([stream, urlencode(dict(parse_qsl(headers)))])

    dash = ('.mpd' in stream or 'dash' in stream) and _isa_enabled()

    logger.info('playing: {0}'.format(stream), 'player')
    directory.resolve(
        stream, meta={'title': title}, icon=image,
        dash=bool(dash), manifest_type='mpd' if dash else None,
    )
