from . import kodi
from .cache import FunctionCache

_fc = FunctionCache(kodi.cacheDirectory)
cache_function = _fc.cache_function
reset_cache = _fc.reset_cache

ADDON_ID = 'plugin.video.kodi.newpipe'
YT_WATCH = 'https://www.youtube.com/watch?v='


def cache_duration(minutes):
    if kodi.setting('debug') == 'true':
        return 0
    return minutes
