import logging
import os
import re
import threading
import time
import traceback

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
except ImportError:
    xbmc = None
    xbmcaddon = None
    xbmcvfs = None

ADDON_ID = 'plugin.video.kodi.newpipe'
LEVEL_ERROR = 0
LEVEL_INFO = 1
LEVEL_DEBUG = 2
_NAMES = {LEVEL_ERROR: 'ERROR', LEVEL_INFO: 'INFO', LEVEL_DEBUG: 'DEBUG'}
_MAX_FILE_SIZE = 1024 * 1024
_CACHE_TTL = 2.0
_SECRET_RE = re.compile(
    r'(?i)\b(sig|lsig|signature|pot|key|token|visitor|__headers|cookie|authorization)=([^&\s\'"|]+)')

_lock = threading.Lock()
_state = {'ts': 0.0, 'enabled': False, 'level': LEVEL_INFO, 'to_file': False}
_file_path = None
_engine_handler = None


def _read_settings():
    now = time.time()
    if now - _state['ts'] < _CACHE_TTL:
        return _state
    enabled = False
    level = LEVEL_INFO
    to_file = False
    if xbmcaddon is not None:
        try:
            addon = xbmcaddon.Addon(ADDON_ID)
            enabled = addon.getSetting('logging_enabled') == 'true'
            raw = addon.getSetting('log_level')
            level = int(raw) if raw not in (None, '') else LEVEL_INFO
            to_file = addon.getSetting('log_to_file') == 'true'
        except Exception:
            pass
    _state.update(ts=now, enabled=enabled, level=level, to_file=to_file)
    return _state


def refresh():
    _state['ts'] = 0.0
    configure_engine()


def redact(text):
    return _SECRET_RE.sub(lambda m: m.group(1) + '=<redacted>', str(text))


def log_file_path():
    global _file_path
    if _file_path:
        return _file_path
    if xbmcvfs is None:
        return None
    try:
        base = xbmcvfs.translatePath('special://profile/addon_data/' + ADDON_ID + '/')
        os.makedirs(base, exist_ok=True)
        _file_path = os.path.join(base, 'newpipe.log')
    except Exception:
        _file_path = None
    return _file_path


def _write_file(line):
    path = log_file_path()
    if not path:
        return
    with _lock:
        try:
            if os.path.exists(path) and os.path.getsize(path) > _MAX_FILE_SIZE:
                old = path + '.old'
                if os.path.exists(old):
                    os.remove(old)
                os.replace(path, old)
            with open(path, 'a', encoding='utf-8') as f:
                f.write(line + '\n')
        except Exception:
            pass


def _emit(level, msg, tag):
    st = _read_settings()
    if not st['enabled'] or level > st['level']:
        return
    text = '[{0}] [{1}] {2}'.format(ADDON_ID, _NAMES.get(level, 'INFO'), redact(msg))
    if tag:
        text = '[{0}] [{1}] [{2}] {3}'.format(ADDON_ID, _NAMES.get(level, 'INFO'), tag, redact(msg))
    if xbmc is not None:
        try:
            xbmc.log(text, xbmc.LOGERROR if level == LEVEL_ERROR else xbmc.LOGINFO)
        except Exception:
            pass
    else:
        print(text)
    if st['to_file']:
        _write_file(time.strftime('%Y-%m-%d %H:%M:%S ') + text)


def error(msg, tag=''):
    _emit(LEVEL_ERROR, msg, tag)


def info(msg, tag=''):
    _emit(LEVEL_INFO, msg, tag)


def debug(msg, tag=''):
    _emit(LEVEL_DEBUG, msg, tag)


def exception(msg, tag=''):
    _emit(LEVEL_ERROR, '{0}\n{1}'.format(msg, traceback.format_exc()), tag)


def is_debug():
    st = _read_settings()
    return st['enabled'] and st['level'] >= LEVEL_DEBUG


def clear_file():
    path = log_file_path()
    if not path:
        return False
    ok = True
    with _lock:
        for p in (path, path + '.old'):
            try:
                if os.path.exists(p):
                    os.remove(p)
            except Exception:
                ok = False
    return ok


class _EngineHandler(logging.Handler):
    def emit(self, record):
        try:
            if record.levelno >= logging.ERROR:
                lvl = LEVEL_ERROR
            elif record.levelno >= logging.INFO:
                lvl = LEVEL_INFO
            else:
                lvl = LEVEL_DEBUG
            msg = record.getMessage()
            if record.exc_info:
                msg += '\n' + ''.join(traceback.format_exception(*record.exc_info))
            _emit(lvl, msg, 'engine')
        except Exception:
            pass


def configure_engine():
    global _engine_handler
    st = _read_settings()
    engine = logging.getLogger('ytresolver')
    if _engine_handler is None:
        _engine_handler = _EngineHandler()
        engine.addHandler(_engine_handler)
        engine.propagate = False
    if not st['enabled']:
        engine.setLevel(logging.CRITICAL + 1)
    elif st['level'] >= LEVEL_DEBUG:
        engine.setLevel(logging.DEBUG)
    elif st['level'] == LEVEL_INFO:
        engine.setLevel(logging.INFO)
    else:
        engine.setLevel(logging.ERROR)
