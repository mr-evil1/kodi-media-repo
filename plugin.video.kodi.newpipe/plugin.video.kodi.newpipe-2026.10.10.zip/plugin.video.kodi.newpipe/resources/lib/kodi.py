import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_ADDON = xbmcaddon.Addon()
ADDON_ID = _ADDON.getAddonInfo('id')
_ADDON_PATH = xbmcvfs.translatePath(_ADDON.getAddonInfo('path'))

syshandle = int(sys.argv[1])
dataPath = xbmcvfs.translatePath(_ADDON.getAddonInfo('profile'))
cacheDirectory = xbmcvfs.translatePath('special://temp/' + ADDON_ID + '/')
ICON = os.path.join(_ADDON_PATH, 'icon.png')
FANART = os.path.join(_ADDON_PATH, 'fanart.jpg')


def i18n(string_id):
    if isinstance(string_id, int):
        result = _ADDON.getLocalizedString(string_id)
        return result if result else str(string_id)
    return str(string_id) if string_id is not None else ''


def setting(key):
    return _ADDON.getSetting(key)


def openSettings():
    _ADDON.openSettings()


class _Dialog:
    def input(self, heading='', default=''):
        return xbmcgui.Dialog().input(str(heading))


dialog = _Dialog()


def infoDialog(msg, title=''):
    heading = str(title) if title else ADDON_ID
    xbmcgui.Dialog().notification(heading, str(msg), xbmcgui.NOTIFICATION_INFO, 3000)


def selectDialog(options, heading=''):
    return xbmcgui.Dialog().select(str(heading), [str(o) for o in options])


def refresh():
    xbmc.executebuiltin('Container.Refresh')


def close_all():
    xbmc.executebuiltin('Action(Back)')


def addonmedia(filename):
    return os.path.join(_ADDON_PATH, 'resources', 'media', filename)


def transPath(path):
    return xbmcvfs.translatePath(path)


def addon_details(addon_id):
    try:
        a = xbmcaddon.Addon(addon_id)
        return {'enabled': True, 'version': a.getAddonInfo('version')}
    except Exception:
        return {'enabled': False}


def item():
    return xbmcgui.ListItem()


def resolve(handle, succeeded, listitem):
    xbmcplugin.setResolvedUrl(handle, succeeded, listitem)


def set_setting(key, value):
    _ADDON.setSetting(key, str(value))


def log(msg, level=xbmc.LOGINFO):
    from . import logger
    if level >= xbmc.LOGERROR:
        logger.error(msg)
    elif level <= xbmc.LOGDEBUG:
        logger.debug(msg)
    else:
        logger.info(msg)
