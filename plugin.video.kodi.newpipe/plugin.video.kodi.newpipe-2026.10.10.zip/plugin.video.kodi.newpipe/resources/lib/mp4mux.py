import os
import struct

_CONTAINERS = (b'moov', b'trak', b'mdia', b'minf', b'stbl', b'edts')
_COPY_BLOCK = 1024 * 1024


class MuxError(Exception):
    pass


def _boxes(f, start, end):
    pos = start
    while pos + 8 <= end:
        f.seek(pos)
        head = f.read(8)
        if len(head) < 8:
            break
        size, kind = struct.unpack('>I4s', head)
        hdr = 8
        if size == 1:
            size = struct.unpack('>Q', f.read(8))[0]
            hdr = 16
        elif size == 0:
            size = end - pos
        if size < hdr or pos + size > end:
            raise MuxError('invalid box ' + repr(kind))
        yield kind, pos, size, hdr
        pos += size


def _parse(path):
    total = os.path.getsize(path)
    info = {'ftyp': None, 'moov': None, 'mdat': []}
    with open(path, 'rb') as f:
        for kind, pos, size, hdr in _boxes(f, 0, total):
            if kind == b'ftyp':
                f.seek(pos)
                info['ftyp'] = f.read(size)
            elif kind == b'moov':
                f.seek(pos + hdr)
                info['moov'] = f.read(size - hdr)
            elif kind == b'mdat':
                info['mdat'].append((pos + hdr, size - hdr))
    if not info['ftyp'] or not info['moov']:
        raise MuxError('missing ftyp or moov')
    if len(info['mdat']) != 1:
        raise MuxError('unsupported mdat layout')
    return info


def _split(data):
    out = []
    pos = 0
    while pos + 8 <= len(data):
        size, kind = struct.unpack('>I4s', data[pos:pos + 8])
        hdr = 8
        if size == 1:
            size = struct.unpack('>Q', data[pos + 8:pos + 16])[0]
            hdr = 16
        elif size == 0:
            size = len(data) - pos
        if size < hdr or pos + size > len(data):
            raise MuxError('invalid child box')
        out.append((kind, data[pos + hdr:pos + size]))
        pos += size
    return out


def _box(kind, payload):
    return struct.pack('>I4s', len(payload) + 8, kind) + payload


def _join(children):
    return b''.join(_box(k, p) for k, p in children)


def _walk(payload, path, fn):
    children = _split(payload)
    out = []
    for kind, body in children:
        if path and kind == path[0]:
            if len(path) == 1:
                body = fn(body)
            else:
                body = _walk(body, path[1:], fn)
        out.append((kind, body))
    return _join(out)


def _tkhd_info(body):
    version = body[0]
    if version == 1:
        track_id = struct.unpack('>I', body[20:24])[0]
        duration = struct.unpack('>Q', body[28:36])[0]
    else:
        track_id = struct.unpack('>I', body[12:16])[0]
        duration = struct.unpack('>I', body[20:24])[0]
    return track_id, duration


def _tkhd_set(body, track_id, duration):
    b = bytearray(body)
    if b[0] == 1:
        b[20:24] = struct.pack('>I', track_id)
        b[28:36] = struct.pack('>Q', duration)
    else:
        b[12:16] = struct.pack('>I', track_id)
        b[20:24] = struct.pack('>I', min(duration, 0xFFFFFFFF))
    return bytes(b)


def _mvhd_info(body):
    if body[0] == 1:
        timescale = struct.unpack('>I', body[20:24])[0]
        duration = struct.unpack('>Q', body[24:32])[0]
    else:
        timescale = struct.unpack('>I', body[12:16])[0]
        duration = struct.unpack('>I', body[16:20])[0]
    return timescale, duration


def _mvhd_set(body, duration, next_id):
    b = bytearray(body)
    if b[0] == 1:
        b[24:32] = struct.pack('>Q', duration)
    else:
        b[16:20] = struct.pack('>I', min(duration, 0xFFFFFFFF))
    b[-4:] = struct.pack('>I', next_id)
    return bytes(b)


def _shift_offsets(trak, delta):
    def shift_stco(body):
        count = struct.unpack('>I', body[4:8])[0]
        values = struct.unpack('>%dI' % count, body[8:8 + 4 * count])
        shifted = [v + delta for v in values]
        if shifted and max(shifted) > 0xFFFFFFFF:
            raise MuxError('offset overflow')
        return body[:8] + struct.pack('>%dI' % count, *shifted) + body[8 + 4 * count:]

    def shift_co64(body):
        count = struct.unpack('>I', body[4:8])[0]
        values = struct.unpack('>%dQ' % count, body[8:8 + 8 * count])
        shifted = [v + delta for v in values]
        return body[:8] + struct.pack('>%dQ' % count, *shifted) + body[8 + 8 * count:]

    trak = _walk(trak, [b'mdia', b'minf', b'stbl', b'stco'], shift_stco)
    return _walk(trak, [b'mdia', b'minf', b'stbl', b'co64'], shift_co64)


def _scale_elst(trak, num, den):
    def scale(body):
        version = body[0]
        count = struct.unpack('>I', body[4:8])[0]
        out = bytearray(body)
        pos = 8
        for _ in range(count):
            if version == 1:
                v = struct.unpack('>Q', body[pos:pos + 8])[0]
                out[pos:pos + 8] = struct.pack('>Q', v * num // den)
                pos += 20
            else:
                v = struct.unpack('>I', body[pos:pos + 4])[0]
                out[pos:pos + 4] = struct.pack('>I', v * num // den)
                pos += 12
        return bytes(out)

    return _walk(trak, [b'edts', b'elst'], scale)


def _build_moov(video, audio, video_delta, audio_delta):
    v_children = _split(video['moov'])
    a_children = _split(audio['moov'])
    if any(k == b'mvex' for k, _ in v_children + a_children):
        raise MuxError('fragmented input')
    v_mvhd = next((b for k, b in v_children if k == b'mvhd'), None)
    a_mvhd = next((b for k, b in a_children if k == b'mvhd'), None)
    if v_mvhd is None or a_mvhd is None:
        raise MuxError('missing mvhd')
    v_scale, v_dur = _mvhd_info(v_mvhd)
    a_scale, a_dur = _mvhd_info(a_mvhd)
    if not v_scale or not a_scale:
        raise MuxError('invalid timescale')

    v_traks = [b for k, b in v_children if k == b'trak']
    a_traks = [b for k, b in a_children if k == b'trak']
    if not v_traks or not a_traks:
        raise MuxError('missing trak')

    max_id = 0
    for t in v_traks:
        tk = next(b for k, b in _split(t) if k == b'tkhd')
        max_id = max(max_id, _tkhd_info(tk)[0])

    new_children = []
    for kind, body in v_children:
        if kind == b'trak':
            new_children.append((kind, _shift_offsets(body, video_delta)))
        elif kind == b'mvhd':
            continue
        else:
            new_children.append((kind, body))

    total_dur = max(v_dur, a_dur * v_scale // a_scale)
    next_id = max_id + 1
    for t in a_traks:
        t = _shift_offsets(t, audio_delta)
        if a_scale != v_scale:
            t = _scale_elst(t, v_scale, a_scale)

        def fix_tkhd(body, tid=next_id):
            _, dur = _tkhd_info(body)
            return _tkhd_set(body, tid, dur * v_scale // a_scale if a_scale != v_scale else dur)

        t = _walk(t, [b'tkhd'], fix_tkhd)
        new_children.append((b'trak', t))
        next_id += 1

    ordered = [(b'mvhd', _mvhd_set(v_mvhd, total_dur, next_id))] + new_children
    return _box(b'moov', _join(ordered))


def _copy_range(src, start, length, dst, progress=None):
    with open(src, 'rb') as f:
        f.seek(start)
        left = length
        while left > 0:
            block = f.read(min(_COPY_BLOCK, left))
            if not block:
                raise MuxError('short read')
            dst.write(block)
            left -= len(block)
            if progress:
                progress(len(block))


def _mdat_header(payload_len):
    if payload_len + 8 <= 0xFFFFFFFF:
        return struct.pack('>I4s', payload_len + 8, b'mdat')
    return struct.pack('>I4sQ', 1, b'mdat', payload_len + 16)


def merge(video_path, audio_path, out_path, progress=None):
    video = _parse(video_path)
    audio = _parse(audio_path)
    v_start, v_len = video['mdat'][0]
    a_start, a_len = audio['mdat'][0]
    v_head = _mdat_header(v_len)
    a_head = _mdat_header(a_len)
    ftyp = video['ftyp']

    probe = _build_moov(video, audio, 0, 0)
    base = len(ftyp) + len(probe)
    v_new = base + len(v_head)
    a_new = v_new + v_len + len(a_head)
    moov = _build_moov(video, audio, v_new - v_start, a_new - a_start)
    if len(moov) != len(probe):
        raise MuxError('moov size changed')

    try:
        with open(out_path, 'wb') as out:
            out.write(ftyp)
            out.write(moov)
            out.write(v_head)
            _copy_range(video_path, v_start, v_len, out, progress)
            out.write(a_head)
            _copy_range(audio_path, a_start, a_len, out, progress)
    except Exception:
        try:
            os.remove(out_path)
        except OSError:
            pass
        raise
    return out_path


def _handler(trak):
    for kind, body in _split(trak):
        if kind == b'mdia':
            for k2, b2 in _split(body):
                if k2 == b'hdlr':
                    return b2[8:12]
    return b''


def _stbl_of(trak):
    for kind, body in _split(trak):
        if kind == b'mdia':
            for k2, b2 in _split(body):
                if k2 == b'minf':
                    for k3, b3 in _split(b2):
                        if k3 == b'stbl':
                            return dict(_split(b3))
    raise MuxError('missing stbl')


def _chunk_layout(stbl):
    stsz = stbl.get(b'stsz')
    stsc = stbl.get(b'stsc')
    if stsz is None or stsc is None:
        raise MuxError('missing sample tables')
    fixed, count = struct.unpack('>II', stsz[4:12])
    if fixed:
        sizes = [fixed] * count
    else:
        sizes = list(struct.unpack('>%dI' % count, stsz[12:12 + 4 * count]))
    if b'stco' in stbl:
        body = stbl[b'stco']
        n = struct.unpack('>I', body[4:8])[0]
        offsets = list(struct.unpack('>%dI' % n, body[8:8 + 4 * n]))
    elif b'co64' in stbl:
        body = stbl[b'co64']
        n = struct.unpack('>I', body[4:8])[0]
        offsets = list(struct.unpack('>%dQ' % n, body[8:8 + 8 * n]))
    else:
        raise MuxError('missing chunk offsets')
    entries_n = struct.unpack('>I', stsc[4:8])[0]
    entries = [struct.unpack('>III', stsc[8 + 12 * i:20 + 12 * i]) for i in range(entries_n)]
    chunks = []
    sample = 0
    for index in range(len(offsets)):
        per = 0
        for first, spc, _desc in entries:
            if first <= index + 1:
                per = spc
            else:
                break
        size = sum(sizes[sample:sample + per])
        sample += per
        chunks.append((offsets[index], size))
    return chunks


def _replace_offsets(trak, offsets):
    def fix_stbl(body):
        out = []
        for kind, b in _split(body):
            if kind == b'co64':
                continue
            if kind == b'stco':
                b = struct.pack('>II', 0, len(offsets)) + struct.pack('>%dI' % len(offsets), *offsets)
            out.append((kind, b))
        return _join(out)

    return _walk(trak, [b'mdia', b'minf', b'stbl'], fix_stbl)


def _audio_moov(moov, offsets):
    children = _split(moov)
    if any(k == b'mvex' for k, _ in children):
        raise MuxError('fragmented input')
    audio = None
    for kind, body in children:
        if kind == b'trak' and _handler(body) == b'soun':
            audio = body
            break
    if audio is None:
        raise MuxError('no audio track')
    new_children = []
    for kind, body in children:
        if kind == b'trak':
            continue
        new_children.append((kind, body))
    new_children.append((b'trak', _replace_offsets(audio, offsets)))
    ordered = [c for c in new_children if c[0] == b'mvhd'] + [c for c in new_children if c[0] != b'mvhd']
    return _box(b'moov', _join(ordered))


def extract_audio(src_path, out_path, progress=None):
    info = _parse(src_path)
    audio = None
    for kind, body in _split(info['moov']):
        if kind == b'trak' and _handler(body) == b'soun':
            audio = body
            break
    if audio is None:
        raise MuxError('no audio track')
    chunks = _chunk_layout(_stbl_of(audio))
    if not chunks:
        raise MuxError('no audio chunks')
    payload = sum(size for _, size in chunks)
    head = _mdat_header(payload)
    ftyp = _box(b'ftyp', b'M4A ' + struct.pack('>I', 0) + b'M4A mp42isom')
    probe = _audio_moov(info['moov'], [0] * len(chunks))
    base = len(ftyp) + len(probe) + len(head)
    offsets = []
    pos = base
    for _, size in chunks:
        offsets.append(pos)
        pos += size
    if max(offsets) > 0xFFFFFFFF:
        raise MuxError('offset overflow')
    moov = _audio_moov(info['moov'], offsets)
    if len(moov) != len(probe):
        raise MuxError('moov size changed')
    try:
        with open(out_path, 'wb') as out:
            out.write(ftyp)
            out.write(moov)
            out.write(head)
            for offset, size in chunks:
                _copy_range(src_path, offset, size, out, progress)
    except Exception:
        try:
            os.remove(out_path)
        except OSError:
            pass
        raise
    return out_path
