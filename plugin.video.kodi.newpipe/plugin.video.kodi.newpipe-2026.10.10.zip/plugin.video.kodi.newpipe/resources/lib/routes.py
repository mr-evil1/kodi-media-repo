import re
from urllib.parse import urlparse, parse_qs, quote

import xbmc

from .scrapetube.scrapetube import get_search
from .dispatcher import urldispatcher
from . import directory, kodi
from .kodi import log

from . import player as playback
from . import download as downloader
from . import storage
from . import yt
from . import logger


def _text(value, fallback=''):
    if isinstance(value, int):
        try:
            return kodi.i18n(value)
        except Exception:
            return fallback
    return value or fallback


def _item(entry):
    entry = dict(entry)
    if 'title' in entry:
        entry['title'] = _text(entry['title'], 'Unknown')
    if isinstance(entry.get('cm'), list):
        fixed = []
        for cm in entry['cm']:
            cm = dict(cm)
            cm['title'] = _text(cm.get('title'), '')
            fixed.append(cm)
        entry['cm'] = fixed
    if 'query' in entry and not isinstance(entry['query'], str):
        entry.pop('query')
    return entry


def _build(items, **kwargs):
    directory.builder([_item(i) for i in items], **kwargs)


def _setting(key, default=''):
    try:
        value = kodi.setting(key)
        return value if value not in (None, '') else default
    except Exception:
        return default


def _limit(default_key='results_per_page', fallback=25):
    try:
        return max(1, int(_setting(default_key, fallback)))
    except (TypeError, ValueError):
        return fallback


def _icon(name):
    try:
        return kodi.addonmedia(name + '.png')
    except Exception:
        return ''


def _video_id(url):
    if not url:
        return ''
    if url.startswith('http'):
        query = parse_qs(urlparse(url).query)
        if 'v' in query:
            return query['v'][0]
        tail = url.rstrip('/').rsplit('/', 1)[-1]
        return tail[:11] if len(tail) >= 11 else tail
    return url


def _channel_cm(channel_url, channel_title=''):
    if not channel_url:
        return []
    return [{'title': 30026, 'isFolder': True,
             'query': {'action': 'channel', 'url': channel_url, 'title': channel_title or ''}}]


def _video_item(item, channel_url='', channel_title=''):
    video_id = _video_id(item.get('url', ''))
    title = item.get('title') or 'Unknown title'
    if item.get('is_live'):
        title = '[LIVE] ' + title
    cm = _channel_cm(channel_url, channel_title)
    if channel_url:
        known = any(s.get('url') == channel_url for s in storage.get_subscriptions())
        cm.append({
            'title': 30015 if known else 30013,
            'query': {'action': 'unsubscribe' if known else 'subscribe',
                      'url': channel_url, 'title': channel_title or ''},
        })
    cm.append({'title': 30060, 'query': {'action': 'download', 'url': video_id, 'title': title}})
    return {
        'title': title,
        'action': 'play',
        'url': video_id,
        'image': item.get('image', ''),
        'duration': item.get('duration') or 0,
        'isFolder': 'False',
        'isPlayable': 'True',
        'cm': cm,
    }


def _next_item(action, continuation, **params):
    entry = {'title': kodi.i18n(30050), 'action': action,
             'continuation': continuation, 'isFolder': 'True', 'isPlayable': 'False'}
    entry.update(params)
    return entry


def _build_videos(tuples_and_token, next_action=None, next_params=None):
    items, next_token = tuples_and_token
    result = [_video_item(v, cu, ct) for v, cu, ct in items]
    if next_token and next_action:
        result.append(_next_item(next_action, next_token, **(next_params or {})))
    _build(result)


_TRENDING = [
    ('Music',   30040),
    ('Gaming',  30041),
    ('News',    30042),
    ('Movies',  30043),
    ('Live',    30018),
]

_LIVE = [
    ('News',     30042),
    ('Music',    30040),
    ('Gaming',   30041),
    ('Sports',   30044),
    ('Podcasts', 30045),
]


def _channel_thumb(item):
    try:
        thumbs = item.get('thumbnail', {}).get('thumbnails') or []
        return thumbs[-1].get('url', '') if thumbs else ''
    except (AttributeError, IndexError):
        return ''


def _channel_title_str(item):
    title = item.get('title', '')
    if isinstance(title, dict):
        return title.get('simpleText') or ''
    return title if isinstance(title, str) else ''


def _channel_id(item):
    return item.get('channelId') or item.get('browseId') or ''


_VIDEO_RE = re.compile(r'^[A-Za-z0-9_-]{11}$')
_PLAYLIST_PREFIXES = ('PL', 'RD', 'UU', 'OL', 'LL', 'FL', 'VL')
_CHANNEL_ID_RE = re.compile(r'^UC[A-Za-z0-9_-]{22}$')


def _first(query, key):
    values = query.get(key) or ['']
    return values[0].strip()


def _parse_youtube_input(text):
    text = (text or '').strip()
    video = ''
    playlist = ''
    channel = ''
    if not text:
        return video, playlist, channel
    lowered = text.lower()
    if lowered.startswith(('http://', 'https://', 'www.', 'youtu', 'm.youtube', 'music.youtube')):
        if not lowered.startswith('http'):
            text = 'https://' + text
        parts = urlparse(text)
        query = parse_qs(parts.query)
        video = _first(query, 'v')
        playlist = _first(query, 'list')
        if not video:
            segments = [seg for seg in parts.path.split('/') if seg]
            host = (parts.hostname or '').lower()
            if 'youtu.be' in host and segments:
                video = segments[0]
            elif len(segments) >= 2 and segments[0] in ('shorts', 'embed', 'live', 'v'):
                video = segments[1]
            elif segments and segments[0] == 'channel' and len(segments) >= 2:
                channel = 'https://www.youtube.com/channel/' + segments[1]
            elif segments and segments[0].startswith('@'):
                channel = 'https://www.youtube.com/' + segments[0]
    else:
        raw = text.lstrip('?')
        tokens = raw.split('&')
        head = tokens[0]
        if '=' in head:
            query = parse_qs(raw)
            video = _first(query, 'v')
            playlist = _first(query, 'list')
        else:
            query = parse_qs('&'.join(tokens[1:]))
            playlist = _first(query, 'list')
            if _VIDEO_RE.match(head):
                video = head
            elif head.startswith(_PLAYLIST_PREFIXES) and len(head) > 11:
                playlist = playlist or head
            elif _CHANNEL_ID_RE.match(head):
                channel = 'https://www.youtube.com/channel/' + head
            elif head.startswith('@') and len(head) > 1:
                channel = 'https://www.youtube.com/' + head
    if not _VIDEO_RE.match(video):
        video = ''
    return video, playlist, channel


def _abort_resolve():
    import sys
    try:
        kodi.resolve(int(sys.argv[1]), False, kodi.item())
    except Exception as e:
        logger.debug('abort resolve failed: {0}'.format(e), 'routes')


def _playlist_available(playlist_id):
    try:
        items, _token = yt.playlist_videos(playlist_id)
        return bool(items)
    except Exception as e:
        logger.debug('playlist check failed: {0}'.format(e), 'routes')
        return False


_TESTURL_PATH = '/storage/emulated/0/Download/testurl.txt'


def _read_testurl():
    try:
        with open(_TESTURL_PATH, 'r', encoding='utf-8') as f:
            return f.read().strip()
    except Exception:
        return ''


def _play_or_download(video_id, title='', image=''):
    choice = kodi.selectDialog(
        [kodi.i18n(30099), kodi.i18n(30100)],
        heading=kodi.i18n(30101),
    )
    if choice == 0:
        play(video_id, title=title, image=image)
    elif choice == 1:
        _abort_resolve()
        download(video_id, title=title)
    else:
        _abort_resolve()


@urldispatcher.register('open_id')
def open_id():
    text = _read_testurl()
    if text:
        logger.debug('open_id: testurl.txt verwendet: {0}'.format(text), 'routes')
    else:
        text = kodi.dialog.input(heading=kodi.i18n(30092))
    video, playlist_id, channel_url = _parse_youtube_input(text)
    if not video and not playlist_id and not channel_url:
        if text:
            kodi.infoDialog(kodi.i18n(30093))
        _abort_resolve()
        return
    if channel_url:
        _abort_resolve()
        xbmc.executebuiltin('Container.Update(plugin://{0}/?action=channel&url={1})'.format(
            kodi.ADDON_ID, quote(channel_url)))
        return
    if playlist_id:
        _abort_resolve()
        xbmc.executebuiltin('Container.Update(plugin://{0}/?action=playlist&url={1})'.format(
            kodi.ADDON_ID, quote(playlist_id)))
        return
    if video:
        _play_or_download(video, title=video)
        return
    kodi.infoDialog(kodi.i18n(30097))
    _abort_resolve()


@urldispatcher.register('root')
def root():
    _build([
        {'title': 30001, 'action': 'search',        'icon': _icon('search'),        'image': _icon('search'),        'isFolder': 'True',  'isPlayable': 'False'},
        {'title': 30091, 'action': 'open_id',       'icon': _icon('search'),        'image': _icon('search'),        'isFolder': 'False', 'isPlayable': 'True'},
        {'title': 30025, 'action': 'trending',       'icon': _icon('trending'),      'image': _icon('trending'),      'isFolder': 'True',  'isPlayable': 'False'},
        {'title': 30018, 'action': 'live',           'icon': _icon('live'),          'image': _icon('live'),          'isFolder': 'True',  'isPlayable': 'False'},
        {'title': 30002, 'action': 'subscriptions',  'icon': _icon('subscriptions'), 'image': _icon('subscriptions'), 'isFolder': 'True',  'isPlayable': 'False'},
        {'title': 30027, 'action': 'bookmarks',      'icon': _icon('bookmarks'),     'image': _icon('bookmarks'),     'isFolder': 'True',  'isPlayable': 'False'},
        {'title': 30003, 'action': 'feed',           'icon': _icon('feed'),          'image': _icon('feed'),          'isFolder': 'True',  'isPlayable': 'False'},
        {'title': 30004, 'action': 'history',        'icon': _icon('history'),       'image': _icon('history'),       'isFolder': 'True',  'isPlayable': 'False'},
        {'title': 30005, 'action': 'open_settings',  'icon': _icon('settings'),      'image': _icon('settings'),      'isFolder': 'False', 'isPlayable': 'False'},
    ])


@urldispatcher.register('open_settings')
def open_settings():
    kodi.openSettings()


@urldispatcher.register('browse_download_path')
def browse_download_path():
    import xbmcgui
    current = kodi.setting('download_path') or '/storage/emulated/0/Download/NewPipe_Download'
    chosen = xbmcgui.Dialog().browse(3, kodi.i18n(30063), 'files', '', False, False, current)
    if chosen and chosen != current:
        kodi.set_setting('download_path', chosen)


@urldispatcher.register('clear_log')
def clear_log():
    kodi.infoDialog(kodi.i18n(30088 if logger.clear_file() else 30089))


@urldispatcher.register('download', kwargs=['url', 'title'])
def download(url, title=''):
    downloader.start(url, title)


@urldispatcher.register('search', kwargs=['query'])
def search(query=None):
    if not query:
        items = [{'title': 30006, 'action': 'search_input', 'icon': _icon('search'),
                  'image': _icon('search'), 'isFolder': 'True', 'isPlayable': 'False'}]
        items += [
            {'title': q, 'action': 'search_results', 'url': q,
             'isFolder': 'True', 'isPlayable': 'False',
             'cm': [{'title': 30008, 'query': {'action': 'forget_search', 'url': q}}]}
            for q in storage.get_searches()
        ]
        _build(items)
        return
    search_results(query)


@urldispatcher.register('search_input')
def search_input():
    query = kodi.dialog.input(heading=kodi.i18n(30001))
    if query:
        storage.add_search(query)
        search_results(query)
    else:
        kodi.close_all()


@urldispatcher.register('clear_searches')
def clear_searches():
    storage.clear_searches()
    kodi.refresh()


@urldispatcher.register('clear_cache')
def clear_cache():
    from .constants import reset_cache
    ok = bool(reset_cache())
    kodi.infoDialog(kodi.i18n(30032 if ok else 30033))
    kodi.refresh()


@urldispatcher.register('trending')
def trending():
    _build([
        {'title': sid, 'action': 'trending_results', 'url': eng,
         'icon': _icon('trending'), 'image': _icon('trending'),
         'isFolder': 'True', 'isPlayable': 'False'}
        for eng, sid in _TRENDING
    ])


@urldispatcher.register('trending_results', kwargs=['url', 'continuation'])
def trending_results(url, continuation=None):
    _build_videos(yt.trending_videos(url, limit=_limit(), continuation=continuation),
                  next_action='trending_results', next_params={'url': url})


@urldispatcher.register('live')
def live():
    _build([
        {'title': sid, 'action': 'live_results', 'url': eng,
         'icon': _icon('live'), 'image': _icon('live'),
         'isFolder': 'True', 'isPlayable': 'False'}
        for eng, sid in _LIVE
    ])


@urldispatcher.register('live_results', kwargs=['url', 'continuation'])
def live_results(url, continuation=None):
    tuples, token = yt.live_videos(url, limit=_limit(), continuation=continuation)
    filtered = [(v, cu, ct) for v, cu, ct in tuples if v.get('is_live')] or tuples
    result = [_video_item(v, cu, ct) for v, cu, ct in filtered]
    if token:
        result.append(_next_item('live_results', token, url=url))
    _build(result)


@urldispatcher.register('forget_search', kwargs=['url'])
def forget_search(url):
    storage.remove_search(url)
    kodi.refresh()


@urldispatcher.register('search_results', kwargs=['url'])
def search_results(url):
    storage.add_search(url)
    _build([
        {'title': 30010, 'action': 'search_videos',    'url': url, 'isFolder': 'True', 'isPlayable': 'False'},
        {'title': 30011, 'action': 'search_channels',  'url': url, 'isFolder': 'True', 'isPlayable': 'False'},
        {'title': 30012, 'action': 'search_playlists', 'url': url, 'isFolder': 'True', 'isPlayable': 'False'},
    ])


@urldispatcher.register('search_videos', kwargs=['url', 'continuation'])
def search_videos_route(url, continuation=None):
    _build_videos(yt.search_videos(url, limit=_limit(), continuation=continuation),
                  next_action='search_videos', next_params={'url': url})


@urldispatcher.register('search_channels', kwargs=['url'])
def search_channels_route(url):
    _list_channels(url, _limit())


@urldispatcher.register('search_playlists', kwargs=['url'])
def search_playlists_route(url):
    _list_playlist_results(url, _limit())


def _list_channels(query, limit):
    items = []
    try:
        from .scrapetube.wrapper import list_search as wrapper_search
        for raw in get_search(query, limit=limit, sleep=0, results_type='channel'):
            cid = _channel_id(raw)
            if not cid:
                continue
            url = 'https://www.youtube.com/channel/' + cid
            title = _channel_title_str(raw) or cid
            items.append({
                'title': title, 'action': 'channel', 'url': url, 'image': _channel_thumb(raw),
                'isFolder': 'True', 'isPlayable': 'False',
                'cm': [{'title': 30013, 'query': {'action': 'subscribe', 'url': url, 'title': title}}],
            })
    except Exception as e:
        log('NewPipe channel search failed: {0}'.format(e))
    _build(items)


def _playlist_item(item):
    title = item.get('title') or 'Untitled playlist'
    url = item.get('url', '')
    marked = any(m.get('url') == url for m in storage.get_bookmarks())
    return {
        'title': title, 'action': 'playlist', 'url': url,
        'image': item.get('image', ''),
        'isFolder': 'True', 'isPlayable': 'False',
        'cm': [{'title': 30029 if marked else 30028,
                'query': {'action': 'unbookmark' if marked else 'bookmark',
                          'url': url, 'title': title, 'image': item.get('image', '')}}],
    }


def _list_playlist_results(query, limit):
    from .scrapetube.wrapper import list_search as wrapper_search
    results = wrapper_search(query, limit=limit, sleep=0, results_type='playlist') or []
    _build([_playlist_item(p) for p in results])


@urldispatcher.register('channel', kwargs=['url', 'title'])
def channel(url, title=''):
    subs = storage.get_subscriptions()
    known = next((s for s in subs if s.get('url') == url), None)
    name = title or (known.get('title') if known else '') or url
    toggle = ({'title': 30015, 'query': {'action': 'unsubscribe', 'url': url}} if known
              else {'title': 30013, 'query': {'action': 'subscribe', 'url': url, 'title': name}})
    _build([
        {'title': 30016, 'action': 'channel_videos',    'url': url, 'tab': 'videos',  'isFolder': 'True',  'isPlayable': 'False'},
        {'title': 30017, 'action': 'channel_videos',    'url': url, 'tab': 'shorts',  'isFolder': 'True',  'isPlayable': 'False'},
        {'title': 30018, 'action': 'channel_videos',    'url': url, 'tab': 'streams', 'isFolder': 'True',  'isPlayable': 'False'},
        {'title': 30012, 'action': 'channel_playlists', 'url': url,                   'isFolder': 'True',  'isPlayable': 'False'},
        dict(toggle, action='unsubscribe' if known else 'subscribe', isFolder='False', isPlayable='False'),
    ])


@urldispatcher.register('channel_videos', kwargs=['url', 'tab', 'continuation'])
def channel_videos_route(url, tab='videos', continuation=None):
    subs = storage.get_subscriptions()
    known = next((s for s in subs if s.get('url') == url), None)
    ch_title = known.get('title') if known else ''
    items, token = yt.channel_videos(url, tab=tab, limit=_limit(), continuation=continuation)
    result = [_video_item(i, url, ch_title) for i, _cu, _ct in items]
    if token:
        result.append(_next_item('channel_videos', token, url=url, tab=tab))
    _build(result)


@urldispatcher.register('channel_playlists', kwargs=['url'])
def channel_playlists(url):
    _build([_playlist_item(p) for p in yt.channel_playlists(url)])


@urldispatcher.register('playlist', kwargs=['url', 'continuation'])
def playlist(url, continuation=None):
    items, token = yt.playlist_videos(url, continuation=continuation)
    result = [_video_item(i) for i in items if i.get('title')]
    if token:
        result.append(_next_item('playlist', token, url=url))
    _build(result)


@urldispatcher.register('subscribe', kwargs=['url', 'title'])
def subscribe(url, title=''):
    storage.subscribe(title or url, url)
    kodi.infoDialog(kodi.i18n(30014))
    kodi.refresh()


@urldispatcher.register('unsubscribe', kwargs=['url'])
def unsubscribe(url):
    storage.unsubscribe(url)
    kodi.refresh()


@urldispatcher.register('bookmark', kwargs=['url', 'title', 'image'])
def bookmark(url, title='', image=''):
    storage.bookmark(title or url, url, image)
    kodi.infoDialog(kodi.i18n(30030))
    kodi.refresh()


@urldispatcher.register('unbookmark', kwargs=['url'])
def unbookmark(url):
    storage.unbookmark(url)
    kodi.refresh()


@urldispatcher.register('bookmarks')
def bookmarks():
    _build([_playlist_item(m) for m in storage.get_bookmarks()])


@urldispatcher.register('subscriptions')
def subscriptions():
    subs = storage.get_subscriptions()
    _build([
        {'title': s.get('title') or s.get('url'), 'action': 'channel', 'url': s.get('url'),
         'isFolder': 'True', 'isPlayable': 'False',
         'cm': [{'title': 30015, 'query': {'action': 'unsubscribe', 'url': s.get('url')}}]}
        for s in subs
    ])


@urldispatcher.register('feed')
def feed():
    per_channel = _limit(default_key='feed_per_channel', fallback=5)
    items = []
    for sub in storage.get_subscriptions():
        try:
            vids, _ = yt.channel_videos(sub.get('url'), limit=per_channel)
            for i, _cu, _ct in vids[:per_channel]:
                entry = _video_item(i, sub.get('url'), sub.get('title') or '')
                entry['title'] = '{0} - {1}'.format(
                    sub.get('title') or '', i.get('title') or 'Unknown title')
                items.append(entry)
        except Exception as e:
            log('NewPipe feed error for {0}: {1}'.format(sub.get('url'), e))
    _build(items)


@urldispatcher.register('history')
def history():
    entries = storage.get_history()
    items = [
        {'title': h.get('title') or h.get('video_id'), 'action': 'play',
         'url': h.get('video_id'), 'image': h.get('image', ''),
         'isFolder': 'False', 'isPlayable': 'True'}
        for h in entries
    ]
    if entries:
        items.append({'title': 30007, 'action': 'clear_history',
                      'isFolder': 'False', 'isPlayable': 'False'})
    _build(items)


@urldispatcher.register('clear_history')
def clear_history():
    storage.clear_history()
    kodi.refresh()


@urldispatcher.register('play', kwargs=['url', 'title', 'image'])
def play(url, title='', image=''):
    video_id = _video_id(url)
    storage.add_history({'video_id': video_id, 'title': title or video_id, 'image': image or ''})
    playback.play(video_id, title=title, image=image)
