import sys

import xbmcgui
import xbmcplugin
from urllib.parse import urlencode

from . import kodi

_URL_KEYS = ('action', 'url', 'tab', 'continuation')


_PLAY_EXTRA_KEYS = ('title', 'image')

def _make_url(item):
    params = {}
    for k in _URL_KEYS:
        v = item.get(k)
        if v not in (None, ''):
            params[k] = str(v)
    if str(item.get('isPlayable', 'False')).lower() == 'true':
        for k in _PLAY_EXTRA_KEYS:
            v = item.get(k)
            if v not in (None, ''):
                params[k] = str(v)
    return sys.argv[0] + '?' + urlencode(params)


def builder(items, content='videos'):
    handle = int(sys.argv[1])
    for item in items:
        title = str(item.get('title') or '')
        is_folder = str(item.get('isFolder', 'True')).lower() != 'false'
        is_playable = str(item.get('isPlayable', 'False')).lower() == 'true'

        li = xbmcgui.ListItem(label=title)
        li.setProperty('IsPlayable', 'true' if is_playable else 'false')

        image = item.get('image') or item.get('icon') or kodi.ICON
        fanart = kodi.FANART
        li.setArt({'thumb': image, 'icon': image, 'fanart': fanart, 'poster': image})

        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        tag.setMediaType('video')
        dur = item.get('duration')
        if dur:
            try:
                tag.setDuration(int(dur))
            except (TypeError, ValueError):
                pass

        cm = []
        for cm_item in (item.get('cm') or []):
            cm_title = str(cm_item.get('title') or '')
            cm_params = {k: str(v) for k, v in (cm_item.get('query') or {}).items()
                         if v is not None}
            cm_url = sys.argv[0] + '?' + urlencode(cm_params)
            if str(cm_item.get('isFolder', 'False')).lower() == 'true':
                cmd = 'Container.Update({0})'.format(cm_url)
            else:
                cmd = 'RunPlugin({0})'.format(cm_url)
            cm.append((cm_title, cmd))
        if cm:
            li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle, _make_url(item), li, is_folder)

    xbmcplugin.endOfDirectory(handle)


def resolve(stream_url, meta=None, icon='', dash=False, manifest_type=None):
    handle = int(sys.argv[1])
    meta = meta or {}
    title = str(meta.get('title', ''))
    li = xbmcgui.ListItem(label=title, path=stream_url)
    li.setProperty('IsPlayable', 'true')
    thumb = icon or kodi.ICON
    li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': kodi.FANART})
    tag = li.getVideoInfoTag()
    tag.setTitle(title)
    tag.setMediaType('video')
    if dash:
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', manifest_type or 'mpd')
    xbmcplugin.setResolvedUrl(handle, True, li)
