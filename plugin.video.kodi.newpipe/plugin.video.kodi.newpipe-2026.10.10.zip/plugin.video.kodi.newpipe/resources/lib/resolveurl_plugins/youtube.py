

import os
import sys
import tempfile
from resolveurl import common
from resolveurl.lib import helpers
from resolveurl.resolver import ResolveUrl, ResolverError

_LIB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'lib')
if _LIB_DIR not in sys.path:
    sys.path.insert(0, _LIB_DIR)

from moq_proxy import serve_yt_mpd, build_yt_stream_url, build_relay_url, _log as _proxy_log

ADDON_ID = 'script.module.resolveurl.pluginsgr'

try:
    from ytresolver.kodion.context.standalone import StandaloneContext
    from ytresolver.youtube.client.player_client import YouTubePlayerClient
    YT_ENGINE_AVAILABLE = True
except ImportError:
    YT_ENGINE_AVAILABLE = False


def _extract_subtitles(entry):
    subtitles = {}
    try:
        for sub in entry.get('subtitles') or []:
            lang = sub.get('lang') or sub.get('name') or 'en'
            sub_url = sub.get('url')
            if sub_url:
                subtitles[lang] = sub_url
    except Exception:
        pass
    return subtitles


def _get_video_codecs():
    codecs = ['avc1']
    try:
        from kodi_six import xbmcaddon
        raw = xbmcaddon.Addon(ADDON_ID).getSetting('yt_video_codecs')
        if raw:
            parsed = [c.strip() for c in raw.split(',') if c.strip()]
            if parsed:
                codecs = parsed
    except Exception:
        pass
    return codecs


def _engine_context(video_codecs=None):
    if video_codecs is None:
        video_codecs = _get_video_codecs()

    try:
        from kodi_six import xbmcvfs
        _translate = xbmcvfs.translatePath
    except Exception:
        _translate = None

    def _real(path, fallback):
        try:
            out = _translate(path) if _translate else None
        except Exception:
            out = None
        if not out or out.startswith('special://'):
            out = fallback
        os.makedirs(out, exist_ok=True)
        return out

    tmp_base = os.path.join(tempfile.gettempdir(), 'ytresolver')
    data_dir = _real('special://temp/ytresolver/', tmp_base)
    config_dir = _real(
        'special://profile/addon_data/{0}/'.format(ADDON_ID), tmp_base)
    context = StandaloneContext(
        data_dir=data_dir,
        config_file=os.path.join(config_dir, 'ytresolver.json'),
        video_codecs=video_codecs)
    try:
        settings = context.get_settings()
        features = set(settings.stream_features())
        if 'hfr' not in features:
            features.add('hfr')
        if 'avc1' in video_codecs:
            features.add('avc1')
        elif video_codecs:
            features.add(video_codecs[0])
        settings.stream_features(sorted(features))
        settings.mpd_video_qualities(7)
    except Exception:
        pass
    return context


def _engine_mpd_path(video_id):
    try:
        from kodi_six import xbmcvfs
        translate = xbmcvfs.translatePath
    except Exception:
        translate = None

    def _t(path):
        try:
            out = translate(path) if translate else None
        except Exception:
            out = None
        return out or path

    base = _t(YouTubePlayerClient.BASE_PATH)
    if base.startswith('special://'):
        return None
    return os.path.join(base, video_id + '.mpd')


def _read_engine_mpd(video_id):
    path = _engine_mpd_path(video_id)
    if not path:
        return None
    try:
        with open(path, 'rb') as f:
            return f.read()
    except OSError:
        return None


_CLIENT_RANK = {'android_vr': 0, 'android_testsuite_params': 1, 'android': 1, 'ios_testsuite_params': 2, 'ios': 2}


def _progressive_relay_url(media_id):
    try:
        client = YouTubePlayerClient(context=_engine_context())
    except Exception as e:
        _proxy_log('progressive client init failed: {0}'.format(e))
        return None

    captured = {}
    original = client._process_progressive_streams

    def capture(**kwargs):
        captured['responses'] = kwargs.get('responses')
        return original(**kwargs)

    client._process_progressive_streams = capture
    try:
        client.load_stream_info(video_id=media_id, use_mpd=False, audio_only=False, ask_for_quality=True)
    except Exception as e:
        _proxy_log('progressive load_stream_info failed: {0}'.format(e))
    finally:
        client._process_progressive_streams = original

    responses = captured.get('responses') or {}
    by_itag = {}
    for name, response in responses.items():
        base_headers = (response.get('client') or {}).get('headers') or {}
        for fmt in response.get('progressive_fmts') or []:
            itag = str(fmt.get('itag'))
            info = client.FORMAT.get(itag) or {}
            if not info.get('video') or not info.get('audio') or info.get('container') != 'mp4':
                continue
            raw_url = fmt.get('url')
            if not raw_url:
                continue
            headers = dict(base_headers)
            try:
                url = client._process_url_params(raw_url, headers=headers)
            except Exception:
                url = None
            if not url or '/videoplayback' not in url:
                continue
            by_itag.setdefault(itag, []).append({
                'client': name,
                'url': url,
                'headers': headers,
                'method': 'GET',
                'height': (info.get('video') or {}).get('height', 0),
            })

    if not by_itag:
        return None

    best = max(by_itag, key=lambda i: by_itag[i][0]['height'])
    sources = sorted(by_itag[best], key=lambda s: _CLIENT_RANK.get(s['client'], 3))
    _proxy_log('progressive itag {0} clients {1}'.format(best, [s['client'] for s in sources]))
    primary = sources[0]
    return build_relay_url(primary['url'], primary['headers'], primary['method'], alternates=sources[1:])


class YouTubeGRResolver(ResolveUrl):
    name = 'YouTubeGR'
    domains = ['youtube.com', 'youtu.be', 'youtube-nocookie.com']
    pattern = (
        r'''(?://|\.)(?:[0-9A-Z-]+\.)?(?:(youtu\.be|youtube(?:-nocookie)?\.com)/?\S*?[^\w\s-])'''
        r'''([\w-]{11})(?=[^\w-]|$)(?![?=&+%\w.-]*(?:['"][^<>]*>|</a>))[?=&+%\w.-]*'''
    )

    def get_media_url(self, host, media_id, subs=False, audio_only=False):
        if not YT_ENGINE_AVAILABLE:
            raise ResolverError('YouTube engine is not available.')

        progressive = _progressive_relay_url(media_id)
        if progressive:
            if subs:
                return progressive, {}
            return progressive

        try:
            client = YouTubePlayerClient(context=_engine_context())
            streams, _yt_item = client.load_stream_info(
                video_id=media_id, use_mpd=True, audio_only=audio_only)
        except Exception as e:
            raise ResolverError('YouTube resolution failed: {}'.format(e))

        stream_list = list(streams) if isinstance(streams, (list, tuple, type({}.values()))) else []

        if audio_only:
            return self._pick_audio(stream_list, media_id, subs, client=client)

        selected = stream_list[0] if stream_list else {}
        if not selected.get('url'):
            raise ResolverError('No playable streams found for YouTube video {}.'.format(media_id))

        xml = _read_engine_mpd(media_id)
        if not xml:
            raise ResolverError('Failed to generate DASH manifest for YouTube video {}.'.format(media_id))

        subtitles = _extract_subtitles(selected) if subs else {}

        proxy_url = serve_yt_mpd(media_id, xml)
        if subs:
            return proxy_url, subtitles
        return proxy_url

    @staticmethod
    def _pick_audio(stream_list, media_id, subs, client=None):
        files = [s for s in stream_list
                 if s.get('url') and (s.get('audio') or {}).get('bitrate', 0) > 0
                 and not s.get('video')]
        if not files:
            files = [s for s in stream_list if s.get('url')]
        if not files:
            raise ResolverError('No playable audio streams found for YouTube video {}.'.format(media_id))
        best = max(files, key=lambda s: (s.get('audio') or {}).get('bitrate', 0))
        headers = {
            'User-Agent': common.RAND_UA,
            'Referer': 'https://www.youtube.com/watch?v={0}'.format(media_id),
        }
        if client and hasattr(client, '_process_url_params'):
            try:
                proxied_url = client._process_url_params(best['url'], stream_proxy=True, headers=headers)
                if proxied_url:
                    stream_url = build_yt_stream_url(proxied_url)
                else:
                    stream_url = best['url'] + helpers.append_headers(headers)
            except Exception:
                stream_url = best['url'] + helpers.append_headers(headers)
        else:
            stream_url = best['url'] + helpers.append_headers(headers)

        if subs:
            return stream_url, _extract_subtitles(best)
        return stream_url

    def get_url(self, host, media_id):
        return 'https://www.youtube.com/watch?v={0}'.format(media_id)

    @classmethod
    def _is_enabled(cls):
        return True

    @classmethod
    def _get_priority(cls):

        return 80
