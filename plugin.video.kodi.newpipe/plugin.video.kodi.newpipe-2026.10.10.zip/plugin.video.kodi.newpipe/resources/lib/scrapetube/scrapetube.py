import base64
import hashlib
import http.cookiejar
import json
import time
import urllib.parse
import urllib.request
from typing import Generator, Union


def _alt_mode():
    try:
        import xbmcaddon
        return xbmcaddon.Addon('plugin.video.kodi.newpipe').getSettingBool('alternativ_mode')
    except Exception:
        return False


_UA_ALT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0'
)

_ALT_MWEB_CLIENT = {
    "clientName": "MWEB",
    "clientVersion": "2.20260120.01.00",
    "userAgent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/30.0 Chrome/143.0.0.0 Mobile Safari/537.36,gzip(gfe)",
    "browserName": "Safari Mobile",
    "browserVersion": "30.0",
    "platform": "MOBILE",
    "clientFormFactor": "SMALL_FORM_FACTOR",
    "osName": "Android",
    "osVersion": "10",
}

_POTOKEN_GOOGLE_API_KEY = "AIzaSyDyT5W0Jh49F30Pqqtyfdf7pDLFKLJoAnw"
_POTOKEN_REQUEST_KEY = "O43z0dpjhgX20SCx4KAo"
_POTOKEN_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.3"
)


def _pot_descramble(scrambled_b64):
    b64 = scrambled_b64.replace('-', '+').replace('_', '/').replace('.', '=')
    pad = (4 - len(b64) % 4) % 4
    data = base64.b64decode(b64 + '=' * pad)
    return bytes((b + 97) & 0xFF for b in data).decode('utf-8', errors='replace')


def _pot_base64_to_u8_js(b64):
    b64mod = b64.replace('-', '+').replace('_', '/').replace('.', '=')
    pad = (4 - len(b64mod) % 4) % 4
    data = base64.b64decode(b64mod + '=' * pad)
    return 'new Uint8Array([' + ','.join(str(b) for b in data) + '])'


def _pot_u8_csv_to_base64(u8_csv):
    data = bytes(int(x) for x in u8_csv.split(','))
    b64 = base64.b64encode(data).decode()
    return b64.replace('+', '-').replace('/', '_').rstrip('=')


def _pot_parse_challenge(raw):
    arr = json.loads(raw)
    if len(arr) > 1 and isinstance(arr[1], str):
        arr = json.loads(_pot_descramble(arr[1]))
    else:
        arr = arr[0]
    js_url = None
    if isinstance(arr[1], list):
        js_url = next((x for x in arr[1] if isinstance(x, str)), None)
    return {
        "messageId": arr[0],
        "interpreterJavascript": {
            "privateDoNotAccessOrElseSafeScriptWrappedValue": js_url,
        },
        "interpreterHash": arr[3],
        "program": arr[4],
        "globalName": arr[5],
        "clientExperimentsStateBlob": arr[7] if len(arr) > 7 else None,
    }


def _pot_parse_integrity_token(raw):
    arr = json.loads(raw)
    return _pot_base64_to_u8_js(arr[0]), int(arr[1])


def _pot_fetch(url, body_str):
    data = body_str.encode('utf-8')
    headers = {
        'User-Agent': _POTOKEN_UA,
        'Accept': 'application/json',
        'Content-Type': 'application/json+protobuf',
        'x-goog-api-key': _POTOKEN_GOOGLE_API_KEY,
        'x-user-agent': 'grpc-web-javascript/0.1',
    }
    req = urllib.request.Request(url, data=data, headers=headers, method='POST')
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read().decode('utf-8')


class _Response:
    def __init__(self, body: bytes, headers):
        self._body = body
        self.headers = headers

    @property
    def text(self) -> str:
        return self._body.decode('utf-8', errors='replace')

    def json(self):
        return json.loads(self._body.decode('utf-8'))


class _Session:
    def __init__(self):
        self.headers = {
            'User-Agent': (
                _UA_ALT if _alt_mode() else
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                'AppleWebKit/537.36 (KHTML, like Gecko) '
                'Chrome/131.0.0.0 Safari/537.36'
            ),
            'Accept-Language': 'en-US,en;q=0.9',
        }
        self.proxies = {}
        self._jar = http.cookiejar.CookieJar()
        self.cookies = _CookieDict(self._jar)

    def _build_opener(self):
        handlers = [urllib.request.HTTPCookieProcessor(self._jar)]
        return urllib.request.build_opener(*handlers)

    def get(self, url, params=None, **_kw) -> _Response:
        if params:
            url = url + '?' + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, headers=self.headers)
        opener = self._build_opener()
        with opener.open(req, timeout=20) as r:
            return _Response(r.read(), r.headers)

    def close(self):
        pass

    def post(self, url, params=None, json=None, headers=None, **_kw) -> _Response:
        if params:
            url = url + '?' + urllib.parse.urlencode(params)
        body = (__import__('json').dumps(json or {}).encode('utf-8'))
        merged = dict(self.headers)
        if headers:
            merged.update(headers)
        merged['Content-Type'] = 'application/json'
        req = urllib.request.Request(url, data=body, headers=merged, method='POST')
        opener = self._build_opener()
        with opener.open(req, timeout=20) as r:
            return _Response(r.read(), r.headers)


class _CookieDict:
    def __init__(self, jar: http.cookiejar.CookieJar):
        self._jar = jar
        self._extra: dict = {}

    def get(self, name, default=None):
        for c in self._jar:
            if c.name == name:
                return c.value
        return self._extra.get(name, default)

    def set(self, name, value, domain='.youtube.com', **_kw):
        self._extra[name] = value
        cookie = http.cookiejar.Cookie(
            version=0, name=name, value=value,
            port=None, port_specified=False,
            domain=domain, domain_specified=True, domain_initial_dot=domain.startswith('.'),
            path='/', path_specified=True,
            secure=False, expires=None, discard=True,
            comment=None, comment_url=None, rest={},
        )
        self._jar.set_cookie(cookie)


class requests:
    Session = _Session

try:
    from typing import Literal
except ImportError:
    try:
        from typing_extensions import Literal
    except ImportError:
        class _LiteralType:
            def __getitem__(self, item):
                return str
        Literal = _LiteralType()

type_property_map = {
    "videos": "videoRenderer",
    "streams": "videoRenderer",
    "shorts": "reelWatchEndpoint"
}

def get_channel(
    channel_id: str = None,
    channel_url: str = None,
    channel_username: str = None,
    limit: int = None,
    sleep: float = 1,
    proxies: dict = None,
    sort_by: Literal["newest", "oldest", "popular"] = "newest",
    content_type: Literal["videos", "shorts", "streams"] = "videos",
    cookies: Union[dict, str] = None,
) -> Generator[dict, None, None]:


    base_url = ""
    if channel_url:
        base_url = channel_url
    elif channel_id:
        base_url = f"https://www.youtube.com/channel/{channel_id}"
    elif channel_username:
        base_url = f"https://www.youtube.com/@{channel_username}"

    url = "{base_url}/{content_type}?view=2".format(
        base_url=base_url,
        content_type=content_type,
    )
    api_endpoint = "https://www.youtube.com/youtubei/v1/browse"
    videos = get_videos(url, api_endpoint, "contents", type_property_map[content_type], limit, sleep, proxies, sort_by, content_type, cookies)
    for video in videos:
        yield video

_MWEB_CLIENT = {
    "clientName": "MWEB",
    "clientVersion": "2.20261006.02.00",
    "userAgent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/30.0 Chrome/143.0.0.0 Mobile Safari/537.36,gzip(gfe)",
    "browserName": "Safari Mobile",
    "browserVersion": "30.0",
    "platform": "MOBILE",
    "clientFormFactor": "SMALL_FORM_FACTOR",
    "osName": "Android",
    "osVersion": "10",
}

def _innertube_browse(session, browse_id=None, params=None, continuation=None, client=None):
    endpoint = "https://m.youtube.com/youtubei/v1/browse"
    default_client = _ALT_MWEB_CLIENT if _alt_mode() else _MWEB_CLIENT
    body = {"context": {"client": client or default_client}}
    if continuation:
        body["continuation"] = continuation
    else:
        body["browseId"] = browse_id
        if params:
            body["params"] = params
    session.headers["X-YouTube-Client-Name"] = "2"
    session.headers["X-YouTube-Client-Version"] = (client or default_client)["clientVersion"]
    session.headers["Origin"] = "https://m.youtube.com"
    session.headers["Referer"] = "https://m.youtube.com/"
    resp = session.post(endpoint, json=body)
    return resp.json()

def get_playlist(
    playlist_id: str, limit: int = None, sleep: int = 1, proxies: dict = None,
    cookies: Union[dict, str] = None,
) -> Generator[dict, None, None]:

    session = get_session(proxies, cookies)
    session.headers["User-Agent"] = _UA_MOBILE
    session.cookies.set("SOCS", "CAESEwgDEgk0ODE3Nzk3MjQaAmVuIAEaBgiA_LysBg", domain=".youtube.com")
    session.cookies.set("CONSENT", "YES+cb", domain=".youtube.com")

    count = 0
    continuation = None
    is_first = True

    while True:
        try:
            if is_first:
                data = _innertube_browse(session, browse_id=f"VL{playlist_id}")
                is_first = False
            else:
                data = _innertube_browse(session, continuation=continuation)
        except Exception as e:
            try:
                import xbmc as _x
                _x.log('[newpipe] _innertube_browse error: ' + str(e), _x.LOGINFO)
            except Exception:
                pass
            break

        found_any = False
        for item in get_videos_items(data, "playlistVideoRenderer"):
            found_any = True
            yield item
            count += 1
            if limit and count >= limit:
                session.close()
                return

        continuation = None
        endpoint = next(search_dict(data, "continuationEndpoint"), None)
        if not endpoint:
            endpoint = next(
                (c for c in search_dict(data, "innertubeCommand") if "continuationCommand" in c),
                None,
            )
        if endpoint:
            cmd = endpoint.get("continuationCommand") or next(search_dict(endpoint, "continuationCommand"), None)
            if cmd and "token" in cmd:
                continuation = cmd["token"]

        if not continuation:
            break

        time.sleep(sleep)

    session.close()

def get_search(
    query: str,
    limit: int = None,
    sleep: int = 1,
    sort_by: Literal["relevance", "upload_date", "view_count", "rating"] = "relevance",
    results_type: Literal["video", "channel", "playlist", "movie"] = "video",
    proxies: dict = None,
    cookies: Union[dict, str] = None,
) -> Generator[dict, None, None]:


    sort_by_map = {
        "relevance": "A",
        "upload_date": "I",
        "view_count": "M",
        "rating": "E",
    }

    results_type_map = {
        "video": ["B", "videoRenderer"],
        "channel": ["C", "channelRenderer"],
        "playlist": ["D", "playlistRenderer"],
        "movie": ["E", "videoRenderer"],
    }

    param_string = f"CA{sort_by_map[sort_by]}SAhA{results_type_map[results_type][0]}"
    url = "https://www.youtube.com/results?search_query={}&sp={}".format(
        urllib.parse.quote(query, safe=""), param_string
    )
    api_endpoint = "https://www.youtube.com/youtubei/v1/search"
    videos = get_videos(
        url, api_endpoint, "contents", results_type_map[results_type][1], limit, sleep, proxies,
        cookies=cookies,
    )
    for video in videos:
        yield video

def get_video(
    id: str,
    cookies: Union[dict, str] = None,
) -> dict:


    session = get_session(cookies=cookies)
    url = f"https://www.youtube.com/watch?v={id}"
    html = get_initial_data(session, url)
    innertube_ctx = _extract_innertube_context(html)
    client = innertube_ctx.get("client", {})
    session.headers["X-YouTube-Client-Name"] = "1"
    if client.get("clientVersion"):
        session.headers["X-YouTube-Client-Version"] = client["clientVersion"]
    data = _extract_yt_initial_data(html)
    if data is None:
        raise RuntimeError(
            "Could not find video data in YouTube response "
            "(page layout changed or login expired)"
        )
    return next(search_dict(data, "videoPrimaryInfoRenderer"))

_UA_MOBILE = (
    'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 '
    '(KHTML, like Gecko) SamsungBrowser/30.0 Chrome/143.0.0.0 Mobile Safari/537.36'
)

def get_videos(
    url: str, api_endpoint: str, selector_list: str, selector_item: str, limit: int, sleep: float, proxies: dict = None, sort_by: str = None, content_type: str = None, cookies: Union[dict, str] = None, force_mweb: bool = False
) -> Generator[dict, None, None]:
    session = get_session(proxies, cookies)
    if force_mweb:
        session.headers['User-Agent'] = _UA_MOBILE
        session.headers['Origin'] = 'https://m.youtube.com'
    is_first = True
    quit_it = False
    count = 0
    while True:
        if is_first:
            html = get_initial_data(session, url)
            innertube_ctx = _extract_innertube_context(html)
            client = innertube_ctx.get("client", {})
            if force_mweb:
                fallback_ver = (_ALT_MWEB_CLIENT if _alt_mode() else _MWEB_CLIENT)["clientVersion"]
                client = {
                    "clientName": "MWEB",
                    "clientVersion": client.get("clientVersion") or fallback_ver,
                    "platform": "MOBILE",
                    "clientFormFactor": "SMALL_FORM_FACTOR",
                }
            api_key = get_json_from_html(html, "innertubeApiKey", 3) or ""
            session.headers["X-YouTube-Client-Name"] = "2" if force_mweb else "1"
            if client.get("clientVersion"):
                session.headers["X-YouTube-Client-Version"] = client["clientVersion"]
            data = _extract_yt_initial_data(html)
            if data is None:
                raise RuntimeError(
                    "Could not find page data in YouTube response "
                    "(page layout changed or login expired)"
                )

            if content_type:
                tabs = next(search_dict(data, "tabs"), [])
                matched = False
                for tab in tabs:
                    renderer = tab.get("tabRenderer", {})
                    tab_url = (
                        renderer.get("endpoint", {})
                        .get("commandMetadata", {})
                        .get("webCommandMetadata", {})
                        .get("url", "")
                    )
                    if tab_url.endswith("/" + content_type) and renderer.get("selected"):
                        matched = True
                        break
                if not matched:
                    return

            if selector_list == "itemSectionRenderer":
                best = None
                best_count = -1
                for candidate in search_dict(data, selector_list):
                    n = sum(
                        1 for _ in search_dict(candidate, "lockupViewModel")
                    ) + sum(
                        1 for _ in search_dict(candidate, "richItemRenderer")
                    ) + sum(
                        1 for _ in search_dict(candidate, "playlistVideoRenderer")
                    )
                    if n > best_count:
                        best_count = n
                        best = candidate
                data = best
            else:
                data = next(search_dict(data, selector_list), None)
            next_data = get_next_data(data, sort_by)
            is_first = False
            if sort_by and sort_by != "newest":
                continue
        else:
            data = get_ajax_data(session, api_endpoint, api_key, next_data, client)
            next_data = get_next_data(data)

        for result in get_videos_items(data, selector_item):
            try:
                count += 1
                if content_type is not None:
                    result = _enrich_channel_item(result)
                yield result
                if count == limit:
                    quit_it = True
                    break
            except GeneratorExit:
                quit_it = True
                break

        if not next_data or quit_it:
            break

        time.sleep(sleep)

    session.close()

def get_videos_paged(
    url: str, api_endpoint: str, selector_list: str, selector_item: str,
    limit: int, sleep: float, proxies: dict = None, sort_by: str = None,
    content_type: str = None, cookies: Union[dict, str] = None,
    continuation: str = None,
):
    import base64 as _b64
    session = get_session(proxies, cookies)
    items = []
    next_token_out = None

    if continuation:
        try:
            state = json.loads(_b64.b64decode(continuation.encode()).decode())
            fallback_ver = (_ALT_MWEB_CLIENT if _alt_mode() else _MWEB_CLIENT)["clientVersion"]
            client = state.get("client") or {
                "clientName": "MWEB",
                "clientVersion": fallback_ver,
            }
            api_key = state.get("api_key", "")
            next_data = state["next_data"]
            effective_endpoint = state.get("api_endpoint", api_endpoint)
            session.headers["X-YouTube-Client-Name"] = "1"
            if client.get("clientVersion"):
                session.headers["X-YouTube-Client-Version"] = client["clientVersion"]
            data = get_ajax_data(session, effective_endpoint, api_key, next_data, client)
            next_data2 = get_next_data(data)
            count = 0
            for result in get_videos_items(data, selector_item):
                result = _enrich_channel_item(result)
                items.append(result)
                count += 1
                if limit and count >= limit:
                    break
            if next_data2:
                new_state = {
                    "client": client, "api_key": api_key,
                    "next_data": next_data2, "api_endpoint": effective_endpoint,
                }
                next_token_out = _b64.b64encode(json.dumps(new_state).encode()).decode()
        except Exception:
            pass
        session.close()
        return items, next_token_out

    html = get_initial_data(session, url)
    innertube_ctx = _extract_innertube_context(html)
    client = innertube_ctx.get("client", {})
    api_key = get_json_from_html(html, "innertubeApiKey", 3) or ""
    session.headers["X-YouTube-Client-Name"] = "1"
    if client.get("clientVersion"):
        session.headers["X-YouTube-Client-Version"] = client["clientVersion"]
    page_data = _extract_yt_initial_data(html)
    if page_data is None:
        session.close()
        return items, None

    if content_type:
        tabs = next(search_dict(page_data, "tabs"), [])
        matched = any(
            tab.get("tabRenderer", {}).get("endpoint", {})
            .get("commandMetadata", {}).get("webCommandMetadata", {})
            .get("url", "").endswith("/" + content_type)
            and tab.get("tabRenderer", {}).get("selected")
            for tab in tabs
        )
        if not matched:
            session.close()
            return items, None

    if selector_list == "itemSectionRenderer":
        best = None
        best_count = -1
        for candidate in search_dict(page_data, selector_list):
            n = (sum(1 for _ in search_dict(candidate, "lockupViewModel"))
                 + sum(1 for _ in search_dict(candidate, "richItemRenderer"))
                 + sum(1 for _ in search_dict(candidate, "playlistVideoRenderer")))
            if n > best_count:
                best_count = n
                best = candidate
        page_data = best
    else:
        page_data = next(search_dict(page_data, selector_list), None)

    next_data = get_next_data(page_data, sort_by)

    if sort_by and sort_by != "newest" and next_data:
        page_data = get_ajax_data(session, api_endpoint, api_key, next_data, client)
        next_data = get_next_data(page_data)

    if not client:
        fallback_ver = (_ALT_MWEB_CLIENT if _alt_mode() else _MWEB_CLIENT)["clientVersion"]
        client = {
            "clientName": "MWEB",
            "clientVersion": fallback_ver,
        }

    count = 0
    for result in get_videos_items(page_data, selector_item):
        result = _enrich_channel_item(result)
        items.append(result)
        count += 1
        if limit and count >= limit:
            break

    try:
        import xbmc
        xbmc.log("NewPipe get_videos_paged: got {} items, next_data={}".format(
            len(items), "YES" if next_data else "NO"), xbmc.LOGDEBUG)
    except Exception:
        pass

    if next_data:
        import base64 as _b64
        state = {"client": client, "api_key": api_key, "next_data": next_data, "api_endpoint": api_endpoint}
        next_token_out = _b64.b64encode(json.dumps(state).encode()).decode()

    session.close()
    return items, next_token_out


def _parse_cookies(cookies: Union[dict, str]) -> dict:
    if not cookies:
        return {}
    if isinstance(cookies, dict):
        return dict(cookies)
    if isinstance(cookies, str):
        parsed = {}
        for part in cookies.split(";"):
            part = part.strip()
            if not part or "=" not in part:
                continue
            name, _, value = part.partition("=")
            name, value = name.strip(), value.strip()
            if name:
                parsed[name] = value
        return parsed
    raise TypeError("cookies must be a dict or 'name=value; ...' string")


def _get_auth_headers(session: requests.Session) -> dict:
    try:
        sapisid = session.cookies.get("SAPISID")
    except Exception:
        sapisid = None
    if not sapisid:
        return {}
    origin = "https://www.youtube.com"
    timestamp = int(time.time())
    token = f"{timestamp} {sapisid} {origin}"
    digest = hashlib.sha1(token.encode("utf-8")).hexdigest()
    return {
        "Authorization": f"SAPISIDHASH {timestamp}_{digest}",
        "X-Origin": origin,
    }


def get_session(proxies: dict = None, cookies: Union[dict, str] = None) -> requests.Session:
    session = requests.Session()
    if proxies:
        session.proxies.update(proxies)
    for name, value in _parse_cookies(cookies).items():
        session.cookies.set(name, value, domain=".youtube.com")
    ua = _UA_ALT if _alt_mode() else (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    )
    session.headers["User-Agent"] = ua
    session.headers["Accept-Language"] = "en-US,en;q=0.9"
    return session

def get_initial_data(session: requests.Session, url: str) -> str:
    session.cookies.set("SOCS", "CAESEwgDEgk0ODE3Nzk3MjQaAmVuIAEaBgiA_LysBg", domain=".youtube.com")
    session.cookies.set("CONSENT", "YES+cb", domain=".youtube.com")
    response = session.get(url)
    html = response.text
    if "consent.youtube.com" in html or "ConsentUi" in html:
        session.cookies.set("SOCS", "CAESEwgDEgk0ODE3Nzk3MjQaAmVuIAEaBgiA_LysBg", domain=".youtube.com")
        session.cookies.set("CONSENT", "YES+cb.en+20240101-00-0", domain=".youtube.com")
        response = session.get(url)
        html = response.text
    return html

def get_ajax_data(
    session: requests.Session,
    api_endpoint: str,
    api_key: str,
    next_data: dict,
    client: dict,
) -> dict:
    data = {
        "context": {"clickTracking": next_data["click_params"], "client": client},
        "continuation": next_data["token"],
    }
    response = session.post(
        api_endpoint, params={"key": api_key}, json=data,
        headers=_get_auth_headers(session),
    )
    return response.json()

def _extract_yt_initial_data(html: str):
    marker = 'id="yt-initial-data"'
    pos = html.find(marker)
    if pos != -1:
        start = html.find(">", pos) + 1
        end = html.find("</script>", start)
        if start > 0 and end > start:
            try:
                return json.loads(html[start:end])
            except ValueError:
                pass
    legacy_key = "var ytInitialData = "
    pos = html.find(legacy_key)
    if pos != -1:
        start = pos + len(legacy_key)
        depth = 0
        for i in range(start, min(start + 2000000, len(html))):
            if html[i] == '{':
                depth += 1
            elif html[i] == '}':
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(html[start:i + 1])
                    except ValueError:
                        break
    import re
    for m in re.finditer(r'ytInitialData\s*=\s*(\{)', html):
        start = m.start(1)
        depth = 0
        for i in range(start, min(start + 2000000, len(html))):
            if html[i] == '{':
                depth += 1
            elif html[i] == '}':
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(html[start:i + 1])
                    except ValueError:
                        break
    return None


def get_json_from_html(html: str, key: str, num_chars: int = 2, stop: str = '"') -> str:
    idx = html.find(key)
    if idx == -1:
        return ""
    pos_begin = idx + len(key) + num_chars
    pos_end = html.find(stop, pos_begin)
    if pos_end == -1:
        return ""
    return html[pos_begin:pos_end]


def _extract_innertube_context(html: str) -> dict:
    import re
    m = re.search(r'"INNERTUBE_CONTEXT"\s*:\s*(\{)', html)
    if m:
        start = m.start(1)
        depth = 0
        for i in range(start, min(start + 8000, len(html))):
            if html[i] == '{':
                depth += 1
            elif html[i] == '}':
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(html[start:i + 1])
                    except (ValueError, json.JSONDecodeError):
                        break
    raw = get_json_from_html(html, "INNERTUBE_CONTEXT", 2, '"}},')
    if raw:
        try:
            return json.loads(raw + '"}}')
        except (ValueError, json.JSONDecodeError):
            pass
    return {}


def get_next_data(data: dict, sort_by: str = None) -> dict:
    sort_by_map = {
        "newest": 0,
        "popular": 1,
        "oldest": 2,
    }
    if sort_by and sort_by != "newest":
        chip_bar = next(search_dict(data, "chipBarViewModel"), None)
        if chip_bar is not None:
            try:
                chips = chip_bar.get("chips", [])
                if chips:
                    first_cmd = (
                        chips[0].get("chipViewModel", {})
                        .get("tapCommand", {})
                        .get("innertubeCommand", {})
                    )
                    if "showSheetCommand" in first_cmd:
                        list_items = next(search_dict(first_cmd, "listItems"), None)
                        if list_items:
                            cmd = list_items[sort_by_map[sort_by]][
                                "listItemViewModel"
                            ]["rendererContext"]["commandContext"]["onTap"][
                                "innertubeCommand"
                            ]
                            token = None
                            click_params = None
                            for command in cmd.get("commandExecutorCommand", {}).get(
                                "commands", []
                            ):
                                token = _safe_get(
                                    command, "continuationCommand", "token"
                                )
                                if token is not None:
                                    click_params = command.get("clickTrackingParams")
                                    break
                            if token:
                                return {
                                    "token": token,
                                    "click_params": {
                                        "clickTrackingParams": click_params
                                    },
                                }
                    else:
                        endpoint = chips[sort_by_map[sort_by]]["chipViewModel"][
                            "tapCommand"
                        ]["innertubeCommand"]
                        if endpoint and "continuationCommand" in endpoint:
                            return {
                                "token": endpoint["continuationCommand"]["token"],
                                "click_params": {
                                    "clickTrackingParams": endpoint.get(
                                        "clickTrackingParams"
                                    )
                                },
                            }
            except (KeyError, IndexError, TypeError, AttributeError):
                pass
        try:
            feed = next(search_dict(data, "feedFilterChipBarRenderer"), None)
            if feed:
                endpoint = feed["contents"][sort_by_map[sort_by]][
                    "chipCloudChipRenderer"
                ]["navigationEndpoint"]
                if endpoint and "continuationCommand" in endpoint:
                    return {
                        "token": endpoint["continuationCommand"]["token"],
                        "click_params": {
                            "clickTrackingParams": endpoint.get("clickTrackingParams")
                        },
                    }
        except (KeyError, IndexError, TypeError, AttributeError):
            pass
        return None
    endpoint = next(search_dict(data, "continuationEndpoint"), None)
    if not endpoint:
        endpoint = next(
            (c for c in search_dict(data, "innertubeCommand") if "continuationCommand" in c),
            None
        )

    if not endpoint:
        return None

    continuation_cmd = endpoint.get("continuationCommand")
    if not continuation_cmd:
        continuation_cmd = next(search_dict(endpoint, "continuationCommand"), None)

    if not continuation_cmd or "token" not in continuation_cmd:
        return None

    token = continuation_cmd["token"]
    next_data = {
        "token": token,
        "click_params": {"clickTrackingParams": endpoint.get("clickTrackingParams")},
    }

    return next_data

def search_dict(partial: dict, search_key: str) -> Generator[dict, None, None]:
    stack = [partial]
    while stack:
        current_item = stack.pop(0)
        if isinstance(current_item, dict):
            for key, value in current_item.items():
                if key == search_key:
                    yield value
                else:
                    stack.append(value)
        elif isinstance(current_item, list):
            for value in current_item:
                stack.append(value)

def parse_rich_item_new_format(rich_item: dict) -> dict:
    content = rich_item.get("content", {})
    lockup_view = content.get("lockupViewModel", {})
    if lockup_view:
        return parse_lockup_view_model(lockup_view)
    return None

def parse_lockup_view_model(lockup_view: dict) -> dict:
    try:
        content_id = lockup_view.get("contentId")
        content_type = lockup_view.get("contentType", "")

        if content_type == "LOCKUP_CONTENT_TYPE_PLAYLIST":
            if content_id:
                return {"playlistId": content_id, "contentType": content_type}
            return None

        if content_type and content_type != "LOCKUP_CONTENT_TYPE_VIDEO":
            return None

        video_id = content_id

        if not video_id:
            for endpoint in search_dict(lockup_view, "watchEndpoint"):
                video_id = endpoint.get("videoId")
                if video_id:
                    break

        if not video_id:
            return None

        metadata = lockup_view.get("metadata", {})
        lockup_metadata = metadata.get("lockupMetadataViewModel", {})

        title = lockup_metadata.get("title", {}).get("content", "")

        thumbnail_url = None
        content_image = lockup_view.get("contentImage", {})
        sources = content_image.get("thumbnailViewModel", {}).get("image", {}).get("sources", [])
        if sources:
            thumbnail_url = sources[-1].get("url")

        channel_name = None
        views = None
        upload_time = None

        meta_rows = lockup_metadata.get("metadata", {}).get("contentMetadataViewModel", {}).get("metadataRows", [])

        if len(meta_rows) == 1:
            parts = meta_rows[0].get("metadataParts", [])
            if len(parts) > 0:
                views = parts[0].get("text", {}).get("content", "")
            if len(parts) > 1:
                upload_time = parts[1].get("text", {}).get("content", "")
        elif len(meta_rows) >= 2:
            parts0 = meta_rows[0].get("metadataParts", [])
            if parts0:
                channel_name = parts0[0].get("text", {}).get("content", "")

            parts1 = meta_rows[1].get("metadataParts", [])
            if len(parts1) > 0:
                views = parts1[0].get("text", {}).get("content", "")
            if len(parts1) > 1:
                upload_time = parts1[1].get("text", {}).get("content", "")

        badge_style = _safe_get(
            lockup_view, "contentImage", "thumbnailViewModel", "overlays", 0,
            "thumbnailBottomOverlayViewModel", "badges", 0,
            "thumbnailBadgeViewModel", "badgeStyle",
        )
        is_live = badge_style == "THUMBNAIL_OVERLAY_BADGE_STYLE_LIVE"

        result = {
            "videoId": video_id,
            "title": {"simpleText": title, "runs": [{"text": title}]},
            "is_live": is_live,
        }

        if thumbnail_url:
            result["thumbnail"] = {"thumbnails": [{"url": thumbnail_url}]}
        if channel_name:
            result["shortBylineText"] = {"simpleText": channel_name}
        if views:
            result["viewCountText"] = {"simpleText": views}
        if upload_time:
            result["publishedTimeText"] = {"simpleText": upload_time}

        return result

    except (KeyError, TypeError, AttributeError, IndexError):
        pass

    return None

def parse_shorts_lockup_format(rich_item: dict) -> dict:
    try:
        content = rich_item.get("content", {})
        shorts_lockup = content.get("shortsLockupViewModel", {})

        if not shorts_lockup:
            return None

        video_id = None
        for endpoint in search_dict(shorts_lockup, "reelWatchEndpoint"):
            video_id = endpoint.get("videoId")
            if video_id:
                break

        if not video_id:
            return None

        overlay_metadata = shorts_lockup.get("overlayMetadata", {})
        title = overlay_metadata.get("primaryText", {}).get("content", "")
        views = overlay_metadata.get("secondaryText", {}).get("content", "")

        return {
            "videoId": video_id,
            "title": {"simpleText": title, "runs": [{"text": title}]},
            "viewCountText": {"simpleText": views},
            "isShort": True,
            "is_live": False,
        }

    except (KeyError, TypeError, AttributeError):
        pass

    return None

def _enrich_playlist_lockup(lockup_view: dict, parsed: dict) -> dict:
    metadata = lockup_view.get("metadata", {}).get("lockupMetadataViewModel", {})
    title = metadata.get("title", {}).get("content", "")
    if title:
        parsed["title"] = {"simpleText": title, "runs": [{"text": title}]}
        parsed["title_text"] = title
    sources = _safe_get(
        lockup_view, "contentImage", "collectionThumbnailViewModel",
        "primaryThumbnail", "thumbnailViewModel", "image", "sources", default=[],
    ) or []
    if sources:
        parsed["thumbnail"] = {"thumbnails": [{"url": sources[-1].get("url", "")}]}
    rows = metadata.get("metadata", {}).get(
        "contentMetadataViewModel", {}).get("metadataRows", [])
    if rows:
        channel = rows[0].get("metadataParts", [{}])[0].get("text", {}).get("content", "")
        if channel:
            parsed["shortBylineText"] = {"simpleText": channel}
    parsed["is_live"] = False
    return parsed


def get_videos_items(data: dict, selector: str) -> Generator[dict, None, None]:
    if selector == "playlistRenderer":
        for lockup_view in search_dict(data, "lockupViewModel"):
            if lockup_view.get("contentType") != "LOCKUP_CONTENT_TYPE_PLAYLIST":
                continue
            parsed = parse_lockup_view_model(lockup_view)
            if not parsed:
                continue
            yield _enrich_playlist_lockup(lockup_view, parsed)
        return

    if selector in ("videoRenderer", "playlistVideoRenderer"):
        rich_items = list(search_dict(data, "richItemRenderer"))
        yielded_any = False

        if rich_items:
            for rich_item in rich_items:
                video_data = parse_rich_item_new_format(rich_item)
                if video_data:
                    yielded_any = True
                    yield video_data
                    continue
                video_data = parse_shorts_lockup_format(rich_item)
                if video_data:
                    yielded_any = True
                    yield video_data

        if yielded_any:
            return

        lockup_items = list(search_dict(data, "lockupViewModel"))
        if lockup_items:
            for lockup_view in lockup_items:
                video_data = parse_lockup_view_model(lockup_view)
                if video_data:
                    yielded_any = True
                    yield video_data

        if yielded_any:
            return

        for video in search_dict(data, selector):
            yield video
    else:
        for item in search_dict(data, selector):
            yield item


def _safe_get(obj, *keys, default=None):
    for key in keys:
        try:
            obj = obj[key]
        except Exception:
            return default
    return obj


def _enrich_channel_item(item: dict) -> dict:
    if "is_live" not in item:
        is_live = False
        if (
            _safe_get(
                item, "thumbnailOverlays", 0,
                "thumbnailOverlayTimeStatusRenderer", "style",
            )
            == "LIVE"
        ):
            is_live = True
        item["is_live"] = is_live
    title = item.get("title")
    if isinstance(title, dict):
        item["title_text"] = title.get("simpleText") or _safe_get(
            title, "runs", 0, "text", default=""
        )
    elif isinstance(title, str):
        item["title_text"] = title
    else:
        item["title_text"] = ""
    return item
