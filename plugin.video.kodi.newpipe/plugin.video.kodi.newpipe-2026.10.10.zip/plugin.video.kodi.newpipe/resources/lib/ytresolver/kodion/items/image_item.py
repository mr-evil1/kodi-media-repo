
from __future__ import absolute_import, division, unicode_literals

from .base_item import BaseItem


class ImageItem(BaseItem):
    def __init__(self, name, uri, image='DefaultPicture.png', fanart=None):
        super(ImageItem, self).__init__(name, uri, image, fanart)
