
from __future__ import absolute_import, division, unicode_literals

from .base_item import BaseItem


class UriItem(BaseItem):
    def __init__(self, uri, playable=None):
        super(UriItem, self).__init__(name=uri, uri=uri)
        if playable is not None:
            self._playable = playable
