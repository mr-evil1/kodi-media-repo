
from __future__ import absolute_import, division, unicode_literals

from functools import partial
from itertools import chain

from .storage import Storage
from ..utils.methods import generate_hash


class FunctionCache(Storage):
    _table_name = 'storage_v2'
    _table_updated = False
    _sql = {}

    _BUILTIN = str.__module__
    SCOPE_NONE = 0
    SCOPE_BUILTINS = 1
    SCOPE_ALL = 2

    def __init__(self, filepath, max_file_size_mb=5):
        max_file_size_kb = max_file_size_mb * 1024
        super(FunctionCache, self).__init__(filepath,
                                            max_file_size_kb=max_file_size_kb)
        self._enabled = True

    def enabled(self):
        self._enabled = True

    def disable(self):
        self._enabled = False

    @classmethod
    def _create_id_from_func(cls, partial_func, scope=SCOPE_ALL):
        signature = (
            partial_func.func.__module__,
            partial_func.func.__name__,
        )
        if scope == cls.SCOPE_BUILTINS:
            signature = chain(
                signature,
                ((
                    arg
                    if type(arg).__module__ == cls._BUILTIN else
                    type(arg)
                ) for arg in partial_func.args),
                ((
                    (key, arg)
                    if type(arg).__module__ == cls._BUILTIN else
                    (key, type(arg))
                ) for key, arg in partial_func.keywords.items()),
            )
        elif scope == cls.SCOPE_ALL:
            signature = chain(
                signature,
                partial_func.args,
                partial_func.keywords.items(),
            )
        return generate_hash(iter=signature)

    def get_result(self, func, *args, **kwargs):
        partial_func = partial(func, *args, **kwargs)

        if not self._enabled:
            return partial_func()

        cache_id = self._create_id_from_func(partial_func)
        return self._get(cache_id)

    def run(self, func, seconds=-1, *args, **kwargs):
        scope = kwargs.pop('_scope', self.SCOPE_ALL)
        ignore_value = kwargs.pop('_ignore_value', None)
        oneshot = kwargs.pop('_oneshot', False)
        refresh = kwargs.pop('_refresh', False)
        process = kwargs.pop('_process', None)
        retry_value = kwargs.pop('_retry_value', None)
        partial_func = partial(func, *args, **kwargs)

        if not self._enabled:
            return partial_func()

        cache_id = self._create_id_from_func(partial_func, scope)
        old_data = self._get(cache_id, as_dict=True)
        if old_data:
            age = old_data['age']
            old_data = old_data['value']
            if age > seconds >= 0 or old_data == retry_value:
                refresh = True
        else:
            old_data = None
            refresh = True

        if refresh:
            data = partial_func()
            if callable(process):
                data = process(data, old_data)
        elif callable(process):
            data = process(None, old_data)
        else:
            data = old_data

        if data != ignore_value:
            self._set(cache_id, data)
        elif oneshot:
            self._remove(cache_id)

        return data

    def _optimize_item_count(self, limit=-1, defer=False):
        return False
