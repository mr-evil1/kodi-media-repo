
from __future__ import absolute_import, division, unicode_literals


SETUP_WIZARD = 'kodion.setup_wizard'
SETUP_WIZARD_RUNS = 'kodion.setup_wizard.forced_runs'
SETTINGS_END = '|end_settings_marker|'

MPD_VIDEOS = 'kodion.mpd.videos'
MPD_STREAM_SELECT = 'kodion.mpd.stream.select'
MPD_QUALITY_SELECTION = 'kodion.mpd.quality.selection'
MPD_STREAM_FEATURES = 'kodion.mpd.stream.features'
VIDEO_STREAM_SELECT = 'kodion.video.stream.select'
VIDEO_QUALITY_ASK = 'kodion.video.quality.ask'
VIDEO_QUALITY = 'kodion.video.quality'
AUDIO_ONLY = 'kodion.audio_only'

SUBTITLE_SELECTION = 'kodion.subtitle.languages.num'
SUBTITLE_DOWNLOAD = 'kodion.subtitle.download'

ITEMS_PER_PAGE = 'kodion.content.max_per_page'
HIDE_VIDEOS = 'youtube.view.hide_videos'
SHORTS_DURATION = 'youtube.view.shorts.duration'
FILTER_LIST = 'youtube.view.filter.list'

MY_SUBSCRIPTIONS_FILTER_ENABLED = 'youtube.folder.my_subscriptions_filtered.show'
MY_SUBSCRIPTIONS_FILTER_BLACKLIST = 'youtube.filter.my_subscriptions_filtered.blacklist'
MY_SUBSCRIPTIONS_FILTER_LIST = 'youtube.filter.my_subscriptions_filtered.list'
MY_SUBSCRIPTIONS_SOURCES = 'youtube.folder.my_subscriptions.sources'

SAFE_SEARCH = 'kodion.safe.search'
AGE_GATE = 'kodion.age.gate'

API_CONFIG_PAGE = 'youtube.api.config.page'
API_KEY = 'youtube.api.key'
API_ID = 'youtube.api.id'
API_SECRET = 'youtube.api.secret'
ALLOW_DEV_KEYS = 'youtube.allow.dev.keys'

SHOW_SIGN_IN = 'youtube.folder.sign.in.show'
SHOW_MY_SUBSCRIPTIONS = 'youtube.folder.my_subscriptions.show'
SHOW_MY_SUBSCRIPTIONS_FILTERED = 'youtube.folder.my_subscriptions_filtered.show'
SHOW_RECOMMENDATIONS = 'youtube.folder.recommendations.show'
SHOW_RELATED = 'youtube.folder.related.show'
SHOW_TRENDING = 'youtube.folder.popular_right_now.show'
SHOW_SEARCH = 'youtube.folder.search.show'
SHOW_QUICK_SEARCH = 'youtube.folder.quick_search.show'
SHOW_INCOGNITO_SEARCH = 'youtube.folder.quick_search_incognito.show'
SHOW_MY_LOCATION = 'youtube.folder.my_location.show'
SHOW_MY_CHANNEL = 'youtube.folder.my_channel.show'
SHOW_WATCH_LATER = 'youtube.folder.watch_later.show'
SHOW_LIKED = 'youtube.folder.liked_videos.show'
SHOW_DISLIKED = 'youtube.folder.disliked_videos.show'
SHOW_HISTORY = 'youtube.folder.history.show'
SHOW_PLAYLISTS = 'youtube.folder.playlists.show'
SHOW_SAVED_PLAYLISTS = 'youtube.folder.saved.playlists.show'
SHOW_SUBSCRIPTIONS = 'youtube.folder.subscriptions.show'
SHOW_BOOKMARKS = 'youtube.folder.bookmarks.show'
SHOW_BROWSE_CHANNELS = 'youtube.folder.browse_channels.show'
SHOW_COMPlETED_LIVE = 'youtube.folder.completed.live.show'
SHOW_UPCOMING_LIVE = 'youtube.folder.upcoming.live.show'
SHOW_LIVE = 'youtube.folder.live.show'
SHOW_SWITCH_USER = 'youtube.folder.switch.user.show'
SHOW_SIGN_OUT = 'youtube.folder.sign.out.show'
SHOW_SETUP_WIZARD = 'youtube.folder.settings.show'
SHOW_SETTINGS = 'youtube.folder.settings.advanced.show'

WATCH_LATER_PLAYLIST = 'youtube.folder.watch_later.playlist'
HISTORY_PLAYLIST = 'youtube.folder.history.playlist'

SUPPORT_ALTERNATIVE_PLAYER = 'kodion.support.alternative_player'
DEFAULT_PLAYER_WEB_URLS = 'kodion.default_player.web_urls'
DEFAULT_PLAYER_FALLBACK_VIDEO = 'kodion.default_player.fallback_video'
ALTERNATIVE_PLAYER_WEB_URLS = 'kodion.alternative_player.web_urls'
ALTERNATIVE_PLAYER_MPD = 'kodion.alternative_player.mpd'

USE_ISA = 'kodion.video.quality.isa'
LIVE_STREAMS = 'kodion.live_stream.selection'

USE_LOCAL_HISTORY = 'kodion.history.local'
USE_REMOTE_HISTORY = 'kodion.history.remote'

SEARCH_SIZE = 'kodion.search.size'
CACHE_SIZE = 'kodion.cache.size'

CHANNEL_NAME_ALIASES = 'youtube.view.channel_name.aliases'
DETAILED_DESCRIPTION = 'youtube.view.description.details'
DETAILED_LABELS = 'youtube.view.label.details'
LABEL_COLOR = 'youtube.view.label.color'

THUMB_SIZE = 'kodion.thumbnail.size'
THUMB_SIZE_BEST = 2
FANART_SELECTION = 'kodion.fanart.selection'
FANART_CHANNEL = 2
FANART_THUMBNAIL = 3

LANGUAGE = 'youtube.language'
REGION = 'youtube.region'
LOCATION = 'youtube.location'
LOCATION_RADIUS = 'youtube.location.radius'

PLAY_SUGGESTED = 'youtube.suggested_videos'

PLAY_COUNT_MIN_PERCENT = 'kodion.play_count.percent'

RATE_VIDEOS = 'youtube.post.play.rate'
RATE_PLAYLISTS = 'youtube.post.play.rate.playlists'

AUTO_LIKE = 'youtube.post.play.auto_like'
AUTO_LIKE_FILTER_LIST = 'youtube.post.play.auto_like.filter.list'
AUTO_LIKE_FILTER_STATE = 'youtube.post.play.auto_like.filter.state'

FILTER_DISABLED = 0
FILTER_ENABLED = 1
FILTER_BLACKLIST = 2

PLAY_REFRESH = 'youtube.post.play.refresh'
WATCH_LATER_REMOVE = 'youtube.playlist.watchlater.autoremove'

VERIFY_SSL = 'requests.ssl.verify'
CONNECT_TIMEOUT = 'requests.timeout.connect'
READ_TIMEOUT = 'requests.timeout.read'
REQUESTS_CACHE_SIZE = 'requests.cache.size'

PROXY_SOURCE = 'requests.proxy.source'
PROXY_ENABLED = 'requests.proxy.enabled'
PROXY_TYPE = 'requests.proxy.type'
PROXY_SERVER = 'requests.proxy.server'
PROXY_PORT = 'requests.proxy.port'
PROXY_USERNAME = 'requests.proxy.username'
PROXY_PASSWORD = 'requests.proxy.password'

HTTPD_PORT = 'kodion.http.port'
HTTPD_LISTEN = 'kodion.http.listen'
HTTPD_WHITELIST = 'kodion.http.ip.whitelist'
HTTPD_IDLE_SLEEP = 'youtube.http.idle_sleep'
HTTPD_STREAM_REDIRECT = 'youtube.http.stream_redirect'

LOG_LEVEL = 'kodion.debug.log.level'
EXEC_LIMIT = 'kodion.debug.exec.limit'
