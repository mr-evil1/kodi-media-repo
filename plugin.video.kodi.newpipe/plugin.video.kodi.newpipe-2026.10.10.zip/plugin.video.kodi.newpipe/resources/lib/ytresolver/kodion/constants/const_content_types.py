
from __future__ import absolute_import, division, unicode_literals


VIDEO_CONTENT = 'videos'
LIST_CONTENT = 'files'

COMMENTS = 'comments'
HISTORY = 'history'
PLAYLIST = 'playlist'

AUDIO_TYPE = 'music'
VIDEO_TYPE = 'video'

FILES = 'files'
SONGS = 'songs'
ARTISTS = 'artists'
ALBUMS = 'albums'
MOVIES = 'movies'
TV_SHOWS = 'tvshows'
EPISODES = 'episodes'
VIDEOS = 'videos'
MUSIC_VIDEOS = 'musicvideos'
