
from __future__ import absolute_import, division, unicode_literals

class DummyPlayer(object):
    pass

XbmcPlaylistPlayer = DummyPlayer

__all__ = ('XbmcPlaylistPlayer',)
