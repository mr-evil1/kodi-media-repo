
from __future__ import absolute_import, division, unicode_literals

from .abstract_context_ui import AbstractContextUI

XbmcContextUI = AbstractContextUI

__all__ = ('AbstractContextUI', 'XbmcContextUI')
