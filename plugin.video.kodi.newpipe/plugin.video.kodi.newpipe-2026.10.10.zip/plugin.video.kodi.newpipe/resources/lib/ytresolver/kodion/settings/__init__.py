
from __future__ import absolute_import, division, unicode_literals

from .xbmc.xbmc_plugin_settings import XbmcPluginSettings


__all__ = ('XbmcPluginSettings',)
