
from __future__ import absolute_import, division, unicode_literals

from .standalone.standalone_context import StandaloneContext
from .abstract_context import AbstractContext

XbmcContext = StandaloneContext

__all__ = ('StandaloneContext', 'AbstractContext', 'XbmcContext')
