
from __future__ import absolute_import, division, unicode_literals

from ..kodion import KodionException
from ..kodion.network import InvalidJSONError


class LoginException(KodionException):
    pass


class YouTubeException(KodionException):
    pass


class InvalidGrant(KodionException):
    pass


class InvalidJSON(KodionException, InvalidJSONError):
    pass
