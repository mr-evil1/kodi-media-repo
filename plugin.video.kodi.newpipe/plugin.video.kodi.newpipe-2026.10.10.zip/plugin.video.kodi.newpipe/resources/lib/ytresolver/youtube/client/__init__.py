
from __future__ import absolute_import, division, unicode_literals

from .player_client import YouTubePlayerClient


__all__ = (
    'YouTubePlayerClient',
)
