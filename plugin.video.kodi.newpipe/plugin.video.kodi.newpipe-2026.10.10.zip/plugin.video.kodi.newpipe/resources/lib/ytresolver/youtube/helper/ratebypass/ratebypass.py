
from __future__ import absolute_import, division, unicode_literals

import re

from ....kodion import logging


def throttling_reverse(arr):
    reverse_copy = arr[::-1]
    for i in range(len(reverse_copy)):
        arr[i] = reverse_copy[i]


def throttling_push(d, e):
    d.append(e)


def throttling_mod_func(d, e):
    return (e % len(d) + len(d)) % len(d)


def throttling_unshift(d, e):
    e = throttling_mod_func(d, e)
    new_arr = d[-e:] + d[:-e]
    del d[:]
    for el in new_arr:
        d.append(el)


def throttling_cipher_helper(d, e, h):
    f = 96
    this = list(e)

    copied_list = d[:]

    for m, l in enumerate(copied_list):
        bracket_val = (h.index(l) - h.index(this[m]) + m - 32 + f) % len(h)
        this.append(
            h[bracket_val]
        )
        d[m] = h[bracket_val]
        f -= 1


def throttling_cipher_function_a(d, e):
    h = list('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_')
    throttling_cipher_helper(d, e, h)


def throttling_cipher_function_b(d, e):
    h = list('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_')
    throttling_cipher_helper(d, e, h)


def throttling_nested_splice(d, e):
    e = throttling_mod_func(d, e)
    inner_splice = js_splice(
        d,
        e,
        1,
        d[0]
    )
    js_splice(
        d,
        0,
        1,
        inner_splice[0]
    )


def throttling_prepend(d, e):
    start_len = len(d)
    e = throttling_mod_func(d, e)

    new_arr = d[-e:] + d[:-e]

    del d[:]
    for el in new_arr:
        d.append(el)

    end_len = len(d)
    assert start_len == end_len


def throttling_swap(d, e):
    e = throttling_mod_func(d, e)
    f = d[0]
    d[0] = d[e]
    d[e] = f


def js_splice(arr, start, delete_count=None, *items):
    try:
        if start > len(arr):
            start = len(arr)
        if start < 0:
            start = len(arr) - start
    except TypeError:
        start = 0

    if not delete_count or delete_count >= len(arr) - start:
        delete_count = len(arr) - start

    deleted_elements = arr[start:start + delete_count]

    new_arr = arr[:start] + list(items) + arr[start + delete_count:]

    del arr[:]
    for el in new_arr:
        arr.append(el)

    return deleted_elements


def throttling_splice(d, e):
    e = throttling_mod_func(d, e)
    js_splice(d, e, 1)


class CalculateN(object):

    MAPPING_FUNC_PATTERNS = (
        (r"{for\(\w=\(\w%\w\.length\+\w\.length\)%\w\.length;\w--;\)\w\.unshift\(\w.pop\(\)\)}", throttling_unshift),
        (r"{\w\.reverse\(\)}", throttling_reverse),
        (r"{\w\.push\(\w\)}", throttling_push),
        (r";var\s\w=\w\[0\];\w\[0\]=\w\[\w\];\w\[\w\]=\w}", throttling_swap),
        (r"case\s65", throttling_cipher_function_b),
        (r"case\s\d+", throttling_cipher_function_a),
        (r"\w\.splice\(0,1,\w\.splice\(\w,1,\w\[0\]\)\[0\]\)", throttling_nested_splice),
        (r";\w\.splice\(\w,1\)}", throttling_splice),
        (r"\w\.splice\(-\w\)\.reverse\(\)\.forEach\(function\(\w\){\w\.unshift\(\w\)}\)", throttling_prepend),
        (r"for\(var \w=\w\.length;\w;\)\w\.push\(\w\.splice\(--\w,1\)\[0\]\)}", throttling_reverse),
    )

    def __init__(self, js):
        self.calculated_n = None
        self.throttling_function_code = self.get_throttling_function_code(js)

    @staticmethod
    def get_throttling_function_code(js):
        fiduciary_index = js.find('enhanced_except_')
        if fiduciary_index == -1:
            logging.debug('fiduciary_index not found')
            return None

        start_index = js.rfind('=function(', 0, fiduciary_index)
        if start_index == -1:
            logging.debug('function code start not found')
            return None

        end_index = js.find('};', fiduciary_index)
        if end_index == -1:
            logging.debug('function code end not found')
            return None

        return js[start_index:end_index].replace('\n', '')

    @staticmethod
    def get_throttling_plan_gen(raw_code):
        plan_start_pattern = 'try{'
        plan_start_index = raw_code.find(plan_start_pattern)
        if plan_start_index == -1:
            logging.debug('command block start not found')
            raise Exception()
        else:
            plan_start_index += len(plan_start_pattern)

        plan_end_index = raw_code.find('}', plan_start_index)
        if plan_end_index == -1:
            logging.debug('command block end not found')
            raise Exception()

        plan_code = raw_code[plan_start_index:plan_end_index]

        for command in (plan_code.strip('c)').replace('[', '')
                .replace(']', '').replace('(', ',')
                .replace('c', '').split('),')):
            yield command.split(',')

    @staticmethod
    def array_reverse_split_gen(array_code):
        accumulator = None
        for piece in reversed(array_code.split(',')):
            if piece.startswith('function') or piece[0] == '"' or piece[0] == "'":
                if accumulator:
                    yield piece + ',' + accumulator
                    accumulator = None
                else:
                    yield piece
            elif piece.endswith('}') or piece[-1] == '"' or piece[-1] == "'":
                accumulator = piece
            else:
                if accumulator:
                    accumulator = piece + ',' + accumulator
                else:
                    yield piece

    @classmethod
    def get_throttling_function_array(cls, mutable_n_list, raw_code):

        array_start_pattern = ",c=["
        array_start_index = raw_code.find(array_start_pattern)
        if array_start_index == -1:
            logging.debug('"c" array pattern not found')
            raise Exception()
        else:
            array_start_index += len(array_start_pattern)

        array_end_index = raw_code.rfind('];')
        if array_end_index == -1:
            logging.debug('"c" array end not found')
            raise Exception()

        array_code = raw_code[array_start_index:array_end_index]

        converted_array = []
        for el in cls.array_reverse_split_gen(array_code):
            try:
                converted_array.append(int(el))
                continue
            except ValueError:
                pass

            if el == 'null':
                converted_array.append(converted_array)
                continue

            if el[0] == '"' or el[0] == "'":
                converted_array.append(el.strip('\'"'))
                continue

            if el.startswith('function'):
                found = False
                for pattern, fn in cls.MAPPING_FUNC_PATTERNS:
                    if re.search(pattern, el):
                        converted_array.append(fn)
                        found = True
                        break
                else:
                    logging.debug('unknown mapping function: %s', el)
                if found:
                    continue

            converted_array.append(mutable_n_list)

        converted_array.reverse()
        return converted_array

    def calculate_n(self, mutable_n_list):
        if self.calculated_n:
            logging.debug('Reusing calculated "n": %s', self.calculated_n)
            return self.calculated_n

        if not self.throttling_function_code:
            return None

        logging.debug('Attempting to calculate "n" from initial: %s',
                      ''.join(mutable_n_list))

        try:
            throttling_array = self.get_throttling_function_array(
                mutable_n_list,
                self.throttling_function_code
            )
            for step in self.get_throttling_plan_gen(self.throttling_function_code):
                curr_func = throttling_array[int(step[0])]
                if not callable(curr_func):
                    logging.debug('%s is not callable', curr_func)
                    logging.debug(('Throttling array:', '%r'), throttling_array)
                    return None

                first_arg = throttling_array[int(step[1])]

                if len(step) == 2:
                    curr_func(first_arg)
                elif len(step) == 3:
                    second_arg = throttling_array[int(step[2])]
                    curr_func(first_arg, second_arg)
        except Exception:
            logging.exception('Error calculating "n"')
            return None

        self.calculated_n = ''.join(mutable_n_list)
        logging.debug('Calculated "n": %s', self.calculated_n)
        return self.calculated_n
