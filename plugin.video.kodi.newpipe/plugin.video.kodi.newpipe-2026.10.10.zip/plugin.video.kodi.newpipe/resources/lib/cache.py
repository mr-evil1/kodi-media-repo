import functools
import hashlib
import os
import pickle
import time


class FunctionCache:
    def __init__(self, cache_dir):
        self._dir = cache_dir
        try:
            os.makedirs(cache_dir, exist_ok=True)
        except OSError:
            pass

    def _key(self, fn, args, kwargs):
        raw = '{0}.{1}|{2}|{3}'.format(
            fn.__module__, fn.__qualname__,
            repr(args), repr(tuple(sorted(kwargs.items())))
        )
        return hashlib.md5(raw.encode('utf-8')).hexdigest()

    def cache_function(self, duration_minutes):
        def decorator(fn):
            @functools.wraps(fn)
            def wrapper(*args, **kwargs):
                if duration_minutes <= 0:
                    return fn(*args, **kwargs)
                key = self._key(fn, args, kwargs)
                path = os.path.join(self._dir, key + '.pkl')
                if os.path.exists(path):
                    try:
                        with open(path, 'rb') as f:
                            ts, data = pickle.load(f)
                        if time.time() - ts < duration_minutes * 60:
                            return data
                    except Exception:
                        pass
                result = fn(*args, **kwargs)
                is_empty = (
                    (isinstance(result, (list, tuple)) and len(result) == 0) or
                    (isinstance(result, tuple) and len(result) >= 1 and
                     isinstance(result[0], (list, tuple)) and len(result[0]) == 0)
                )
                if not is_empty:
                    try:
                        os.makedirs(self._dir, exist_ok=True)
                        with open(path, 'wb') as f:
                            pickle.dump((time.time(), result), f)
                    except Exception:
                        pass
                return result
            return wrapper
        return decorator

    def reset_cache(self):
        try:
            for f in os.listdir(self._dir):
                if f.endswith('.pkl'):
                    os.remove(os.path.join(self._dir, f))
            return True
        except Exception:
            return False
