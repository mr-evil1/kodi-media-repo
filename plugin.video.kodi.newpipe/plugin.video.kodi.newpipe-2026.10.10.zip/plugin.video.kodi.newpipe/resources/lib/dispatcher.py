_registry = {}


class _Dispatcher:
    def register(self, action, kwargs=None):
        def decorator(fn):
            _registry[action] = (fn, list(kwargs or []))
            return fn
        return decorator

    def dispatch(self, action, params):
        entry = _registry.get(action)
        if not entry:
            return
        fn, kwarg_keys = entry
        kw = {k: params[k] for k in kwarg_keys if k in params}
        fn(**kw)


urldispatcher = _Dispatcher()
