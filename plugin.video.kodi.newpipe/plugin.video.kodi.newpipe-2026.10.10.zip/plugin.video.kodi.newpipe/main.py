from sys import argv
from urllib.parse import parse_qsl

from resources.lib.dispatcher import urldispatcher
from resources.lib import routes
from resources.lib import logger


def run(argv):
    logger.refresh()
    params = dict(parse_qsl(argv[2][1:]))
    logger.debug('dispatch {0}'.format(argv[2]), 'main')
    try:
        urldispatcher.dispatch(params.get('action') or 'root', params)
    except Exception:
        logger.exception('unhandled error in action ' + str(params.get('action') or 'root'), 'main')
        raise


if __name__ == '__main__':
    run(argv)
