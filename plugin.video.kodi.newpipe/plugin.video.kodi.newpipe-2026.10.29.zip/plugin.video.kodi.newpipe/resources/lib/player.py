import inspect
import os
import re
import sys
from urllib.parse import parse_qs, parse_qsl, urlencode, urlparse

from resolveurl import add_plugin_dirs
from resolveurl.hmf import HostedMediaFile
from . import directory, kodi
from .kodi import log
from . import logger
from .constants import YT_WATCH

_LIB_DIR = os.path.dirname(os.path.abspath(__file__))
_PLUGINS_DIR = os.path.join(_LIB_DIR, 'resolveurl_plugins')

_EMOJI_RE = re.compile(
    r'['
    r'\U0001F000-\U0001FAFF'
    r'\U0001F1E6-\U0001F1FF'
    r'\U00002700-\U000027BF'
    r'\U00002600-\U000026FF'
    r'\U0001F900-\U0001F9FF'
    r'\U00002300-\U000023FF'
    r'\U00002B00-\U00002BFF'
    r'\U00003200-\U000032FF'
    r'\U0000FE00-\U0000FE0F'
    r'\U0000200D'
    r']+', flags=re.UNICODE
)


_CLEAN_RE = re.compile(r'[^a-zA-Z0-9äöüÄÖÜß\s.,!?:;#/|()\'&+_-]', flags=re.UNICODE)


def _clean_text(text):
    if not isinstance(text, str):
        return text
    cleaned = _CLEAN_RE.sub('', text)
    return re.sub(r'\s+', ' ', cleaned).strip()


def _ensure_lib_path():
    if _LIB_DIR not in sys.path:
        sys.path.insert(0, _LIB_DIR)


def _audio_stream(resolver, url):
    spec = inspect.getfullargspec(resolver.get_media_url)
    if 'audio_only' not in (spec.args or []) + (spec.kwonlyargs or []):
        return None
    host, media_id = resolver.get_host_and_id(url)
    res = resolver.get_media_url(host, media_id, audio_only=True)
    if isinstance(res, (tuple, list)):
        res = res[0]
    return res


def resolve(video_id, audio_only=False):
    _ensure_lib_path()
    url = video_id if (video_id or '').startswith('http') else YT_WATCH + video_id
    logger.debug('resolve {0} audio_only={1}'.format(url, audio_only), 'player')
    add_plugin_dirs(kodi.transPath(_PLUGINS_DIR))
    hmf = HostedMediaFile(url)
    if not hmf.valid_url():
        return None
    if audio_only:
        try:
            for resolver in hmf.get_resolvers(validated=True):
                stream = _audio_stream(resolver, url)
                if stream:
                    return stream
        except Exception as e:
            logger.exception('audio-only resolve failed: {0}'.format(e), 'player')
    try:
        result = hmf.resolve() or None
        logger.debug('resolve result: {0}'.format(result), 'player')
        return result
    except Exception as e:
        logger.exception('resolve failed: {0}'.format(e), 'player')
        return None


def _isa_enabled():
    try:
        return kodi.addon_details('inputstream.adaptive').get('enabled')
    except Exception:
        return False


def _is_hls(url):
    return '/hls_variant/' in url or '/hls_playlist/' in url or '.m3u8' in url


def _max_height():
    try:
        value = int(kodi.setting('video_max_height') or 1080)
    except ValueError:
        value = 1080
    return max(value, 0)


YT_ADDON_ID = 'plugin.video.youtube'
YT_ADDON_PLAY = 'plugin://plugin.video.youtube/play/?video_id='


def _extract_id(value):
    value = value or ''
    if value.startswith('http'):
        parsed = urlparse(value)
        ids = parse_qs(parsed.query).get('v')
        if ids:
            return ids[0]
        return parsed.path.rstrip('/').rpartition('/')[2]
    return value


def _youtube_addon_enabled():
    if kodi.setting('use_youtube_addon') != 'true':
        return False
    if kodi.addon_details(YT_ADDON_ID).get('enabled'):
        return True
    logger.error('use_youtube_addon is on but {0} is not available'.format(YT_ADDON_ID), 'player')
    return False


def play(video_id, title='', image=''):
    title = _clean_text(title)

    if _youtube_addon_enabled():
        stream = YT_ADDON_PLAY + _extract_id(video_id)
        logger.info('playing via youtube addon: {0}'.format(stream), 'player')
        directory.resolve(stream, meta={'title': title}, icon=image)
        return

    audio_only = kodi.setting('audio_only') == 'true'
    stream = resolve(video_id, audio_only=audio_only)

    if not stream:
        kodi.infoDialog('No playable stream found')
        import sys as _sys
        kodi.resolve(int(_sys.argv[1]), False, kodi.item())
        return

    headers = ''
    if '|' in stream:
        stream, _, raw_headers = stream.rpartition('|')
        headers = urlencode(dict(parse_qsl(raw_headers)))

    isa = _isa_enabled()
    hls = isa and _is_hls(stream)
    dash = isa and not hls and ('.mpd' in stream or 'dash' in stream)

    if headers and not hls:
        stream = '|'.join([stream, headers])

    max_height = _max_height()
    logger.info('playing: {0} hls={1} limit={2}'.format(stream, bool(hls), max_height or 'max'), 'player')
    directory.resolve(
        stream, meta={'title': title}, icon=image,
        dash=bool(dash or hls),
        manifest_type='hls' if hls else ('mpd' if dash else None),
        headers=headers if hls else '',
        max_height=max_height if hls else None,
    )
