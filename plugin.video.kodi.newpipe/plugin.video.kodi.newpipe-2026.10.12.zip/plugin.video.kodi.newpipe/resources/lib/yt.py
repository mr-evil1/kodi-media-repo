import re

from .scrapetube.wrapper import (
    list_search, list_channel_videos, list_playlist_videos, list_playlists,
    list_channel_videos_paged, list_search_paged,
)
from .scrapetube.scrapetube import get_search, search_dict, _safe_get

from .constants import cache_function, cache_duration

_EMOJI_RE = re.compile(
    r'['
    r'\U0001F000-\U0001FAFF'
    r'\U0001F1E6-\U0001F1FF'
    r'\U00002700-\U000027BF'
    r'\U00002600-\U000026FF'
    r'\U0001F900-\U0001F9FF'
    r'\U00002300-\U000023FF'
    r'\U00002B00-\U00002BFF'
    r'\U00003200-\U000032FF'
    r'\U0000FE00-\U0000FE0F'
    r'\U0000200D'
    r']+', flags=re.UNICODE
)


_CLEAN_RE = re.compile(r'[^a-zA-Z0-9äöüÄÖÜß\s.,!?:;#/|()\'&+_-]', flags=re.UNICODE)


def _clean_text(text):
    if not isinstance(text, str):
        return text
    cleaned = _CLEAN_RE.sub('', text)
    return re.sub(r'\s+', ' ', cleaned).strip()
    

def _channel_url(raw):
    for endpoint in search_dict(raw, 'browseEndpoint'):
        browse_id = (endpoint or {}).get('browseId', '')
        if browse_id.startswith('UC'):
            return 'https://www.youtube.com/channel/' + browse_id
    return ''


def _channel_name(raw, url):
    owner = raw.get('ownerText') or raw.get('shortBylineText') or raw.get('longBylineText') or {}
    name = owner.get('simpleText') or _safe_get(owner, 'runs', 0, 'text', default='')
    if name:
        return _clean_text(name)
    for endpoint in search_dict(raw, 'browseEndpoint'):
        base = (endpoint or {}).get('canonicalBaseUrl', '')
        if base.startswith('/@'):
            return _clean_text(base[2:])
    return url


@cache_function(cache_duration(15))
def search_videos(query, limit=25, sort='relevance', continuation=None):
    items, next_token = list_search_paged(query, limit=limit, sort_by=sort, continuation=continuation)
    enriched = []
    for item in items:
        enriched.append((item, '', ''))
    return enriched, next_token


@cache_function(cache_duration(15))
def trending_videos(query, limit=25, continuation=None):
    items, next_token = list_search_paged(query, limit=limit, sort_by='view_count', continuation=continuation)
    return ([(i, '', '') for i in items], next_token)


@cache_function(cache_duration(10))
def live_videos(query, limit=25, continuation=None):
    import urllib.parse
    items, next_token = list_search_paged(
        query + ' live', limit=limit, sort_by='relevance', continuation=continuation
    )
    return ([(i, '', '') for i in items], next_token)


@cache_function(cache_duration(30))
def channel_videos(url, tab='videos', limit=25, continuation=None):
    items, next_token = list_channel_videos_paged(
        channel_url=url, limit=limit, sleep=0, content_type=tab, continuation=continuation
    )
    return ([(i, '', '') for i in items], next_token)


@cache_function(cache_duration(60))
def channel_playlists(url):
    return list_playlists(url.rstrip('/') + '/playlists')


def playlist_videos(playlist_id, limit=50, continuation=None):
    items = list_playlist_videos(playlist_id, sleep=0)
    return (items, None)
