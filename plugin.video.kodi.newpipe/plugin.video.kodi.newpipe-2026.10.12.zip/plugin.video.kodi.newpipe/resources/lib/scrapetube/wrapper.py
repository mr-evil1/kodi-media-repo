from __future__ import absolute_import
import re
from .scrapetube import get_videos, get_channel, get_playlist, get_search, get_videos_paged

YT_ADDON_ID = 'plugin.video.youtube'
YT_ADDON = 'plugin://{0}'.format(YT_ADDON_ID)
YT_ADDON = ''.join([YT_ADDON, '/play/?video_id={0}'])
YT_PREFIX = 'https://www.youtube.com/watch?v={0}'

_EMOJI_RE = re.compile(
    r'['
    r'\U0001F000-\U0001FAFF'
    r'\U0001F1E6-\U0001F1FF'
    r'\U00002700-\U000027BF'
    r'\U00002600-\U000026FF'
    r'\U0001F900-\U0001F9FF'
    r'\U00002300-\U000023FF'
    r'\U00002B00-\U00002BFF'
    r'\U00003200-\U000032FF'
    r'\U0000FE00-\U0000FE0F'
    r'\U0000200D'
    r']+', flags=re.UNICODE
)


def _clean_text(text):
    if not isinstance(text, str):
        return text
    return _EMOJI_RE.sub('', text).strip()


def duration_converter(duration):
    if duration is None:
        return 0

    if not isinstance(duration, str):
        try:
            return int(duration)
        except (TypeError, ValueError):
            return 0

    text = duration.strip().upper()
    if not text or text in ('LIVE', 'SHORTS', 'UPCOMING', 'PREMIERE'):
        return 0

    text = text.split('•')[0].strip()

    try:
        parts = [int(p) for p in text.split(':')]
    except ValueError:
        return 0

    if not parts:
        return 0

    total = 0
    for part in parts:
        total = total * 60 + part

    return total


def _get_title(item):
    if not isinstance(item, dict):
        return ''

    title_text = item.get('title_text')
    if isinstance(title_text, str) and title_text:
        return _clean_text(title_text)

    title = item.get('title')
    if isinstance(title, str) and title:
        return _clean_text(title)

    if isinstance(title, dict):
        simple = title.get('simpleText')
        if isinstance(simple, str) and simple:
            return _clean_text(simple)
        try:
            runs = title.get('runs') or []
            if runs and isinstance(runs[0], dict):
                text = runs[0].get('text')
                if isinstance(text, str):
                    return _clean_text(text)
        except (AttributeError, IndexError, KeyError, TypeError):
            pass

    return ''


def _get_thumbnail(item, thumb_quality=-1):
    try:
        thumbs = item.get('thumbnail', {}).get('thumbnails') or []
        if thumbs:
            return thumbs[thumb_quality]['url']
    except (AttributeError, IndexError, KeyError, TypeError):
        pass

    try:
        thumbs = item.get('thumbnail', {}).get('thumbnails') or []
        if thumbs:
            return thumbs[-1]['url']
    except (AttributeError, IndexError, KeyError, TypeError):
        pass

    return ''


def _get_duration_text(item):
    try:
        overlays = item.get('thumbnailOverlays') or []
        if overlays:
            return overlays[0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']
    except (AttributeError, IndexError, KeyError, TypeError):
        pass

    length = item.get('lengthText')
    if isinstance(length, dict):
        simple = length.get('simpleText')
        if isinstance(simple, str):
            return simple

    return ''


def _build_video_dict(item, add_prefix=True, thumb_quality=-1, add_url=YT_PREFIX):
    video_id = item.get('videoId', '')

    return dict(
        title=_get_title(item),
        url=add_url.format(video_id) if add_prefix else video_id,
        image=_get_thumbnail(item, thumb_quality),
        duration=duration_converter(_get_duration_text(item)),
        is_live=bool(item.get('is_live', False)),
    )


def _build_playlist_dict(item):
    return dict(
        title=_get_title(item),
        url=item.get('playlistId', ''),
        image=_get_thumbnail(item, 0),
    )


def list_channel_videos(
    channel_id=None, channel_url=None, limit=None, sleep=1, sort_by="newest",
    content_type="videos", add_prefix=True, thumb_quality=-1, add_url=YT_PREFIX,
    proxies=None, cookies=None
):
    items_list = list(get_channel(
        channel_id=channel_id, channel_url=channel_url, limit=limit,
        sleep=sleep, sort_by=sort_by, content_type=content_type,
        proxies=proxies, cookies=cookies,
    ))

    items_list = [
        _build_video_dict(i, add_prefix, thumb_quality, add_url)
        for i in items_list
    ]

    return items_list


def list_playlists(
    url, api='https://www.youtube.com/youtubei/v1/browse', renderer='gridPlaylistRenderer', limit=None, sleep=1
):
    items_list = list(get_videos(url, api, "contents", renderer, limit, sleep))

    items_list = [
        _build_playlist_dict(i) for i in items_list
    ]

    return items_list


def list_playlist_videos(url, limit=None, sleep=1, add_prefix=True, thumb_quality=-1, add_url=YT_PREFIX, cookies=None):
    items_list = list(get_playlist(url, limit, sleep, cookies=cookies))

    items_list = [
        _build_video_dict(i, add_prefix, thumb_quality, add_url)
        for i in items_list
    ]

    return items_list


def list_search(
    query, limit=None, sleep=1, sort_by="relevance", results_type="video", add_prefix=True, thumb_quality=-1, add_url=YT_PREFIX, cookies=None
):
    items_list = list(get_search(query, limit, sleep, sort_by, results_type, cookies=cookies))

    if results_type == 'video':
        items_list = [
            _build_video_dict(i, add_prefix, thumb_quality, add_url)
            for i in items_list
        ]
        return items_list

    elif results_type == 'playlist':
        items_list = [
            _build_playlist_dict(i) for i in items_list
        ]
        return items_list

    else:
        return


def list_channel_videos_paged(
    channel_id=None, channel_url=None, limit=None, sleep=0, sort_by="newest",
    content_type="videos", add_prefix=True, thumb_quality=-1, add_url=YT_PREFIX,
    proxies=None, cookies=None, continuation=None
):
    base_url = ""
    if channel_url:
        base_url = channel_url
    elif channel_id:
        base_url = "https://www.youtube.com/channel/{}".format(channel_id)

    url = "{}/{}?view=2".format(base_url, content_type)
    api_endpoint = "https://www.youtube.com/youtubei/v1/browse"

    from .scrapetube import type_property_map
    selector_item = type_property_map.get(content_type, "videoRenderer")

    raw_items, next_token = get_videos_paged(
        url, api_endpoint, "contents", selector_item,
        limit, sleep, proxies, sort_by, content_type, cookies, continuation
    )

    items = [_build_video_dict(i, add_prefix, thumb_quality, add_url) for i in raw_items]
    return items, next_token


def list_search_paged(
    query, limit=None, sleep=0, sort_by="relevance", results_type="video",
    add_prefix=True, thumb_quality=-1, add_url=YT_PREFIX, cookies=None, continuation=None
):
    import urllib.parse
    url = "https://www.youtube.com/results?search_query={}".format(
        urllib.parse.quote(query, safe="")
    )
    api_endpoint = "https://www.youtube.com/youtubei/v1/search"

    sort_by_map = {"relevance": "A", "upload_date": "I", "view_count": "M", "rating": "E"}
    results_type_map = {
        "video": ["B", "videoRenderer"],
        "channel": ["C", "channelRenderer"],
        "playlist": ["D", "playlistRenderer"],
        "movie": ["E", "videoRenderer"],
    }
    param_string = "CA{}SAhA{}".format(sort_by_map.get(sort_by, "A"), results_type_map[results_type][0])
    url = url + "&sp=" + param_string
    selector_item = results_type_map[results_type][1]

    raw_items, next_token = get_videos_paged(
        url, api_endpoint, "contents", selector_item,
        limit, sleep, None, sort_by, None, cookies, continuation
    )

    if results_type == 'video':
        items = [_build_video_dict(i, add_prefix, thumb_quality, add_url) for i in raw_items]
    elif results_type == 'playlist':
        items = [_build_playlist_dict(i) for i in raw_items]
    else:
        items = raw_items

    return items, next_token
