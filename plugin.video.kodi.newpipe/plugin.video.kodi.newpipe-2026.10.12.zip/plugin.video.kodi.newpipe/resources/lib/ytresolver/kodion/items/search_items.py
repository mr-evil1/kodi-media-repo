
from __future__ import absolute_import, division, unicode_literals

from . import context_menu_items as menu_items
from .directory_item import DirectoryItem
from ..constants import CHANNEL_ID, INCOGNITO, PATHS


class SearchItem(DirectoryItem):
    def __init__(self,
                 context,
                 name=None,
                 image=None,
                 fanart=None,
                 location=False):
        if not name:
            name = context.localize('search')

        if image is None:
            image = '{media}/search.png'

        params = {}
        if location:
            params['location'] = location

        super(SearchItem, self).__init__(name,
                                         context.create_uri(
                                             (PATHS.SEARCH, 'list',),
                                             params=params,
                                         ),
                                         image=image,
                                         fanart=fanart)

        context_menu = [
            menu_items.search_clear(context),
            menu_items.separator(),
            menu_items.goto_quick_search(context, params),
            menu_items.goto_quick_search(context, params, incognito=True)
        ]
        self.add_context_menu(context_menu)


class SearchHistoryItem(DirectoryItem):
    def __init__(self, context, query, image=None, fanart=None, location=False):
        if image is None:
            image = '{media}/search.png'

        if isinstance(query, dict):
            params = query
            query = params['q']
        else:
            params = {'q': query}
        if location:
            params['location'] = location

        super(SearchHistoryItem, self).__init__(query,
                                                context.create_uri(
                                                    (PATHS.SEARCH, 'query',),
                                                    params=params,
                                                ),
                                                image=image,
                                                fanart=fanart)

        context_menu = [
            menu_items.search_remove(context, query),
            menu_items.search_rename(context, query),
            menu_items.search_clear(context),
            menu_items.separator(),
            menu_items.search_sort_by(context, params, 'relevance'),
            menu_items.search_sort_by(context, params, 'date'),
            menu_items.search_sort_by(context, params, 'viewCount'),
            menu_items.search_sort_by(context, params, 'rating'),
            menu_items.search_sort_by(context, params, 'title'),
        ]
        self.add_context_menu(context_menu)


class NewSearchItem(DirectoryItem):
    def __init__(self,
                 context,
                 name=None,
                 title=None,
                 image=None,
                 fanart=None,
                 incognito=False,
                 channel_id='',
                 addon_id='',
                 location=False,
                 **kwargs):
        if not name:
            name = context.get_ui().bold(
                title or context.localize('search.new')
            )

        if image is None:
            image = '{media}/new_search.png'

        params = {}
        if addon_id:
            params['addon_id'] = addon_id
        if incognito:
            params[INCOGNITO] = incognito
        if channel_id:
            params[CHANNEL_ID] = channel_id
        if location:
            params['location'] = location

        super(NewSearchItem, self).__init__(name,
                                            context.create_uri(
                                                (PATHS.SEARCH, 'input',),
                                                params=params,
                                            ),
                                            image=image,
                                            fanart=fanart,
                                            **kwargs)

        if context.is_plugin_path(context.get_uri(), ((PATHS.SEARCH, 'list'),)):
            context_menu = [
                menu_items.search_clear(context),
                menu_items.separator(),
                menu_items.goto_quick_search(context, params, not incognito)
            ]
        else:
            context_menu = [
                menu_items.goto_quick_search(context, params, not incognito)
            ]
        self.add_context_menu(context_menu)
