import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import json
import random
import os
import sys
import urllib.parse
import urllib.request
import ssl
import mod


addon = xbmcaddon.Addon('script.ydkj.quiz')
enable_music = (addon.getSetting('enable_music') == 'true')
lang_value = addon.getSetting('language')
lang_code = "sv" if lang_value == "Schwedisch" else "de"


def vorlesen(text):
    vorlese_text = text.replace("[B]", "").replace("[/B]", "").replace("„", '"').replace("“", '"')
    kodierter_text = urllib.parse.quote(vorlese_text)
    tts_url = f"https://translate.google.com/translate_tts?ie=UTF-8&tl={lang_code}&client=tw-ob&q={kodierter_text}"    
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        headers = {'User-Agent': 'Mozilla/5.0'}
        req = urllib.request.Request(tts_url, headers=headers)        
        with urllib.request.urlopen(req, context=ctx, timeout=2) as response:
            if response.status == 200:
                tts_player = xbmc.Player()
                tts_player.play(tts_url)
            else:
                pass
    except Exception:
        pass


class Jackui(xbmcgui.WindowXML):
    def __new__(cls, xml_filename, script_path, *args, **kwargs):
        addon_basis_pfad = xbmcvfs.translatePath(script_path)
        return super(Jackui, cls).__new__(cls, xml_filename, addon_basis_pfad, 'Default', '1080i')

    
    def __init__(self, xml_filename, script_path):
        super(Jackui, self).__init__()
        self.auswahl = -1
        self.beendet = False


    def onInit(self):
        pass


    def zeige_neue_frage(self, runde, runden_anzahl, kategorie, frage, antworten, punktestand, anzahl_spieler):
        stop_audio()
        self.beendet = False
        self.auswahl = -1
        self.anzahl_spieler = anzahl_spieler
        self.antworten = antworten
        self.getControl(1001).setLabel(f"Runde {runde}/{runden_anzahl}   •   Kategorie: {kategorie}")
        self.getControl(1003).setLabel(punktestand)
        self.clear_screen_for_dialog()        
        xbmc.sleep(1000)        
        self.getControl(1002).setText(f"[B]{frage}[/B]")
        vorlesen(frage)
        self.getControl(2001).setLabel(f"[COLOR yellow][B]A:[/B][/COLOR]  {antworten[0]}")
        self.getControl(2002).setLabel(f"[COLOR yellow][B]B:[/B][/COLOR]  {antworten[1]}")
        self.getControl(2003).setLabel(f"[COLOR yellow][B]C:[/B][/COLOR]  {antworten[2]}")
        self.getControl(2004).setLabel(f"[COLOR yellow][B]D:[/B][/COLOR]  {antworten[3]}")        
        self.getControl(3001).setVisible(True)
        if anzahl_spieler >= 2:
            self.getControl(3002).setVisible(True)
        if anzahl_spieler >= 3:
            self.getControl(3003).setVisible(True)
        self.getControl(3004).setVisible(True)
        xbmc.sleep(300)        
        self.setFocusId(3001)


    def onControl(self, control):
        control_id = control.getId()
        if control_id in [3001, 3002, 3003, 3004]:
            self.auswahl = control_id - 3001
            self.beendet = True


    def onAction(self, action):
        action_id = action.getId()
        if action_id in [7, 100]:
            try:
                focused_id = self.getFocusId()
                if focused_id in [3001, 3002, 3003, 3004]:
                    self.auswahl = focused_id - 3001
                    self.beendet = True
            except Exception:
                pass
        elif action_id in [92, 10]:
            self.auswahl = -1
            self.beendet = True


    def clear_screen_for_dialog(self):
        try:
            self.getControl(1002).setText("")
            self.getControl(2001).setLabel("")
            self.getControl(2002).setLabel("")
            self.getControl(2003).setLabel("")
            self.getControl(2004).setLabel("")
            self.getControl(3001).setVisible(False)
            self.getControl(3002).setVisible(False)
            self.getControl(3003).setVisible(False)
            self.getControl(3004).setVisible(False)
        except Exception:
            pass


def lade_und_aktualisiere_highscore(neue_ergebnisse, profile_path, schwierigkeits_name):
    highscore_datei = os.path.join(profile_path, "highscore.json")
    if not os.path.exists(profile_path):
        os.makedirs(profile_path)

    alle_scores = {}
    if os.path.exists(highscore_datei):
        try:
            with open(highscore_datei, 'r', encoding='utf-8') as f:
                data = json.load(f)

                if isinstance(data, dict):
                    alle_scores = data
                else:
                    alle_scores = {}
        except Exception:
            alle_scores = {}    
    if not isinstance(alle_scores, dict):
        alle_scores = {}        
    if schwierigkeits_name not in alle_scores:
        alle_scores[schwierigkeits_name] = []    
    for spieler, punkte in neue_ergebnisse.items():
        alle_scores[schwierigkeits_name].append({"name": spieler, "punkte": punkte})    
    alle_scores[schwierigkeits_name] = sorted(
        alle_scores[schwierigkeits_name], 
        key=lambda x: x["punkte"], 
        reverse=True
    )[:10]    
    with open(highscore_datei, 'w', encoding='utf-8') as f:
        json.dump(alle_scores, f, indent=4, ensure_ascii=False)        
    return alle_scores[schwierigkeits_name]


def spiel_starten():
    dialog = xbmcgui.Dialog()
    addon_path = 'special://home/addons/script.ydkj.quiz/'
    profile_path = xbmcvfs.translatePath('special://profile/addon_data/script.ydkj.quiz/')
    
    musik_player = None
    if enable_music:
        musik_player = xbmc.Player()
        musik_pfad = os.path.join(xbmcvfs.translatePath(addon_path), 'resources', 'media', 'welcome.mp3')
        if os.path.exists(musik_pfad):
            musik_player.play(musik_pfad)

    spieler_optionen = ["1 Spieler", "2 Spieler", "3 Spieler"]
    anzahl_spieler_index = dialog.select("Wie viele Spieler treten an?", spieler_optionen)
    if anzahl_spieler_index == -1: return
    anzahl_spieler = anzahl_spieler_index + 1
    
    namen_defaults = [addon.getSetting('p1_name'), addon.getSetting('p2_name'), addon.getSetting('p3_name')]
    
    konten = {}
    naegel = {}
    for i in range(anzahl_spieler):
        default_name = namen_defaults[i] if i < len(namen_defaults) else f"Spieler {i+1}"
        eingabe_name = dialog.input(f"Name für Spieler {i+1}:", defaultt=default_name)
        
        name = eingabe_name.strip() if eingabe_name.strip() else default_name
        konten[name] = 0
        naegel[name] = 1

    modus_optionen = ["7 Fragen (Kurze Runde)", "21 Fragen (Marathon)"]
    modus_index = dialog.select("Wähle deine Spieldauer:", modus_optionen)
    if modus_index == -1: return    
    runden_anzahl = 7 if modus_index == 0 else 21
    schwierigkeit_optionen = [
        "Warm-up Runde (Leicht)", 
        "Gehirn leicht aktiviert (Mittel)", 
        "Kopf-Knoten-Level (Schwer)", 
        "Quiz-Achterbahn (Alles gemischt!)"
    ]
    schwierigkeit_index = dialog.select("Wähle deinen Schwierigkeitsgrad:", schwierigkeit_optionen)
    if schwierigkeit_index == -1: return    
    basis_fragen_ordner = os.path.join(xbmcvfs.translatePath(addon_path), 'resources', 'questions')        
    fragen_pool = []
    ordner_mapping = {
        0: ['leicht'],
        1: ['mittel'],
        2: ['schwer'],
        3: ['leicht', 'mittel', 'schwer']
    }    
    ziel_ordner_liste = ordner_mapping[schwierigkeit_index]    
    for sub_ordner in ziel_ordner_liste:
        aktueller_pfad = os.path.join(basis_fragen_ordner, sub_ordner)
        if os.path.exists(aktueller_pfad):
            dateien = [f for f in os.listdir(aktueller_pfad) if f.endswith('.json')]
            for datei in dateien:
                fragen_pool.append((aktueller_pfad, datei))                
    if not fragen_pool:
        dialog.ok("Fehler", "Keine Fragen für diesen Schwierigkeitsgrad gefunden!")
        return
    if len(fragen_pool) < runden_anzahl:
        runden_anzahl = len(fragen_pool)
        dialog.ok("Hinweis", f"Nicht genug Fragen vorhanden. Runde verkürzt auf {runden_anzahl} Fragen.")
    if musik_player and musik_player.isPlaying():
        musik_player.stop()    
    random.shuffle(fragen_pool)
    fenster = Jackui("Jackui.xml", addon_path)
    fenster.show()
    xbmc.sleep(200)         
    for runde in range(1, runden_anzahl + 1):
        punktestand_text = "   |   ".join([f"{sp}: {punkte} T {f'( † )' if naegel[sp]>0 else ''}" for sp, punkte in konten.items()])                
        gewaehlter_ordner, zufaellige_datei = fragen_pool.pop()        
        with open(os.path.join(gewaehlter_ordner, zufaellige_datei), 'r', encoding='utf-8') as f:
            daten = json.load(f)            
        antworten = daten["falsche_antworten"] + [daten["korrekte_antwort"]]
        random.shuffle(antworten)        
        fenster.zeige_neue_frage(runde, runden_anzahl, daten['kategorie'], daten['frage'], antworten, punktestand_text, anzahl_spieler)        
        while not fenster.beendet:
            xbmc.sleep(50)            
        aktiver_spieler_index = fenster.auswahl        
        if aktiver_spieler_index == -1 or aktiver_spieler_index == len(konten):
            continue                        
        wer_antwortet_liste = list(konten.keys())
        aktiver_spieler = wer_antwortet_liste[aktiver_spieler_index] if aktiver_spieler_index < len(konten) else None
        if not aktiver_spieler:
            continue                    
        aktion = 0 
        if anzahl_spieler > 1 and naegel[aktiver_spieler] > 0:
            aktions_auswahl = dialog.select(f"{aktiver_spieler}, was tust du?", ["Ich antworte selbst", " † JEMANDEN NAGELN!"])
            if aktions_auswahl == -1:
                konten[aktiver_spieler] -= 100
                spruch = random.choice(mod.SPRUECHE_SCHUMMELN)
                stop_audio()
                vorlesen(spruch)
                xbmc.sleep(500)
                dialog.ok("Feigling!", f"[COLOR red]{spruch}[/COLOR]\n\n-100 Taler für {aktiver_spieler}!")
                continue                
            if aktions_auswahl == 1:
                aktion = 1 
                naegel[aktiver_spieler] -= 1        
        if aktion == 1:
            opfer_liste = [sp for sp in konten.keys() if sp != aktiver_spieler]
            opfer_index = dialog.select(f"{aktiver_spieler}, wen willst du nageln?", opfer_liste)
            if opfer_index == -1: 
                naegel[aktiver_spieler] += 1
                opfer = aktiver_spieler
                dialog.ok("Feigling", "Nageln abgebrochen! Zur Strafe musst du selbst ran.")
            else:
                opfer = opfer_liste[opfer_index]
                nagel_text = f"{aktiver_spieler} nagelt {opfer}! {opfer}, du musst jetzt antworten!"
                stop_audio()
                vorlesen(nagel_text)
                xbmc.sleep(500)                                    
                dialog.ok("† NAGEL-ALARM! †", f"[COLOR red]{aktiver_spieler}[/COLOR] nagelt [COLOR yellow]{opfer}[/COLOR]!\n\n{opfer}, du MUSST jetzt antworten!")                        
            auswahl = dialog.select(f"{opfer}: Logge DEINE Antwort ein!", [f"A: {antworten[0]}", f"B: {antworten[1]}", f"C: {antworten[2]}", f"D: {antworten[3]}"])
            if auswahl == -1:
                konten[opfer] -= 100
                konten[aktiver_spieler] += 100
                fehler_text = f"Feige geflüchtet! {opfer} hat die Antwort verweigert!"
                stop_audio()
                vorlesen(fehler_text)
                xbmc.sleep(500)
                dialog.ok("Der Moderator sagt:", f"[COLOR red]Feige geflüchtet![/COLOR]\n\n{opfer} hat die Antwort verweigert!\n\n-100 Taler für {opfer}\n+100 Taler für {aktiver_spieler}")
            else:
                if antworten[auswahl] == daten["korrekte_antwort"]:
                    konten[opfer] += 100
                    konten[aktiver_spieler] -= 100
                    spruch = random.choice(mod.SPRUECHE_NAGELN_FEHLGESCHLAGEN)
                    stop_audio()
                    vorlesen(spruch)
                    xbmc.sleep(500)
                    dialog.ok("Der Moderator sagt:", f"[COLOR green]Das Opfer hat's gewusst![/COLOR]\n\n{spruch}\n\n+100 Taler für {opfer}\n-100 Taler für {aktiver_spieler}")
                else:
                    konten[opfer] -= 100
                    konten[aktiver_spieler] += 100
                    spruch = random.choice(mod.SPRUECHE_NAGELN_ERFOLGREICH)
                    antwort_hinweis = f" Die richtige Antwort gewesen wäre: {daten['korrekte_antwort']}."
                    stop_audio()
                    vorlesen(spruch + antwort_hinweis)
                    xbmc.sleep(500)
                    dialog.ok("Der Moderator sagt:", f"[COLOR red]Voll erwischt![/COLOR]\n\n{spruch}\n\nHier wäre richtig gewesen: [COLOR green]{daten['korrekte_antwort']}[/COLOR]\n\n-100 Taler für {opfer}\n+100 Taler für {aktiver_spieler}")
        else:
            auswahl = dialog.select(f"{aktiver_spieler}: Logge deine Antwort ein!", [f"A: {antworten[0]}", f"B: {antworten[1]}", f"C: {antworten[2]}", f"D: {antworten[3]}"])
            if auswahl == -1:
                konten[aktiver_spieler] -= 100
                spruch = random.choice(mod.SPRUECHE_SCHUMMELN)
                stop_audio()
                vorlesen(spruch)
                xbmc.sleep(500)
                dialog.ok("Moderator", f"[COLOR red]FEIGE![/COLOR]\n\n{spruch}\n\n-100 Taler für {aktiver_spieler}!")
            else:
                if antworten[auswahl] == daten["korrekte_antwort"]:
                    konten[aktiver_spieler] += 100
                    spruch = random.choice(mod.SPRUECHE_RICHTIG)
                    stop_audio()
                    vorlesen(spruch)
                    xbmc.sleep(500)
                    dialog.ok("Moderator", f"[COLOR green]KORREKT![/COLOR]\n\n{spruch}\n\n+100 Taler!")
                else:
                    konten[aktiver_spieler] -= 100
                    spruch = random.choice(mod.SPRUECHE_FALSCH)
                    antwort_hinweis = f" Die richtige Antwort gewesen wäre: {daten['korrekte_antwort']}."
                    stop_audio()
                    vorlesen(spruch + antwort_hinweis)
                    xbmc.sleep(500)
                    dialog.ok("Moderator", f"[COLOR red]FALSCH![/COLOR]\n\n{spruch}\n\nRichtige Antwort: [COLOR green]{daten['korrekte_antwort']}[/COLOR]\n\n-100 Taler!")    
    letzter_punktestand = "   |   ".join([f"{sp}: {punkte} T" for sp, punkte in konten.items()])
    fenster.getControl(1001).setLabel("SPIEL VORBEI - ENDSTAND")
    fenster.getControl(1003).setLabel(letzter_punktestand)
    fenster.clear_screen_for_dialog()
    end_text = "[B]Das Spiel ist vorbei! Hier ist der Endstand:[/B]\n\n"
    for sp, punkte in sorted(konten.items(), key=lambda x: x[1], reverse=True): 
        end_text += f"• [COLOR yellow]{sp}[/COLOR]: {punkte} Taler\n"
    dialog.ok("Spiel vorbei!", end_text)
    schwierigkeits_name = schwierigkeit_optionen[schwierigkeit_index]    
    top_scores = lade_und_aktualisiere_highscore(konten, profile_path, schwierigkeits_name)        
    highscore_text = f"[B]$ EWIGE HIGHSCORE: {schwierigkeits_name} $[/B]\n\n"
    for platz, eintrag in enumerate(top_scores, 1):
        highscore_text += f"{platz}. {eintrag['name']} - {eintrag['punkte']} Taler\n"
    dialog.ok("Globale Highscores", highscore_text)
    fenster.close()
    del fenster


def stop_audio():
    try:
        player = xbmc.Player()
        if player.isPlaying():
            player.stop()
    except Exception:
        pass


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'reset_db':
        profile_path = xbmcvfs.translatePath('special://profile/addon_data/script.ydkj.quiz/')
        highscore_file = os.path.join(profile_path, "highscore.json")
        if os.path.exists(highscore_file):
            os.remove(highscore_file)
            xbmcgui.Dialog().notification("Kodi Quiz", "Highscore wurde gelöscht", xbmcgui.NOTIFICATION_INFO)
    else:
        spiel_starten()
