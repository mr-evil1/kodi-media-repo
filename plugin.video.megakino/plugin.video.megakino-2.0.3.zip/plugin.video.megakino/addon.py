import xbmc, xbmcplugin, xbmcaddon, xbmcgui
import sys, os, re, requests, urllib
from urllib.parse import quote_plus, urlparse

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
addon_path = addon.getAddonInfo('path')
use_custom = addon.getSettingBool('use_custom_domain')
def get_live_domain():
    try:
        data = requests.get(url, timeout=5).json()
        return data.get("url").replace('https://','').replace('http://','').strip('/')
    except Exception:
        return None

DOMAIN = addon.getSetting('custom_domain') if use_custom else get_live_domain()
if not DOMAIN:
    xbmcgui.Dialog().ok(
        "Megakino",
        "Fehler\n\nBitte in den Einstellungen eine gültige Domain eintragen"
    )
    sys.exit()

addon.setSetting('raw_domain', DOMAIN)

try:DOMAIN = DOMAIN.replace('https://', '').replace('http://', '').strip('/')
except:pass
URL_MAIN = 'https://' + DOMAIN + '/'

def get_html(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': URL_MAIN
    }
    session = requests.Session()
    try:
        response = session.get(url, headers=headers, timeout=15)
        html = response.text
        if 'yg=token' in html:
            token_url = URL_MAIN + 'index.php?yg=token'
            session.get(token_url, headers={'X-Requested-With': 'XMLHttpRequest', 'Referer': url}, timeout=10)
            html = session.get(url, headers=headers, timeout=15).text
        return html
    except:
        return ""

def add_dir(name, mode, url="", icon="", desc=""):
    u = sys.argv[0] + "?mode=" + mode + "&url=" + quote_plus(url) + "&name=" + quote_plus(name) + "&icon=" + quote_plus(icon)
    item = xbmcgui.ListItem(name)
    item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': icon})
    if desc:
        item.setInfo('video', {'plot': desc})
    if mode == "play":
        item.setProperty('IsPlayable', 'true')
        isFolder = False
    else:
        isFolder = True
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=item, isFolder=isFolder)

def main_menu():
    add_dir("Neues", "show_entries", URL_MAIN)
    add_dir("Kinofilme", "show_entries", URL_MAIN + "kinofilme/")
    add_dir("Filme", "show_entries", URL_MAIN + "films/")
    add_dir("Serien", "show_entries", URL_MAIN + "serials/")
    add_dir("Sammlungen", "show_collection", URL_MAIN)
    xbmcplugin.endOfDirectory(addon_handle)

def show_collection(url):
    html = get_html(url)
    pattern = r'href="([^"]+)"[^>]*>.*?<div class="custom-collection-title">([^<]+)</div>'
    matches = re.findall(pattern, html, re.DOTALL)
    for sUrl, sName in matches:
        if sUrl.startswith('/'): sUrl = URL_MAIN + sUrl[1:]
        add_dir(sName, "show_entries", sUrl)
    xbmcplugin.endOfDirectory(addon_handle)

def show_entries(url):
    html = get_html(url)
    pattern = r'<a class="poster grid-item[^>]*href="([^"]+)"[^>]*>.*?<img[^>]*data-src="([^"]+)"[^>]*alt="([^"]+)"'
    matches = re.findall(pattern, html, re.DOTALL)
    for sUrl, sThumb, sName in matches:
        if sUrl.startswith('/'): sUrl = URL_MAIN + sUrl[1:]
        if sThumb.startswith('//'): sThumb = 'https:' + sThumb
        elif sThumb.startswith('/'): sThumb = URL_MAIN + sThumb[1:]
        is_tv = 'staffel' in sName.lower() or '/serials/' in sUrl
        mode = "show_episodes" if is_tv else "show_hosters"
        add_dir(sName, mode, sUrl, sThumb)
    next_p = re.search(r'class="pagination.*?href="([^"]+)">\D', html)
    if next_p:
        n_url = next_p.group(1)
        if n_url.startswith('/'): n_url = URL_MAIN + n_url[1:]
        add_dir("Nächste Seite >>", "show_entries", n_url)
    xbmcplugin.endOfDirectory(addon_handle)

def show_episodes(url):
    icon = dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('icon', '')
    html = get_html(url)
    matches = re.findall(r'<option\s+value="ep([^"]+)">([^<]+)</option>', html)
    for ep_id, ep_name in matches:
        add_dir(ep_name, "show_hosters", url + "|ep" + ep_id, icon)
    xbmcplugin.endOfDirectory(addon_handle)

def show_hosters(url):
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    icon = params.get('icon', '')
    target_url = url.split('|')[0]
    html = get_html(target_url)
    if '|ep' in url:
        ep_id = url.split('|')[1]
        container = re.search(r'id="%s"[^>]*>(.*?)</select>' % ep_id, html, re.DOTALL)
        if container:
            links = re.findall(r'value="([^"]+)"', container.group(1))
        else:
            links = []
    else:
        links = re.findall(r'<iframe[^>]*src="([^"]+)"', html)
    for h_url in links:
        if 'youtube' in h_url or not h_url.strip(): continue
        if h_url.startswith('//'): h_url = 'https:' + h_url
        h_name = urlparse(h_url).netloc.split('.')[-2].capitalize()
        add_dir(h_name, "play", h_url, icon)
    xbmcplugin.endOfDirectory(addon_handle)

def play(url):
    try:
        import resolveurl
        stream_url = resolveurl.resolve(url)
        if stream_url:
            listitem = xbmcgui.ListItem(path=stream_url)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem)
    except:
        pass

params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
mode = params.get('mode')
url = params.get('url')

if mode is None: main_menu()
elif mode == "show_collection": show_collection(url)
elif mode == "show_entries": show_entries(url)
elif mode == "show_episodes": show_episodes(url)
elif mode == "show_hosters": show_hosters(url)
elif mode == "play": play(url)
