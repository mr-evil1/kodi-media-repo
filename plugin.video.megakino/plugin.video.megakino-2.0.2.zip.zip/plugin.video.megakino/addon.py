#!/usr/bin/env python
# -*- coding: utf-8 -*-
#python3 by mr-evil1
import xbmc, xbmcplugin, xbmcaddon, xbmcgui, sys, os
from urllib.parse import quote_plus
import requests

addon = xbmcaddon.Addon()
use_custom = addon.getSettingBool('use_custom_domain')


def get_url():
    url = "https://raw.githubusercontent.com/mr-evil1/megakino/main/megakino-url.json"
    try:
        current_domain = requests.get(url).json().get("url")
        return current_domain
    except Exception:
        return None



setting_id = addon.getSetting('custom_domain') if use_custom else get_url()
if setting_id:
    addon.setSetting('raw_domain',setting_id)
else:
    xbmcgui.Dialog().ok("Megakino",'Fehler /n/n In den Einstellungen Custom Domain eingeben')
    sys.exit()
raw_domain = addon.getSetting('raw_domain') or 'megakino.live'

DOMAIN = raw_domain.replace('https://', '').replace('http://', '').strip('/')

URL_MAIN = 'https://' + DOMAIN + '/'
URL_KINO = URL_MAIN + 'kinofilme/'
URL_MOVIES = URL_MAIN + 'films/'
URL_SERIES = URL_MAIN + 'serials/'
URL_ANIMATION = URL_MAIN + 'multfilm/'
URL_DOKU = URL_MAIN + 'documentary/'
URL_SEARCH = URL_MAIN + '?do=search&subaction=search&story=%s'

sys.path.append(os.path.join(addon.getAddonInfo('path'), 'resources', 'lib'))
import tools

def get_page_content(target_url):
    try:
        s = requests.Session()
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
            'Referer': URL_MAIN
        }
        s.get(URL_MAIN, headers=headers, timeout=15)
        token_url = URL_MAIN + 'index.php?yg=token'
        s.get(token_url, headers=headers, timeout=15)
        response = s.get(target_url, headers=headers, timeout=30)
        response.raise_for_status()
        if response.text:
            return response.text
        else:
            return ""
    except requests.exceptions.RequestException as e:
        xbmc.log(f"[megakino] Webseiten-Anfrage fehlgeschlagen: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Megakino Fehler", f"Seite konnte nicht geladen werden", xbmcgui.NOTIFICATION_ERROR, 5000)
        return ""

def build_main_menu():
    tools.__set_content_type__('files')
    tools.__add_item__(url=URL_MAIN, title='Neues', imode='showEntries', is_folder=True)
    tools.__add_item__(url=URL_KINO, title='Aktuelle Filme im Kino', imode='showEntries', is_folder=True)
    tools.__add_item__(url=URL_MOVIES, title='Filme', imode='showEntries', is_folder=True)
    tools.__add_item__(url=URL_ANIMATION, title='Animationsfilme', imode='showEntries', is_folder=True)
    tools.__add_item__(url=URL_SERIES, title='Serien', imode='showEntries', is_folder=True)
    tools.__add_item__(url=URL_DOKU, title='Dokumentationen', imode='showEntries', is_folder=True)
    tools.__add_item__(url=URL_MAIN, title='Sammlungen', imode='showCollection', is_folder=True)
    tools.__add_item__(url=URL_MAIN, title='Genre', imode='showGenre', is_folder=True)
    tools.__add_item__(title='Suche', imode='showSearch', is_folder=True)
    tools.__end_of_directory__()

def showGenre(params):
    sHtmlContent = get_page_content(params.get('url'))
    match = tools.__regex_search__('<div\s+class="side-block__title">Genres</div>(.*?)</ul>\s*</div>', sHtmlContent)
    if match:
        for sUrl, sName in tools.__regex_findall__('href="([^"]+)">([^<]+)</a>', match.group(1)):
            tools.__add_item__(url=sUrl, title=sName, imode='showEntries', is_folder=True)
    tools.__end_of_directory__()

def showCollection(params):
    sHtmlContent = get_page_content(params.get('url'))
    match = tools.__regex_search__('<div\s+class="side-block__title">Sammlung</div>(.*?)<div class="side-block\sjs', sHtmlContent)
    if match:
        for sUrl, sName in tools.__regex_findall__('href="([^"]+)"\s.*?title">([^<]+)', match.group(1)):
            tools.__add_item__(url=sUrl, title=sName, imode='showEntries', is_folder=True)
    tools.__end_of_directory__()

def showEntries(params):
    entryUrl = params.get('url')
    sHtmlContent = get_page_content(entryUrl)
    if not sHtmlContent:
        tools.__end_of_directory__()
        return

    content_container_match = tools.__regex_search__(r'<div id="dle-content">(.*?)<div class="pagination"', sHtmlContent)
    if not content_container_match:
        content_container_match = tools.__regex_search__(r'<div id="dle-content">(.*?)<\/main>', sHtmlContent)
        if not content_container_match:
            xbmcgui.Dialog().notification("Megakino", "Konnte Inhaltsbereich nicht finden.", xbmcgui.NOTIFICATION_WARNING, 3000)
            tools.__end_of_directory__()
            return
    html_inside_container = content_container_match.group(1)

    pattern = r'<a class="poster grid-item[^"]*" href="([^"]+)">.*?<img data-src="([^"]+)"[^>]*?alt="([^"]+)".*?<\/a>'
    matches = tools.__regex_findall__(pattern, sHtmlContent)

    if not matches:
        xbmcgui.Dialog().notification("Megakino", "Keine Einträge auf dieser Seite gefunden.", xbmcgui.NOTIFICATION_INFO, 3000)
        tools.__end_of_directory__()
        return

    isTvshowList = 'serials' in entryUrl
    for sUrl, sThumbnail, sName in matches:
        sName = sName.strip()
        full_entry_match = tools.__regex_search__(rf'<a href="{sUrl}".*?>(.*?)<\/a>', sHtmlContent)
        sDummy = full_entry_match.group(1) if full_entry_match else ''
        quality_match = tools.__regex_search__(r'poster__label">([^<]+)', sDummy)
        sQuality = quality_match.group(1).strip() if quality_match else ''
        year_match = tools.__regex_search__(r'([\d]{4})<\/li>', sDummy)
        sYear = year_match.group(1) if year_match else ''
        info_labels = {'year': sYear, 'plot': sName}
        isTvshow = 'staffel' in sName.lower()
        if isTvshow: isTvshowList = True
        display_title = f"{sName} [{sQuality}]" if sQuality and sQuality != '+' else sName
        tools.__add_item__(
            url=sUrl, title=display_title, image=URL_MAIN.strip('/') + sThumbnail, fanart=tools.__addon_fanart__,
            info_labels_update=info_labels, params_update={'entryUrl': sUrl, 'sName': sName, 'sThumbnail': sThumbnail},
            imode='showEpisodes' if isTvshow else 'showHosters', is_folder=True
        )

    next_page_match = tools.__regex_search__(r'<div class="pagination__btn-loader[^"]*"><a href="([^"]+)">', sHtmlContent)
    if not next_page_match:
        next_page_match = tools.__regex_search__(r'class="pagination.*?href="([^"]+)">\D', sHtmlContent)

    if next_page_match:
        tools.__add_item__(url=next_page_match.group(1), title='Nächste Seite >>', imode='showEntries', is_folder=True)

    content_type = 'tvshows' if isTvshowList else 'movies'
    tools.__set_content_type__(content_type)
    tools.__end_of_directory__()

def showEpisodes(params):
    sUrl, sThumbnail, sName = params.get('entryUrl'), params.get('sThumbnail'), params.get('sName')
    sHtmlContent = get_page_content(sUrl)
    if not sHtmlContent:
        tools.__end_of_directory__()
        return
    matches = tools.__regex_findall__('<option\s+value="ep([^"]+)">([^<]+)</option>', sHtmlContent)
    sSeason = tools.__regex_search__('staffel\s+(\d+)', sName.lower()).group(1) if tools.__regex_search__('staffel\s+(\d+)', sName.lower()) else '1'
    for episode, episodeName in matches:
        info_labels = {'season': sSeason, 'episode': episode, 'tvshowtitle': sName}
        tools.__add_item__(
            url=sUrl, title=episodeName.strip(), image=sThumbnail, fanart=tools.__addon_fanart__, info_labels_update=info_labels,
            params_update={'episodeId': 'ep' + episode, 'entryUrl': sUrl}, imode='showEpisodeHosters', is_folder=True
        )
    tools.__set_content_type__('episodes')
    tools.__end_of_directory__()

def showHosters(params):
    sUrl, sName, sThumbnail = params.get('entryUrl'), params.get('sName'), params.get('sThumbnail')
    sHtmlContent = get_page_content(sUrl)
    if not sHtmlContent:
        tools.__end_of_directory__()
        return
    matches = tools.__regex_findall__('<iframe.*?src="([^"]+)"', sHtmlContent)
    for hosterUrl in matches:
        if 'youtube' in hosterUrl: continue
        hosterName = tools.__get_domain__(hosterUrl).split('.')[0].capitalize()
        tools.__add_item__(
            url=hosterUrl, title=f"{sName} | {hosterName}", image=sThumbnail, fanart=tools.__addon_fanart__,
            imode='playHoster', is_folder=False, is_playable=True
        )
    tools.__end_of_directory__()

def showEpisodeHosters(params):
    sUrl, episodeId, sThumbnail = params.get('entryUrl'), params.get('episodeId'), params.get('sThumbnail')
    sHtmlContent = get_page_content(sUrl)
    if not sHtmlContent:
        tools.__end_of_directory__()
        return
    container_match = tools.__regex_search__(f'<select[^>]*id="{episodeId}">\s*(.*?)\s*</select>', sHtmlContent)
    if container_match:
        matches = tools.__regex_findall__('<option\s+value="([^"]+)">', container_match.group(1))
        for hosterUrl in matches:
            if 'youtube' in hosterUrl: continue
            hosterName = tools.__get_domain__(hosterUrl).split('.')[0].capitalize()
            tools.__add_item__(
                url=hosterUrl, title=hosterName, image=sThumbnail, fanart=tools.__addon_fanart__,
                imode='playHoster', is_folder=False, is_playable=True
            )
    tools.__end_of_directory__()

def showSearch(params):
    sSearchText = tools.__dialog_imput_alphanum__(heading='Suchbegriff eingeben')
    if sSearchText:
        params['url'] = URL_SEARCH % quote_plus(sSearchText)
        showEntries(params)

def playHoster(params):
    hoster_url = params.get('url')
    play_url = tools.__get_resolved_url__(hoster_url)
    if play_url:
        tools.__set_resolved_url__(url=play_url)

__params__ = tools.__get_params__()
imode = __params__.get('imode') if __params__ else None

if imode is None: build_main_menu()
elif imode == 'showEntries': showEntries(__params__)
elif imode == 'showGenre': showGenre(__params__)
elif imode == 'showCollection': showCollection(__params__)
elif imode == 'showEpisodes': showEpisodes(__params__)
elif imode == 'showHosters': showHosters(__params__)
elif imode == 'showEpisodeHosters': showEpisodeHosters(__params__)
elif imode == 'showSearch': showSearch(__params__)
elif imode == 'playHoster': playHoster(__params__)
