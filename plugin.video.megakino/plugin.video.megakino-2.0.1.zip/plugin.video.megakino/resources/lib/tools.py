#!/usr/bin/env python
# -*- coding: utf-8 -*-
#python3 by mr-evil1
import xbmc, xbmcplugin, xbmcaddon, xbmcgui, xbmcvfs, os, sys, json, re, resolveurl
import urllib.parse

__plugin_handle__ = int(sys.argv[1])
__addon__ = xbmcaddon.Addon()
__addon_fanart__ = __addon__.getAddonInfo('fanart')
__addon_icon__ = __addon__.getAddonInfo('icon')

def __add_item__(url='', title='', image=__addon_icon__, fanart=__addon_fanart__, info_labels_update={}, params_update={}, imode='', is_folder=True, is_playable=False):
    iparams = {'url': url, 'title': title, 'image': image, 'fanart': fanart, 'imode': imode}
    iparams.update(params_update)
    
    info_labels = {'Title': title}
    info_labels.update(info_labels_update)

    listitem = xbmcgui.ListItem(label=title)
    
    listitem.setArt({'thumb': image, 'poster': image, 'banner': image, 'fanart': fanart, 'icon': image})
    listitem.setProperties({'icon': image})

    if is_playable:
        listitem.setProperty('IsPlayable', 'true')
    
    final_url = f"{sys.argv[0]}?{urllib.parse.quote_plus(json.dumps(iparams))}"
    xbmcplugin.addDirectoryItem(handle=__plugin_handle__, url=final_url, listitem=listitem, isFolder=is_folder)

def __get_params__():
    try:
        return json.loads(urllib.parse.unquote_plus(sys.argv[2][1:]))
    except:
        return None

def __end_of_directory__():
    xbmcplugin.endOfDirectory(handle=__plugin_handle__, succeeded=True, cacheToDisc=True)

def __dialog_imput_alphanum__(heading=''):
    return xbmcgui.Dialog().input(heading=heading, type=xbmcgui.INPUT_ALPHANUM)

def __get_resolved_url__(url):
    try:
        if resolveurl.HostedMediaFile(url=url).valid_url():
            return resolveurl.HostedMediaFile(url=url).resolve()
    except Exception as e:
        xbmcgui.Dialog().notification('URL Resolver', str(e), xbmcgui.NOTIFICATION_ERROR, 3000, True)
    return None

def __set_resolved_url__(url):
    listitem = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(handle=__plugin_handle__, succeeded=True, listitem=listitem)

def __get_domain__(url):
    return urllib.parse.urlparse(url).netloc

def __regex_search__(regex, content):
    return re.search(regex, content, re.DOTALL)

def __regex_findall__(regex, content):
    return re.findall(regex, content, re.DOTALL)
    
def __set_content_type__(content_type):
    xbmcplugin.setContent(__plugin_handle__, content_type)

