try:
    import xbmc
    import xbmcgui
    _HAS_KODI = True
except ImportError:
    _HAS_KODI = False
    xbmc = None
    xbmcgui = None
from . import tmdb, sources, resolver, filters, creators, langpref, debug, isa
DEFAULT_MAX_QUALITY = 2160
DEFAULT_INCLUDE_FAN_MADE = False
DEFAULT_QUALITY_PROMPT = True
DEFAULT_AUTOPLAY = False
DEFAULT_BEST_STREAM = True
_BEST_MAX_CANDIDATES = 6
_BEST_GOOD_ENOUGH = 1080
DEFAULT_PREFERRED_HOST = "auto"
_HOST_ALIASES = {
    "auto": "auto", "": "auto", "any": "auto",
    "youtube": "youtube", "yt": "youtube", "you tube": "youtube",
    "flicks": "flicks", "flicks.co.uk": "flicks", "flick": "flicks",
    "vimeo": "vimeo", "tiktok": "tiktok", "dailymotion": "dailymotion",
    "imdb": "imdb",
}

def _normalise_host(h):
    if not h:
        return "auto"
    return _HOST_ALIASES.get(str(h).strip().lower(), str(h).strip().lower())

def _notify(msg, heading="MultiTrailer", icon_type=None, time=4000):
    if _HAS_KODI:
        try:
            xbmcgui.Dialog().notification(heading, msg,
                                          icon_type or xbmcgui.NOTIFICATION_INFO, time)
        except Exception:
            pass

def _busy(on):
    if _HAS_KODI:
        try:
            xbmc.executebuiltin("ActivateWindow(busydialognocancel)" if on
                                else "Dialog.Close(busydialognocancel)")
        except Exception:
            pass

class _SearchProgress(object):
    def __init__(self, heading="MultiTrailer"):
        self.heading = heading
        self.bg = None
        if not _HAS_KODI:
            return
        try:
            self.bg = xbmcgui.DialogProgressBG()
            self.bg.create(heading, "Searching for trailer links...")
        except Exception:
            self.bg = None

    def update(self, host, i, n):
        if not self.bg:
            return
        try:
            pct = int(max(1, min(99, (i * 100) // max(n, 1))))
            self.bg.update(pct, self.heading,
                           "Searching {} ({}/{})".format(host or "host", i, n))
        except Exception:
            pass

    def close(self):
        if not self.bg:
            return
        try:
            self.bg.close()
        except Exception:
            pass
        self.bg = None

def _fan_tag(item):
    return " [COLOR red](fan-made)[/COLOR]" if item.get("fan_made") else ""

def _pick_trailer_and_quality(items, max_quality, preferred_host="auto", prefer_dash=True):
    if not _HAS_KODI:
        for it in items:
            try:
                q = resolver.resolve_ex(it, max_height=max_quality, prefer_dash=prefer_dash)
            except Exception:
                q = None
            if q:
                return q, it
        return None, None
    per_provider_cap = {"youtube": 3, "flicks": 4, "vimeo": 2,
                        "dailymotion": 2, "tiktok": 2, "imdb": 2}
    bucketed = []
    counts = {}
    for it in items:
        prov = it.get("provider") or "video"
        cap = per_provider_cap.get(prov, 2)
        if counts.get(prov, 0) >= cap:
            continue
        counts[prov] = counts.get(prov, 0) + 1
        bucketed.append(it)
    rows = []
    progress = _SearchProgress("MultiTrailer - Searching")
    total = len(bucketed)
    try:
        for idx, it in enumerate(bucketed, 1):
            host_name = (it.get("host")
                         or (it.get("provider") or "video").title())
            progress.update(host_name, idx, total)
            try:
                qs = resolver.list_qualities(it, prefer_dash=prefer_dash)
            except Exception as exc:
                try:
                    xbmc.log("[multitrailer] list_qualities({}) crashed: {}".format(
                        it.get("provider"), exc), xbmc.LOGWARNING)
                except Exception:
                    pass
                qs = []
            if not qs:
                continue
            title = it.get("title") or "Trailer"
            for q in qs:
                host = q.get("host") or it.get("provider", "video").title()
                host_key = _normalise_host(host)
                label = "[B]{}[/B] · {} · {}{}".format(
                    host, q.get("label") or "Auto", title, _fan_tag(it))
                rows.append((label, q, it, host_key))
    finally:
        progress.close()
    if not rows:
        return None, None
    pref = _normalise_host(preferred_host)
    if pref not in ("auto", "", None):
        rows.sort(key=lambda r: 0 if r[3] == pref else 1)
    labels = [r[0] for r in rows]
    try:
        idx = xbmcgui.Dialog().select("MultiTrailer - Choose Host & Quality", labels)
    except Exception:
        idx = -1
    if idx < 0:
        return None, None
    _, q, it, _ = rows[idx]
    return q, it

def get_trailers(tmdb_id=None, imdb_id=None, media_type="movie",
                 title=None, year=None, include_fan_made=False,
                 include_teasers=True):
    if not tmdb_id and imdb_id:
        info = tmdb.find_by_imdb(imdb_id)
        if info:
            tmdb_id = info.get("id")
            media_type = info.get("media_type", media_type)
            if not title:
                title = info.get("title") or info.get("name")
            if not year and (info.get("release_date") or info.get("first_air_date")):
                year = (info.get("release_date") or info.get("first_air_date") or "")[:4]
    if not tmdb_id and title:
        results = tmdb.search_movie(title, year) if media_type == "movie" else tmdb.search_tv(title, year)
        if results:
            tmdb_id = results[0].get("id")
            if not imdb_id:
                imdb_id = (results[0].get("external_ids") or {}).get("imdb_id")
    return sources.collect(media_type, tmdb_id, imdb_id=imdb_id,
                           title=title, year=year,
                           include_fan_made=include_fan_made,
                           include_teasers=include_teasers)

def _pick_best(ordered, max_quality, prefer_dash):
    cap = max_quality or DEFAULT_MAX_QUALITY
    good_enough = min(cap, _BEST_GOOD_ENOUGH)
    best = None
    best_item = None
    best_key = None
    tried = 0
    for item in ordered:
        if tried >= _BEST_MAX_CANDIDATES:
            break
        tried += 1
        try:
            q = resolver.resolve_ex(item, max_height=cap, prefer_dash=prefer_dash)
        except Exception:
            continue
        if not q:
            continue
        height = min(int(q.get("height") or 0), cap)
        key = (height, 1 if q.get("is_dash") else 0)
        if best_key is None or key > best_key:
            best, best_item, best_key = q, item, key
        if height >= good_enough:
            break
    return best, best_item

def resolve_stream(tmdb_id=None, imdb_id=None, media_type="movie",
                   title=None, year=None, max_quality=None, ask_quality=None,
                   include_fan_made=None, preferred_host=None,
                   include_teasers=True, prefer_dash=True, autoplay=None, best=None):
    q, item = _resolve_stream_full(tmdb_id=tmdb_id, imdb_id=imdb_id,
                                   media_type=media_type, title=title, year=year,
                                   max_quality=max_quality, ask_quality=ask_quality,
                                   include_fan_made=include_fan_made,
                                   preferred_host=preferred_host,
                                   include_teasers=include_teasers, prefer_dash=prefer_dash,
                                   autoplay=autoplay, best=best)
    if not q:
        return None, None
    enriched = dict(item or {})
    enriched.update({
        "label": q.get("label"),
        "host": q.get("host"),
        "is_dash": q.get("is_dash", False),
        "isa_manifest_type": q.get("isa_manifest_type"),
        "mime_type": q.get("mime_type", ""),
        "ext": q.get("ext", ""),
        "height": q.get("height", 0),
        "http_headers": q.get("http_headers", {}),
    })
    return q.get("url"), enriched

def _resolve_stream_full(tmdb_id=None, imdb_id=None, media_type="movie",
                         title=None, year=None, max_quality=None, ask_quality=None,
                         include_fan_made=None, preferred_host=None,
                   include_teasers=True, prefer_dash=True, autoplay=None, best=None):
    if autoplay is None:
        autoplay = DEFAULT_AUTOPLAY
    if best is None:
        best = DEFAULT_BEST_STREAM
    if autoplay:
        ask_quality = False
    if max_quality is None:
        max_quality = DEFAULT_MAX_QUALITY
    if ask_quality is None:
        ask_quality = DEFAULT_QUALITY_PROMPT
    if include_fan_made is None:
        include_fan_made = DEFAULT_INCLUDE_FAN_MADE
    pref = _normalise_host(preferred_host or DEFAULT_PREFERRED_HOST)
    _busy(True)
    try:
        try:
            items = get_trailers(tmdb_id=tmdb_id, imdb_id=imdb_id,
                                 media_type=media_type, title=title, year=year,
                                 include_fan_made=include_fan_made,
                                 include_teasers=include_teasers)
        except Exception as exc:
            try:
                xbmc.log("[multitrailer] get_trailers crashed: {}".format(exc),
                         xbmc.LOGWARNING)
            except Exception:
                pass
            items = []
    finally:
        _busy(False)
    if not include_fan_made:
        items = [i for i in items if not i.get("fan_made")]
    if not items:
        return None, None
    if ask_quality:
        return _pick_trailer_and_quality(items, max_quality, preferred_host=pref,
                                         prefer_dash=prefer_dash)
    ordered = items
    if pref not in ("auto", "", None):
        pref_items = [i for i in items if _normalise_host(i.get("provider")) == pref]
        rest = [i for i in items if _normalise_host(i.get("provider")) != pref]
        ordered = pref_items + rest
    if best:
        return _pick_best(ordered, max_quality, prefer_dash)
    for item in ordered[:8]:
        try:
            q = resolver.resolve_ex(item, max_height=max_quality, prefer_dash=prefer_dash)
            if q:
                return q, item
        except Exception:
            continue
    return None, None

def play(tmdb_id=None, imdb_id=None, media_type="movie", title=None, year=None,
         max_quality=None, ask_quality=None, include_fan_made=None,
         preferred_host=None, show_notifications=True,
         include_teasers=True, prefer_dash=True, autoplay=None, best=None):
    url, item = resolve_stream(tmdb_id=tmdb_id, imdb_id=imdb_id,
                               media_type=media_type, title=title, year=year,
                               max_quality=max_quality, ask_quality=ask_quality,
                               include_fan_made=include_fan_made,
                               preferred_host=preferred_host,
                               include_teasers=include_teasers, prefer_dash=prefer_dash,
                               autoplay=autoplay, best=best)
    if not url:
        if show_notifications:
            _notify("No trailer found for this title.",
                    icon_type=xbmcgui.NOTIFICATION_WARNING if _HAS_KODI else None)
        return False
    if _HAS_KODI:
        try:
            listitem = xbmcgui.ListItem((item.get("title") if item else "Trailer") or "Trailer",
                                        path=url)
            listitem.setInfo("video", {
                "title": (item.get("title") if item else "Trailer") or "Trailer",
                "plot": "Source: {} | Channel: {}".format(
                    (item or {}).get("source", ""), (item or {}).get("channel", "")),
            })
            listitem.setProperty("IsPlayable", "true")
            manifest = (item or {}).get("isa_manifest_type")
            if manifest:
                isa.ensure()
                if (item or {}).get("http_headers"):
                    from urllib.parse import urlencode
                    headers = urlencode(item["http_headers"])
                    listitem.setProperty("inputstream.adaptive.manifest_headers", headers)
                    listitem.setProperty("inputstream.adaptive.stream_headers", headers)
                listitem.setProperty("inputstream", "inputstream.adaptive")
                version = xbmc.getInfoLabel("System.BuildVersion").split(".")[0]
                if version.isdigit() and int(version) < 21:
                    listitem.setProperty("inputstream.adaptive.manifest_type", manifest)
                listitem.setMimeType((item or {}).get("mime_type") or
                                     ("application/dash+xml" if manifest == "mpd" else
                                      "application/vnd.apple.mpegurl"))
                listitem.setContentLookup(False)
            xbmc.Player().play(url, listitem)
        except Exception:
            return False
    return True

def play_movie(tmdb_id=None, imdb_id=None, title=None, year=None, **kw):
    return play(tmdb_id=tmdb_id, imdb_id=imdb_id, media_type="movie",
                title=title, year=year, **kw)

def play_tv(tmdb_id=None, imdb_id=None, title=None, year=None, **kw):
    return play(tmdb_id=tmdb_id, imdb_id=imdb_id, media_type="tv",
                title=title, year=year, **kw)

def search(query):
    return tmdb.search_multi(query)

def search_videos(query, include_youtube=True, include_vimeo=True,
                  include_tiktok=True, include_imdb=False,
                  include_dailymotion=True):
    if not query or not query.strip():
        return []
    q = query.strip()
    results = []
    if include_youtube:
        try:
            results.extend(sources.from_youtube_search(q, suffix=""))
        except Exception:
            pass
    if include_vimeo:
        try:
            results.extend(sources.from_vimeo_search(q, suffix=""))
        except Exception:
            pass
    if include_tiktok:
        try:
            results.extend(sources.from_tiktok_search(q, suffix=""))
        except Exception:
            pass
    if include_dailymotion:
        try:
            results.extend(sources.from_dailymotion_search(q, suffix=""))
        except Exception:
            pass
    debug.vlog("search_videos '{}' Modus={} Rohtreffer={}".format(q, langpref.mode(), len(results)))
    seen = set()
    cleaned = []
    for it in results:
        key = (it.get("provider"), it.get("id"))
        if not key[0] or not key[1] or key in seen:
            continue
        if not langpref.matches(it):
            debug.vlog("search_videos Sprachfilter verworfen: {} | {}".format(it.get("provider"), it.get("title")))
            continue
        seen.add(key)
        if not it.get("thumb"):
            if it.get("provider") == "youtube":
                it["thumb"] = "https://i.ytimg.com/vi/{}/hqdefault.jpg".format(it["id"])
            elif it.get("provider") == "vimeo":
                it["thumb"] = "https://vumbnail.com/{}.jpg".format(it["id"])
            elif it.get("provider") == "dailymotion":
                it["thumb"] = "https://www.dailymotion.com/thumbnail/video/{}".format(it["id"])
            else:
                it["thumb"] = ""
        cleaned.append(it)
    return cleaned

def get_latest_trailers(limit=25):
    queries = langpref.latest_queries()
    out = []
    seen = set()
    for q in queries:
        try:
            items = sources.from_youtube_search(q, suffix="", require_match=False)
        except Exception:
            items = []
        for it in items:
            key = it.get("id")
            if not key or key in seen:
                continue
            if filters.is_fan_made(it.get("title", ""), it.get("channel", "")):
                continue
            if not langpref.matches(it):
                continue
            seen.add(key)
            out.append(it)
            if len(out) >= limit:
                return out
    return out

def resolve_video_item(item, max_quality=None, ask_quality=False, prefer_dash=True):
    if max_quality is None:
        max_quality = DEFAULT_MAX_QUALITY
    if ask_quality and _HAS_KODI:
        try:
            qs = resolver.list_qualities(item, prefer_dash=prefer_dash)
        except Exception:
            qs = []
        if not qs:
            return None, item
        labels = ["[B]{}[/B] | {}".format(q.get("host", "Video"),
                                          q.get("label", "Auto")) for q in qs]
        idx = xbmcgui.Dialog().select("MultiTrailer - Choose Quality", labels)
        if idx < 0:
            return None, item
        return qs[idx], item
    try:
        q = resolver.resolve_ex(item, max_height=max_quality, prefer_dash=prefer_dash)
    except Exception:
        q = None
    return q, item

def get_popular_movies(page=1):
    return tmdb.popular("movie", page=page)

def get_popular_tv(page=1):
    return tmdb.popular("tv", page=page)

def get_trending(media_type="all", window="week", page=1):
    return tmdb.trending(media_type=media_type, window=window, page=page)

def get_fan_film_creators():
    return creators.list_creators()

def get_fan_films_for_creator(creator_id_or_name, page_token=None, limit=30):
    creator = creators.get_creator(creator_id_or_name)
    if not creator:
        return {"items": [], "next_page_token": None, "creator": None}
    res = creators.get_creator_videos(creator, page_token=page_token, limit=limit)
    res["creator"] = creator
    return res

def get_all_fan_films(limit_per_creator=10):
    return creators.get_all_fan_films(limit_per_creator=limit_per_creator)

def resolve_youtube_video(video_id, max_quality=None, ask_quality=False, prefer_dash=True):
    if max_quality is None:
        max_quality = DEFAULT_MAX_QUALITY
    item = {
        "source": "fan_film", "provider": "youtube", "id": video_id,
        "url": "https://www.youtube.com/watch?v=" + video_id,
        "title": "", "type": "Movie", "official": False,
        "fan_made": True, "channel": "",
    }
    if ask_quality and _HAS_KODI:
        try:
            qs = resolver.list_qualities(item, prefer_dash=prefer_dash)
        except Exception:
            qs = []
        if not qs:
            return None, item
        labels = ["[B]{}[/B] · {}".format(q.get("host", "YouTube"),
                                          q.get("label", "Auto")) for q in qs]
        idx = xbmcgui.Dialog().select("MultiTrailer - Choose Quality", labels)
        if idx < 0:
            return None, item
        return qs[idx], item
    q = resolver.resolve_ex(item, max_height=max_quality, prefer_dash=prefer_dash)
    return q, item
