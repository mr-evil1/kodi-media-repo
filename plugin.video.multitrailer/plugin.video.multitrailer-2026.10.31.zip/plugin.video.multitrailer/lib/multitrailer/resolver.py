import re
import json
from . import langpref, debug as _dbgv
try:
    import requests
except ImportError:
    requests = None
from . import host_extractors as _hosts
from . import youtube as _yt
from . import ytdlp_bridge as _ytdlp
from . import dash as _dash
_TIMEOUT = 12
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
_UA_ROTATION = (
    _UA,
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:123.0) Gecko/20100101 Firefox/123.0",
)

def _http(url, headers=None, rotate_ua=False, referer=None):
    if requests is None:
        return None
    uas = _UA_ROTATION if rotate_ua else (_UA,)
    base = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": langpref.accept_language(),
        "Accept-Encoding": "gzip, deflate",
    }
    if referer:
        base["Referer"] = referer
    if headers:
        base.update(headers)
    last_status = None
    for ua in uas:
        h = dict(base)
        h["User-Agent"] = ua
        try:
            r = requests.get(url, headers=h, timeout=_TIMEOUT, allow_redirects=True)
            last_status = r.status_code
            _dbgv.vlog("resolver http {} -> {}".format(url, r.status_code))
            if r.status_code == 200 and r.text:
                return r.text
        except Exception:
            continue
    if rotate_ua and last_status is not None:
        try:
            from . import debug as _dbg
            _dbg.wlog("http: all UAs failed for {} (last={})".format(url, last_status))
        except Exception:
            pass
    return None

def _resolve_imdb(video_id):
    html = _http("https://www.imdb.com/video/{}/".format(video_id))
    if not html:
        return None
    m = re.search(r'"playbackURLs":(\[.*?\])', html)
    if not m:
        return None
    try:
        data = json.loads(m.group(1))
        order = {"1080p": 4, "720p": 3, "480p": 2, "SD": 1, "auto": 0}
        data.sort(key=lambda x: order.get(x.get("displayName", {}).get("value", ""), 0), reverse=True)
        for entry in data:
            url = entry.get("url")
            if url and ".mp4" in url:
                return {"url": url, "label": entry.get("displayName", {}).get("value", "?")}
    except Exception:
        pass
    return None

def _imdb_qualities(video_id):
    html = _http("https://www.imdb.com/video/{}/".format(video_id))
    out = []
    if not html:
        return out
    m = re.search(r'"playbackURLs":(\[.*?\])', html)
    if not m:
        return out
    try:
        for e in json.loads(m.group(1)):
            url = e.get("url")
            if url and ".mp4" in url:
                label = e.get("displayName", {}).get("value", "SD")
                h = {"1080p": 1080, "720p": 720, "480p": 480, "SD": 360}.get(label, 360)
                out.append({"url": url, "label": label, "height": h, "host": "IMDB"})
    except Exception:
        pass
    return sorted(out, key=lambda x: -x["height"])

def _youtube_dash(video_id, max_height=None):
    fmts, dur = _yt.get_adaptive_formats(video_id)
    if not fmts or not dur:
        return None
    mpd_path = _dash.write_mpd(fmts, dur, max_height=max_height)
    if not mpd_path:
        return None
    best_h = 0
    for f in fmts:
        if f.get("url") and (f.get("height") or 0) > best_h:
            h = f.get("height") or 0
            if max_height and h > max_height:
                continue
            best_h = h
    label = "Auto"
    if best_h >= 2160:
        label = "4K (DASH)"
    elif best_h >= 1440:
        label = "1440p (DASH)"
    elif best_h >= 1080:
        label = "1080p (DASH)"
    elif best_h >= 720:
        label = "720p (DASH)"
    elif best_h > 0:
        label = "{}p (DASH)".format(best_h)
    return {
        "url": mpd_path, "label": label, "height": best_h, "host": "YouTube",
        "is_dash": True, "isa_manifest_type": "mpd",
        "mime_type": "application/dash+xml", "ext": "mpd",
    }
_FLICKS_JWID_RES = [
    re.compile(r"""data-jwid=["']([A-Za-z0-9_-]{6,})["']"""),
    re.compile(r"cdn\.jwplayer\.com/v2/media/([A-Za-z0-9_-]{6,})"),
    re.compile(r"cdn\.jwplayer\.com/players/([A-Za-z0-9_-]{6,})-[A-Za-z0-9_-]+\.js"),
    re.compile(r"cdn\.jwplayer\.com/libraries/([A-Za-z0-9_-]{6,})\.js"),
    re.compile(r"""jwplayer\(["'][^"']+["']\)\.setup\([^)]*["']([A-Za-z0-9_-]{8,})["']"""),
]
_FLICKS_LABEL_HEIGHT_RE = re.compile(r"(\d{3,4})")

def _flicks_log(msg):
    try:
        from . import debug as _dbg
        _dbg.wlog("flicks: " + str(msg))
    except Exception:
        pass

def _flicks_jwid_candidates(page_url):
    html = _http(page_url, rotate_ua=True, referer="https://www.flicks.co.uk/")
    if not html:
        _flicks_log("page fetch failed: {}".format(page_url))
        return []
    candidates = []
    seen = set()
    for rx in _FLICKS_JWID_RES:
        for m in rx.finditer(html):
            jwid = m.group(1)
            if len(jwid) < 6 or jwid in seen:
                continue
            seen.add(jwid)
            candidates.append(jwid)
    if not candidates:
        _flicks_log("no jwid found on {}".format(page_url))
    return candidates

def _flicks_jwid(page_url):
    ids = _flicks_jwid_candidates(page_url)
    return ids[0] if ids else None

def _flicks_qualities(page_url):
    if not page_url or requests is None:
        return []
    candidates = _flicks_jwid_candidates(page_url)
    if not candidates:
        return []
    data = None
    chosen = None
    for jwid in candidates:
        try:
            r = requests.get("https://cdn.jwplayer.com/v2/media/" + jwid,
                             headers={"User-Agent": _UA,
                                      "Accept": "application/json"},
                             timeout=_TIMEOUT)
        except Exception as exc:
            _flicks_log("jw cdn error {}: {}".format(jwid, exc))
            continue
        if r.status_code != 200:
            _flicks_log("jw cdn {} -> {} (trying next)".format(jwid, r.status_code))
            continue
        try:
            data = r.json()
        except Exception as exc:
            _flicks_log("jw cdn json error {}: {}".format(jwid, exc))
            continue
        chosen = jwid
        break
    if not data:
        _flicks_log("no valid jwid media found on {} (tried {})".format(
            page_url, ",".join(candidates)))
        return []
    if chosen and chosen != candidates[0]:
        _flicks_log("jw cdn resolved via fallback candidate {} (primary was {})".format(
            chosen, candidates[0]))
    playlist = data.get("playlist") or []
    if not playlist:
        return []
    sources = playlist[0].get("sources") or []
    out = []
    for s in sources:
        url = s.get("file")
        if not url:
            continue
        typ = (s.get("type") or "").lower()
        if typ.startswith("audio/"):
            continue
        label = s.get("label") or "Auto"
        height = s.get("height") or 0
        if not height:
            hm = _FLICKS_LABEL_HEIGHT_RE.search(str(label))
            if hm:
                height = int(hm.group(1))
        is_hls = typ == "application/vnd.apple.mpegurl" or url.endswith(".m3u8")
        out.append({
            "url": url,
            "label": ("Auto (HLS)" if is_hls else
                      ("{}p".format(height) if height else (str(label) or "Auto"))),
            "height": 9999 if is_hls else height,
            "host": "Flicks",
            "is_dash": False,
            "isa_manifest_type": "hls" if is_hls else None,
            "mime_type": ("application/vnd.apple.mpegurl" if is_hls else "video/mp4"),
            "ext": ("m3u8" if is_hls else "mp4"),
        })
    out.sort(key=lambda q: -q["height"])
    for q in out:
        if q["host"] == "Flicks" and q["height"] == 9999:
            q["height"] = 0
    return out

def resolve(item, max_height=None):
    q = resolve_ex(item, max_height=max_height)
    return q["url"] if q else None

def _source_url(provider, video_id, page_url):
    if page_url and str(page_url).startswith(("http://", "https://")):
        return page_url
    if not video_id:
        return page_url or ""
    bases = {
        "youtube": "https://www.youtube.com/watch?v=",
        "vimeo": "https://vimeo.com/",
        "tiktok": "https://www.tiktok.com/video/",
        "dailymotion": "https://www.dailymotion.com/video/",
    }
    base = bases.get(provider)
    if not base:
        return page_url or str(video_id)
    return base + str(page_url or video_id)

def resolve_ex(item, max_height=None, prefer_dash=True):
    provider = (item.get("provider") or "").strip().lower()
    vid = item.get("id")
    page_url = _source_url(provider, vid, item.get("url"))
    if provider in ("vimeo", "dailymotion", "tiktok", "imdb", "direct"):
        rows = _hosts.list_qualities(provider, page_url)
        if rows:
            return _pick_ex(rows, max_height)
    if provider == "youtube":
        dash = _youtube_dash(vid, max_height=max_height) if prefer_dash else None
        if dash:
            return dash
        hls = _yt.hls_quality(vid)
        if hls:
            return hls
        stream = _yt.best_stream(vid, max_height=max_height)
        if stream:
            return {
                "url": stream["url"], "label": stream["label"],
                "height": stream["height"], "host": "YouTube",
                "is_dash": False, "isa_manifest_type": None,
                "mime_type": "video/" + (stream.get("container") or "mp4"),
                "ext": stream.get("container") or "mp4",
            }
        qs = _ytdlp.list_qualities(page_url or ("https://www.youtube.com/watch?v=" + vid),
                                  host_label="YouTube")
        return _pick_ex([q for q in qs if prefer_dash or not (q.get("is_dash") or q.get("ext") == "mpd")], max_height)
    if provider == "imdb":
        r = _resolve_imdb(vid)
        if r:
            return {
                "url": r["url"], "label": r["label"],
                "height": {"1080p": 1080, "720p": 720, "480p": 480}.get(r["label"], 360),
                "host": "IMDB", "is_dash": False, "isa_manifest_type": None,
                "mime_type": "video/mp4", "ext": "mp4",
            }
        return None
    if provider == "vimeo":
        qs = _ytdlp.list_qualities(page_url, host_label="Vimeo")
        qs = _hosts.available(qs, provider)
        return _pick_ex(qs, max_height)
    if provider == "tiktok":
        qs = _ytdlp.list_qualities(page_url, host_label="TikTok")
        qs = _hosts.available(qs, provider)
        return _pick_ex(qs, max_height)
    if provider == "dailymotion":
        qs = _ytdlp.list_qualities(page_url, host_label="Dailymotion")
        qs = _hosts.available(qs, provider)
        return _pick_ex(qs, max_height)
    if provider == "flicks":
        qs = _flicks_qualities(page_url)
        return _pick_ex(qs, max_height)
    if provider == "direct":
        return None
    return None

def _pick_ex(qs, max_height=None):
    if not qs:
        return None
    filt = qs
    if max_height:
        hc = [q for q in qs if q.get("height", 0) <= max_height]
        if hc:
            filt = hc
    q = filt[0]
    ext = q.get("ext") or ""
    is_hls = ext == "m3u8" or q.get("label", "").startswith("Auto (HLS)")
    is_dash = bool(q.get("is_dash")) or ext == "mpd"
    native_hls = is_hls and bool(q.get("native_hls"))
    if q.get("http_headers") and (native_hls or not (is_dash or is_hls)) and "|" not in q["url"]:
        from urllib.parse import urlencode
        q = dict(q, url=q["url"] + "|" + urlencode(q["http_headers"]))
    return dict(q,
        is_dash=is_dash,
        isa_manifest_type=None if native_hls else (q.get("isa_manifest_type") or ("mpd" if is_dash else ("hls" if is_hls else None))),
        mime_type=q.get("mime_type") or ("application/dash+xml" if is_dash else ("application/vnd.apple.mpegurl" if is_hls else ("video/" + ext if ext else ""))),
        ext=ext,
    )

def list_qualities(item, prefer_dash=True):
    provider = (item.get("provider") or "").strip().lower()
    vid = item.get("id")
    page_url = _source_url(provider, vid, item.get("url"))
    if provider in ("vimeo", "dailymotion", "tiktok", "imdb", "direct"):
        rows = _hosts.list_qualities(provider, page_url)
        if rows:
            return rows
    if provider == "youtube":
        result = []
        hls = _yt.hls_quality(vid)
        if hls:
            result.append(hls)
        fmts, dur = _yt.get_adaptive_formats(vid)
        if prefer_dash and fmts and dur:
            avail = sorted({(f.get("height") or 0) for f in fmts
                            if f.get("url") and (f.get("height") or 0) > 0},
                           reverse=True)
            best_h = avail[0] if avail else 0
            ladder = [(2160, "4K (DASH)"), (1440, "1440p (DASH)"),
                      (1080, "1080p (DASH)"), (720, "720p (DASH)"),
                      (480, "480p (DASH)"), (360, "360p (DASH)")]
            seen = set()
            for cap, label in ladder:
                if best_h < cap:
                    continue
                if cap in seen:
                    continue
                seen.add(cap)
                mpd_path = _dash.write_mpd(fmts, dur, max_height=cap)
                if mpd_path:
                    result.append({
                        "url": mpd_path, "label": label, "height": cap,
                        "host": "YouTube", "is_dash": True,
                        "isa_manifest_type": "mpd",
                        "mime_type": "application/dash+xml", "ext": "mpd",
                    })
        streams = _yt.get_streams(vid)
        for s in streams:
            if not s.get("has_audio"):
                continue
            result.append({
                "url": s["url"], "label": s["label"], "height": s["height"],
                "host": "YouTube", "is_dash": False, "isa_manifest_type": None,
                "mime_type": "video/" + s.get("container", "mp4"),
                "ext": s.get("container", "mp4"),
            })
        if result:
            result.sort(key=lambda q: (-q["height"], 0 if q["is_dash"] else 1))
            return result
        qs = _ytdlp.list_qualities(page_url or ("https://www.youtube.com/watch?v=" + vid),
                                   host_label="YouTube")
        return _enrich_ytdlp([q for q in qs if prefer_dash or not (q.get("is_dash") or q.get("ext") == "mpd")])
    if provider == "imdb":
        return [_enrich_simple(q) for q in _imdb_qualities(vid)]
    if provider == "vimeo":
        qs = _ytdlp.list_qualities(page_url, host_label="Vimeo")
        return _enrich_ytdlp(_hosts.available(qs, provider))
    if provider == "tiktok":
        qs = _ytdlp.list_qualities(page_url, host_label="TikTok")
        return _enrich_ytdlp(_hosts.available(qs, provider))
    if provider == "dailymotion":
        qs = _ytdlp.list_qualities(page_url, host_label="Dailymotion")
        return _enrich_ytdlp(_hosts.available(qs, provider))
    if provider == "flicks":
        return _flicks_qualities(page_url)
    if provider == "direct":
        return []
    return []

def _enrich_simple(q):
    ext = q.get("ext") or ""
    return dict(q, is_dash=False, isa_manifest_type=None,
                mime_type="video/" + ext if ext else "", ext=ext)

def _enrich_ytdlp(qs):
    return [_pick_ex([q]) for q in qs]
