import sys
import os
import json
import shutil
import subprocess

def _log(message):
    try:
        from . import debug
        debug.wlog("yt-dlp: " + str(message), level="WARNING")
    except Exception:
        try:
            import xbmc
            xbmc.log("[multitrailer] yt-dlp: " + str(message), xbmc.LOGWARNING)
        except ImportError:
            pass

def _native_paths():
    folder = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                          "resources", "bin", "windows-x64")
    return os.path.join(folder, "yt-dlp.exe"), os.path.join(folder, "node.exe")

def native_available():
    return sys.platform == "win32" and os.path.isfile(_native_paths()[0])

class _NativeYDL:
    def extract_info(self, url, download=False):
        executable, node = _native_paths()
        command = [executable, "--ignore-config", "--no-playlist",
                   "--skip-download", "--dump-single-json", "--no-warnings", "--no-cache-dir",
                   "--socket-timeout", "15", "--retries", "1"]
        runtime = node if os.path.isfile(node) else shutil.which("node")
        if runtime:
            command.extend(["--js-runtimes", "node:" + runtime])
        command.extend(["--", url])
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=90, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if result.returncode:
            _log(result.stderr.decode("utf-8", "replace")[-1500:])
            return None
        return json.loads(result.stdout.decode("utf-8"))
_QUALITY_LABELS = {
    144: "144p", 240: "240p", 360: "360p", 480: "480p",
    720: "720p", 1080: "1080p", 1440: "1440p", 2160: "4K", 4320: "8K",
}

def _label_for_height(h):
    if not h:
        return "Auto"
    for std in sorted(_QUALITY_LABELS.keys(), reverse=True):
        if h >= std:
            return _QUALITY_LABELS[std]
    return "{}p".format(h)

class _YdlLogger:
    def debug(self, msg):
        _log(msg)

    def info(self, msg):
        _log(msg)

    def warning(self, msg):
        _log(msg)

    def error(self, msg):
        _log(msg)

def _get_ydl():
    if native_available():
        return _NativeYDL()
    try:
        from yt_dlp import YoutubeDL
    except Exception as exc:
        _log("Cannot import bundled extractor: {}".format(exc))
        return None
    opts = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        "ignoreerrors": True,
        "extract_flat": False,
        "socket_timeout": 15,
        "cachedir": False,
    }
    try:
        from . import debug
        if debug.verbose():
            opts["quiet"] = False
            opts["no_warnings"] = False
            opts["verbose"] = True
            opts["logger"] = _YdlLogger()
    except Exception:
        pass
    try:
        return YoutubeDL(opts)
    except Exception:
        return None

def list_qualities(url, host_label=None):
    if not url:
        return []
    ydl = _get_ydl()
    if ydl is None:
        return []
    try:
        info = ydl.extract_info(url, download=False)
    except Exception as exc:
        _log("Extraction failed: {}".format(exc))
        return []
    if not info:
        return []
    if "entries" in info:
        for e in info.get("entries") or []:
            if e:
                info = e
                break
    if not info or "formats" not in info:
        single = info.get("url") if info else None
        if single and info.get('vcodec') != 'none':
            return [{
                "url": single,
                "label": _label_for_height(info.get("height")),
                "height": info.get("height") or 0,
                "host": host_label or (info.get("extractor_key") or "Video"),
                "ext": info.get("ext") or "mp4",
                "http_headers": info.get("http_headers") or {},
            }]
        return []
    host = host_label or info.get("extractor_key") or "Video"
    out = []
    seen = set()
    hls_masters = {}
    for f in info.get("formats") or []:
        if "m3u8" in (f.get("protocol") or "").lower():
            master = f.get("manifest_url")
            if master and f.get("vcodec") != "none":
                hls_masters[master] = max(hls_masters.get(master, 0), f.get("height") or 0)
    hls_url = info.get("hls_manifest_url")
    if hls_url:
        hls_masters.setdefault(hls_url, info.get("height") or 0)
    for master, height in hls_masters.items():
        out.append({"url": master, "label": "Auto (HLS)", "height": height,
                    "host": host, "ext": "m3u8", "http_headers": info.get("http_headers") or {}})
    for f in info.get("formats") or []:
        url_ = f.get("url")
        if not url_:
            continue
        if not url_.startswith("http"):
            continue
        vcodec = f.get("vcodec") or "none"
        acodec = f.get("acodec") or "none"
        proto = (f.get("protocol") or "").lower()
        is_hls = "m3u8" in proto
        if vcodec == "none":
            continue
        if acodec == "none":
            continue
        height = f.get("height") or 0
        key = (height, f.get("ext"), proto)
        if key in seen:
            continue
        seen.add(key)
        out.append({
            "url": url_,
            "label": _label_for_height(height),
            "height": height,
            "host": host,
            "ext": "m3u8" if is_hls else (f.get("ext") or ""),
            "http_headers": dict(info.get("http_headers") or {}, **(f.get("http_headers") or {})),
        })
    if not out and info.get("url") and info.get("vcodec") != "none" and info.get("acodec") not in (None, "none"):
        out.append({
            "url": info["url"],
            "label": _label_for_height(info.get("height")),
            "height": info.get("height") or 0,
            "host": host,
            "ext": info.get("ext") or "",
        })
    out.sort(key=lambda x: -x["height"])
    final = []
    seen_h = set()
    for q in out:
        if q["height"] in seen_h:
            continue
        seen_h.add(q["height"])
        final.append(q)
    return final

def best_url(url, max_height=None):
    qs = list_qualities(url)
    if not qs:
        return None
    if max_height:
        filt = [q for q in qs if q["height"] <= max_height]
        if filt:
            return filt[0]["url"]
    return qs[0]["url"]
