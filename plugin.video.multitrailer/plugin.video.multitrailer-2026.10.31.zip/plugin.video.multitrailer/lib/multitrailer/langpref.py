import re
try:
    import xbmcaddon
except ImportError:
    xbmcaddon = None
_VALID = ("all", "de", "en")
_DE_REGEX = re.compile(
    r"\b(?:deutsch|deutsche[rsn]?|german|synchronisiert|offizieller|offizielle[rsn]?|"
    r"kinotrailer|kino-trailer|filmtrailer|jetzt im kino|ab sofort im kino|neu im kino|"
    r"im kino|ab dem \d+\.|vorschau|erster trailer|zweiter trailer|finaler trailer|"
    r"erster teaser|neuer trailer|hörspiel|staffel)\b|\((?:de|ger)\)|\[(?:de|ger)\]|[äöüß]",
    re.IGNORECASE,
)
_DE_CHANNELS = (
    "kinocheck", "filmtrailer", "studiocanal deutschland", "constantin film",
    "leonine", "warner bros. deutschland", "sony pictures deutschland",
    "universal pictures germany", "disney deutschland", "paramount pictures germany",
    "wild bunch germany", "netflix deutschland", "prime video de", "sky deutschland",
    "moviepilot", "kino.de", "filmstarts", "ard", "zdf", "rtl", "prosieben",
)

def mode():
    value = ""
    if xbmcaddon is not None:
        try:
            value = xbmcaddon.Addon("plugin.video.multitrailer").getSetting("content_language")
        except Exception:
            value = ""
    value = (value or "de").strip().lower()
    return value if value in _VALID else "de"

def hl():
    return "en" if mode() == "en" else "de"

def gl():
    return "US" if mode() == "en" else "DE"

def accept_language():
    if mode() == "en":
        return "en-US,en;q=0.9"
    return "de-DE,de;q=0.9,en;q=0.4"

def tmdb_language():
    return "en-US" if mode() == "en" else "de-DE"

def tmdb_region():
    return "US" if mode() == "en" else "DE"

def tmdb_video_languages():
    m = mode()
    if m == "de":
        return "de"
    if m == "en":
        return "en"
    return "de,en,null"

def search_suffix():
    m = mode()
    if m == "de":
        return " Trailer Deutsch"
    if m == "en":
        return " official trailer"
    return " Trailer"

def latest_queries():
    m = mode()
    de = ["neue Kinotrailer Deutsch", "Kino Trailer Deutsch neu", "offizieller Trailer Deutsch"]
    en = ["new movie trailers", "official trailer new movies", "upcoming movie trailers official"]
    if m == "de":
        return de
    if m == "en":
        return en
    return de[:2] + en[:2]

def is_german_text(title, channel=""):
    if _DE_REGEX.search(title or ""):
        return True
    ch = (channel or "").lower()
    return any(c in ch for c in _DE_CHANNELS)

def matches(item):
    m = mode()
    if m == "all":
        return True
    lang = (item.get("language") or "").strip().lower()[:2]
    if lang:
        return lang == m
    german = is_german_text(item.get("title", ""), item.get("channel", ""))
    if m == "de":
        return german
    return not german
