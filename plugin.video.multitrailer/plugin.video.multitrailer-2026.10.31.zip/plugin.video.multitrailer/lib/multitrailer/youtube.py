import json
from . import langpref, debug
import re
import time
_PLAYER_CACHE = {}
try:
    import requests
except ImportError:
    requests = None
_TIMEOUT = 12
_CLIENTS = [
    {
        "name": "IOS",
        "params": "2AMB",
        "context": {"client": {
            "clientName": "IOS", "clientVersion": "20.20.7",
            "deviceMake": "Apple", "deviceModel": "iPhone16,2",
            "osName": "iOS", "osVersion": "18.5.0.22F76",
            "platform": "MOBILE", "hl": "de", "gl": "DE",
        }},
        "ua": "com.google.ios.youtube/20.20.7 (iPhone16,2; U; CPU iOS 18_5_0 like Mac OS X)",
    },
    {
        "name": "ANDROID",
        "params": "2AMB",
        "context": {"client": {
            "clientName": "ANDROID", "clientVersion": "20.10.38",
            "androidSdkVersion": 32, "osName": "Android", "osVersion": "15",
            "platform": "MOBILE", "hl": "de", "gl": "DE",
        }},
        "ua": "com.google.android.youtube/20.10.38 (Linux; U; Android 15) gzip",
    },
]

def _localized(context):
    ctx = {"client": dict(context["client"], hl=langpref.hl(), gl=langpref.gl())}
    for k, v in context.items():
        if k != "client":
            ctx[k] = v
    return ctx
_HEADERS = {
    "Content-Type": "application/json",
    "Accept-Language": "de-DE,de;q=0.9,en;q=0.4",
    "X-YouTube-Client-Name": "3",
    "Origin": "https://www.youtube.com",
}
_ITAG_MAP = {
    18:  (360,  "360p",  "mp4"),
    22:  (720,  "720p",  "mp4"),
    37:  (1080, "1080p", "mp4"),
    133: (240,  "240p",  "mp4"),
    134: (360,  "360p",  "mp4"),
    135: (480,  "480p",  "mp4"),
    136: (720,  "720p",  "mp4"),
    137: (1080, "1080p", "mp4"),
    264: (1440, "1440p", "mp4"),
    266: (2160, "4K",    "mp4"),
    242: (240,  "240p",  "webm"),
    243: (360,  "360p",  "webm"),
    244: (480,  "480p",  "webm"),
    247: (720,  "720p",  "webm"),
    248: (1080, "1080p", "webm"),
    271: (1440, "1440p", "webm"),
    313: (2160, "4K",    "webm"),
}
_PROGRESSIVE_ITAGS = {18, 22, 37}
_HTML_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
_HTML_PLAYER_RES = [
    re.compile(r"var\s+ytInitialPlayerResponse\s*=\s*(\{.+?\})\s*;\s*(?:var|</script>)", re.DOTALL),
    re.compile(r"ytInitialPlayerResponse\s*=\s*(\{.+?\})\s*;\s*(?:var|</script>|\(function)", re.DOTALL),
    re.compile(r'"ytInitialPlayerResponse"\s*:\s*(\{.+?\})\s*,\s*"', re.DOTALL),
]
_HTML_EMBED_JSON_STR_RE = re.compile(
    r'"embedded_player_response"\s*:\s*"((?:\\.|[^"\\])*)"'
)

def _html_player_response(video_id):
    if requests is None:
        return None
    urls = [
        "https://www.youtube.com/watch?v={}&bpctr=9999999999&has_verified=1&hl={}&gl={}".format(video_id, langpref.hl(), langpref.gl()),
        "https://m.youtube.com/watch?v={}&bpctr=9999999999&has_verified=1&hl={}&gl={}".format(video_id, langpref.hl(), langpref.gl()),
        "https://www.youtube.com/embed/{}?hl={}".format(video_id, langpref.hl()),
    ]
    headers = {
        "User-Agent": _HTML_UA,
        "Accept-Language": langpref.accept_language(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Cookie": "CONSENT=YES+cb.20210328-17-p0.de+FX+000; SOCS=CAI",
    }
    for u in urls:
        try:
            r = requests.get(u, headers=headers, timeout=_TIMEOUT)
        except Exception:
            continue
        if r.status_code != 200 or not r.text:
            continue
        html = r.text
        for rx in _HTML_PLAYER_RES:
            m = rx.search(html)
            if not m:
                continue
            blob = m.group(1)
            blob = _balance_json(blob, html, m.start(1))
            try:
                pj = json.loads(blob)
            except Exception:
                continue
            if pj.get("streamingData") or pj.get("videoDetails"):
                return pj
        m = _HTML_EMBED_JSON_STR_RE.search(html)
        if m:
            raw = '"' + m.group(1) + '"'
            try:
                decoded = json.loads(raw)
                pj = json.loads(decoded)
            except Exception:
                pj = None
            if pj and (pj.get("streamingData") or pj.get("videoDetails")):
                return pj
    return None

def _balance_json(blob, full_text, start_offset):
    if blob.count("{") == blob.count("}"):
        return blob
    depth = 0
    in_str = False
    esc = False
    i = start_offset
    n = len(full_text)
    while i < n:
        ch = full_text[i]
        if esc:
            esc = False
        elif ch == "\\":
            esc = True
        elif in_str:
            if ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return full_text[start_offset:i + 1]
        i += 1
    return blob

def _player(video_id, client):
    if requests is None:
        return None
    url = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false"
    body = {
        "videoId": video_id,
        "context": _localized(client["context"]),
        "contentCheckOk": True,
        "racyCheckOk": True,
    }
    if client.get("params"):
        body["params"] = client["params"]
    headers = dict(_HEADERS)
    headers["Accept-Language"] = langpref.accept_language()
    headers["Origin"] = "https://m.youtube.com"
    if client.get("ua"):
        headers["User-Agent"] = client["ua"]
    cn = client["context"]["client"]["clientName"]
    cv = client["context"]["client"]["clientVersion"]
    headers["X-YouTube-Client-Name"] = {
        "ANDROID": "3",
        "TVHTML5": "7",
        "TVHTML5_SIMPLY_EMBEDDED_PLAYER": "85",
        "ANDROID_VR": "28",
        "WEB_CREATOR": "62",
        "MEDIA_CONNECT_FRONTEND": "95",
        "WEB_EMBEDDED_PLAYER": "56",
        "IOS": "5",
        "MWEB": "2",
    }.get(cn, "1")
    headers["X-YouTube-Client-Version"] = cv
    headers["Accept-Encoding"] = "gzip, deflate"
    headers["Connection"] = "keep-alive"
    try:
        r = requests.post(url, headers=headers, data=json.dumps(body), timeout=_TIMEOUT)
        debug.vlog("youtube player {} client={} -> {}".format(video_id, cn, r.status_code))
        if r.status_code == 200:
            return r.json()
    except Exception as exc:
        debug.vlog("youtube player {} client={} Fehler: {}".format(video_id, cn, exc), "WARNING")
    return None

def _fix_stream_url(url):
    if not url or "googlevideo.com" not in url:
        return url
    if "ratebypass" not in url:
        separator = "&" if "?" in url else "?"
        url = url + separator + "ratebypass=yes"
    return url

def _extract_streams(player_json):
    out = []
    if not player_json:
        return out
    sd = player_json.get("streamingData") or {}
    formats = sd.get("formats") or []
    adaptive = sd.get("adaptiveFormats") or []
    for f in formats + adaptive:
        url = f.get("url")
        if not url:
            continue
        url = _fix_stream_url(url)
        itag = f.get("itag")
        info = _ITAG_MAP.get(itag)
        if info:
            height, label, container = info
        else:
            height = f.get("height") or 0
            if not height:
                continue
            mime = f.get("mimeType", "")
            container = (mime.split("/", 1)[1].split(";", 1)[0]
                         if "/" in mime else "mp4")
            label = "{}p".format(height)
        if not itag:
            continue
        mime = f.get("mimeType", "")
        is_progressive = itag in _PROGRESSIVE_ITAGS or ("video/" in mime and "audio" in mime)
        out.append({
            "url": url,
            "itag": itag,
            "height": height,
            "label": label,
            "container": container,
            "has_audio": is_progressive,
            "bitrate": f.get("bitrate") or 0,
        })
    return out

def get_streams(video_id):
    streams = _extract_streams(get_player_response(video_id))
    streams.sort(key=lambda x: (-x["height"], 0 if x["has_audio"] else 1))
    return streams

def get_player_response(video_id):
    cached = _PLAYER_CACHE.get(video_id)
    if cached and time.monotonic() - cached[0] < 120:
        return cached[1]
    merged = None
    seen_itags = set()
    combined_adaptive = []
    combined_progressive = []
    for client in _CLIENTS:
        pj = _player(video_id, client)
        if not pj:
            continue
        status = (pj.get("playabilityStatus") or {}).get("status")
        if status and status not in ("OK", "LIVE_STREAM"):
            continue
        if merged is None:
            merged = pj
        sd = pj.get("streamingData") or {}
        for f in sd.get("adaptiveFormats") or []:
            itag = f.get("itag")
            if itag in seen_itags:
                continue
            if not f.get("url"):
                continue
            seen_itags.add(itag)
            combined_adaptive.append(f)
        for f in sd.get("formats") or []:
            itag = f.get("itag")
            if ("p_" + str(itag)) in seen_itags:
                continue
            if not f.get("url"):
                continue
            seen_itags.add("p_" + str(itag))
            combined_progressive.append(f)
    if merged is None or (not combined_adaptive and not combined_progressive):
        html_pj = _html_player_response(video_id)
        if html_pj:
            if merged is None:
                merged = html_pj
            sd = html_pj.get("streamingData") or {}
            for f in sd.get("adaptiveFormats") or []:
                itag = f.get("itag")
                if itag in seen_itags or not f.get("url"):
                    continue
                seen_itags.add(itag)
                combined_adaptive.append(f)
            for f in sd.get("formats") or []:
                itag = f.get("itag")
                key = "p_" + str(itag)
                if key in seen_itags or not f.get("url"):
                    continue
                seen_itags.add(key)
                combined_progressive.append(f)
    if merged is None:
        return None
    merged.setdefault("streamingData", {})
    for f in combined_adaptive:
        if f.get("url"):
            f["url"] = _fix_stream_url(f["url"])
    for f in combined_progressive:
        if f.get("url"):
            f["url"] = _fix_stream_url(f["url"])
    merged["streamingData"]["adaptiveFormats"] = combined_adaptive
    merged["streamingData"]["formats"] = combined_progressive
    if combined_adaptive or combined_progressive or merged["streamingData"].get("hlsManifestUrl"):
        if len(_PLAYER_CACHE) >= 32:
            _PLAYER_CACHE.clear()
        _PLAYER_CACHE[video_id] = (time.monotonic(), merged)
    return merged

def hls_quality(video_id):
    response = get_player_response(video_id) or {}
    url = (response.get("streamingData") or {}).get("hlsManifestUrl")
    if not url:
        return None
    return {"url": url, "label": "Auto (HLS)", "height": 0,
            "host": "YouTube", "is_dash": False, "isa_manifest_type": "hls",
            "mime_type": "application/vnd.apple.mpegurl", "ext": "m3u8"}

def get_adaptive_formats(video_id):
    pj = get_player_response(video_id)
    if not pj:
        return [], 0
    sd = pj.get("streamingData") or {}
    fmts = sd.get("adaptiveFormats") or []
    vd = pj.get("videoDetails") or {}
    try:
        dur = float(vd.get("lengthSeconds") or 0)
    except (TypeError, ValueError):
        dur = 0
    return fmts, dur

def best_stream(video_id, max_height=None):
    streams = get_streams(video_id)
    progressive = [s for s in streams if s["has_audio"]]
    if max_height:
        progressive = [s for s in progressive if s["height"] <= max_height] or progressive
    if progressive:
        return progressive[0]
    return None

def stream_for_quality(video_id, max_height=None):
    s = best_stream(video_id, max_height=max_height)
    return s["url"] if s else None

def title_and_channel(video_id):
    for client in _CLIENTS:
        pj = _player(video_id, client)
        if not pj:
            continue
        vd = pj.get("videoDetails") or {}
        return vd.get("title", ""), vd.get("author", "")
    return "", ""
