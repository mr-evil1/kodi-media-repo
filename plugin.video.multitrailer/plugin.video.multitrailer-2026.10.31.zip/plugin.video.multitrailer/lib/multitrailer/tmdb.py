try:
    import requests
except ImportError:
    requests = None
from . import langpref, debug
DEFAULT_TMDB_KEY = "8265bd1679663a7ea12ac168da84d2e8"
BASE = "https://api.themoviedb.org/3"
IMG = "https://image.tmdb.org/t/p"
_TIMEOUT = 12

def _get(path, params=None):
    if requests is None:
        return {}
    p = {"api_key": DEFAULT_TMDB_KEY, "language": langpref.tmdb_language(), "region": langpref.tmdb_region()}
    if params:
        p.update(params)
    try:
        r = requests.get(BASE + path, params=p, timeout=_TIMEOUT)
        debug.vlog("tmdb {} {} -> {}".format(path, {k: v for k, v in p.items() if k != "api_key"}, r.status_code))
        if r.status_code == 200:
            return r.json()
    except Exception as exc:
        debug.vlog("tmdb {} Fehler: {}".format(path, exc), "WARNING")
    return {}

def poster(path, size="w500"):
    if not path:
        return ""
    return "{}/{}{}".format(IMG, size, path)

def fanart(path, size="original"):
    if not path:
        return ""
    return "{}/{}{}".format(IMG, size, path)

def find_by_imdb(imdb_id):
    if not imdb_id:
        return None
    data = _get("/find/{}".format(imdb_id), {"external_source": "imdb_id"})
    if data.get("movie_results"):
        m = data["movie_results"][0]
        m["media_type"] = "movie"
        return m
    if data.get("tv_results"):
        t = data["tv_results"][0]
        t["media_type"] = "tv"
        return t
    return None

def search_movie(title, year=None):
    p = {"query": title}
    if year:
        p["year"] = year
    data = _get("/search/movie", p)
    return data.get("results", [])

def search_tv(title, year=None):
    p = {"query": title}
    if year:
        p["first_air_date_year"] = year
    data = _get("/search/tv", p)
    return data.get("results", [])

def search_multi(query):
    return _get("/search/multi", {"query": query}).get("results", [])

def movie_details(tmdb_id):
    return _get("/movie/{}".format(tmdb_id), {"append_to_response": "videos,external_ids", "include_video_language": langpref.tmdb_video_languages()})

def tv_details(tmdb_id):
    return _get("/tv/{}".format(tmdb_id), {"append_to_response": "videos,external_ids", "include_video_language": langpref.tmdb_video_languages()})

def videos(media_type, tmdb_id):
    return _get("/{}/{}/videos".format(media_type, tmdb_id), {"include_video_language": langpref.tmdb_video_languages()}).get("results", [])

def popular(media_type="movie", page=1):
    return _get("/{}/popular".format(media_type), {"page": page}).get("results", [])

def top_rated(media_type="movie", page=1):
    return _get("/{}/top_rated".format(media_type), {"page": page}).get("results", [])

def trending(media_type="all", window="week", page=1):
    return _get("/trending/{}/{}".format(media_type, window), {"page": page}).get("results", [])

def upcoming(page=1):
    return _get("/movie/upcoming", {"page": page}).get("results", [])

def now_playing(page=1):
    return _get("/movie/now_playing", {"page": page}).get("results", [])

def airing_today(page=1):
    return _get("/tv/airing_today", {"page": page}).get("results", [])

def genres(media_type="movie"):
    return _get("/genre/{}/list".format(media_type)).get("genres", [])

def discover(media_type="movie", **kwargs):
    return _get("/discover/{}".format(media_type), kwargs).get("results", [])
