import json
try:
    import xbmc
    import xbmcgui
    _HAS_KODI = True
except ImportError:
    xbmc = None
    xbmcgui = None
    _HAS_KODI = False

ADDON_ID = "inputstream.adaptive"
_FAIL_FLAG = "multitrailer.isa_failed"
_WAIT_SECONDS = 90

def _rpc(method, params):
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    except Exception:
        return {}

def status():
    if not _HAS_KODI:
        return "enabled"
    r = _rpc("Addons.GetAddonDetails", {"addonid": ADDON_ID, "properties": ["enabled"]})
    addon = (r.get("result") or {}).get("addon") or {}
    if addon.get("addonid") == ADDON_ID:
        return "enabled" if addon.get("enabled") else "disabled"
    if "error" in r:
        return "missing"
    return "enabled" if xbmc.getCondVisibility("System.HasAddon({})".format(ADDON_ID)) else "missing"

def is_ready():
    return status() == "enabled"

def _notify(msg, error=False):
    try:
        xbmcgui.Dialog().notification(
            "MultiTrailer", msg,
            xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception:
        pass

def _wait_until_ready(seconds):
    monitor = xbmc.Monitor()
    waited = 0.0
    while waited < seconds:
        if is_ready():
            return True
        if monitor.waitForAbort(0.5):
            return False
        waited += 0.5
    return is_ready()

def ensure(force=False):
    if not _HAS_KODI:
        return True
    st = status()
    if st == "enabled":
        return True
    win = xbmcgui.Window(10000)
    if not force and win.getProperty(_FAIL_FLAG) == "1":
        return False
    if st == "disabled":
        _notify("InputStream Adaptive wird aktiviert ...")
        _rpc("Addons.SetAddonEnabled", {"addonid": ADDON_ID, "enabled": True})
    else:
        _notify("InputStream Adaptive wird installiert ...")
        xbmc.executebuiltin("InstallAddon({})".format(ADDON_ID), True)
    ok = _wait_until_ready(_WAIT_SECONDS)
    if not ok and status() == "disabled":
        _rpc("Addons.SetAddonEnabled", {"addonid": ADDON_ID, "enabled": True})
        ok = _wait_until_ready(10)
    if ok:
        win.clearProperty(_FAIL_FLAG)
        _notify("InputStream Adaptive ist bereit.")
    else:
        win.setProperty(_FAIL_FLAG, "1")
        _notify("InputStream Adaptive konnte nicht installiert werden.", error=True)
    return ok
