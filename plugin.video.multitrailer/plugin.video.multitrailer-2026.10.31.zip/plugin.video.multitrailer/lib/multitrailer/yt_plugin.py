def _user_prefers_yt_addon():
    return False

def is_available():
    return False

def list_qualities(video_id, max_height=None):
    return []

def best_quality(video_id, max_height=None):
    return None
