from __future__ import annotations
import json
from . import langpref
import os
import re
import threading
from datetime import datetime, timezone
try:
    import requests
except ImportError:
    requests = None
try:
    import xml.etree.ElementTree as ET
except ImportError:
    ET = None
try:
    import xbmcvfs
    _HAS_KODI = True
except ImportError:
    _HAS_KODI = False
    xbmcvfs = None
try:
    from . import debug as _debug
except Exception:
    _debug = None
_TIMEOUT = 12
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
_INNERTUBE_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"
_INNERTUBE_CLIENT = {
    "clientName": "WEB",
    "clientVersion": "2.20260115.01.00",
    "hl": "de",
    "gl": "DE",
}
_MODULE_ADDON_ID = "plugin.video.multitrailer"
_STORE_NAME = "my_channels.json"
_SEEN_CAP = 2000
_LOCK = threading.RLock()

def _wlog(msg, level="INFO"):
    if _debug is not None:
        try:
            _debug.wlog("[my_channels] " + str(msg), level=level)
        except Exception:
            pass

def _now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def _translate(p):
    if _HAS_KODI:
        try:
            return xbmcvfs.translatePath(p)
        except Exception:
            pass
    return p

def _profile_dir():
    path = _translate("special://profile/addon_data/{}/".format(_MODULE_ADDON_ID))
    if "special:" in path:
        return path
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path

def _store_path():
    return os.path.join(_profile_dir(), _STORE_NAME)
_DEFAULT = {
    "version": 1,
    "channels": [],
    "seen_videos": [],
    "last_open": "",
}

def load():
    with _LOCK:
        path = _store_path()
        if not os.path.isfile(path):
            return dict(_DEFAULT, channels=[], seen_videos=[])
        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:
            _wlog("store read failed, returning empty default", level="WARNING")
            return dict(_DEFAULT, channels=[], seen_videos=[])
        out = dict(_DEFAULT)
        out["channels"] = list(data.get("channels") or [])
        out["seen_videos"] = list(data.get("seen_videos") or [])
        out["last_open"] = data.get("last_open") or ""
        out["version"] = int(data.get("version") or 1)
        return out

def save(data):
    with _LOCK:
        path = _store_path()
        tmp = path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
        except Exception as exc:
            _wlog("store write failed: {}".format(exc), level="ERROR")
            try:
                if os.path.isfile(tmp):
                    os.remove(tmp)
            except Exception:
                pass

def list_followed():
    data = load()
    chans = list(data.get("channels") or [])
    for c in chans:
        c.setdefault("platform", "youtube")
    chans.sort(key=lambda c: (c.get("name") or "").lower())
    return chans

def is_followed(channel_id, platform=None):
    if not channel_id:
        return False
    for c in (load().get("channels") or []):
        if c.get("channel_id") != channel_id:
            continue
        if platform and (c.get("platform", "youtube") != platform):
            continue
        return True
    return False

def follow(channel_id, name="", handle="", thumb="", platform="youtube"):
    if not channel_id:
        return False
    with _LOCK:
        data = load()
        for c in (data.get("channels") or []):
            if (c.get("channel_id") == channel_id
                    and c.get("platform", "youtube") == platform):
                if name:
                    c["name"] = name
                if handle:
                    c["handle"] = handle
                if thumb:
                    c["thumb"] = thumb
                save(data)
                return False
        data.setdefault("channels", []).append({
            "channel_id": channel_id,
            "platform": platform or "youtube",
            "name": name or channel_id,
            "handle": handle or "",
            "thumb": thumb or "",
            "added": _now_iso(),
            "last_check": "",
            "last_seen_video_id": "",
        })
        save(data)
        _wlog("followed {} ({})".format(channel_id, name))
        return True

def unfollow(channel_id, platform=None):
    if not channel_id:
        return False
    with _LOCK:
        data = load()
        before = len(data.get("channels") or [])

        def _keep(c):
            if c.get("channel_id") != channel_id:
                return True
            if platform and c.get("platform", "youtube") != platform:
                return True
            return False
        data["channels"] = [c for c in (data.get("channels") or []) if _keep(c)]
        if len(data["channels"]) == before:
            return False
        save(data)
        _wlog("unfollowed {} ({})".format(channel_id, platform or "any"))
        return True

def get_followed(channel_id, platform=None):
    for c in (load().get("channels") or []):
        if c.get("channel_id") != channel_id:
            continue
        if platform and c.get("platform", "youtube") != platform:
            continue
        out = dict(c)
        out.setdefault("platform", "youtube")
        return out
    return None

def update_channel_state(channel_id, platform=None, **fields):
    with _LOCK:
        data = load()
        changed = False
        for c in (data.get("channels") or []):
            if c.get("channel_id") != channel_id:
                continue
            if platform and c.get("platform", "youtube") != platform:
                continue
            for k, v in fields.items():
                c[k] = v
            changed = True
            break
        if changed:
            save(data)
        return changed

def is_video_seen(video_id):
    if not video_id:
        return False
    return video_id in (load().get("seen_videos") or [])

def mark_video_seen(video_ids):
    if not video_ids:
        return
    if isinstance(video_ids, str):
        video_ids = [video_ids]
    with _LOCK:
        data = load()
        seen = list(data.get("seen_videos") or [])
        seen_set = set(seen)
        added = 0
        for vid in video_ids:
            if vid and vid not in seen_set:
                seen.append(vid)
                seen_set.add(vid)
                added += 1
        if added:
            if len(seen) > _SEEN_CAP:
                seen = seen[-_SEEN_CAP:]
            data["seen_videos"] = seen
            save(data)

def touch_last_open():
    with _LOCK:
        data = load()
        data["last_open"] = _now_iso()
        save(data)

def get_last_open():
    return load().get("last_open") or ""

def _http_get(url, headers=None):
    if requests is None:
        return None
    h = {"User-Agent": _UA, "Accept-Language": langpref.accept_language()}
    if headers:
        h.update(headers)
    try:
        r = requests.get(url, headers=h, timeout=_TIMEOUT)
        if r.status_code == 200:
            return r.text
        _wlog("GET {} -> {}".format(url, r.status_code), level="WARNING")
    except Exception as exc:
        _wlog("GET {} failed: {}".format(url, exc), level="WARNING")
    return None

def _http_post_json(url, body, headers=None):
    if requests is None:
        return None
    h = {
        "User-Agent": _UA,
        "Accept-Language": langpref.accept_language(),
        "Content-Type": "application/json",
        "X-Youtube-Client-Name": "1",
        "X-Youtube-Client-Version": _INNERTUBE_CLIENT["clientVersion"],
    }
    if headers:
        h.update(headers)
    try:
        r = requests.post(url, data=json.dumps(body), headers=h, timeout=_TIMEOUT)
        if r.status_code == 200:
            return r.json()
        _wlog("POST {} -> {}".format(url, r.status_code), level="WARNING")
    except Exception as exc:
        _wlog("POST {} failed: {}".format(url, exc), level="WARNING")
    return None

def _yt_rss_uploads(channel_id):
    if not channel_id or ET is None:
        return []
    text = _http_get(
        "https://www.youtube.com/feeds/videos.xml?channel_id=" + channel_id)
    if not text:
        return []
    out = []
    try:
        root = ET.fromstring(text)
    except Exception as exc:
        _wlog("YT RSS parse failed for {}: {}".format(channel_id, exc),
              level="WARNING")
        return []
    ns = {
        "atom": "http://www.w3.org/2005/Atom",
        "yt": "http://www.youtube.com/xml/schemas/2015",
        "media": "http://search.yahoo.com/mrss/",
    }
    chan_name = ""
    author_el = root.find("atom:author/atom:name", ns)
    if author_el is not None and author_el.text:
        chan_name = author_el.text
    for entry in root.findall("atom:entry", ns):
        try:
            vid_el = entry.find("yt:videoId", ns)
            if vid_el is None or not vid_el.text:
                continue
            vid = vid_el.text.strip()
            title_el = entry.find("atom:title", ns)
            title = (title_el.text or "").strip() if title_el is not None else ""
            pub_el = entry.find("atom:published", ns)
            published = (pub_el.text or "").strip() if pub_el is not None else ""
            thumb = ""
            mt = entry.find("media:group/media:thumbnail", ns)
            if mt is not None:
                thumb = mt.get("url") or ""
            descr = ""
            md = entry.find("media:group/media:description", ns)
            if md is not None and md.text:
                descr = md.text.strip()
            out.append({
                "video_id": vid,
                "title": title,
                "channel": chan_name,
                "channel_id": channel_id,
                "platform": "youtube",
                "thumb": thumb or
                        ("https://i.ytimg.com/vi/{}/hqdefault.jpg".format(vid)),
                "published": published,
                "description": descr,
                "url": "https://www.youtube.com/watch?v=" + vid,
            })
        except Exception:
            continue
    return out

def _vimeo_rss_uploads(handle, channel_id="", channel_name=""):
    if not handle or ET is None:
        return []
    text = _http_get("https://vimeo.com/{}/videos/rss".format(
        handle.lstrip("/")))
    if not text:
        return []
    try:
        root = ET.fromstring(text)
    except Exception as exc:
        _wlog("Vimeo RSS parse failed for {}: {}".format(handle, exc),
              level="WARNING")
        return []
    ns = {"media": "http://search.yahoo.com/mrss/"}
    out = []
    channel = root.find("channel")
    if channel is None:
        return []
    feed_title = channel.findtext("title") or channel_name
    for item in channel.findall("item"):
        try:
            link = (item.findtext("link") or "").strip()
            m = re.search(r"/(\d{6,12})", link)
            if not m:
                continue
            vid = m.group(1)
            title = (item.findtext("title") or "").strip()
            published = (item.findtext("pubDate") or "").strip()
            descr = (item.findtext("description") or "").strip()
            thumb = ""
            mt = item.find("media:thumbnail", ns)
            if mt is not None:
                thumb = mt.get("url") or ""
            out.append({
                "video_id": vid,
                "title": title,
                "channel": channel_name or feed_title,
                "channel_id": channel_id or handle,
                "platform": "vimeo",
                "thumb": thumb or "https://vumbnail.com/{}.jpg".format(vid),
                "published": published,
                "description": descr,
                "url": "https://vimeo.com/" + vid,
            })
        except Exception:
            continue
    return out

def get_rss_uploads(channel_id, platform="youtube", handle="", name=""):
    platform = (platform or "youtube").lower()
    if platform == "vimeo":
        return _vimeo_rss_uploads(handle, channel_id=channel_id,
                                  channel_name=name)
    return _yt_rss_uploads(channel_id)

def _extract_initial_data(html):
    if not html:
        return None
    for pat in (
        r"var ytInitialData\s*=\s*({.*?});</script>",
        r'ytInitialData"\]\s*=\s*({.*?});\s*</script>',
        r"ytInitialData\s*=\s*({.+?});\s*(?:var\s|window\[|</script>)",
    ):
        m = re.search(pat, html, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(1))
            except Exception:
                continue
    return None

def _parse_video_renderer(vr):
    if not vr:
        return None
    vid = vr.get("videoId")
    if not vid:
        return None
    runs = (vr.get("title") or {}).get("runs") or []
    if runs:
        title = runs[0].get("text", "")
    else:
        title = (vr.get("title") or {}).get("simpleText", "")
    thumbs = (vr.get("thumbnail") or {}).get("thumbnails") or []
    thumb = thumbs[-1].get("url", "") if thumbs else ""
    dur = ((vr.get("lengthText") or {}).get("simpleText")) or ""
    pub = ((vr.get("publishedTimeText") or {}).get("simpleText")) or ""
    return {
        "video_id": vid,
        "title": title,
        "thumb": thumb or "https://i.ytimg.com/vi/{}/hqdefault.jpg".format(vid),
        "duration": dur,
        "published": pub,
        "url": "https://www.youtube.com/watch?v=" + vid,
    }

def _parse_lockup(lvm):
    if not lvm:
        return None
    vid = lvm.get("contentId")
    if not vid or len(vid) != 11:
        return None
    meta = ((lvm.get("metadata") or {}).get("lockupMetadataViewModel") or {})
    title = (meta.get("title") or {}).get("content", "")
    pub = ""
    rows = (((meta.get("metadata") or {})
             .get("contentMetadataViewModel") or {})
            .get("metadataRows") or [])
    for row in rows:
        for part in (row.get("metadataParts") or []):
            txt = (part.get("text") or {}).get("content")
            if txt and any(k in txt.lower() for k in
                           ("ago", "year", "month", "week", "day", "hour", "vor ", "jahr", "monat", "woche", "tag", "stunde", "minute")):
                pub = txt
    dur = ""
    ovs = (((lvm.get("contentImage") or {})
            .get("thumbnailViewModel") or {}).get("overlays") or [])
    for ov in ovs:
        for b in (((ov.get("thumbnailBottomOverlayViewModel") or {})
                   .get("badges") or [])):
            t = ((b.get("thumbnailBadgeViewModel") or {}).get("text") or "")
            if isinstance(t, str) and t and ":" in t:
                dur = t
                break
        if dur:
            break
    srcs = (((lvm.get("contentImage") or {})
             .get("thumbnailViewModel") or {})
            .get("image", {}).get("sources") or [])
    thumb = (srcs[-1].get("url") if srcs else
             "https://i.ytimg.com/vi/{}/hqdefault.jpg".format(vid))
    return {
        "video_id": vid,
        "title": title,
        "thumb": thumb,
        "duration": dur,
        "published": pub,
        "url": "https://www.youtube.com/watch?v=" + vid,
    }

def _parse_shorts_lockup(slvm):
    if not slvm:
        return None
    cmd = ((slvm.get("onTap") or {}).get("innertubeCommand") or {})
    vid = ((cmd.get("reelWatchEndpoint") or {}).get("videoId")
           or (cmd.get("watchEndpoint") or {}).get("videoId"))
    if not vid:
        ent = slvm.get("entityId") or ""
        m = re.search(r"shorts-shelf-item-([A-Za-z0-9_-]{11})", ent)
        vid = m.group(1) if m else None
    if not vid or len(vid) != 11:
        return None
    title_obj = (slvm.get("overlayMetadata") or {}).get("primaryText") or {}
    title = title_obj.get("content", "")
    if not title:
        title = slvm.get("accessibilityText") or ""
    srcs = (slvm.get("thumbnail") or {}).get("sources") or []
    thumb = (srcs[-1].get("url") if srcs else
             "https://i.ytimg.com/vi/{}/hqdefault.jpg".format(vid))
    return {
        "video_id": vid,
        "title": title,
        "thumb": thumb,
        "duration": "",
        "published": "",
        "url": "https://www.youtube.com/shorts/" + vid,
        "is_short": True,
    }

def _walk_grid_items(items):
    for c in (items or []):
        cir = c.get("continuationItemRenderer")
        if cir:
            tok = (((cir.get("continuationEndpoint") or {})
                    .get("continuationCommand") or {}).get("token") or "")
            if tok:
                yield ("__continuation__", tok)
            continue
        vr = (c.get("videoRenderer")
              or c.get("gridVideoRenderer")
              or ((c.get("richItemRenderer") or {})
                  .get("content", {}).get("videoRenderer")))
        if vr:
            parsed = _parse_video_renderer(vr)
            if parsed:
                yield parsed
                continue
        lvm = (c.get("lockupViewModel")
               or ((c.get("richItemRenderer") or {})
                   .get("content", {}).get("lockupViewModel")))
        if lvm:
            parsed = _parse_lockup(lvm)
            if parsed:
                yield parsed
                continue
        slvm = (c.get("shortsLockupViewModel")
                or ((c.get("richItemRenderer") or {})
                    .get("content", {}).get("shortsLockupViewModel")))
        if slvm:
            parsed = _parse_shorts_lockup(slvm)
            if parsed:
                yield parsed
                continue

def _first_page(channel_id, tab):
    suffix = "/shorts" if tab == "shorts" else "/videos"
    html = _http_get(
        "https://www.youtube.com/channel/{}{}".format(channel_id, suffix))
    if not html:
        return [], None, ""
    data = _extract_initial_data(html)
    if not data:
        return [], None, ""
    chan_name = ""
    try:
        chan_name = (((data.get("metadata") or {})
                      .get("channelMetadataRenderer") or {}).get("title") or "")
    except Exception:
        pass
    tabs = ((data.get("contents") or {})
            .get("twoColumnBrowseResultsRenderer") or {}).get("tabs") or []
    grid_items = []
    for tab_node in tabs:
        tr = tab_node.get("tabRenderer") or {}
        url = (((tr.get("endpoint") or {}).get("commandMetadata") or {})
               .get("webCommandMetadata", {}).get("url") or "")
        if not url.endswith(suffix) and not tr.get("selected"):
            continue
        content = tr.get("content") or {}
        rg = (content.get("richGridRenderer") or {}).get("contents") or []
        if rg:
            grid_items = rg
            break
        sections = (content.get("sectionListRenderer") or {}).get("contents") or []
        for sec in sections:
            isr = (sec.get("itemSectionRenderer") or {}).get("contents") or []
            for item in isr:
                gr = (item.get("gridRenderer") or {}).get("items") or []
                grid_items.extend(gr)
        if grid_items:
            break
    items = []
    next_token = ""
    for entry in _walk_grid_items(grid_items):
        if isinstance(entry, tuple) and entry[0] == "__continuation__":
            next_token = entry[1]
            continue
        items.append(entry)
    return items, (next_token or None), chan_name

def _continuation_page(token):
    if not token:
        return [], None
    body = {
        "context": {"client": dict(_INNERTUBE_CLIENT, hl=langpref.hl(), gl=langpref.gl())},
        "continuation": token,
    }
    url = ("https://www.youtube.com/youtubei/v1/browse?key=" + _INNERTUBE_KEY
           + "&prettyPrint=false")
    data = _http_post_json(url, body)
    if not data:
        return [], None
    actions = (data.get("onResponseReceivedActions")
               or data.get("onResponseReceivedEndpoints") or [])
    grid_items = []
    for act in actions:
        a = (act.get("appendContinuationItemsAction")
             or act.get("reloadContinuationItemsCommand"))
        if not a:
            continue
        grid_items.extend(a.get("continuationItems") or [])
    items = []
    next_token = None
    for entry in _walk_grid_items(grid_items):
        if isinstance(entry, tuple) and entry[0] == "__continuation__":
            next_token = entry[1]
            continue
        items.append(entry)
    return items, next_token

def get_channel_page(channel_id, tab="videos", continuation=None,
                     platform="youtube", handle="", name=""):
    platform = (platform or "youtube").lower()
    if platform == "vimeo":
        page = 1
        if continuation:
            try:
                page = max(1, int(continuation))
            except (TypeError, ValueError):
                page = 1
        return _vimeo_channel_page(channel_id, page=page, name=name,
                                   handle=handle)
    if continuation:
        items, nxt = _continuation_page(continuation)
        return {"items": items, "next_continuation": nxt, "channel_name": ""}
    items, nxt, chan_name = _first_page(channel_id, tab)
    return {"items": items, "next_continuation": nxt, "channel_name": chan_name}

def _vimeo_jwt():
    try:
        from . import sources as _src
        return _src._get_vimeo_jwt()
    except Exception:
        return None

def _vimeo_api_get(path, params=None, retry_on_401=True):
    if requests is None:
        return None
    jwt = _vimeo_jwt()
    if not jwt:
        return None

    def _do(token):
        try:
            return requests.get(
                "https://api.vimeo.com" + path,
                params=params or {},
                headers={
                    "User-Agent": _UA,
                    "Authorization": "jwt " + token,
                    "Accept": "application/vnd.vimeo.*+json;version=3.4",
                    "Accept-Language": langpref.accept_language(),
                },
                timeout=_TIMEOUT,
            )
        except Exception:
            return None
    r = _do(jwt)
    if r is not None and r.status_code == 401 and retry_on_401:
        try:
            from . import sources as _src
            jwt2 = _src._get_vimeo_jwt(force_refresh=True)
        except Exception:
            jwt2 = None
        if jwt2:
            r = _do(jwt2)
    if r is None or r.status_code != 200:
        if r is not None:
            _wlog("vimeo api {} -> {}".format(path, r.status_code),
                  level="WARNING")
        return None
    try:
        return r.json()
    except Exception:
        return None

def _largest_vimeo_pic(pictures):
    sizes = (pictures or {}).get("sizes") or []
    if not sizes:
        return ""
    best = sizes[-1]
    for s in sizes:
        if (s.get("width") or 0) > (best.get("width") or 0):
            best = s
    return best.get("link") or ""

def _parse_vimeo_video(v):
    if not v:
        return None
    uri = v.get("uri") or ""
    m = re.search(r"/videos/(\d+)", uri)
    if not m:
        return None
    vid = m.group(1)
    dur = v.get("duration") or 0
    if isinstance(dur, (int, float)) and dur > 0:
        mm, ss = divmod(int(dur), 60)
        if mm >= 60:
            hh, mm = divmod(mm, 60)
            duration_str = "{}:{:02d}:{:02d}".format(hh, mm, ss)
        else:
            duration_str = "{}:{:02d}".format(mm, ss)
    else:
        duration_str = ""
    user = v.get("user") or {}
    return {
        "video_id": vid,
        "title": v.get("name") or "",
        "thumb": _largest_vimeo_pic(v.get("pictures"))
                 or "https://vumbnail.com/{}.jpg".format(vid),
        "duration": duration_str,
        "published": (v.get("created_time") or "")[:10],
        "channel": user.get("name") or "",
        "platform": "vimeo",
        "url": "https://vimeo.com/" + vid,
    }

def _vimeo_channel_page(user_id, page=1, name="", handle=""):
    if not user_id:
        return {"items": [], "next_continuation": None, "channel_name": name}
    data = _vimeo_api_get(
        "/users/{}/videos".format(user_id),
        params={"per_page": 25, "page": page,
                "sort": "date", "direction": "desc",
                "fields": "uri,name,duration,created_time,description,"
                          "pictures.sizes,user.name"},
    )
    if not data:
        return {"items": [], "next_continuation": None, "channel_name": name}
    items = []
    for v in (data.get("data") or []):
        parsed = _parse_vimeo_video(v)
        if parsed:
            items.append(parsed)
    has_next = bool((data.get("paging") or {}).get("next"))
    next_token = str(page + 1) if has_next else None
    chan_name = name
    if items and items[0].get("channel"):
        chan_name = items[0]["channel"]
    return {"items": items, "next_continuation": next_token,
            "channel_name": chan_name}

def search_vimeo_creators(query, limit=15):
    if not query or requests is None:
        return []
    data = _vimeo_api_get("/search", params={
        "query": query.strip(),
        "filter_type": "people",
        "per_page": min(int(limit), 20),
    })
    if not data:
        return []
    out = []
    seen = set()
    for item in (data.get("data") or []):
        people = item.get("people") or {}
        uri = people.get("uri") or ""
        m = re.search(r"/users/(\d+)", uri)
        if not m:
            continue
        uid = m.group(1)
        if uid in seen:
            continue
        seen.add(uid)
        link = people.get("link") or ""
        handle = ""
        mh = re.search(r"vimeo\.com/([^/?#]+)$", link)
        if mh and not mh.group(1).isdigit():
            handle = mh.group(1)
        out.append({
            "channel_id": uid,
            "platform": "vimeo",
            "name": people.get("name") or handle or uid,
            "handle": handle,
            "thumb": _largest_vimeo_pic(people.get("pictures")),
            "description": (people.get("short_bio") or
                            people.get("bio") or "") or "",
            "meta": people.get("location") or "",
        })
        if len(out) >= limit:
            break
    return out

def _resolve_handle_to_channel_id(handle):
    if not handle:
        return None
    h = handle if handle.startswith("@") else ("@" + handle)
    html = _http_get("https://www.youtube.com/" + h)
    if not html:
        return None
    for pat in (r'"channelId":"(UC[A-Za-z0-9_-]{22})"',
                r'"externalId":"(UC[A-Za-z0-9_-]{22})"',
                r'"browseId":"(UC[A-Za-z0-9_-]{22})"'):
        m = re.search(pat, html)
        if m:
            return m.group(1)
    return None

def search_channels(query, limit=20):
    if not query:
        return []
    url = ("https://www.youtube.com/results?search_query="
           + requests.utils.quote(query) + "&sp=EgIQAg%253D%253D")
    html = _http_get(url)
    if not html:
        return []
    data = _extract_initial_data(html)
    if not data:
        return []
    out = []
    seen = set()
    try:
        sections = (((data.get("contents") or {})
                     .get("twoColumnSearchResultsRenderer") or {})
                    .get("primaryContents", {})
                    .get("sectionListRenderer", {})
                    .get("contents") or [])
        for sec in sections:
            isr = (sec.get("itemSectionRenderer") or {}).get("contents") or []
            for it in isr:
                cr = it.get("channelRenderer")
                if not cr:
                    continue
                cid = cr.get("channelId")
                if not cid or cid in seen:
                    continue
                seen.add(cid)
                title = (cr.get("title") or {}).get("simpleText", "") or ""
                sub_text = ((cr.get("videoCountText") or {}).get("simpleText") or
                            (cr.get("subscriberCountText") or {}).get("simpleText") or
                            "")
                descr = ""
                snippet = (cr.get("descriptionSnippet") or {}).get("runs") or []
                if snippet:
                    descr = "".join(r.get("text", "") for r in snippet)
                thumbs = (cr.get("thumbnail") or {}).get("thumbnails") or []
                thumb = thumbs[-1].get("url", "") if thumbs else ""
                if thumb.startswith("//"):
                    thumb = "https:" + thumb
                handle = ""
                run_url = ((cr.get("navigationEndpoint") or {})
                           .get("browseEndpoint", {})
                           .get("canonicalBaseUrl") or "")
                if run_url.startswith("/@"):
                    handle = run_url.lstrip("/")
                out.append({
                    "channel_id": cid,
                    "name": title,
                    "handle": handle,
                    "thumb": thumb,
                    "description": descr,
                    "meta": sub_text,
                })
                if len(out) >= limit:
                    return out
    except Exception as exc:
        _wlog("search_channels parse failed: {}".format(exc), level="WARNING")
    return out

def _parse_iso(s):
    if not s:
        return 0.0
    try:
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        return datetime.fromisoformat(s).timestamp()
    except Exception:
        try:
            from email.utils import parsedate_to_datetime
            return parsedate_to_datetime(s).timestamp()
        except Exception:
            return 0.0

def whats_new(limit=60):
    chans = list_followed()
    last_open = _parse_iso(get_last_open())
    out = []
    for c in chans:
        items = get_rss_uploads(
            c["channel_id"],
            platform=c.get("platform", "youtube"),
            handle=c.get("handle", ""),
            name=c.get("name", ""),
        )
        for v in items:
            v = dict(v)
            v["channel"] = v.get("channel") or c.get("name") or ""
            v["channel_id"] = c["channel_id"]
            v.setdefault("platform", c.get("platform", "youtube"))
            v["new"] = (_parse_iso(v.get("published", "")) > last_open
                        if last_open else False)
            out.append(v)
    out.sort(key=lambda v: _parse_iso(v.get("published", "")), reverse=True)
    return out[:limit]

def export_to(dest_path):
    try:
        data = load()
        with open(dest_path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
        _wlog("exported follow list to " + dest_path)
        return True
    except Exception as exc:
        _wlog("export failed: {}".format(exc), level="ERROR")
        return False

def import_from(src_path, replace=False):
    try:
        with open(src_path, "r", encoding="utf-8") as fh:
            incoming = json.load(fh)
    except Exception as exc:
        _wlog("import open failed: {}".format(exc), level="ERROR")
        return 0
    src_channels = list(incoming.get("channels") or [])
    if not src_channels:
        return 0
    with _LOCK:
        data = load()
        if replace:
            data["channels"] = []
        existing = {(c.get("platform") or "youtube", c.get("channel_id")): c
                    for c in (data.get("channels") or [])}
        added = 0
        for c in src_channels:
            cid = c.get("channel_id")
            if not cid:
                continue
            platform = c.get("platform") or "youtube"
            key = (platform, cid)
            if key in existing:
                ex = existing[key]
                if c.get("name"):
                    ex["name"] = c["name"]
                if c.get("handle"):
                    ex["handle"] = c["handle"]
                if c.get("thumb"):
                    ex["thumb"] = c["thumb"]
            else:
                data.setdefault("channels", []).append({
                    "channel_id": cid,
                    "platform": platform,
                    "name": c.get("name") or cid,
                    "handle": c.get("handle") or "",
                    "thumb": c.get("thumb") or "",
                    "added": _now_iso(),
                    "last_check": "",
                    "last_seen_video_id": c.get("last_seen_video_id") or "",
                })
                existing[key] = data["channels"][-1]
                added += 1
        save(data)
    _wlog("imported {} new channels from {}".format(added, src_path))
    return added
