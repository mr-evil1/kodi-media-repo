import os
import sys
_HERE = os.path.dirname(os.path.abspath(__file__))
_LIB = os.path.dirname(_HERE)
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)
try:
    from multitrailer import debug as _debug
    _debug.download_debug_bundle(show_ui=True)
except Exception:
    try:
        import traceback
        import xbmcgui
        xbmcgui.Dialog().ok("MultiTrailer - Debug Error",
                            traceback.format_exc())
    except Exception:
        pass
