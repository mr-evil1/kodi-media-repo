from __future__ import annotations
import threading
try:
    import xbmc
    import xbmcgui
    _HAS_KODI = True
except ImportError:
    _HAS_KODI = False
    xbmc = xbmcgui = None
from . import my_channels
try:
    from . import debug as _debug
except Exception:
    _debug = None
_PLUGIN_ADDON_ID = "plugin.video.multitrailer"

def _wlog(msg, level="INFO"):
    if _debug is not None:
        try:
            _debug.wlog("[notifier] " + str(msg), level=level)
        except Exception:
            pass

def _settings_addon():
    if not _HAS_KODI:
        return None
    try:
        import xbmcaddon
        return xbmcaddon.Addon(_PLUGIN_ADDON_ID)
    except Exception:
        return None

def notifications_enabled():
    a = _settings_addon()
    if a is None:
        return True
    try:
        v = a.getSetting("mc_notify") or "true"
        return v == "true"
    except Exception:
        return True

def poll_interval_seconds():
    a = _settings_addon()
    default = 1800
    if a is None:
        return default
    try:
        raw = (a.getSetting("mc_poll_interval") or "1800").strip()
        return max(300, int(raw))
    except Exception:
        return default

def _toast(title, message, time_ms=6000):
    if not _HAS_KODI:
        return
    try:
        xbmcgui.Dialog().notification(
            title or "MultiTrailer",
            message or "",
            xbmcgui.NOTIFICATION_INFO,
            int(time_ms),
            sound=False,
        )
    except Exception:
        pass

def _seed_seen_silently():
    chans = my_channels.list_followed()
    seeded = 0
    for c in chans:
        cid = c.get("channel_id")
        if not cid or c.get("last_check"):
            continue
        try:
            items = my_channels.get_rss_uploads(
                cid,
                platform=c.get("platform", "youtube"),
                handle=c.get("handle", ""),
                name=c.get("name", ""),
            )
        except Exception:
            items = []
        if items:
            ids = [v["video_id"] for v in items if v.get("video_id")]
            my_channels.mark_video_seen(ids)
            my_channels.update_channel_state(
                cid,
                platform=c.get("platform"),
                last_check=my_channels._now_iso(),
                last_seen_video_id=ids[0] if ids else "",
            )
            seeded += len(ids)
    if seeded:
        _wlog("seeded {} videos as already-seen on first run".format(seeded))

def run_once(silent=False):
    chans = my_channels.list_followed()
    if not chans:
        return 0
    notified = 0
    notify = (not silent) and notifications_enabled()
    for c in chans:
        cid = c.get("channel_id")
        if not cid:
            continue
        try:
            items = my_channels.get_rss_uploads(
                cid,
                platform=c.get("platform", "youtube"),
                handle=c.get("handle", ""),
                name=c.get("name", ""),
            )
        except Exception as exc:
            _wlog("RSS fetch failed for {}: {}".format(cid, exc), level="WARNING")
            continue
        if not items:
            my_channels.update_channel_state(
                cid,
                platform=c.get("platform"),
                last_check=my_channels._now_iso())
            continue
        first_check = not c.get("last_check")
        new_ids = []
        for v in items:
            vid = v.get("video_id")
            if not vid:
                continue
            if my_channels.is_video_seen(vid):
                continue
            new_ids.append(v)
        my_channels.mark_video_seen([v["video_id"] for v in items])
        my_channels.update_channel_state(
            cid,
            platform=c.get("platform"),
            last_check=my_channels._now_iso(),
            last_seen_video_id=items[0]["video_id"] if items else "",
        )
        if first_check or not new_ids:
            continue
        if notify:
            for v in new_ids[:3]:
                _toast(c.get("name") or "New upload",
                       v.get("title") or "")
                notified += 1
    if notified:
        _wlog("notified user about {} new videos".format(notified))
    return notified

def run_loop(stop_event):
    if not _HAS_KODI:
        return
    try:
        if stop_event.wait(45):
            return
        try:
            _seed_seen_silently()
        except Exception as exc:
            _wlog("seed crashed: {}".format(exc), level="ERROR")
        while not stop_event.is_set():
            try:
                run_once()
            except Exception as exc:
                _wlog("run_once crashed: {}".format(exc), level="ERROR")
            interval = poll_interval_seconds()
            slept = 0
            while slept < interval and not stop_event.is_set():
                if stop_event.wait(1):
                    return
                slept += 1
    except Exception as exc:
        _wlog("run_loop fatal: {}".format(exc), level="ERROR")

def start_thread(stop_event=None):
    if stop_event is None:
        stop_event = threading.Event()
    t = threading.Thread(target=run_loop, args=(stop_event,),
                         name="multitrailer-mc-notifier", daemon=True)
    t.start()
    return t, stop_event
