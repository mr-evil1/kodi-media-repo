import base64
import json
import os
import time
try:
    import requests
except ImportError:
    requests = None
try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
    _HAS_KODI = True
except ImportError:
    _HAS_KODI = False
    xbmc = xbmcaddon = xbmcgui = xbmcvfs = None
PLUGIN_ID = "plugin.video.multitrailer"
SCRIPT_ID = "plugin.video.multitrailer"
DEVICE_AUTH_URL = "https://oauth2.googleapis.com/device/code"
TOKEN_URL = "https://oauth2.googleapis.com/token"
REVOKE_URL = "https://oauth2.googleapis.com/revoke"
API_BASE = "https://www.googleapis.com/youtube/v3"
SCOPE = "https://www.googleapis.com/auth/youtube"
_TIMEOUT = 15
_UA = ("Mozilla/5.0 (MultiTrailer) Kodi/AddOn")

def _log(msg, level=None):
    if not _HAS_KODI:
        return
    try:
        xbmc.log("[multitrailer.yt_account] " + str(msg),
                 level if level is not None else xbmc.LOGINFO)
    except Exception:
        pass

def _profile_dir():
    if not _HAS_KODI:
        d = os.path.join(os.path.expanduser("~"),
                         ".multitrailer_yt_account")
        if not os.path.isdir(d):
            try:
                os.makedirs(d)
            except OSError:
                pass
        return d
    p = xbmcvfs.translatePath(
        "special://profile/addon_data/{}/".format(SCRIPT_ID))
    try:
        if not os.path.isdir(p):
            os.makedirs(p)
    except OSError:
        pass
    return p

def _state_path():
    return os.path.join(_profile_dir(), "yt_account.json")

def _load_state():
    try:
        with open(_state_path(), "r", encoding="utf-8") as fh:
            return json.load(fh) or {}
    except (OSError, ValueError):
        return {}

def _save_state(state):
    try:
        with open(_state_path(), "w", encoding="utf-8") as fh:
            json.dump(state, fh)
    except OSError as exc:
        _log("save_state failed: {}".format(exc), xbmc.LOGWARNING if _HAS_KODI else None)

def clear_state():
    try:
        os.remove(_state_path())
    except OSError:
        pass

def _addon_setting(key, default=""):
    if not _HAS_KODI:
        return default
    try:
        v = xbmcaddon.Addon(PLUGIN_ID).getSetting(key)
        return v if v not in (None, "") else default
    except Exception:
        return default
_OAUTH_OBF_XOR = b"multitrailer-yt-oauth-2026"
_BUILTIN_CID_OBF = "Rl9bW0RGUV1UXUUVVBhOBhEaRV5bQgNWDhEDHhocABVaHg0RXE8ZFVkNEARYA1NAQkVZDgQGEx4EHB8AAE4WGlkKDwFaC0Jf"
_BUILTIN_SEC_OBF = "MCYoOiQqTDk8NkZeOh1gLi8ZIRxZQmF2WVpfICATNywHIhQ="

def _decode_obf(blob):
    if not blob:
        return ""
    try:
        raw = base64.b64decode(blob)
        return bytes(b ^ _OAUTH_OBF_XOR[i % len(_OAUTH_OBF_XOR)]
                     for i, b in enumerate(raw)).decode("utf-8")
    except Exception:
        return ""

def _builtin_client_id():
    return _decode_obf(_BUILTIN_CID_OBF)

def _builtin_client_secret():
    return _decode_obf(_BUILTIN_SEC_OBF)

def get_client_id():
    user = (_addon_setting("yt_client_id") or "").strip()
    return user or _builtin_client_id()

def get_client_secret():
    user = (_addon_setting("yt_client_secret") or "").strip()
    return user or _builtin_client_secret()

def has_credentials():
    return bool(get_client_id() and get_client_secret())

def using_builtin_credentials():
    user_cid = (_addon_setting("yt_client_id") or "").strip()
    user_sec = (_addon_setting("yt_client_secret") or "").strip()
    return not (user_cid and user_sec)

def is_signed_in():
    s = _load_state()
    return bool(s.get("refresh_token"))

def signed_in_as():
    s = _load_state()
    return s.get("channel_title") or s.get("channel_id") or ""

def _post(url, data, headers=None, timeout=_TIMEOUT):
    if requests is None:
        return None
    h = {"User-Agent": _UA, "Accept": "application/json"}
    if headers:
        h.update(headers)
    try:
        r = requests.post(url, data=data, headers=h, timeout=timeout)
        return r
    except Exception as exc:
        _log("POST {} failed: {}".format(url, exc),
             xbmc.LOGWARNING if _HAS_KODI else None)
        return None

def _start_device_flow():
    cid = get_client_id()
    if not cid:
        return None, "Missing Client ID. Configure it in Settings -> YouTube Account."
    r = _post(DEVICE_AUTH_URL,
              data={"client_id": cid, "scope": SCOPE})
    if r is None:
        return None, "Network error contacting Google."
    if r.status_code != 200:
        try:
            err = r.json().get("error_description") or r.json().get("error") or r.text
        except Exception:
            err = r.text
        return None, "Google rejected device-code request: {}".format(err)
    return r.json(), None

def _poll_token(device_code, interval, expires_in):
    cid = get_client_id()
    cs = get_client_secret()
    deadline = time.time() + max(60, int(expires_in or 600))
    sleep = max(2, int(interval or 5))
    consecutive_net_errors = 0
    max_consecutive_net_errors = 5
    while time.time() < deadline:
        if _HAS_KODI:
            try:
                if xbmc.Monitor().waitForAbort(sleep):
                    return None, "Cancelled."
            except Exception:
                time.sleep(sleep)
        else:
            time.sleep(sleep)
        r = _post(TOKEN_URL, data={
            "client_id": cid,
            "client_secret": cs,
            "device_code": device_code,
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
        })
        if r is None:
            consecutive_net_errors += 1
            if consecutive_net_errors >= max_consecutive_net_errors:
                return None, ("Network unreachable - cannot contact "
                              "oauth2.googleapis.com.  Please check your "
                              "internet connection and try again.")
            continue
        consecutive_net_errors = 0
        try:
            body = r.json()
        except Exception:
            continue
        if r.status_code == 200 and body.get("access_token"):
            return body, None
        err = (body.get("error") or "").lower()
        if err == "authorization_pending":
            continue
        if err == "slow_down":
            sleep = min(sleep + 2, 30)
            continue
        if err in ("access_denied", "expired_token"):
            return None, body.get("error_description") or err
        _log("token poll error: {}".format(body))
    return None, "Timed out waiting for user authorization."

def _fetch_my_channel(access_token):
    if requests is None:
        return None
    try:
        r = requests.get(API_BASE + "/channels",
                         params={"part": "snippet", "mine": "true"},
                         headers={"Authorization": "Bearer " + access_token,
                                  "User-Agent": _UA},
                         timeout=_TIMEOUT)
        if r.status_code != 200:
            return None
        items = r.json().get("items") or []
        if not items:
            return None
        sn = items[0].get("snippet") or {}
        return {"channel_id": items[0].get("id"),
                "channel_title": sn.get("title", "")}
    except Exception:
        return None

def sign_in_interactive():
    if not _HAS_KODI:
        return False
    if requests is None:
        xbmcgui.Dialog().ok("MultiTrailer",
                            "Python 'requests' module unavailable.")
        return False
    if not has_credentials():
        xbmcgui.Dialog().ok(
            "MultiTrailer - YouTube Account",
            "Please set your Google OAuth Client ID and Client Secret first.\n"
            "Settings -> YouTube Account.")
        return False
    info, err = _start_device_flow()
    if not info:
        xbmcgui.Dialog().ok("MultiTrailer - Sign-In Failed", err or "")
        return False
    user_code = info.get("user_code") or ""
    verify_url = (info.get("verification_url")
                  or info.get("verification_uri")
                  or "https://www.google.com/device")
    device_code = info.get("device_code")
    interval = info.get("interval") or 5
    expires_in = info.get("expires_in") or 1800
    xbmcgui.Dialog().ok(
        "MultiTrailer - Sign in to YouTube",
        "1. On a phone or laptop, open:\n[B]{}[/B]\n\n"
        "2. Enter this code:\n[B][COLOR yellow]{}[/COLOR][/B]\n\n"
        "3. Approve access for your YouTube account.\n\n"
        "Press OK below to start waiting for approval "
        "(this dialog will close once you approve, up to {} minutes).".format(
            verify_url, user_code, max(1, int(expires_in / 60))))
    pd = xbmcgui.DialogProgressBG()
    try:
        pd.create("MultiTrailer", "Waiting for YouTube authorization...")
    except Exception:
        pd = None
    try:
        token, err = _poll_token(device_code, interval, expires_in)
    finally:
        if pd:
            try:
                pd.close()
            except Exception:
                pass
    if not token:
        xbmcgui.Dialog().ok("MultiTrailer - Sign-In Failed",
                            err or "Unknown error.")
        return False
    state = {
        "access_token": token.get("access_token"),
        "refresh_token": token.get("refresh_token"),
        "expires_at": int(time.time()) + int(token.get("expires_in") or 3600) - 60,
        "scope": token.get("scope") or SCOPE,
    }
    chan = _fetch_my_channel(state["access_token"])
    if chan:
        state.update(chan)
    _save_state(state)
    xbmcgui.Dialog().notification(
        "MultiTrailer",
        "Signed in as {}".format(state.get("channel_title") or "your account"),
        xbmcgui.NOTIFICATION_INFO, 4000)
    return True

def sign_out():
    state = _load_state()
    rt = state.get("refresh_token") or state.get("access_token")
    if rt and requests is not None:
        try:
            requests.post(REVOKE_URL, data={"token": rt},
                          headers={"User-Agent": _UA}, timeout=_TIMEOUT)
        except Exception:
            pass
    clear_state()
    if _HAS_KODI:
        try:
            xbmcgui.Dialog().notification(
                "MultiTrailer", "Signed out of YouTube.",
                xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception:
            pass

def _refresh(state):
    cid = get_client_id()
    cs = get_client_secret()
    rt = state.get("refresh_token")
    if not (cid and cs and rt and requests is not None):
        return None
    r = _post(TOKEN_URL, data={
        "client_id": cid,
        "client_secret": cs,
        "refresh_token": rt,
        "grant_type": "refresh_token",
    })
    if r is None or r.status_code != 200:
        return None
    body = r.json() or {}
    if not body.get("access_token"):
        return None
    state["access_token"] = body["access_token"]
    state["expires_at"] = int(time.time()) + int(body.get("expires_in") or 3600) - 60
    _save_state(state)
    return state

def _access_token():
    state = _load_state()
    if not state.get("refresh_token"):
        return None
    if state.get("access_token") and state.get("expires_at", 0) > int(time.time()):
        return state["access_token"]
    state = _refresh(state) or {}
    return state.get("access_token")

def _auth_headers():
    tok = _access_token()
    if not tok:
        return None
    return {"Authorization": "Bearer " + tok, "User-Agent": _UA,
            "Accept": "application/json"}

def _api_get(path, params=None):
    if requests is None:
        return None
    h = _auth_headers()
    if not h:
        return None
    try:
        r = requests.get(API_BASE + path, params=params or {},
                         headers=h, timeout=_TIMEOUT)
    except Exception as exc:
        _log("GET {} failed: {}".format(path, exc),
             xbmc.LOGWARNING if _HAS_KODI else None)
        return None
    if r.status_code == 401:
        st = _refresh(_load_state())
        if not st:
            return None
        h = _auth_headers()
        try:
            r = requests.get(API_BASE + path, params=params or {},
                             headers=h, timeout=_TIMEOUT)
        except Exception:
            return None
    if r.status_code != 200:
        _log("GET {} -> {}: {}".format(path, r.status_code, r.text[:200]),
             xbmc.LOGWARNING if _HAS_KODI else None)
        return None
    try:
        return r.json()
    except Exception:
        return None

def _api_post(path, params=None, body=None):
    if requests is None:
        return None
    h = _auth_headers()
    if not h:
        return None
    h2 = dict(h)
    h2["Content-Type"] = "application/json"
    try:
        r = requests.post(API_BASE + path, params=params or {},
                          data=json.dumps(body or {}),
                          headers=h2, timeout=_TIMEOUT)
    except Exception:
        return None
    if r.status_code in (200, 201, 204):
        try:
            return r.json() if r.text else {}
        except Exception:
            return {}
    _log("POST {} -> {}: {}".format(path, r.status_code, r.text[:200]),
         xbmc.LOGWARNING if _HAS_KODI else None)
    return None

def _api_delete(path, params=None):
    if requests is None:
        return False
    h = _auth_headers()
    if not h:
        return False
    try:
        r = requests.delete(API_BASE + path, params=params or {},
                            headers=h, timeout=_TIMEOUT)
    except Exception:
        return False
    return r.status_code in (200, 204)

def _format_video_items(playlist_items):
    out = []
    for it in playlist_items or []:
        sn = it.get("snippet") or {}
        cd = it.get("contentDetails") or {}
        vid = cd.get("videoId") or (sn.get("resourceId") or {}).get("videoId")
        if not vid:
            continue
        thumbs = sn.get("thumbnails") or {}
        thumb = (
            (thumbs.get("maxres") or thumbs.get("high")
             or thumbs.get("medium") or thumbs.get("default")
             or {}).get("url", "")
            or "https://i.ytimg.com/vi/{}/hqdefault.jpg".format(vid)
        )
        out.append({
            "video_id": vid,
            "title": sn.get("title", ""),
            "description": sn.get("description", ""),
            "channel": sn.get("videoOwnerChannelTitle") or sn.get("channelTitle", ""),
            "channel_id": sn.get("videoOwnerChannelId") or "",
            "published": sn.get("publishedAt", ""),
            "thumb": thumb,
            "url": "https://www.youtube.com/watch?v=" + vid,
        })
    return out

def get_liked_videos(page_token=None, max_results=25):
    params = {"part": "snippet,contentDetails",
              "playlistId": "LL",
              "maxResults": int(max_results)}
    if page_token:
        params["pageToken"] = page_token
    data = _api_get("/playlistItems", params=params)
    if not data:
        return {"items": [], "next_page_token": None}
    return {"items": _format_video_items(data.get("items")),
            "next_page_token": data.get("nextPageToken")}

def get_my_subscriptions(page_token=None, max_results=50):
    params = {"part": "snippet,contentDetails",
              "mine": "true", "order": "alphabetical",
              "maxResults": int(max_results)}
    if page_token:
        params["pageToken"] = page_token
    data = _api_get("/subscriptions", params=params)
    if not data:
        return {"items": [], "next_page_token": None}
    out = []
    for it in data.get("items") or []:
        sn = it.get("snippet") or {}
        rid = (sn.get("resourceId") or {})
        chan_id = rid.get("channelId") or ""
        thumbs = sn.get("thumbnails") or {}
        thumb = (thumbs.get("high") or thumbs.get("medium")
                 or thumbs.get("default") or {}).get("url", "")
        out.append({
            "subscription_id": it.get("id"),
            "channel_id": chan_id,
            "title": sn.get("title", ""),
            "description": sn.get("description", ""),
            "thumb": thumb,
            "published": sn.get("publishedAt", ""),
        })
    return {"items": out, "next_page_token": data.get("nextPageToken")}

def get_channel_uploads(channel_id, page_token=None, max_results=25):
    chan = _api_get("/channels", params={"part": "contentDetails",
                                         "id": channel_id})
    if not chan or not chan.get("items"):
        return {"items": [], "next_page_token": None}
    uploads = (
        (chan["items"][0].get("contentDetails") or {})
        .get("relatedPlaylists", {})
        .get("uploads")
    )
    if not uploads:
        return {"items": [], "next_page_token": None}
    params = {"part": "snippet,contentDetails",
              "playlistId": uploads,
              "maxResults": int(max_results)}
    if page_token:
        params["pageToken"] = page_token
    data = _api_get("/playlistItems", params=params)
    if not data:
        return {"items": [], "next_page_token": None}
    return {"items": _format_video_items(data.get("items")),
            "next_page_token": data.get("nextPageToken")}

def search_channels(query, max_results=25):
    if not query:
        return []
    data = _api_get("/search", params={
        "part": "snippet", "type": "channel",
        "q": query, "maxResults": int(max_results),
    })
    if not data:
        return []
    out = []
    for it in data.get("items") or []:
        sn = it.get("snippet") or {}
        rid = (it.get("id") or {}).get("channelId") or ""
        thumbs = sn.get("thumbnails") or {}
        thumb = (thumbs.get("high") or thumbs.get("medium")
                 or thumbs.get("default") or {}).get("url", "")
        out.append({
            "channel_id": rid,
            "title": sn.get("title", ""),
            "description": sn.get("description", ""),
            "thumb": thumb,
        })
    return out

def find_subscription_id(channel_id):
    data = _api_get("/subscriptions", params={
        "part": "id", "mine": "true",
        "forChannelId": channel_id, "maxResults": 1,
    })
    if not data:
        return None
    items = data.get("items") or []
    if not items:
        return None
    return items[0].get("id")

def subscribe(channel_id):
    if not channel_id:
        return False
    res = _api_post("/subscriptions", params={"part": "snippet"}, body={
        "snippet": {"resourceId": {"kind": "youtube#channel",
                                   "channelId": channel_id}},
    })
    return bool(res)

def unsubscribe(channel_id=None, subscription_id=None):
    sid = subscription_id
    if not sid and channel_id:
        sid = find_subscription_id(channel_id)
    if not sid:
        return False
    return _api_delete("/subscriptions", params={"id": sid})
