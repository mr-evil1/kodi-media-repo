import re
import json
import datetime
from html import unescape
from urllib.parse import unquote
try:
    import requests
except ImportError:
    requests = None
from . import tmdb, filters, langpref, debug
_TIMEOUT = 12
LAST_ERRORS = {}

def _source_error(provider, reason):
    LAST_ERRORS[provider] = str(reason)
    try:
        from . import debug
        debug.wlog('{} discovery: {}'.format(provider, reason), level='WARNING')
    except Exception:
        pass
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
_NOISE_WORDS = {
    "the", "a", "an", "of", "and", "or", "in", "on", "at", "to",
    "for", "with", "is", "it", "this", "that", "season", "series",
    "official", "trailer", "teaser", "show", "tv", "part",
    "deutsch", "german", "offizieller", "offizielle", "der", "die", "das", "und", "ein", "eine",
    "movie", "film", "video", "uk", "us",
}
_FAN_NOISE_TITLE_WORDS = {
    "reaction", "reacts", "review", "reviews", "explained",
    "ranking", "ranked", "recap", "breakdown", "every", "ending",
    "theory", "predictions", "tier", "compilation", "edit",
    "tribute", "fan", "made", "concept", "what", "if", "honest",
    "parody", "spoof",
}

def _significant_words(text):
    if not text:
        return set()
    raw = re.findall(r"[A-Za-z0-9]+", text.lower())
    return {w for w in raw if len(w) >= 3 and w not in _NOISE_WORDS}

def _slug_words(slug):
    return _significant_words((slug or "").replace("-", " "))

def _title_match_ratio(candidate, query_title):
    q = _significant_words(query_title)
    if not q:
        return 1.0
    c = _significant_words(candidate)
    if not c:
        return 0.0
    return len(q & c) / float(len(q))

def _is_query_relevant(candidate, query_title, threshold=0.5):
    return _title_match_ratio(candidate, query_title) >= threshold

def _http(url, headers=None, params=None):
    if requests is None:
        return None
    h = {"User-Agent": _UA, "Accept-Language": langpref.accept_language()}
    if headers:
        h.update(headers)
    try:
        r = requests.get(url, headers=h, params=params, timeout=_TIMEOUT)
        debug.vlog("http {} {} -> {} ({} Bytes)".format(url, params or "", r.status_code, len(r.content)))
        if r.status_code == 200:
            return r.text
    except Exception as exc:
        debug.vlog("http {} Fehler: {}".format(url, exc), "WARNING")
    return None

def from_tmdb(media_type, tmdb_id):
    out = []
    for v in tmdb.videos(media_type, tmdb_id):
        site = (v.get("site") or "").lower()
        key = v.get("key")
        if not key:
            continue
        if site == "youtube":
            out.append({
                "source": "tmdb", "provider": "youtube", "id": key,
                "url": "https://www.youtube.com/watch?v=" + key,
                "title": v.get("name") or "", "type": v.get("type") or "Trailer",
                "official": bool(v.get("official")), "size": v.get("size") or 0,
                "channel": "", "published": v.get("published_at") or "",
                "language": v.get("iso_639_1") or "",
            })
        elif site == "vimeo":
            out.append({
                "source": "tmdb", "provider": "vimeo", "id": key,
                "url": "https://vimeo.com/" + key,
                "title": v.get("name") or "", "type": v.get("type") or "Trailer",
                "official": bool(v.get("official")), "size": v.get("size") or 0,
                "channel": "", "published": v.get("published_at") or "",
                "language": v.get("iso_639_1") or "",
            })
    return out
_IMDB_VIDEO_RE = re.compile(r'"id":"(vi\d+)"')

def from_imdb(imdb_id):
    if not imdb_id:
        return []
    raw = _http("https://v2.sg.media-imdb.com/suggestion/t/{}.json".format(imdb_id),
                params={"includeVideos": "1"})
    if raw:
        try:
            results = json.loads(raw).get("d") or []
            videos = next((item.get("v") or [] for item in results if item.get("id") == imdb_id), [])
            items = []
            for video in videos:
                video_id = video.get("id") or ""
                if re.fullmatch(r"vi\d+", video_id):
                    items.append({"source":"imdb", "provider":"imdb", "id":video_id,
                                  "url":"https://www.imdb.com/video/{}/".format(video_id),
                                  "title":video.get("l") or "IMDb Trailer", "type":"Trailer", "language":"en",
                                  "official":True, "size":0, "channel":"imdb", "published":""})
            if items:
                return items[:5]
        except (ValueError, TypeError):
            pass
    html = _http("https://www.imdb.com/title/{}/videogallery/content_type-trailer/".format(imdb_id))
    if not html:
        return []
    out = []
    seen = set()
    for vid in _IMDB_VIDEO_RE.findall(html):
        if vid in seen:
            continue
        seen.add(vid)
        out.append({
            "source": "imdb", "provider": "imdb", "id": vid,
            "url": "https://www.imdb.com/video/{}/".format(vid),
            "title": "IMDB Trailer", "type": "Trailer", "language": "en",
            "official": True, "size": 0, "channel": "imdb", "published": "",
        })
        if len(out) >= 5:
            break
    return out

def from_youtube_search(query, suffix=None, query_title=None,
                        require_match=True):
    if suffix is None:
        suffix = langpref.search_suffix()
    if not query:
        return []
    base_title = (query_title or query).strip()
    html = _http("https://www.youtube.com/results", params={"search_query": query + (suffix or ""), "hl": langpref.hl(), "gl": langpref.gl()})
    if not html:
        return []
    out = []
    seen = set()
    m = re.search(r"var ytInitialData\s*=\s*({.*?});</script>", html, re.DOTALL)
    if not m:
        m = re.search(r'ytInitialData"\]\s*=\s*({.*?});\s*</script>', html, re.DOTALL)
    if not m:
        m = re.search(r'ytInitialData\s*=\s*({.+?});\s*(?:var\s|window\[|</script>)', html, re.DOTALL)
    if m:
        try:
            data = json.loads(m.group(1))
            contents = (data.get("contents", {})
                        .get("twoColumnSearchResultsRenderer", {})
                        .get("primaryContents", {})
                        .get("sectionListRenderer", {})
                        .get("contents", []))
            for section in contents:
                items = section.get("itemSectionRenderer", {}).get("contents", [])
                for it in items:
                    vr = it.get("videoRenderer")
                    if not vr:
                        continue
                    vid = vr.get("videoId")
                    if not vid or vid in seen:
                        continue
                    seen.add(vid)
                    title_runs = vr.get("title", {}).get("runs", [{}])
                    title = title_runs[0].get("text", "") if title_runs else ""
                    chan = ""
                    long_byline = vr.get("longBylineText", {}).get("runs", [{}])
                    if long_byline:
                        chan = long_byline[0].get("text", "")
                    title_words = set(re.findall(r"[a-z]+", (title or "").lower()))
                    if title_words & _FAN_NOISE_TITLE_WORDS:
                        continue
                    if require_match and base_title and not _is_query_relevant(title, base_title):
                        continue
                    out.append({
                        "source": "youtube_search", "provider": "youtube", "id": vid,
                        "url": "https://www.youtube.com/watch?v=" + vid,
                        "title": title, "type": "Trailer",
                        "official": filters.is_official(title, chan),
                        "size": 0, "channel": chan, "published": "",
                    })
                    if len(out) >= 8:
                        return out
        except Exception:
            pass
    if not out and not require_match:
        for vid in re.findall(r'"videoId":"([a-zA-Z0-9_-]{11})"', html)[:8]:
            if vid in seen:
                continue
            seen.add(vid)
            out.append({
                "source": "youtube_search", "provider": "youtube", "id": vid,
                "url": "https://www.youtube.com/watch?v=" + vid,
                "title": "", "type": "Trailer", "official": False,
                "size": 0, "channel": "", "published": "",
            })
    return out
_VIMEO_JWT_CACHE = {"jwt": None}

def _get_vimeo_jwt(force_refresh=False):
    if requests is None:
        return None
    if not force_refresh and _VIMEO_JWT_CACHE.get("jwt"):
        return _VIMEO_JWT_CACHE["jwt"]
    try:
        r = requests.get(
            "https://vimeo.com/_rv/viewer",
            headers={"User-Agent": _UA,
                     "Accept": "application/json",
                     "Accept-Language": langpref.accept_language()},
            timeout=_TIMEOUT,
        )
        if r.status_code != 200:
            return None
        jwt = (r.json() or {}).get("jwt")
        if jwt:
            _VIMEO_JWT_CACHE["jwt"] = jwt
            return jwt
    except Exception:
        return None
    return None

def from_vimeo_search(query, suffix=None):
    if suffix is None:
        suffix = langpref.search_suffix()
    if not query or requests is None:
        return []
    full = (query + (suffix or "")).strip()

    def _do_search(jwt):
        try:
            return requests.get(
                "https://api.vimeo.com/search",
                params={
                    "query": full,
                    "filter_type": "clip",
                    "per_page": 8,
                },
                headers={
                    "User-Agent": _UA,
                    "Authorization": "jwt " + jwt,
                    "Accept": "application/vnd.vimeo.*+json;version=3.4",
                    "Accept-Language": langpref.accept_language(),
                },
                timeout=_TIMEOUT,
            )
        except Exception:
            return None
    jwt = _get_vimeo_jwt()
    if not jwt:
        return []
    r = _do_search(jwt)
    if r is not None and r.status_code == 401:
        jwt = _get_vimeo_jwt(force_refresh=True)
        if jwt:
            r = _do_search(jwt)
    if r is None or r.status_code != 200:
        reason = 'Request failed' if r is None else 'HTTP {}'.format(r.status_code)
        if r is not None:
            try:
                reason = r.json().get('developer_message') or r.json().get('error') or reason
            except ValueError:
                pass
        _source_error('vimeo', reason)
        return []
    out = []
    seen = set()
    try:
        data = r.json() or {}
    except Exception:
        return []
    for entry in (data.get("data") or []):
        clip = entry.get("clip") or entry.get("video") or entry
        uri = clip.get("uri") or ""
        m = re.search(r"/videos/(\d+)", uri)
        if not m:
            continue
        vid = m.group(1)
        if vid in seen:
            continue
        seen.add(vid)
        thumb = ""
        for size in ((clip.get("pictures") or {}).get("sizes") or []):
            link = size.get("link")
            if link:
                thumb = link
        owner = clip.get("user") or {}
        out.append({
            "source": "vimeo",
            "provider": "vimeo",
            "id": vid,
            "url": "https://vimeo.com/" + vid,
            "title": clip.get("name") or "",
            "type": "Trailer",
            "official": False,
            "size": 0,
            "channel": owner.get("name") or "",
            "published": clip.get("created_time") or "",
            "thumb": thumb or "https://vumbnail.com/{}.jpg".format(vid),
        })
        if len(out) >= 5:
            break
    return out
_TIKTOK_URL_RE = re.compile(r'https?://(?:www\.)?tiktok\.com/@[^/]+/video/(\d+)')

def _get_setting(sid, default=""):
    try:
        import xbmcaddon
        return xbmcaddon.Addon("plugin.video.multitrailer").getSetting(sid) or default
    except Exception:
        return default

def _from_tiktok_official_api(query, suffix=None):
    if suffix is None:
        suffix = langpref.search_suffix()
    token = _get_setting("tiktok_api_key", "").strip()
    if not token:
        return []
    try:
        r = requests.post(
            "https://open.tiktokapis.com/v2/research/video/query/",
            headers={
                "Authorization": "Bearer " + token,
                "Content-Type": "application/json",
            },
            params={"fields": "id,username,video_description,create_time"},
            json={
                "query": {
                    "and": [{
                        "operation": "EQ",
                        "field_name": "keyword",
                        "field_values": [
                            (query + (suffix or "")).strip(),
                        ],
                    }],
                },
                "max_count": 5,
                "start_date": (datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=29)).strftime("%Y%m%d"),
                "end_date": datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d"),
            },
            timeout=_TIMEOUT,
        )
        if r.status_code != 200:
            return []
        data = r.json().get("data", {}).get("videos", []) or []
    except Exception:
        return []
    out = []
    for v in data:
        vid = str(v.get("id") or "")
        user = v.get("username") or "user"
        if not vid:
            continue
        share = v.get("share_url") or "https://www.tiktok.com/@{}/video/{}".format(user, vid)
        out.append({
            "source": "tiktok_api", "provider": "tiktok", "id": vid,
            "url": share,
            "title": v.get("video_description") or "TikTok Trailer",
            "type": "Trailer", "official": False, "size": 0,
            "channel": "@" + user, "published": "",
        })
    return out

def from_tiktok_search(query, suffix=None):
    if suffix is None:
        suffix = langpref.search_suffix()
    if not query:
        return []
    api_items = _from_tiktok_official_api(query, suffix=suffix)
    if api_items:
        return api_items
    html = _http(
        "https://duckduckgo.com/html/",
        params={"q": '"{}"{} site:tiktok.com'.format(query, suffix or "")},
    )
    if not html:
        return []
    html = unquote(unescape(html))
    seen = set()
    out = []
    for m in _TIKTOK_URL_RE.finditer(html):
        vid = m.group(1)
        if vid in seen:
            continue
        seen.add(vid)
        user_m = re.search(r'tiktok\.com/(@[^/]+)/video/' + vid, html)
        username = user_m.group(1) if user_m else "@user"
        out.append({
            "source": "tiktok", "provider": "tiktok", "id": vid,
            "url": "https://www.tiktok.com/{}/video/{}".format(username, vid),
            "title": "TikTok Trailer", "type": "Trailer",
            "official": False, "size": 0, "channel": username, "published": "",
        })
        if len(out) >= 3:
            break
    return out

def _dailymotion_api_call(search, sort="relevance", family_filter=None):
    if requests is None:
        return None
    params = {
        "fields": "id,title,channel,thumbnail_url,created_time,duration",
        "limit": 5,
        "search": search,
        "sort": sort,
    }
    if family_filter is not None:
        params["family_filter"] = "true" if family_filter else "false"
    try:
        r = requests.get(
            "https://api.dailymotion.com/videos",
            params=params,
            headers={"User-Agent": _UA,
                     "Accept-Language": langpref.accept_language()},
            timeout=_TIMEOUT,
        )
        if r.status_code != 200:
            return None
        return r.json().get("list", []) or []
    except Exception:
        return None

def from_dailymotion_search(query, suffix=None):
    if suffix is None:
        suffix = langpref.search_suffix()
    if not query or requests is None:
        return []
    full = (query + (suffix or "")).strip()
    items = None
    for sort, family in (("relevance", None),
                         ("relevance", False),
                         ("recent", False),
                         ("relevance", None)):
        items = _dailymotion_api_call(full, sort=sort, family_filter=family)
        if items:
            break
    if not items:
        return []
    out = []
    for it in items:
        vid = it.get("id")
        if not vid:
            continue
        out.append({
            "source": "dailymotion", "provider": "dailymotion", "id": vid,
            "url": "https://www.dailymotion.com/video/" + vid,
            "title": it.get("title") or "",
            "type": "Trailer",
            "official": False,
            "size": 0,
            "channel": it.get("channel") or "",
            "published": str(it.get("created_time") or ""),
            "thumb": it.get("thumbnail_url") or
                     "https://www.dailymotion.com/thumbnail/video/" + vid,
        })
    return out
_FLICKS_TRAILER_PATH_RE = re.compile(r'/trailer/([a-z0-9-]+)/(\d+)/')
_FLICKS_JWID_RE = re.compile(r'data-jwid="([A-Za-z0-9]+)"')
_FLICKS_TITLE_RE = re.compile(r"<title>([^<]+?)</title>")

def _flicks_item_from_path(path, title_hint=None):
    m = _FLICKS_TRAILER_PATH_RE.search(path)
    if not m:
        return None
    slug, nid = m.group(1), m.group(2)
    return {
        "source": "flicks", "provider": "flicks",
        "id": nid, "slug": slug,
        "url": "https://www.flicks.co.uk" + path,
        "title": title_hint or slug.replace("-", " ").title(),
        "type": "Trailer", "official": True,
        "size": 0, "channel": "flicks.co.uk", "published": "",
    }

def from_flicks_search(query, limit=5):
    if not query:
        return []
    html = _http("https://www.flicks.co.uk/search/", params={"q": query})
    if not html:
        return []
    movie_paths = []
    seen_m = set()
    for m in re.finditer(r'/movie/([a-z0-9-]+)/', html):
        slug = m.group(1)
        if not _is_query_relevant(slug.replace("-", " "), query):
            continue
        p = "/movie/{}/".format(slug)
        if p in seen_m:
            continue
        seen_m.add(p)
        movie_paths.append(p)
        if len(movie_paths) >= 3:
            break
    direct = []
    seen_t = set()
    for m in _FLICKS_TRAILER_PATH_RE.finditer(html):
        slug = m.group(1)
        if not _is_query_relevant(slug.replace("-", " "), query):
            continue
        path = m.group(0)
        if path in seen_t:
            continue
        seen_t.add(path)
        direct.append(path)
    for mp in movie_paths:
        page = _http("https://www.flicks.co.uk" + mp)
        if not page:
            continue
        for m in _FLICKS_TRAILER_PATH_RE.finditer(page):
            slug = m.group(1)
            mp_slug_text = mp.strip("/").split("/", 1)[-1].replace("-", " ")
            if not _is_query_relevant(slug.replace("-", " "), mp_slug_text):
                continue
            path = m.group(0)
            if path in seen_t:
                continue
            seen_t.add(path)
            direct.append(path)
        if len(direct) >= limit:
            break
    out = []
    for path in direct[:limit]:
        it = _flicks_item_from_path(path, title_hint="{} (Trailer)".format(query))
        if it:
            out.append(it)
    return out

def from_flicks_trailers_feed(limit=15):
    html = _http("https://www.flicks.co.uk/trailers/")
    if not html:
        return []
    seen = set()
    out = []
    for m in _FLICKS_TRAILER_PATH_RE.finditer(html):
        path = m.group(0)
        if path in seen:
            continue
        seen.add(path)
        slug = m.group(1)
        title = slug.replace("-", " ").title()
        it = _flicks_item_from_path(path, title_hint=title)
        if it:
            out.append(it)
        if len(out) >= limit:
            break
    return out
_PROVIDER_ORDER = {
    "youtube":     0,
    "flicks":      1,
    "vimeo":       2,
    "dailymotion": 3,
    "tiktok":      4,
    "imdb":        5,
}

def collect(media_type, tmdb_id, imdb_id=None, title=None, year=None,
            include_fan_made=False, include_teasers=True):
    items = []
    is_tv = (media_type == "tv")
    if tmdb_id:
        items.extend(from_tmdb(media_type, tmdb_id))
    if imdb_id:
        items.extend(from_imdb(imdb_id))
    youtube_count = sum(1 for i in items if i.get("provider") == "youtube")
    if is_tv:
        if title and youtube_count == 0:
            q = title + (" {}".format(year) if year else "")
            items.extend(from_youtube_search(q, query_title=title))
    else:
        if title and youtube_count < 3:
            q = title + (" {}".format(year) if year else "")
            items.extend(from_youtube_search(q, query_title=title))
        if title:
            items.extend(from_vimeo_search(title))
        if title:
            q_full = title + (" {}".format(year) if year else "")
            items.extend(from_tiktok_search(q_full))
            try:
                items.extend(from_dailymotion_search(q_full))
            except Exception:
                pass
    cleaned = []
    seen_ids = set()
    dropped_lang = 0
    debug.vlog("collect {} id={} Modus={} Rohtreffer={}".format(title, tmdb_id, langpref.mode(), len(items)))
    for it in items:
        key = (it["provider"], it["id"])
        if key in seen_ids:
            continue
        seen_ids.add(key)
        if not langpref.matches(it):
            dropped_lang += 1
            debug.vlog("Sprachfilter verworfen: {} | {} | {}".format(it.get("provider"), it.get("title"), it.get("channel")))
            continue
        fan = filters.is_fan_made(it.get("title", ""), it.get("channel", ""))
        it["fan_made"] = bool(fan)
        if not include_fan_made and fan:
            continue
        if not include_teasers and (it.get("type") or "").lower() == "teaser":
            continue
        cleaned.append(it)

    def _provider_rank(it):
        return _PROVIDER_ORDER.get(it.get("provider"), 9)
    cleaned.sort(key=lambda x: (x.get("fan_made", False),
                                _provider_rank(x),
                                -filters.score(x)))
    debug.vlog("collect Ergebnis={} durch Sprachfilter verworfen={}".format(len(cleaned), dropped_lang))
    return cleaned
