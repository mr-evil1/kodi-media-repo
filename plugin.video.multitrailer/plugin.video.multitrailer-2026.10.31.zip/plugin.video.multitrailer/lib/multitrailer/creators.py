import base64
import json
from . import langpref
import re
try:
    import requests
except ImportError:
    requests = None
try:
    import xbmcaddon
    import xbmcgui
    _HAS_KODI = True
except ImportError:
    _HAS_KODI = False
    xbmcaddon = None
    xbmcgui = None
_TIMEOUT = 12
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
CURATED_CREATORS = [
    {
        "name": "Corridor Digital",
        "handle": "@Corridor",
        "channel_id": "UCSpFnDQr88xCZ80N-X7t0nQ",
        "category": "movies",
        "description": "High-end VFX fan films and shorts (Star Wars, Anime, Keanu Reeves, etc.).",
    },
    {
        "name": "Corridor Crew",
        "handle": "@CorridorCrew",
        "channel_id": "UCsn6cjffsvyOZCZxvGoJxGg",
        "category": "movies",
        "description": "VFX-artist breakdowns + behind-the-scenes of Corridor's fan films.",
    },
    {
        "name": "Bat in the Sun",
        "handle": "@BatintheSun",
        "channel_id": "UCPBdC3cr6Yd_7RkQVueoEXg",
        "category": "movies",
        "description": "Super Power Beat Down creators — hour-long fan movies and crossover films.",
    },
    {
        "name": "RackaRacka",
        "handle": "@therackaracka",
        "channel_id": "UCz_cDc_2arKIb6SlJoqFT0w",
        "category": "movies",
        "description": "Australian brothers behind viral fan mashups and action shorts.",
    },
    {
        "name": "Star Wars Theory",
        "handle": "@StarWarsTheory",
        "channel_id": "UCK5cUXncI7unTWJGjRjN8gQ",
        "category": "movies",
        "description": "Home of 'Vader: Shards of the Past' and other long-form Star Wars fan films.",
    },
    {
        "name": "Darth Maker",
        "handle": "@DarthMaker",
        "channel_id": "UC0zIla20KmAYrIfJ_61Enyw",
        "category": "movies",
        "description": "Fan films & cinematic edits focused on Star Wars and superheroes.",
    },
    {
        "name": "Stryder HD",
        "handle": "@StryderHD",
        "channel_id": "UCRbxtBjhJYILLBcpDvxmE9A",
        "category": "tv",
        "description": "Feature-length fan trailers, concept films and cinematic cuts.",
    },
    {
        "name": "Screen Junkies",
        "handle": "@screenjunkies",
        "channel_id": "UCQMbqH7xJu5aTAPQ9y_U7WQ",
        "category": "movies",
        "description": "Parody feature films and full-length fan productions.",
    },
    {
        "name": "Shadow Animation",
        "handle": "@shadowanimation",
        "channel_id": "UCtgtVFusVYe_SmFlXl9dpaA",
        "category": "movies",
        "description": "Independent animated fan films (Dragon Ball, Sonic, etc.).",
    },
    {
        "name": "Mightyraccoon!",
        "handle": "@mightyraccoon",
        "channel_id": "UCmiqHGk6uPr1tWgm6XocMfw",
        "category": "tv",
        "description": "Animated fan series, full episodes.",
    },
    {
        "name": "Dorkly",
        "handle": "@Dorkly",
        "channel_id": "UCHdos0HAIEhIMqUc9L3vh1w",
        "category": "tv",
        "description": "Long-form animated fan parodies of movies and games.",
    },
    {
        "name": "K&K Productions",
        "handle": "@KandKProductions",
        "channel_id": "UCn1_mkkSkY9iuNJOnht3EkQ",
        "category": "movies",
        "description": "Feature-length Star Wars fan films produced since 2001.",
    },
    {
        "name": "Rooster Teeth Archive",
        "handle": "@RoosterTeeth",
        "channel_id": "UCzH3iADRIq1IJlIXjfNgTpA",
        "category": "tv",
        "description": "Red vs. Blue and other long-form machinima/fan series.",
    },
    {
        "name": "Mr. Sunday Movies",
        "handle": "@MrSundayMovies",
        "channel_id": "UCFLpAEe-1KINb2Vm7i8eDAQ",
        "category": "movies",
        "description": "Feature-length deep-dive fan essays / retrospectives.",
    },
    {
        "name": "TeamFourStar",
        "handle": "@TeamFourStar",
        "channel_id": "UCsvazPPlhZlch0-Z3wPByeg",
        "category": "tv",
        "description": "DragonBall Z Abridged — full-length fan-dub episodes.",
    },
]
_YT_API_OBF_XOR = b"multitrailer-yt-key-2026"
_YT_API_KEY_OBFUSCATED = "NiARCCcLJQU2PQpjCB5oCVYeFGIFZWVCA1wLFkoMPCY6G08vLHUM"

def obfuscate_api_key(key):
    if not key:
        return ""
    kb = key.encode("utf-8")
    out = bytearray()
    for i, b in enumerate(kb):
        out.append(b ^ _YT_API_OBF_XOR[i % len(_YT_API_OBF_XOR)])
    return base64.b64encode(bytes(out)).decode("ascii")
_PLUGIN_ID = "plugin.video.multitrailer"
_BUILTIN_QUOTA_EXCEEDED = False
_QUOTA_NOTICE_SHOWN = False

def _decode_builtin_key():
    if not _YT_API_KEY_OBFUSCATED:
        return None
    try:
        raw = base64.b64decode(_YT_API_KEY_OBFUSCATED)
        out = bytearray()
        for i, b in enumerate(raw):
            out.append(b ^ _YT_API_OBF_XOR[i % len(_YT_API_OBF_XOR)])
        return out.decode("utf-8")
    except Exception:
        return None

def _get_user_settings():
    if not _HAS_KODI:
        return "", False
    try:
        addon = xbmcaddon.Addon(_PLUGIN_ID)
        user_key = (addon.getSetting("user_yt_api_key") or "").strip()
        prefer = (addon.getSetting("prefer_user_key") or "false") == "true"
        return user_key, prefer
    except Exception:
        return "", False

def _show_quota_popup():
    global _QUOTA_NOTICE_SHOWN
    if _QUOTA_NOTICE_SHOWN or not _HAS_KODI:
        return
    _QUOTA_NOTICE_SHOWN = True
    try:
        msg = ("The built-in YouTube API quota for today has been used up. "
               "Fan Films will keep working via web scraping, but for richer "
               "data you can add your own free YouTube Data API v3 key in "
               "Settings -> YouTube API.")
        xbmcgui.Dialog().ok("MultiTrailer - YouTube quota reached", msg)
    except Exception:
        try:
            xbmcgui.Dialog().notification(
                "MultiTrailer",
                "YouTube quota reached - add your own key in Settings.",
                xbmcgui.NOTIFICATION_WARNING, 6000)
        except Exception:
            pass

def _get_api_key():
    user_key, prefer = _get_user_settings()
    if user_key and prefer:
        return user_key
    if not _BUILTIN_QUOTA_EXCEEDED:
        builtin = _decode_builtin_key()
        if builtin:
            return builtin
    if user_key:
        return user_key
    return None

def _looks_like_quota_error(response):
    if response is None or response.status_code != 403:
        return False
    try:
        body = response.json()
    except Exception:
        return False
    for err in (body.get("error") or {}).get("errors") or []:
        reason = (err.get("reason") or "").lower()
        if reason in ("quotaexceeded", "dailylimitexceeded", "ratelimitexceeded"):
            return True
    msg = ((body.get("error") or {}).get("message") or "").lower()
    return "quota" in msg

def _mark_builtin_quota_exhausted():
    global _BUILTIN_QUOTA_EXCEEDED
    _BUILTIN_QUOTA_EXCEEDED = True
    _show_quota_popup()

def _http(url, headers=None, params=None):
    if requests is None:
        return None
    h = {"User-Agent": _UA, "Accept-Language": langpref.accept_language()}
    if headers:
        h.update(headers)
    try:
        r = requests.get(url, headers=h, params=params, timeout=_TIMEOUT)
        if r.status_code == 200:
            return r.text
    except Exception:
        pass
    return None

def _api_channel_uploads(channel_id, page_token=None, max_results=25):
    key = _get_api_key()
    if not key:
        return None
    user_key, _ = _get_user_settings()

    def _do_request(active_key):
        params = {"part": "contentDetails", "id": channel_id, "key": active_key}
        try:
            r = requests.get("https://www.googleapis.com/youtube/v3/channels",
                             params=params, timeout=_TIMEOUT)
        except Exception:
            return None, None
        if r.status_code != 200:
            return None, r
        items = r.json().get("items") or []
        if not items:
            return None, r
        uploads = items[0]["contentDetails"]["relatedPlaylists"]["uploads"]
        params = {
            "part": "snippet,contentDetails",
            "playlistId": uploads,
            "maxResults": max_results,
            "key": active_key,
        }
        if page_token:
            params["pageToken"] = page_token
        try:
            r = requests.get("https://www.googleapis.com/youtube/v3/playlistItems",
                             params=params, timeout=_TIMEOUT)
        except Exception:
            return None, None
        if r.status_code != 200:
            return None, r
        return r.json(), r
    data, resp = _do_request(key)
    if data is None and _looks_like_quota_error(resp):
        builtin = _decode_builtin_key()
        if key == builtin:
            _mark_builtin_quota_exhausted()
            if user_key and user_key != builtin:
                data, resp = _do_request(user_key)
    if data is None:
        return None
    out = []
    for it in data.get("items") or []:
        sn = it.get("snippet") or {}
        cd = it.get("contentDetails") or {}
        vid = cd.get("videoId") or sn.get("resourceId", {}).get("videoId")
        if not vid:
            continue
        thumbs = sn.get("thumbnails") or {}
        thumb = (thumbs.get("maxres") or thumbs.get("high") or thumbs.get("medium")
                 or thumbs.get("default") or {}).get("url", "")
        out.append({
            "video_id": vid,
            "title": sn.get("title", ""),
            "description": sn.get("description", ""),
            "channel": sn.get("channelTitle", ""),
            "published": sn.get("publishedAt", ""),
            "thumb": thumb,
            "url": "https://www.youtube.com/watch?v=" + vid,
        })
    return {"items": out, "next_page_token": data.get("nextPageToken")}

def _resolve_handle_to_channel_id(handle):
    if not handle:
        return None
    url = "https://www.youtube.com/{}".format(handle if handle.startswith("@") else ("@" + handle))
    html = _http(url)
    if not html:
        return None
    for pat in (r'"channelId":"(UC[A-Za-z0-9_-]{22})"',
                r'"externalId":"(UC[A-Za-z0-9_-]{22})"',
                r'"browseId":"(UC[A-Za-z0-9_-]{22})"',
                r'"webCommandMetadata":\{"url":"/channel/(UC[A-Za-z0-9_-]{22})"'):
        m = re.search(pat, html)
        if m:
            return m.group(1)
    return None
_RESOLVED_ID_CACHE = {}

def _self_heal_channel_id(creator):
    handle = creator.get("handle")
    if not handle:
        return creator.get("channel_id")
    cached = _RESOLVED_ID_CACHE.get(handle)
    if cached:
        return cached
    resolved = _resolve_handle_to_channel_id(handle)
    if resolved:
        _RESOLVED_ID_CACHE[handle] = resolved
        return resolved
    return creator.get("channel_id")

def _scrape_channel_videos(channel_id, handle=None, limit=30):
    targets = []
    if handle:
        h = handle if handle.startswith("@") else ("@" + handle)
        targets.append("https://www.youtube.com/{}/videos".format(h))
    if channel_id:
        targets.append("https://www.youtube.com/channel/{}/videos".format(channel_id))
    html = None
    for t in targets:
        html = _http(t)
        if html:
            break
    if not html:
        return []
    m = re.search(r"var ytInitialData\s*=\s*({.*?});</script>", html, re.DOTALL)
    if not m:
        m = re.search(r'ytInitialData"\]\s*=\s*({.*?});\s*</script>', html, re.DOTALL)
    if not m:
        m = re.search(r'ytInitialData\s*=\s*({.+?});\s*(?:var\s|window\[|</script>)', html, re.DOTALL)
    out = []
    seen = set()
    if m:
        try:
            data = json.loads(m.group(1))
            tabs = (data.get("contents", {})
                    .get("twoColumnBrowseResultsRenderer", {})
                    .get("tabs", []))

            def _tab_priority(tab):
                tr = tab.get("tabRenderer") or {}
                url = (((tr.get("endpoint") or {})
                        .get("commandMetadata") or {})
                       .get("webCommandMetadata", {}).get("url") or "")
                title = (tr.get("title") or "").lower()
                if url.endswith("/videos") or title == "videos":
                    return 0
                if tr.get("selected"):
                    return 1
                return 2
            ordered = sorted(tabs, key=_tab_priority)
            for tab in ordered:
                tr = tab.get("tabRenderer") or {}
                content = tr.get("content") or {}
                grid_items = (content.get("richGridRenderer") or {}).get("contents") or []
                if not grid_items:
                    sections = (content.get("sectionListRenderer") or {}).get("contents") or []
                    for sec in sections:
                        isr = (sec.get("itemSectionRenderer") or {}).get("contents") or []
                        for item in isr:
                            gr_items = (item.get("gridRenderer") or {}).get("items") or []
                            grid_items.extend(gr_items)
                if not grid_items:
                    continue
                for c in grid_items:
                    vr = ((c.get("richItemRenderer") or {})
                          .get("content", {}).get("videoRenderer")) \
                         or c.get("gridVideoRenderer") \
                         or c.get("videoRenderer")
                    lvm = None
                    if not vr:
                        lvm = ((c.get("richItemRenderer") or {})
                               .get("content", {}).get("lockupViewModel")) \
                              or c.get("lockupViewModel")
                    if not vr and not lvm:
                        continue
                    if vr:
                        vid = vr.get("videoId")
                        if not vid or vid in seen:
                            continue
                        seen.add(vid)
                        title_runs = (vr.get("title") or {}).get("runs") or []
                        if title_runs:
                            title = title_runs[0].get("text", "")
                        else:
                            title = (
                                (vr.get("title") or {}).get("simpleText", "")
                                or (vr.get("headline") or {}).get("simpleText", "")
                            )
                        thumbs = (vr.get("thumbnail") or {}).get("thumbnails") or []
                        thumb = thumbs[-1].get("url", "") if thumbs else ""
                        dur_text = ((vr.get("lengthText") or {}).get("simpleText")) or ""
                        published = ((vr.get("publishedTimeText") or {}).get("simpleText")) or ""
                    else:
                        vid = lvm.get("contentId")
                        if not vid or vid in seen:
                            continue
                        seen.add(vid)
                        meta = ((lvm.get("metadata") or {})
                                .get("lockupMetadataViewModel") or {})
                        title = (meta.get("title") or {}).get("content", "")
                        published = ""
                        rows = (((meta.get("metadata") or {})
                                 .get("contentMetadataViewModel") or {})
                                .get("metadataRows") or [])
                        for row in rows:
                            for part in (row.get("metadataParts") or []):
                                txt = (part.get("text") or {}).get("content")
                                if txt and any(k in txt.lower() for k in ("ago", "year", "month", "week", "day", "hour", "vor ", "jahr", "monat", "woche", "tag", "stunde", "minute")):
                                    published = txt
                        dur_text = ""
                        ovs = (((lvm.get("contentImage") or {})
                                .get("thumbnailViewModel") or {})
                               .get("overlays") or [])
                        for ov in ovs:
                            badges = (((ov.get("thumbnailBottomOverlayViewModel") or {})
                                       .get("badges") or []))
                            for b in badges:
                                t = ((b.get("thumbnailBadgeViewModel") or {})
                                     .get("text") or "")
                                if isinstance(t, str) and t and ":" in t:
                                    dur_text = t
                                    break
                            if dur_text:
                                break
                        srcs = (((lvm.get("contentImage") or {})
                                 .get("thumbnailViewModel") or {})
                                .get("image", {}).get("sources") or [])
                        thumb = (
                            srcs[-1].get("url", "")
                            if srcs
                            else "https://i.ytimg.com/vi/{}/hqdefault.jpg".format(vid)
                        )
                    out.append({
                        "video_id": vid,
                        "title": title,
                        "description": "",
                        "channel": "",
                        "published": published,
                        "duration": dur_text,
                        "thumb": thumb,
                        "url": "https://www.youtube.com/watch?v=" + vid,
                    })
                    if len(out) >= limit:
                        return out
                if out:
                    return out
        except Exception:
            pass
    if not out:
        for vid in re.findall(r'"videoId":"([a-zA-Z0-9_-]{11})"', html):
            if vid in seen:
                continue
            seen.add(vid)
            out.append({
                "video_id": vid,
                "title": "",
                "description": "",
                "channel": "",
                "published": "",
                "duration": "",
                "thumb": "https://i.ytimg.com/vi/{}/hqdefault.jpg".format(vid),
                "url": "https://www.youtube.com/watch?v=" + vid,
            })
            if len(out) >= limit:
                break
    return out

def list_creators():
    return [dict(c) for c in CURATED_CREATORS]

def get_creator(creator_id_or_name):
    if not creator_id_or_name:
        return None
    key = creator_id_or_name.lower().lstrip("@")
    for c in CURATED_CREATORS:
        if c["channel_id"].lower() == creator_id_or_name.lower():
            return dict(c)
        if c["handle"].lstrip("@").lower() == key:
            return dict(c)
        if c["name"].lower() == creator_id_or_name.lower():
            return dict(c)
    return None

def get_creator_videos(creator, page_token=None, limit=30):
    if isinstance(creator, str):
        creator = get_creator(creator)
    if not creator:
        return {"items": [], "next_page_token": None}
    channel_id = creator["channel_id"]
    handle = creator.get("handle")

    def _fetch(cid):
        if _get_api_key():
            api_res = _api_channel_uploads(cid, page_token=page_token, max_results=limit)
            if api_res and api_res["items"]:
                return api_res
        vids = _scrape_channel_videos(cid, handle=handle, limit=limit)
        if vids:
            return {"items": vids, "next_page_token": None}
        return None
    res = _fetch(channel_id)
    needs_heal = (not res) or (res and len(res.get("items") or []) < 2)
    if needs_heal and handle:
        resolved = _self_heal_channel_id(creator)
        if resolved and resolved != channel_id:
            healed = _fetch(resolved)
            if healed and healed.get("items"):
                res = healed
    if not res:
        return {"items": [], "next_page_token": None}
    for v in res.get("items", []):
        if not v.get("channel"):
            v["channel"] = creator["name"]
    return res

def get_all_fan_films(limit_per_creator=10):
    out = []
    for c in CURATED_CREATORS:
        res = get_creator_videos(c, limit=limit_per_creator)
        for v in res.get("items", []):
            v = dict(v)
            v["creator"] = c["name"]
            v["creator_category"] = c.get("category", "movies")
            out.append(v)
    return out
