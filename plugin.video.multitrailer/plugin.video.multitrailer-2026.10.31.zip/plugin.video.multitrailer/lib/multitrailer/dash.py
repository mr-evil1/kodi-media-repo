import os
import tempfile
import time
import uuid
import re
from urllib.parse import quote as _url_quote
from urllib.request import pathname2url as _pathname2url
try:
    import xbmc
    import xbmcvfs
    _HAS_KODI = True
except ImportError:
    _HAS_KODI = False
    xbmc = None
    xbmcvfs = None
_HTTPD_DATA_SUBDIR = "special://profile/addon_data/plugin.video.multitrailer/"
_HTTPD_PORT_FILE = _HTTPD_DATA_SUBDIR + "httpd_port.txt"
_HTTPD_MPD_SUBDIR = _HTTPD_DATA_SUBDIR + "mpd/"

def _read_httpd_port():
    if not _HAS_KODI:
        return None
    try:
        path = xbmcvfs.translatePath(_HTTPD_PORT_FILE)
        if not os.path.isfile(path):
            return None
        with open(path, "r", encoding="utf-8") as fh:
            raw = fh.read().strip()
        port = int(raw)
        if 1024 <= port <= 65535:
            return port
    except (OSError, ValueError):
        pass
    return None
_ADAPTIVE_ITAGS = {
    133: (240,  "240p",   "mp4",  "avc1",  30, False),
    134: (360,  "360p",   "mp4",  "avc1",  30, False),
    135: (480,  "480p",   "mp4",  "avc1",  30, False),
    136: (720,  "720p",   "mp4",  "avc1",  30, False),
    137: (1080, "1080p",  "mp4",  "avc1",  30, False),
    264: (1440, "1440p",  "mp4",  "avc1",  30, False),
    266: (2160, "4K",     "mp4",  "avc1",  30, False),
    298: (720,  "720p60", "mp4",  "avc1",  60, False),
    299: (1080, "1080p60","mp4",  "avc1",  60, False),
    304: (1440, "1440p60","mp4",  "avc1",  60, False),
    305: (2160, "4K60",   "mp4",  "avc1",  60, False),
    242: (240,  "240p",   "webm", "vp9",   30, False),
    243: (360,  "360p",   "webm", "vp9",   30, False),
    244: (480,  "480p",   "webm", "vp9",   30, False),
    247: (720,  "720p",   "webm", "vp9",   30, False),
    248: (1080, "1080p",  "webm", "vp9",   30, False),
    271: (1440, "1440p",  "webm", "vp9",   30, False),
    313: (2160, "4K",     "webm", "vp9",   30, False),
    302: (720,  "720p60", "webm", "vp9",   60, False),
    303: (1080, "1080p60","webm", "vp9",   60, False),
    308: (1440, "1440p60","webm", "vp9",   60, False),
    315: (2160, "4K60",   "webm", "vp9",   60, False),
    394: (144,  "144p",   "mp4",  "av01",  30, False),
    395: (240,  "240p",   "mp4",  "av01",  30, False),
    396: (360,  "360p",   "mp4",  "av01",  30, False),
    397: (480,  "480p",   "mp4",  "av01",  30, False),
    398: (720,  "720p",   "mp4",  "av01",  30, False),
    399: (1080, "1080p",  "mp4",  "av01",  30, False),
    400: (1440, "1440p",  "mp4",  "av01",  30, False),
    401: (2160, "4K",     "mp4",  "av01",  30, False),
    139: (None, "48kbps",  "mp4",  "mp4a",  0, True),
    140: (None, "128kbps", "mp4",  "mp4a",  0, True),
    141: (None, "256kbps", "mp4",  "mp4a",  0, True),
    249: (None, "50kbps",  "webm", "opus",  0, True),
    250: (None, "70kbps",  "webm", "opus",  0, True),
    251: (None, "160kbps", "webm", "opus",  0, True),
    256: (None, "aac-5.1", "mp4",  "mp4a",  0, True),
    258: (None, "aac-5.1", "mp4",  "mp4a",  0, True),
}
_VIDEO_MIME = {"mp4": "video/mp4", "webm": "video/webm"}
_AUDIO_MIME = {"mp4": "audio/mp4", "webm": "audio/webm"}

def _codecs_from_mime(mime_type):
    if not mime_type:
        return None
    m = re.search(r'codecs="([^"]+)"', mime_type)
    return m.group(1) if m else None

def _iso_duration(seconds):
    try:
        s = float(seconds)
    except (TypeError, ValueError):
        return "PT0S"
    if s <= 0:
        return "PT0S"
    h = int(s // 3600)
    m = int((s % 3600) // 60)
    sec = s - (h * 3600) - (m * 60)
    parts = ["PT"]
    if h:
        parts.append("{}H".format(h))
    if m:
        parts.append("{}M".format(m))
    parts.append("{:.3f}S".format(sec))
    return "".join(parts)

def _xml_escape(v):
    if v is None:
        return ""
    return str(v).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def _represent_stream(fmt, is_audio=False):
    itag = fmt.get("itag")
    url = fmt.get("url")
    if not url:
        return None
    meta = _ADAPTIVE_ITAGS.get(itag)
    mime = fmt.get("mimeType", "") or ""
    codecs = _codecs_from_mime(mime) or (meta[3] if meta else None)
    bitrate = fmt.get("bitrate") or fmt.get("averageBitrate") or 0
    init_range = fmt.get("initRange") or {}
    index_range = fmt.get("indexRange") or {}
    init_start = init_range.get("start")
    init_end = init_range.get("end")
    idx_start = index_range.get("start")
    idx_end = index_range.get("end")
    if None in (init_start, init_end, idx_start, idx_end):
        return None
    lines = []
    attrs = [
        'id="{}"'.format(itag),
        'bandwidth="{}"'.format(int(bitrate) or 100000),
    ]
    if codecs:
        attrs.append('codecs="{}"'.format(_xml_escape(codecs)))
    if is_audio:
        sr = fmt.get("audioSampleRate") or 44100
        attrs.append('audioSamplingRate="{}"'.format(sr))
    else:
        if fmt.get("width"):
            attrs.append('width="{}"'.format(fmt["width"]))
        if fmt.get("height"):
            attrs.append('height="{}"'.format(fmt["height"]))
        if fmt.get("fps"):
            attrs.append('frameRate="{}"'.format(fmt["fps"]))
    lines.append("      <Representation {}>".format(" ".join(attrs)))
    if is_audio:
        ch = fmt.get("audioChannels") or 2
        lines.append(
            '        <AudioChannelConfiguration '
            'schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" '
            'value="{}"/>'.format(ch)
        )
    lines.append("        <BaseURL>{}</BaseURL>".format(_xml_escape(url)))
    lines.append(
        '        <SegmentBase indexRange="{}-{}" indexRangeExact="true">'.format(
            idx_start, idx_end)
    )
    lines.append(
        '          <Initialization range="{}-{}"/>'.format(init_start, init_end)
    )
    lines.append("        </SegmentBase>")
    lines.append("      </Representation>")
    return "\n".join(lines)

def _group_by_container(formats, is_audio):
    out = {"mp4": [], "webm": []}
    for f in formats:
        meta = _ADAPTIVE_ITAGS.get(f.get("itag"))
        if not meta:
            continue
        if meta[5] != is_audio:
            continue
        container = meta[2]
        out.setdefault(container, []).append(f)
    return out

def build_mpd(adaptive_formats, duration_seconds, max_height=None):
    if not adaptive_formats:
        return None
    usable = []
    for f in adaptive_formats:
        itag = f.get("itag")
        meta = _ADAPTIVE_ITAGS.get(itag)
        if not meta:
            continue
        if not f.get("url"):
            continue
        if not meta[5] and max_height and meta[0] and meta[0] > max_height:
            continue
        usable.append(f)
    video_by_container = _group_by_container(usable, is_audio=False)
    audio_by_container = _group_by_container(usable, is_audio=True)
    video_reps = []
    video_container = None
    if video_by_container.get("mp4"):
        video_container = "mp4"
        for f in sorted(video_by_container["mp4"], key=lambda x: x.get("bitrate", 0)):
            r = _represent_stream(f, is_audio=False)
            if r:
                video_reps.append(r)
    if not video_reps and video_by_container.get("webm"):
        video_container = "webm"
        for f in sorted(video_by_container["webm"], key=lambda x: x.get("bitrate", 0)):
            r = _represent_stream(f, is_audio=False)
            if r:
                video_reps.append(r)
    audio_reps = []
    preferred_order = [video_container, "mp4", "webm"]
    for c in preferred_order:
        if not c:
            continue
        chosen = audio_by_container.get(c)
        if chosen:
            for f in sorted(chosen, key=lambda x: x.get("bitrate", 0)):
                r = _represent_stream(f, is_audio=True)
                if r:
                    audio_reps.append(r)
            if audio_reps:
                break
    if not video_reps or not audio_reps:
        return None
    video_mime = _VIDEO_MIME.get(video_container, "video/mp4")
    audio_mime = _AUDIO_MIME.get(video_container, "audio/mp4")
    xml = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<MPD xmlns="urn:mpeg:dash:schema:mpd:2011"',
        '     profiles="urn:mpeg:dash:profile:isoff-on-demand:2011"',
        '     type="static"',
        '     mediaPresentationDuration="{}"'.format(_iso_duration(duration_seconds)),
        '     minBufferTime="PT2S"',
        '     maxSegmentDuration="PT5S">',
        '  <Period duration="{}">'.format(_iso_duration(duration_seconds)),
        '    <AdaptationSet mimeType="{}" segmentAlignment="true" startWithSAP="1" '
        'subsegmentAlignment="true" subsegmentStartsWithSAP="1" bitstreamSwitching="true" lang="und">'.format(
            video_mime),
    ]
    xml.extend(video_reps)
    xml.append('    </AdaptationSet>')
    xml.append(
        '    <AdaptationSet mimeType="{}" segmentAlignment="true" startWithSAP="1" '
        'bitstreamSwitching="true" lang="und">'.format(audio_mime)
    )
    xml.extend(audio_reps)
    xml.append('    </AdaptationSet>')
    xml.append('  </Period>')
    xml.append('</MPD>')
    return "\n".join(xml)

def _temp_dir():
    if _HAS_KODI:
        try:
            p = xbmcvfs.translatePath(_HTTPD_MPD_SUBDIR)
            if p:
                if not os.path.exists(p):
                    os.makedirs(p)
                return p
        except OSError:
            pass
        try:
            p = xbmcvfs.translatePath("special://temp/")
            if p:
                wt = os.path.join(p, "multitrailer")
                if not os.path.exists(wt):
                    os.makedirs(wt)
                return wt
        except OSError:
            pass
    return tempfile.gettempdir()

def _cleanup_old(folder, max_age_sec=3600):
    try:
        now = time.time()
        for name in os.listdir(folder):
            if not name.startswith("multitrailer_") or not name.endswith(".mpd"):
                continue
            full = os.path.join(folder, name)
            try:
                if now - os.path.getmtime(full) > max_age_sec:
                    os.remove(full)
            except OSError:
                pass
    except OSError:
        pass

def _path_to_file_url(path):
    try:
        url = _pathname2url(path)
    except Exception:
        url = _url_quote(path)
    if url.startswith("///"):
        return "file://" + url
    if url.startswith("/"):
        return "file://" + url
    return "file:///" + url.lstrip("/")

def write_mpd(adaptive_formats, duration_seconds, max_height=None):
    xml = build_mpd(adaptive_formats, duration_seconds, max_height=max_height)
    if not xml:
        return None
    folder = _temp_dir()
    _cleanup_old(folder)
    name = "multitrailer_{}.mpd".format(uuid.uuid4().hex[:10])
    full = os.path.join(folder, name)
    try:
        with open(full, "w", encoding="utf-8") as fh:
            fh.write(xml)
    except OSError:
        return None
    port = _read_httpd_port()
    if port is not None:
        try:
            mpd_root = xbmcvfs.translatePath(_HTTPD_MPD_SUBDIR) if _HAS_KODI else ""
        except OSError:
            mpd_root = ""
        if mpd_root and os.path.commonpath([full, mpd_root]) == os.path.normpath(mpd_root):
            return "http://127.0.0.1:{}/mpd/{}".format(port, name)
    return _path_to_file_url(full)
