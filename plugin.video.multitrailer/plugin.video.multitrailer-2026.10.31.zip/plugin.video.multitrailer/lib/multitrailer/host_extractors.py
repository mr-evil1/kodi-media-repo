import json
import re
import time
from urllib.parse import urlparse, urlencode, parse_qsl
try:
    import requests
except ImportError:
    requests = None
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36'
LAST_ERRORS = {}
_MEDIA_CACHE = {}

def available(rows, provider):
    if requests is None:
        return []
    out=[]
    for row in rows:
        raw=row.get('url') or ''
        url,_,encoded_headers=raw.partition('|')
        if urlparse(url).scheme not in ('http','https'):
            continue
        headers=dict(parse_qsl(encoded_headers))
        headers.update(row.get('http_headers') or {})
        key=(url,tuple(sorted(headers.items())))
        cached=_MEDIA_CACHE.get(key)
        if cached and time.monotonic()-cached[0]<60:
            valid=cached[1]
        else:
            try:
                with requests.get(url,headers=headers,stream=True,timeout=10) as response:
                    status=response.status_code
                    valid=status in (200,206)
                    if valid:
                        prefix=next(response.iter_content(16),b'')
                        valid=bool(prefix)
                        if row.get('ext')=='m3u8':valid=valid and b'#EXTM3U' in prefix
                    if not valid:_error(provider,'Media unavailable (HTTP {})'.format(status))
            except Exception as exc:
                valid=False;_error(provider,'Media check failed: '+type(exc).__name__)
            if len(_MEDIA_CACHE)>128:_MEDIA_CACHE.clear()
            _MEDIA_CACHE[key]=(time.monotonic(),valid)
        if valid:
            if provider == 'dailymotion' and row.get('ext') == 'm3u8':
                row = dict(row, native_hls=True, isa_manifest_type=None)
                if headers and '|' not in row['url']:
                    row['url'] += '|' + urlencode(headers)
            out.append(row)
    return out

def _error(provider, reason):
    LAST_ERRORS[provider] = str(reason)
    try:
        from . import debug
        debug.wlog('{}: {}'.format(provider, reason), level='WARNING')
    except Exception:
        pass

def _get(provider, url, as_json=True, headers=None):
    if requests is None:
        _error(provider, 'requests dependency unavailable')
        return None
    try:
        response = requests.get(url, headers=dict({'User-Agent': UA}, **(headers or {})), timeout=15)
        if response.status_code != 200:
            _error(provider, 'HTTP {}'.format(response.status_code))
            return None
        return response.json() if as_json else response.text
    except Exception as exc:
        _error(provider, type(exc).__name__)
        return None

def _quality(url, host, height=0, label=None, mime='', headers=None):
    if not isinstance(url,str) or urlparse(url).scheme not in ('http','https'):
        return None
    path=urlparse(url).path.lower()
    hls='mpegurl' in mime.lower() or path.endswith('.m3u8')
    dash='dash+xml' in mime.lower() or path.endswith('.mpd')
    headers=headers or {}
    if headers and not (hls or dash):
        url += '|' + urlencode(headers)
    return {'url':url,'host':host,'height':int(height or 0),
            'label':label or ('Auto (HLS)' if hls else ('Auto (DASH)' if dash else ('{}p'.format(height) if height else 'Auto'))),
            'ext':'m3u8' if hls else ('mpd' if dash else 'mp4'),
            'is_dash':dash,'isa_manifest_type':'hls' if hls else ('mpd' if dash else None),
            'mime_type':'application/vnd.apple.mpegurl' if hls else ('application/dash+xml' if dash else 'video/mp4'),
            'http_headers':headers}

def _clean(rows):
    seen=set();result=[]
    for row in rows:
        if not row or row['url'] in seen:continue
        seen.add(row['url']);result.append(row)
    return sorted(result,key=lambda row:(-row['height'],row['isa_manifest_type'] is None))

def vimeo(url):
    match=re.search(r'(?:video/|vimeo\.com/)(\d+)',url or '')
    if not match:return []
    video_id=match.group(1)
    from urllib.parse import parse_qs
    query=parse_qs(urlparse(url).query)
    tail=urlparse(url).path.strip('/').split('/')
    video_hash=(query.get('h') or [None])[0]
    if not video_hash and len(tail)>1 and tail[0].isdigit():video_hash=tail[1]
    config_url='https://player.vimeo.com/video/{}/config'.format(video_id)
    if video_hash:config_url+='?'+urlencode({'h':video_hash})
    data=_get('vimeo',config_url) or {}
    files=(data.get('request') or {}).get('files') or {}
    headers={'User-Agent':UA,'Referer':url}
    rows=[]
    for fmt in files.get('progressive') or []:
        rows.append(_quality(fmt.get('url'),'Vimeo',fmt.get('height'),mime=fmt.get('mime',''),headers=headers))
    hls=files.get('hls') or {}
    cdns=hls.get('cdns') or {}
    cdn=cdns.get(hls.get('default_cdn')) or next(iter(cdns.values()),{})
    if cdn.get('url'):rows.append(_quality(cdn['url'],'Vimeo',mime='application/vnd.apple.mpegurl',headers=headers))
    return _clean(rows)

def dailymotion(url):
    match=re.search(r'(?:video/|dai\.ly/)([A-Za-z0-9]+)',url or '')
    if not match:return []
    data=_get('dailymotion','https://www.dailymotion.com/player/metadata/video/'+match.group(1)+'?app=com.dailymotion.neon') or {}
    if data.get('error'):
        _error('dailymotion','Provider reports unavailable or restricted video')
        return []
    rows=[]
    for quality,formats in (data.get('qualities') or {}).items():
        for fmt in formats or []:
            if fmt.get('drm') or 'audio/' in fmt.get('type','') or fmt.get('type')=='application/vnd.lumberjack.manifest':continue
            height=int(quality) if str(quality).isdigit() else 0
            rows.append(_quality(fmt.get('url'),'Dailymotion',height,mime=fmt.get('type',''),headers={'User-Agent':UA,'Referer':url}))
    return _clean(rows)

def _script_json(html,script_id):
    match=re.search(r'<script\b[^>]*\bid=["\']'+re.escape(script_id)+r'["\'][^>]*>(.*?)</script>',html or '',re.S)
    if match:
        try:return json.loads(match.group(1))
        except ValueError:pass
    return {}

def tiktok(url):
    html=_get('tiktok',url,as_json=False) or ''
    data=_script_json(html,'__UNIVERSAL_DATA_FOR_REHYDRATION__')
    detail=(data.get('__DEFAULT_SCOPE__') or {}).get('webapp.video-detail') or {}
    item=(detail.get('itemInfo') or {}).get('itemStruct') or {}
    if not item:
        sigi=_script_json(html,'SIGI_STATE')
        item=next(iter((sigi.get('ItemModule') or {}).values()),{})
    video=item.get('video') or {};rows=[]

    def media_url(address):
        if isinstance(address,str):return address
        if isinstance(address,dict):return next(iter(address.get('UrlList') or address.get('urlList') or []),None)
        return None
    headers={'User-Agent':UA,'Referer':url}
    rows.append(_quality(media_url(video.get('playAddr')),'TikTok',video.get('height'),headers=headers))
    for fmt in video.get('bitrateInfo') or []:
        addr=fmt.get('PlayAddr') or {}
        rows.append(_quality(media_url(addr),'TikTok',addr.get('Height') or video.get('height'),headers=headers))
    if not any(rows):_error('tiktok','Public page did not expose playable media; authentication or access restriction may apply')
    return _clean(rows)

def imdb(url):
    data=_get('imdb',url,as_json=False) or ''
    page=_script_json(data,'__NEXT_DATA__')
    video=(((page.get('props') or {}).get('pageProps') or {}).get('videoPlaybackData') or {}).get('video') or {}
    rows=[]
    encodings=video.get('playbackURLs') or []
    if not encodings:
        match=re.search(r'"playbackURLs"\s*:\s*',data)
        if match:
            try:encodings=json.JSONDecoder().raw_decode(data[match.end():].lstrip())[0]
            except ValueError:pass
    for fmt in encodings:
        label=(fmt.get('displayName') or {}).get('value') or fmt.get('definition') or ''
        height_match=re.search(r'(\d+)p',label)
        rows.append(_quality(fmt.get('url'),'IMDB',int(height_match.group(1)) if height_match else 0,label=label or None,mime=fmt.get('mimeType','')))
    return _clean(rows)

def direct(url,host='Direct'):
    row=_quality(url,host)
    return [row] if row else []

def list_qualities(provider,url):
    handler={'vimeo':vimeo,'dailymotion':dailymotion,'tiktok':tiktok,'imdb':imdb,'direct':direct}.get(provider)
    if not handler:return []
    LAST_ERRORS.pop(provider,None)
    try:
        rows=handler(url)
        return rows if provider=='direct' else available(rows,provider)
    except Exception as exc:
        _error(provider,type(exc).__name__)
        return []
