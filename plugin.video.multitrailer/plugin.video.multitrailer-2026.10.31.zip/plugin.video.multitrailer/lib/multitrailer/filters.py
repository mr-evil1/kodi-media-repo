import re
_FAN_PATTERNS = [
    r"\bfan[\s\-]?made\b",
    r"\bfan[\s\-]?film\b",
    r"\bfan[\s\-]?trailers?\b",
    r"\bfan[\s\-]?(?:re)?(?:cut|edit|remaster|version)\b",
    r"\bconcept\s+trailers?\b",
    r"\btrailer\s+concepts?\b",
    r"\bwhat\s+if\b",
    r"\bunofficial\b",
    r"\bparody\b",
    r"\bmashup\b",
    r"\bmash[\s\-]?up\b",
    r"\bre[\s\-]?cut\b",
    r"\brecut\b",
    r"\bhonest\s+trailers?\b",
    r"\bhomemade\b",
    r"\bspoof\b",
    r"\bsweded\b",
    r"\bif\s+.+\s+was\b",
    r"\bby\s+stryder\s*hd\b",
    r"\bccn\s+studios\b",
]
_OFFICIAL_HINTS = [
    "official trailer",
    "official teaser",
    "offizieller trailer",
    "offizieller teaser",
    "offizielle",
    "official",
    "main trailer",
    "final trailer",
    "teaser trailer",
]
_TRUSTED_CHANNELS = {
    "warner bros. pictures", "warner bros pictures", "warner bros",
    "marvel entertainment", "marvel studios",
    "20th century studios", "20th century fox", "fox movies",
    "universal pictures", "universal pictures all-access",
    "sony pictures entertainment", "sony pictures", "spe",
    "paramount pictures",
    "walt disney studios", "disney",
    "lionsgate movies", "lionsgate",
    "a24",
    "netflix", "prime video", "hbo", "hbo max", "max",
    "apple tv", "apple tv+",
    "rotten tomatoes trailers", "rotten tomatoes coming soon",
    "fandangonow", "movieclips trailers", "fandango",
    "screen gems", "focus features", "stx entertainment",
    "amazon prime video", "hulu", "peacock",
    "bbc", "itv", "showtime", "starz", "fx networks",
    "dreamworks animation", "pixar",
    "kinocheck international", "kinocheck", "kino check", "filmtrailer", "studiocanal deutschland",
    "constantin film", "leonine studios", "warner bros. deutschland", "sony pictures deutschland",
    "universal pictures germany", "disney deutschland", "paramount pictures germany", "wild bunch germany",
    "the hollywood reporter trailers",
}
_FAN_REGEX = re.compile("|".join(_FAN_PATTERNS), re.IGNORECASE)

def is_fan_made(title, channel=None):
    if not title:
        return False
    if _FAN_REGEX.search(title):
        return True
    if channel:
        ch = channel.lower().strip()
        if ch in _TRUSTED_CHANNELS:
            return False
        if _FAN_REGEX.search(ch):
            return True
    return False

def is_official(title, channel=None):
    if not title:
        return False
    t = title.lower()
    if any(h in t for h in _OFFICIAL_HINTS):
        if not is_fan_made(title, channel):
            return True
    if channel and channel.lower().strip() in _TRUSTED_CHANNELS:
        return not is_fan_made(title, channel)
    return False

def score(item):
    s = 0
    title = (item.get("title") or item.get("name") or "").lower()
    channel = (item.get("channel") or "").lower()
    typ = (item.get("type") or "").lower()
    src = (item.get("source") or "").lower()
    if item.get("official") is True:
        s += 50
    lang = (item.get("language") or "").lower()
    if lang == "de" or "deutsch" in title or "german" in title or "(de)" in title:
        s += 60
    elif lang and lang != "de":
        s -= 10
    if "offizieller trailer" in title:
        s += 40
    elif "official trailer" in title:
        s += 40
    elif "main trailer" in title:
        s += 35
    elif "final trailer" in title:
        s += 30
    elif "official teaser" in title:
        s += 25
    elif "teaser trailer" in title:
        s += 20
    elif "trailer" in title:
        s += 15
    elif "teaser" in title:
        s += 10
    if typ == "trailer":
        s += 20
    elif typ == "teaser":
        s += 10
    if channel and channel in _TRUSTED_CHANNELS:
        s += 25
    if is_fan_made(title, channel):
        s -= 200
    if src == "tmdb":
        s += 5
    elif src == "imdb":
        s += 3
    return s
