from __future__ import annotations
import os
import io
import sys
import json
import zipfile
import platform
import time
import traceback
from datetime import datetime
try:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    _HAS_KODI = True
except Exception:
    _HAS_KODI = False
    xbmc = xbmcgui = xbmcaddon = xbmcvfs = None
MODULE_ADDON_ID = "plugin.video.multitrailer"
PLUGIN_ADDON_ID = "plugin.video.multitrailer"
_LOG_FILENAME = "debug.log"
_LOG_ROLL_BYTES = 1024 * 1024
_LINE_PREFIX = "[multitrailer]"
_VERBOSE_CACHE = [0.0, False]

def verbose() -> bool:
    now = time.time()
    if now - _VERBOSE_CACHE[0] < 2.0:
        return _VERBOSE_CACHE[1]
    value = False
    if _HAS_KODI:
        try:
            value = xbmcaddon.Addon(PLUGIN_ADDON_ID).getSetting("debug_verbose") == "true"
        except Exception:
            value = False
    _VERBOSE_CACHE[0] = now
    _VERBOSE_CACHE[1] = value
    return value

def _translate(p: str) -> str:
    if _HAS_KODI:
        try:
            return xbmcvfs.translatePath(p)
        except Exception:
            try:
                return xbmc.translatePath(p)
            except Exception:
                return p
    return p

def _module_profile_dir() -> str:
    path = _translate("special://profile/addon_data/{}/".format(MODULE_ADDON_ID))
    if "special:" in path:
        return path
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path

def _log_path() -> str:
    return os.path.join(_module_profile_dir(), _LOG_FILENAME)

def _downloads_dir() -> str:
    if _HAS_KODI:
        try:
            if xbmc.getCondVisibility("System.Platform.Android"):
                for cand in ("/storage/emulated/0/Download",
                             "/sdcard/Download",
                             "/storage/emulated/0/Downloads"):
                    if os.path.isdir(cand):
                        return cand
        except Exception:
            pass
    for var in ("XDG_DOWNLOAD_DIR", "USERPROFILE", "HOME"):
        base = os.environ.get(var)
        if not base:
            continue
        cand = os.path.join(base, "Downloads")
        if os.path.isdir(cand):
            return cand
        cand = os.path.join(base, "Download")
        if os.path.isdir(cand):
            return cand
    return _module_profile_dir()

def wlog(msg: str, level: str = "INFO") -> None:
    stamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    line = "{} [{}] {}".format(stamp, level.upper(), msg)
    if _HAS_KODI:
        try:
            lvl = level.upper()
            if verbose() or lvl in ("WARNING", "ERROR", "FATAL"):
                lv = {
                    "DEBUG": xbmc.LOGINFO, "INFO": xbmc.LOGINFO,
                    "NOTICE": xbmc.LOGINFO, "WARNING": xbmc.LOGWARNING,
                    "ERROR": xbmc.LOGERROR, "FATAL": xbmc.LOGFATAL,
                }.get(lvl, xbmc.LOGINFO)
                xbmc.log("{} {}".format(_LINE_PREFIX, msg), lv)
        except Exception:
            pass
    try:
        path = _log_path()
        try:
            if os.path.isfile(path) and os.path.getsize(path) > _LOG_ROLL_BYTES:
                rolled = path + ".1"
                try:
                    if os.path.isfile(rolled):
                        os.remove(rolled)
                except Exception:
                    pass
                try:
                    os.rename(path, rolled)
                except Exception:
                    pass
        except Exception:
            pass
        with open(path, "a", encoding="utf-8", errors="replace") as fh:
            fh.write(line + "\n")
    except Exception:
        pass

def vlog(msg: str, level: str = "DEBUG") -> None:
    if verbose():
        wlog(msg, level)

def wexc(prefix: str = "unhandled") -> None:
    try:
        tb = traceback.format_exc()
    except Exception:
        tb = "<traceback unavailable>"
    wlog("{}:\n{}".format(prefix, tb), level="ERROR")

def _addon_info(addon_id: str) -> dict:
    if not _HAS_KODI:
        return {"id": addon_id, "available": False}
    try:
        a = xbmcaddon.Addon(addon_id)
        out = {
            "id": addon_id,
            "available": True,
            "name": a.getAddonInfo("name"),
            "version": a.getAddonInfo("version"),
            "author": a.getAddonInfo("author"),
            "path": a.getAddonInfo("path"),
            "profile": a.getAddonInfo("profile"),
        }
        try:
            settings_xml = os.path.join(_translate(a.getAddonInfo("path") or ""),
                                        "resources", "settings.xml")
            ids: list = []
            if os.path.isfile(settings_xml):
                import re
                with open(settings_xml, "r", encoding="utf-8", errors="replace") as fh:
                    text = fh.read()
                ids = re.findall(r'<setting[^>]+id="([^"]+)"', text)
            values = {}
            for sid in ids:
                try:
                    values[sid] = a.getSetting(sid)
                except Exception:
                    values[sid] = "<read-error>"
            out["settings"] = values
        except Exception:
            out["settings"] = {}
        return out
    except Exception as e:
        return {"id": addon_id, "available": False, "error": str(e)}

def _system_info_text() -> str:
    lines = []
    lines.append("MultiTrailer Debug Bundle")
    lines.append("Generated: " + datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"))
    lines.append("")
    if _HAS_KODI:
        try:
            lines.append("Kodi Build:    " + xbmc.getInfoLabel("System.BuildVersion"))
        except Exception:
            pass
        try:
            lines.append("Kodi Date:     " + xbmc.getInfoLabel("System.BuildDate"))
        except Exception:
            pass
        try:
            for prop in ("System.Platform.Windows", "System.Platform.Linux",
                         "System.Platform.OSX", "System.Platform.Android",
                         "System.Platform.ATV2", "System.Platform.IOS",
                         "System.Platform.TVOS"):
                try:
                    if xbmc.getCondVisibility(prop):
                        lines.append("Kodi Platform: " + prop.rsplit(".", 1)[-1])
                        break
                except Exception:
                    pass
        except Exception:
            pass
    lines.append("Python:        " + sys.version.replace("\n", " "))
    lines.append("Platform:      " + platform.platform())
    lines.append("Machine:       " + platform.machine())
    lines.append("")
    lines.append("---- Addons ----")
    for aid in (MODULE_ADDON_ID, PLUGIN_ADDON_ID):
        info = _addon_info(aid)
        lines.append(json.dumps(info, indent=2, ensure_ascii=False, default=str))
        lines.append("")
    return "\n".join(lines)

def _add_file_if_exists(zf: zipfile.ZipFile, src: str, arcname: str) -> bool:
    try:
        if not src or not os.path.isfile(src):
            return False
        zf.write(src, arcname)
        return True
    except Exception:
        wexc("add_file failed for " + str(src))
        return False

def _filtered_kodi_log(kodi_log_path: str) -> bytes:
    try:
        if not os.path.isfile(kodi_log_path):
            return b""
        needles = (b"[multitrailer]", b"plugin.video.multitrailer",
                   b"plugin.video.multitrailer", b"multitrailer")
        out = io.BytesIO()
        with open(kodi_log_path, "rb") as fh:
            for raw in fh:
                low = raw.lower()
                if any(n in low for n in needles):
                    out.write(raw)
        return out.getvalue()
    except Exception:
        wexc("filter kodi.log failed")
        return b""

def build_debug_bundle(dest_dir: str | None = None) -> str | None:
    try:
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        filename = "multitrailer-debug-{}.zip".format(ts)
        dest = dest_dir or _downloads_dir()
        try:
            os.makedirs(dest, exist_ok=True)
        except Exception:
            pass
        out_path = os.path.join(dest, filename)
        kodi_log = _translate("special://logpath/kodi.log")
        kodi_old = _translate("special://logpath/kodi.old.log")
        addon_log = _log_path()
        addon_log_rolled = addon_log + ".1"
        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
            try:
                zf.writestr("system_info.txt", _system_info_text())
            except Exception:
                wexc("write system_info.txt failed")
            _add_file_if_exists(zf, kodi_log, "kodi/kodi.log")
            _add_file_if_exists(zf, kodi_old, "kodi/kodi.old.log")
            _add_file_if_exists(zf, addon_log, "addon/debug.log")
            _add_file_if_exists(zf, addon_log_rolled, "addon/debug.log.1")
            try:
                filt = _filtered_kodi_log(kodi_log)
                if filt:
                    zf.writestr("multitrailer_filtered.log", filt)
            except Exception:
                wexc("write filtered log failed")
            try:
                zf.writestr("README.txt",
                    "MultiTrailer debug bundle\n"
                    "=========================\n"
                    "Share this file when reporting an issue. It contains:\n"
                    "  - system_info.txt      Kodi / Python / platform / addon versions + current settings\n"
                    "  - kodi/kodi.log        Full Kodi session log (current run)\n"
                    "  - kodi/kodi.old.log    Previous Kodi session log (if available)\n"
                    "  - addon/debug.log      Always-on MultiTrailer rolling log (current)\n"
                    "  - addon/debug.log.1    Previous rollover (if available)\n"
                    "  - multitrailer_filtered.log  kodi.log lines mentioning MultiTrailer\n"
                    "\n"
                    "Note: log files may contain URLs / timestamps / channel ids.\n"
                    "They do NOT contain login credentials.\n")
            except Exception:
                pass
        wlog("Debug bundle written to " + out_path)
        return out_path
    except Exception:
        wexc("build_debug_bundle failed")
        return None

def download_debug_bundle(show_ui: bool = True) -> str | None:
    wlog("download_debug_bundle: starting")
    path = build_debug_bundle()
    if not _HAS_KODI or not show_ui:
        return path
    try:
        if not path:
            xbmcgui.Dialog().notification(
                "MultiTrailer",
                "Failed to build debug bundle. See kodi.log.",
                xbmcgui.NOTIFICATION_ERROR, 5000)
            return None
        xbmcgui.Dialog().notification(
            "MultiTrailer",
            "Debug zip saved to Downloads",
            xbmcgui.NOTIFICATION_INFO, 5000)
        try:
            xbmcgui.Dialog().ok(
                "MultiTrailer - Debug Bundle Ready",
                "Saved to:\n[B]{}[/B]\n\n"
                "Attach this zip when reporting a bug.".format(path))
        except Exception:
            pass
    except Exception:
        wexc("download_debug_bundle UI failed")
    return path
try:
    wlog("module loaded (plugin.video.multitrailer debug channel active)")
except Exception:
    pass
