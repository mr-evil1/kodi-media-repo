from urllib.request import *

from ..compat_utils import passthrough_module

passthrough_module(__name__, 'urllib.request')
del passthrough_module


import os

if os.name == 'nt':
    import sys
    from urllib.request import getproxies_environment, getproxies_registry

    def getproxies_registry_patched():
        proxies = getproxies_registry()

        if sys.version_info < (3, 10, 5):
            for scheme in ('https', 'ftp'):
                if scheme in proxies and proxies[scheme].startswith(f'{scheme}://'):
                    proxies[scheme] = 'http' + proxies[scheme][len(scheme):]

        return proxies

    def getproxies():
        return getproxies_environment() or getproxies_registry_patched()

del os
