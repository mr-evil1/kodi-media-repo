from urllib import *

del request
from . import request

from ..compat_utils import passthrough_module

passthrough_module(__name__, 'urllib')
del passthrough_module
