# -*- coding: utf-8 -*-
# GitPlayGer 
# Copyright (c) 2026 Team IT('s) Possible. All rights reserved.
# Version 2026.10.16
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.video.gitplayger"


def _hunter_on():
    return xbmcaddon.Addon(ADDON_ID).getSetting("hunter_enabled") == "true"


def _ask_disclaimer():
    heading = "GitPlayGer — Haftungsausschluss"
    message = (
        "ACHTUNG: Dieser Bereich und das gesamte Addon sind nur zu Testzwecken gedacht!\n\n"
        "• Keine Garantie oder Haftung für Inhalte oder Verfügbarkeit.\n"
        "• Die Nutzung erfolgt komplett auf eigene Verantwortung (Selber schuld).\n\n"
        "Stimmst du diesen Bedingungen zu und möchtest fortfahren?"
    )
    return xbmcgui.Dialog().yesno(heading, message, yeslabel="Ja, ich stimme zu", nolabel="Nein / Abbrechen")


def _refresh():
    xbmc.executebuiltin("Container.Refresh()")
    xbmc.executebuiltin("Action(noop)")


class HunterMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self._state = _hunter_on()

    def onSettingsChanged(self):
        now = _hunter_on()
        if now == self._state:
            return

        if now:
            if _ask_disclaimer():
                self._state = True
                xbmcgui.Dialog().notification("GitPlayGer", "TV Hunter aktiviert", xbmcgui.NOTIFICATION_INFO, 2500)
            else:
                self._state = False
                xbmcaddon.Addon(ADDON_ID).setSetting("hunter_enabled", "false")
                xbmcgui.Dialog().notification("GitPlayGer", "Disclaimer abgelehnt – TV Hunter bleibt deaktiviert", xbmcgui.NOTIFICATION_WARNING, 3000)
        else:
            self._state = False
            xbmcgui.Dialog().notification("GitPlayGer", "TV Hunter deaktiviert", xbmcgui.NOTIFICATION_INFO, 2500)

        _refresh()


if __name__ == "__main__":
    monitor = HunterMonitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum des Autors.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.