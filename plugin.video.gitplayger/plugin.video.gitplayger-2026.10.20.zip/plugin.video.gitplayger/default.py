# -*- coding: utf-8 -*-
# GitPlayGer 
# Copyright (c) 2026 Team IT('s) Possible. All rights reserved.
# Version 2026.10.20
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
import sys
import os
import re
import time
import glob
import json
import zipfile
import threading
import urllib.parse
from urllib.parse import parse_qsl, urlencode
import urllib.request
import requests
import urllib3
from http.server import BaseHTTPRequestHandler, HTTPServer
from resources.lib import config
from resources.lib import hunter
import unicodedata
import xbmcgui
import xbmcplugin
import xbmc
import xbmcvfs
import xbmcaddon
import concurrent.futures
from resources.lib.gitplayger_api import GitPlayGer, get_cache_duration
from resources.lib.filter import ChannelFilter


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
DEFAULT_ICON = os.path.join(ADDON_PATH, 'icon.png')


target_dir = "/storage/emulated/0/GitPlayGer/M3U"
m3u_path = "/storage/emulated/0/GitPlayGer/M3U/GitPlayGer.m3u"
primary_epg = "/storage/emulated/0/GitPlayGer/guide.xml"
profile_dir = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
fallback_epg = os.path.join(profile_dir, "guide.xml")

epg_path = None

if xbmcvfs.exists(primary_epg):
    epg_path = primary_epg
elif xbmcvfs.exists(fallback_epg):
    epg_path = fallback_epg
else:
    epg_path = None
if epg_path:
    pass


PROXIES = []
use_proxies_enabled = False
dns_mode_manual = False
proxy_server_instance = None
proxy_server_thread = None
LOCAL_PROXY_PORT = 4022


def _auto_clean(val):
    if isinstance(val, str):
        cleaned = re.sub(r'[\U00010000-\U0010ffff]|[\u2600-\u27bf]|[\U0001f300-\U0001f5ff]|[\U0001f600-\U0001f64f]|[\U0001f680-\U0001f6ff]', '', val)
        cleaned = re.sub(r'^[^\w\säöüÄÖÜß]+', '', cleaned)
        return cleaned.strip()
    elif isinstance(val, dict):
        return {k: _auto_clean(v) for k, v in val.items()}
    elif isinstance(val, list):
        return [_auto_clean(v) for v in val]
    return val


_original_json_loads = json.loads

def _patched_json_loads(s, *args, **kwargs):
    result = _original_json_loads(s, *args, **kwargs)
    return _auto_clean(result)

json.loads = _patched_json_loads


def get_proxy_dir():
    proxy_dir = "/storage/emulated/0/GitPlayGer/proxy"
    if not xbmcvfs.exists(proxy_dir):
        xbmcvfs.mkdirs(proxy_dir)
    return proxy_dir


def load_proxies():
    p_list = []
    proxy_path = get_proxy_dir()
    if not os.path.exists(proxy_path): 
        return p_list    
    try:
        files = [f for f in os.listdir(proxy_path) if f.endswith(".txt")]
        for f in files:
            full_p = os.path.join(proxy_path, f)
            with open(full_p, 'r', encoding='utf-8', errors='ignore') as file:
                for line in file:
                    proxy = line.strip()
                    if proxy and ":" in proxy:
                        p_list.append({"http": f"http://{proxy}", "https": f"http://{proxy}"})
    except Exception as e:
        xbmc.log(f"[gitplayger] Proxy Load Error: {e}", xbmc.LOGERROR)
    return p_list


def update_proxies_from_web():
    progress = xbmcgui.DialogProgressBG()
    progress.create("GitPlayGer", "Lade frische Proxies aus dem Web...")
    try:
        proxy_dir = get_proxy_dir()
        elite_path = os.path.join(proxy_dir, "elite_proxies.txt")
        
        urls = [
            "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=5000&country=all&ssl=all&anonymity=elite",
            "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt"
        ]
        
        valid_proxies = []
        for url in urls:
            try:
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=10) as resp:
                    content = resp.read().decode('utf-8', errors='ignore')
                    lines = content.splitlines()
                    for line in lines:
                        p = line.strip()
                        if p and ":" in p and p not in valid_proxies:
                            valid_proxies.append(p)
            except Exception as e:
                xbmc.log(f"[gitplayger] Fehler beim Laden von {url}: {e}", xbmc.LOGERROR)
        
        if not valid_proxies:
            xbmcgui.Dialog().notification("GitPlayGer", "Keine Proxies im Web gefunden.", xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        progress.update(50, f"Teste {len(valid_proxies)} Proxies...")
        tested_elite = []
        
        def test_proxy(proxy_str):
            try:
                proxy_handler = urllib.request.ProxyHandler({'http': f"http://{proxy_str}", 'https': f"http://{proxy_str}"})
                opener = urllib.request.build_opener(proxy_handler)
                req = urllib.request.Request("http://httpbin.org/ip", headers={'User-Agent': 'Mozilla/5.0'})
                with opener.open(req, timeout=3) as resp:
                    if resp.status == 200:
                        return proxy_str
            except:
                pass
            return None

        with concurrent.futures.ThreadPoolExecutor(max_workers=30) as executor:
            futures = [executor.submit(test_proxy, p) for p in valid_proxies[:150]]
            for future in concurrent.futures.as_completed(futures):
                res = future.result()
                if res:
                    tested_elite.append(res)

        if tested_elite:
            with open(elite_path, 'w', encoding='utf-8') as f:
                for p in tested_elite:
                    f.write(f"{p}\n")
            xbmcgui.Dialog().notification("GitPlayGer", f"{len(tested_elite)} Elite-Proxies erfolgreich gespeichert!", xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            with open(elite_path, 'w', encoding='utf-8') as f:
                for p in valid_proxies[:50]:
                    f.write(f"{p}\n")
            xbmcgui.Dialog().notification("GitPlayGer", "Proxies gespeichert (ohne erfolgreichen Test-Filter).", xbmcgui.NOTIFICATION_INFO, 3000)
            
    except Exception as e:
        xbmc.log(f"[gitplayger] Web Proxy Error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("GitPlayGer", "Fehler beim Laden der Web-Proxies!", xbmcgui.NOTIFICATION_ERROR, 3000)
    finally:
        progress.close()
    xbmc.executebuiltin("Container.Refresh()")


def resolve_dns_doh(hostname):
    try:
        if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", hostname): 
            return hostname
            
        try:
            url = f"https://1.1.1.1/dns-query?name={hostname}&type=A"
            req = urllib.request.Request(url, headers={"Accept": "application/dns-json", "Host": "cloudflare-dns.com", "User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=3) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode('utf-8'))
                    if "Answer" in data:
                        for ans in data["Answer"]:
                            ip = str(ans.get("data", ""))
                            if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", ip):
                                return ip
        except Exception:
            pass

        try:
            url = f"https://dns.google/resolve?name={hostname}&type=A"
            req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=3) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode('utf-8'))
                    if "Answer" in data:
                        for ans in data["Answer"]:
                            ip = str(ans.get("data", ""))
                            if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", ip):
                                return ip
        except Exception:
            pass

        import socket
        return socket.gethostbyname(hostname)
    except Exception as e:
        xbmc.log(f"[gitplayger] DoH Resolver Error: {e}", xbmc.LOGDEBUG)
    return hostname


class KodiProxyHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_GET(self):
        try:
            target_url = urllib.parse.unquote(self.path[1:])
            if not target_url.startswith("http"):
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"Invalid URL")
                return

            req_headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
            
            proxy_dict = None
            global use_proxies_enabled, PROXIES
            if use_proxies_enabled and PROXIES:
                proxy_dict = random.choice(PROXIES) if isinstance(PROXIES, list) else None

            req = urllib.request.Request(target_url, headers=req_headers)
            
            if proxy_dict and "http" in proxy_dict:
                proxy_handler = urllib.request.ProxyHandler({'http': proxy_dict["http"], 'https': proxy_dict["https"]})
                opener = urllib.request.build_opener(proxy_handler)
                resp = opener.open(req, timeout=15)
            else:
                resp = urllib.request.urlopen(req, timeout=15)

            self.send_response(resp.status)
            for header, value in resp.headers.items():
                if header.lower() not in ['transfer-encoding', 'content-encoding']:
                    self.send_header(header, value)
            self.end_headers()
            
            while True:
                chunk = resp.read(8192)
                if not chunk:
                    break
                self.wfile.write(chunk)
        except Exception as e:
            xbmc.log(f"[gitplayger] ProxyHandler Error: {e}", xbmc.LOGERROR)
            try:
                self.send_response(502)
                self.end_headers()
            except:
                pass


def start_local_proxy_server():
    global proxy_server_instance, proxy_server_thread
    if proxy_server_instance:
        return
    try:
        server_address = ('127.0.0.1', LOCAL_PROXY_PORT)
        proxy_server_instance = HTTPServer(server_address, KodiProxyHandler)
        proxy_server_thread = threading.Thread(target=proxy_server_instance.serve_forever, daemon=True)
        proxy_server_thread.start()
        xbmc.log(f"[gitplayger] Lokaler HTTP-Proxy gestartet auf Port {LOCAL_PROXY_PORT}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[gitplayger] Konnte lokalen Proxy-Server nicht starten: {e}", xbmc.LOGERROR)


def apply_settings_to_globals():
    global use_proxies_enabled, PROXIES, dns_mode_manual
    
    try:
        p_mode = int(ADDON.getSettingInt("proxy_mode"))
    except:
        p_mode = 0

    if p_mode > 0:
        use_proxies_enabled = True
        PROXIES = load_proxies()
        if p_mode == 2:
            elite_path = os.path.join(get_proxy_dir(), "elite_proxies.txt")
            if os.path.exists(elite_path):
                filtered_proxies = []
                with open(elite_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        p = line.strip()
                        if p:
                            filtered_proxies.append({"http": f"http://{p}", "https": f"http://{p}"})
                if filtered_proxies:
                    PROXIES = filtered_proxies
        start_local_proxy_server()
    else:
        use_proxies_enabled = False
        PROXIES = []

    dns_setting = ADDON.getSetting("dns_mode")
    dns_mode_manual = (dns_setting == "true")


def _resolve_channel_metadata(stream_url):
    api = GitPlayGer(region="de")
    
    channels = api.get_channels()
    target = next((c for c in channels if c.get("url") == stream_url), None)
    if target:
        return target
        
    for i in range(1, 4):
        if ADDON.getSetting(f"custom_m3u_{i}_enabled") == "true":
            m3u_path = ADDON.getSetting(f"custom_m3u_{i}_url")
            if m3u_path and hasattr(api, '_parse_m3u'):
                try:
                    if os.path.exists(m3u_path):
                        with open(m3u_path, 'r', encoding='utf-8', errors='ignore') as cf:
                            content = cf.read()
                    else:
                        req = urllib.request.Request(m3u_path, headers={'User-Agent': 'Mozilla/5.0'})
                        with urllib.request.urlopen(req, timeout=10) as resp:
                            content = resp.read().decode('utf-8', errors='ignore')
                    custom_channels = api._parse_m3u(content, f"Eigene M3U {i}")
                    target = next((c for c in custom_channels if c.get("url") == stream_url), None)
                    if target:
                        return target
                except Exception:
                    pass

    favorites = api.get_favorites()
    target = next((c for c in favorites if c.get("url") == stream_url), None)
    if target:
        return target

    return {"name": "Sender", "url": stream_url, "logo": "", "tvg_id": "", "genre": "Favoriten", "description": ""}


def _ask_disclaimer():
    heading = "GitPlayGer — Haftungsausschluss"
    message = (
        "ACHTUNG: Dieser Bereich und das gesamte Addon sind nur zu Testzwecken gedacht!\n\n"
        "• Keine Garantie oder Haftung für Inhalte oder Verfügbarkeit.\n"
        "• Die Nutzung erfolgt komplett auf eigene Verantwortung (Selber schuld).\n\n"
        "Stimmst du diesen Bedingungen zu und möchtest fortfahren?"
    )
    return xbmcgui.Dialog().yesno(heading, message, yeslabel="Ja, ich stimme zu", nolabel="Nein / Abbrechen")


def hunter_visible():
    return ADDON.getSetting("hunter_enabled") == "true"


def _refresh_everything():
    xbmc.executebuiltin("Container.Refresh()")
    xbmc.executebuiltin("Action(noop)")


def toggle_hunter():
    if ADDON.getSetting("hunter_enabled") == "true":
        ADDON.setSetting("hunter_enabled", "false")
        xbmcgui.Dialog().notification("GitPlayGer", "TV Hunter deaktiviert", xbmcgui.NOTIFICATION_INFO, 2500)
    else:
        if not _ask_disclaimer():
            xbmcgui.Dialog().notification("GitPlayGer", "Disclaimer abgelehnt – TV Hunter bleibt deaktiviert", xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        ADDON.setSetting("hunter_enabled", "true")
        xbmcgui.Dialog().notification("GitPlayGer", "TV Hunter aktiviert", xbmcgui.NOTIFICATION_INFO, 2500)
    _refresh_everything()


def check_disclaimer():
    if ADDON.getSetting("hunter_enabled") == "true":
        return True

    xbmcgui.Dialog().notification("GitPlayGer", "TV Hunter ist deaktiviert (Settings → Backup & Hunter)", xbmcgui.NOTIFICATION_WARNING, 3000)
    li_main = xbmcgui.ListItem(label='[B][COLOR cyan]« Zurück zum Hauptmenü[/COLOR][/B]')
    li_main.setArt({'icon': DEFAULT_ICON, 'thumb': DEFAULT_ICON, 'poster': DEFAULT_ICON})
    li_main.setInfo('video', {'title': 'TV Hunter deaktiviert', 'plot': 'TV Hunter ist deaktiviert. Aktivierung in den Settings.'})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=URL, listitem=li_main, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)
    sys.exit(0)


def get_dead_links_path():
    profile_dir = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not xbmcvfs.exists(profile_dir):
        xbmcvfs.mkdirs(profile_dir)
    return os.path.join(profile_dir, 'dead_links.json')


def load_dead_links():
    path = get_dead_links_path()
    if xbmcvfs.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    return []


def save_dead_links(dead_list):
    path = get_dead_links_path()
    try:
        existing = load_dead_links()
        existing_urls = {c.get("url") for c in existing if c.get("url")}
        
        updated = list(existing)
        for item in dead_list:
            u = item.get("url")
            if u and u not in existing_urls:
                updated.append(item)
                existing_urls.add(u)
                
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(updated, f, ensure_ascii=False, indent=4)
    except Exception as e:
        xbmc.log(f"[gitplayger] Fehler beim Speichern der toten Links: {e}", xbmc.LOGERROR)


def clear_dead_links_cache():
    path = get_dead_links_path()
    if xbmcvfs.exists(path):
        try:
            os.remove(path)
            xbmcgui.Dialog().notification("GitPlayGer", "Liste der toten Links geleert!", xbmcgui.NOTIFICATION_INFO, 2000)
        except Exception as e:
            xbmc.log(f"[gitplayger] Fehler beim Löschen der dead_links.json: {e}", xbmc.LOGERROR)
    else:
        xbmcgui.Dialog().notification("GitPlayGer", "Keine gespeicherten toten Links vorhanden.", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh()")


def clear_all_addon_data():
    if xbmcgui.Dialog().yesno(
        "GitPlayGer — Gefahrenzone",
        "Möchtest du wirklich alle Addon-Daten, Caches und Einstellungen komplett löschen?\n"
        "Das Addon wird danach auf den Ursprungszustand zurückgesetzt."
    ):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lösche alle Addon-Daten...")
        try:
            profile_dir = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
            if xbmcvfs.exists(profile_dir):
                dirs, files = xbmcvfs.listdir(profile_dir)
                for f in files:
                    xbmcvfs.delete(os.path.join(profile_dir, f))
            
            ADDON.setSetting("epg_url_enabled", "false")
            ADDON.setSetting("epg_local_enabled", "false")
            ADDON.setSetting("epg_auto_download", "false")
            ADDON.setSetting("epg_url", "")
            ADDON.setSetting("epg_local_path", "")
            ADDON.setSetting("hunter_enabled", "false")
            
            xbmcgui.Dialog().notification("GitPlayGer", "Alle Addon-Daten erfolgreich gelöscht!", xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as e:
            xbmc.log(f"[gitplayger] Fehler beim Löschen der Daten: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("GitPlayGer", "Fehler beim Löschen!", xbmcgui.NOTIFICATION_ERROR, 3000)
        finally:
            progress.close()
        xbmc.executebuiltin("Container.Update(plugin://plugin.video.gitplayger/, replace)")


def generate_gitplayger_m3u():
    progress = xbmcgui.DialogProgressBG()
    progress.create("GitPlayGer", "Generiere M3U-Export...")
    try:
        api = GitPlayGer(region="de")
        f_mgr = ChannelFilter()
        
        progress.update(30, "Lade Sender...")
        raw_channels = api.get_channels()
        
        for i in range(1, 4):
            if ADDON.getSetting(f"custom_m3u_{i}_enabled") == "true":
                m3u_path_setting = ADDON.getSetting(f"custom_m3u_{i}_url")
                if m3u_path_setting and hasattr(api, '_parse_m3u'):
                    try:
                        if os.path.exists(m3u_path_setting):
                            with open(m3u_path_setting, 'r', encoding='utf-8', errors='ignore') as cf:
                                content = cf.read()
                        else:
                            req = urllib.request.Request(m3u_path_setting, headers={'User-Agent': 'Mozilla/5.0'})
                            with urllib.request.urlopen(req, timeout=15) as resp:
                                content = resp.read().decode('utf-8', errors='ignore')
                        custom_channels = api._parse_m3u(content, f"Eigene M3U {i}")
                        if custom_channels:
                            raw_channels.extend(custom_channels)
                    except Exception as ce:
                        xbmc.log(f"[gitplayger] Fehler beim Laden der eigenen M3U {i} für Export: {ce}", xbmc.LOGERROR)

        progress.update(60, "Wende Filter an...")
        channels = f_mgr.apply_filters(raw_channels)
        
        if not channels:
            xbmcgui.Dialog().notification("GitPlayGer", "Keine Sender zum Exportieren gefunden.", xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        target_dir = "/storage/emulated/0/GitPlayGer/M3U"
        if not os.path.exists(target_dir):
            os.makedirs(target_dir, exist_ok=True)
            
        existing_files = os.listdir(target_dir)
        max_num = 0
        for f_name in existing_files:
            if f_name.startswith("GitPlayGer-") and f_name.endswith(".m3u"):
                num_str = f_name[11:-4]
                if num_str.isdigit():
                    num = int(num_str)
                    if num > max_num:
                        max_num = num
        
        next_num = max_num + 1
        file_name = f"GitPlayGer-{next_num:03d}.m3u"
        file_path = os.path.join(target_dir, file_name)
        base_file_path = os.path.join(target_dir, "GitPlayGer.m3u")

        progress.update(80, "Schreibe M3U-Datei...")
        
        content_lines = ["#EXTM3U\n"]
        for ch in channels:
            name = _auto_clean(ch.get("name", "Unbekannter Sender"))
            logo = ch.get("logo", "")
            tvg_id = ch.get("tvg_id", "")
            group = ch.get("genre", "Allgemein")
            url = ch.get("url", "")

            if use_proxies_enabled:
                url = f"http://127.0.0.1:{LOCAL_PROXY_PORT}/{urllib.parse.quote(url)}"

            extinf = f'#EXTINF:-1 tvg-id="{tvg_id}" tvg-logo="{logo}" group-title="{group}",{name}\n'
            content_lines.append(extinf)
            content_lines.append(f'{url}\n')
            
        for path in [file_path, base_file_path]:
            with open(path, 'w', encoding='utf-8') as f:
                f.writelines(content_lines)
                
        xbmcgui.Dialog().notification("GitPlayGer", "M3U erfolgreich erstellt!", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.log(f"[gitplayger] M3U exportiert nach: {file_path} und {base_file_path} ({len(channels)} Sender)", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[gitplayger] Fehler beim Erstellen der GitPlayGer.m3u: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("GitPlayGer", "Fehler beim M3U-Export!", xbmcgui.NOTIFICATION_ERROR, 4000)
    finally:
        progress.close()


def setup_iptv_simple_client():
    global epg_path
    pvr_id = "pvr.iptvsimple"

    try:
        pvr_addon = xbmcaddon.Addon(pvr_id)
    except Exception:
        if xbmcgui.Dialog().yesno(
            "GitPlayGer — IPTV Simple",
            "Der IPTV Simple Client ist nicht installiert.\n\n"
            "Möchtest du ihn jetzt installieren?"
        ):
            xbmc.executebuiltin(f"InstallAddon({pvr_id})")
            xbmcgui.Dialog().ok(
                "GitPlayGer",
                "Bitte die Installation in Kodi abschließen.\n\n"
                "Danach 'IPTV Simple Client automatisch einrichten' "
                "erneut auswählen."
            )
        return

    resolved_m3u_path = os.path.join(target_dir, "GitPlayGer.m3u")

    if not os.path.exists(resolved_m3u_path):
        try:
            generate_gitplayger_m3u()
        except Exception:
            pass

    if not os.path.exists(resolved_m3u_path):
        xbmcgui.Dialog().ok(
            "GitPlayGer",
            "Die M3U-Datei konnte nicht gefunden oder erstellt werden.\n\n"
            "Bitte zuerst 'M3U GitPlayGer.m3u exportieren' ausführen."
        )
        return
        
    if not xbmcgui.Dialog().yesno(
        "GitPlayGer — IPTV Simple einrichten",
        "Die Konfiguration für den IPTV Simple Client wird jetzt geschrieben.\n\n"
        "Damit die Kanäle und EPG-Daten fehlerfrei und ohne Altlasten geladen werden, "
        "ist im Anschluss ein kurzer Neustart von Kodi erforderlich.\n\n"
        "Möchtest du fortfahren?"
    ):
        return

    try:
        if not xbmcvfs.exists(epg_path):
            epg_path = ""

        profile_path = xbmcvfs.translatePath("special://profile/addon_data/pvr.iptvsimple/")
        if not xbmcvfs.exists(profile_path):
            xbmcvfs.mkdirs(profile_path)

        instance_settings_path = os.path.join(profile_path, "instance-settings-1.xml")
        settings_path = os.path.join(profile_path, "settings.xml")

        xml_content = f'''<settings version="2">
    <setting id="m3uPathType">0</setting>
    <setting id="m3uPath">{resolved_m3u_path}</setting>
    <setting id="m3uUrl" default="true" />
    <setting id="m3uCache" default="true">true</setting>
    <setting id="startNum" default="true">1</setting>
    <setting id="numberByOrder" default="true">false</setting>
    <setting id="m3uRefreshMode" default="true">0</setting>
    <setting id="m3uRefreshIntervalMins" default="true">60</setting>
    <setting id="m3uRefreshHour" default="true">4</setting>
    <setting id="defaultProviderName" default="true" />
    <setting id="enableProviderMappings" default="true">false</setting>
    <setting id="providerMappingFile" default="true">special://userdata/addon_data/pvr.iptvsimple/providers/providerMappings.xml</setting>
    <setting id="tvGroupMode" default="true">0</setting>
    <setting id="numTvGroups" default="true">1</setting>
    <setting id="oneTvGroup" default="true" />
    <setting id="twoTvGroup" default="true" />
    <setting id="threeTvGroup" default="true" />
    <setting id="fourTvGroup" default="true" />
    <setting id="fiveTvGroup" default="true" />
    <setting id="customTvGroupsFile" default="true">special://userdata/addon_data/pvr.iptvsimple/channelGroups/customTVGroups-example.xml</setting>
    <setting id="tvChannelGroupsOnly" default="true">false</setting>
    <setting id="radioGroupMode" default="true">0</setting>
    <setting id="numRadioGroups" default="true">1</setting>
    <setting id="oneRadioGroup" default="true" />
    <setting id="twoRadioGroup" default="true" />
    <setting id="threeRadioGroup" default="true" />
    <setting id="fourRadioGroup" default="true" />
    <setting id="fiveRadioGroup" default="true" />
    <setting id="customRadioGroupsFile" default="true">special://userdata/addon_data/pvr.iptvsimple/channelGroups/customRadioGroups-example.xml</setting>
    <setting id="radioChannelGroupsOnly" default="true">false</setting>
    <setting id="epgPathType">0</setting>
    <setting id="epgPath">{epg_path}</setting>
    <setting id="epgUrl" default="true" />
    <setting id="epgCache" default="true">true</setting>
    <setting id="epgTimeShift" default="true">0</setting>
    <setting id="epgTSOverride" default="true">false</setting>
    <setting id="epgIgnoreCaseForChannelIds" default="true">true</setting>
    <setting id="useEpgGenreText" default="true">false</setting>
    <setting id="genresPathType" default="true">0</setting>
    <setting id="genresPath" default="true">special://userdata/addon_data/pvr.iptvsimple/genres/genreTextMappings/genres.xml</setting>
    <setting id="genresUrl" default="true" />
    <setting id="logoPathType" default="true">1</setting>
    <setting id="logoPath" default="true" />
    <setting id="logoBaseUrl" default="true" />
    <setting id="useLogosLocalPathOnly" default="true">false</setting>
    <setting id="logoFromEpg" default="true">1</setting>
    <setting id="mediaEnabled" default="true">true</setting>
    <setting id="mediaGroupByTitle" default="true">true</setting>
    <setting id="mediaGroupBySeason" default="true">true</setting>
    <setting id="mediaTitleSeasonEpisode" default="true">false</setting>
    <setting id="mediaVODAsRecordings" default="true">true</setting>
    <setting id="timeshiftEnabled" default="true">false</setting>
    <setting id="timeshiftEnabledAll" default="true">true</setting>
    <setting id="timeshiftEnabledHttp" default="true">true</setting>
    <setting id="timeshiftEnabledUdp" default="true">true</setting>
    <setting id="timeshiftEnabledCustom" default="true">false</setting>
    <setting id="catchupEnabled" default="true">false</setting>
    <setting id="catchupQueryFormat" default="true" />
    <setting id="catchupDays" default="true">5</setting>
    <setting id="allChannelsCatchupMode" default="true">0</setting>
    <setting id="catchupOverrideMode" default="true">0</setting>
    <setting id="catchupCorrection" default="true">0</setting>
    <setting id="catchupPlayEpgAsLive" default="true">false</setting>
    <setting id="catchupWatchEpgBeginBufferMins" default="true">5</setting>
    <setting id="catchupWatchEpgEndBufferMins" default="true">15</setting>
    <setting id="catchupOnlyOnFinishedProgrammes" default="true">false</setting>
    <setting id="transformMulticastStreamUrls" default="true">false</setting>
    <setting id="udpxyHost" default="true">127.0.0.1</setting>
    <setting id="udpxyPort" default="true">4022</setting>
    <setting id="useFFmpegReconnect" default="true">true</setting>
    <setting id="useInputstreamAdaptiveforHls" default="true">false</setting>
    <setting id="defaultUserAgent" default="true" />
    <setting id="defaultInputstream" default="true" />
    <setting id="defaultMimeType" default="true" />
</settings>'''

        with open(settings_path, 'w', encoding='utf-8') as f:
            f.write(xml_content)
        with open(instance_settings_path, 'w', encoding='utf-8') as f:
            f.write(xml_content)
        
        if xbmcgui.Dialog().yesno(
            "GitPlayGer — Konfiguration erfolgreich",
            "Die M3U-Dateien und Einstellungen wurden erfolgreich geschrieben.\n\n"
            "Soll Kodi jetzt neu gestartet werden, damit der IPTV Simple Client frisch startet?"
        ):
            xbmc.executebuiltin("Quit")

    except Exception as e:
        xbmc.log(f"[gitplayger] Fehler beim automatischen PVR-Setup: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "GitPlayGer — Fehler",
            f"IPTV Simple konnte nicht eingerichtet werden:\n\n{e}"
        )

def list_genres():
    apply_settings_to_globals()
    api = GitPlayGer(region="de")
    f_mgr = ChannelFilter()
    
    fav_item = xbmcgui.ListItem(label="[B][COLOR powderblue][ Meine Favoriten & Themen ][/COLOR][/B]")
    fav_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    fav_item.setInfo("video", {"title": "Meine Favoriten & Themen", "plot": "Deine persönlich gespeicherten Lieblingssender und eigene Themen-Ordner."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=list_favorite_themes", listitem=fav_item, isFolder=True)

    alpha_item = xbmcgui.ListItem(label="[B][COLOR lightblue][ Sender von A bis Z ][/COLOR][/B]")
    alpha_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    alpha_item.setInfo("video", {"title": "Sender von A bis Z", "plot": "Wähle einen Anfangsbuchstaben aus, um Sender gezielt anzuzeigen."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=list_alphabet_index", listitem=alpha_item, isFolder=True)

    search_item = xbmcgui.ListItem(label="[B][COLOR skyblue][ Sender suchen... ][/COLOR][/B]")
    search_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    search_item.setInfo("video", {"title": "Sender suchen", "plot": "Durchsuche alle geladenen Playlisten nach Sendername."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=search_prompt", listitem=search_item, isFolder=False)

    epg_item = xbmcgui.ListItem(label="[B][COLOR lightskyblue][ Sender mit EPG ID ][/COLOR][/B]")
    epg_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    epg_item.setInfo("video", {"title": "Nur Sender mit EPG ID", "plot": "Zeigt ausschließlich Sender, die eine gültige EPG-ID besitzen."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=list_channels&filter=epg", listitem=epg_item, isFolder=True)

    kodinerds_item = xbmcgui.ListItem(label="[B][COLOR deepskyblue][ Kodinerds M3U IPTV ][/COLOR][/B]")
    kodinerds_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    kodinerds_item.setInfo("video", {"title": "Kodinerds IPTV", "plot": "Öffnet direkt die tagesaktuellen Playlisten von Kodinerds IPTV (jnk22)."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=list_kodinerds", listitem=kodinerds_item, isFolder=True)

    dead_item = xbmcgui.ListItem(label="[B][COLOR dodgerblue][ Nicht verfügbare Sender ][/COLOR][/B]")
    dead_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    dead_item.setInfo("video", {"title": "Nicht verfügbare Sender", "plot": "Sender, die beim Dead Link Cleaner als tot erkannt wurden."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=list_dead_channels", listitem=dead_item, isFolder=True)

    settings_item = xbmcgui.ListItem(label="[B][COLOR royalblue][ Playlist-Verwaltung & Einstellungen ][/COLOR][/B]")
    settings_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    settings_item.setInfo("video", {
        "title": "Playlist-Verwaltung & Einstellungen", 
        "plot": "Playlisten, Länder-Filter und Addon-Einstellungen verwalten."
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=settings_menu", listitem=settings_item, isFolder=True)

    index_file = os.path.join(api.profile_dir, "playlist_index.json")
    cache_valid = False
    if xbmcvfs.exists(index_file):
        try:
            with open(index_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            timestamp = data.get("timestamp", 0)
            cached_playlists = data.get("playlists", [])
            if cached_playlists and (time.time() - timestamp < get_cache_duration()):
                cache_valid = True
        except Exception:
            pass

    progress = xbmcgui.DialogProgressBG()
    progress.create("GitPlayGer", "Lade Sender und Playlisten...")
    progress.update(10, "Initialisiere Playlisten...")

    try:
        progress.update(40, "Lade Sender und Playlisten...")
        raw_channels = api.get_channels()

        for i in range(1, 4):
            if ADDON.getSetting(f"custom_m3u_{i}_enabled") == "true":
                m3u_path = ADDON.getSetting(f"custom_m3u_{i}_url")
                if m3u_path and hasattr(api, '_parse_m3u'):
                    try:
                        if os.path.exists(m3u_path):
                            with open(m3u_path, 'r', encoding='utf-8', errors='ignore') as cf:
                                content = cf.read()
                        else:
                            req = urllib.request.Request(m3u_path, headers={'User-Agent': 'Mozilla/5.0'})
                            with urllib.request.urlopen(req, timeout=15) as resp:
                                content = resp.read().decode('utf-8', errors='ignore')
                        custom_channels = api._parse_m3u(content, f"Eigene M3U {i}")
                        if custom_channels:
                            raw_channels.extend(custom_channels)
                    except Exception as ce:
                        xbmc.log(f"[gitplayger] Fehler beim Laden der eigenen M3U {i}: {ce}", xbmc.LOGERROR)

        progress.update(70, "Wende Filter und EPG-Abgleich an...")
        raw_count = len(raw_channels)
        channels = f_mgr.apply_filters(raw_channels)
        filtered_out_count = raw_count - len(channels)
        progress.update(100, "Fertig!")
    finally:
        progress.close()        

    xbmc.log(f"[gitplayger] Sender nach Filtern eingelesen: {len(channels)} (Gefiltert/Entfernt: {filtered_out_count})", xbmc.LOGINFO)

    if not channels:
        error_item = xbmcgui.ListItem(label="[B][COLOR deeppink] [ Keine Sender erreichbar! ][/COLOR][/B]")
        error_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        error_item.setInfo("video", {"title": "Fehler", "plot": "Keine Sender entsprechen den aktiven Qualitäts- oder Länderfiltern."})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=empty", listitem=error_item, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    q_setting = ADDON.getSettingInt("quality_filter")
    filter_names = {0: "Alle", 1: "UHD/4K", 2: "FHD", 3: "HD", 4: "SD"}
    current_filter_name = filter_names.get(q_setting, "Alle")

    item_all = xbmcgui.ListItem(label=f"[B][COLOR mediumturquoise][ Alle Sender: [/COLOR][COLOR silver]{len(channels)}[/COLOR]  [COLOR mediumturquoise]|   Filter:  [/COLOR][COLOR silver]{current_filter_name}[/COLOR] [COLOR mediumturquoise] ][/COLOR][/B]")
    item_all.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_all.setInfo("video", {
        "title": "Alle Sender", 
        "plot": f"Gesamt in Playlisten: {raw_count} | Ausgeschlossen durch Filter: {filtered_out_count}\nVerbleibende aktive Sender (Qualität: {current_filter_name}): {len(channels)}"
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=list_channels&genre=all", listitem=item_all, isFolder=True)

    item_refresh = xbmcgui.ListItem(label="[B][COLOR lightseagreen][ Sender & EPG aktualisieren ][/COLOR][/B]")
    item_refresh.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_refresh.setInfo("video", {"title": "Sender & EPG aktualisieren", "plot": "Aktualisiert ausschließlich die Sender und EPG-Daten."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=refresh_epg", listitem=item_refresh, isFolder=False)

    item_cat = xbmcgui.ListItem(label="[B][COLOR mediumaquamarine][ ▼  ▼ Kategorien ▼  ▼ ][/COLOR][/B]")
    item_cat.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_cat.setInfo("video", {
        "title": "Kategorien", 
        "plot": "Kategorien"
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=dummy", listitem=item_cat, isFolder=False)

    genres = sorted(list(set(c["genre"] for c in channels if c.get("genre"))))
    for genre in genres:
        genre_count = sum(1 for c in channels if c.get("genre") == genre)
        list_item = xbmcgui.ListItem(label=f"[B][COLOR gold][ ♦ ][/COLOR]  [COLOR white]{genre}[/COLOR]  [COLOR darkgray]({genre_count} Sender)[/COLOR][/B]")
        list_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        list_item.setInfo("video", {"title": genre, "plot": f"Sender in Kategorie {genre} ({genre_count} Sender nach Abzug aller aktiven Filter)"})
        item_url = f"{URL}?action=list_channels&genre={genre}"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=item_url, listitem=list_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(HANDLE)


def list_channels(genre="all", search_query=None, filter_type=None):
    api = GitPlayGer(region="de")
    f_mgr = ChannelFilter()
    raw_channels = api.get_channels()
    
    for i in range(1, 4):
        if ADDON.getSetting(f"custom_m3u_{i}_enabled") == "true":
            m3u_path = ADDON.getSetting(f"custom_m3u_{i}_url")
            if m3u_path and hasattr(api, '_parse_m3u'):
                try:
                    if os.path.exists(m3u_path):
                        with open(m3u_path, 'r', encoding='utf-8', errors='ignore') as cf:
                            content = cf.read()
                    else:
                        req = urllib.request.Request(m3u_path, headers={'User-Agent': 'Mozilla/5.0'})
                        with urllib.request.urlopen(req, timeout=15) as resp:
                            content = resp.read().decode('utf-8', errors='ignore')
                    custom_channels = api._parse_m3u(content, f"Eigene M3U {i}")
                    if custom_channels:
                        raw_channels.extend(custom_channels)
                except Exception as ce:
                    xbmc.log(f"[gitplayger] Fehler beim Laden der eigenen M3U {i} in list_channels: {ce}", xbmc.LOGERROR)

    channels = f_mgr.apply_filters(raw_channels)

    if search_query:
        query = search_query.lower()
        channels = [c for c in channels if query in c.get("name", "").lower()]
    elif filter_type == "epg":
        channels = [c for c in channels if c.get("tvg_id")]
    elif genre != "all":
        channels = [c for c in channels if c.get("genre") == genre]

    if not channels:
        item = xbmcgui.ListItem(label="Keine Sender in dieser Kategorie gefunden.")
        item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=empty", listitem=item, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for channel in channels:
        name = _auto_clean(channel.get("name", "Unbekannter Sender"))
        logo = channel.get("logo", "") or DEFAULT_ICON
        desc = channel.get("description", "Keine EPG-Informationen verfügbar.")
        stream_url = channel["url"]
        tvg_id = channel.get("tvg_id", "")

        display_name = f"[COLOR white]{name}[/COLOR]"
        if tvg_id:
            display_name = f"[COLOR white]{name}[/COLOR]  [COLOR gray][EPG][/COLOR]"
        list_item = xbmcgui.ListItem(label=display_name)
        list_item.setArt({"icon": logo, "thumb": logo, "poster": logo})
        if tvg_id:
            list_item.setProperty('tvg_id', tvg_id)
            
        info = list_item.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(desc)
        list_item.setProperty('IsPlayable', 'true')

        is_fav = api.is_favorite(stream_url)
        fav_label = "Aus Favoriten entfernen" if is_fav else "Zu Favoriten hinzufügen"
        fav_action = f"RunPlugin({URL}?action=toggle_favorite&url={urllib.parse.quote_plus(stream_url)})"
        theme_action = f"RunPlugin({URL}?action=assign_channel_to_theme_prompt&url={urllib.parse.quote_plus(stream_url)})"
        test_action = f"RunPlugin({URL}?action=test_stream&url={urllib.parse.quote_plus(stream_url)})"

        list_item.addContextMenuItems([
            (fav_label, fav_action),
            ("Zu einem Thema hinzufügen...", theme_action),
            ("Stream auf Verfügbarkeit testen", test_action)
        ])

        params = {"action": "play", "url": stream_url}
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?{urlencode(params)}", listitem=list_item, isFolder=False)

    top_item = xbmcgui.ListItem(label="[B][COLOR cyan]▲ Zum Seitenanfang ▲[/COLOR][/B]")
    top_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    top_item.setInfo("video", {"title": "Zum Seitenanfang", "plot": "Springt direkt zum ersten Eintrag dieser Liste."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=scroll_top", listitem=top_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def list_alphabet_index():
    api = GitPlayGer(region="de")
    f_mgr = ChannelFilter()
    raw_channels = api.get_channels()
    
    for i in range(1, 4):
        if ADDON.getSetting(f"custom_m3u_{i}_enabled") == "true":
            m3u_path = ADDON.getSetting(f"custom_m3u_{i}_url")
            if m3u_path and hasattr(api, '_parse_m3u'):
                try:
                    if os.path.exists(m3u_path):
                        with open(m3u_path, 'r', encoding='utf-8', errors='ignore') as cf:
                            content = cf.read()
                    else:
                        req = urllib.request.Request(m3u_path, headers={'User-Agent': 'Mozilla/5.0'})
                        with urllib.request.urlopen(req, timeout=15) as resp:
                            content = resp.read().decode('utf-8', errors='ignore')
                    custom_channels = api._parse_m3u(content, f"Eigene M3U {i}")
                    if custom_channels:
                        raw_channels.extend(custom_channels)
                except Exception:
                    pass

    channels = f_mgr.apply_filters(raw_channels)
    
    chars = set()
    for ch in channels:
        name = ch.get("name", "").strip()
        if name:
            first_char = name[0].upper()
            if first_char.isalnum():
                if first_char.isdigit():
                    chars.add("#")
                else:
                    chars.add(first_char)
            else:
                chars.add("#")
                
    item_hash = xbmcgui.ListItem(label="[B][COLOR gold]#[/COLOR]  [COLOR white](Zahlen & Sonderzeichen)[/COLOR][/B]")
    item_hash.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=list_channels_by_char&char=HASH", listitem=item_hash, isFolder=True)

    for letter in sorted([c for c in chars if c != "#"]):
        count = sum(1 for ch in channels if ch.get("name", "").strip().upper().startswith(letter))
        item = xbmcgui.ListItem(label=f"[B][COLOR gold]{letter}[/COLOR]  [COLOR silver]({count} Sender)[/COLOR][/B]")
        item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=list_channels_by_char&char={letter}", listitem=item, isFolder=True)
    
    xbmcplugin.endOfDirectory(HANDLE)


def list_channels_by_char(char):
    api = GitPlayGer(region="de")
    f_mgr = ChannelFilter()
    raw_channels = api.get_channels()
    
    for i in range(1, 4):
        if ADDON.getSetting(f"custom_m3u_{i}_enabled") == "true":
            m3u_path = ADDON.getSetting(f"custom_m3u_{i}_url")
            if m3u_path and hasattr(api, '_parse_m3u'):
                try:
                    if os.path.exists(m3u_path):
                        with open(m3u_path, 'r', encoding='utf-8', errors='ignore') as cf:
                            content = cf.read()
                    else:
                        req = urllib.request.Request(m3u_path, headers={'User-Agent': 'Mozilla/5.0'})
                        with urllib.request.urlopen(req, timeout=15) as resp:
                            content = resp.read().decode('utf-8', errors='ignore')
                    custom_channels = api._parse_m3u(content, f"Eigene M3U {i}")
                    if custom_channels:
                        raw_channels.extend(custom_channels)
                except Exception:
                    pass

    channels = f_mgr.apply_filters(raw_channels)
    channels = sorted(channels, key=lambda x: x.get("name", "").lower())

    count = 0
    for channel in channels:
        name = channel.get("name", "").strip()
        if not name:
            continue
        first_char = name[0].upper()
        
        if char == "HASH":
            if first_char.isalnum() and not first_char.isdigit():
                continue
        else:
            if first_char != char:
                continue

        logo = channel.get("logo", "") or DEFAULT_ICON
        desc = channel.get("description", "Keine EPG-Informationen verfügbar.")
        stream_url = channel["url"]
        tvg_id = channel.get("tvg_id", "")

        display_name = "[COLOR white]" + name + "[/COLOR]"
        if tvg_id:
            display_name = "[COLOR white]" + name + "[/COLOR]  [COLOR gray][EPG][/COLOR]"
        list_item = xbmcgui.ListItem(label=display_name)
        list_item.setArt({"icon": logo, "thumb": logo, "poster": logo})
        if tvg_id:
            list_item.setProperty('tvg_id', tvg_id)
            
        info = list_item.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(desc)
        list_item.setProperty('IsPlayable', 'true')

        is_fav = api.is_favorite(stream_url)
        fav_label = "Aus Favoriten entfernen" if is_fav else "Zu Favoriten hinzufügen"
        fav_action = f"RunPlugin({URL}?action=toggle_favorite&url={urllib.parse.quote_plus(stream_url)})"
        theme_action = f"RunPlugin({URL}?action=assign_channel_to_theme_prompt&url={urllib.parse.quote_plus(stream_url)})"
        test_action = f"RunPlugin({URL}?action=test_stream&url={urllib.parse.quote_plus(stream_url)})"

        list_item.addContextMenuItems([
            (fav_label, fav_action),
            ("Zu einem Thema hinzufügen...", theme_action),
            ("Stream auf Verfügbarkeit testen", test_action)
        ])

        params = {"action": "play", "url": stream_url}
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?{urlencode(params)}", listitem=list_item, isFolder=False)
        count += 1

    if count > 0:
        top_item = xbmcgui.ListItem(label="[B][COLOR cyan]▲ Zum Seitenanfang ▲[/COLOR][/B]")
        top_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        top_item.setInfo("video", {"title": "Zum Seitenanfang", "plot": "Springt direkt zum ersten Eintrag dieser Liste."})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=scroll_top", listitem=top_item, isFolder=False)
    else:
        xbmcgui.Dialog().notification("GitPlayGer", "Keine Sender für diesen Buchstaben gefunden.", xbmcgui.NOTIFICATION_WARNING, 2000)

    xbmcplugin.endOfDirectory(HANDLE)


def list_favorite_themes():
    api = GitPlayGer(region="de")
    
    fav_all_item = xbmcgui.ListItem(label="[COLOR gold]★ Alle Favoriten (Standard) ★[/COLOR]")
    fav_all_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    fav_all_item.setInfo("video", {"title": "Alle Favoriten", "plot": "Alle als Favorit markierten Sender auf einen Blick."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=list_favorites", listitem=fav_all_item, isFolder=True)

    new_theme_item = xbmcgui.ListItem(label="[COLOR cyan]+ Neues Thema erstellen...[/COLOR]")
    new_theme_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    new_theme_item.setInfo("video", {"title": "Neues Thema erstellen", "plot": "Erstelle einen neuen Themen-Ordner über die Onscreen-Tastatur."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=create_theme_prompt", listitem=new_theme_item, isFolder=False)

    themes = api.get_favorite_themes()
    for theme_name in sorted(themes.keys()):
        count = len(themes[theme_name])
        item = xbmcgui.ListItem(label=f"[COLOR gold] Favoriten [/COLOR]  [COLOR white]{theme_name}[/COLOR]  [COLOR silver]({count} Sender)[/COLOR]")
        item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        item.setInfo("video", {"title": theme_name, "plot": f"Themen-Ordner: {theme_name} mit {count} Sendern."})
        
        del_action = f"RunPlugin({URL}?action=delete_theme&theme={urllib.parse.quote_plus(theme_name)})"
        item.addContextMenuItems([
            ("Thema löschen", del_action)
        ])
        
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=list_channels_in_theme&theme={urllib.parse.quote_plus(theme_name)}", listitem=item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def create_theme_prompt():
    keyboard = xbmc.Keyboard('', 'Themen-Name eingeben (z.B. Sport, Nachrichten)')
    keyboard.doModal()
    if keyboard.isConfirmed():
        theme_name = keyboard.getText().strip()
        if theme_name:
            api = GitPlayGer(region="de")
            api.create_favorite_theme(theme_name)
            xbmcgui.Dialog().notification("GitPlayGer", f"Thema '{theme_name}' erstellt!", xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.executebuiltin("Container.Refresh()")


def delete_theme(theme_name):
    if xbmcgui.Dialog().yesno("GitPlayGer", f"Möchtest du das Thema '{theme_name}' wirklich löschen?"):
        api = GitPlayGer(region="de")
        api.delete_favorite_theme(theme_name)
        xbmcgui.Dialog().notification("GitPlayGer", "Thema gelöscht!", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh()")


def assign_channel_to_theme_prompt(stream_url):
    api = GitPlayGer(region="de")
    themes = api.get_favorite_themes()
    theme_names = sorted(list(themes.keys()))
    
    if not theme_names:
        if xbmcgui.Dialog().yesno("GitPlayGer", "Es existieren noch keine Themen. Jetzt ein neues Thema per Tastatur erstellen?"):
            keyboard = xbmc.Keyboard('', 'Neues Thema eingeben')
            keyboard.doModal()
            if keyboard.isConfirmed():
                t_name = keyboard.getText().strip()
                if t_name:
                    api.create_favorite_theme(t_name)
                    theme_names = [t_name]
                else:
                    return
        else:
            return

    selected_idx = xbmcgui.Dialog().select("Wähle ein Thema aus", theme_names)
    if selected_idx >= 0:
        chosen_theme = theme_names[selected_idx]
        target_channel = _resolve_channel_metadata(stream_url)
        
        if target_channel:
            api.add_channel_to_theme(chosen_theme, target_channel)
            xbmcgui.Dialog().notification("GitPlayGer", f"Sender zu '{chosen_theme}' hinzugefügt!", xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            xbmcgui.Dialog().notification("GitPlayGer", "Sender konnte nicht gefunden werden.", xbmcgui.NOTIFICATION_ERROR, 2000)
            

def list_channels_in_theme(theme_name):
    api = GitPlayGer(region="de")
    themes = api.get_favorite_themes()
    channels = themes.get(theme_name, [])

    if not channels:
        item = xbmcgui.ListItem(label="Keine Sender in diesem Thema gespeichert.")
        item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=empty", listitem=item, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for channel in channels:
        name = channel["name"]
        logo = channel.get("logo", "") or DEFAULT_ICON
        desc = channel.get("description", "")
        stream_url = channel["url"]
        
        list_item = xbmcgui.ListItem(label=name)
        list_item.setArt({"icon": logo, "thumb": logo, "poster": logo})
        list_item.setInfo("video", {"title": name, "plot": desc, "genre": theme_name})
        list_item.setProperty('IsPlayable', 'true')
        
        remove_action = f"RunPlugin({URL}?action=remove_from_theme&theme={urllib.parse.quote_plus(theme_name)}&url={urllib.parse.quote_plus(stream_url)})"
        test_action = f"RunPlugin({URL}?action=test_stream&url={urllib.parse.quote_plus(stream_url)})"
        
        list_item.addContextMenuItems([
            ("Aus diesem Thema entfernen", remove_action),
            ("Stream auf Verfügbarkeit testen", test_action)
        ])
        
        params = {"action": "play", "url": stream_url}
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?{urlencode(params)}", listitem=list_item, isFolder=False)
        
    top_item = xbmcgui.ListItem(label="[B][COLOR cyan]▲ Zum Seitenanfang ▲[/COLOR][/B]")
    top_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    top_item.setInfo("video", {"title": "Zum Seitenanfang", "plot": "Springt direkt zum ersten Eintrag dieser Liste."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=scroll_top", listitem=top_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def remove_from_theme(theme_name, stream_url):
    api = GitPlayGer(region="de")
    api.remove_channel_from_theme(theme_name, stream_url)
    xbmcgui.Dialog().notification("GitPlayGer", "Sender aus Thema entfernt!", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh()")


def list_kodinerds():
    progress = xbmcgui.DialogProgressBG()
    progress.create("GitPlayGer", "Durchsuche Kodinerds Unterverzeichnisse...")
    
    playlists = []
    try:
        api_url = "https://api.github.com/repos/jnk22/kodinerds-iptv/git/trees/master?recursive=1"
        req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0', 'Accept': 'application/vnd.github+json'})
        with urllib.request.urlopen(req, timeout=15) as response:
            data = json.loads(response.read().decode('utf-8'))
            
        tree = data.get("tree", [])
        for item in tree:
            path = item.get("path", "")
            if path.endswith(".m3u"):
                name = path.split("/")[-1].replace(".m3u", "").upper()
                folder_path = "/".join(path.split("/")[:-1])
                display_name = f"Kodinerds [{folder_path}] — {name}" if folder_path else f"Kodinerds — {name}"
                
                raw_url = f"https://raw.githubusercontent.com/jnk22/kodinerds-iptv/master/{path}"
                playlists.append({"name": display_name, "url": raw_url})
                
    except Exception as e:
        xbmc.log(f"[gitplayger] Fehler beim Scannen der Kodinerds-Ordner: {e}", xbmc.LOGERROR)
    finally:
        progress.close()

    if not playlists:
        xbmcgui.Dialog().notification("GitPlayGer", "Keine Kodinerds M3Us gefunden.", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for pl in playlists:
        list_item = xbmcgui.ListItem(label=pl["name"])
        list_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        list_item.setInfo("video", {"title": pl["name"], "plot": f"Online M3U-Quelle von Kodinerds: {pl['url']}"})
        
        item_url = f"{URL}?action=load_kodinerds_playlist&url={urllib.parse.quote_plus(pl['url'])}"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=item_url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def load_kodinerds_playlist(playlist_url):
    api = GitPlayGer(region="de")
    f_mgr = ChannelFilter()
    
    progress = xbmcgui.DialogProgressBG()
    progress.create("GitPlayGer", "Lade Kodinerds Playlist...")
    try:
        req = urllib.request.Request(playlist_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as response:
            content = response.read().decode('utf-8', errors='ignore')
        
        raw_channels = api._parse_m3u(content, "Kodinerds")
        channels = f_mgr.apply_filters(raw_channels)
    except Exception as e:
        xbmc.log(f"[gitplayger] Fehler beim Laden der Kodinerds M3U: {e}", xbmc.LOGERROR)
        channels = []
    finally:
        progress.close()

    if not channels:
        xbmcgui.Dialog().notification("GitPlayGer", "Keine Sender in dieser Playlist gefunden.", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for channel in channels:
        name = channel["name"]
        logo = channel.get("logo", "") or DEFAULT_ICON
        desc = channel.get("description", "Keine EPG-Informationen verfügbar.")
        stream_url = channel["url"]
        tvg_id = channel.get("tvg_id", "")
        
        list_item = xbmcgui.ListItem(label=name)
        list_item.setArt({"icon": logo, "thumb": logo, "poster": logo})
        if tvg_id:
            list_item.setProperty('tvg_id', tvg_id)
            
        info = list_item.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(desc)
        list_item.setProperty('IsPlayable', 'true')
        
        params = {"action": "play", "url": stream_url}
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?{urlencode(params)}", listitem=list_item, isFolder=False)

    top_item = xbmcgui.ListItem(label="[B][COLOR cyan]▲ Zum Seitenanfang ▲[/COLOR][/B]")
    top_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    top_item.setInfo("video", {"title": "Zum Seitenanfang", "plot": "Springt direkt zum ersten Eintrag dieser Liste."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=scroll_top", listitem=top_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def settings_menu():
    item_addon_settings = xbmcgui.ListItem(label="[B][COLOR crimson][ Addon-Einstellungen öffnen ][/COLOR][/B]")
    item_addon_settings.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_addon_settings.setInfo("video", {
        "title": "Addon-Einstellungen", 
        "plot": "Öffnet die Kodi-Einstellungsmaske des Addons (für Qualitätsfilter etc.)."
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=open_settings", listitem=item_addon_settings, isFolder=False)

    item_web_proxies = xbmcgui.ListItem(label="[B][COLOR orange][ Frische Proxies aus dem Web laden & testen ][/COLOR][/B]")
    item_web_proxies.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_web_proxies.setInfo("video", {
        "title": "Web-Proxies aktualisieren", 
        "plot": "Lädt öffentliche Proxy-Quellen herunter, filtert funktionierende Proxies und speichert sie als Elite-Proxies."
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=update_web_proxies", listitem=item_web_proxies, isFolder=False)

    item_countries = xbmcgui.ListItem(label="[B][COLOR powderblue][ Länder-Filter verwalten ][/COLOR][/B]")
    item_countries.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_countries.setInfo("video", {
        "title": "Länder-Filter verwalten", 
        "plot": "Einzelne Länder (DE, AT, CH, TR etc.) aktivieren oder deaktivieren."
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=manage_countries", listitem=item_countries, isFolder=True)

    item_regen = xbmcgui.ListItem(label="[B][COLOR lightblue][ Alle Playlisten neu suchen / erzeugen ][/COLOR][/B]")
    item_regen.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_regen.setInfo("video", {
        "title": "Alle Playlisten neu erzeugen", 
        "plot": "Löscht den Index und startet die GitHub-Suche komplett neu."
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=regenerate_all", listitem=item_regen, isFolder=False)

    item_manage = xbmcgui.ListItem(label="[B][COLOR lightskyblue][ Gefundene Playlisten verwalten ][/COLOR][/B]")
    item_manage.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_manage.setInfo("video", {
        "title": "Gefundene Playlisten verwalten", 
        "plot": "Einzelne Playlisten aktivieren, deaktivieren oder löschen."
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=manage_playlists", listitem=item_manage, isFolder=True)

    item_test_batch = xbmcgui.ListItem(label="[B][COLOR deepskyblue][ Alle Sender auf Erreichbarkeit testen - (Dead Link Cleaner) ][/COLOR][/B]")
    item_test_batch.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_test_batch.setInfo("video", {
        "title": "Batch-Stream-Tester", 
        "plot": "Testet alle aktuell geladenen Sender der Reihe nach und prüft deren Erreichbarkeit."
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=batch_test_streams", listitem=item_test_batch, isFolder=False)

    item_export_m3u = xbmcgui.ListItem(label="[B][COLOR dodgerblue][ M3U GitPlayGer.m3u exportieren ][/COLOR][/B]")
    item_export_m3u.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_export_m3u.setInfo("video", {
        "title": "M3U Exportieren", 
        "plot": "Führt alle gefilterten Sender (ohne Blacklist) zusammen und speichert sie als GitPlayGer.m3u unter /storage/emulated/0/GitPlayGer/M3U."
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=generate_gitplayger_m3u", listitem=item_export_m3u, isFolder=False)

    item_setup_pvr = xbmcgui.ListItem(label="[B][COLOR royalblue][ IPTV Simple Client automatisch einrichten ][/COLOR][/B]")
    item_setup_pvr.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_setup_pvr.setInfo("video", {
        "title": "IPTV Simple Client einrichten", 
        "plot": "Verknüpft die generierte M3U und den EPG-Guide direkt mit dem IPTV Simple Client PVR-Addon."
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=setup_pvr", listitem=item_setup_pvr, isFolder=False)

    if hunter_visible():
        item_hunter = xbmcgui.ListItem(label="[B][COLOR orange][ Hunter-Modus öffnen ][/COLOR][/B]")
        item_hunter.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        item_hunter.setInfo("video", {
            "title": "Hunter-Modus", 
            "plot": "Öffnet den Hunter, um nach speziellen Streams oder Inhalten zu suchen."
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=open_hunter", listitem=item_hunter, isFolder=True)

    item_backup = xbmcgui.ListItem(label="[B][COLOR greenyellow][ Backup aller Daten erstellen ][/COLOR][/B]")
    item_backup.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_backup.setInfo("video", {
        "title": "Backup erstellen", 
        "plot": "Sichert alle Addon-Daten (Einstellungen, Cache, Favoriten) nach /storage/emulated/0/GitPlayGer/gitplayger_backup.zip."
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=backup_data", listitem=item_backup, isFolder=False)

    item_restore = xbmcgui.ListItem(label="[B][COLOR greenyellow][ Daten wiederherstellen ][/COLOR][/B]")
    item_restore.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_restore.setInfo("video", {
        "title": "Daten wiederherstellen", 
        "plot": "Stellt Addon-Daten aus /storage/emulated/0/GitPlayGer/gitplayger_backup.zip wieder her."
    })
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=restore_data", listitem=item_restore, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def batch_test_streams():
    api = GitPlayGer(region="de")
    f_mgr = ChannelFilter()
    
    raw_channels = api.get_channels()
    for i in range(1, 4):
        if ADDON.getSetting(f"custom_m3u_{i}_enabled") == "true":
            m3u_path = ADDON.getSetting(f"custom_m3u_{i}_url")
            if m3u_path and hasattr(api, '_parse_m3u'):
                try:
                    if os.path.exists(m3u_path):
                        with open(m3u_path, 'r', encoding='utf-8', errors='ignore') as cf:
                            content = cf.read()
                    else:
                        req = urllib.request.Request(m3u_path, headers={'User-Agent': 'Mozilla/5.0'})
                        with urllib.request.urlopen(req, timeout=15) as resp:
                            content = resp.read().decode('utf-8', errors='ignore')
                    custom_channels = api._parse_m3u(content, f"Eigene M3U {i}")
                    if custom_channels:
                        raw_channels.extend(custom_channels)
                except Exception:
                    pass

    channels = f_mgr.apply_filters(raw_channels)
    
    if not channels:
        xbmcgui.Dialog().notification("GitPlayGer", "Keine Sender zum Testen vorhanden.", xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    total = len(channels)
    new_dead_channels = []
    working_count = 0
    
    progress = xbmcgui.DialogProgress()
    progress.create("GitPlayGer — Turbo Batch-Stream-Test", f"Teste {total} Sender mit Multi-Threading...")
    
    try:
        max_workers = int(ADDON.getSetting("batch_workers") or 20)
    except Exception:
        max_workers = 20
    max_workers = max(20, min(100, max_workers))

    completed = 0
    
    def test_single_stream(channel):
        stream_url = channel.get("url", "")
        is_working = False
        req_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        
        try:
            if hasattr(api, 'test_stream'):
                success, _ = api.test_stream(stream_url)
                is_working = success
            else:
                try:
                    req = urllib.request.Request(stream_url, headers=req_headers, method='HEAD')
                    with urllib.request.urlopen(req, timeout=2.5) as resp:
                        if resp.status < 400:
                            is_working = True
                except Exception:
                    try:
                        req = urllib.request.Request(stream_url, headers=req_headers)
                        with urllib.request.urlopen(req, timeout=2.5) as resp:
                            if resp.status < 400:
                                is_working = True
                    except Exception:
                        is_working = False
        except Exception:
            is_working = False
            
        return channel, is_working

    executor = concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
    try:
        future_to_channel = {executor.submit(test_single_stream, ch): ch for ch in channels}
        
        for future in concurrent.futures.as_completed(future_to_channel):
            if progress.iscanceled():
                executor.shutdown(wait=False)
                break
                
            completed += 1
            try:
                channel_obj, is_working = future.result(timeout=0.5)
            except Exception:
                channel_obj = future_to_channel[future]
                is_working = False
                
            if is_working:
                working_count += 1
            else:
                new_dead_channels.append(channel_obj)
                
            name = _auto_clean(channel_obj.get("name", "Unbekannter Sender"))
            percent = int((completed / total) * 100)
            progress.update(percent, f"Getestet: {completed}/{total} | Tote Links: {len(new_dead_channels)}\nAktuell: {name}")
    finally:
        executor.shutdown(wait=False)
        progress.close()
    
    save_dead_links(new_dead_channels)
    
    dead_count = len(load_dead_links())
    report_msg = f"Turbo-Test beendet!\nGetestet: {total} Sender\nErfolgreich: {working_count} | Tote Links gesamt: {dead_count}"
    xbmcgui.Dialog().ok("GitPlayGer — Turbo Testergebnis", report_msg)
    xbmc.log(f"[gitplayger] Batch-Test beendet. Tote Streams gesamt: {dead_count}", xbmc.LOGINFO)
    xbmc.executebuiltin("Container.Refresh()")


def list_dead_channels():
    dead_list = load_dead_links()
    
    if not dead_list:
        item = xbmcgui.ListItem(label="Keine nicht verfügbaren Sender gespeichert.")
        item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=empty", listitem=item, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for channel in dead_list:
        name = _auto_clean(channel.get("name", "Unbekannter Sender"))
        logo = channel.get("logo", "") or DEFAULT_ICON
        stream_url = channel.get("url", "")
        
        list_item = xbmcgui.ListItem(label=f"[COLOR red]{name}[/COLOR]")
        list_item.setArt({"icon": logo, "thumb": logo, "poster": logo})
        list_item.setInfo("video", {"title": name, "plot": f"Dieser Sender wurde als nicht verfügbar eingestuft.\nURL: {stream_url}"})
        list_item.setProperty('IsPlayable', 'true')
        
        restore_action = f"RunPlugin({URL}?action=restore_channel&url={urllib.parse.quote_plus(stream_url)})"
        list_item.addContextMenuItems([
            ("Wiederherstellen (wieder sichtbar machen)", restore_action)
        ])
        
        params = {"action": "play", "url": stream_url}
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?{urlencode(params)}", listitem=list_item, isFolder=False)
        
    top_item = xbmcgui.ListItem(label="[B][COLOR cyan]▲ Zum Seitenanfang ▲[/COLOR][/B]")
    top_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    top_item.setInfo("video", {"title": "Zum Seitenanfang", "plot": "Springt direkt zum ersten Eintrag dieser Liste."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=scroll_top", listitem=top_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def restore_channel(stream_url):
    dead_list = load_dead_links()
    updated_list = [c for c in dead_list if c.get("url") != stream_url]
    save_dead_links(updated_list)
    xbmcgui.Dialog().notification("GitPlayGer", "Sender wurde wiederhergestellt!", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh()")


def backup_addon_data():
    profile_dir = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    target_dir = "/storage/emulated/0/GitPlayGer"
    if not os.path.exists(target_dir):
        try:
            os.makedirs(target_dir, exist_ok=True)
        except Exception:
            pass
            
    existing_files = os.listdir(target_dir)
    max_num = 0
    for f_name in existing_files:
        if f_name.startswith("GitPlayGer_backup-") and f_name.endswith(".zip"):
            num_str = f_name[18:-4]
            if num_str.isdigit():
                num = int(num_str)
                if num > max_num:
                    max_num = num
                    
    next_num = max_num + 1
    backup_filename = f"GitPlayGer_backup-{next_num:03d}.zip"
    backup_path = os.path.join(target_dir, backup_filename)
    
    progress = xbmcgui.DialogProgressBG()
    progress.create("GitPlayGer", "Erstelle Backup...")
    try:
        with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(profile_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, profile_dir)
                    zipf.write(file_path, arcname)
        xbmcgui.Dialog().notification("GitPlayGer", f"Backup als {backup_filename} erstellt!", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.log(f"[gitplayger] Backup erstellt: {backup_path}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[gitplayger] Backup error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("GitPlayGer", f"Backup fehlgeschlagen: {e}", xbmcgui.NOTIFICATION_ERROR, 4000)
    finally:
        progress.close()


def restore_addon_data():
    target_dir = "/storage/emulated/0/GitPlayGer"
    
    if not os.path.exists(target_dir):
        xbmcgui.Dialog().notification("GitPlayGer", "Kein Backup-Ordner gefunden!", xbmcgui.NOTIFICATION_WARNING, 4000)
        return

    try:
        files = os.listdir(target_dir)
    except Exception as e:
        xbmc.log(f"[gitplayger] Fehler beim Lesen des Backup-Verzeichnisses: {e}", xbmc.LOGERROR)
        return

    backup_files = []
    for f_name in files:
        if f_name == "GitPlayGer_backup.zip" or (f_name.startswith("GitPlayGer_backup-") and f_name.endswith(".zip")):
            backup_files.append(f_name)

    backup_files.sort(reverse=True)

    if not backup_files:
        xbmcgui.Dialog().notification("GitPlayGer", "Keine Backup-Dateien gefunden!", xbmcgui.NOTIFICATION_WARNING, 4000)
        return

    selected_idx = xbmcgui.Dialog().select("Wähle ein Backup zum Wiederherstellen", backup_files)
    
    if selected_idx < 0:
        return

    chosen_backup = backup_files[selected_idx]
    backup_path = os.path.join(target_dir, chosen_backup)
    profile_dir = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

    if xbmcgui.Dialog().yesno(
        "GitPlayGer — Wiederherstellung",
        f"Ausgewähltes Backup: {chosen_backup}\n\n"
        "Möchtest du dieses Backup wirklich wiederherstellen?\n"
        "Achtung: Aktuelle Einstellungen und Caches werden überschrieben!"
    ):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Stelle Daten wieder her...")
        try:
            with zipfile.ZipFile(backup_path, 'r') as zipf:
                zipf.extractall(profile_dir)
            xbmcgui.Dialog().notification("GitPlayGer", "Backup erfolgreich wiederhergestellt!", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmc.executebuiltin("Container.Refresh()")
        except Exception as e:
            xbmc.log(f"[gitplayger] Restore error: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("GitPlayGer", f"Wiederherstellung fehlgeschlagen: {e}", xbmcgui.NOTIFICATION_ERROR, 4000)
        finally:
            progress.close()


def configure_epg_url():
    current_url = ADDON.getSetting("epg_url")
    keyboard = xbmc.Keyboard(current_url, 'EPG URL (Online) eingeben')
    keyboard.doModal()
    if keyboard.isConfirmed():
        new_url = keyboard.getText()
        ADDON.setSetting("epg_url", new_url)
        ADDON.setSetting("epg_url_enabled", "true")
        xbmcgui.Dialog().notification("GitPlayGer", "EPG URL gespeichert & aktiviert!", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh()")        


def configure_epg_local():
    gitplayger_dir = "/storage/emulated/0/GitPlayGer"
    
    if not xbmcvfs.exists(gitplayger_dir):
        try:
            xbmcvfs.mkdirs(gitplayger_dir)
        except Exception as e:
            xbmc.log(f"[gitplayger] Konnte Ordner GitPlayGer nicht erstellen: {e}", xbmc.LOGERROR)

    default_path = ADDON.getSetting("epg_local_path") or gitplayger_dir
    
    selected_file = xbmcgui.Dialog().browse(1, "EPG-Datei (XMLTV) auswählen", "files", ".xml|.xmltv", False, False, default_path)
    if selected_file:
        ADDON.setSetting("epg_local_path", selected_file)
        ADDON.setSetting("epg_local_enabled", "true")
        xbmcgui.Dialog().notification("GitPlayGer", "Lokaler EPG-Pfad gespeichert & aktiviert!", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh()")


def manage_countries():
    f_mgr = ChannelFilter()
    
    item_all_on = xbmcgui.ListItem(label="[B][ Alle Länder aktivieren ][/B]")
    item_all_on.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_all_on.setInfo("video", {"title": "Alle Länder aktivieren", "plot": "Aktiviert sämtliche Länderfilter auf einmal."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=enable_all_countries", listitem=item_all_on, isFolder=False)

    item_all_off = xbmcgui.ListItem(label="[B][ Alle Länder deaktivieren ][/B]")
    item_all_off.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    item_all_off.setInfo("video", {"title": "Alle Länder deaktivieren", "plot": "Deaktiviert sämtliche Länderfilter auf einmal."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=disable_all_countries", listitem=item_all_off, isFolder=False)

    countries = f_mgr.get_countries_status()

    for c in countries:
        code = c["code"]
        name = c["name"]
        enabled = c.get("enabled", True)

        status_str = "Aktiviert" if enabled else "Deaktiviert"
        label = f"{name} — [{status_str}]"

        list_item = xbmcgui.ListItem(label=label)
        list_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        list_item.setInfo("video", {
            "title": name, 
            "plot": f"Land: {name}\nStatus: {status_str}\n\n[B]Tipp:[/B] Klicke oder öffne das Kontextmenü (Taste C), um dieses Land ein- oder auszuschalten."
        })

        toggle_label = "Deaktivieren" if enabled else "Aktivieren"
        toggle_action = f"RunPlugin({URL}?action=toggle_country&code={code})"
        list_item.addContextMenuItems([
            (toggle_label, toggle_action)
        ])

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=toggle_country&code={code}", listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def manage_playlists():
    api = GitPlayGer(region="de")
    playlists = api.get_playlists_status()

    cleaned_playlists = []
    for p in playlists:
        url = p.get("url", "") if isinstance(p, dict) else (p[1] if isinstance(p, (list, tuple)) else "")
        if "custom_m3u" not in url:
            cleaned_playlists.append(p)

    for i in range(1, 4):
        m3u_path = ADDON.getSetting(f"custom_m3u_{i}_url")
        if m3u_path:
            enabled = ADDON.getSetting(f"custom_m3u_{i}_enabled") == "true"
            cleaned_playlists.append({
                "name": f"Eigene M3U {i} ({os.path.basename(m3u_path)})",
                "url": f"custom_m3u_{i}_enabled",
                "enabled": enabled
            })

    if not cleaned_playlists:
        item = xbmcgui.ListItem(label="Keine Playlisten gefunden.")
        item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=empty", listitem=item, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for pl in cleaned_playlists:
        name = pl.get("name", "Unbekannt")
        identifier = pl.get("url", "")
        enabled = pl.get("enabled", True)

        status_str = "Aktiviert" if enabled else "Deaktiviert"
        label = f"{name} ({status_str})"

        list_item = xbmcgui.ListItem(label=label)
        list_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        list_item.setInfo("video", {
            "title": name, 
            "plot": f"Playlist: {name}\nIdentifier: {identifier}\nStatus: {status_str}\n\n[B]Tipp:[/B] Nutze das Kontextmenü (Taste C) zum Ein-/Ausschalten."
        })

        if "custom_m3u" in identifier:
            click_url = f"{URL}?action=toggle_setting_bool&setting={identifier}"
            toggle_action = f"RunPlugin({click_url})"
            
            list_item.addContextMenuItems([
                ("Ein-/Ausschalten", toggle_action)
            ])
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=click_url, listitem=list_item, isFolder=False)
        else:
            toggle_action = f"RunPlugin({URL}?action=toggle_playlist&identifier={identifier})"
            regen_action = f"RunPlugin({URL}?action=regen_playlist&identifier={identifier})"
            delete_action = f"RunPlugin({URL}?action=delete_playlist&identifier={identifier})"
            copy_action = f"RunPlugin({URL}?action=copy_playlist_to_folder&url={urllib.parse.quote_plus(identifier)})"

            list_item.addContextMenuItems([
                ("Kopiere zu GitPlayGer", copy_action),
                ("Ein-/Ausschalten", toggle_action),
                ("Einzeln neu laden", regen_action),
                ("Löschen", delete_action)
            ])
            click_url = f"{URL}?action=toggle_playlist&identifier={identifier}"
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=click_url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def list_favorites():
    api = GitPlayGer(region="de")
    favorites = api.get_favorites()

    if not favorites:
        item = xbmcgui.ListItem(label="Keine Favoriten gespeichert.")
        item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
        item.setInfo("video", {"title": "Favoriten", "plot": "Drücke im Kontextmenü eines Senders auf 'Zu Favoriten hinzufügen'."})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=empty", listitem=item, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for channel in favorites:
        name = channel["name"]
        logo = channel.get("logo", "") or DEFAULT_ICON
        desc = channel.get("description", "")
        stream_url = channel["url"]
        
        list_item = xbmcgui.ListItem(label=name)
        list_item.setArt({"icon": logo, "thumb": logo, "poster": logo})
        list_item.setInfo("video", {"title": name, "plot": desc, "genre": channel.get("genre", "Favoriten")})
        list_item.setProperty('IsPlayable', 'true')
        
        fav_action = f"RunPlugin({URL}?action=toggle_favorite&url={urllib.parse.quote_plus(stream_url)})"
        test_action = f"RunPlugin({URL}?action=test_stream&url={urllib.parse.quote_plus(stream_url)})"
        
        list_item.addContextMenuItems([
            ("Aus Favoriten entfernen", fav_action),
            ("Stream auf Verfügbarkeit testen", test_action)
        ])
        
        params = {"action": "play", "url": stream_url}
        item_url = f"{URL}?{urlencode(params)}"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=item_url, listitem=list_item, isFolder=False)
        
    top_item = xbmcgui.ListItem(label="[B][COLOR cyan]▲ Zum Seitenanfang ▲[/COLOR][/B]")
    top_item.setArt({"icon": DEFAULT_ICON, "thumb": DEFAULT_ICON, "poster": DEFAULT_ICON})
    top_item.setInfo("video", {"title": "Zum Seitenanfang", "plot": "Springt direkt zum ersten Eintrag dieser Liste."})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=f"{URL}?action=scroll_top", listitem=top_item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def search_prompt():
    keyboard = xbmc.Keyboard('', 'Sender suchen ... ')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_term = keyboard.getText()
        if search_term:
            xbmc.executebuiltin(f"Container.Update({URL}?action=list_channels&search={urllib.parse.quote_plus(search_term)})")


def play_stream(stream_url):
    apply_settings_to_globals()
    xbmc.log(f"[gitplayger] Starte Stream: {stream_url}", xbmc.LOGINFO)

    if use_proxies_enabled:
        stream_url = f"http://127.0.0.1:{LOCAL_PROXY_PORT}/{urllib.parse.quote(stream_url)}"

    list_item = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)


def copy_playlist_to_folder(playlist_url):
    if not playlist_url:
        xbmcgui.Dialog().notification("GitPlayGer", "Ungültige Playlist-URL!", xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    progress = xbmcgui.DialogProgressBG()
    progress.create("GitPlayGer", "Kopiere M3U-Datei...")
    
    try:
        target_dir = "/storage/emulated/0/GitPlayGer/M3U"
        if not os.path.exists(target_dir):
            os.makedirs(target_dir, exist_ok=True)

        parsed_url = urllib.parse.urlparse(playlist_url)
        file_name = os.path.basename(parsed_url.path)
        if not file_name or not file_name.endswith(".m3u"):
            file_name = "downloaded_playlist.m3u"

        target_file_path = os.path.join(target_dir, file_name)

        if os.path.exists(playlist_url):
            with open(playlist_url, 'r', encoding='utf-8', errors='ignore') as src:
                content = src.read()
            with open(target_file_path, 'w', encoding='utf-8') as dst:
                dst.write(content)
        else:
            req = urllib.request.Request(playlist_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=15) as resp:
                content = resp.read().decode('utf-8', errors='ignore')
            with open(target_file_path, 'w', encoding='utf-8') as dst:
                dst.write(content)

        xbmcgui.Dialog().notification("GitPlayGer", "M3U erfolgreich kopiert!", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.log(f"[gitplayger] Playlist kopiert nach: {target_file_path}", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[gitplayger] Fehler beim Kopieren der M3U: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("GitPlayGer", "Fehler beim Kopieren!", xbmcgui.NOTIFICATION_ERROR, 4000)
    finally:
        progress.close()


def open_skin_menu():
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
    from resources.lib.skin_menu import show_main_menu
    show_main_menu()


def router(paramstring):
    apply_settings_to_globals()
    if not paramstring or paramstring == "?" or len(paramstring) <= 1:
        if ADDON.getSetting("use_skin_menu") == "true":
            open_skin_menu()
        else:
            list_genres()
        return

    params = dict(parse_qsl(paramstring[1:]))
    action = params.get("action")
    mode = params.get("mode")
    identifier = params.get("identifier")
    url = params.get("url")
    code = params.get("code")
    char = params.get("char")
    theme = params.get("theme")
    setting = params.get("setting")
    
    api = GitPlayGer(region="de")

    if mode in ['sel', 'channels_menu', 'channels', 'vodgen', 'vod', 'sergen', 'seriescat', 'season', 'episode', 'epiplay', 'genres', 'check', 'playvod', 'mac_vault', 'activate_vault_mac']:
        check_disclaimer()
        if mode == 'sel':
            hunter.SelectLevel()
        elif mode == 'channels_menu':
            hunter.channelsMenuLevel()
        elif mode == 'channels':
            hunter.channelLevel()
        elif mode == 'vodgen':
            hunter.vodgenreLevel()
        elif mode == 'vod':
            hunter.vodLevel()
        elif mode == 'sergen':
            hunter.SeriesGenre()
        elif mode == 'seriescat':
            hunter.SeriesLevel()
        elif mode == 'season':
            hunter.SeasonLevel()
        elif mode == 'episode':
            hunter.EpisodeLevel()
        elif mode == 'epiplay':
            hunter.PlayEpisode()
        elif mode == 'genres':
            hunter.genreLevel()
            hunter.ClearLevel()
        elif mode == 'check':
            hunter.checkcmd()
        elif mode == 'playvod':
            hunter.playLevel()
        elif mode == 'mac_vault':
            hunter.show_mac_vault_level()
        elif mode == 'activate_vault_mac':
            chosen_mac = params.get("mac")
            chosen_url = params.get("url")
            if chosen_mac and chosen_url:
                portal_obj = config.portalConfig('1')
                portal_obj['mac'] = chosen_mac
                portal_obj['url'] = chosen_url
                try:
                    ADDON.setSetting("portal_mac_1", chosen_mac)
                    ADDON.setSetting("portal_url_1", chosen_url)
                except Exception:
                    pass
                xbmcgui.Dialog().notification("GitPlayGer", f"MAC aktiviert: {chosen_mac}", xbmcgui.NOTIFICATION_INFO, 3000)
                xbmc.executebuiltin(f"Container.Update({URL}, replace)")
        return

    if action == "play":
        play_stream(url)
    elif action == "skin_menu":
        open_skin_menu()
    elif action == "scroll_top":
        xbmc.executebuiltin("Action(FirstPage)")
        return
    elif action == "list_alphabet_index":
        list_alphabet_index()
    elif action == "list_channels_by_char":
        list_channels_by_char(char)
    elif action == "list_favorite_themes":
        list_favorite_themes()
    elif action == "create_theme_prompt":
        create_theme_prompt()
    elif action == "delete_theme":
        delete_theme(theme)
    elif action == "assign_channel_to_theme_prompt":
        assign_channel_to_theme_prompt(url)
    elif action == "list_channels_in_theme":
        list_channels_in_theme(theme)
    elif action == "remove_from_theme":
        remove_from_theme(theme, url)
    elif action == "list_kodinerds":
        list_kodinerds()
    elif action == "list_dead_channels":
        list_dead_channels()
    elif action == "restore_channel":
        restore_channel(url)
    elif action == "clear_data":
        clear_all_addon_data()
    elif action == "clear_dead_links":
        clear_dead_links_cache()
    elif action == "list_channels":
        genre = params.get("genre", "all")
        search_query = params.get("search")
        filter_type = params.get("filter")
        list_channels(genre, search_query, filter_type)
    elif action == "list_favorites":
        list_favorites()
    elif action == "search_prompt":
        search_prompt()
    elif action == "settings_menu":
        settings_menu()
    elif action == "open_settings":
        ADDON.openSettings()
        xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "update_web_proxies":
        update_proxies_from_web()
    elif action == "batch_test_streams":
        batch_test_streams()
    elif action == "toggle_hunter":
        toggle_hunter()
    elif action == "open_hunter":
        check_disclaimer()
        hunter.SelectLevel()
    elif action == "generate_gitplayger_m3u":
        generate_gitplayger_m3u()
    elif action == "setup_pvr":
        setup_iptv_simple_client()
    elif action == "backup_data":
        backup_addon_data()
    elif action == "restore_data":
        restore_addon_data()
    elif action == "configure_epg_url":
        configure_epg_url()
    elif action == "configure_epg_local":
        configure_epg_local()
    elif action == "toggle_epg_url":
        current = ADDON.getSetting("epg_url_enabled") == "true"
        ADDON.setSetting("epg_url_enabled", "false" if current else "true")
        xbmcgui.Dialog().notification("GitPlayGer", "EPG Online-URL Status geändert", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "toggle_epg_auto":
        current = ADDON.getSetting("epg_auto_download") == "true"
        ADDON.setSetting("epg_auto_download", "false" if current else "true")
        xbmcgui.Dialog().notification("GitPlayGer", "Automatischer EPG-Download Status geändert", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "refresh_epg":
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lade Sender und Playlisten...")
        try:
            f_mgr = ChannelFilter()
            progress.update(40, "Lade Sender...")
            raw_channels = api.get_channels()

            progress.update(70, "Wende Filter und EPG-Abgleich an...")
            raw_count = len(raw_channels)
            channels = f_mgr.apply_filters(raw_channels)
            filtered_out_count = raw_count - len(channels)
            progress.update(100, "Fertig!")     
            if not raw_channels:
                xbmcgui.Dialog().notification("GitPlayGer", "Keine Sender gefunden - bitte Playlisten neu suchen", xbmcgui.NOTIFICATION_WARNING, 4000)
            else:
                xbmcgui.Dialog().notification("GitPlayGer", "EPG & Sender erfolgreich aktualisiert!", xbmcgui.NOTIFICATION_INFO, 3000)
        except Exception as e:
            xbmc.log(f"[gitplayger] Fehler bei refresh_epg: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("GitPlayGer", "Fehler beim Aktualisieren!", xbmcgui.NOTIFICATION_ERROR, 4000)
        finally:
            progress.close()
        xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "toggle_epg_local":
        current = ADDON.getSetting("epg_local_enabled") == "true"
        ADDON.setSetting("epg_local_enabled", "false" if current else "true")
        xbmcgui.Dialog().notification("GitPlayGer", "EPG Lokaler Status geändert", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "manage_countries":
        manage_countries()
    elif action == "toggle_country":
        f_mgr = ChannelFilter()
        f_mgr.toggle_country(code)
        xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "enable_all_countries":
        f_mgr = ChannelFilter()
        f_mgr.set_all_countries(True)
        xbmcgui.Dialog().notification("GitPlayGer", "Alle Länder aktiviert", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "disable_all_countries":
        f_mgr = ChannelFilter()
        f_mgr.set_all_countries(False)
        xbmcgui.Dialog().notification("GitPlayGer", "Alle Länder deaktiviert", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "load_kodinerds_playlist":
        load_kodinerds_playlist(url)        
    elif action == "manage_playlists":
        manage_playlists()
    elif action == "toggle_playlist":
        api.toggle_playlist(identifier)
        xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "delete_playlist":
        api.delete_playlist(identifier)
        xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "toggle_setting_bool":
        if setting:
            current = ADDON.getSetting(setting) == "true"
            ADDON.setSetting(setting, "false" if current else "true")
            xbmcgui.Dialog().notification("GitPlayGer", "Playlist Status geändert", xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "copy_playlist_to_folder":
        copy_playlist_to_folder(url)       
    elif action == "regen_playlist":
        """IT('s) Possible"""
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Aktualisiere Playlist...")
        found = None
        try:
            found = api.regenerate_playlist(identifier)
        finally:
            progress.close()
        if found == 0:
            xbmcgui.Dialog().notification("GitPlayGer", "Keine neuen Playlists gefunden - vorhandene bleiben erhalten", xbmcgui.NOTIFICATION_WARNING, 4000)
        else:
            xbmcgui.Dialog().notification("GitPlayGer", "Playlist erfolgreich aktualisiert!", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "regenerate_active":
        pass
    elif action == "regenerate_all":
        if xbmcgui.Dialog().yesno("GitPlayGer", "Möchtest du wirklich alle Playlisten komplett neu suchen und erzeugen?"):
            progress = xbmcgui.DialogProgressBG()
            progress.create("GitPlayGer", "Erzeuge alle Playlisten neu...")
            found = None
            try:
                found = api.regenerate_playlist("all")
            finally:
                progress.close()
            if found == 0:
                xbmcgui.Dialog().notification("GitPlayGer", "Keine neuen Playlists gefunden - vorhandene bleiben erhalten", xbmcgui.NOTIFICATION_WARNING, 4000)
            else:
                xbmcgui.Dialog().notification("GitPlayGer", "Alle Playlisten wurden neu erzeugt!", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmc.executebuiltin(f"Container.Update({URL}, replace)")
    elif action == "toggle_favorite":
        target_keyword = _resolve_channel_metadata(url)

        if api.is_favorite(url):
            api.remove_favorite(url)
            xbmcgui.Dialog().notification(
                "GitPlayGer",
                "Aus Favoriten entfernt",
                xbmcgui.NOTIFICATION_INFO,
                2000
            )
        else:
            api.add_favorite(target_keyword)
            xbmcgui.Dialog().notification(
                "GitPlayGer",
                "Zu Favoriten hinzugefügt",
                xbmcgui.NOTIFICATION_INFO,
                2000
            )

            dialog = xbmcgui.Dialog()
            choice = dialog.select(
                "Favorit einem Thema zuordnen",
                [
                    "Keinem Thema zuordnen",
                    "Vorhandenes Thema auswählen",
                    "Neues Thema erstellen"
                ]
            )

            if choice == 1:
                assign_channel_to_theme_prompt(url)

            elif choice == 2:
                keyboard = xbmc.Keyboard(
                    '',
                    'Neuen Themen-Namen eingeben'
                )
                keyboard.doModal()

                if keyboard.isConfirmed():
                    theme_name = keyboard.getText().strip()

                    if theme_name:
                        themes = api.get_favorite_themes()

                        if theme_name not in themes:
                            api.create_favorite_theme(theme_name)

                        api.add_channel_to_theme(
                            theme_name,
                            target_keyword
                        )

                        xbmcgui.Dialog().notification(
                            "GitPlayGer",
                            f"Sender zu '{theme_name}' hinzugefügt!",
                            xbmcgui.NOTIFICATION_INFO,
                            2500
                        )

        xbmc.executebuiltin("Container.Refresh()")

    elif action == "test_stream":
        success, message = api.test_stream(url) if hasattr(api, 'test_stream') else (False, "Nicht unterstützt")
        icon_type = xbmcgui.NOTIFICATION_INFO if success else xbmcgui.NOTIFICATION_ERROR
        xbmcgui.Dialog().notification("Stream Test", message, icon_type, 4000)
    elif action == "doh_test":
        hunter.run_doh_test()        
    elif action == "dummy":
        return        
    else:
        list_genres()


if __name__ == "__main__":
    router(sys.argv[2] if len(sys.argv) > 2 else "")
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum des Autors.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.