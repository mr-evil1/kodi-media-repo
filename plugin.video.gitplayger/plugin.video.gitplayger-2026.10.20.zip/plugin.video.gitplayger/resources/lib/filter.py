# -*- coding: utf-8 -*-
# GitPlayGer 
# Copyright (c) 2026 Team IT('s) Possible. All rights reserved.
# Version 2026.10.16
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
import os
import json
import re
import datetime
import xml.etree.ElementTree as ET
import io
import gzip
import shutil
import urllib.request
import time
import requests
import xbmcvfs
import xbmcaddon
import xbmc

DEFAULT_COUNTRIES = [
    {"code": "DE", "name": "Deutschland (DE / GER)", "enabled": True, "keywords": ["de", "ger", "deutschland", "german"]},
    {"code": "AT", "name": "Österreich (AT)", "enabled": True, "keywords": ["at", "austria", "österreich"]},
    {"code": "CH", "name": "Schweiz (CH)", "enabled": True, "keywords": ["ch", "switzerland", "schweiz"]},
    {"code": "TR", "name": "Türkei (TR)", "enabled": True, "keywords": ["tr", "turkey", "türkei", "tuerkei"]},
    {"code": "US", "name": "USA / UK (Englisch)", "enabled": True, "keywords": ["us", "usa", "uk", "gb", "english", "england", "united states"]},
    {"code": "FR", "name": "Frankreich (FR)", "enabled": True, "keywords": ["fr", "france", "frankreich"]},
    {"code": "ES", "name": "Spanien (ES)", "enabled": True, "keywords": ["es", "spain", "spanien"]},
    {"code": "IT", "name": "Italien (IT)", "enabled": True, "keywords": ["it", "italy", "italien"]},
    {"code": "NL", "name": "Niederlande (NL)", "enabled": True, "keywords": ["nl", "netherlands", "holland"]},
    {"code": "PL", "name": "Polen (PL)", "enabled": True, "keywords": ["pl", "poland", "polen"]},
    {"code": "RU", "name": "Russland (RU)", "enabled": True, "keywords": ["ru", "russia", "russland"]},
    {"code": "EX-YU", "name": "Balkan / Ex-Yu", "enabled": True, "keywords": ["ex-yu", "balkan", "serbia", "croatia", "bosnia", "albania", "srbija", "hrvatska"]}
]


class ChannelFilter:

    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.profile_dir = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        if not xbmcvfs.exists(self.profile_dir):
            xbmcvfs.mkdirs(self.profile_dir)
        self.config_file = os.path.join(self.profile_dir, 'country_filters.json')
        self._epg_channels = None
        self._epg_programmes = None

    def get_countries_status(self):
        if xbmcvfs.exists(self.config_file):
            try:
                f = xbmcvfs.File(self.config_file, 'r')
                data = json.loads(f.read())
                f.close()
                existing_codes = {c['code'] for c in data}
                for dc in DEFAULT_COUNTRIES:
                    if dc['code'] not in existing_codes:
                        data.append(dc)
                return data
            except:
                pass
        return DEFAULT_COUNTRIES

    def save_countries_status(self, countries):
        try:
            f = xbmcvfs.File(self.config_file, 'w')
            f.write(json.dumps(countries, ensure_ascii=False, indent=4))
            f.close()
        except:
            pass

    def toggle_country(self, code):
        countries = self.get_countries_status()
        for c in countries:
            if c['code'] == code:
                c['enabled'] = not c.get('enabled', True)
                break
        self.save_countries_status(countries)

    def set_all_countries(self, enabled=True):
        countries = self.get_countries_status()
        for c in countries:
            c['enabled'] = enabled
        self.save_countries_status(countries)

    def get_blacklist(self):
        try:
            terms_str = self.addon.getSetting("blacklist_terms")
            if terms_str:
                return [t.strip().lower() for t in terms_str.split(",") if t.strip()]
        except Exception:
            pass
        return ["teleshopping", "shop", "horoskop", "erotic", "xxx"]

    def _parse_xmltv_time(self, time_str):
        if not time_str:
            return None
        try:
            clean_str = time_str.strip().split()[0][:14]
            return datetime.datetime.strptime(clean_str, "%Y%m%d%H%M%S")
        except:
            return None

    def get_epg_status_info(self):
        local_path = os.path.join(self.profile_dir, "guide.xml")
        if self.addon.getSetting("epg_local_enabled") == "true":
            custom_local = self.addon.getSetting("epg_local_path")
            if custom_local and os.path.exists(custom_local):
                local_path = custom_local

        if not os.path.exists(local_path):
            return "Keine EPG-Datei vorhanden", 0, 0

        try:
            file_size = os.path.getsize(local_path) / (1024 * 1024)
            prog_count = 0
            ch_count = 0
            with open(local_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    if '<programme ' in line:
                        prog_count += 1
                    elif '<channel ' in line:
                        ch_count += 1
            return f"Vorhanden ({file_size:.1f} MB)", ch_count, prog_count
        except Exception as e:
            return f"Fehler beim Lesen: {e}", 0, 0

    def _dynamic_epg_search(self):
        direct_urls = [
            "https://raw.githubusercontent.com/iptv-org/epg/master/guides/de/de.epg.xml",
            "https://raw.githubusercontent.com/iptv-org/epg/master/guides/de/de.epg.xml.gz",
            "https://epgshare01.online/epgshare01/epg_ripper_DE1.xml.gz"
        ]
        
        for url in direct_urls:
            try:
                xbmc.log(f"[gitplayger] Prüfe direkte EPG-URL: {url}", xbmc.LOGINFO)
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=6) as response:
                    if response.status == 200:
                        xbmc.log(f"[gitplayger] EPG-Quelle erfolgreich direkt gefunden: {url}", xbmc.LOGINFO)
                        return url
            except Exception as e:
                xbmc.log(f"[gitplayger] EPG-URL nicht erreichbar ({url}): {e}", xbmc.LOGDEBUG)
                
        return "https://raw.githubusercontent.com/iptv-org/epg/master/guides/de/de.epg.xml"

    def force_download_epg(self):
        epg_url = self.addon.getSetting("epg_url")
        if not epg_url:
            epg_url = self._dynamic_epg_search()
            self.addon.setSetting("epg_url", epg_url)

        target_xml_path = os.path.join(self.profile_dir, "guide.xml")

        try:
            xbmc.log(f"[gitplayger] Lade EPG von URL: {epg_url}", xbmc.LOGINFO)
            req = urllib.request.Request(epg_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=25) as response:
                content_bytes = response.read()
                if epg_url.endswith('.gz') or 'gz' in epg_url.lower() or content_bytes[:2] == b'\x1f\x8b':
                    gz_path = target_xml_path + ".gz"
                    with open(gz_path, 'wb') as f_out:
                        f_out.write(content_bytes)
                    with gzip.open(gz_path, 'rb') as f_in:
                        with open(target_xml_path, 'wb') as f_out:
                            shutil.copyfileobj(f_in, f_out)
                    try:
                        os.remove(gz_path)
                    except:
                        pass
                else:
                    with open(target_xml_path, 'wb') as f_out:
                        f_out.write(content_bytes)
            return True, "EPG erfolgreich heruntergeladen!"
        except Exception as e:
            xbmc.log(f"[gitplayger] EPG-Download-Fehler: {e}", xbmc.LOGERROR)
            try:
                fallback_url = "https://epgshare01.online/epgshare01/epg_ripper_DE1.xml.gz"
                req = urllib.request.Request(fallback_url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=25) as response:
                    gz_path = target_xml_path + ".gz"
                    with open(gz_path, 'wb') as f_out:
                        f_out.write(response.read())
                    with gzip.open(gz_path, 'rb') as f_in:
                        with open(target_xml_path, 'wb') as f_out:
                            shutil.copyfileobj(f_in, f_out)
                    try:
                        os.remove(gz_path)
                    except:
                        pass
                return True, "EPG via Fallback erfolgreich geladen!"
            except Exception as e2:
                return False, str(e2)

    def _ensure_epg_downloaded(self):
        auto_dl_enabled = self.addon.getSetting("epg_auto_download") == "true"
        if not auto_dl_enabled:
            return os.path.join(self.profile_dir, "guide.xml")

        epg_url = self.addon.getSetting("epg_url")
        if not epg_url or "api.github.com" in epg_url:
            epg_url = self._dynamic_epg_search()
            self.addon.setSetting("epg_url", epg_url)

        target_xml_path = os.path.join(self.profile_dir, "guide.xml")
        should_download = True
        if os.path.exists(target_xml_path):
            file_time = os.path.getmtime(target_xml_path)
            if (time.time() - file_time) < (12 * 3600):
                should_download = False

        if should_download:
            self.force_download_epg()

        return target_xml_path

    def _load_epg_data(self):
        if self._epg_channels is not None:
            return self._epg_channels, self._epg_programmes

        self._epg_channels = {}
        self._epg_programmes = {}
        epg_sources = []
        
        target_xml_path = self._ensure_epg_downloaded()
        if os.path.exists(target_xml_path):
            epg_sources.append(target_xml_path)

        if self.addon.getSetting("epg_local_enabled") == "true":
            custom_local = self.addon.getSetting("epg_local_path")
            if custom_local and os.path.exists(custom_local) and custom_local not in epg_sources:
                epg_sources.append(custom_local)

        if not epg_sources:
            xbmc.log("[gitplayger] Keine EPG-Dateien oder Quellen gefunden.", xbmc.LOGERROR)
            return self._epg_channels, self._epg_programmes

        now = datetime.datetime.now()
        total_ch_count = 0
        total_prog_count = 0
        raw_programmes = {}

        for local_path in epg_sources:
            try:
                xbmc.log(f"[gitplayger] Lade EPG-Datei ein: {local_path}", xbmc.LOGINFO)
                with open(local_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()

                for event, elem in ET.iterparse(io.StringIO(content), events=('end',)):
                    if elem.tag == 'channel':
                        ch_id = elem.get('id', '')
                        for child in elem:
                            if child.tag == 'display-name' and child.text:
                                dn = child.text.strip().lower()
                                self._epg_channels[dn] = ch_id
                                total_ch_count += 1
                        if ch_id:
                            self._epg_channels[ch_id.lower()] = ch_id
                        elem.clear()

                    elif elem.tag == 'programme':
                        ch_id = elem.get('channel', '')
                        start_dt = self._parse_xmltv_time(elem.get('start', ''))
                        stop_dt = self._parse_xmltv_time(elem.get('stop', ''))

                        if ch_id:
                            title = ""
                            desc = ""
                            for child in elem:
                                if child.tag == 'title' and child.text:
                                    title = child.text.strip()
                                elif child.tag == 'desc' and child.text:
                                    desc = child.text.strip()
                            
                            if ch_id not in raw_programmes:
                                raw_programmes[ch_id] = []
                            raw_programmes[ch_id].append((start_dt, stop_dt, title, desc))
                            total_prog_count += 1
                        elem.clear()
            except Exception as e:
                xbmc.log(f"[gitplayger] FEHLER beim Parsen der EPG-XML ({local_path}): {e}", xbmc.LOGERROR)

        for ch_id, progs in raw_programmes.items():
            if not progs:
                continue
            
            progs.sort(key=lambda x: x[0] if x[0] else datetime.datetime.min)
            
            chosen = None
            prefix = "PROGRAMM"
            
            for start_dt, stop_dt, title, desc in progs:
                if start_dt and stop_dt and start_dt <= now <= stop_dt:
                    chosen = (start_dt, stop_dt, title, desc)
                    prefix = "JETZT"
                    break
            
            if not chosen:
                for start_dt, stop_dt, title, desc in progs:
                    if start_dt and start_dt > now:
                        chosen = (start_dt, stop_dt, title, desc)
                        prefix = "NÄCHSTE"
                        break
            
            if not chosen and progs:
                chosen = progs[0]
                prefix = "INFO"

            if chosen:
                start_dt, stop_dt, title, desc = chosen
                start_str = start_dt.strftime("%H:%M") if start_dt else "??"
                stop_str = stop_dt.strftime("%H:%M") if stop_dt else "??"
                info_text = f"{prefix}: {start_str} - {stop_str} | {title}"
                if desc:
                    info_text += f"\n\n{desc}"
                self._epg_programmes[ch_id] = info_text

        xbmc.log(f"[gitplayger] ERFOLGREICH MERGED: {total_ch_count} EPG-Namen und {len(self._epg_programmes)} aktive EPG-Vorschauen aus allen Quellen geladen!", xbmc.LOGINFO)
        return self._epg_channels, self._epg_programmes

    def apply_filters(self, channels):
        dead_links_path = os.path.join(self.profile_dir, 'dead_links.json')
        dead_urls = set()
        if os.path.exists(dead_links_path):
            try:
                with open(dead_links_path, 'r', encoding='utf-8') as f:
                    dead_data = json.load(f)
                    dead_urls = {c.get("url") for c in dead_data if c.get("url")}
            except Exception:
                pass

        q_setting = self.addon.getSettingInt("quality_filter")
        countries = self.get_countries_status()
        disabled_keywords = []
        for c in countries:
            if not c.get('enabled', True):
                disabled_keywords.extend(c.get('keywords', []))

        epg_map, epg_programmes = self._load_epg_data()
        matched_count = 0

        noise_words = [
            "bayern", "bremen", "niedersachsen", "hamburg", "schleswig", "holstein", 
            "hessen", "nordrhein", "westfalen", "rhein", "neckar", "aachen", "bielefeld", 
            "bonn", "dortmund", "duisburg", "düsseldorf", "essen", "münster", "siegen", 
            "wuppertal", "hd", "fhd", "sd", "4k", "uhd", "free", "iptv", "world", "plus", 
            "hevc", "geo-blocked", "medien", "live", "stream", "de", "tv"
        ]

        filtered = []
        for channel in channels:
            stream_url = channel.get("url", "")

            if stream_url in dead_urls:
                continue

            name = channel.get("name", "")
            name_lower = name.lower()
            genre = channel.get("genre", "")
            genre_lower = genre.lower()
            combined = f"{name_lower} {genre_lower}"

            tvg_id = channel.get("tvg_id", "")
            if not tvg_id and epg_map:
                if name_lower in epg_map:
                    tvg_id = epg_map[name_lower]
                else:
                    clean_name = name_lower
                    for char in ["(", ")", "[", "]", "|", "-", "—", "+", "1080p", "720p"]:
                        clean_name = clean_name.replace(char, " ")
                    
                    tokens = clean_name.split()
                    filtered_tokens = [t for t in tokens if t not in noise_words]
                    core_name = " ".join(filtered_tokens).strip()

                    for epg_name, epg_id in epg_map.items():
                        if core_name and (core_name in epg_name or epg_name in core_name):
                            tvg_id = epg_id
                            break
                
                if tvg_id:
                    matched_count += 1
                    channel["tvg_id"] = tvg_id

            if tvg_id and tvg_id in epg_programmes:
                channel["description"] = epg_programmes[tvg_id]
            else:
                channel["description"] = f"Sender: {name} | Kein EPG verfügbar"

            if q_setting == 1 and not ("4k" in name_lower or "uhd" in name_lower):
                continue
            elif q_setting == 2 and not ("fhd" in name_lower or "1080p" in name_lower):
                continue
            elif q_setting == 3 and not ("hd" in name_lower):
                continue
            elif q_setting == 4 and not ("sd" in name_lower):
                continue

            skip = False
            if disabled_keywords:
                for kw in disabled_keywords:
                    pattern = r'(?i)\b' + re.escape(kw) + r'\b'
                    if re.search(pattern, combined):
                        skip = True
                        break
            if skip:
                continue

            blacklist = self.get_blacklist()
            blacklisted = False
            for term in blacklist:
                if term.strip():
                    pattern = r'(?i)\b' + re.escape(term.strip()) + r'\b'
                    if re.search(pattern, combined) or re.search(pattern, genre_lower):
                        blacklisted = True
                        break
            if blacklisted:
                continue

            logo = channel.get("logo", "")
            if not logo or logo.strip() == "":
                clean_logo_name = name_lower
                for term in [" (de)", " (at)", " (ch)", " nord", " süd", " west", " ost", " hd", " fhd", " 4k", " uhd", "+", "fhd"]:
                    clean_logo_name = clean_logo_name.replace(term, "")
                
                clean_logo_name = re.sub(r'[^a-zA-Z0-9]', '', clean_logo_name)
                channel["logo"] = f"https://raw.githubusercontent.com/jnk22/kodinerds-iptv/master/logos/png/{clean_logo_name}.png"

            filtered.append(channel)

        xbmc.log(f"[gitplayger] EPG-Abgleich (Intelligent): {matched_count} von {len(filtered)} Kanälen verknüpft.", xbmc.LOGINFO)
        return filtered
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum des Autors.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.