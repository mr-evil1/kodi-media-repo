# -*- coding: utf-8 -*-
# GitPlayGer 
# Copyright (c) 2026 Team IT('s) Possible. All rights reserved.
# Version 2026.10.16
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
import os
import time
import json
import re
import requests
import urllib3
import xbmcvfs
import xbmc
import xbmcaddon
import xbmcgui


def get_cache_duration():
    try:
        addon = xbmcaddon.Addon()
        setting_idx = addon.getSettingInt("cache_interval")
    except Exception:
        setting_idx = 1

    mapping = {
        0: 10 * 365 * 24 * 60 * 60,
        1: 7 * 24 * 60 * 60,
        2: 14 * 24 * 60 * 60,
        3: 30 * 24 * 60 * 60,
        4: 182 * 24 * 60 * 60,
        5: 365 * 24 * 60 * 60,
    }
    return mapping.get(setting_idx, 7 * 24 * 60 * 60)


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class GitPlayGer:
    GITHUB_WEB = "https://github.com"
    CACHE_SECONDS = 6 * 60 * 60
    MAX_PLAYLISTS = 5
    MAX_REPOS_PER_QUERY = 15
    MAX_M3U_SIZE = 8 * 1024 * 1024

    GITHUB_API = "https://api.github.com"

    SCAN_FAIL_COOLDOWN = 6 * 60 * 60
    SCAN_TIME_BUDGET = 90
    MIN_SCAN_INTERVAL = 24 * 60 * 60

    API_REQUEST_DELAY = 2.0
    SEARCH_REQUEST_DELAY = 7.0

    SEED_PLAYLISTS = [
        (
            "https://raw.githubusercontent.com/jnk22/kodinerds-iptv/refs/heads/master/iptv/clean/clean_tv.m3u",
            "kodinerds",
            "Clean-TV (clean_tv.m3u)",
        ),
        (
            "https://iptv-org.github.io/iptv/languages/deu.m3u",
            "iptv-org",
            "Deutsch (deu.m3u)",
        ),
        (
            "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_germany.m3u8",
            "Free-TV/IPTV",
            "playlist_germany.m3u8",
        ),
    ]

    def __init__(self, region="de"):
        self.region = region.lower()
        self.profile_dir = xbmcvfs.translatePath(
            "special://profile/addon_data/plugin.video.gitplayger/"
        )

        if not xbmcvfs.exists(self.profile_dir):
            xbmcvfs.mkdirs(self.profile_dir)

        self.index_file = os.path.join(self.profile_dir, "playlist_index.json")
        self.last_scan_found = None
        self._last_api_request = 0.0

        self.session = requests.Session()
        self.session.headers.update({
            "Accept": "application/vnd.github+json",
            "User-Agent": "GitPlayGer-Kodi",
            "X-GitHub-Api-Version": "2022-11-28",
        })

    def get_channels(self, force_refresh=False):
        playlists = self._get_or_discover_playlists(force_refresh)
        all_channels = []

        headers = {
            "User-Agent": "GitPlayGer-Kodi",
            "Accept": "*/*",
        }

        for item in playlists:
            if isinstance(item, dict):
                name = item.get("name", "Unbekannt")
                url = item.get("url", "")
                if not item.get("enabled", True):
                    continue
            elif isinstance(item, (list, tuple)) and len(item) >= 2:
                name, url = item[0], item[1]
            else:
                continue

            content = ""

            if url.startswith("special://") or (
                "/" in url and not url.startswith("http")
            ):
                file_path = xbmcvfs.translatePath(url)
            elif "custom_m3u" in url:
                try:
                    m3u_setting_url = xbmcaddon.Addon().getSetting(url)
                    if m3u_setting_url:
                        if m3u_setting_url.startswith("http"):
                            url = m3u_setting_url
                            safe_name = re.sub(
                                r"[^a-zA-Z0-9äöüÄÖÜß_-]", "_", name
                            ).lower()
                            file_path = os.path.join(
                                self.profile_dir, safe_name + ".m3u"
                            )
                        else:
                            file_path = xbmcvfs.translatePath(m3u_setting_url)
                    else:
                        continue
                except Exception:
                    continue
            else:
                safe_name = re.sub(
                    r"[^a-zA-Z0-9äöüÄÖÜß_-]", "_", name
                ).lower()
                file_path = os.path.join(self.profile_dir, safe_name + ".m3u")

            if not url.startswith("custom_m3u") and xbmcvfs.exists(file_path):
                try:
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                        content = f.read()
                except Exception as e:
                    xbmc.log(
                        f"[gitplayger] Lokaler Cache konnte nicht gelesen werden: {e}",
                        xbmc.LOGWARNING,
                    )

            if not content and url.startswith("http"):
                try:
                    resp = self.session.get(url, headers=headers, timeout=15)
                    if resp.status_code == 200:
                        text = resp.text
                        if "#EXTM3U" in text or "#EXTINF" in text:
                            content = text
                            try:
                                with open(file_path, "w", encoding="utf-8") as f:
                                    f.write(content)
                            except Exception:
                                pass
                    resp.close()
                except Exception as e:
                    xbmc.log(
                        f"[gitplayger] Netzwerkfehler bei {name}: {e}",
                        xbmc.LOGWARNING,
                    )

            if content:
                channels = self._parse_m3u(content, name)
                if channels:
                    all_channels.extend(channels)
                    xbmc.log(
                        f"[gitplayger] {name}: {len(channels)} Sender",
                        xbmc.LOGINFO,
                    )

        xbmc.log(
            f"[gitplayger] Sender insgesamt eingelesen: {len(all_channels)}",
            xbmc.LOGINFO,
        )
        return all_channels

    def get_playlists_status(self, force_refresh=False):
        playlists = self._get_or_discover_playlists(force_refresh)
        formatted = []
        for p in playlists:
            if isinstance(p, dict):
                formatted.append({
                    "name": p.get("name", "Unbekannt"),
                    "url": p.get("url", ""),
                    "enabled": p.get("enabled", True),
                })
            elif isinstance(p, (list, tuple)) and len(p) >= 2:
                formatted.append({"name": p[0], "url": p[1], "enabled": True})
        return formatted

    def toggle_playlist(self, identifier):
        data = self._load_index_data()
        playlists = data.get("playlists", [])
        updated = False
        new_playlists = []
        for p in playlists:
            if isinstance(p, dict):
                if p.get("url") == identifier:
                    p["enabled"] = not p.get("enabled", True)
                    updated = True
                new_playlists.append(p)
            elif isinstance(p, (list, tuple)) and len(p) >= 2:
                if p[1] == identifier:
                    new_playlists.append({
                        "name": p[0], "url": p[1], "enabled": False
                    })
                    updated = True
                else:
                    new_playlists.append({
                        "name": p[0], "url": p[1], "enabled": True
                    })
        if updated:
            data["playlists"] = new_playlists
            self._save_index_data(data)

    def delete_playlist(self, identifier):
        data = self._load_index_data()
        playlists = data.get("playlists", [])
        new_playlists = []
        for p in playlists:
            url = p.get("url") if isinstance(p, dict) else (
                p[1] if isinstance(p, (list, tuple)) else ""
            )
            if url != identifier:
                new_playlists.append(p)
        data["playlists"] = new_playlists
        self._save_index_data(data)

    def regenerate_playlist(self, identifier):
        self.last_scan_found = None
        if identifier == "all":
            self._get_or_discover_playlists(force_refresh=True)
        else:
            self.get_channels(force_refresh=True)
        return self.last_scan_found

    def _scan_fail_file(self):
        return os.path.join(self.profile_dir, "scan_fail.json")

    def _scan_state_file(self):
        return os.path.join(self.profile_dir, "github_scan_state.json")

    def _rate_limit_file(self):
        return os.path.join(self.profile_dir, "github_rate_limit.json")

    def _scan_recently_run(self):
        try:
            path = self._scan_state_file()
            if not xbmcvfs.exists(path):
                return False
            with open(path, "r", encoding="utf-8") as f:
                timestamp = float(json.load(f).get("timestamp", 0))
            return time.time() - timestamp < self.MIN_SCAN_INTERVAL
        except Exception:
            return False

    def _mark_scan_started(self):
        try:
            with open(self._scan_state_file(), "w", encoding="utf-8") as f:
                json.dump({"timestamp": time.time()}, f)
        except Exception as e:
            xbmc.log(
                f"[gitplayger] Scan-Zeit konnte nicht gespeichert werden: {e}",
                xbmc.LOGWARNING,
            )

    def _github_rate_limited(self):
        try:
            path = self._rate_limit_file()
            if not xbmcvfs.exists(path):
                return False
            with open(path, "r", encoding="utf-8") as f:
                blocked_until = float(json.load(f).get("blocked_until", 0))
            if time.time() < blocked_until:
                remaining = int(blocked_until - time.time())
                xbmc.log(
                    "[gitplayger] GitHub-Suche pausiert. Noch ungefähr "
                    f"{max(1, remaining // 60)} Minuten Wartezeit.",
                    xbmc.LOGWARNING,
                )
                return True
            os.remove(path)
            return False
        except Exception:
            return False

    def _scan_recently_failed(self):
        try:
            path = self._scan_fail_file()
            if xbmcvfs.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    ts = json.load(f).get("timestamp", 0)
                return (time.time() - ts) < self.SCAN_FAIL_COOLDOWN
        except Exception:
            pass
        return False

    def _mark_scan_failed(self):
        try:
            with open(self._scan_fail_file(), "w", encoding="utf-8") as f:
                json.dump({"timestamp": time.time()}, f)
        except Exception:
            pass

    def _clear_scan_failed(self):
        try:
            path = self._scan_fail_file()
            if xbmcvfs.exists(path):
                os.remove(path)
        except Exception:
            pass

    def _load_index_data(self):
        if xbmcvfs.exists(self.index_file):
            try:
                with open(self.index_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {"timestamp": 0, "playlists": []}

    def _save_index_data(self, data):
        try:
            with open(self.index_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            xbmc.log(
                f"[gitplayger] Index konnte nicht gespeichert werden: {e}",
                xbmc.LOGWARNING,
            )

    def _ensure_scan_authorized(self, force_refresh=False):
        auth_file = os.path.join(self.profile_dir, "scan_auth.json")
        current_version = xbmcaddon.Addon().getAddonInfo("version")
        try:
            if xbmcvfs.exists(auth_file):
                with open(auth_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
            else:
                data = {}
        except Exception:
            data = {}

        if data.get("auth") is True and data.get("version") == current_version:
            return True

        if (
            data.get("version") == current_version
            and data.get("auth") is False
            and not force_refresh
        ):
            return False

        confirmed = xbmcgui.Dialog().yesno(
            "GitPlayGer – GitHub-Suche",
            "GitPlayGer kann automatisch nach neuen M3U-Playlists "
            "auf GitHub suchen.\n\nMöchtest du diese Suche erlauben?\n\n"
            "Ohne Zustimmung werden keine neuen GitHub-Playlists gesucht. "
            "Bereits gespeicherte Playlists und eigene M3U-Listen bleiben verfügbar.",
            nolabel="Nein",
            yeslabel="Ja",
        )

        try:
            with open(auth_file, "w", encoding="utf-8") as f:
                json.dump(
                    {"auth": bool(confirmed), "version": current_version},
                    f,
                    ensure_ascii=False,
                    indent=2,
                )
        except Exception as e:
            xbmc.log(
                f"[gitplayger] Scan-Freigabe konnte nicht gespeichert werden: {e}",
                xbmc.LOGERROR,
            )
        return confirmed

    def _get_cached_playlists_without_scan(self, custom_playlists):
        data = self._load_index_data()
        cached_playlists = data.get("playlists", [])
        if cached_playlists:
            return (custom_playlists + cached_playlists)[:self.MAX_PLAYLISTS + 3]
        local_playlists = self._find_local_fallback_playlists()
        return (custom_playlists + local_playlists)[:self.MAX_PLAYLISTS + 3]

    def _get_or_discover_playlists(self, force_refresh=False):
        current_time = time.time()
        custom_playlists = []

        try:
            addon = xbmcaddon.Addon()
            for i in range(1, 4):
                m3u_path = addon.getSetting(f"custom_m3u_{i}_url")
                if m3u_path:
                    enabled = addon.getSetting(f"custom_m3u_{i}_enabled") == "true"
                    custom_playlists.append({
                        "name": f"Eigene M3U {i} ({os.path.basename(m3u_path)})",
                        "url": f"custom_m3u_{i}_url",
                        "enabled": enabled,
                    })
        except Exception:
            pass

        if xbmcvfs.exists(self.index_file) and not force_refresh:
            try:
                with open(self.index_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                timestamp = data.get("timestamp", 0)
                cached_playlists = data.get("playlists", [])
                if (
                    cached_playlists
                    and current_time - timestamp < get_cache_duration()
                ):
                    xbmc.log(
                        "[gitplayger] Verwende gespeicherten GitHub-Playlist-Index.",
                        xbmc.LOGINFO,
                    )
                    return (custom_playlists + cached_playlists)[:self.MAX_PLAYLISTS + 3]
            except Exception as e:
                xbmc.log(
                    f"[gitplayger] Playlist-Cache ungültig: {e}",
                    xbmc.LOGWARNING,
                )

        if self._github_rate_limited():
            return self._get_cached_playlists_without_scan(custom_playlists)

        if self._scan_recently_run():
            xbmc.log(
                "[gitplayger] GitHub-Suche wurde innerhalb der letzten "
                "24 Stunden bereits gestartet. Vorhandener Index wird verwendet.",
                xbmc.LOGINFO,
            )
            return self._get_cached_playlists_without_scan(custom_playlists)

        if not force_refresh and self._scan_recently_failed():
            xbmc.log(
                "[gitplayger] Letzte GitHub-Suche fehlgeschlagen; "
                "neue Suche vorübergehend pausiert.",
                xbmc.LOGINFO,
            )
            return self._get_cached_playlists_without_scan(custom_playlists)

        if not self._ensure_scan_authorized(force_refresh):
            xbmc.log(
                "[gitplayger] GitHub-Suche nicht freigegeben. "
                "Verwende vorhandene Playlists ohne neuen Scan.",
                xbmc.LOGINFO,
            )
            return self._get_cached_playlists_without_scan(custom_playlists)

        xbmc.log(
            "[gitplayger] Starte GitHub-Suche nach deutschen M3U-Playlists.",
            xbmc.LOGINFO,
        )

        self._mark_scan_started()

        try:
            playlists = self._dynamic_github_search()
        except Exception as e:
            xbmc.log(
                f"[gitplayger] GitHub-Suche fehlgeschlagen: {e}",
                xbmc.LOGERROR,
            )
            playlists = []

        self.last_scan_found = len(playlists)

        if playlists:
            self._clear_scan_failed()
        else:
            self._mark_scan_failed()
            xbmc.log(
                "[gitplayger] GitHub-Suche hat keine Playlists geliefert.",
                xbmc.LOGWARNING,
            )

        if not playlists and xbmcvfs.exists(self.index_file):
            try:
                with open(self.index_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                playlists = data.get("playlists", [])
                xbmc.log(
                    "[gitplayger] Nutze alten Playlist-Index als Fallback.",
                    xbmc.LOGWARNING,
                )
            except Exception:
                playlists = []

        if not playlists:
            playlists = self._find_local_fallback_playlists()
            if playlists:
                xbmc.log(
                    "[gitplayger] Nutze lokale M3U-Dateien als Notfall-Fallback.",
                    xbmc.LOGWARNING,
                )

        combined_playlists = custom_playlists + playlists
        if combined_playlists:
            try:
                with open(self.index_file, "w", encoding="utf-8") as f:
                    json.dump(
                        {"timestamp": current_time, "playlists": combined_playlists},
                        f,
                        ensure_ascii=False,
                        indent=2,
                    )
            except Exception as e:
                xbmc.log(
                    f"[gitplayger] Index konnte nicht gespeichert werden: {e}",
                    xbmc.LOGWARNING,
                )

        return combined_playlists[:self.MAX_PLAYLISTS + 3]

    def _github_api_get(self, path, params=None):
        is_search = path.startswith("/search/")
        delay = self.SEARCH_REQUEST_DELAY if is_search else self.API_REQUEST_DELAY

        elapsed = time.time() - self._last_api_request
        if elapsed < delay:
            time.sleep(delay - elapsed)

        try:
            self._last_api_request = time.time()
            resp = self.session.get(
                self.GITHUB_API + path,
                params=params,
                timeout=15,
            )
        except Exception as e:
            xbmc.log(
                f"[gitplayger] GitHub-API nicht erreichbar: {e}",
                xbmc.LOGWARNING,
            )
            return None

        if resp.status_code in (403, 429):
            retry_after = resp.headers.get("Retry-After")
            reset = resp.headers.get("X-RateLimit-Reset")
            remaining = resp.headers.get("X-RateLimit-Remaining", "?")
            now = time.time()
            blocked_until = now + 3600

            try:
                if retry_after:
                    blocked_until = now + max(60, int(retry_after))
                elif reset:
                    blocked_until = max(now + 60, float(reset))
            except (TypeError, ValueError):
                pass

            try:
                with open(self._rate_limit_file(), "w", encoding="utf-8") as f:
                    json.dump({"blocked_until": blocked_until}, f)
            except Exception:
                pass

            xbmc.log(
                f"[gitplayger] GitHub-Limit erreicht (HTTP {resp.status_code}, "
                f"verbleibend: {remaining}). Suche wird pausiert.",
                xbmc.LOGWARNING,
            )
            resp.close()
            return "limit"

        if resp.status_code != 200:
            xbmc.log(
                f"[gitplayger] GitHub-API Antwort HTTP {resp.status_code} bei {path}",
                xbmc.LOGWARNING,
            )
            resp.close()
            return None

        try:
            result = resp.json()
        except Exception:
            result = None
        finally:
            resp.close()
        return result

    def _dynamic_github_search(self):
        candidates = []
        seen_urls = set()
        deadline = time.time() + self.SCAN_TIME_BUDGET

        for url, repo_name, label in self.SEED_PLAYLISTS:
            if time.time() > deadline:
                break
            seen_urls.add(url)
            candidate = self._analyze_playlist(url, label, {"full_name": repo_name})
            if candidate:
                candidates.append(candidate)

        xbmc.log(
            f"[gitplayger] Bekannte Quellen geprüft: {len(candidates)} brauchbar",
            xbmc.LOGINFO,
        )

        repo_queries = [
            "iptv german m3u",
            "iptv deutschland m3u",
            "german tv playlist m3u",
        ]
        repos = []
        seen_repos = set()
        limit_hit = False

        for query in repo_queries:
            if time.time() > deadline or limit_hit:
                break
            data = self._github_api_get(
                "/search/repositories",
                {"q": query, "sort": "updated", "order": "desc", "per_page": 10},
            )
            if data == "limit":
                limit_hit = True
                break
            if not isinstance(data, dict):
                continue

            for repo in data.get("items", []):
                full = repo.get("full_name")
                if (
                    not full
                    or full in seen_repos
                    or repo.get("fork")
                    or repo.get("archived")
                ):
                    continue
                seen_repos.add(full)
                repos.append((full, repo.get("default_branch") or "master"))

        xbmc.log(
            f"[gitplayger] GitHub-Repo-Suche: {len(repos)} Repositories gefunden",
            xbmc.LOGINFO,
        )

        hints = (
            "german", "deutsch", "germany", "deu", "_de",
            "-de", "/de", "de.", "ger",
        )

        for full, branch in repos[:8]:
            if time.time() > deadline or limit_hit:
                break
            tree = self._github_api_get(
                f"/repos/{full}/git/trees/{branch}",
                {"recursive": "1"},
            )
            if tree == "limit":
                limit_hit = True
                break
            if not isinstance(tree, dict):
                continue

            files = []
            for node in tree.get("tree", []):
                path = node.get("path", "")
                if (
                    node.get("type") == "blob"
                    and path.lower().endswith((".m3u", ".m3u8"))
                    and node.get("size", 0) <= self.MAX_M3U_SIZE
                ):
                    files.append(path)

            hinted = [p for p in files if any(h in p.lower() for h in hints)]
            chosen = (hinted or files[:1])[:3]

            for path in chosen:
                if time.time() > deadline:
                    break
                raw_url = (
                    f"https://raw.githubusercontent.com/{full}/{branch}/"
                    + requests.utils.quote(path)
                )
                if raw_url in seen_urls:
                    continue
                seen_urls.add(raw_url)
                candidate = self._analyze_playlist(
                    raw_url, path, {"full_name": full}
                )
                if candidate:
                    candidates.append(candidate)

        xbmc.log(
            f"[gitplayger] Suche abgeschlossen: {len(candidates)} Kandidaten",
            xbmc.LOGINFO,
        )

        candidates.sort(key=lambda x: x.get("score", 0), reverse=True)
        selected = []
        used_repos = set()

        for candidate in candidates:
            if len(selected) >= self.MAX_PLAYLISTS:
                break
            repo = candidate.get("repo", "")
            if repo in used_repos:
                continue
            used_repos.add(repo)
            selected.append({
                "name": candidate["name"],
                "url": candidate["url"],
                "enabled": True,
            })

        if len(selected) < self.MAX_PLAYLISTS:
            selected_urls = {item["url"] for item in selected}
            for candidate in candidates:
                if len(selected) >= self.MAX_PLAYLISTS:
                    break
                url = candidate.get("url")
                if not url or url in selected_urls:
                    continue
                selected.append({
                    "name": candidate["name"],
                    "url": url,
                    "enabled": True,
                })
                selected_urls.add(url)

        return selected[:self.MAX_PLAYLISTS]

    def _find_m3u_files_in_repo(self, repo):
        return []

    def _analyze_playlist(self, url, path, repo):
        try:
            resp = self.session.get(url, timeout=10, stream=True)
            if resp.status_code != 200:
                resp.close()
                return None

            chunks = []
            total = 0
            try:
                for chunk in resp.iter_content(chunk_size=65536):
                    if not chunk:
                        continue
                    chunks.append(chunk)
                    total += len(chunk)
                    if total >= self.MAX_M3U_SIZE:
                        break
            finally:
                resp.close()

            content = b"".join(chunks).decode("utf-8", errors="ignore")
        except Exception:
            return None

        if "#EXTM3U" not in content and "#EXTINF" not in content:
            return None

        extinf_count = len(re.findall(r"#EXTINF:", content, re.IGNORECASE))
        if extinf_count < 3:
            return None

        content_lower = content.lower()
        german_channels = [
            "ard", "zdf", "rtl", "rtl2", "rtl ii", "vox", "sat.1", "sat1",
            "pro7", "prosieben", "kabel eins", "kabel1", "sixx", "n24",
            "welt", "ntv", "phoenix", "arte", "3sat", "super rtl", "tele 5",
            "tele5", "dmax", "kika", "kinderkanal", "tagesschau", "one",
            "zdfinfo", "zdf neo", "zdfneo", "hr fernsehen", "ndr", "wdr",
            "swr", "br fernsehen", "mdr", "rbb", "sr fernsehen", "servus tv",
            "nitro", "rtlup", "rtl up", "voxup", "joyn", "pluto tv",
        ]
        german_hits = sum(content_lower.count(ch) for ch in german_channels)
        german_words = [
            "deutsch", "german", "germany", "deutschland",
            "deutschland tv", "deutsch tv", "german tv", "german television",
        ]
        keyword_hits = sum(content_lower.count(w) for w in german_words)

        score = 10
        score += min(german_hits * 8, 70)
        score += min(keyword_hits * 5, 30)
        score += min(extinf_count / 10, 20)

        repo_name = repo.get("full_name", "GitHub")
        playlist_name = f"{repo_name} / {path}"
        return {
            "name": playlist_name,
            "url": url,
            "repo": repo_name,
            "path": path,
            "score": score,
            "channels": extinf_count,
            "german_hits": german_hits,
        }

    def _find_local_fallback_playlists(self):
        fallback = []
        try:
            dirs, files = xbmcvfs.listdir(self.profile_dir)
            for filename in files:
                if not filename.lower().endswith(".m3u"):
                    continue
                name = filename.rsplit(".", 1)[0].replace("_", " ").strip().title()
                path = os.path.join(self.profile_dir, filename)
                fallback.append({"name": name, "url": path, "enabled": True})
        except Exception as e:
            xbmc.log(
                f"[gitplayger] Lokaler Fallback fehlgeschlagen: {e}",
                xbmc.LOGWARNING,
            )
        return fallback[:self.MAX_PLAYLISTS]

    def _parse_m3u(self, content, source_name):
        channels = []
        current_channel = {}

        for line in content.splitlines():
            line = line.strip()
            if not line:
                continue

            if line.startswith("#EXTINF:"):
                current_channel = {"source": source_name}
                current_channel["logo"] = self._extract_attr(line, 'tvg-logo="')
                raw_group = self._extract_attr(line, 'group-title="')
                group = self._clean_text(raw_group)
                current_channel["genre"] = group if group else f"Quelle: {source_name}"

                if "," in line:
                    raw_name = line.rsplit(",", 1)[-1].strip()
                    current_channel["name"] = self._clean_text(raw_name)
                else:
                    current_channel["name"] = "Unbekannt"

            elif line and not line.startswith("#") and current_channel:
                current_channel["url"] = line
                current_channel["description"] = (
                    "Sender: " + current_channel.get("name", "")
                    + " | Quelle: " + source_name
                )
                if current_channel.get("name") and current_channel.get("url"):
                    channels.append(current_channel)
                current_channel = {}

        return channels

    def _clean_text(self, text):
        if not text:
            return ""
        cleaned = re.sub(
            r'[^\w\s\-\.,\(\)&/\+\!\?äöüÄÖÜßëçÇË]', "", text
        )
        return " ".join(cleaned.split()).strip()

    def _extract_attr(self, line, attr_key):
        if attr_key not in line:
            return ""
        try:
            return line.split(attr_key, 1)[1].split('"', 1)[0]
        except Exception:
            return ""

    def _get_favorites_path(self):
        profile_dir = xbmcvfs.translatePath(
            xbmcaddon.Addon().getAddonInfo("profile")
        )
        if not xbmcvfs.exists(profile_dir):
            xbmcvfs.mkdirs(profile_dir)
        return os.path.join(profile_dir, "favorites.json")

    def get_favorites(self):
        fav_path = self._get_favorites_path()
        if xbmcvfs.exists(fav_path):
            try:
                f = xbmcvfs.File(fav_path, "r")
                data = json.loads(f.read())
                f.close()
                return data
            except Exception:
                pass
        return []

    def is_favorite(self, url):
        return any(f.get("url") == url for f in self.get_favorites())

    def add_favorite(self, channel):
        favorites = self.get_favorites()
        if not any(f.get("url") == channel.get("url") for f in favorites):
            favorites.append(channel)
            self._save_favorites(favorites)

    def remove_favorite(self, url):
        favorites = [
            f for f in self.get_favorites() if f.get("url") != url
        ]
        self._save_favorites(favorites)

    def _save_favorites(self, favorites):
        fav_path = self._get_favorites_path()
        f = xbmcvfs.File(fav_path, "w")
        f.write(json.dumps(favorites, ensure_ascii=False, indent=4))
        f.close()

    def _get_themes_path(self):
        profile_dir = xbmcvfs.translatePath(
            xbmcaddon.Addon().getAddonInfo("profile")
        )
        if not xbmcvfs.exists(profile_dir):
            xbmcvfs.mkdirs(profile_dir)
        return os.path.join(profile_dir, "favorite_themes.json")

    def get_favorite_themes(self):
        path = self._get_themes_path()
        if xbmcvfs.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save_favorite_themes(self, themes):
        path = self._get_themes_path()
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(themes, f, ensure_ascii=False, indent=2)
        except Exception as e:
            xbmc.log(
                f"[gitplayger] Fehler beim Speichern der Themen: {e}",
                xbmc.LOGERROR,
            )

    def create_favorite_theme(self, theme_name):
        themes = self.get_favorite_themes()
        if theme_name not in themes:
            themes[theme_name] = []
            self._save_favorite_themes(themes)

    def delete_favorite_theme(self, theme_name):
        themes = self.get_favorite_themes()
        if theme_name in themes:
            del themes[theme_name]
            self._save_favorite_themes(themes)

    def add_channel_to_theme(self, theme_name, channel):
        themes = self.get_favorite_themes()
        if theme_name not in themes:
            themes[theme_name] = []
        if not any(c.get("url") == channel.get("url") for c in themes[theme_name]):
            themes[theme_name].append(channel)
            self._save_favorite_themes(themes)

    def remove_channel_from_theme(self, theme_name, stream_url):
        themes = self.get_favorite_themes()
        if theme_name in themes:
            themes[theme_name] = [
                c for c in themes[theme_name] if c.get("url") != stream_url
            ]
            self._save_favorite_themes(themes)
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum des Autors.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.