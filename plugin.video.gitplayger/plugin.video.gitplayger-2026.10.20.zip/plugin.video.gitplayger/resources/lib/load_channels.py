# -*- coding: utf-8 -*-
# GitPlayGer 
# Copyright (c) 2026 Team IT('s) Possible. All rights reserved.
# Version 2026.10.16
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
import sys
import urllib.parse
import json
import os
import re
import uuid
from time import time
from datetime import datetime
import math
import hashlib
from xml.dom import minidom
import xbmcaddon
import xbmcgui
import requests
import xbmc
import xbmcvfs
import unicodedata


def _auto_clean(val):
    if isinstance(val, str):
        cleaned = re.sub(r'[\U00010000-\U0010ffff]|[\u2600-\u27bf]|[\U0001f300-\U0001f5ff]|[\U0001f600-\U0001f64f]|[\U0001f680-\U0001f6ff]', '', val)
        cleaned = re.sub(r'^[^\w\säöüÄÖÜß]+', '', cleaned)
        return cleaned.strip()
    elif isinstance(val, dict):
        return {k: _auto_clean(v) for k, v in val.items()}
    elif isinstance(val, list):
        return [_auto_clean(v) for v in val]
    return val

_original_json_loads = json.loads
def _patched_json_loads(s, *args, **kwargs):
    result = _original_json_loads(s, *args, **kwargs)
    return _auto_clean(result)

json.loads = _patched_json_loads


key = None
mac = ':'.join(re.findall('..', '%012x' % uuid.getnode()))
sn = None
device_id = None
device_id2 = None
signature = None
stlink = None
cache_version = '3'

dialog = xbmcgui.Dialog()
addon = xbmcaddon.Addon()
profile_dir = xbmcvfs.translatePath(addon.getAddonInfo('profile')) if hasattr(xbmcvfs, 'translatePath') else xbmcvfs.translatePath(addon.getAddonInfo('profile'))
addondir = os.path.join(profile_dir, 'hunter')
if not xbmcvfs.exists(addondir):
    xbmcvfs.mkdirs(addondir)
addonname = addon.getAddonInfo('name')

session = requests.Session()
session.verify = False

USER_AGENTS = [
    'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36',
    'Mozilla/5.0 (STB; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) QtWebEngine/5.21.0 Chrome/87.0.4280.144 Safari/537.36 MAG322'
]

def is_json(myjson):
    if not myjson:
        return False
    try:
        json.loads(myjson)
    except (ValueError, TypeError):
        return False
    return True

def setMac(nmac):
    global mac
    if nmac and re.match("[0-9a-f]{2}([-:])[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$", nmac.lower()):
        mac = nmac

def getMac():
    global mac
    return mac

def setSerialNumber(serial):
    global sn, device_id, device_id2, signature
    if serial is None:
        sn = hashlib.md5(mac.encode('utf-8')).hexdigest().upper()[13:]
        device_id = hashlib.sha256(sn.encode('utf-8')).hexdigest().upper()
        device_id2 = hashlib.sha256(mac.encode('utf-8')).hexdigest().upper()
        signature = hashlib.sha256((sn + mac).encode('utf-8')).hexdigest().upper()
    elif serial.get('custom') is False:
        sn = hashlib.md5(mac.encode('utf-8')).hexdigest().upper()[13:]
        device_id = hashlib.sha256(sn.encode('utf-8')).hexdigest().upper()
        device_id2 = hashlib.sha256(mac.encode('utf-8')).hexdigest().upper()
        signature = hashlib.sha256((sn + mac).encode('utf-8')).hexdigest().upper()
    elif serial.get('custom') is True:
        sn = serial.get('sn')
        device_id = serial.get('device_id')
        device_id2 = serial.get('device_id2')
        signature = serial.get('signature')

def handshake(url):
    global key
    if key is not None:
        return
    try:
        info = retrieveData(url, values={
            'type': 'stb', 
            'action': 'handshake',
            'JsHttpRequest': '1-xml'})
        if info and isinstance(info, dict):
            key = info.get('js', {}).get('token')
        getProfile(url)
    except Exception:
        pass

def getProfile(url):
    global sn, device_id, device_id2, signature
    values = {
        'type': 'stb', 
        'action': 'get_profile',
        'hd': '1',
        'ver': 'ImageDescription:%200.2.18-r11-pub-254;%20ImageDate:%20Wed%20Mar%2018%2018:09:40%20EET%202015;%20PORTAL%20version:%204.9.14;%20API%20Version:%20JS%20API%20version:%20331;%20STB%20API%20version:%20141;%20Player%20Engine%20version:%200x572',
        'num_banks': '1',
        'stb_type': 'MAG254',
        'image_version': '218',
        'auth_second_step': '0',
        'hw_version': '2.6-IB-00',
        'not_valid_token': '0',
        'JsHttpRequest': '1-xml'}

    if sn is not None:
        values['sn'] = sn
        values['device_id'] = device_id
        values['device_id2'] = device_id2
        values['signature'] = signature

    try:
        retrieveData(url, values)
    except Exception:
        pass

def retrieveData(url, values):
    global key, mac
    load = '/portal.php'
    api_url = url.rstrip('/') + load if not url.endswith('/portal.php') else url
    refer = '/c/'
    timezone = 'Europe%2FBerlin'
    
    headers = { 
        'User-Agent': USER_AGENTS[0], 
        'Referer': url.rstrip('/') + refer,
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'Keep-Alive',
        'X-Requested-With': 'XMLHttpRequest',
        'X-User-Agent': 'Model: MAG254; Link: Ethernet'
    }
    
    cookies = {
        'mac': mac,
        'stb_lang': 'en',
        'timezone': timezone
    }
    
    if key is not None:
        headers['Authorization'] = 'Bearer ' + key
   
    resp_text = ""
    try:
        r = session.get(api_url, params=values, headers=headers, cookies=cookies, timeout=8)
        resp_text = r.text
        if not is_json(resp_text):
            r = session.post(api_url, data=values, headers=headers, cookies=cookies, timeout=8)
            resp_text = r.text
    except Exception as e:
        resp_text = str(e)

    if not is_json(resp_text):
        raise Exception("Ungültige Portal-Antwort oder Server blockiert (Kein JSON)")

    return json.loads(resp_text)

def getGenres(portal_mac, url, serial, path):    
    global key, cache_version
    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", url))
    portalurl = os.path.join(path, portalurl + '-genres')
    
    setMac(portal_mac)
    setSerialNumber(serial)
    
    if not os.path.exists(path): 
        os.makedirs(path)
    
    if os.path.exists(portalurl):
        try:
            with open(portalurl, 'r', encoding='utf-8') as data_file:
                data = json.load(data_file)
            if data.get('version') == cache_version:
                if ((now - float(data.get('time', 0))) / 3600) < 12:
                    return data
        except Exception:
            pass
    
    handshake(url)
    info = retrieveData(url, values={'type': 'itv', 'action': 'get_genres', 'JsHttpRequest': '1-xml'})
    results = info.get('js', [])
    
    genres_dict = {}
    for i in results:
        alias = i.get("alias", "")
        gid = str(i.get("id", ""))
        title = i.get('title', "")
        genres_dict[gid] = {"alias": alias, "title": title}
    
    data = {"version": cache_version, "time": str(now), "genres": genres_dict}
    try:
        with open(portalurl, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception:
        pass
    
    return data

def getAllChannels(portal_mac, url, serial, path):
    global key
    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", url))
    portalurl = os.path.join(path, portalurl + 'channels')
    
    setMac(portal_mac)
    setSerialNumber(serial)
    
    if not os.path.exists(path):
        os.makedirs(path)

    if os.path.exists(portalurl):
        try:
            with open(portalurl, 'r', encoding='utf-8') as data_file:
                data = json.load(data_file)
            if data.get('version') == cache_version:
                if ((now - float(data.get('time', 0))) / 3600) < 12:
                    return data
        except Exception:
            pass
    
    handshake(url)
    channels = []
    info = retrieveData(url, values={'type': 'itv', 'action': 'get_all_channels', 'JsHttpRequest': '1-xml'})

    for result in info.get('js', {}).get('data', []):
        channels.append({
            "id": str(result.get('id')),
            "number": result.get("number"),
            "name": result.get("name"),
            "cmd": result.get('cmd'),
            "logo": result.get("logo"),
            "tmp": result.get("use_http_tmp_link"),
            "genre_id": str(result.get('tv_genre_id')),
        })

    data = {"version": cache_version, "time": now, 'channels': channels}
    try:
        with open(portalurl, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception:
        pass
    
    return data

def getVoDgenres(portal_mac, url, serial, path):    
    global key, cache_version
    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", url))
    portalurl = os.path.join(path, portalurl + '-vodgenres')
    
    setMac(portal_mac)
    setSerialNumber(serial)
    
    if not os.path.exists(path):
        os.makedirs(path)
    
    if os.path.exists(portalurl):
        try:
            with open(portalurl, 'r', encoding='utf-8') as data_file:
                data = json.load(data_file)
            if data.get('version') == cache_version:
                if ((now - float(data.get('time', 0))) / 3600) < 12:
                    return data
        except Exception:
            pass
    
    handshake(url)
    info = retrieveData(url, values={'type': 'vod', 'action': 'get_categories', 'JsHttpRequest': '1-xml'})
    results = info.get('js', [])
    
    vodgenres_dict = {}
    for i in results:
        alias = i.get("alias", "")
        gid = str(i.get("id", ""))
        title = i.get('title', "")
        vodgenres_dict[gid] = {"alias": alias, "title": title, "cat": gid}
    
    data = {"version": cache_version, "time": str(now), "vodgenres": vodgenres_dict}
    try:
        with open(portalurl, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception:
        pass
    
    return data

def getVoD(portal_mac, url, serial, path):
    global key
    args = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
    cat = args.get('cat', [''])[0]
    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", url))
    portalurl = os.path.join(path, portalurl + '-vod' + cat)
    
    setMac(portal_mac)
    setSerialNumber(serial)
    
    if not os.path.exists(path):
        os.makedirs(path)
    
    if os.path.exists(portalurl):
        try:
            with open(portalurl, 'r', encoding='utf-8') as data_file:
                data = json.load(data_file)
            if data.get('version') == cache_version:
                if ((now - float(data.get('time', 0))) / 3600) < 12:
                    return data
        except Exception:
            pass
    
    handshake(url)
    vod_list = []
    page = 1
    
    while True:
        try:
            info = retrieveData(url, values={
                'type': 'vod', 
                'action': 'get_ordered_list',
                'category': cat,
                'sortby': 'added',
                'not_ended': '0',
                'p': page,
                'fav': '0',
                'JsHttpRequest': '1-xml'})
        except Exception:
            break
        
        js_data = info.get('js', {})
        total_items = float(js_data.get('total_items', 1))
        max_page_items = float(js_data.get('max_page_items', 1))
        pages = math.ceil(total_items / max_page_items) if max_page_items > 0 else 1
        
        results = js_data.get('data', [])
        if not results:
            break
            
        for i in results:
            plot = i.get("description", "") or ""
            plot = plot.replace('"', "-").replace("\r", "").replace("\n", " ").replace("  ", " ")
            vod_list.append({
                "name": i.get("name", ""),
                "cmd": i.get("cmd", ""),
                "logo": i.get("screenshot_uri", ""),
                "plot": plot,
                "genre": i.get('genres_str', ""),
                "year": str(i.get("year", ""))
            })
            
        page += 1
        if page > pages or page >= 300:
            break

    data = {"version": cache_version, "time": str(now), 'vod' + cat: vod_list}
    try:
        with open(portalurl, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception:
        pass
    
    return data

def getSergenres(portal_mac, url, serial, path):    
    global key, cache_version
    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", url))
    portalurl = os.path.join(path, portalurl + '-sergenres')
    
    setMac(portal_mac)
    setSerialNumber(serial)
    
    if not os.path.exists(path):
        os.makedirs(path)
    
    if os.path.exists(portalurl):
        try:
            with open(portalurl, 'r', encoding='utf-8') as data_file:
                data = json.load(data_file)
            if data.get('version') == cache_version:
                if ((now - float(data.get('time', 0))) / 3600) < 12:
                    return data
        except Exception:
            pass
    
    handshake(url)
    info = retrieveData(url, values={'type': 'series', 'action': 'get_categories', 'JsHttpRequest': '1-xml'})
    results = info.get('js', [])
    
    sergenres_dict = {}
    for i in results:
        alias = i.get("alias", "")
        gid = str(i.get("id", ""))
        title = i.get('title', "")
        sergenres_dict[gid] = {"alias": alias, "title": title, "cat": gid}
    
    data = {"version": cache_version, "time": str(now), "sergenres": sergenres_dict}
    try:
        with open(portalurl, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception:
        pass
    
    return data

def getSeries(portal_mac, url, serial, path):
    global key
    args = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
    cat = args.get('cat', [''])[0]
    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", url))
    portalurl = os.path.join(path, portalurl + '-ser' + cat)
    
    setMac(portal_mac)
    setSerialNumber(serial)
    
    if not os.path.exists(path):
        os.makedirs(path)
    
    if os.path.exists(portalurl):
        try:
            with open(portalurl, 'r', encoding='utf-8') as data_file:
                data = json.load(data_file)
            if data.get('version') == cache_version:
                if ((now - float(data.get('time', 0))) / 3600) < 12:
                    return data
        except Exception:
            pass
    
    handshake(url)
    series = []
    for page in range(1, 300):
        try:
            info = retrieveData(url, values={
                'type': 'series', 
                'action': 'get_ordered_list',
                'category': cat,
                'sortby': 'added',
                'not_ended': '0',
                'p': page,
                'fav': '0',
                'JsHttpRequest': '1-xml'})
        except Exception:
            break
        
        js_data = info.get('js', {})
        total_items = js_data.get('total_items', 0)
        results = js_data.get('data', [])
        if not results:
            break
            
        for result in results:
            plot = result.get("description", "") or ""
            plot = plot.replace('"', "-").replace("\r", "").replace("\n", " ").replace("  ", " ")
            series.append({
                "category": str(result.get('category_id', '')),
                "cat": str(result.get("id", "")),
                "name": result.get("name", ""),
                "cmd": result.get('cmd', ""),
                "logo": result.get("screenshot_uri", ""),
                "plot": plot,
                "genre": result.get('genres_str', ""),
                "year": str(result.get("year", ""))
            })
        if len(series) >= total_items:
            break

    data = {"version": cache_version, "time": now, 'ser' + cat: series}
    try:
        with open(portalurl, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception:
        pass
            
    return data

def get_seasons(portal_mac, url, serial, path):
    global key
    args = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
    cat = args.get('cat', [''])[0]
    category = args.get('category', [''])[0]
    now = time()
    
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", url))
    portalurl = os.path.join(path, portalurl + '-seasons' + cat)

    setMac(portal_mac)
    setSerialNumber(serial)
    
    if not os.path.exists(path):
        os.makedirs(path)
    
    if os.path.exists(portalurl):
        try:
            with open(portalurl, 'r', encoding='utf-8') as data_file:
                data = json.load(data_file)
            if data.get('version') == cache_version:
                if ((now - float(data.get('time', 0))) / 3600) < 12:
                    return data
        except Exception:
            pass
    
    handshake(url)
    seasons = []
    for page in range(1, 300):
        try:
            info = retrieveData(url, values={
                'type': 'series', 
                'action': 'get_ordered_list',
                'category': category,
                'movie_id': cat,
                'sortby': 'added',
                'season_id': '0',
                'episod_id': '0',
                'p': page,
                'JsHttpRequest': '1-xml'})
        except Exception:
            break
            
        js_data = info.get('js', {})
        total_items = js_data.get('total_items', 0)
        results = js_data.get('data', [])
        if not results:
            break

        for result in results:
            plot = result.get("description", "") or ""
            plot = plot.replace('"', "-").replace("\r", "").replace("\n", " ").replace("  ", " ")
            seasons.append({
                "name": result.get('name', ''),
                "category": str(result.get('category_id', '')),
                "cat": str(result.get("id", "")),
                "cmd": result.get('cmd', ''),
                "logo": result.get("screenshot_uri", ''),
                "plot": plot,
                "genre": result.get('genres_str', ''),
                "year": str(result.get("year", "")),
                "series": result.get("series", []),
            })
        if len(seasons) >= total_items:
            break

    data = {"version": cache_version, "time": now, 'seasons' + cat: seasons}
    try:
        with open(portalurl, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception:
        pass
   
    return data

def get_episodes(portal_mac, url, serial, path):
    global key
    args = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
    cat = args.get('cat', [''])[0]
    category = args.get('category', [''])[0]
    now = time()
    
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", url))
    portalurl = os.path.join(path, portalurl + '-episodes')

    setMac(portal_mac)
    setSerialNumber(serial)
    
    if not os.path.exists(path):
        os.makedirs(path)

    handshake(url)
    episodes = []
    
    for page in range(1, 5):
        try:
            info = retrieveData(url, values={
                'type': 'series', 
                'action': 'get_ordered_list',
                'category': category,
                'movie_id': cat,
                'sortby': 'added',
                'season_id': '0',
                'episod_id': '0',
                'p': page,
                'JsHttpRequest': '1-xml'})
        except Exception:
            break
            
        js_data = info.get('js', {})
        total_items = js_data.get('total_items', 0)
        dicts = js_data.get('data', [])
        if not dicts:
            break
        
        epi = next((index for (index, d) in enumerate(dicts) if str(d.get("id")) == str(cat)), None)
        if epi is not None and len(dicts) > epi:
            series_items = dicts[epi].get('series', [])
            for item in series_items:
                for result in dicts:
                    episodes.append({
                        "episode": str(item),
                        "name": result.get('name', ''),
                        "category": str(result.get('category_id', '')),
                        "cat": str(result.get("id", "")),
                        "cmd": result.get('cmd', ''),
                        "logo": result.get("screenshot_uri", ''),
                        "genre": result.get('genres_str', ''),
                        "year": str(result.get("year", "")),
                        "series": result.get("series", []),
                    })
        if len(episodes) >= total_items:
            break

    data = {"version": cache_version, "time": now, 'episodes': episodes}
    try:
        with open(portalurl, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception:
        pass
   
    return data

def retriveUrl(portal_mac, url, serial, channel, tmp):
    setMac(portal_mac)
    setSerialNumber(serial)
    if 'matrix' in channel:
        return retrieve_matrixUrl(url, channel)
    else:
        return retrive_defaultUrl(url, channel, tmp)
 
def retrive_defaultUrl(url, channel, tmp):
    if tmp == '0' or not tmp:
        s = channel.split(' ')
        res_url = s[0]
        if len(s) > 1:
            res_url = s[1]
        return res_url

    handshake(url)
    try:
        info = retrieveData(url, values={
            'type': 'itv', 
            'action': 'create_link', 
            'cmd': channel,
            'forced_storage': 'undefined',
            'disable_ad': '0',
            'JsHttpRequest': '1-xml'})
        cmd = info.get('js', {}).get('cmd', channel)
    except Exception:
        cmd = channel

    s = cmd.split(' ')
    res_url = s[0]
    if len(s) > 1:
        res_url = s[1]

    try:
        r = session.head(res_url, timeout=5, allow_redirects=True)
        res_url = r.url
    except Exception:
        pass
    return res_url

def retrieve_matrixUrl(url, channel):
    channel_parts = channel.split('/')
    ch_val = channel_parts[-1]
    matrix_url = url.rstrip('/') + '/server/api/matrix.php?channel=' + ch_val + '&mac=' + mac
    
    try:
        r = session.get(matrix_url, timeout=5)
        data = r.text
        _s1 = data.split(' ')
        data_val = _s1[0]
        if len(_s1) > 1:
            data_val = _s1[-1]
        return data_val
    except Exception:
        return url

def retriveVoD(portal_mac, url, serial, video):
    setMac(portal_mac)
    setSerialNumber(serial)
    s = video.split(' ')
    res_url = s[0]
    if len(s) > 1:
        res_url = s[1]
    
    res_url = res_url.replace('TOMTOM:', 'http://')
    try:
        r = session.get(res_url, timeout=5, allow_redirects=True)
        res_url = r.url
    except Exception:
        pass
    return res_url

def orderChannels(channels):
    n_data = {}
    for i in channels:
        number = i.get("number", 0)
        try:
            n_data[int(number)] = i
        except (ValueError, TypeError):
            n_data[0] = i
    ordered = sorted(n_data.keys())
    return [n_data[i] for i in ordered]

def getEpistream(portal_mac, url, serial, path):
    global key
    dp = xbmcgui.DialogProgressBG()
    dp.create('IPTV', 'Bitte warten ...')
    
    args = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
    cmd = args.get('cmd', [''])[0]
    episode = args.get('episode', [''])[0]
    
    setMac(portal_mac)
    setSerialNumber(serial)
    handshake(url)
    dp.update(20)
    
    try:
        info = retrieveData(url, values={
            'type': 'vod', 
            'action': 'create_link',
            'cmd': cmd,
            'series': episode,
            'JsHttpRequest': '1-xml'})
    except Exception:
        info = {}
        
    dp.update(40)
    results = info.get('js', {}).get('cmd', '')
    results = results.replace("ffmpeg ", "")
    title = args.get('episode', [''])[0]
    name = args.get('name', [''])[0]    
    
    li = xbmcgui.ListItem(title)
    li.setInfo('video', {'Title': 'Episode:' + title + '  ' + name})
    dp.update(100)
    dp.close()
    xbmc.Player().play(item=results, listitem=li)

def getStream(portal_mac, url, serial, path):
    global key
    dp = xbmcgui.DialogProgressBG()
    dp.create('IPTV', 'Bitte warten ...')
    
    args = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
    cmd = args.get('cmd', [''])[0]
    
    setMac(portal_mac)
    setSerialNumber(serial)
    handshake(url)
    dp.update(20)
    
    try:
        info = retrieveData(url, values={
            'type': 'vod', 
            'action': 'create_link',
            'cmd': cmd,
            'JsHttpRequest': '1-xml'})
    except Exception:
        info = {}
        
    dp.update(40)
    results = info.get('js', {}).get('cmd', '')
    results = results.replace("ffmpeg ", "")
    title = args.get('title', [''])[0]
    
    li = xbmcgui.ListItem(title)
    li.setInfo('video', {'Title': title})
    dp.update(100)
    dp.close()
    xbmc.Player().play(item=results, listitem=li)

def getTvStream(portal_mac, url, serial, path):
    global key
    dp = xbmcgui.DialogProgressBG()
    dp.create('IPTV', 'Bitte warten ...')
    
    args = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
    cmd = args.get('cmd', [''])[0]
    
    setMac(portal_mac)
    setSerialNumber(serial)
    handshake(url)
    dp.update(20)
    
    try:
        info = retrieveData(url, values={
            'type': 'itv', 
            'action': 'create_link',
            'cmd': cmd,
            'JsHttpRequest': '1-xml'})
    except Exception:
        info = {}
        
    dp.update(40)
    results = info.get('js', {}).get('cmd', '')
    results = results.replace("ffmpeg ", "")
    title = args.get('title', [''])[0]
    
    li = xbmcgui.ListItem(title)
    li.setInfo('video', {'Title': title})
    dp.update(100)
    dp.close()
    xbmc.Player().play(item=results, listitem=li)

def getEPG(portal_mac, url, serial, path):
    global key, cache_version
    now = time()
    portalurl = "_".join(re.findall("[a-zA-Z0-9]+", url))
    portalurl = os.path.join(path, portalurl + '-epg')
    
    setMac(portal_mac)
    setSerialNumber(serial)
    
    if not os.path.exists(path): 
        os.makedirs(path)
    
    if os.path.exists(portalurl):
        try:
            xmldoc = minidom.parse(portalurl)
            itemlist = xmldoc.getElementsByTagName('tv')
            if itemlist:
                version = itemlist[0].attributes['cache-version'].value
                if version == cache_version:
                    time_init = float(itemlist[0].attributes['cache-time'].value)
                    if ((now - time_init) / 3600) < 2:
                        return xmldoc.toxml(encoding='utf-8')
        except Exception:
            pass
    
    channels_data = getAllChannels(portal_mac, url, serial, path)
    channels_map = {str(c['id']): c for c in channels_data.get('channels', [])}
    
    handshake(url)
    try:
        info = retrieveData(url, values={
            'type': 'itv', 
            'action': 'get_epg_info',
            'period': '6',
            'JsHttpRequest': '1-xml'})
    except Exception:
        info = {}

    results = info.get('js', {}).get('data', {})
    
    doc = minidom.Document()
    base = doc.createElement('tv')
    base.setAttribute("cache-version", cache_version)
    base.setAttribute("cache-time", str(now))
    base.setAttribute("generator-info-name", "IPTV Plugin")
    base.setAttribute("generator-info-url", "http://www.xmltv.org/")
    doc.appendChild(base)

    for c in results:
        if str(c) not in channels_map:
            continue
        channel = channels_map[str(c)]
        name = channel['name']
        
        c_entry = doc.createElement('channel')
        c_entry.setAttribute("id", str(c))
        base.appendChild(c_entry)
                
        dn_entry = doc.createElement('display-name')
        dn_entry.appendChild(doc.createTextNode(name))
        c_entry.appendChild(dn_entry)
    
    for k, v in list(results.items()):
        channel = channels_map.get(str(k))
        for epg in v:
            try:
                start_time = datetime.fromtimestamp(float(epg['start_timestamp']))
                stop_time = datetime.fromtimestamp(float(epg['stop_timestamp']))
            except Exception:
                continue
            
            pg_entry = doc.createElement('programme')
            pg_entry.setAttribute("start", start_time.strftime('%Y%m%d%H%M%S -0000'))
            pg_entry.setAttribute("stop", stop_time.strftime('%Y%m%d%H%M%S -0000'))
            pg_entry.setAttribute("channel", str(k))
            base.appendChild(pg_entry)
            
            t_entry = doc.createElement('title')
            t_entry.setAttribute("lang", "en")
            t_entry.appendChild(doc.createTextNode(epg.get('title', '')))
            pg_entry.appendChild(t_entry)
            
            d_entry = doc.createElement('desc')
            d_entry.setAttribute("lang", "en")
            d_entry.appendChild(doc.createTextNode(epg.get('descr', '')))
            pg_entry.appendChild(d_entry)
            
            if 'on_date' in epg:
                dt_entry = doc.createElement('date')
                dt_entry.appendChild(doc.createTextNode(epg['on_date']))
                pg_entry.appendChild(dt_entry)
            
            if 'category' in epg:
                c_entry = doc.createElement('category')
                c_entry.appendChild(doc.createTextNode(epg['category']))
                pg_entry.appendChild(c_entry)
                    
            if channel and channel.get('logo'):
                i_entry = doc.createElement('icon')
                i_entry.setAttribute("src", url.rstrip('/') + ':8080/misc/logos/320/' + channel['logo'])
                pg_entry.appendChild(i_entry)
    
    xml_str = doc.toxml(encoding='utf-8')
    try:
        with open(portalurl, 'wb') as f:
            f.write(xml_str)
    except Exception:
        pass
    
    return xml_str
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum des Autors.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.