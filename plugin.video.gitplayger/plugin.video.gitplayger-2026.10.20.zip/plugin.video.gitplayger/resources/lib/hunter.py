# -*- coding: utf-8 -*-
# GitPlayGer 
# Copyright (c) 2026 Team IT('s) Possible. All rights reserved.
# Version 2026.10.16
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte
# Weiterverbreitung des Codes ist strengstens untersagt.
import sys
import os
import json
import urllib.parse
import unicodedata
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from . import load_channels

import hashlib
import re
import time
import datetime
from . import config
import requests
import random
import threading
import urllib3
from requests.adapters import HTTPAdapter

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_thread_local = threading.local()
portal = config.portalConfig('1')

def get_thread_session():
    if not hasattr(_thread_local, "session"):
        session = requests.Session()
        session.verify = False
        adapter = HTTPAdapter(pool_connections=10, pool_maxsize=10, max_retries=1)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        _thread_local.session = session
    return _thread_local.session

    
def _auto_clean(val):
    if isinstance(val, str):
        cleaned = re.sub(r'[\U00010000-\U0010ffff]|[\u2600-\u27bf]|[\U0001f300-\U0001f5ff]|[\U0001f600-\U0001f64f]|[\U0001f680-\U0001f6ff]', '', val)
        cleaned = re.sub(r'^[^\w\säöüÄÖÜß]+', '', cleaned)
        return cleaned.strip()
    elif isinstance(val, dict):
        return {k: _auto_clean(v) for k, v in val.items()}
    elif isinstance(val, list):
        return [_auto_clean(v) for v in val]
    return val


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

dialog = xbmcgui.Dialog()
addon = xbmcaddon.Addon()
profile_dir = xbmcvfs.translatePath(addon.getAddonInfo('profile')) if hasattr(xbmcvfs, 'translatePath') else xbmcvfs.translatePath(addon.getAddonInfo('profile'))
addondir = os.path.join(profile_dir, 'hunter')
if not xbmcvfs.exists(addondir):
    xbmcvfs.mkdirs(addondir)
addonname = addon.getAddonInfo('name')

base_url = sys.argv[0]
addon_handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 0
args = urllib.parse.parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
icon1 = os.path.join(addondir, 'icon.png')

VALID_MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC",
                "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OKTOBER", "NOVEMBER", "DEZEMBER",
                "JANUAR", "FEBRUAR", "MÄRZ", "APRIL", "MAI", "JUNI", "JULI", "AUGUST", "SEPTEMBER", "OKTOBER", "NOVEMBER", "DEZEMBER"]

COUNTRY_MAP = {
    "DE": ["DE", "GER", "GERMANY", "DEUTSCHLAND", "DACH", "AUT", "SUI"],
    "TR": ["TR", "TURKEY", "TURK", "TURKIYE", "TÜRK"],
    "IT": ["IT", "ITALY", "ITA"],
    "FR": ["FR", "FRANCE", "FRA"],
    "ES": ["ES", "SPAIN", "SPA", "MOVISTAR"],
    "UK": ["UK", "ENGLAND", "SKY UK"],
    "US": ["US", "USA", "AMERICA"],
    "AR": ["AR", "ARABIC", "ARAB", "MAGHREB", "ALGERIA", "MOROCCO", "TUNISIA"],
    "EX-YU": ["EX-YU", "BALKAN", "SERBIA", "CROATIA", "BOSNIA"],
    "PL": ["PL", "POLAND", "POLSKA"]
}

STANDARD_PREFIXES = [
    '00:1A:79', '00:1B:79', '00:1E:B8', '10:27:BE', 'A0:BB:3E', 
    '00:2A:79', '00:2A:01', '00:14:22', '00:30:18', '00:50:56', 
    '00:03:FF', '00:05:69', '00:05:9A', '00:0A:27', '00:0C:29', 
    '00:0F:4B', '00:11:D8', '00:16:3E', '00:19:66', '00:1A:70', 
    '00:1C:14', '00:1C:19', '00:1C:42', '00:1F:16', '00:20:91', 
    '00:21:5C', '00:24:D4', '00:25:90', '00:26:75', '00:40:96', 
    '00:60:2F', '00:90:0B', '00:A1:79', '00:E0:4C', '04:D6:AA', 
    '08:00:27', '18:C8:E7', '1A:00:6A', '1A:00:FB', '11:33:01', 
    '33:44:CF', '55:93:EA', '74:1A:79', 'D4:CF:F9', 'DC:9A:2F', 'E0:37:17'
]

COUNTRY_OUIS = {
    "Alle OUI / Zufall (Empfohlen)": None,
    "Deutschland (00:1A:79)": "00:1A:79",
    "Frankreich (00:1A:78)": "00:1A:78",
    "Italien (00:1A:7A)": "00:1A:7A",
    "Spanien (00:1A:7B)": "00:1A:7B",
    "Türkei (00:1A:7C)": "00:1A:7C"
}

USER_AGENTS_LIST = [
    'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/537.36 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Safari/537.36',
    'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/537.36 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/537.36',
    'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/537.36 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 2721 Mobile Safari/537.36',
    'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3',
    'Mozilla/5.0 (X11; Linux i686; U; rv:1.7.13) Gecko/20070322 Kazehakase/0.4.4.1'
]

xbmcplugin.setContent(addon_handle, 'movies')


def resolve_dns_doh(hostname):
    try:
        if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", hostname): 
            return hostname
            
        try:
            url = f"https://1.1.1.1/dns-query?name={hostname}&type=A"
            r = requests.get(url, headers={"Accept": "application/dns-json", "Host": "cloudflare-dns.com"}, timeout=3, verify=False)
            if r.status_code == 200:
                data = r.json()
                if "Answer" in data:
                    for ans in data["Answer"]:
                        ip = str(ans.get("data", ""))
                        if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", ip):
                            return ip
        except Exception:
            pass

        try:
            url = f"https://dns.google/resolve?name={hostname}&type=A"
            r = requests.get(url, headers={"Accept": "application/json"}, timeout=3, verify=False)
            if r.status_code == 200:
                data = r.json()
                if "Answer" in data:
                    for ans in data["Answer"]:
                        ip = str(ans.get("data", ""))
                        if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", ip):
                            return ip
        except Exception:
            pass

        import socket
        return socket.gethostbyname(hostname)
    except Exception:
        pass
    return hostname


def calculate_device_strings(mac):
    sn = hashlib.md5(mac.encode('utf-8')).hexdigest().upper()[13:]
    device_id = hashlib.sha256(sn.encode('utf-8')).hexdigest().upper()
    device_id2 = hashlib.sha256(mac.encode('utf-8')).hexdigest().upper()
    signature = hashlib.sha256((sn + mac).encode('utf-8')).hexdigest().upper()
    return sn, device_id, device_id2, signature


def get_headers(url, mac, token=None):
    hostname = url.split("//")[-1].split("/")[0].split(":")[0]
    user_agent = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3"
    h = {
        "User-Agent": user_agent,
        "X-User-Agent": "Model: MAG254; Link: Ethernet",
        "Accept": "*/*",
        "Referer": f"{url}/c/",
        "Connection": "Keep-Alive",
        "Cookie": f"mac={mac}; stb_lang=en; timezone=Europe%2FBerlin;",
        "Host": hostname
    }
    if token: 
        h["Authorization"] = f"Bearer {token}"
    return h


def check_mac(base_url, mac):
    session = get_thread_session()
    
    try:
        parsed_url = urllib.parse.urlparse(base_url)
        hostname = parsed_url.hostname
        if hostname:
            resolved_ip = resolve_dns_doh(hostname)
            if resolved_ip and resolved_ip != hostname:
                base_url = base_url.replace(hostname, resolved_ip)
    except Exception:
        pass

    api_url = base_url.rstrip("/") + "/portal.php" if not base_url.endswith("/portal.php") else base_url
    
    try:
        params = {'type': 'stb', 'action': 'handshake', 'JsHttpRequest': '1-xml'}
        r = session.get(api_url, headers=get_headers(base_url, mac), params=params, timeout=8)
        if r.status_code != 200: 
            return None
            
        try:
            resp_json = r.json()
        except Exception:
            return None
            
        token = resp_json.get("js", {}).get("token") if isinstance(resp_json.get("js"), dict) else None
        if not token: 
            return None
        
        sn, device_id, device_id2, signature = calculate_device_strings(mac)
        profile_params = {
            'type': 'stb', 'action': 'get_profile', 'hd': '1', 'num_banks': '1', 'stb_type': 'MAG254',
            'sn': sn, 'device_id': device_id, 'device_id2': device_id2, 'signature': signature, 'JsHttpRequest': '1-xml'
        }            
        session.get(api_url, headers=get_headers(base_url, mac, token), params=profile_params, timeout=8)            
        
        info_params = {'type': 'account_info', 'action': 'get_main_info', 'JsHttpRequest': '1-xml'}
        r_info = session.get(api_url, headers=get_headers(base_url, mac, token), params=info_params, timeout=8)
        
        if r_info.status_code == 200 and r_info.text:
            return {"mac": mac, "info": r_info.text}
            
    except Exception:
        pass
    return None


def _scan_thread(url, progress, state, selected_prefix, sleep_time):
    while state['active'] and not progress.iscanceled():
        possible_chars = "0123456789ABCDEF"
        suffix = ":".join(''.join(random.choice(possible_chars) for _ in range(2)) for _ in range(3))
        
        if selected_prefix:
            current_prefix = selected_prefix
        else:
            current_prefix = random.choice(STANDARD_PREFIXES)
            
        current_mac = f"{current_prefix}:{suffix}"
        
        with state['lock']:
            state['attempts'] += 1
            progress.update(0, f"Scanne MACs... Versuche: {state['attempts']}\nPrüfe: {current_mac}")
        
        res = check_mac(url, current_mac)
        if res:
            state['active'] = False
            state['found'] = res
            save_working_account(url, current_mac, res['info'])
            save_to_mac_vault(url, current_mac, res['info'])
            return

        actual_sleep = max(sleep_time, 0.05)
        time.sleep(actual_sleep)


def ensure_valid_account(portal_obj):
    global portal
    url = portal_obj['url']
    mac = portal_obj['mac']
 
    if mac:
        res = check_mac(url, mac)
        if res:
            save_working_account(url, mac, res['info'])
            save_to_mac_vault(url, mac, res['info'])
            return res
        else:
            if xbmcgui.Dialog().yesno(
                "GitPlayGer — Hunter",
                f"Die gespeicherte MAC ({mac}) konnte vom Server nicht sofort verifiziert werden (Timeout).\n\n"
                "Möchtest du die gespeicherte MAC trotzdem weiterverwenden (Empfohlen)?"
            ):
                return {"mac": mac, "info": "Gespeicherte MAC (Offline/Toleriert verwendet)"}
        
    if not xbmcgui.Dialog().yesno("GitPlayGer — Hunter", "Keine gültige MAC gespeichert.\nSoll der erweiterte Auto-Scan gestartet werden?"):
        return None
    
    country_names = list(COUNTRY_OUIS.keys())
    selected_idx = xbmcgui.Dialog().select("Wähle ein OUI-Präfix / Land für den Scan", country_names)
    if selected_idx < 0:
        return None
    selected_prefix = COUNTRY_OUIS[country_names[selected_idx]]
    
    try:
        bot_power = int(addon.getSetting("bot_power") or 15)
    except Exception:
        bot_power = 15
        
    try:
        thread_speed = int(addon.getSetting("thread_speed") or 10)
        sleep_time = max(0.01, 1.0 / (thread_speed * 2)) 
    except Exception:
        sleep_time = 0.05
    
    progress = xbmcgui.DialogProgress()
    progress.create("Account Prüfung", f"Starte Turbo-Scan mit {bot_power} Bots...")
    
    state = {'active': True, 'attempts': 0, 'found': None, 'lock': threading.Lock()}
    threads = []
    
    for _ in range(bot_power):
        t = threading.Thread(target=_scan_thread, args=(url, progress, state, selected_prefix, sleep_time))
        t.daemon = True
        threads.append(t)
        t.start()
        
    while state['active'] and not progress.iscanceled():
        time.sleep(0.2)
        
    progress.close()
    state['active'] = False
    
    if state['found']:
        new_mac = state['found']['mac']
        portal_obj['mac'] = new_mac
        try:
            addon.setSetting("portal_mac_1", new_mac)
        except Exception:
            pass
        xbmcgui.Dialog().notification("Scanner Erfolg!", f"Gültige MAC gefunden: {new_mac}", xbmcgui.NOTIFICATION_INFO, 4000)
        return state['found']


def _find_expiry_values(data, found=None):
    if found is None:
        found = []

    expiry_keys = {
        "end_date", "enddate", "expire_date", "expiredate",
        "expiration", "expiration_date", "expiry", "expires",
        "expire", "valid_until", "validity", "paid_until",
        "tariff_end_date", "account_expiry"
    }

    if isinstance(data, dict):
        for key, value in data.items():
            normalized_key = re.sub(
                r"[^a-z0-9]", "", str(key).lower()
            )

            if normalized_key in {
                re.sub(r"[^a-z0-9]", "", k)
                for k in expiry_keys
            }:
                if value not in (None, "", 0, "0", False):
                    found.append(value)

            if isinstance(value, (dict, list)):
                _find_expiry_values(value, found)

    elif isinstance(data, list):
        for item in data:
            _find_expiry_values(item, found)

    return found


def _normalize_expiry(value):
    if value is None or isinstance(value, bool):
        return None

    if isinstance(value, (int, float)):
        number = float(value)

        if number >= 100000000000:
            number /= 1000.0

        if number >= 1000000000:
            try:
                return datetime.datetime.fromtimestamp(number).strftime("%d.%m.%Y")
            except (ValueError, OverflowError, OSError):
                return None

        return None

    text = str(value).strip()
    if not text or text.lower() in {
        "unknown", "unbekannt", "null", "none", "n/a"
    }:
        return None

    iso_text = text.replace("Z", "+00:00")
    try:
        dt = datetime.datetime.fromisoformat(iso_text)
        return dt.strftime("%d.%m.%Y")
    except (ValueError, TypeError):
        pass

    english_months = {
        "january": 1, "february": 2, "march": 3,
        "april": 4, "may": 5, "june": 6,
        "july": 7, "august": 8, "september": 9,
        "october": 10, "november": 11, "december": 12
    }

    match = re.fullmatch(
        r"([A-Za-z]+)\s+(\d{1,2}),\s*(\d{4})"
        r"(?:,\s*(\d{1,2}):(\d{2})\s*([AaPp][Mm]))?",
        text
    )

    if match:
        month_name, day, year, hour, minute, ampm = match.groups()
        month = english_months.get(month_name.lower())

        if month:
            try:
                dt = datetime.datetime(
                    int(year), month, int(day)
                )

                if hour is not None:
                    h = int(hour)
                    m = int(minute)

                    if not 1 <= h <= 12 or not 0 <= m <= 59:
                        return None

                    if ampm.lower() == "pm" and h != 12:
                        h += 12
                    elif ampm.lower() == "am" and h == 12:
                        h = 0

                    dt = dt.replace(hour=h, minute=m)

                return dt.strftime("%d.%m.%Y")
            except ValueError:
                return None

    formats = (
        "%Y-%m-%d",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%d.%m.%Y",
        "%d.%m.%Y %H:%M:%S",
        "%d/%m/%Y",
        "%m/%d/%Y",
        "%d-%m-%Y",
        "%Y/%m/%d",
        "%d.%m.%y",
        "%d %b %Y",
        "%d %B %Y",
    )

    for fmt in formats:
        try:
            dt = datetime.datetime.strptime(text, fmt)
            return dt.strftime("%d.%m.%Y")
        except ValueError:
            continue

    return None


def extract_expiry(info_text):
    for val in re.findall(r"['\"](.*?)['\"]", info_text):
        if any(m in val.upper() for m in VALID_MONTHS):
            return val
    return "Unbekannt"


def extract_expiry_and_countries(info_text):
    expiry_found = "Unbekannt"
    text = str(info_text or "")

    if "Gespeicherte MAC" in text or "Offline" in text or "Toleriert" in text:
        return "Unbekannt", []

    try:
        parsed = json.loads(text)
        values = _find_expiry_values(parsed)

        for value in values:
            normalized = _normalize_expiry(value)
            if normalized:
                expiry_found = normalized
                break
    except (ValueError, TypeError):
        pass

    if expiry_found == "Unbekannt":
        expiry_found = extract_expiry(text)

    upper_text = text.upper()
    found_countries = []
    for code, terms in COUNTRY_MAP.items():
        for term in terms:
            if " " in term:
                if term in upper_text:
                    if code not in found_countries:
                        found_countries.append(code)
                    break
            else:
                pattern = r'\b' + re.escape(term) + r'\b'
                if re.search(pattern, upper_text):
                    if code not in found_countries:
                        found_countries.append(code)
                    break

    return expiry_found, found_countries


def addPortal(portal_item):
    if not portal_item.get('url'):
        return
    url = build_url({'mode': 'sel', 'portal': json.dumps(portal_item)})   
    li = xbmcgui.ListItem(portal_item['name'])
    li.setArt({'icon': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    
def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)


def homeLevel():
    SelectLevel()


def SelectLevel():
    main_menu_url = "plugin://plugin.video.gitplayger/"
    li_main = xbmcgui.ListItem('[B][COLOR cyan]« Zurück zum Hauptmenü [/COLOR][/B]')
    li_main.setArt({'icon': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_menu_url, listitem=li_main, isFolder=True)
       
    url = build_url({'mode': 'channels_menu', 'portal': json.dumps(portal)})
    li = xbmcgui.ListItem('[B][COLOR powderblue][ Live TV ][/COLOR][/B]')
    li.setArt({'icon': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    url = build_url({'mode': 'vodgen', 'portal': json.dumps(portal)})
    li = xbmcgui.ListItem('[B][COLOR lightblue][ VOD ][/COLOR][/B]')
    li.setArt({'icon': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'sergen', 'portal': json.dumps(portal)})
    li = xbmcgui.ListItem('[B][COLOR skyblue][ Serien ][/COLOR][/B]')
    li.setArt({'icon': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)    

    vault_url = build_url({'mode': 'mac_vault', 'portal': json.dumps(portal)})
    li_vault = xbmcgui.ListItem('[B][COLOR gold] 6+ Monate MAC-Tresor verwalten[/COLOR][/B]')
    li_vault.setArt({'icon': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=vault_url, listitem=li_vault, isFolder=True)
    
    acc_url = build_url({'mode': 'account_info', 'portal': json.dumps(portal)})
    li_acc = xbmcgui.ListItem('[B][COLOR orange]Detaillierte Account-Info anzeigen[/COLOR][/B]')
    li_acc.setArt({'icon': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=acc_url, listitem=li_acc, isFolder=False)


    account_data = ensure_valid_account(portal)

    history_entry = get_hunter_history_entry(
        portal.get("url", ""),
        account_data.get("mac", portal.get("mac", ""))
        if account_data else portal.get("mac", "")
    )

    if account_data:
        expiry_date, countries = extract_expiry_and_countries(
            account_data.get("info", "")
        )
    else:
        expiry_date, countries = "Unbekannt", []

    if expiry_date == "Unbekannt" and history_entry:
        saved_expiry = _normalize_expiry(history_entry.get("expiry"))

        if saved_expiry:
            expiry_date = saved_expiry

        if not countries:
            saved_countries = history_entry.get("countries", [])
            if isinstance(saved_countries, list):
                countries = saved_countries

    countries_str = (
        f" | Länder: {', '.join(countries)}"
        if countries else ""
    )

    if account_data or history_entry:
        info_item = xbmcgui.ListItem(
            f"[COLOR yellow]Konto gültig bis: "
            f"{expiry_date}{countries_str}[/COLOR]"
        )
    else:
        info_item = xbmcgui.ListItem(
            "[B][COLOR red]Account abgelaufen / Keine MAC gefunden[/COLOR][/B]"
        )

    info_item.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=f"{base_url}?action=dummy",
        listitem=info_item,
        isFolder=False
    )

    
    doh_test_item = xbmcgui.ListItem('[B][COLOR lime][ Cloudflare DNS-Check durchführen ][/COLOR][/B]')
    doh_test_item.setArt({'icon': icon1})
    doh_test_item.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{base_url}?action=doh_test", listitem=doh_test_item, isFolder=False)

    url_clear = build_url({'mode': 'clear_cache', 'portal': json.dumps(portal)})
    li_clear = xbmcgui.ListItem('[B][COLOR crimson][ CACHE LEEREN ][/COLOR][/B]')
    li_clear.setArt({'icon': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_clear, listitem=li_clear, isFolder=False)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
    
def ClearLevel():
    filelist = [f for f in os.listdir(addondir) if not f.endswith(".xml")]
    for f in filelist:
        try:
            os.remove(os.path.join(addondir, f))
        except Exception:
            pass


def channelsMenuLevel():
    url_all = build_url({'mode': 'channels', 'filter_type': 'all', 'portal': json.dumps(portal)})
    li_all = xbmcgui.ListItem('[B][COLOR white]Alle Sender[/COLOR][/B]')
    li_all.setArt({'icon': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_all, listitem=li_all, isFolder=True)

    url_genres = build_url({'mode': 'genres', 'portal': json.dumps(portal)})
    li_genres = xbmcgui.ListItem('[B][COLOR lightgreen]Nach Genres filtern[/COLOR][/B]')
    li_genres.setArt({'icon': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_genres, listitem=li_genres, isFolder=True)

    url_num = build_url({'mode': 'channels', 'filter_type': 'num', 'portal': json.dumps(portal)})
    li_num = xbmcgui.ListItem('[B][COLOR yellow]Nach Nummer (#)[/COLOR][/B]')
    li_num.setArt({'icon': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_num, listitem=li_num, isFolder=True)

    for char in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        url_char = build_url({'mode': 'channels', 'filter_type': 'char', 'char_val': char, 'portal': json.dumps(portal)})
        li_char = xbmcgui.ListItem(f'[B]Sender mit "{char}"[/B]')
        li_char.setArt({'icon': icon1})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_char, listitem=li_char, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)
      
      
def genreLevel():
    ensure_valid_account(portal)
    try:
        data = load_channels.getGenres(portal['mac'], portal['url'], portal['serial'], addondir)
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    data = data.get('genres', {})
    for id, i in list(data.items()):
        title = i.get("title", "")
        url = build_url({
            'mode': 'channels', 
            'genre_id': id, 
            'genre_name': title.title(), 
            'portal': json.dumps(portal)
        })
        li = xbmcgui.ListItem(title.title())
        li.setArt({'icon': icon1}) 
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


def channelLevel():
    ensure_valid_account(portal)
    stop = False
        
    try:
        data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'], addondir)
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return
    
    channels_data = data.get('channels', [])
    genre_name = args.get('genre_name', [None])[0]
    genre_id_main = args.get('genre_id', ['*'])[0]
    filter_type = args.get('filter_type', ['all'])[0]
    char_val = args.get('char_val', [''])[0].upper()
    
    parental_val = portal.get('parental', '')
    if genre_id_main == '10' and parental_val == 'true':
        pwd = portal.get('password', '')
        result = xbmcgui.Dialog().input('Parental', hashlib.md5(pwd.encode('utf-8')).hexdigest(), type=xbmcgui.INPUT_PASSWORD, option=xbmcgui.PASSWORD_VERIFY)
        if not result: 
            stop = True

    if not stop:
        filtered_channels = []
        for i in channels_data:
            name = i.get("name", "").strip()
            genre_id = str(i.get("genre_id", ""))
        
            if genre_id_main == '*' and genre_id == '10' and parental_val == 'true':
                continue
            if genre_id_main != '*' and genre_id_main != genre_id:
                continue

            if filter_type == 'num':
                if not name or not name[0].isdigit():
                    continue
            elif filter_type == 'char' and char_val:
                if not name or not name.upper().startswith(char_val):
                    continue
            
            filtered_channels.append(i)

        for i in filtered_channels:
            name = i.get("name", "")
            cmd = i.get("cmd", "")
            tmp = i.get("tmp", "")
            number = i.get("number", "")
            logo = i.get("logo", "")
        
            logo_url = portal['url'].rstrip('/') + '/stalker_portal/misc/logos/320/' + logo if logo else icon1
                
            url = build_url({
                'mode': 'check', 
                'cmd': cmd, 
                'tmp': tmp, 
                'title': name,
                'genre_name': genre_name,
                'logo_url': logo_url,  
                'portal': json.dumps(portal)
            })
        
            li = xbmcgui.ListItem(name)
            li.setArt({'icon': logo if logo else icon1})
            li.setInfo(type='Video', infoLabels={'title': name, 'count': number, 'plot': "'GitPlayGer'"})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
        
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PLAYLIST_ORDER)
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE)
        xbmcplugin.endOfDirectory(addon_handle)

def vodgenreLevel():
    ensure_valid_account(portal)
    try:
        data = load_channels.getVoDgenres(portal['mac'], portal['url'], portal['serial'], addondir)
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    data = data.get('vodgenres', {})
    for id, i in list(data.items()):
        title = i.get("title", "")
        cat = i.get("cat", "")
        url = build_url({'mode': 'vod', 'genre_name': title.title(), 'cat': cat, 'portal': json.dumps(portal)})
            
        li = xbmcgui.ListItem(title.title())
        li.setArt({'icon': icon1})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def vodLevel():
    ensure_valid_account(portal)
    try:
        data = load_channels.getVoD(portal['mac'], portal['url'], portal['serial'], addondir)
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return
    cat = args.get('cat', [''])[0]    
    vod_items = data.get('vod' + cat, [])
    
    for i in vod_items:
        name = i.get("name", "")
        cmd = i.get("cmd", "")
        logo = i.get("logo", "")
        plot = i.get("plot", "")
        year = i.get("year", "")
        genre = i.get("genre", "")
        
        logo_url = portal['url'].rstrip('/') + logo if logo else icon1
                
        url = build_url({'mode': 'playvod', 'cmd': cmd, 'tmp': '0', 'title': name, 'genre_name': 'VoD', 'logo_url': logo_url, 'portal': json.dumps(portal)})
            
        li = xbmcgui.ListItem(name)
        li.setInfo(type='Video', infoLabels={'title': name, 'plot': plot, 'year': year, 'genre': genre})
        li.setArt({'icon': logo if logo else icon1})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(addon_handle)

def SeriesGenre():
    ensure_valid_account(portal)
    try:
        data = load_channels.getSergenres(portal['mac'], portal['url'], portal['serial'], addondir)
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    data = data.get('sergenres', {})
    for id, i in list(data.items()):
        title = i.get("title", "")
        cat = i.get("cat", "")
        url = build_url({'mode': 'seriescat', 'genre_name': title.title(), 'cat': cat, 'portal': json.dumps(portal)})
            
        li = xbmcgui.ListItem(title.title())
        li.setArt({'icon': icon1})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle)

def SeriesLevel():
    ensure_valid_account(portal)
    try:
        data = load_channels.getSeries(portal['mac'], portal['url'], portal['serial'], addondir)
    except Exception:
        return
    cat = args.get('cat', [''])[0]    
    series_items = data.get('ser' + cat, [])
    
    for i in series_items:
        name = i.get("name", "")
        cmd = i.get("cmd", "")
        logo = i.get("logo", "")
        plot = i.get("plot", "")
        year = i.get("year", "")
        genre = i.get("genre", "")
        cat_id = i.get('cat', '')
        category = i.get('category', '')
        
        logo_url = portal['url'].rstrip('/') + logo if logo else icon1
                
        url = build_url({'mode': 'season', 'cat': cat_id, 'name': name, 'cmd': cmd, 'category': category, 'logo_url': logo_url, 'portal': json.dumps(portal)})
            
        li = xbmcgui.ListItem(name)
        li.setInfo(type='Video', infoLabels={'name': name, 'plot': plot, 'year': year, 'genre': genre})
        li.setArt({'icon': logo if logo else icon1})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(addon_handle)

def SeasonLevel():
    ensure_valid_account(portal)
    try:
        data = load_channels.get_seasons(portal['mac'], portal['url'], portal['serial'], addondir)
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return
    cat = args.get('cat', [''])[0]    
    seasons_items = data.get('seasons' + cat, [])
  
    for i in seasons_items:
        name = i.get("name", "")
        cmd = i.get("cmd", "")
        logo = i.get("logo", "")
        cat_id = i.get("cat", "")
        category = i.get("category", "")
        plot = i.get('plot', '')
        genre = i.get('genre', '')

        url = build_url({'mode': 'episode', 'cat': cat_id, 'category': category, 'name': name, 'cmd': cmd, 'portal': json.dumps(portal)})
            
        li = xbmcgui.ListItem(name)
        li.setInfo(type='Video', infoLabels={'name': name, 'plot': plot, 'genre': genre})
        li.setArt({'icon': logo if logo else icon1})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(addon_handle)

def EpisodeLevel():
    ensure_valid_account(portal)
    data = load_channels.get_episodes(portal['mac'], portal['url'], portal['serial'], addondir)
    episodes_items = data.get('episodes', [])
  
    cat1 = args.get('cat', [None])[0]
    for i in episodes_items:
        name = i.get("name", "")
        cmd = i.get("cmd", "")
        cat_id = i.get("cat", "")
        category = i.get("category", "")
        episode = i.get("episode", "")

        url = build_url({'mode': 'epiplay', 'episode': episode, 'name': name, 'cat': cat_id, 'category': category, 'cmd': cmd, 'portal': json.dumps(portal)})
            
        if str(cat1) == str(cat_id):
            li = xbmcgui.ListItem(str(episode))
            li.setInfo(type='Video', infoLabels={'name': episode})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)

def checkcmd():
    cmd = args.get('cmd', [''])[0]
    if str(cmd).startswith('ffmpeg http://localhost'):
        ensure_valid_account(portal)
        load_channels.getTvStream(portal['mac'], portal['url'], portal['serial'], addondir)
    else:
        playLevel()

def playLevel():
    ensure_valid_account(portal)
    dp = xbmcgui.DialogProgressBG()
    dp.create('IPTV', 'Bitte warten ...')
    
    title = args.get('title', [''])[0]
    cmd = args.get('cmd', [''])[0]
    tmp = args.get('tmp', ['1'])[0]
    genre_name = args.get('genre_name', [''])[0]
    
    try:
        if genre_name != 'VoD':
            url = load_channels.retriveUrl(portal['mac'], portal['url'], portal['serial'], cmd, tmp)
        else:
            url = load_channels.retrive_defaultUrl(portal['mac'], portal['url'], portal['serial'], cmd)
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    dp.update(80)
    title += ' (' + portal['name'] + ')'
    li = xbmcgui.ListItem(title)
    li.setInfo('video', {'Title': title, 'Genre': genre_name})
    xbmc.Player().play(item=url, listitem=li)
    dp.update(100)
    dp.close()

def playStreamLevel():
    ensure_valid_account(portal)
    load_channels.getStream(portal['mac'], portal['url'], portal['serial'], addondir)
 
def PlayEpisode(): 
    ensure_valid_account(portal)
    load_channels.getEpistream(portal['mac'], portal['url'], portal['serial'], addondir)

def dummyLevel():
    pass

def run_doh_test():
    portal_url = addon.getSetting("portal_url_1").strip()

    if not portal_url:
        xbmcgui.Dialog().ok(
            "Cloudflare DNS-Check",
            "Es ist keine Portal-URL in den Einstellungen eingetragen."
        )
        return

    if "://" not in portal_url:
        portal_url = "http://" + portal_url

    try:
        parsed = urllib.parse.urlparse(portal_url)
        hostname = parsed.hostname

        if not hostname:
            xbmcgui.Dialog().ok(
                "Cloudflare DNS-Check",
                "Die eingetragene Portal-URL ist ungültig:\n\n"
                + portal_url
            )
            return

        if re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}", hostname):
            xbmcgui.Dialog().ok(
                "Cloudflare DNS-Check",
                f"Die Portal-URL enthält bereits eine IP-Adresse:\n\n"
                f"{hostname}\n\n"
                f"URL: {portal_url}"
            )
            return

        response = requests.get(
            "https://cloudflare-dns.com/dns-query",
            params={"name": hostname, "type": "A"},
            headers={
                "Accept": "application/dns-json",
                "User-Agent": "GitPlayGer-DNS-Checker/1.0"
            },
            timeout=8
        )
        response.raise_for_status()
        data = response.json()

        if data.get("Status") == 0:
            addresses = [
                answer.get("data", "")
                for answer in data.get("Answer", [])
                if answer.get("type") == 1
                and re.fullmatch(
                    r"\d{1,3}(?:\.\d{1,3}){3}",
                    str(answer.get("data", ""))
                )
            ]

            if addresses:
                xbmcgui.Dialog().ok(
                    "Cloudflare DNS-Check",
                    f"[COLOR lime]DNS-Auflösung erfolgreich![/COLOR]\n\n"
                    f"Portal: {hostname}\n"
                    f"IP-Adresse(n):\n"
                    + "\n".join(addresses)
                    + f"\n\nGeprüfte URL:\n{portal_url}"
                )
                return

            message = (
                "Cloudflare hat geantwortet, aber keine IPv4-Adresse "
                "für diesen Hostnamen geliefert."
            )

        elif data.get("Status") == 3:
            message = (
                "Der Hostname existiert laut DNS nicht (NXDOMAIN).\n\n"
                f"Host: {hostname}"
            )
        else:
            message = (
                "Cloudflare meldet einen DNS-Fehler.\n\n"
                f"DNS-Status: {data.get('Status', 'unbekannt')}"
            )

        xbmcgui.Dialog().ok(
            "Cloudflare DNS-Check",
            f"[COLOR red]DNS-Prüfung fehlgeschlagen[/COLOR]\n\n"
            f"{message}\n\nURL: {portal_url}"
        )

    except Exception as e:
        xbmcgui.Dialog().ok(
            "Cloudflare DNS-Check",
            "[COLOR red]DNS-Prüfung fehlgeschlagen[/COLOR]\n\n"
            f"Host: {hostname if 'hostname' in locals() else 'unbekannt'}"
            f"\nFehler: {str(e)}\n\n"
            f"URL: {portal_url}"
        )        
        

def save_working_account(url, mac, info_text):
    history_path = os.path.join(addondir, "hunter_history.json")
    history = []

    try:
        if os.path.isfile(history_path):
            with open(history_path, "r", encoding="utf-8") as f:
                loaded = json.load(f)

            if isinstance(loaded, list):
                history = [
                    item for item in loaded
                    if isinstance(item, dict)
                ]
            elif isinstance(loaded, dict):
                entries = loaded.get("history", loaded.get("accounts", []))
                if isinstance(entries, list):
                    history = [
                        item for item in entries
                        if isinstance(item, dict)
                    ]
    except (OSError, ValueError, TypeError):
        history = []

    expiry, countries = extract_expiry_and_countries(info_text)
    mac_upper = str(mac or "").strip().upper()
    normalized_url = str(url or "").strip().rstrip("/").lower()

    previous = next(
        (
            item for item in history
            if str(item.get("mac", "")).strip().upper() == mac_upper
            and str(item.get("url", "")).strip().rstrip("/").lower() == normalized_url
        ),
        None
    )

    if previous:
        old_expiry = previous.get("expiry")
        if (not expiry or expiry == "Unbekannt") and old_expiry and old_expiry != "Unbekannt":
            expiry = old_expiry

        if not countries and isinstance(previous.get("countries"), list):
            countries = previous["countries"]

    history = [
        item for item in history
        if not (
            str(item.get("mac", "")).strip().upper() == mac_upper
            and str(item.get("url", "")).strip().rstrip("/").lower() == normalized_url
        )
    ]

    history.insert(0, {
        "url": url,
        "mac": mac_upper,
        "expiry": expiry,
        "countries": countries,
        "time": time.time()
    })

    try:
        os.makedirs(addondir, exist_ok=True)
        temp_path = history_path + ".tmp"

        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(history[:20], f, ensure_ascii=False, indent=4)

        os.replace(temp_path, history_path)

    except (OSError, TypeError, ValueError) as e:
        print("[gitplayger] Hunter-Historie konnte nicht gespeichert werden: {}".format(e))


def get_hunter_history_entry(url, mac):
    history_paths = [
        os.path.join(addondir, "hunter_history.json"),
        os.path.join(profile_dir, "hunter_history.json")
    ]

    normalized_url = str(url or "").strip().rstrip("/").lower()
    normalized_mac = str(mac or "").strip().upper()

    for history_path in history_paths:
        if not os.path.isfile(history_path):
            continue

        try:
            with open(history_path, "r", encoding="utf-8") as f:
                history = json.load(f)

            if isinstance(history, dict):
                history = history.get(
                    "history", history.get("accounts", [])
                )

            if not isinstance(history, list):
                continue

            for entry in history:
                if not isinstance(entry, dict):
                    continue

                entry_url = str(entry.get("url", "")).strip().rstrip("/").lower()
                entry_mac = str(entry.get("mac", "")).strip().upper()

                if (
                    entry_url == normalized_url
                    and entry_mac == normalized_mac
                ):
                    return entry

        except (OSError, ValueError, TypeError):
            pass

    return None
    

def get_mac_vault_dir():
    base_storage = "/storage/emulated/0/GitPlayGer/MAC"
    try:
        translated = xbmcvfs.translatePath("special://masterprofile/addon_data/plugin.video.gitplayger/MAC")
        if os.path.exists("/storage/emulated/0"):
            base_storage = "/storage/emulated/0/GitPlayGer/MAC"
        else:
            base_storage = translated
    except Exception:
        pass
        
    if not os.path.exists(base_storage):
        try:
            os.makedirs(base_storage, exist_ok=True)
        except Exception:
            pass
    return base_storage

def parse_expiry_months(expiry_str):
    if not expiry_str or expiry_str == "Unbekannt":
        return 0, False
    
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%Y-%m-%d %H:%M:%S", "%d/%m/%Y"):
        try:
            dt = datetime.datetime.strptime(expiry_str.strip(), fmt)
            diff_days = (dt - datetime.datetime.now()).days
            return diff_days, diff_days >= 180
        except Exception:
            continue
            
    if any(str(year) in expiry_str for year in [2026, 2027, 2028, 2029]):
        return 365, True
        
    return 0, False

def save_to_mac_vault(url, mac, info_text):
    vault_dir = get_mac_vault_dir()
    expiry_date, countries = extract_expiry_and_countries(info_text)
    
    days_left, is_valid_duration = parse_expiry_months(expiry_date)
    
    if not is_valid_duration and days_left > 0:
        return False 
        
    account_data = {
        "url": url,
        "mac": mac.upper(),
        "expiry": expiry_date,
        "days_left": days_left,
        "countries": countries,
        "timestamp": time.time()
    }
    
    vault_files = [os.path.join(vault_dir, f) for f in os.listdir(vault_dir) if f.endswith(".json")]
    accounts = []
    for vf in vault_files:
        try:
            with open(vf, "r", encoding="utf-8") as f:
                acc = json.load(f)
                if acc.get("mac").upper() != mac.upper():
                    accounts.append((vf, acc))
        except Exception:
            pass
            
    accounts.sort(key=lambda x: x[1].get("days_left", 0), reverse=True)
    
    filename = f"MAC_{mac.replace(':', '')}.json"
    filepath = os.path.join(vault_dir, filename)
    
    try:
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(account_data, f, ensure_ascii=False, indent=4)
    except Exception:
        return False
        
    accounts.insert(0, (filepath, account_data))
    
    if len(accounts) > 3:
        for vf, acc in accounts[3:]:
            try:
                os.remove(vf)
            except Exception:
                pass
                
    return True

def show_mac_vault_level():
    vault_dir = get_mac_vault_dir()
    vault_files = [os.path.join(vault_dir, f) for f in os.listdir(vault_dir) if f.endswith(".json")]
    
    url_back = build_url({'mode': 'sel', 'portal': json.dumps(portal)})
    li_back = xbmcgui.ListItem('[B][COLOR cyan]« Zurück [/COLOR][/B]')
    li_back.setArt({'icon': icon1})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_back, listitem=li_back, isFolder=True)
    
    if not vault_files:
        li_empty = xbmcgui.ListItem('[COLOR red]Keine 6+ Monate Accounts im Tresor gespeichert.[/COLOR]')
        li_empty.setArt({'icon': icon1})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{base_url}?action=dummy", listitem=li_empty, isFolder=False)
    else:
        for vf in vault_files:
            try:
                with open(vf, "r", encoding="utf-8") as f:
                    acc = json.load(f)
                    mac = acc.get("mac")
                    url = acc.get("url")
                    expiry = acc.get("expiry")
                    countries = acc.get("countries", [])
                    
                    title = f"[B][COLOR lightgreen]MAC: {mac}[/COLOR][/B] | Gültig bis: [COLOR yellow]{expiry}[/COLOR]"
                    plot = f"Portal: {url}\nLänder: {', '.join(countries)}\nPfad: {vf}"
                    
                    li = xbmcgui.ListItem(title)
                    li.setArt({'icon': icon1})
                    li.setInfo('video', {'title': title, 'plot': plot})
                    
                    play_url = build_url({'mode': 'activate_vault_mac', 'mac': mac, 'url': url})
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)
            except Exception:
                pass
                
    xbmcplugin.endOfDirectory(addon_handle)
        
    
def run_hunter():
    global portal
    portal = config.portalConfig('1')
    SelectLevel()


def account_info_level():
    account_data = ensure_valid_account(portal)
    
    if account_data and account_data.get("info"):
        info_text = account_data.get("info")
        
        try:
            parsed = json.loads(info_text)
            info_text = json.dumps(parsed, ensure_ascii=False, indent=4)
        except Exception:
            pass
            
        xbmcgui.Dialog().text_viewer("Detaillierte Account-Info", info_text)
        return

    xbmcgui.Dialog().ok("Account Info", "Konnte keine Account-Details vom Server abrufen.")


def activate_vault_mac_handler():
    mac = args.get('mac', [''])[0]
    url = args.get('url', [''])[0]
    if mac and url:
        portal['mac'] = mac
        portal['url'] = url
        try:
            addon.setSetting("portal_mac_1", mac)
            addon.setSetting("portal_url_1", url)
        except Exception:
            pass
        xbmcgui.Dialog().notification(addonname, f"Vault-MAC aktiviert: {mac}", xbmcgui.NOTIFICATION_INFO, 3000)
        SelectLevel()


if __name__ == '__main__':
    mode_arg = args.get('mode', None)
    portal_arg = args.get('portal', None)

    if portal_arg is None:
        portal = config.portalConfig('1')
    else:
        try:
            portal = json.loads(portal_arg[0])
        except Exception:
            portal = config.portalConfig('1')

    mode = mode_arg[0] if mode_arg else 'sel'
    
    if mode == 'sel' or not mode:
        SelectLevel()
    elif mode == 'channels_menu':
        channelsMenuLevel()
    elif mode == 'genres':
        genreLevel()
    elif mode == 'channels':
        channelLevel()
    elif mode == 'vodgen':
        vodgenreLevel()
    elif mode == 'vod':
        vodLevel()
    elif mode == 'sergen':
        SeriesGenre()
    elif mode == 'seriescat':
        SeriesLevel()
    elif mode == 'season':
        SeasonLevel()
    elif mode == 'episode':
        EpisodeLevel()
    elif mode == 'epiplay':
        PlayEpisode()
    elif mode == 'check':
        checkcmd()
    elif mode == 'play':
        playLevel()
    elif mode == 'mac_vault':
        show_mac_vault_level()
    elif mode == 'activate_vault_mac':
        activate_vault_mac_handler()
    elif mode == 'clear_cache':
        ClearLevel()
        xbmcgui.Dialog().notification(addonname, "Cache erfolgreich geleert!", xbmcgui.NOTIFICATION_INFO, 3000)
        SelectLevel()
    elif mode == 'account_info':
        account_info_level()
    elif mode == 'doh_test':
        run_doh_test()
    else:
        SelectLevel()
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum des Autors.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.