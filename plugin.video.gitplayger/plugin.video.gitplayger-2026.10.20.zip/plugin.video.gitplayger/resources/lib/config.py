# -*- coding: utf-8 -*-
# GitPlayGer 
# Copyright (c) 2026 Team IT('s) Possible. All rights reserved.
# Version 2026.10.16
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
import sys
import os
import json
import urllib.parse
import unicodedata
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import re


def _auto_clean(val):
    if isinstance(val, str):
        cleaned = re.sub(r'[\U00010000-\U0010ffff]|[\u2600-\u27bf]|[\U0001f300-\U0001f5ff]|[\U0001f600-\U0001f64f]|[\U0001f680-\U0001f6ff]', '', val)
        cleaned = re.sub(r'^[^\w\säöüÄÖÜß]+', '', cleaned)
        return cleaned.strip()
    elif isinstance(val, dict):
        return {k: _auto_clean(v) for k, v in val.items()}
    elif isinstance(val, list):
        return [_auto_clean(v) for v in val]
    return val

_original_json_loads = json.loads
def _patched_json_loads(s, *args, **kwargs):
    result = _original_json_loads(s, *args, **kwargs)
    return _auto_clean(result)

json.loads = _patched_json_loads


addon = xbmcaddon.Addon()
profile_dir = xbmcvfs.translatePath(addon.getAddonInfo('profile')) if hasattr(xbmcvfs, 'translatePath') else xbmcvfs.translatePath(addon.getAddonInfo('profile'))
addondir = os.path.join(profile_dir, 'hunter')
if not xbmcvfs.exists(addondir):
    xbmcvfs.mkdirs(addondir)
addonname = addon.getAddonInfo('name')


def portalConfig(number):
    portal = {}
    
    portal['parental'] = addon.getSetting("parental")
    portal['password'] = addon.getSetting("password")
    
    portal['name'] = addon.getSetting("portal_name_" + number)
    portal['url'] = addon.getSetting("portal_url_" + number)
    portal['mac'] = configMac(number)
    portal['serial'] = configSerialNumber(number)
        
    return portal

def configMac(number):
    portal_mac = addon.getSetting('portal_mac_' + number)
    if not portal_mac:
        portal_mac = ''
    return portal_mac
	
def configSerialNumber(number):
    send_serial = addon.getSetting('send_serial_' + number)
    custom_serial = addon.getSetting('custom_serial_' + number)
    serial_number = addon.getSetting('serial_number_' + number)
    device_id = addon.getSetting('device_id_' + number)
    device_id2 = addon.getSetting('device_id2_' + number)
    signature = addon.getSetting('signature_' + number)

    if send_serial != 'true':
        return None
    elif send_serial == 'true' and custom_serial == 'false':
        return {'custom': False}
    elif send_serial == 'true' and custom_serial == 'true':
        if not serial_number or not device_id or not device_id2 or not signature:
            return None
        return {'custom': True, 'sn': serial_number, 'device_id': device_id, 'device_id2': device_id2, 'signature': signature}
        
    return None
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum des Autors.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.