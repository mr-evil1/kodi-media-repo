# -*- coding: utf-8 -*-
# GitPlayGer 
# Copyright (c) 2026 Team IT('s) Possible. All rights reserved.
# Version 2026.10.16
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte
# Weiterverbreitung des Codes ist strengstens untersagt.
import os
import time
import json
import urllib.request
from urllib.parse import quote_plus

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.gitplayger_api import GitPlayGer
from resources.lib.filter import ChannelFilter

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PATH = ADDON.getAddonInfo("path")
PLUGIN_URL = "plugin://%s/" % ADDON_ID

XML_FILE = "gitplayger-main.xml"
LIST_ID = 9696

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92

MENU_ITEMS = [
    {
        "key": "favorites",
        "label": "[COLOR slateblue][[/COLOR][COLOR powderblue] Meine Favoriten & Themen [COLOR][COLOR slateblue]][/COLOR]",
        "plot": "Deine persönlich gespeicherten Lieblingssender und eigene Themen-Ordner.",
        "kind": "view_favorites",
    },
    {
        "key": "playlist_manager",
        "label": "[COLOR slateblue][[/COLOR][COLOR lightblue] Playlists verwalten [COLOR][COLOR slateblue]][/COLOR]",        
        "plot": "M3U-Playlisten aktivieren, deaktivieren oder löschen.",
        "kind": "manage_playlists",
    },    
    {
        "key": "all",
        "label": "[COLOR slateblue][[/COLOR][COLOR skyblue] Alle Sender [COLOR][COLOR slateblue]][/COLOR]",
        "plot": "Alle Sender nach Anwendung der aktiven Qualitäts- und Länderfilter.",
        "kind": "view_all",
    },
    {
        "key": "alphabet",
        "label": "[COLOR slateblue][[/COLOR][COLOR lightskyblue] Sender von A bis Z [COLOR][COLOR slateblue]][/COLOR]",        
        "plot": "Wähle einen Anfangsbuchstaben aus, um Sender gezielt anzuzeigen.",
        "kind": "view_alphabet",
    },
    {
        "key": "epg",
        "label": "[COLOR slateblue][[/COLOR][COLOR deepskyblue] Sender mit EPG ID [COLOR][COLOR slateblue]][/COLOR]",             
        "plot": "Zeigt ausschließlich Sender, die eine gültige EPG-ID besitzen.",
        "kind": "view_epg",
    },    
    {
        "key": "search",
        "label": "[COLOR slateblue][[/COLOR][COLOR dodgerblue] Sender Suchen [COLOR][COLOR slateblue]][/COLOR]",
        "plot": "Durchsuche alle geladenen Playlisten nach Sendername.",
        "kind": "search",
    },  
    {
        "key": "country_manager",
        "label": "[COLOR slateblue][[/COLOR][COLOR royalblue] Länderfilter verwalten [COLOR][COLOR slateblue]][/COLOR]",        
        "plot": "Länder auswählen und aktivieren oder deaktivieren.",
        "kind": "manage_countries",
    },  
    {
        "key": "categories",
        "label": "[COLOR slateblue][[/COLOR][COLOR dodgerblue] Kategorien [COLOR][COLOR slateblue]][/COLOR]",         
        "plot": "Sender nach Kategorie (Genre) durchsuchen.",
        "kind": "view_categories",
    },    
    {
        "key": "kodinerds",
        "label": "[COLOR slateblue][[/COLOR][COLOR deepskyblue] Kodinerds M3U IPTV [COLOR][COLOR slateblue]][/COLOR]",         
        "plot": "Öffnet die tagesaktuellen Playlisten von Kodinerds IPTV (jnk22).",
        "kind": "view_kodinerds",
    },
    {
        "key": "item_test_batch",
        "label": "[COLOR slateblue][[/COLOR][COLOR lightskyblue] Dead Link Cleaner [COLOR][COLOR slateblue]][/COLOR]",                 
        "plot": "Streams im Batch-Verfahren testen.",
        "kind": "batch_test_streams",
    },            
    {
        "key": "dead",
        "label": "[COLOR slateblue][[/COLOR][COLOR powderblue] Nicht verfügbare Sender [COLOR][COLOR slateblue]][/COLOR]",        
        "plot": "Sender, die beim Dead Link Cleaner als tot erkannt wurden.",
        "kind": "view_dead",
    },
    {
        "key": "generate_gitplayger_m3u",
        "label": "[COLOR slateblue][[/COLOR][COLOR lightblue] Generiere meine M3U-Playlist [COLOR][COLOR slateblue]][/COLOR]",        
        "plot": "Aktualisiert die Sender und EPG-Daten.",
        "query": "action=generate_gitplayger_m3u",
        "kind": "run",
    },
    {
        "key": "refresh",
        "label": "[COLOR slateblue][[/COLOR][COLOR skyblue] Sender & EPG aktualisieren [COLOR][COLOR slateblue]][/COLOR]",         
        "plot": "Aktualisiert die Sender und EPG-Daten.",
        "query": "action=refresh_epg",
        "kind": "run",
    },
    {
        "key": "setup_pvr",
        "label": "[COLOR slateblue][[/COLOR][COLOR lightskyblue] IPTV Simple Client [COLOR][COLOR slateblue]][/COLOR]",         
        "plot": "IPTV Simple Client (PVR) einrichten.",
        "kind": "setup_pvr",    
    },            
    {
        "key": "hunter",
        "label": "[COLOR slateblue][[/COLOR][COLOR skyblue] Stalker-Portal & MAC-Hunter [COLOR][COLOR slateblue]][/COLOR]",            
        "plot": "Autonomer Stalker-Portal & MAC-Hunter, Live-TV, VOD, Serien & 6+ Monate MAC-Tresor.",
        "kind": "hunter_select",
        "requires_hunter": True,
    },        
    {
        "key": "mac_vault",
        "label": "[COLOR slateblue][[/COLOR][COLOR lightskyblue] MAC-Tresor (Vault) [COLOR][COLOR slateblue]][/COLOR]",                  
        "plot": "Verfügbare Stalker-Portal MAC-Adressen und Vault-Aktivierung.",
        "kind": "hunter_vault",
        "requires_hunter": True,
    },    
    {
        "key": "doh_test",
        "label": "[COLOR slateblue][[/COLOR][COLOR skyblue] DNS / DoH Test [COLOR][COLOR slateblue]][/COLOR]",          
        "plot": "Führe einen DNS-over-HTTPS-Test über den Hunter aus.",
        "query": "action=doh_test",
        "kind": "run",
        "requires_hunter": True,
    },    
    {
        "key": "settings",
        "label": "[COLOR slateblue][[/COLOR][COLOR lightskyblue] Addon-Einstellungen [COLOR][COLOR slateblue]][/COLOR]",         
        "plot": "Öffne die Addon-Konfiguration und Grundeinstellungen.",
        "kind": "settings",
    },    
    {
        "key": "quit",
        "label": "[COLOR slateblue][[/COLOR][COLOR powderblue] Zurück zu Kodi [COLOR][COLOR slateblue]][/COLOR]",         
        "plot": "Schließt das Skin-Menü und beendet das Addon.",
        "kind": "quit",
    },
]


def _hunter_visible():
    return xbmcaddon.Addon().getSetting("hunter_enabled") == "true"


def _icon_for(key):
    path = os.path.join(ADDON_PATH, "resources", "skins", "Default", "media", "icons", key + ".png")
    if os.path.exists(path):
        return path
    return os.path.join(ADDON_PATH, "icon.png")


class MainMenuWindow(xbmcgui.WindowXML):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.current_view = "main"
        self.view_stack = []
        self._hunter_shown = None
        self._last_sync = 0.0

    def onInit(self):
        self.setProperty("fanart", os.path.join(ADDON_PATH, "fanart.jpg"))
        self.setProperty("icon", os.path.join(ADDON_PATH, "icon.png"))
        self.setProperty("version", ADDON.getAddonInfo("version"))
        self._fill_main_menu()

    def _set_view(self, view_name, save_previous=True):
        if save_previous and self.current_view != view_name:
            self.view_stack.append(self.current_view)
        self.current_view = view_name

    def _fill_main_menu(self):
        self.current_view = "main"
        self.view_stack = []
        listing = self.getControl(LIST_ID)
        listing.reset()
        items = []

        hunter_enabled = _hunter_visible()
        self._hunter_shown = hunter_enabled

        for entry in MENU_ITEMS:
            if entry.get("requires_hunter", False) and not hunter_enabled:
                continue

            li = xbmcgui.ListItem(label=entry["label"])
            li.setLabel(entry["label"])
            icon = _icon_for(entry["key"])
            li.setArt({"icon": icon, "thumb": icon})
            li.setProperty("plot", entry["plot"])
            li.setProperty("key", entry["key"])
            li.setProperty("kind", entry["kind"])
            if "query" in entry:
                li.setProperty("query", entry["query"])
            items.append(li)

        listing.addItems(items)
        if items:
            self.setFocus(listing)

    def _go_back(self):
        if self.current_view == "main":
            return
        
        if self.view_stack:
            previous = self.view_stack.pop()
            if previous == "main":
                self._fill_main_menu()
            elif previous == "hunter_menu":
                self._load_hunter_menu(save_previous=False)
            elif previous == "categories":
                self._load_categories(save_previous=False)
            elif previous == "alphabet_list":
                self._load_alphabet(save_previous=False)
            elif previous == "kodinerds_playlists":
                self._load_kodinerds_playlists(save_previous=False)
            elif previous == "kodinerds_channels":
                self._load_kodinerds_playlists(save_previous=False)
            elif previous in ("favorite_themes", "favorites", "theme_channels"):
                self._load_favorite_themes(save_previous=False)
            else:
                self._fill_main_menu()
        else:
            self._fill_main_menu()
        listing = self.getControl(LIST_ID)
        if listing.size() > 0:
            self.setFocus(listing)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            self._go_back()
        elif action_id == 117:
            self._open_context_menu()
        self._sync_hunter_entries(force=(action_id == 999))

    def _sync_hunter_entries(self, force=False):
        now = time.time()
        if not force and now - self._last_sync < 1.0:
            return
        self._last_sync = now
        if self.current_view == "main" and _hunter_visible() != self._hunter_shown:
            self._fill_main_menu()

    def onClick(self, control_id):
        if control_id != LIST_ID:
            return

        listing = self.getControl(LIST_ID)
        item = listing.getSelectedItem()
        if item is None:
            return

        kind = item.getProperty("kind")
        query = item.getProperty("query")

        if self.current_view == "main":
            if kind == "quit":
                self.close()
                return
            elif kind == "run" and query:
                xbmc.executebuiltin('RunPlugin("%s?%s")' % (PLUGIN_URL, query))
            elif kind == "settings":
                ADDON.openSettings()
                self._sync_hunter_entries(force=True)
                if listing.size() > 0:
                    self.setFocus(listing)
            elif kind == "search":
                self._search()
            elif kind == "hunter_select":
                self._load_hunter_menu()
            elif kind == "hunter_vault":
                self._load_mac_vault()             
            elif kind == "view_favorites":
                self._load_favorite_themes()
            elif kind == "view_all":
                self._load_channels("all")
            elif kind == "view_epg":
                self._load_channels("epg")
            elif kind == "view_categories":
                self._load_categories()
            elif kind == "view_alphabet":
                self._load_alphabet()
            elif kind == "view_kodinerds":
                self._load_kodinerds_playlists()
            elif kind == "view_dead":
                self._load_dead_channels()
            elif kind == "manage_playlists":
                self._manage_playlists_dialog()
            elif kind == "manage_countries":
                self._manage_countries_dialog()
            elif kind == "batch_test_streams":
                xbmc.executebuiltin('RunPlugin("%s?action=batch_test_streams")' % PLUGIN_URL)
            elif kind == "setup_pvr":
                xbmc.executebuiltin('RunPlugin("%s?action=setup_pvr")' % PLUGIN_URL)
            return

        if self.current_view == "favorite_themes":
            if kind == "fav_all":
                self._load_favorites()
            elif kind == "fav_new_theme":
                self._create_theme_prompt()
            elif kind == "fav_theme_folder":
                theme_name = item.getProperty("theme_name")
                if theme_name:
                    self._load_channels_in_theme(theme_name)
            return

        if self.current_view == "hunter_menu":
            action_type = item.getProperty("hunter_action")
            if action_type == "live_tv":
                self._load_hunter_channels()
            elif action_type == "vod":
                self._load_hunter_vod_genres()
            elif action_type == "series":
                self._load_hunter_series()
            elif action_type == "get_main_info":
                from resources.lib import hunter, config
                portal = config.portalConfig('1')
                account_data = hunter.ensure_valid_account(portal)
                if account_data and account_data.get("info"):
                    info_text = account_data.get("info")
                    try:
                        parsed = json.loads(info_text)
                        info_text = json.dumps(parsed, ensure_ascii=False, indent=4)
                    except Exception:
                        pass
                    xbmcgui.Dialog().text_viewer("Detaillierte Account-Info", info_text)
                else:
                    xbmcgui.Dialog().ok("Account Info", "Konnte keine Account-Details vom Server abrufen.")
            elif action_type == "doh_test":
                from resources.lib import hunter
                hunter.run_doh_test()
            return

        if self.current_view == "hunter_vod_genres":
            cat = item.getProperty("cat")
            if cat:
                self._load_hunter_vod_items(cat)
            return

        if self.current_view == "mac_vault":
            mac = item.getProperty("mac")
            url = item.getProperty("url")
            if mac and url:
                from resources.lib import config
                portal = config.portalConfig('1')
                portal['mac'] = mac
                portal['url'] = url
                try:
                    ADDON.setSetting("portal_mac_1", mac)
                    ADDON.setSetting("portal_url_1", url)
                except Exception:
                    pass
                xbmcgui.Dialog().notification("GitPlayGer", "MAC aktiviert: %s" % mac, xbmcgui.NOTIFICATION_INFO, 3000)
                self._fill_main_menu()
            return

        if self.current_view == "hunter_channels":
            cmd = item.getProperty("cmd")
            tmp = item.getProperty("tmp")
            title = item.getLabel()
            if cmd:
                self._play_hunter_stream(cmd, tmp, title)
            return

        if self.current_view == "hunter_vod_items":
            cmd = item.getProperty("cmd")
            title = item.getLabel()
            if cmd:
                self._play_hunter_vod_stream(cmd, title)
            return

        if self.current_view in ("channels", "favorites", "theme_channels", "dead", "kodinerds_channels"):
            stream_url = item.getProperty("url")
            title = item.getLabel()
            if stream_url:
                self._play_stream(stream_url, title)
            return

        if self.current_view == "categories":
            genre = item.getProperty("genre")
            if genre:
                self._load_channels_by_genre(genre)
        elif self.current_view == "alphabet_list":
            char = item.getProperty("char")
            if char:
                self._load_channels_by_char(char)
        elif self.current_view == "kodinerds_playlists":
            url = item.getProperty("url")
            if url:
                self._load_kodinerds_channels(url)

    def _rescan_playlists(self, api):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Suche Playlisten auf GitHub...")
        found = None
        try:
            found = api.regenerate_playlist("all")
        except Exception as e:
            xbmc.log(f"[gitplayger] Neu-Suche fehlgeschlagen: {e}", xbmc.LOGERROR)
        finally:
            progress.close()
        if found == 0 or found is None:
            xbmcgui.Dialog().notification("GitPlayGer", "Keine neuen Playlists gefunden - vorhandene bleiben erhalten", xbmcgui.NOTIFICATION_WARNING, 4000)
        else:
            xbmcgui.Dialog().notification("GitPlayGer", f"{found} Playlist(s) gefunden", xbmcgui.NOTIFICATION_INFO, 3000)

    def _manage_playlists_dialog(self):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lade Playlist-Status...")
        try:
            api = GitPlayGer(region="de")
            playlists = api.get_playlists_status()

            cleaned_playlists = []
            for p in playlists:
                url = p.get("url", "") if isinstance(p, dict) else (p[1] if isinstance(p, (list, tuple)) else "")
                if "custom_m3u" not in url:
                    cleaned_playlists.append(p)

            for i in range(1, 4):
                m3u_path = ADDON.getSetting(f"custom_m3u_{i}_url")
                if m3u_path:
                    enabled = ADDON.getSetting(f"custom_m3u_{i}_enabled") == "true"
                    cleaned_playlists.append({
                        "name": f"Eigene M3U {i} ({os.path.basename(m3u_path)})",
                        "url": f"custom_m3u_{i}_enabled",
                        "path_setting": f"custom_m3u_{i}_url",
                        "enabled": enabled,
                        "is_custom": True
                    })

            if not cleaned_playlists:
                if xbmcgui.Dialog().yesno("GitPlayGer", "Keine Playlisten gefunden.\n\nJetzt neu auf GitHub suchen?"):
                    self._rescan_playlists(api)
                return

            options = []
            for pl in cleaned_playlists:
                name = pl.get("name", "Unbekannt")
                enabled = pl.get("enabled", True)
                status_str = "Aktiviert" if enabled else "Deaktiviert"
                options.append(f"{name} — [{status_str}]")
        finally:
            progress.close()

        sel = xbmcgui.Dialog().select("Playlisten verwalten (Aktion wählen)", options)
        if sel >= 0:
            chosen = cleaned_playlists[sel]
            identifier = chosen.get("url", "")
            is_custom = chosen.get("is_custom", False)
            
            action_choices = [
                "Status umschalten (Aktivieren / Deaktivieren)",
                "Playlist neu suchen / aktualisieren",
                "Playlist löschen / entfernen"
            ]
            
            action_sel = xbmcgui.Dialog().select(f"Aktion für: {chosen.get('name')}", action_choices)
            
            if action_sel == 0:
                if is_custom:
                    current = ADDON.getSetting(identifier) == "true"
                    ADDON.setSetting(identifier, "false" if current else "true")
                    xbmcgui.Dialog().notification("GitPlayGer", "Playlist Status geändert", xbmcgui.NOTIFICATION_INFO, 2000)
                else:
                    api.toggle_playlist(identifier)
                    xbmcgui.Dialog().notification("GitPlayGer", "Playlist Status geändert", xbmcgui.NOTIFICATION_INFO, 2000)
                self._manage_playlists_dialog()
                
            elif action_sel == 1:
                xbmcgui.Dialog().notification("GitPlayGer", "Suche / Aktualisiere Playlist...", xbmcgui.NOTIFICATION_INFO, 2000)
                if is_custom:
                    path_setting = chosen.get("path_setting")
                    m3u_url = ADDON.getSetting(path_setting)
                    if m3u_url and not os.path.exists(m3u_url):
                        try:
                            req = urllib.request.Request(m3u_url, headers={'User-Agent': 'Mozilla/5.0'})
                            with urllib.request.urlopen(req, timeout=15) as resp:
                                _ = resp.read()
                            xbmcgui.Dialog().notification("GitPlayGer", "Playlist erfolgreich aktualisiert", xbmcgui.NOTIFICATION_INFO, 2000)
                        except Exception as e:
                            xbmcgui.Dialog().ok("GitPlayGer", f"Fehler beim Aktualisieren: {e}")
                    else:
                        xbmcgui.Dialog().notification("GitPlayGer", "Lokale Playlist neu geladen", xbmcgui.NOTIFICATION_INFO, 2000)
                else:
                    self._rescan_playlists(GitPlayGer(region="de"))
                self._manage_playlists_dialog()
                
            elif action_sel == 2:
                confirm = xbmcgui.Dialog().yesno("GitPlayGer", f"Möchtest du diese Playlist wirklich entfernen?\n\n{chosen.get('name')}")
                if confirm:
                    if is_custom:
                        path_setting = chosen.get("path_setting")
                        ADDON.setSetting(path_setting, "")
                        ADDON.setSetting(identifier, "false")
                        xbmcgui.Dialog().notification("GitPlayGer", "Eigene M3U entfernt", xbmcgui.NOTIFICATION_INFO, 2000)
                    else:
                        if hasattr(api, "remove_playlist"):
                            api.remove_playlist(identifier)
                        else:
                            api.toggle_playlist(identifier)
                        xbmcgui.Dialog().notification("GitPlayGer", "Playlist gelöscht", xbmcgui.NOTIFICATION_INFO, 2000)
                    self._manage_playlists_dialog()


    def _manage_countries_dialog(self):
        f_mgr = ChannelFilter()
        countries = f_mgr.get_countries_status()

        options = ["[ Alle Länder aktivieren ]", "[ Alle Länder deaktivieren ]"]
        for c in countries:
            status_str = "Aktiviert" if c.get("enabled", True) else "Deaktiviert"
            options.append(f"{c['name']} — [{status_str}]")

        sel = xbmcgui.Dialog().select("Länderfilter verwalten", options)
        if sel == 0:
            f_mgr.set_all_countries(True)
            xbmcgui.Dialog().notification("GitPlayGer", "Alle Länder aktiviert", xbmcgui.NOTIFICATION_INFO, 2000)
            self._manage_countries_dialog()
        elif sel == 1:
            f_mgr.set_all_countries(False)
            xbmcgui.Dialog().notification("GitPlayGer", "Alle Länder deaktiviert", xbmcgui.NOTIFICATION_INFO, 2000)
            self._manage_countries_dialog()
        elif sel >= 2:
            chosen_country = countries[sel - 2]
            f_mgr.toggle_country(chosen_country["code"])
            xbmcgui.Dialog().notification("GitPlayGer", f"Land {chosen_country['name']} umgeschaltet", xbmcgui.NOTIFICATION_INFO, 2000)
            self._manage_countries_dialog()

    def _open_context_menu(self):
        if self.getFocusId() != LIST_ID:
            return

        valid_views = ("channels", "favorites", "theme_channels", "dead", "kodinerds_channels", "hunter_channels")
        if self.current_view not in valid_views:
            return

        listing = self.getControl(LIST_ID)
        item = listing.getSelectedItem()
        if not item:
            return

        url = item.getProperty("url") or item.getProperty("cmd")
        if not url:
            return

        api = GitPlayGer(region="de")
        is_fav = api.is_favorite(url)
        fav_label = "Aus Favoriten entfernen" if is_fav else "Zu Favoriten hinzufügen"

        options = [
            fav_label,
            "Zu einem Thema hinzufügen...",
            "Sender ausblenden"
        ]

        choice = xbmcgui.Dialog().contextmenu(options)
        if choice == 0:
            self._toggle_favorite(item)
        elif choice == 1:
            self._assign_channel_to_theme_prompt(item)
        elif choice == 2:
            self._hide_channel(item)

    def _get_hidden_urls(self):
        profile_dir = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        hidden_path = os.path.join(profile_dir, 'hidden_channels.json')
        if xbmcvfs.exists(hidden_path):
            try:
                with open(hidden_path, 'r', encoding='utf-8') as f:
                    return {h.get("url") for h in json.load(f) if h.get("url")}
            except Exception:
                pass
        return set()

    def _toggle_favorite(self, item):
        api = GitPlayGer(region="de")
        name = item.getLabel()
        url = item.getProperty("url") or item.getProperty("cmd")
        logo = item.getArt("icon") or ""
        target_channel = {
            "name": name,
            "url": url,
            "logo": logo,
            "tvg_id": item.getProperty("tvg_id") or "",
            "genre": "Favoriten",
            "description": ""
        }

        if api.is_favorite(url):
            api.remove_favorite(url)
            xbmcgui.Dialog().notification("GitPlayGer", f"'{name}' aus Favoriten entfernt", xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            api.add_favorite(target_channel)
            xbmcgui.Dialog().notification("GitPlayGer", "Zu Favoriten hinzugefügt", xbmcgui.NOTIFICATION_INFO, 2000)

            dialog = xbmcgui.Dialog()
            choice = dialog.select("Favorit einem Thema zuordnen", [
                "Keinem Thema zuordnen (Nur Standard-Favoriten)",
                "Vorhandenes Thema auswählen",
                "Neues Thema erstellen (Tastatur)"
            ])

            if choice == 1:
                themes = api.get_favorite_themes()
                theme_names = sorted(list(themes.keys()))
                if not theme_names:
                    dialog.ok("GitPlayGer", "Es existieren noch keine Themen.")
                else:
                    t_idx = dialog.select("Wähle ein Thema aus", theme_names)
                    if t_idx >= 0:
                        chosen_theme = theme_names[t_idx]
                        api.add_channel_to_theme(chosen_theme, target_channel)
                        dialog.notification("GitPlayGer", f"Zu '{chosen_theme}' hinzugefügt!", xbmcgui.NOTIFICATION_INFO, 2500)
            elif choice == 2:
                keyboard = xbmc.Keyboard('', 'Neuen Themen-Namen eingeben')
                keyboard.doModal()
                if keyboard.isConfirmed():
                    theme_name = keyboard.getText().strip()
                    if theme_name:
                        themes = api.get_favorite_themes()
                        if theme_name not in themes:
                            api.create_favorite_theme(theme_name)
                        api.add_channel_to_theme(theme_name, target_channel)
                        dialog.notification("GitPlayGer", f"Sender zu '{theme_name}' hinzugefügt!", xbmcgui.NOTIFICATION_INFO, 2500)

    def _assign_channel_to_theme_prompt(self, item):
        api = GitPlayGer(region="de")
        dialog = xbmcgui.Dialog()
        themes = api.get_favorite_themes()
        theme_names = sorted(list(themes.keys()))
        
        choices = ["Vorhandenes Thema auswählen", "Neues Thema erstellen (Tastatur)"]
        sel = dialog.select("Thema zuordnen", choices)
        
        chosen_theme = None
        if sel == 0:
            if not theme_names:
                dialog.ok("GitPlayGer", "Es existieren noch keine Themen.")
                return
            t_idx = dialog.select("Wähle ein Thema aus", theme_names)
            if t_idx >= 0:
                chosen_theme = theme_names[t_idx]
        elif sel == 1:
            keyboard = xbmc.Keyboard('', 'Neuen Themen-Namen eingeben')
            keyboard.doModal()
            if keyboard.isConfirmed():
                chosen_theme = keyboard.getText().strip()
                if chosen_theme:
                    if chosen_theme not in themes:
                        api.create_favorite_theme(chosen_theme)

        if chosen_theme:
            name = item.getLabel()
            url = item.getProperty("url") or item.getProperty("cmd")
            logo = item.getArt("icon") or ""
            target_channel = {
                "name": name,
                "url": url,
                "logo": logo,
                "tvg_id": item.getProperty("tvg_id") or "",
                "genre": chosen_theme,
                "description": ""
            }
            api.add_favorite(target_channel)
            api.add_channel_to_theme(chosen_theme, target_channel)
            dialog.notification("GitPlayGer", f"Sender zu '{chosen_theme}' hinzugefügt!", xbmcgui.NOTIFICATION_INFO, 2000)

    def _hide_channel(self, item):
        profile_dir = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        hidden_path = os.path.join(profile_dir, 'hidden_channels.json')
        
        name = item.getLabel()
        url = item.getProperty("url") or item.getProperty("cmd")
        
        hidden = []
        if xbmcvfs.exists(hidden_path):
            try:
                with open(hidden_path, 'r', encoding='utf-8') as f:
                    hidden = json.load(f)
            except Exception:
                pass
                
        if not any(h.get("url") == url for h in hidden):
            hidden.append({"name": name, "url": url})
            try:
                os.makedirs(profile_dir, exist_ok=True)
                with open(hidden_path, 'w', encoding='utf-8') as f:
                    json.dump(hidden, f, ensure_ascii=False, indent=4)
            except Exception as e:
                xbmc.log(f"[gitplayger] Fehler beim Ausblenden des Senders: {e}", xbmc.LOGERROR)
                
        xbmcgui.Dialog().notification("GitPlayGer", f"'{name}' wurde ausgeblendet", xbmcgui.NOTIFICATION_INFO, 3000)
        self._go_back()

    def _play_stream(self, stream_url, title="Stream"):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Starte Stream...")
        try:
            try:
                if ADDON.getSettingInt("proxy_mode") > 0:
                    local_proxy_port = 4022
                    stream_url = "http://127.0.0.1:%d/%s" % (local_proxy_port, quote_plus(stream_url))
            except Exception:
                pass

            xbmc.Player().play(item=stream_url, listitem=xbmcgui.ListItem(title))
        except Exception as e:
            xbmcgui.Dialog().notification("GitPlayGer", "Fehler: %s" % e, xbmcgui.NOTIFICATION_ERROR, 3000)
        finally:
            progress.close()

    def _play_hunter_stream(self, cmd, tmp, title):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Starte IPTV Stream...")
        try:
            from resources.lib import config, hunter, load_channels
            portal = config.portalConfig('1')
            url = load_channels.retriveUrl(portal['mac'], portal['url'], portal['serial'], cmd, tmp)
            xbmc.Player().play(item=url, listitem=xbmcgui.ListItem(title))
        except Exception as e:
            xbmcgui.Dialog().notification("GitPlayGer", "Fehler: %s" % e, xbmcgui.NOTIFICATION_ERROR, 3000)
        finally:
            progress.close()

    def _play_hunter_vod_stream(self, cmd, title):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Starte VOD Stream...")
        try:
            from resources.lib import config, hunter, load_channels
            portal = config.portalConfig('1')
            url = load_channels.retrive_defaultUrl(portal['mac'], portal['url'], portal['serial'], cmd)
            xbmc.Player().play(item=url, listitem=xbmcgui.ListItem(title))
        except Exception as e:
            xbmcgui.Dialog().notification("GitPlayGer", "Fehler: %s" % e, xbmcgui.NOTIFICATION_ERROR, 3000)
        finally:
            progress.close()

    def _load_hunter_menu(self, save_previous=True):
        self._set_view("hunter_menu", save_previous=save_previous)
        listing = self.getControl(LIST_ID)
        listing.reset()
        items = []
        
        actions = [
            ("Stalker-Portal Live TV", "live_tv", "channels"),
            ("VOD (Filme)", "vod", "vod"),
            ("Serien", "series", "series"),
            ("Cloudflare DNS-Check", "doh_test", "doh_test")
        ]
        
        for label, act_type, key in actions:
            li = xbmcgui.ListItem(label=label)
            icon = _icon_for(key)
            li.setArt({"icon": icon, "thumb": icon})
            li.setProperty("plot", "Stalker-Portal: %s" % label)
            li.setProperty("hunter_action", act_type)
            li.setProperty("kind", "hunter_action_item")
            items.append(li)
            
        listing.addItems(items)
        if items:
            self.setFocus(listing)

    def _load_hunter_channels(self, save_previous=True):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lade Stalker-Portal Sender...")
        try:
            from resources.lib import config, hunter, load_channels
            portal = config.portalConfig('1')
            data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'], hunter.addondir)
            channels = data.get('channels', [])
            
            self._set_view("hunter_channels", save_previous=save_previous)
            hidden_urls = self._get_hidden_urls()
            listing = self.getControl(LIST_ID)
            listing.reset()
            items = []
            
            for ch in channels:
                cmd = ch.get("cmd", "")
                if cmd in hidden_urls:
                    continue
                name = ch.get("name", "Sender")
                logo = ch.get("logo", "")
                tmp = ch.get("tmp", "")
                
                logo_url = portal['url'].rstrip('/') + '/stalker_portal/misc/logos/320/' + logo if logo else _icon_for("all")
                
                li = xbmcgui.ListItem(label=name)
                li.setArt({"icon": logo_url, "thumb": logo_url})
                li.setProperty("cmd", cmd)
                li.setProperty("tmp", str(tmp))
                li.setProperty("plot", ch.get("description", f"Stalker-Portal Live-TV Sender: {name}"))
                items.append(li)
                
            listing.addItems(items)
            if items:
                self.setFocus(listing)
        except Exception as e:
            xbmcgui.Dialog().ok("GitPlayGer", "Fehler beim Laden der Sender: %s" % e)
        finally:
            progress.close()

    def _load_hunter_vod_genres(self, save_previous=True):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lade VOD-Kategorien...")
        try:
            from resources.lib import config, hunter, load_channels
            portal = config.portalConfig('1')
            data = load_channels.getVoDgenres(portal['mac'], portal['url'], portal['serial'], hunter.addondir)
            genres = data.get('vodgenres', {})
            
            self._set_view("hunter_vod_genres", save_previous=save_previous)
            listing = self.getControl(LIST_ID)
            listing.reset()
            items = []
            
            for cat_id, info in genres.items():
                title = info.get("title", "Genre")
                li = xbmcgui.ListItem(label=title.title())
                icon = _icon_for("vod")
                li.setArt({"icon": icon, "thumb": icon})
                li.setProperty("cat", str(info.get("cat", "")))
                li.setProperty("plot", f"VOD-Kategorie: {title.title()}")
                items.append(li)
                
            listing.addItems(items)
            if items:
                self.setFocus(listing)
        except Exception as e:
            xbmcgui.Dialog().ok("GitPlayGer", "Fehler beim Laden von VOD: %s" % e)
        finally:
            progress.close()

    def _load_hunter_vod_items(self, cat, save_previous=True):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lade Filme...")
        try:
            from resources.lib import config, hunter, load_channels
            portal = config.portalConfig('1')
            data = load_channels.getVoD(portal['mac'], portal['url'], portal['serial'], hunter.addondir)
            vod_items = data.get('vod' + cat, [])
            
            self._set_view("hunter_vod_items", save_previous=save_previous)
            listing = self.getControl(LIST_ID)
            listing.reset()
            items = []
            
            for i in vod_items:
                name = i.get("name", "")
                cmd = i.get("cmd", "")
                logo = i.get("logo", "")
                logo_url = portal['url'].rstrip('/') + logo if logo else _icon_for("vod")
                
                li = xbmcgui.ListItem(label=name)
                li.setArt({"icon": logo_url, "thumb": logo_url})
                li.setProperty("cmd", cmd)
                li.setProperty("plot", i.get("description", f"Film: {name}"))
                items.append(li)
                
            listing.addItems(items)
            if items:
                self.setFocus(listing)
        except Exception as e:
            xbmcgui.Dialog().ok("GitPlayGer", "Fehler beim Laden der Filme: %s" % e)
        finally:
            progress.close()

    def _load_hunter_series(self, save_previous=True):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Serien sind über das Hauptmenü erreichbar.")
        progress.close()
        xbmcgui.Dialog().ok("GitPlayGer", "Serien-Ansicht wird im Hauptmenü direkt unterstützt.")

    def _load_mac_vault(self, save_previous=True):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lade MAC-Tresor...")
        try:
            from resources.lib import hunter
            vault_dir = hunter.get_mac_vault_dir()
            vault_files = [os.path.join(vault_dir, f) for f in os.listdir(vault_dir) if f.endswith(".json")] if os.path.exists(vault_dir) else []
            
            self._set_view("mac_vault", save_previous=save_previous)
            listing = self.getControl(LIST_ID)
            listing.reset()
            items = []
            
            if not vault_files:
                li = xbmcgui.ListItem(label="Keine 6+ Monate Accounts im Tresor gespeichert.")
                icon = _icon_for("mac_vault")
                li.setArt({"icon": icon, "thumb": icon})
                li.setProperty("plot", "Der MAC-Tresor speichert aktivierte und geprüfte Stalker-Portal Zugangsdaten.")
                items.append(li)
            else:
                for vf in vault_files:
                    try:
                        with open(vf, "r", encoding="utf-8") as f:
                            acc = json.load(f)
                            mac = acc.get("mac")
                            url = acc.get("url")
                            expiry = acc.get("expiry")
                            title = "MAC: %s | Gültig bis: %s" % (mac, expiry)
                            
                            li = xbmcgui.ListItem(label=title)
                            icon = _icon_for("mac_vault")
                            li.setArt({"icon": icon, "thumb": icon})
                            li.setProperty("mac", mac)
                            li.setProperty("url", url)
                            li.setProperty("plot", f"Stalker-Portal MAC: {mac}\nPortal-URL: {url}\nGültig bis: {expiry}")
                            items.append(li)
                    except Exception:
                        pass
                        
            listing.addItems(items)
            if items:
                self.setFocus(listing)
        finally:
            progress.close()

    def _search(self):
        keyboard = xbmc.Keyboard("", "Sender suchen ...")
        keyboard.doModal()
        if keyboard.isConfirmed():
            term = keyboard.getText().strip()
            if term:
                progress = xbmcgui.DialogProgressBG()
                progress.create("GitPlayGer", "Durchsuche Sender...")
                try:
                    api = GitPlayGer(region="de")
                    channels = [c for c in api.get_channels() if term.lower() in c.get("name", "").lower()]
                finally:
                    progress.close()
                self._populate_channel_list(channels, "Suche: %s" % term)

    def _load_favorite_themes(self, save_previous=True):
        self._set_view("favorite_themes", save_previous=save_previous)
        api = GitPlayGer(region="de")
        listing = self.getControl(LIST_ID)
        listing.reset()
        items = []

        fav_all_item = xbmcgui.ListItem(label="[COLOR gold]★ Alle Favoriten (Standard) ★[/COLOR]")
        icon = _icon_for("favorites")
        fav_all_item.setArt({"icon": icon, "thumb": icon})
        fav_all_item.setProperty("kind", "fav_all")
        fav_all_item.setProperty("plot", "Alle als Favorit markierten Sender in der Standardansicht.")
        items.append(fav_all_item)

        new_theme_item = xbmcgui.ListItem(label="[COLOR cyan]+ Neues Thema erstellen...[/COLOR]")
        new_theme_item.setArt({"icon": icon, "thumb": icon})
        new_theme_item.setProperty("kind", "fav_new_theme")
        new_theme_item.setProperty("plot", "Erstelle einen neuen Themen-Ordner (z.B. Sport, Nachrichten, Filme).")
        items.append(new_theme_item)

        themes = api.get_favorite_themes()
        for theme_name in sorted(themes.keys()):
            count = len(themes[theme_name])
            li = xbmcgui.ListItem(label=f"[COLOR gold][ ♦ ][/COLOR]  [COLOR white]{theme_name}[/COLOR]  [COLOR silver]({count} Sender)[/COLOR]")
            li.setArt({"icon": icon, "thumb": icon})
            li.setProperty("kind", "fav_theme_folder")
            li.setProperty("theme_name", theme_name)
            li.setProperty("plot", f"Themen-Ordner '{theme_name}' mit {count} gespeicherten Sendern.")
            items.append(li)            

        listing.addItems(items)
        if items:
            self.setFocus(listing)


    def _create_theme_prompt(self):
        keyboard = xbmc.Keyboard('', 'Themen-Name eingeben (z.B. Sport, Nachrichten)')
        keyboard.doModal()
        if keyboard.isConfirmed():
            theme_name = keyboard.getText().strip()
            if theme_name:
                api = GitPlayGer(region="de")
                api.create_favorite_theme(theme_name)
                xbmcgui.Dialog().notification("GitPlayGer", f"Thema '{theme_name}' erstellt!", xbmcgui.NOTIFICATION_INFO, 2000)
                self._load_favorite_themes(save_previous=False)

    def _load_favorites(self):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lade Favoriten...")
        try:
            api = GitPlayGer(region="de")
            favorites = api.get_favorites()
        finally:
            progress.close()

        if not favorites:
            xbmcgui.Dialog().ok("GitPlayGer", "Keine Favoriten gespeichert.")
            return
        self._populate_channel_list(favorites, "Meine Favoriten", view_name="favorites")

    def _load_channels_in_theme(self, theme_name, save_previous=True):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", f"Lade Thema '{theme_name}'...")
        try:
            api = GitPlayGer(region="de")
            themes = api.get_favorite_themes()
            channels = themes.get(theme_name, [])
        finally:
            progress.close()

        self._set_view("theme_channels", save_previous=save_previous)
        if not channels:
            xbmcgui.Dialog().ok("GitPlayGer", f"Keine Sender im Thema '{theme_name}' gespeichert.")
            return
        self._populate_channel_list(channels, f"Thema: {theme_name}", view_name="theme_channels")

    def _load_channels(self, mode="all"):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lade und filtere Sender...")
        try:
            api = GitPlayGer(region="de")
            f_mgr = ChannelFilter()
            raw_channels = api.get_channels()
            
            for i in range(1, 4):
                if ADDON.getSetting(f"custom_m3u_{i}_enabled") == "true":
                    m3u_path = ADDON.getSetting(f"custom_m3u_{i}_url")
                    if m3u_path and hasattr(api, '_parse_m3u'):
                        try:
                            if os.path.exists(m3u_path):
                                with open(m3u_path, 'r', encoding='utf-8', errors='ignore') as cf:
                                    content = cf.read()
                            else:
                                req = urllib.request.Request(m3u_path, headers={'User-Agent': 'Mozilla/5.0'})
                                with urllib.request.urlopen(req, timeout=15) as resp:
                                    content = resp.read().decode('utf-8', errors='ignore')
                            custom_channels = api._parse_m3u(content, f"Eigene M3U {i}")
                            if custom_channels:
                                raw_channels.extend(custom_channels)
                        except Exception:
                            pass

            channels = f_mgr.apply_filters(raw_channels)

            if mode == "epg":
                channels = [c for c in channels if c.get("tvg_id") or c.get("epg_id") or c.get("tvg-id")]
        finally:
            progress.close()

        if not channels:
            xbmcgui.Dialog().ok("GitPlayGer", "Keine Sender gefunden.")
            return
        self._populate_channel_list(channels, "Alle Sender", view_name="channels")

    def _load_categories(self, save_previous=True):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lade Kategorien...")
        try:
            api = GitPlayGer(region="de")
            channels = api.get_channels()
            genres = sorted({c.get("genre") for c in channels if c.get("genre")}, key=str.lower)
            
            self._set_view("categories", save_previous=save_previous)
            listing = self.getControl(LIST_ID)
            listing.reset()
            items = []
            for g in genres:
                li = xbmcgui.ListItem(label=g)
                li.setArt({"icon": _icon_for("categories"), "thumb": _icon_for("categories")})
                li.setProperty("genre", g)
                li.setProperty("plot", f"Sender-Kategorie / Genre: {g}")
                items.append(li)
            listing.addItems(items)
            if items:
                self.setFocus(listing)
        finally:
            progress.close()

    def _load_channels_by_genre(self, genre):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", f"Lade Kategorie '{genre}'...")
        try:
            api = GitPlayGer(region="de")
            channels = [c for c in api.get_channels() if c.get("genre") == genre]
        finally:
            progress.close()
        self._populate_channel_list(channels, "Kategorie: %s" % genre)

    def _load_alphabet(self, save_previous=True):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lade Alphabet-Übersicht...")
        try:
            api = GitPlayGer(region="de")
            channels = api.get_channels()
            chars = sorted({ch.get("name", "").strip()[0].upper() for ch in channels if ch.get("name", "").strip() and ch.get("name", "").strip()[0].isalnum()})
            
            self._set_view("alphabet_list", save_previous=save_previous)
            listing = self.getControl(LIST_ID)
            listing.reset()
            items = [xbmcgui.ListItem(label="# (Zahlen & Sonderzeichen)")]
            items[0].setProperty("char", "HASH")
            items[0].setProperty("plot", "Sender, die mit Zahlen oder Sonderzeichen beginnen.")
            items[0].setArt({"icon": _icon_for("alphabet"), "thumb": _icon_for("alphabet")})
            for char in chars:
                li = xbmcgui.ListItem(label=char)
                li.setProperty("char", char)
                li.setProperty("plot", f"Sender, die mit dem Buchstaben '{char}' beginnen.")
                li.setArt({"icon": _icon_for("alphabet"), "thumb": _icon_for("alphabet")})
                items.append(li)
            listing.addItems(items)
            if items:
                self.setFocus(listing)
        finally:
            progress.close()

    def _load_channels_by_char(self, char):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", f"Lade Sender für '{char}'...")
        try:
            api = GitPlayGer(region="de")
            channels = api.get_channels()
            if char == "HASH":
                filtered = [c for c in channels if c.get("name", "").strip() and not c.get("name", "").strip()[0].isalnum()]
            else:
                filtered = [c for c in channels if c.get("name", "").strip().upper().startswith(char)]
        finally:
            progress.close()
        self._populate_channel_list(filtered, "Sender mit '%s'" % char)

    def _load_kodinerds_playlists(self, save_previous=True):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Durchsuche Kodinerds Unterverzeichnisse...")
        
        playlists = []
        try:
            api_url = "https://api.github.com/repos/jnk22/kodinerds-iptv/git/trees/master?recursive=1"
            req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0', 'Accept': 'application/vnd.github+json'})
            with urllib.request.urlopen(req, timeout=15) as response:
                data = json.loads(response.read().decode('utf-8'))
                
            tree = data.get("tree", [])
            for item in tree:
                path = item.get("path", "")
                if path.endswith(".m3u"):
                    name = path.split("/")[-1].replace(".m3u", "").upper()
                    folder_path = "/".join(path.split("/")[:-1])
                    display_name = f"Kodinerds [{folder_path}] — {name}" if folder_path else f"Kodinerds — {name}"
                    
                    raw_url = f"https://raw.githubusercontent.com/jnk22/kodinerds-iptv/master/{path}"
                    playlists.append({"name": display_name, "url": raw_url})
        except Exception as e:
            xbmc.log(f"[gitplayger] Fehler beim Scannen der Kodinerds-Ordner: {e}", xbmc.LOGERROR)
        finally:
            progress.close()

        if not playlists:
            xbmcgui.Dialog().ok("GitPlayGer", "Keine Kodinerds M3Us gefunden.")
            return

        self._set_view("kodinerds_playlists", save_previous=save_previous)
        listing = self.getControl(LIST_ID)
        listing.reset()
        items = []
        
        for pl in playlists:
            li = xbmcgui.ListItem(label=pl["name"])
            icon = _icon_for("kodinerds")
            li.setArt({"icon": icon, "thumb": icon})
            li.setProperty("url", pl["url"])
            li.setProperty("plot", f"Kodinerds Playlist: {pl['name']}")
            items.append(li)
            
        listing.addItems(items)
        if items:
            self.setFocus(listing)

    def _load_kodinerds_channels(self, playlist_url, save_previous=True):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lade Kodinerds Playlist...")
        try:
            api = GitPlayGer(region="de")
            f_mgr = ChannelFilter()
            
            req = urllib.request.Request(playlist_url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=15) as response:
                content = response.read().decode('utf-8', errors='ignore')
            
            raw_channels = api._parse_m3u(content, "Kodinerds")
            channels = f_mgr.apply_filters(raw_channels)
        except Exception as e:
            xbmc.log(f"[gitplayger] Fehler beim Laden der Kodinerds M3U: {e}", xbmc.LOGERROR)
            channels = []
        finally:
            progress.close()

        if not channels:
            xbmcgui.Dialog().ok("GitPlayGer", "Keine Sender in dieser Playlist gefunden.")
            return

        self._set_view("kodinerds_channels", save_previous=save_previous)
        hidden_urls = self._get_hidden_urls()
        listing = self.getControl(LIST_ID)
        listing.reset()
        items = []
        
        for ch in channels:
            url = ch.get("url", "")
            if url in hidden_urls:
                continue
            name = ch.get("name", "Sender")
            logo = ch.get("logo", "") or _icon_for("all")
            li = xbmcgui.ListItem(label=name)
            li.setArt({"icon": logo, "thumb": logo})
            li.setProperty("url", url)
            li.setProperty("plot", ch.get("description", f"Kodinerds IPTV Sender: {name}"))
            items.append(li)
            
        listing.addItems(items)
        if items:
            self.setFocus(listing)

    def _load_dead_channels(self, save_previous=True):
        progress = xbmcgui.DialogProgressBG()
        progress.create("GitPlayGer", "Lade tote Links...")
        try:
            profile_dir = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
            path = os.path.join(profile_dir, 'dead_links.json')
            dead_list = []
            if xbmcvfs.exists(path):
                try:
                    with open(path, 'r', encoding='utf-8') as f:
                        dead_list = json.load(f)
                except Exception:
                    pass
        finally:
            progress.close()

        if not dead_list:
            xbmcgui.Dialog().ok("GitPlayGer", "Keine nicht verfügbaren Sender gespeichert.")
            return

        self._set_view("dead", save_previous=save_previous)
        hidden_urls = self._get_hidden_urls()
        listing = self.getControl(LIST_ID)
        listing.reset()
        items = []
        
        for ch in dead_list:
            url = ch.get("url", "")
            if url in hidden_urls:
                continue
            name = ch.get("name", "Unbekannter Sender")
            logo = ch.get("logo", "") or _icon_for("all")
            li = xbmcgui.ListItem(label="[COLOR red]%s[/COLOR]" % name)
            li.setArt({"icon": logo, "thumb": logo})
            li.setProperty("url", url)
            li.setProperty("plot", f"Dieser Sender ('{name}') wurde als nicht erreichbar eingestuft.")
            items.append(li)
            
        listing.addItems(items)
        if items:
            self.setFocus(listing)

    def _populate_channel_list(self, channels, title, view_name="channels"):
        self._set_view(view_name)
        hidden_urls = self._get_hidden_urls()
        listing = self.getControl(LIST_ID)
        listing.reset()
        items = []

        for ch in channels:
            url = ch.get("url", "") or ch.get("cmd", "")
            if url in hidden_urls:
                continue

            name = ch.get("name", "Sender")
            logo = ch.get("logo", "") or ch.get("icon", "") or _icon_for("all")
            tvg_id = str(ch.get("tvg_id", "") or ch.get("epg_id", "") or ch.get("tvg-id", ""))
            desc = ch.get("description", "") or ch.get("epg_plot", "") or "Keine EPG-Informationen verfügbar."

            display_name = f"[COLOR white]{name}[/COLOR]"
            if tvg_id:
                display_name = f"[COLOR white]{name}[/COLOR]  [COLOR gray][EPG][/COLOR]"

            li = xbmcgui.ListItem(label=display_name)
            li.setArt({"icon": logo, "thumb": logo, "poster": logo})
            li.setProperty("url", url)
            li.setProperty("tvg_id", tvg_id)
            
            info = li.getVideoInfoTag()
            info.setTitle(name)
            info.setPlot(desc)
            li.setProperty('plot', desc)

            items.append(li)

        listing.addItems(items)
        if items:
            self.setFocus(listing)


def show_main_menu():
    window = MainMenuWindow(XML_FILE, ADDON_PATH, "Default", "1080i")
    try:
        window.doModal()
    finally:
        del window
        xbmc.executebuiltin('ActivateWindow(home)')
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum des Autors.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
