# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import sys, urllib.parse, requests, json, os, time

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
SETTING_MODE = ADDON.getSetting('mode') or '0'
ADDON_PATH = ADDON.getAddonInfo('path')
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

if not xbmcvfs.exists(PROFILE_DIR):
    xbmcvfs.mkdir(PROFILE_DIR)

URL_GITHUB = "https://raw.githubusercontent.com/mr-evil1/VAVOO/refs/heads/main/vavoo_full.json"
CACHE_GITHUB = os.path.join(PROFILE_DIR, 'vavoo_full.json')
FAVORITES_FILE = os.path.join(PROFILE_DIR, 'tv_favorites.json')

FALLBACK_SEQUENCE = [
    ('0', None),
    ('1', '0'),
    ('1', '1'),
    ('1', '2'),
    ('1', '3'),
    ('2', None),
]

def get_fail_counter():
    return int(ADDON.getSetting('fail_counter') or '0')

def increment_fail_counter():
    current = get_fail_counter()
    current += 1
    ADDON.setSetting('fail_counter', str(current))
    xbmc.log("[FALLBACK] Fail Counter = {0}/3".format(current), xbmc.LOGWARNING)
    return current

def reset_fail_counter():
    ADDON.setSetting('fail_counter', '0')
    xbmc.log("[FALLBACK] Counter zurückgesetzt", xbmc.LOGINFO)

def get_current_fallback_index():
    current_mode = ADDON.getSetting('mode') or '0'
    current_provider = ADDON.getSetting('provider_selection') or '0'
    
    for i, (mode, provider) in enumerate(FALLBACK_SEQUENCE):
        if mode == current_mode:
            if mode == '1':
                if provider == current_provider:
                    return i
            else:
                return i
    return 0

def switch_to_next_fallback():
    current_index = get_current_fallback_index()
    next_index = (current_index + 1) % len(FALLBACK_SEQUENCE)
    new_mode, new_provider = FALLBACK_SEQUENCE[next_index]
    
    old_mode = ADDON.getSetting('mode') or '0'
    old_provider = ADDON.getSetting('provider_selection') or '0'
    
    ADDON.setSetting('mode', new_mode)
    if new_provider is not None:
        ADDON.setSetting('provider_selection', new_provider)
    
    reset_fail_counter()
    
    mode_names = {
        '0': 'VAVOO (Legacy)',
        '1': {
            '0': 'VAVOO MODE 2 (VAVOO.to)',
            '1': 'VAVOO MODE 2 (OHA.to)',
            '2': 'VAVOO MODE 2 (HUHU.to)',
            '3': 'VAVOO MODE 2 (KOOL.to)'
        },
        '2': 'GitHub'
    }
    
    old_name = mode_names['1'][old_provider] if old_mode == '1' else mode_names.get(old_mode, 'Unknown')
    new_name = mode_names['1'][new_provider] if new_mode == '1' else mode_names.get(new_mode, 'Unknown')
    
    xbmc.log("[FALLBACK] Wechsel von {0} zu {1}".format(old_name, new_name), xbmc.LOGWARNING)
    return new_name

def test_stream_url(stream_url, headers):
    try:
        xbmc.log("[FALLBACK] Teste Stream: {0}".format(stream_url), xbmc.LOGDEBUG)
        response = requests.head(stream_url, headers=headers, timeout=5, allow_redirects=True)
        if response.status_code in [200, 302, 301]:
            xbmc.log("[FALLBACK] Stream OK (Status: {0})".format(response.status_code), xbmc.LOGDEBUG)
            return True
        else:
            xbmc.log("[FALLBACK] Stream Fehler (Status: {0})".format(response.status_code), xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log("[FALLBACK] Stream Test Fehler: {0}".format(str(e)), xbmc.LOGWARNING)
    return False

def clear_cache():
    deleted_files = []
    try:
        if os.path.exists(CACHE_GITHUB):
            os.remove(CACHE_GITHUB)
            deleted_files.append('GitHub Cache')
            xbmc.log("[VAVOO-CACHE] GitHub Cache gelöscht", xbmc.LOGINFO)
        
        if deleted_files:
            msg = "Cache gelöscht: {0}".format(", ".join(deleted_files))
            xbmcgui.Dialog().notification('VAVOO', msg, xbmcgui.NOTIFICATION_INFO, 3000)
        else:
            xbmcgui.Dialog().notification('VAVOO', 'Kein Cache vorhanden', xbmcgui.NOTIFICATION_INFO, 2000)
        
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmc.log("[VAVOO-CACHE] Fehler beim Löschen: {0}".format(str(e)), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('VAVOO', 'Fehler beim Cache löschen', xbmcgui.NOTIFICATION_ERROR, 3000)

def get_oha_provider():
    provider_selection = ADDON.getSetting('provider_selection') or '0'
    providers = {
        '0': {
            'name': 'VAVOO',
            'domain': 'vavoo.to',
            'catalog_url': 'http://vavoo.to/mediahubmx-catalog.json',
            'resolve_url': 'https://vavoo.to/vto-cluster/mediahubmx-resolve.json',
            'play_url': 'https://vavoo.to/vavoo-iptv/play/{0}'
        },
        '1': {
            'name': 'OHA',
            'domain': 'oha.to',
            'catalog_url': 'http://oha.to/mediaurl-catalog.json',
            'resolve_url': 'https://oha.to/vto-cluster/mediahubmx-resolve.json',
            'play_url': 'https://oha.to/oha-iptv/play/{0}'
        },
        '2': {
            'name': 'HUHU',
            'domain': 'huhu.to',
            'catalog_url': 'http://huhu.to/mediaurl-catalog.json',
            'resolve_url': 'https://huhu.to/vto-cluster/mediahubmx-resolve.json',
            'play_url': 'https://huhu.to/huhu-iptv/play/{0}'
        },
        '3': {
            'name': 'KOOL',
            'domain': 'kool.to',
            'catalog_url': 'http://kool.to/mediahubmx-catalog.json',
            'resolve_url': 'https://kool.to/vto-cluster/mediahubmx-resolve.json',
            'play_url': 'https://kool.to/kool-iptv/play/{0}'
        }
    }
    provider = providers.get(provider_selection, providers['0'])
    xbmc.log("[VAVOO-OHA] Provider: {0} (Selection: {1})".format(provider['name'], provider_selection), xbmc.LOGINFO)
    return provider

def get_oha_headers():
    provider = get_oha_provider()
    return {
        'User-Agent': 'MediaHubMX/2',
        'Content-Type': 'application/json; charset=utf-8',
        'mediahubmx-signature': 'eyJkYXRhIjoie1widGltZVwiOjE5Njk0NTY5MDI2OTYsXCJ2YWxpZFVudGlsXCI6NTc2OTQ1NzkwMDAwMCxcInVzZXJcIjpcIlN6SE9icmlkdDlDOHBXSG0rZVFMLzJYaDNSN3JqUm1ISTlPdFlqRWNHenM9XCIsXCJzdGF0dXNcIjpcImd1ZXN0XCIsXCJ2ZXJpZmllZFwiOmZhbHNlLFwiaXBzXCI6W1wiMTc3LjEyMi4yNTIuMTY5XCJdLFwiYXBwXCI6e1wibmFtZVwiOlwiRGV6b3JcIixcInZlcnNpb25cIjpcIjEuMS4yXCIsXCJwbGF0Zm9ybVwiOlwiYW5kcm9pZFwiLFwib2tcIjp0cnVlfX0iLCJzaWduYXR1cmUiOiJKcUk4TDRGV3lIb1Z0MGZjM29lVllPWHgxTXFncDRVRlMwcEwvVFVwcmFkSnJBRldEUmM2ZS8waEEwVmdUYmpCYldGdGVqWU9CNEFWOTZQcEltSmZrbG5zNVNvNnNNMDFpWk5rb29rc2kxUmFxeWFzb0xYa1kxQmFKdUdOb3RjdU81cnYvVmpUbkRGRUdJcnRxcHNPMGcwZnBNUXVXS0FLNGF6OFg3R2Flcnc9In0=',
        'Accept-Encoding': 'gzip',
        'Connection': 'keep-alive',
        'Host': provider['domain']
    }

def load_tv_favorites():
    try:
        if os.path.exists(FAVORITES_FILE):
            with open(FAVORITES_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                xbmc.log("[VAVOO-FAV] {0} Favoriten geladen".format(len(data)), xbmc.LOGINFO)
                return data
    except Exception as e:
        xbmc.log("[VAVOO-FAV] Ladefehler: {0}".format(str(e)), xbmc.LOGERROR)
    return []

def save_tv_favorites(favorites):
    try:
        with open(FAVORITES_FILE, 'w', encoding='utf-8') as f:
            json.dump(favorites, f, ensure_ascii=False, indent=2)
        xbmc.log("[VAVOO-FAV] {0} Favoriten gespeichert".format(len(favorites)), xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log("[VAVOO-FAV] Speicherfehler: {0}".format(str(e)), xbmc.LOGERROR)
        return False

def add_tv_favorite(name, channel_id, mode):
    favorites = load_tv_favorites()
    for fav in favorites:
        if fav.get('name') == name and fav.get('mode') == str(mode):
            xbmcgui.Dialog().notification('VAVOO', 'Bereits in TV Favoriten', xbmcgui.NOTIFICATION_INFO, 2000)
            return
    favorites.append({
        'name': name,
        'id': channel_id,
        'mode': str(mode),
        'added': time.time()
    })
    if save_tv_favorites(favorites):
        xbmcgui.Dialog().notification('VAVOO', 'Zu TV Favoriten hinzugefügt', xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")

def remove_tv_favorite(name, mode):
    favorites = load_tv_favorites()
    favorites = [f for f in favorites if not (f.get('name') == name and f.get('mode') == str(mode))]
    if save_tv_favorites(favorites):
        xbmcgui.Dialog().notification('VAVOO', 'Aus TV Favoriten entfernt', xbmcgui.NOTIFICATION_INFO, 2000)
        if len(favorites) == 0:
            xbmc.executebuiltin("Action(ParentDir)")
        else:
            xbmc.executebuiltin("Container.Refresh")

def is_tv_favorite(name, mode):
    favorites = load_tv_favorites()
    for fav in favorites:
        if fav.get('name') == name and fav.get('mode') == str(mode):
            return True
    return False

def show_all_tv_favorites():
    favorites = load_tv_favorites()
    if not favorites:
        xbmcgui.Dialog().notification('VAVOO', 'Keine TV Favoriten vorhanden', xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    mode_names = {'0': 'VAVOO', '1': get_oha_provider()['name'], '2': 'GitHub'}
    for fav in sorted(favorites, key=lambda x: x.get('name', '')):
        name = fav.get('name', 'Unbekannt')
        mode = str(fav.get('mode', '0'))
        channel_id = fav.get('id', '')
        label = "[{0}] {1}".format(mode_names.get(mode, 'Unknown'), name)
        li = xbmcgui.ListItem(label=label)
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {
            'title': name,
            'plot': '[COLOR gold]TV Favorite[/COLOR]\nQuelle: {0}'.format(mode_names.get(mode, 'Unknown'))
        })
        cm = [
            ('Remove from TV Favorites', 'RunPlugin({0}?action=remove_fav&name={1}&mode={2})'.format(
                BASE_URL, urllib.parse.quote_plus(name), mode)),
            ('Clear Cache', 'RunPlugin({0}?action=clear_cache)'.format(BASE_URL))
        ]
        li.addContextMenuItems(cm)
        url = "{0}?mode={1}&action=play&id={2}&name={3}".format(
            BASE_URL, mode, channel_id, urllib.parse.quote_plus(name))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def add_tv_favorites_entry():
    favorites = load_tv_favorites()
    if not favorites:
        return
    li = xbmcgui.ListItem(label="★ TV Favorites ({0})".format(len(favorites)))
    li.setArt({'icon': 'DefaultFavourites.png'})
    li.setInfo('video', {'plot': '[COLOR gold]Your TV Favorites from all sources[/COLOR]'})
    cm = [('Clear Cache', 'RunPlugin({0}?action=clear_cache)'.format(BASE_URL))]
    li.addContextMenuItems(cm)
    url = "{0}?action=show_all_favorites".format(BASE_URL)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, True)

def clean_name(name):
    if not name: return "Unbenannt"
    return name.lstrip('.').strip()

def sort_germany_first(item_list):
    germany = [x for x in item_list if x and 'Germany' in x]
    others = [x for x in item_list if x and 'Germany' not in x]
    return sorted(germany) + sorted(others)

def get_country_flag(group_name):
    flag_file = 'DefaultFolder.png'
    mapping = {
        'Germany': 'de.png', 'Austria': 'at.png', 'Switzerland': 'ch.png',
        'Turkey': 'tr.png', 'UK': 'gb.png', 'United Kingdom': 'gb.png',
        'France': 'fr.png', 'Italy': 'it.png', 'Albania': 'al.png',
        'Spain': 'es.png', 'Poland': 'pl.png', 'Netherlands': 'nl.png',
        'Portugal': 'pt.png', 'Greece': 'gr.png', 'Russia': 'ru.png',
        'USA': 'us.png', 'United States': 'us.png', 'Balkans': 'hr.png',
        'Bosnia': 'ba.png', 'Croatia': 'hr.png', 'Serbia': 'rs.png',
        'Slovenia': 'si.png', 'Macedonia': 'mk.png', 'Montenegro': 'me.png',
        'Kosovo': 'xk.png', 'Belgium': 'be.png', 'Bulgaria': 'bg.png',
        'Czech': 'cz.png', 'Denmark': 'dk.png', 'Finland': 'fi.png',
        'Hungary': 'hu.png', 'Iceland': 'is.png', 'Ireland': 'ie.png',
        'Norway': 'no.png', 'Romania': 'ro.png', 'Slovakia': 'sk.png',
        'Sweden': 'se.png', 'Ukraine': 'ua.png', 'Arabia': 'ae.png',
        'Arabic': 'ae.png', 'Iran': 'ir.png', 'Israel': 'il.png',
        'India': 'in.png', 'Pakistan': 'pk.png', 'Afghanistan': 'af.png',
        'Azerbaijan': 'az.png', 'Morocco': 'ma.png', 'Egypt': 'eg.png',
        'Tunisia': 'tn.png', 'Algeria': 'dz.png', 'Brazil': 'br.png',
        'Mexico': 'mx.png', 'Argentina': 'ar.png'
    }
    for key, val in mapping.items():
        if group_name == key or group_name.startswith(key):
            flag_file = val
            break
    if flag_file == 'DefaultFolder.png':
        group_lower = group_name.lower()
        for key, val in mapping.items():
            if key.lower() in group_lower:
                flag_file = val
                break
    path = os.path.join(ADDON_PATH, 'resources', 'country', flag_file)
    return path if os.path.exists(path) else 'DefaultFolder.png'

def create_channel_item(name, vid, mode, is_fav=False, icon=None):
    display_name = name
    li = xbmcgui.ListItem(label=display_name)
    li.setProperty('IsPlayable', 'true')
    plot = '[COLOR gold]TV Favorite[/COLOR]\n' if is_fav else ''
    mode_names = {'0': 'VAVOO', '1': get_oha_provider()['name'], '2': 'GitHub'}
    plot += 'Quelle: {0}'.format(mode_names.get(str(mode), 'Unknown'))
    li.setInfo('video', {'title': name, 'plot': plot})
    if icon:
        li.setArt({'thumb': icon, 'icon': icon})
    cm = []
    if is_fav:
        cm.append(('Aus TV Favorites entfernen', 'RunPlugin({0}?action=remove_fav&name={1}&mode={2})'.format(
            BASE_URL, urllib.parse.quote_plus(name), str(mode))))
    else:
        cm.append(('Zu TV Favorites hinzufügen', 'RunPlugin({0}?action=add_fav&name={1}&id={2}&mode={3})'.format(
            BASE_URL, urllib.parse.quote_plus(name), vid, str(mode))))
    cm.append(('Vavoo Cache leeren', 'RunPlugin({0}?action=clear_cache)'.format(BASE_URL)))
    li.addContextMenuItems(cm)
    url = "{0}?mode={1}&action=play&id={2}&name={3}".format(BASE_URL, mode, vid, urllib.parse.quote_plus(name))
    return li, url

def get_github_data():
    if os.path.exists(CACHE_GITHUB):
        if (time.time() - os.path.getmtime(CACHE_GITHUB)) < 7200:
            try:
                with open(CACHE_GITHUB, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
    try:
        r = requests.get(URL_GITHUB, timeout=30)
        if r.status_code == 200:
            data = r.json()
            with open(CACHE_GITHUB, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return data
    except:
        pass
    return None

def list_groups_github():
    data = get_github_data()
    if not data or not isinstance(data, dict):
        xbmcgui.Dialog().notification('VAVOO', 'GitHub: Keine Daten', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    add_tv_favorites_entry()
    countries = sort_germany_first(list(data.keys()))
    for country in countries:
        channels = data.get(country, [])
        li = xbmcgui.ListItem(label="{0} ({1})".format(clean_name(country), len(channels)))
        li.setArt({'icon': get_country_flag(country)})
        cm = [('Clear Cache', 'RunPlugin({0}?action=clear_cache)'.format(BASE_URL))]
        li.addContextMenuItems(cm)
        url = "{0}?mode=2&action=list_channels&group={1}".format(BASE_URL, urllib.parse.quote_plus(country))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_channels_github(group_enc):
    group = urllib.parse.unquote_plus(group_enc)
    data = get_github_data()
    channels = data.get(group, []) if data else []
    all_channels = []
    for item in channels:
        name = clean_name(item.get('name', 'Unbekannt'))
        url_str = item.get('url', '')
        vid = url_str.split('/play/')[-1] if '/play/' in url_str else None
        if vid:
            is_fav = is_tv_favorite(name, '2')
            icon = item.get('icon', '')
            all_channels.append({'name': name, 'vid': vid, 'is_fav': is_fav, 'icon': icon})
    
    favorites = sorted([ch for ch in all_channels if ch['is_fav']], key=lambda x: x['name'])
    non_favorites = sorted([ch for ch in all_channels if not ch['is_fav']], key=lambda x: x['name'])
    
    for ch in favorites:
        li, url = create_channel_item(ch['name'], ch['vid'], '2', is_fav=True, icon=ch['icon'])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)
    for ch in non_favorites:
        li, url = create_channel_item(ch['name'], ch['vid'], '2', is_fav=False, icon=ch['icon'])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def list_groups_oha():
    provider = get_oha_provider()
    headers = get_oha_headers()
    payload = {
        "language": "de", "region": "XX", "catalogId": "iptv", "id": "iptv",
        "adult": False, "search": "", "sort": "", "filter": {},
        "cursor": None, "clientVersion": "3.0.2"
    }
    try:
        r = requests.post(provider['catalog_url'], headers=headers, json=payload, timeout=20)
        if r.status_code == 200:
            data = r.json()
            groups = []
            for f in data.get('features', {}).get('filter', []):
                if f.get('id') == 'group':
                    groups = f.get('values', [])
            add_tv_favorites_entry()
            for group in sort_germany_first(groups):
                li = xbmcgui.ListItem(label="[{0}] {1}".format(provider['name'], clean_name(group)))
                li.setArt({'icon': get_country_flag(group)})
                cm = [('Clear Cache', 'RunPlugin({0}?action=clear_cache)'.format(BASE_URL))]
                li.addContextMenuItems(cm)
                url = "{0}?mode=1&action=list_channels&group={1}".format(BASE_URL, urllib.parse.quote_plus(group))
                xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
    except:
        pass
    xbmcplugin.endOfDirectory(HANDLE)

def list_channels_oha(group_enc):
    provider = get_oha_provider()
    headers = get_oha_headers()
    group = urllib.parse.unquote_plus(group_enc)
    cursor = None
    all_channels = []
    while True:
        payload = {
            "language": "de", "region": "XX", "catalogId": "iptv", "id": "iptv",
            "adult": False, "search": "", "sort": "", "filter": {"group": group},
            "cursor": cursor, "clientVersion": "3.0.2"
        }
        try:
            r = requests.post(provider['catalog_url'], headers=headers, json=payload, timeout=30)
            if r.status_code != 200: break
            data = r.json()
            for item in data.get('items', []):
                vid = item.get('ids', {}).get('id')
                if vid:
                    name = clean_name(item.get('name', 'Unbekannt'))
                    all_channels.append({
                        'name': name, 'vid': vid, 'is_fav': is_tv_favorite(name, '1'),
                        'icon': item.get('image') or item.get('icon')
                    })
            cursor = data.get('nextCursor')
            if not cursor: break
        except:
            break
    
    for ch in sorted([c for c in all_channels if c['is_fav']], key=lambda x: x['name']):
        li, url = create_channel_item(ch['name'], ch['vid'], '1', is_fav=True, icon=ch['icon'])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)
    for ch in sorted([c for c in all_channels if not c['is_fav']], key=lambda x: x['name']):
        li, url = create_channel_item(ch['name'], ch['vid'], '1', is_fav=False, icon=ch['icon'])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def list_groups_vavoo():
    try:
        r = requests.get("http://vavoo.to/channels", headers={'User-Agent': 'VAVOO/2.6'}, timeout=10)
        countries = sort_germany_first(list(set(c.get('country') for c in r.json() if c.get('country'))))
        add_tv_favorites_entry()
        for country in countries:
            li = xbmcgui.ListItem(label=country)
            li.setArt({'icon': get_country_flag(country)})
            cm = [('Clear Cache', 'RunPlugin({0}?action=clear_cache)'.format(BASE_URL))]
            li.addContextMenuItems(cm)
            url = "{0}?mode=0&action=list_channels&country={1}".format(BASE_URL, urllib.parse.quote_plus(country))
            xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
    except:
        pass
    xbmcplugin.endOfDirectory(HANDLE)

def list_channels_vavoo(country_enc):
    country = urllib.parse.unquote_plus(country_enc)
    all_channels = []
    try:
        r = requests.get("http://vavoo.to/channels", headers={'User-Agent': 'VAVOO/2.6'}, timeout=10)
        for ch in r.json():
            if ch.get('country') == country:
                name = clean_name(ch.get('name'))
                all_channels.append({'name': name, 'vid': ch.get('id'), 'is_fav': is_tv_favorite(name, '0'), 'icon': None})
    except:
        pass
    for ch in sorted([c for c in all_channels if c['is_fav']], key=lambda x: x['name']):
        li, url = create_channel_item(ch['name'], ch['vid'], '0', is_fav=True, icon=None)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)
    for ch in sorted([c for c in all_channels if not c['is_fav']], key=lambda x: x['name']):
        li, url = create_channel_item(ch['name'], ch['vid'], '0', is_fav=False, icon=None)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_item(vid, mode):
    if str(mode) == '1':
        provider = get_oha_provider()
        stream_url = provider['play_url'].format(vid)
        agent = "MediaHubMX/2"
    elif str(mode) == '2':
        stream_url = "https://vavoo.to/vavoo-iptv/play/{0}".format(vid)
        agent = "MediaHubMX/2"
    else:
        stream_url = "https://vavoo.to/play/{0}/index.m3u8".format(vid)
        agent = "VAVOO/2.6"
    
    if not test_stream_url(stream_url, {'User-Agent': agent}):
        fail_count = increment_fail_counter()
        if fail_count >= 3:
            new_source_name = switch_to_next_fallback()
            xbmcgui.Dialog().ok("Stream-Quelle gewechselt", "Zu {0} gewechselt. Bitte erneut versuchen.".format(new_source_name))
            xbmc.executebuiltin("Action(Back)")
        else:
            xbmcgui.Dialog().notification("Stream nicht verfügbar", "Fehler {0}/3".format(fail_count), xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    reset_fail_counter()
    li = xbmcgui.ListItem(path=stream_url)
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent=' + agent)
    li.setMimeType('application/vnd.apple.mpegurl')
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    m = params.get('mode', SETTING_MODE)
    
    if action == 'clear_cache': clear_cache()
    elif action == 'show_all_favorites': show_all_tv_favorites()
    elif action == 'add_fav':
        add_tv_favorite(urllib.parse.unquote_plus(params.get('name', '')), params.get('id', ''), params.get('mode', m))
    elif action == 'remove_fav':
        remove_tv_favorite(urllib.parse.unquote_plus(params.get('name', '')), params.get('mode', m))
    elif str(m) == '2':
        if action == 'list_channels': list_channels_github(params.get('group', ''))
        elif action == 'play': play_item(params.get('id'), '2')
        else: list_groups_github()
    elif str(m) == '1':
        if action == 'list_channels': list_channels_oha(params.get('group', ''))
        elif action == 'play': play_item(params.get('id'), '1')
        else: list_groups_oha()
    else:
        if action == 'list_channels': list_channels_vavoo(params.get('country', ''))
        elif action == 'play': play_item(params.get('id'), '0')
        else: list_groups_vavoo()
