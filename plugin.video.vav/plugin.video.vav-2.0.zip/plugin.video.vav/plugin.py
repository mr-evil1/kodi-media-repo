# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import urllib.parse
import requests
import json
import os

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
SETTING_MODE = ADDON.getSetting('mode') or '0'
ADDON_PATH = ADDON.getAddonInfo('path')

OHA_URL = "http://vavoo.to/mediahubmx-catalog.json"
OHA_HEADERS = {
    'User-Agent': 'MediaHubMX/2',
    'Content-Type': 'application/json; charset=utf-8',
    'mediahubmx-signature':'eyJkYXRhIjoie1widGltZVwiOjE5Njk0NTY5MDI2OTYsXCJ2YWxpZFVudGlsXCI6NTc2OTQ1NzkwMDAwMCxcInVzZXJcIjpcIlN6SE9icmlkdDlDOHBXSG0rZVFMLzJYaDNSN3JqUm1ISTlPdFlqRWNHenM9XCIsXCJzdGF0dXNcIjpcImd1ZXN0XCIsXCJ2ZXJpZmllZFwiOmZhbHNlLFwiaXBzXCI6W1wiMTc3LjEyMi4yNTIuMTY5XCJdLFwiYXBwXCI6e1wibmFtZVwiOlwiRGV6b3JcIixcInZlcnNpb25cIjpcIjEuMS4yXCIsXCJwbGF0Zm9ybVwiOlwiYW5kcm9pZFwiLFwib2tcIjp0cnVlfX0iLCJzaWduYXR1cmUiOiJKcUk4TDRGV3lIb1Z0MGZjM29lVllPWHgxTXFncDRVRlMwcEwvVFVwcmFkSnJBRldEUmM2ZS8waEEwVmdUYmpCYldGdGVqWU9CNEFWOTZQcEltSmZrbG5zNVNvNnNNMDFpWk5rb29rc2kxUmFxeWFzb0xYa1kxQmFKdUdOb3RjdU81cnYvVmpUbkRGRUdJcnRxcHNPMGcwZnBNUXVXS0FLNGF6OFg3R2Flcnc9In0=',
    'Accept-Encoding': 'gzip',
    'Connection': 'keep-alive',
    'Host': 'vavoo.to'
}

COUNTRY_FLAGS = {
    'Albania': 'al.png',
    'Arabia': 'ae.png',
    'Azerbaijan': 'az.png',
    'Balkans': 'yu.png',
    'Belgium': 'be.png',
    'Bulgaria': 'bg.png',
    'Croatia': 'yu.png',
    'Denmark': 'dk.png',
    'France': 'fr.png',
    'Germany': 'de.png',
    'Greece': 'gr.png',
    'Iran': 'ir.png',
    'Italy': 'it.png',
    'Netherlands': 'nl.png',
    'Poland': 'pl.png',
    'Portugal': 'pt.png',
    'Romania': 'ro.png',
    'Russia': 'ru.png',
    'Spain': 'es.png',
    'Sweden': 'se.png',
    'Turkey': 'tr.png',
    'UK': 'gb.png',
    'United Kingdom': 'gb.png'
}

def get_country_flag(group_name):
    for country, flag_file in COUNTRY_FLAGS.items():
        if group_name.startswith(country):
            flag_path = os.path.join(ADDON_PATH, 'resources', 'country', flag_file)
            if os.path.exists(flag_path):
                return flag_path
    return 'DefaultFolder.png'

def get_fail_counter():
    return int(ADDON.getSetting('fail_counter') or '0')

def increment_fail_counter():
    current = get_fail_counter()
    current += 1
    ADDON.setSetting('fail_counter', str(current))
    xbmc.log("FALLBACK: Fail Counter = {0}/3".format(current), xbmc.LOGWARNING)
    return current

def reset_fail_counter():
    ADDON.setSetting('fail_counter', '0')
    xbmc.log("FALLBACK: Counter zurückgesetzt", xbmc.LOGINFO)

def switch_mode():
    current_mode = ADDON.getSetting('mode') or '0'
    new_mode = '1' if current_mode == '0' else '0'
    
    ADDON.setSetting('mode', new_mode)
    reset_fail_counter()
    
    mode_name = 'VAVOO2' if new_mode == '1' else 'VAVOO'
    source_name = 'VAVOO' if current_mode == '0' else 'VAVOO2'
    
    xbmc.log("FALLBACK: Wechsel von {0} zu {1}".format(source_name, mode_name), xbmc.LOGWARNING)
    
    return mode_name

def get_oha_filters():
    payload = {
        "language": "de",
        "region": "XX",
        "catalogId": "iptv",
        "id": "iptv",
        "adult": False,
        "search": "",
        "sort": "",
        "filter": {},
        "cursor": None,
        "clientVersion": "3.0.2"
    }
    
    try:
        xbmc.log("VAVOO: Lade Gruppen...", xbmc.LOGINFO)
        
        response = requests.post(
            OHA_URL, 
            headers=OHA_HEADERS, 
            json=payload, 
            timeout=15,
            stream=True
        )
        
        if response.status_code == 200:
            chunks = []
            for chunk in response.iter_content(chunk_size=8192, decode_unicode=False):
                if chunk:
                    chunks.append(chunk)
            
            content = b''.join(chunks).decode('utf-8')
            data = json.loads(content)
            
            groups = []
            for f in data.get('features', {}).get('filter', []):
                if f.get('id') == 'group':
                    for opt in f.get('values', []):
                        groups.append(opt)
                    break
            
            germany_groups = [g for g in groups if g.startswith('Germany')]
            other_groups = [g for g in groups if not g.startswith('Germany')]
            
            sorted_groups = sorted(germany_groups) + sorted(other_groups)
            
            xbmc.log("VAVOO: {0} Gruppen gefunden".format(len(sorted_groups)), xbmc.LOGINFO)
            return sorted_groups
            
    except Exception as e:
        xbmc.log("VAVOO: Fehler - " + str(e), xbmc.LOGERROR)
    
    return []

def get_oha_channels(group):
    payload = {
        "language": "de",
        "region": "XX",
        "catalogId": "iptv",
        "id": "iptv",
        "adult": False,
        "search": "",
        "sort": "",
        "filter": {"group": group},
        "cursor": None,
        "clientVersion": "3.0.2"
    }
    
    try:
        xbmc.log("VAVOO: Lade Channels für " + group, xbmc.LOGINFO)
        
        response = requests.post(
            OHA_URL, 
            headers=OHA_HEADERS, 
            json=payload, 
            timeout=30,
            stream=True
        )
        
        if response.status_code == 200:
            chunks = []
            for chunk in response.iter_content(chunk_size=8192, decode_unicode=False):
                if chunk:
                    chunks.append(chunk)
            
            content = b''.join(chunks).decode('utf-8')
            data = json.loads(content)
            
            items = data.get('items', [])
            xbmc.log("VAVOO: {0} Channels geladen".format(len(items)), xbmc.LOGINFO)
            return items
            
    except Exception as e:
        xbmc.log("VAVOO: Fehler - " + str(e), xbmc.LOGERROR)
    
    return []

def list_groups_oha():
    groups = get_oha_filters()
    
    if not groups:
        xbmcgui.Dialog().notification("VAVOO", "Keine Gruppen gefunden", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    
    for group in groups:
        li = xbmcgui.ListItem(label=group)
        
        flag_path = get_country_flag(group)
        li.setArt({'icon': flag_path, 'thumb': flag_path})
        
        url = "{0}?mode=1&action=list_channels&group={1}".format(
            BASE_URL, 
            urllib.parse.quote_plus(group)
        )
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_channels_oha(group_enc):
    group = urllib.parse.unquote_plus(group_enc)
    
    dialog = xbmcgui.DialogProgress()
    dialog.create("VAVOO", "Lade Sender: " + group)
    
    channels = get_oha_channels(group)
    
    dialog.close()
    
    if not channels:
        xbmcgui.Dialog().notification("VAVOO", "Keine Sender gefunden", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    
    for item in channels:
        name = item.get('name', 'Unbenannt')
        vid = item.get('ids', {}).get('id')
        
        if not vid:
            continue
        
        li = xbmcgui.ListItem(label=name)
        
        img = item.get('image') or item.get('icon')
        if img:
            li.setArt({'thumb': img, 'icon': img})
        
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': name})
        
        url = "{0}?mode=1&action=play&id={1}".format(BASE_URL, vid)
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def list_groups_vavoo():
    try:
        r = requests.get("http://vavoo.to/channels", headers={'User-Agent': 'VAVOO/2.6'}, timeout=10)
        data = r.json()
        
        countries = list(set(c.get('country') for c in data if c.get('country')))
        
        germany_countries = [c for c in countries if c.startswith('Germany')]
        other_countries = [c for c in countries if not c.startswith('Germany')]
        
        sorted_countries = sorted(germany_countries) + sorted(other_countries)
        
        for country in sorted_countries:
            li = xbmcgui.ListItem(label=country)
            
            flag_path = get_country_flag(country)
            li.setArt({'icon': flag_path, 'thumb': flag_path})
            
            url = "{0}?mode=0&action=list_channels&country={1}".format(
                BASE_URL, 
                urllib.parse.quote_plus(country)
            )
            xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
    except:
        pass
    
    xbmcplugin.endOfDirectory(HANDLE)

def list_channels_vavoo(country_enc):
    country = urllib.parse.unquote_plus(country_enc)
    try:
        r = requests.get("http://vavoo.to/channels", headers={'User-Agent': 'VAVOO/2.6'}, timeout=10)
        for ch in r.json():
            if ch.get('country') == country:
                li = xbmcgui.ListItem(label=ch.get('name'))
                li.setProperty('IsPlayable', 'true')
                url = "{0}?mode=0&action=play&id={1}".format(BASE_URL, ch.get('id'))
                xbmcplugin.addDirectoryItem(HANDLE, url, li, False)
    except:
        pass
    
    xbmcplugin.endOfDirectory(HANDLE)

def test_stream_url(stream_url, headers):
    try:
        response = requests.head(stream_url, headers=headers, timeout=5, allow_redirects=True)
        if response.status_code in [200, 302, 301]:
            return True
    except:
        pass
    return False

def play_item(vid, mode):
    if str(mode) == '1':
        stream_url = "https://vavoo.to/vavoo-iptv/play/{0}".format(vid)
        agent = "MediaHubMX/2"
    else:
        stream_url = "https://vavoo.to/play/{0}/index.m3u8".format(vid)
        agent = "VAVOO/2.6"
    
    xbmc.log("PLAYER: Teste Stream {0} (Mode {1})".format(stream_url, mode), xbmc.LOGINFO)
    
    stream_ok = test_stream_url(stream_url, {'User-Agent': agent})
    
    if not stream_ok:
        xbmc.log("PLAYER: Stream nicht erreichbar", xbmc.LOGWARNING)
        
        fail_count = increment_fail_counter()
        
        if fail_count >= 3:
            new_mode_name = switch_mode()
            
            xbmcgui.Dialog().ok(
                "Stream-Quelle gewechselt",
                "Nach 3 Fehlversuchen wurde automatisch zu {0} gewechselt.".format(new_mode_name))
            xbmc.sleep(2000)
            
            xbmc.executebuiltin("Action(Back)")
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            sys.exit()
            xbmc.executebuiltin("ActivateWindow(Home)")
            
        else:
            xbmcgui.Dialog().notification(
                "Stream nicht verfügbar",
                "Fehler {0}/3 - Versuchen Sie einen anderen Sender".format(fail_count),
                xbmcgui.NOTIFICATION_WARNING,
                3000
            )
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
    
    xbmc.log("PLAYER: Stream OK - Starte Wiedergabe", xbmc.LOGINFO)
    reset_fail_counter()
    
    li = xbmcgui.ListItem(path=stream_url)
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent=' + agent)
    
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    m = params.get('mode', SETTING_MODE)

    if str(m) == '1':
        if action == 'list_channels':
            list_channels_oha(params.get('group', ''))
        elif action == 'play':
            play_item(params.get('id'), '1')
        else:
            list_groups_oha()
    else:
        if action == 'list_channels':
            list_channels_vavoo(params.get('country', ''))
        elif action == 'play':
            play_item(params.get('id'), '0')
        else:
            list_groups_vavoo()