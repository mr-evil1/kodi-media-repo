import sys
import urllib.parse
import xbmcplugin
import xbmcgui
import xbmcaddon
import requests
import re
import os

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]

remote_json_url = 'https://www2.vavoo.to/live2/index?output=json'

LIVE_GROUP_ALIASES = (
    (1, 'Germany', 'Deutschland', 'special://home/addons/plugin.video.vav/resources/country/de.png', None),
    (2, 'Turkey', 'Türkei', 'special://home/addons/plugin.video.vav/resources/country/tr.png', None),
    (3, 'Denmark', 'Dänemark', 'special://home/addons/plugin.video.vav/resources/country/dk.png', None),
    (4, 'Sports International', 'Sport International', 'special://home/addons/plugin.video.vav/resources/country/eu.png', None),
    (99999, 'Albania', 'Albanien', 'special://home/addons/plugin.video.vav/resources/country/al.png', None),
    (99999, 'Arabia', 'Arabisch', 'special://home/addons/plugin.video.vav/resources/country/ae.png', None),
    (99999, 'Azerbaijan', 'Azerbaijan', 'special://home/addons/plugin.video.vav/resources/country/az.png', None),
    (99999, 'Bulgaria', 'Bulgarien', 'special://home/addons/plugin.video.vav/resources/country/bg.png', None),
    (99999, 'France', 'Frankreich', 'special://home/addons/plugin.video.vav/resources/country/fr.png', None),
    (99999, 'Netherlands', 'Niederlande', 'special://home/addons/plugin.video.vav/resources/country/nl.png', None),
    (99999, 'Poland', 'Polen', 'special://home/addons/plugin.video.vav/resources/country/pl.png', None),
    (99999, 'Romania', 'Rumänien', 'special://home/addons/plugin.video.vav/resources/country/ro.png', None),
    (99999, 'Portugal', 'Portugal', 'special://home/addons/plugin.video.vav/resources/country/pt.png', None),
    (99999, 'Italy', 'Italien', 'special://home/addons/plugin.video.vav/resources/country/it.png', None),
    (99999, 'Belgium', 'Belgien', 'special://home/addons/plugin.video.vav/resources/country/be.png', None),
    (99999, 'United Kingdom', 'England', 'special://home/addons/plugin.video.vav/resources/country/gb.png', None),
    (99999, 'Greece', 'Griechenland', 'special://home/addons/plugin.video.vav/resources/country/gr.png', None),
    (99999, 'Russia', 'Russland', 'special://home/addons/plugin.video.vav/resources/country/ru.png', None),
    (99999, 'Spain', 'Spanien', 'special://home/addons/plugin.video.vav/resources/country/es.png', None),
    (99999, 'Sweden', 'Schweden', 'special://home/addons/plugin.video.vav/resources/country/se.png', None),
    (99999, 'Iran', 'Iran', 'special://home/addons/plugin.video.vav/resources/country/ir.png', None),
    (99999, 'Balkans', 'Balkans', 'special://home/addons/plugin.video.vav/resources/yu.png', None),
)

def clean_unused_logos():
    keep_files = set()
    for _, _, _, path, _ in LIVE_GROUP_ALIASES:
        if path:
            keep_files.add(os.path.basename(path))

    resource_dir = xbmc.translatePath('special://home/addons/plugin.video.vav/resources/country')
    if not os.path.exists(resource_dir):
        return
    for file in os.listdir(resource_dir):
        if file.endswith('.png') and file not in keep_files:
            try:
                os.remove(os.path.join(resource_dir, file))
            except:
                pass

#clean_unused_logos()

def get_group_logo(group):
    for _, en, de, path, _ in LIVE_GROUP_ALIASES:
        if group.lower() in (en.lower(), de.lower()):
            return path
    return ''

def get_sorted_groups(all_groups):
    order = []
    seen = set()
    for _, en, de, _, _ in LIVE_GROUP_ALIASES:
        for g in all_groups:
            if g.lower() == en.lower() or g.lower() == de.lower():
                if g not in seen:
                    order.append(g)
                    seen.add(g)
    for g in all_groups:
        if g not in seen:
            order.append(g)
    return order

def load_channels():
    try:
        response = requests.get(remote_json_url, timeout=10)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        xbmcgui.Dialog().notification('Fehler beim Laden', str(e), xbmcgui.NOTIFICATION_ERROR)
        return []

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def list_groups():
    data = load_channels()
    raw_groups = set(item.get('group', 'Ungrouped') for item in data)
    groups = get_sorted_groups(raw_groups)
    for group in groups:
        url = build_url({'mode': 'list_channels', 'group': group})
        li = xbmcgui.ListItem(label=group)
        logo = get_group_logo(group)
        if logo:
            li.setArt({'thumb': logo, 'icon': logo, 'fanart': logo})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def list_channels(group):
    data = load_channels()
    for c in data:
        if c.get('group') != group:
            continue
        match = re.search(r'/play/(\d+)', c.get('url', ''))
        if not match:
            continue
        channel_id = match.group(1)
        url = build_url({'mode': 'play', 'id': channel_id})
        li = xbmcgui.ListItem(label=c.get('name', 'Unbenannt'))
        logo = c.get('logo') or ''
        li.setArt({'thumb': logo, 'icon': logo, 'fanart': logo})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def play_stream(channel_id):
    m3u8_url = f'https://metvmetvmetv7.serv00.net/vavame.php?id={channel_id}&e=.m3u8'
    try:
        response = requests.get(m3u8_url, timeout=15)
        response.raise_for_status()
        playlist = response.text
        stream_lines = []
        lines = playlist.strip().splitlines()
        for i in range(len(lines)):
            if lines[i].startswith("#EXT-X-STREAM-INF") and i + 1 < len(lines):
                stream_lines.append(lines[i + 1])

        if stream_lines:
            dialog = xbmcgui.Dialog()
            choices = [f"Stream {i+1}: {url}" for i, url in enumerate(stream_lines)]
            index = dialog.select("Wähle einen Stream", choices)
            if index >= 0:
                selected_url = stream_lines[index]
                li = xbmcgui.ListItem(path=selected_url)
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)
        else:
            li = xbmcgui.ListItem(path=m3u8_url)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)

    except Exception as e:
        xbmcgui.Dialog().notification('Fehler beim Abspielen', str(e), xbmcgui.NOTIFICATION_ERROR)



params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
mode = params.get('mode')

if mode == 'list_channels':
    list_channels(params['group'])
elif mode == 'play':
    
    play_stream(params['id'])
else:
    list_groups()