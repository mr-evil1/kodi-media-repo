#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
import uuid
import time
import gzip
import json
import threading
import urllib.parse

import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import requests

addon        = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url     = sys.argv[0]

ADDON_DATA  = xbmcvfs.translatePath("special://userdata/addon_data/plugin.video.vav/")
CACHE_FILE  = os.path.join(ADDON_DATA, "catalog_cache.json")
FAV_FILE    = os.path.join(ADDON_DATA, "favourites.json")
ORDER_FILE  = os.path.join(ADDON_DATA, "country_order.json")

os.makedirs(ADDON_DATA, exist_ok=True)

PING_URLS  = [
    "https://www.lokke.app/api/app/ping",
    "https://www.vavoo.tv/api/app/ping",
]
BASE_SITES  = ["https://vavoo.to", "https://kool.to"]
BROWSER_UA  = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
               "AppleWebKit/537.36 (KHTML, like Gecko) "
               "Chrome/124.0.0.0 Safari/537.36")
MEDIAHUB_UA = "MediaHubMX/2"
PING_HEADERS = {"accept": "*/*", "user-agent": BROWSER_UA,
                "Accept-Encoding": "gzip, deflate", "Connection": "close"}
CATALOG_TTL = 3600
SIG_TTL     = 480

COUNTRY_LOGOS = {
    "albania":              "special://home/addons/plugin.video.vav/resources/country/al.png",
    "arabia":               "special://home/addons/plugin.video.vav/resources/country/ae.png",
    "azerbaijan":           "special://home/addons/plugin.video.vav/resources/country/az.png",
    "balkans":              "special://home/addons/plugin.video.vav/resources/country/yu.png",
    "belgium":              "special://home/addons/plugin.video.vav/resources/country/be.png",
    "bulgaria":             "special://home/addons/plugin.video.vav/resources/country/bg.png",
    "croatia":              "special://home/addons/plugin.video.vav/resources/country/hr.png",
    "denmark":              "special://home/addons/plugin.video.vav/resources/country/dk.png",
    "france":               "special://home/addons/plugin.video.vav/resources/country/fr.png",
    "germany":              "special://home/addons/plugin.video.vav/resources/country/de.png",
    "greece":               "special://home/addons/plugin.video.vav/resources/country/gr.png",
    "iran":                 "special://home/addons/plugin.video.vav/resources/country/ir.png",
    "italy":                "special://home/addons/plugin.video.vav/resources/country/it.png",
    "netherlands":          "special://home/addons/plugin.video.vav/resources/country/nl.png",
    "poland":               "special://home/addons/plugin.video.vav/resources/country/pl.png",
    "portugal":             "special://home/addons/plugin.video.vav/resources/country/pt.png",
    "romania":              "special://home/addons/plugin.video.vav/resources/country/ro.png",
    "russia":               "special://home/addons/plugin.video.vav/resources/country/ru.png",
    "spain":                "special://home/addons/plugin.video.vav/resources/country/es.png",
    "sports international": "special://home/addons/plugin.video.vav/resources/country/eu.png",
    "sweden":               "special://home/addons/plugin.video.vav/resources/country/se.png",
    "turkey":               "special://home/addons/plugin.video.vav/resources/country/tr.png",
    "united kingdom":       "special://home/addons/plugin.video.vav/resources/country/gb.png",
}

DEFAULT_COUNTRY_ORDER = [
    "Germany", "Turkey", "Denmark", "Sports International",
    "United Kingdom", "France", "Italy", "Spain", "Portugal",
    "Netherlands", "Poland", "Romania", "Bulgaria", "Russia",
    "Greece", "Sweden", "Belgium", "Albania", "Arabia",
    "Azerbaijan", "Balkans", "Croatia", "Iran",
]

_SEPARATORS = ["=>", "->", "|"]
_SEPARATORS_UNI = ["\u27be", "\u27fe", "\u2192", "\u00bb", "\u203a"]

_sig_cache = {"sig": None, "ts": 0}
_sig_lock  = threading.Lock()
_base_idx  = [0]


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log("[plugin.video.vav] " + str(msg), level)

def _build_url(q):
    return base_url + "?" + urllib.parse.urlencode(q)

def _current_base():
    return BASE_SITES[_base_idx[0] % len(BASE_SITES)]

def _switch_base():
    _base_idx[0] += 1

def _decode(resp):
    raw = resp.content
    try:
        raw = gzip.decompress(raw)
    except Exception:
        pass
    return json.loads(raw.decode("utf-8", errors="replace"))

def _extract_country(group_str):
    s = (group_str or "").strip()
    for sep in _SEPARATORS_UNI + _SEPARATORS:
        if sep in s:
            s = s.split(sep)[0].strip()
            break
    return s or "Other"

def _clean_logo(url):
    if not url:
        return ""
    if "logo.huhu.to" in url:
        return ""
    return url

def _notify(msg, error=False):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification("VAVOO", msg, icon, 3000)

def _refresh_container():
    xbmc.executebuiltin("Container.Refresh")


def _load_order():
    try:
        with open(ORDER_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list) and data:
            return data
    except Exception:
        pass
    return list(DEFAULT_COUNTRY_ORDER)

def _save_order(order):
    try:
        with open(ORDER_FILE, "w", encoding="utf-8") as f:
            json.dump(order, f, ensure_ascii=False, indent=2)
    except Exception as e:
        _log("Order save: " + str(e), xbmc.LOGWARNING)

def _sorted_countries(countries):
    order = _load_order()
    out, seen = [], set()
    for name in order:
        for c in countries:
            if c.lower() == name.lower() and c not in seen:
                out.append(c)
                seen.add(c)
    for c in sorted(countries):
        if c not in seen:
            out.append(c)
    return out

def _move_country(country, direction):
    channels = _get_catalog()
    all_ctry = list(set(ch["country"] for ch in channels))
    order    = _sorted_countries(all_ctry)
    if country not in order:
        order.append(country)
    idx = order.index(country)
    if direction == "up"     and idx > 0:
        order[idx], order[idx - 1] = order[idx - 1], order[idx]
    elif direction == "down" and idx < len(order) - 1:
        order[idx], order[idx + 1] = order[idx + 1], order[idx]
    elif direction == "top":
        order.insert(0, order.pop(idx))
    elif direction == "bottom":
        order.append(order.pop(idx))
    _save_order(order)
    _refresh_container()

def _reset_order():
    try:
        os.remove(ORDER_FILE)
    except Exception:
        pass
    _refresh_container()


def _load_favs():
    try:
        with open(FAV_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def _save_favs(favs):
    try:
        with open(FAV_FILE, "w", encoding="utf-8") as f:
            json.dump(favs, f, ensure_ascii=False, indent=2)
    except Exception as e:
        _log("Fav save: " + str(e), xbmc.LOGWARNING)

def _fav_exists(ch_id):
    return any(f["id"] == ch_id for f in _load_favs())

def _add_fav(ch):
    favs = _load_favs()
    if not _fav_exists(ch["id"]):
        favs.append({"id": ch["id"], "name": ch["name"],
                     "url": ch["url"], "logo": ch.get("logo", "")})
        _save_favs(favs)
        _notify('"%s" zu VAV Favoriten hinzugefuegt' % ch["name"])

def _remove_fav(ch_id):
    _save_favs([f for f in _load_favs() if f["id"] != ch_id])
    _notify("Aus VAV Favoriten entfernt")
    _refresh_container()

def _rename_fav(ch_id):
    favs  = _load_favs()
    entry = next((f for f in favs if f["id"] == ch_id), None)
    if not entry:
        return
    kb = xbmc.Keyboard(entry["name"], "Neuer Name")
    kb.doModal()
    if kb.isConfirmed():
        new_name = kb.getText().strip()
        if new_name:
            entry["name"] = new_name
            _save_favs(favs)
            _notify('Umbenannt zu "%s"' % new_name)
            _refresh_container()

def _move_fav(ch_id, direction):
    favs = _load_favs()
    idx  = next((i for i, f in enumerate(favs) if f["id"] == ch_id), None)
    if idx is None:
        return
    if direction == "up"     and idx > 0:
        favs[idx], favs[idx - 1] = favs[idx - 1], favs[idx]
    elif direction == "down" and idx < len(favs) - 1:
        favs[idx], favs[idx + 1] = favs[idx + 1], favs[idx]
    elif direction == "top":
        favs.insert(0, favs.pop(idx))
    elif direction == "bottom":
        favs.append(favs.pop(idx))
    _save_favs(favs)
    _refresh_container()


def _get_sig(force=False):
    with _sig_lock:
        now = time.time()
        if not force and _sig_cache["sig"] and (now - _sig_cache["ts"]) < SIG_TTL:
            return _sig_cache["sig"]
    uid = str(uuid.uuid4())
    ts  = int(time.time() * 1000)
    payload = {
        "reason": "app-focus", "locale": "en", "theme": "dark",
        "metadata": {
            "device":  {"type": "desktop", "uniqueId": uid},
            "os":      {"name": "win32", "version": "Windows 10 Pro",
                        "abis": ["x64"], "host": "Lenovo"},
            "app":     {"platform": "electron"},
            "version": {"package": "tv.vavoo.app", "binary": "3.1.8", "js": "3.1.8"},
        },
        "appFocusTime": 0, "playerActive": False, "playDuration": 0,
        "devMode": False, "hasAddon": True, "castConnected": False,
        "package": "tv.vavoo.app", "version": "3.1.8", "process": "app",
        "firstAppStart": ts, "lastAppStart": ts, "ipLocation": None,
        "adblockEnabled": True,
        "proxy": {"supported": ["ss"], "engine": "Mu",
                  "enabled": False, "autoServer": True},
        "iap": {"supported": False},
    }
    sig = None
    for url in PING_URLS:
        try:
            r = requests.post(url, json=payload, headers=PING_HEADERS,
                              timeout=15, verify=False)
            r.raise_for_status()
            sig = _decode(r).get("addonSig")
            if sig:
                break
        except Exception as e:
            _log("Ping %s: %s" % (url, e), xbmc.LOGWARNING)
    if sig:
        with _sig_lock:
            _sig_cache["sig"] = sig
            _sig_cache["ts"]  = time.time()
    return sig


def _save_catalog(channels):
    try:
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump({"ts": time.time(), "channels": channels}, f)
    except Exception as e:
        _log("Cache write: " + str(e), xbmc.LOGWARNING)

def _load_catalog_cache():
    try:
        with open(CACHE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if time.time() - data.get("ts", 0) < CATALOG_TTL:
            return data["channels"]
    except Exception:
        pass
    return None

MAX_PAGES = 60

def _fetch_catalog(sig, pd=None):
    channels, cursor, page = [], None, 0
    base, mirror_tried = _current_base(), False

    first_pass_pages = None

    while True:
        page += 1
        headers = {
            "content-type":         "application/json; charset=utf-8",
            "mediahubmx-signature": sig,
            "user-agent":           MEDIAHUB_UA,
            "accept":               "*/*",
            "Accept-Language":      "en",
            "Accept-Encoding":      "gzip, deflate",
            "Connection":           "close",
        }
        payload = {
            "language": "en", "region": "US",
            "catalogId": "iptv", "id": "iptv",
            "adult": False, "search": "", "sort": "", "filter": {},
            "cursor": cursor, "clientVersion": "3.0.2",
        }
        try:
            r = requests.post(base + "/mediahubmx-catalog.json",
                              json=payload, headers=headers,
                              timeout=30, verify=False)
            if r.status_code == 451 and not mirror_tried:
                _switch_base()
                base = _current_base()
                mirror_tried = True
                page -= 1
                continue
            r.raise_for_status()
            data = _decode(r)
        except Exception as e:
            _log("Catalog p%d: %s" % (page, e), xbmc.LOGWARNING)
            break

        items = data.get("items", [])
        if not items:
            break

        if first_pass_pages is None:
            total_items = data.get("totalCount") or data.get("total") or 0
            items_per_page = len(items) if items else 1
            first_pass_pages = max(1, int(total_items / items_per_page)) if total_items else MAX_PAGES

        for item in items:
            if item.get("type") != "iptv":
                continue
            group = item.get("group", "")
            ids   = item.get("ids") or {}
            ch_id = ids.get("id") or item.get("id", "")
            channels.append({
                "id":      ch_id,
                "name":    item.get("name") or item.get("title", "Unbekannt"),
                "url":     item.get("url", ""),
                "logo":    _clean_logo(item.get("logo") or item.get("artwork", "")),
                "country": _extract_country(group),
                "group":   group,
            })

        if pd is not None:
            pct = min(99, int(page * 100 / first_pass_pages))
            pd.update(pct, "Lade Kanalliste... Seite %d  (%d Kanaele)" % (page, len(channels)))
            if pd.iscanceled():
                break

        cursor = data.get("nextCursor")
        if not cursor or page >= MAX_PAGES:
            break

    return channels

def _get_catalog():
    cached = _load_catalog_cache()
    if cached:
        return cached
    sig = _get_sig()
    if not sig:
        _notify("Kein Token – erneut versuchen", error=True)
        return []
    pd = xbmcgui.DialogProgress()
    pd.create("VAVOO", "Lade Kanalliste...")
    pd.update(0)
    channels = _fetch_catalog(sig, pd=pd)
    pd.update(100)
    pd.close()
    if channels:
        _save_catalog(channels)
    return channels


def _resolve(channel_url, sig):
    for attempt in range(2):
        headers = {
            "content-type":         "application/json; charset=utf-8",
            "mediahubmx-signature": sig,
            "user-agent":           MEDIAHUB_UA,
            "accept":               "*/*",
            "Accept-Language":      "en",
            "Accept-Encoding":      "gzip, deflate",
            "Connection":           "close",
        }
        payload = {"language": "en", "region": "US",
                   "url": channel_url, "clientVersion": "3.0.2"}
        try:
            r = requests.post(_current_base() + "/mediahubmx-resolve.json",
                              json=payload, headers=headers,
                              timeout=30, verify=False)
            if r.status_code == 451:
                _switch_base()
                continue
            r.raise_for_status()
            result = _decode(r)
            stream_url = None
            if isinstance(result, list) and result:
                stream_url = result[0].get("url")
            elif isinstance(result, dict):
                stream_url = result.get("url") or result.get("streamUrl")
            if stream_url:
                return stream_url
        except Exception as e:
            _log("Resolve %d: %s" % (attempt + 1, e), xbmc.LOGWARNING)
        if attempt == 0:
            sig = _get_sig(force=True)
            if not sig:
                break
    return None


def _make_channel_li(ch, context="channel"):
    li   = xbmcgui.ListItem(label=ch["name"])
    logo = ch.get("logo") or ""
    if logo:
        li.setArt({"thumb": logo, "icon": logo})
    li.setProperty("IsPlayable", "true")

    play_url = _build_url({"mode": "play",
                           "channel_url": ch["url"],
                           "channel_id":  ch["id"]})
    ctx = []

    if context == "fav":
        ctx += [
            ("Nach oben",
             "RunPlugin(%s)" % _build_url({"mode": "fav_move", "id": ch["id"], "dir": "up"})),
            ("Nach unten",
             "RunPlugin(%s)" % _build_url({"mode": "fav_move", "id": ch["id"], "dir": "down"})),
            ("Ganz nach oben",
             "RunPlugin(%s)" % _build_url({"mode": "fav_move", "id": ch["id"], "dir": "top"})),
            ("Ganz nach unten",
             "RunPlugin(%s)" % _build_url({"mode": "fav_move", "id": ch["id"], "dir": "bottom"})),
            ("Umbenennen",
             "RunPlugin(%s)" % _build_url({"mode": "fav_rename", "id": ch["id"]})),
            ("Aus VAV Favoriten entfernen",
             "RunPlugin(%s)" % _build_url({"mode": "fav_remove", "id": ch["id"]})),
        ]
    else:
        if _fav_exists(ch["id"]):
            ctx += [("Aus VAV Favoriten entfernen",
                     "RunPlugin(%s)" % _build_url({"mode": "fav_remove", "id": ch["id"]}))]
        else:
            ctx += [("Zu VAV Favoriten hinzufuegen",
                     "RunPlugin(%s)" % _build_url({"mode": "fav_add", "id": ch["id"]}))]

    li.addContextMenuItems(ctx)
    return li, play_url


def list_groups():
    channels = _get_catalog()
    if not channels:
        xbmcplugin.endOfDirectory(addon_handle)
        return

    fav_count = len(_load_favs())
    fav_label = "VAV Favoriten (%d)" % fav_count if fav_count else "VAV Favoriten"
    fav_icon  = "special://home/addons/plugin.video.vav/resources/favourites.png"
    li_fav = xbmcgui.ListItem(label=fav_label)
    li_fav.setArt({"thumb": fav_icon, "icon": fav_icon})
    xbmcplugin.addDirectoryItem(handle=addon_handle,
                                url=_build_url({"mode": "list_favs"}),
                                listitem=li_fav, isFolder=True)

    search_icon = "special://home/addons/plugin.video.vav/resources/search.png"
    li_search = xbmcgui.ListItem(label="Suche...")
    li_search.setArt({"thumb": search_icon, "icon": search_icon})
    xbmcplugin.addDirectoryItem(handle=addon_handle,
                                url=_build_url({"mode": "search"}),
                                listitem=li_search, isFolder=True)

    countries = set(ch["country"] for ch in channels)
    for country in _sorted_countries(countries):
        li   = xbmcgui.ListItem(label=country)
        logo = COUNTRY_LOGOS.get(country.lower(), "")
        if logo:
            li.setArt({"thumb": logo, "icon": logo})
        ctx = [
            ("Nach oben",
             "RunPlugin(%s)" % _build_url({"mode": "ctry_move", "country": country, "dir": "up"})),
            ("Nach unten",
             "RunPlugin(%s)" % _build_url({"mode": "ctry_move", "country": country, "dir": "down"})),
            ("Ganz nach oben",
             "RunPlugin(%s)" % _build_url({"mode": "ctry_move", "country": country, "dir": "top"})),
            ("Ganz nach unten",
             "RunPlugin(%s)" % _build_url({"mode": "ctry_move", "country": country, "dir": "bottom"})),
            ("Reihenfolge zuruecksetzen",
             "RunPlugin(%s)" % _build_url({"mode": "ctry_reset"})),
        ]
        li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(handle=addon_handle,
                                    url=_build_url({"mode": "list_channels", "group": country}),
                                    listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


def list_channels(group):
    channels = _get_catalog()
    for ch in channels:
        if ch["country"].lower() != group.lower() or not ch.get("url"):
            continue
        li, url = _make_channel_li(ch, context="channel")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)


def list_favs():
    favs = _load_favs()
    if not favs:
        xbmcgui.Dialog().ok("VAV Favoriten", "Noch keine VAV Favoriten gespeichert.")
        xbmcplugin.endOfDirectory(addon_handle)
        return
    for fav in favs:
        li, url = _make_channel_li(fav, context="fav")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)


def do_search(query=None):
    if not query:
        kb = xbmc.Keyboard("", "Kanal suchen")
        kb.doModal()
        if not kb.isConfirmed():
            xbmcplugin.endOfDirectory(addon_handle)
            return
        query = kb.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(addon_handle)
        return
    channels = _get_catalog()
    q        = query.lower()
    found    = [ch for ch in channels
                if q in ch["name"].lower() or q in ch["country"].lower()]
    if not found:
        xbmcgui.Dialog().ok("Suche", 'Keine Ergebnisse fuer "%s".' % query)
        xbmcplugin.endOfDirectory(addon_handle)
        return
    country_order = _load_order()
    order_map     = {c.lower(): i for i, c in enumerate(country_order)}

    def _sort_key(ch):
        ctry_idx = order_map.get(ch["country"].lower(), len(country_order))
        return (ctry_idx, ch["name"].lower())

    found.sort(key=_sort_key)

    xbmcplugin.setPluginCategory(addon_handle, "Suche: " + query)
    for ch in found:
        li, url = _make_channel_li(ch, context="channel")
        li.setLabel("%s  [%s]" % (ch["name"], ch["country"]))
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)


def play_stream(channel_url, channel_id):
    sig = _get_sig()
    if not sig:
        _notify("Kein Token", error=True)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return
    stream_url = None
    max_attempts = 3
    for attempt in range(max_attempts):
        stream_url = _resolve(channel_url, sig)
        if stream_url:
            break
        if attempt < max_attempts - 1:
            xbmc.sleep(2000)
    if not stream_url:
        _notify("Stream konnte nicht aufgeloest werden", error=True)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return
    
    li = xbmcgui.ListItem(path=stream_url)
    li.setMimeType("application/x-mpegURL")
    li.setContentLookup(False)
    li.setProperty("inputstream",                                "inputstream.adaptive")
    li.setProperty("inputstream.adaptive.manifest_type",         "hls")
    li.setProperty("inputstream.adaptive.stream_headers",        "verifypeer=false")
    li.setProperty("inputstream.adaptive.manifest_headers",      "verifypeer=false")
    li.setProperty("inputstream.adaptive.license_flags",         "persistent_storage")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)


params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
mode   = params.get("mode", "")

if   mode == "list_channels":   list_channels(params.get("group", ""))
elif mode == "list_favs":        list_favs()
elif mode == "search":           do_search(params.get("query"))
elif mode == "play":             play_stream(params.get("channel_url", ""), params.get("channel_id", ""))
elif mode == "fav_add":          _add_fav(next((c for c in _get_catalog() if c["id"] == params.get("id", "")), {}))
elif mode == "fav_remove":       _remove_fav(params.get("id", ""))
elif mode == "fav_rename":       _rename_fav(params.get("id", ""))
elif mode == "fav_move":         _move_fav(params.get("id", ""), params.get("dir", "up"))
elif mode == "ctry_move":        _move_country(params.get("country", ""), params.get("dir", "up"))
elif mode == "ctry_reset":       _reset_order()
else:                            list_groups()
