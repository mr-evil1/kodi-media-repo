# -*- coding: utf-8 -*-
"""
MAC-/Stalker-Portal Client (eigene Implementierung, nur Standardbibliothek).

Spricht das oeffentlich bekannte Stalker-Middleware-Protokoll (portal.php / load.php):
Handshake -> Token -> Kanaele (itv), Filme (vod), Serien (series) -> create_link -> Stream-URL.
Funktioniert mit dem normalen MAG-Handshake und faellt bei Portalen ohne Handshake auf einen
Kompatibilitaetsmodus (MAC als URL-Parameter) zurueck.
"""
import gzip
import hashlib
import json
import random
import re
import string
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib

MAG_UA = ('Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 '
          '(KHTML, like Gecko) MAG250 stbapp ver: 2 rev: 250 Safari/533.3')
CHROME_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
             '(KHTML, like Gecko) Chrome/131.0 Safari/537.36')

ENDPOINTS = ('/portal.php', '/stalker_portal/server/load.php', '/server/load.php', '/load.php')
MAX_RESPONSE = 25 * 1024 * 1024

MAC_RE = re.compile(r'(?<![0-9A-Fa-f:])((?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2})(?![0-9A-Fa-f:])')
_URL_RE = re.compile(r'https?://[^\s<>"\']+', re.I)
_HOSTPORT_RE = re.compile(
    r'(?<![\w@/.\-])((?:[A-Za-z0-9\-]+\.)+[A-Za-z]{2,}:\d{2,5}(?:/[^\s<>"\']*)?'
    r'|\d{1,3}(?:\.\d{1,3}){3}:\d{2,5}(?:/[^\s<>"\']*)?)')
_SKIP_HOSTS = ('t.me', 'telegram.me', 'telegram.org', 'youtube.com', 'youtu.be', 'wikipedia.org')


class MacPortalError(Exception):
    pass


# ----------------------------------------------------------------------
# Erkennung in Texten (Telegram-Beitraege)
# ----------------------------------------------------------------------
def find_macs(text):
    seen, out = set(), []
    for m in MAC_RE.findall(text or ''):
        m = m.upper()
        if m not in seen:
            seen.add(m)
            out.append(m)
    return out


def find_portal(text, extra_urls=None):
    """Sucht in einem Beitrag Portal-URL + MAC-Adresse(n). -> (url, [macs]) oder None."""
    macs = find_macs(text)
    if not macs:
        return None
    panel_m = re.search(r'(?i)\bpanel\s*:\s*(https?://[^\s<>"\']+)', text or '')
    if panel_m:
        u = panel_m.group(1).strip().rstrip('.,;:!?)]}»')
        host = urllib.parse.urlparse(u).netloc.lower()
        if host and not any(host == h or host.endswith('.' + h) for h in _SKIP_HOSTS):
            if not re.search(r'(?i)\.m3u8?(?:[?&#]|$)|[?&](?:type|output)=m3u|/get\.php\?', u):
                return u, macs
    cands = [u for u in (extra_urls or []) if u]
    cands += _URL_RE.findall(text or '')
    cands += ['http://' + h for h in _HOSTPORT_RE.findall(text or '')]
    for u in cands:
        u = u.strip().rstrip('.,;:!?)]}»')
        host = urllib.parse.urlparse(u).netloc.lower()
        if not host or any(host == h or host.endswith('.' + h) for h in _SKIP_HOSTS):
            continue
        if re.search(r'(?i)\.m3u8?(?:[?&#]|$)|[?&](?:type|output)=m3u|/get\.php\?', u):
            continue
        return u, macs
    return None


# ----------------------------------------------------------------------
# Hilfsfunktionen
# ----------------------------------------------------------------------
def normalise_base(url):
    url = (url or '').strip()
    if not url.lower().startswith(('http://', 'https://')):
        url = 'http://' + url
    url = url.split('?')[0].split('#')[0].rstrip('/')
    for sfx in ('/stalker_portal/server/load.php', '/server/load.php', '/portal.php', '/load.php',
                '/stalker_portal/c', '/stalker_portal', '/c'):
        if url.lower().endswith(sfx):
            url = url[:-len(sfx)]
            break
    return url.rstrip('/')


def _http_get(url, headers, timeout):
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(MAX_RESPONSE)
        enc = (r.headers.get('Content-Encoding') or '').lower()
    if enc == 'gzip':
        data = gzip.decompress(data)
    elif enc == 'deflate':
        try:
            data = zlib.decompress(data)
        except zlib.error:
            data = zlib.decompress(data, -15)
    return data


def clean_stream_url(raw):
    raw = (raw or '').strip()
    for pfx in ('ffmpeg ', 'ffrt ', 'shell ', 'vlc ', 'auto '):
        if raw.lower().startswith(pfx):
            raw = raw[len(pfx):].strip()
    if raw.lower().startswith(('http%3a', 'rtmp%3a')):
        raw = urllib.parse.unquote(raw)
    m = re.search(r'((?:https?|rtmps?|rtsp|udp|rtp)://\S+)', raw)
    return m.group(1) if m else raw


class MacPortalClient:
    def __init__(self, server_url, mac, timeout=15, log=None):
        self.base = normalise_base(server_url)
        self.mac = (mac or '').upper().strip()
        self.timeout = timeout
        self._log = log or (lambda m: None)
        self.endpoint = None
        self.token = ''
        self.compat = False
        self.connected_at = 0.0
        self.restored = False
        self._serial = ''.join(random.choices(string.digits, k=13))
        self._dev_id = hashlib.md5(self.mac.encode()).hexdigest().upper()
        self._dev_id2 = hashlib.md5((self.mac + 'extra').encode()).hexdigest().upper()
        self.host = urllib.parse.urlparse(self.base).netloc

    # ---------- HTTP ----------
    def _cookie(self):
        return 'mac=%s; stb_lang=de; timezone=Europe/Berlin; token=%s' % (self.mac, self.token or '')

    def _headers(self, auth=True):
        if self.compat:
            return {'User-Agent': CHROME_UA, 'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate'}
        h = {'User-Agent': MAG_UA, 'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate',
             'X-User-Agent': 'Model: MAG250; Link: WiFi', 'Cookie': self._cookie()}
        if auth and self.token:
            h['Authorization'] = 'Bearer ' + self.token
        return h

    def _get_json(self, endpoint, params, auth=True):
        p = dict(params)
        p['JsHttpRequest'] = '1-xml'
        if self.compat:
            p['mac'] = self.mac
        url = self.base + endpoint + '?' + urllib.parse.urlencode(p)
        data = _http_get(url, self._headers(auth), self.timeout)
        try:
            obj = json.loads(data.decode('utf-8', 'replace'))
        except ValueError:
            raise MacPortalError('Antwort des Portals ist kein JSON')
        if isinstance(obj, dict) and 'js' in obj:
            js = obj['js']
            return js if js is not None else {}
        return obj

    def _call(self, params, _retry=True):
        if not self.endpoint:
            raise MacPortalError('Nicht verbunden')
        try:
            return self._get_json(self.endpoint, params)
        except urllib.error.HTTPError as e:
            if e.code in (401, 403) and _retry and not self.compat:
                self._log('Token abgelaufen - neuer Handshake')
                self._handshake(self.endpoint)
                return self._call(params, _retry=False)
            raise

    # ---------- Verbindung ----------
    def _handshake(self, endpoint):
        self.token = ''
        js = self._get_json(endpoint, {'type': 'stb', 'action': 'handshake',
                                       'token': '', 'prehash': '0'}, auth=False)
        token = js.get('token', '') if isinstance(js, dict) else ''
        if not token:
            raise MacPortalError('Kein Token im Handshake')
        self.token = token
        return token

    def _profile(self):
        try:
            self._get_json(self.endpoint, {
                'type': 'stb', 'action': 'get_profile', 'hd': '1', 'num_banks': '2',
                'sn': self._serial, 'stb_type': 'MAG250', 'image_version': '218',
                'device_id': self._dev_id, 'device_id2': self._dev_id2, 'signature': '',
                'auth_second_step': '1', 'hw_version': '1.7-BD-00',
                'ver': ('ImageDescription: 0.2.18-r23-pub-250; ImageDate: Wed Mar 9 17:28:54 EET 2022; '
                        'PORTAL version: 6.2.0; API Version: JS API version: 343')})
        except Exception as e:                      # nicht kritisch
            self._log('get_profile fehlgeschlagen: %s' % e)

    def connect(self):
        errors = []
        for ep in ENDPOINTS:                         # 1) Standard-Handshake
            self.compat = False
            try:
                self._handshake(ep)
            except Exception as e:
                errors.append('%s: %s' % (ep, e))
                continue
            self.endpoint = ep
            self._profile()
            self.connected_at = time.time()
            self._log('Handshake ok (%s)' % ep)
            return True
        for ep in ENDPOINTS:                         # 2) Kompatibilitaetsmodus ohne Handshake
            self.compat, self.token, self.endpoint = True, '', ep
            try:
                js = self._get_json(ep, {'type': 'itv', 'action': 'get_genres'})
                if js:
                    self.connected_at = time.time()
                    self._log('Compat-Modus ok (%s)' % ep)
                    return True
            except Exception as e:
                errors.append('compat %s: %s' % (ep, e))
        self.compat, self.endpoint = False, None
        raise MacPortalError('Verbindung fehlgeschlagen (%s)' % '; '.join(errors[-2:]))

    def export_session(self):
        return {'endpoint': self.endpoint, 'token': self.token, 'compat': self.compat, 't': self.connected_at}

    def restore(self, sess):
        """Gespeicherte Sitzung wieder verwenden (kein Handshake, keine Anfrage)."""
        self.endpoint = sess.get('endpoint')
        self.token = sess.get('token', '')
        self.compat = bool(sess.get('compat'))
        self.connected_at = float(sess.get('t') or time.time())
        self.restored = True
        return bool(self.endpoint)

    def check(self):
        """Hat die MAC Zugang? (Genres oder Kategorien muessen etwas liefern)"""
        try:
            if self.genres():
                return True
            if self.categories('vod') or self.categories('series'):
                return True
        except Exception as e:
            self._log('check: %s' % e)
        return False

    # ---------- Inhalte ----------
    def genres(self):
        js = self._call({'type': 'itv', 'action': 'get_genres'})
        if isinstance(js, dict):                      # manche Portale: {"data":[...]} oder {"1":"Name", ...}
            if isinstance(js.get('data'), list):
                return js['data']
            out = []
            for k, v in js.items():
                if isinstance(v, str):
                    out.append({'id': str(k), 'title': v})
                elif isinstance(v, dict):
                    d = dict(v)
                    d.setdefault('id', str(k))
                    out.append(d)
            return out
        return js if isinstance(js, list) else []

    def channels(self):
        js = self._call({'type': 'itv', 'action': 'get_all_channels'})
        if isinstance(js, dict):
            return js.get('data', []) or []
        return js if isinstance(js, list) else []

    def categories(self, kind):
        js = self._call({'type': kind, 'action': 'get_categories'})
        return js if isinstance(js, list) else []

    def ordered(self, kind, category=None, page=1, movie_id=None, season_id='0', episode_id='0'):
        p = {'type': kind, 'action': 'get_ordered_list'}
        if movie_id is not None:
            p.update({'movie_id': movie_id, 'season_id': season_id, 'episode_id': episode_id})
        else:
            p.update({'p': page, 'sortby': 'name', 'fav': '0', 'category': category or '*'})
        js = self._call(p)
        return js if isinstance(js, dict) else {'data': js if isinstance(js, list) else []}

    def account_info(self):
        try:
            js = self._call({'type': 'account_info', 'action': 'get_main_info'})
            return js if isinstance(js, dict) else {}
        except Exception:
            return {}

    def create_link(self, kind, cmd, series=None):
        """Loest einen Eintrag in eine abspielbare Stream-URL auf ('' wenn nicht moeglich)."""
        def ask(k, c):
            p = {'type': k, 'action': 'create_link', 'cmd': c, 'series': '0',
                 'forced_storage': 'undefined', 'disable_ad': '0', 'download': '0',
                 'force_ch_link_check': '0'}
            if series not in (None, ''):
                p['series'] = series
            js = self._call(p)
            raw = js.get('cmd', '') if isinstance(js, dict) else ''
            url = clean_stream_url(raw)
            return '' if (not url or '://localhost' in url) else url

        url = ask(kind, cmd)
        if not url and kind == 'itv':
            m = re.search(r'(\d+)[^\d/]*$', clean_stream_url(cmd))
            if m:
                url = ask('itv', 'ffmpeg http://localhost/ch/' + m.group(1))
        if not url and kind == 'vod':
            url = ask('series', cmd)
        if not url:
            fallback = clean_stream_url(cmd)
            if fallback.lower().startswith(('http://', 'https://', 'rtmp://')) and '://localhost' not in fallback:
                return fallback
        return url

    def probe_stream(self, url, timeout=8):
        """Liest ein paar Bytes vom Stream. -> (Zustand, Grund)
        Zustand: True = Video kommt, False = eindeutig kein Video, None = unklar (Serverfehler/Timeout)."""
        try:
            hdrs = dict(self.stream_headers(url))
            hdrs.setdefault('Accept', '*/*')
            hdrs.setdefault('Connection', 'close')
            req = urllib.request.Request(url, headers=hdrs)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                ctype = (r.headers.get('Content-Type') or '').lower()
                data = r.read(8192)
        except urllib.error.HTTPError as e:
            if e.code in (401, 403, 404, 410, 451):
                return False, 'Stream abgelehnt (HTTP %s)' % e.code
            return None, 'Serverfehler beim Test (HTTP %s) - unklar' % e.code      # 5xx, z.B. Cloudflare 520
        except Exception as e:
            return None, 'Test nicht moeglich (%s) - unklar' % type(e).__name__
        if not data:
            return False, 'Stream liefert keine Daten'
        head = data[:400].lstrip().lower()
        if head.startswith(b'#extm3u'):
            return True, ''
        if head.startswith((b'<html', b'<!doctype', b'<?xml', b'{', b'[')) or 'text/html' in ctype:
            return False, 'Stream liefert eine Fehlerseite statt Video'
        if len(data) < 188:
            return None, 'Stream liefert sehr wenig Daten - unklar'
        return True, ''

    def verify_playback(self, tries=4):
        """Test, ob ein Bild kommen kann. -> (Zustand, Grund); Zustand True / False / None (unklar)."""
        cands = []
        try:
            chans = [c for c in self.channels() if c.get('cmd')]
            if chans:
                n = len(chans)
                idx = []
                for k in range(tries):                       # gleichmaessig verteilt
                    i2 = (k * n) // tries
                    if i2 not in idx:
                        idx.append(i2)
                cands = [('itv', chans[i2]['cmd']) for i2 in idx]
        except Exception as e:
            self._log('verify: Kanaele: %s' % e)
        if not cands:
            try:
                for it in (self.ordered('vod', category='*', page=1).get('data') or []):
                    if it.get('cmd') and str(it.get('is_series') or '0') != '1':
                        cands.append(('vod', it['cmd']))
                        if len(cands) >= tries:
                            break
            except Exception as e:
                self._log('verify: VOD: %s' % e)
        if not cands:
            return False, 'keine Kanaele oder Filme gefunden'
        sure_bad, unclear, unclear_n = None, None, 0
        for kind, cmd in cands:
            if unclear_n >= 3:                                # nicht ewig weitertesten
                break
            for attempt in (1, 2):                            # bei Serverfehler neuer Link + 2. Versuch
                try:
                    url = self.create_link(kind, cmd)
                except Exception as e:
                    sure_bad = sure_bad or 'Stream-Link nicht erzeugbar (%s)' % type(e).__name__
                    break
                if not url:
                    sure_bad = sure_bad or 'Portal liefert keinen Stream-Link'
                    break
                if not url.lower().startswith(('http://', 'https://')):
                    return True, ''                           # rtmp/udp o.ae. kann nicht angelesen werden
                state, why = self.probe_stream(url)
                if state is True:
                    return True, ''
                if state is None:
                    unclear = why
                    unclear_n += 1
                    if 'HTTP' in why and attempt == 1:        # Serverfehler: kurz warten, neuer Link
                        time.sleep(1.0)
                        continue
                    break                                     # Timeout o.ae.: gleich naechster Kanal
                sure_bad = why
                break
        if unclear:
            return None, unclear
        return False, sure_bad or 'kein Stream'

    def stream_headers(self, url):
        """Header fuer Kodi. Cookie/Referer nur, wenn der Stream auf dem Portal-Server liegt."""
        h = {'User-Agent': MAG_UA if not self.compat else CHROME_UA}
        if urllib.parse.urlparse(url).netloc == self.host:
            h['Referer'] = self.base + '/'
            if not self.compat:
                h['Cookie'] = self._cookie()
        return h

    def absolute(self, path):
        """Logo-/Screenshot-Pfad in eine vollstaendige URL umwandeln."""
        path = (path or '').strip()
        if not path:
            return ''
        if path.lower().startswith(('http://', 'https://')):
            return path
        if path.startswith('//'):
            return 'http:' + path
        if path.startswith('/'):
            return self.base + path
        return self.base + '/stalker_portal/misc/logos/320/' + path
