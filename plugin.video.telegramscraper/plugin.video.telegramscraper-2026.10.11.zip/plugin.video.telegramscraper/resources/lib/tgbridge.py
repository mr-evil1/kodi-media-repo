# -*- coding: utf-8 -*-
# Telegram Scraper
# Copyright (c) 2026 Team IT('s) Possible. All rights reserved.
# Version 2026.10.11
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
import asyncio
import json
import mimetypes
import os
import re
import sys
import threading
import time
import urllib.parse
import socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

CHUNK = 512 * 1024
VIDEO_EXT = {'.mp4', '.mkv', '.avi', '.mov', '.webm', '.m4v', '.ts', '.wmv', '.flv', '.mpg', '.mpeg', '.3gp'}
AUDIO_EXT = {'.mp3', '.m4a', '.flac', '.ogg', '.oga', '.opus', '.wav', '.aac'}
MSG_CACHE_TTL = 300


def _pure_ref(aes, libssl, fn):
    saved = (aes.cryptg, libssl.decrypt_ige, libssl.encrypt_ige)
    aes.cryptg = None
    libssl.decrypt_ige = None
    libssl.encrypt_ige = None
    try:
        return fn()
    finally:
        aes.cryptg, libssl.decrypt_ige, libssl.encrypt_ige = saved


def _selftest(aes, libssl):
    data = os.urandom(256)
    key = os.urandom(32)
    iv = os.urandom(32)

    ref_d = _pure_ref(
        aes,
        libssl,
        lambda: aes.AES.decrypt_ige(data, key, iv)
    )

    ref_e = _pure_ref(
        aes,
        libssl,
        lambda: aes.AES.encrypt_ige(data, key, iv)
    )

    fast_d = aes.AES.decrypt_ige(data, key, iv)
    fast_e = aes.AES.encrypt_ige(data, key, iv)

    return fast_d == ref_d and fast_e == ref_e


def _benchmark(aes, log):
    data = os.urandom(128 * 1024)
    key = os.urandom(32)
    iv = os.urandom(32)

    t = time.time()

    aes.AES.decrypt_ige(
        data,
        key,
        iv
    )

    dt = max(
        time.time() - t,
        1e-6
    )

    speed = 0.125 / dt

    log(
        'AES: Geschwindigkeit ca. %.1f MB/s'
        % speed
    )

    return speed


def ige_with_block_fn(data, iv, encrypt, block_fn):
    frm = int.from_bytes

    iv1 = frm(
        iv[:16],
        'big'
    )

    iv2 = frm(
        iv[16:32],
        'big'
    )

    n = len(data) // 16

    out = bytearray(
        n * 16
    )

    if encrypt:
        for i in range(n):
            p = frm(
                data[
                    i * 16:
                    i * 16 + 16
                ],
                'big'
            )

            c = block_fn(
                p ^ iv1
            ) ^ iv2

            out[
                i * 16:
                i * 16 + 16
            ] = c.to_bytes(
                16,
                'big'
            )

            iv1 = c
            iv2 = p

    else:
        for i in range(n):
            c = frm(
                data[
                    i * 16:
                    i * 16 + 16
                ],
                'big'
            )

            p = block_fn(
                c ^ iv2
            ) ^ iv1

            out[
                i * 16:
                i * 16 + 16
            ] = p.to_bytes(
                16,
                'big'
            )

            iv1 = c
            iv2 = p

    return bytes(out)


def _load_cryptg(lib_dir, log):
    try:
        import cryptg

        if (
            hasattr(cryptg, 'decrypt_ige')
            and hasattr(cryptg, 'encrypt_ige')
        ):
            return cryptg

    except Exception as e:
        log(
            'cryptg: Import fehlgeschlagen: %r'
            % (e,)
        )

    if not lib_dir:
        return None

    import glob
    import importlib.machinery
    import importlib.util

    pat = (
        'cryptg*.pyd'
        if os.name == 'nt'
        else 'cryptg*.so'
    )

    for path in glob.glob(
        os.path.join(
            lib_dir,
            'cryptg',
            pat
        )
    ):
        try:
            loader = importlib.machinery.ExtensionFileLoader(
                'cryptg.cryptg',
                path
            )

            spec = importlib.util.spec_from_file_location(
                'cryptg.cryptg',
                path,
                loader=loader
            )

            mod = importlib.util.module_from_spec(
                spec
            )

            loader.exec_module(
                mod
            )

            if (
                hasattr(mod, 'decrypt_ige')
                and hasattr(mod, 'encrypt_ige')
            ):
                return mod

        except Exception as e:
            log(
                'cryptg: manuelles Laden fehlgeschlagen (%s): %r'
                % (
                    os.path.basename(path),
                    e
                )
            )

    return None


def _load_native_aes(log):
    modules = (
        'Crypto.Cipher.AES',
        'Cryptodome.Cipher.AES',
    )

    for name in modules:
        try:
            parts = name.split('.')

            module = __import__(
                name,
                fromlist=[parts[-1]]
            )

            if not hasattr(
                module,
                'new'
            ):
                continue

            cipher = module.new(
                b'\x00' * 32,
                module.MODE_ECB
            )

            cipher.encrypt(
                b'\x00' * 16
            )

            cipher.decrypt(
                b'\x00' * 16
            )

            log(
                'AES: native %s gefunden'
                % name
            )

            return module

        except Exception as e:
            log(
                'AES: %s nicht verfügbar: %r'
                % (
                    name,
                    e
                )
            )

    return None


def _make_native_aes_ige(aes_module):
    def run(data, key, iv, encrypt):
        if not data:
            return data

        if len(data) % 16:
            raise ValueError(
                'AES-IGE Datenlänge ist kein Vielfaches von 16.'
            )

        cipher = aes_module.new(
            bytes(key),
            aes_module.MODE_ECB
        )

        if encrypt:
            operation = cipher.encrypt
        else:
            operation = cipher.decrypt

        def block(value):
            raw = int(value).to_bytes(
                16,
                'big'
            )

            return int.from_bytes(
                operation(raw),
                'big'
            )

        return ige_with_block_fn(
            data,
            iv,
            encrypt,
            block
        )

    return run


def _make_libcrypto(cand, log):
    import ctypes

    lib = ctypes.CDLL(cand)

    set_dec = lib.AES_set_decrypt_key
    set_enc = lib.AES_set_encrypt_key
    ige = lib.AES_ige_encrypt

    set_dec.argtypes = set_enc.argtypes = [
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_void_p
    ]

    ige.argtypes = [
        ctypes.c_char_p,
        ctypes.c_void_p,
        ctypes.c_size_t,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_int
    ]

    def run(data, key, iv, encrypt):
        ks = ctypes.create_string_buffer(
            512
        )

        setter = (
            set_enc
            if encrypt
            else set_dec
        )

        setter(
            bytes(key),
            len(key) * 8,
            ctypes.addressof(ks)
        )

        ivb = ctypes.create_string_buffer(
            bytes(iv),
            len(iv)
        )

        out = ctypes.create_string_buffer(
            len(data)
        )

        ige(
            bytes(data),
            ctypes.addressof(out),
            len(data),
            ctypes.addressof(ks),
            ctypes.addressof(ivb),
            1 if encrypt else 0
        )

        return out.raw

    return run


def _make_windows_cng(log):
    import ctypes

    from ctypes import (
        c_void_p,
        c_ulong,
        c_long,
        c_wchar_p,
        c_char_p,
        POINTER
    )

    bcrypt = ctypes.WinDLL(
        'bcrypt'
    )

    bcrypt.BCryptOpenAlgorithmProvider.argtypes = [
        POINTER(c_void_p),
        c_wchar_p,
        c_wchar_p,
        c_ulong
    ]

    bcrypt.BCryptOpenAlgorithmProvider.restype = c_long

    bcrypt.BCryptSetProperty.argtypes = [
        c_void_p,
        c_wchar_p,
        c_wchar_p,
        c_ulong,
        c_ulong
    ]

    bcrypt.BCryptSetProperty.restype = c_long

    bcrypt.BCryptGenerateSymmetricKey.argtypes = [
        c_void_p,
        POINTER(c_void_p),
        c_void_p,
        c_ulong,
        c_char_p,
        c_ulong,
        c_ulong
    ]

    bcrypt.BCryptGenerateSymmetricKey.restype = c_long

    for fn in (
        bcrypt.BCryptEncrypt,
        bcrypt.BCryptDecrypt
    ):
        fn.argtypes = [
            c_void_p,
            c_void_p,
            c_ulong,
            c_void_p,
            c_void_p,
            c_ulong,
            c_void_p,
            c_ulong,
            POINTER(c_ulong),
            c_ulong
        ]

        fn.restype = c_long

    bcrypt.BCryptDestroyKey.argtypes = [
        c_void_p
    ]

    bcrypt.BCryptCloseAlgorithmProvider.argtypes = [
        c_void_p,
        c_ulong
    ]

    halg = c_void_p()

    st = bcrypt.BCryptOpenAlgorithmProvider(
        ctypes.byref(halg),
        'AES',
        None,
        0
    )

    if st != 0:
        raise OSError(
            'BCryptOpenAlgorithmProvider: 0x%08x'
            % (st & 0xffffffff)
        )

    mode = 'ChainingModeECB'

    st = bcrypt.BCryptSetProperty(
        halg,
        'ChainingMode',
        mode,
        (len(mode) + 1) * 2,
        0
    )

    if st != 0:
        raise OSError(
            'BCryptSetProperty: 0x%08x'
            % (st & 0xffffffff)
        )

    def run(data, key, iv, encrypt):
        hkey = c_void_p()

        st = bcrypt.BCryptGenerateSymmetricKey(
            halg,
            ctypes.byref(hkey),
            None,
            0,
            bytes(key),
            len(key),
            0
        )

        if st != 0:
            raise OSError(
                'BCryptGenerateSymmetricKey: 0x%08x'
                % (st & 0xffffffff)
            )

        try:
            inb = ctypes.create_string_buffer(
                16
            )

            outb = ctypes.create_string_buffer(
                16
            )

            ia = ctypes.addressof(
                inb
            )

            oa = ctypes.addressof(
                outb
            )

            res = c_ulong()
            resp = ctypes.byref(
                res
            )

            call = (
                bcrypt.BCryptEncrypt
                if encrypt
                else bcrypt.BCryptDecrypt
            )

            frm = int.from_bytes

            def block(x):
                inb.raw = x.to_bytes(
                    16,
                    'big'
                )

                call(
                    hkey,
                    ia,
                    16,
                    None,
                    None,
                    0,
                    oa,
                    16,
                    resp,
                    0
                )

                return frm(
                    outb.raw,
                    'big'
                )

            return ige_with_block_fn(
                data,
                iv,
                encrypt,
                block
            )

        finally:
            bcrypt.BCryptDestroyKey(
                hkey
            )

    return run


def enable_fast_aes(
    search_dirs=(),
    log=print,
    lib_dir=None
):
    import ctypes
    import ctypes.util
    import glob

    from telethon.crypto import (
        aes,
        libssl
    )

    def attempt(label, install):
        saved = (
            aes.cryptg,
            libssl.decrypt_ige,
            libssl.encrypt_ige
        )

        try:
            install()

            if _selftest(
                aes,
                libssl
            ):
                log(
                    'AES: %s aktiv'
                    % label
                )

                _benchmark(
                    aes,
                    log
                )

                return True

            log(
                'AES: Selbsttest fehlgeschlagen: %s'
                % label
            )

        except Exception as e:
            log(
                'AES: %s nicht nutzbar: %r'
                % (
                    label,
                    e
                )
            )

        aes.cryptg = saved[0]
        libssl.decrypt_ige = saved[1]
        libssl.encrypt_ige = saved[2]

        return False

    def set_cryptg(mod):
        aes.cryptg = mod

    def set_fns(run):
        libssl.decrypt_ige = (
            lambda d, k, i:
            run(
                d,
                k,
                i,
                False
            )
        )

        libssl.encrypt_ige = (
            lambda d, k, i:
            run(
                d,
                k,
                i,
                True
            )
        )

    mod = (
        aes.cryptg
        or _load_cryptg(
            lib_dir,
            log
        )
    )

    if mod is not None:
        if attempt(
            'cryptg',
            lambda: set_cryptg(mod)
        ):
            return True

    try:
        import tgfast
        if tgfast.install_aes(aes, libssl, log):
            return True
    except Exception as e:
        log('AES: tgfast nicht nutzbar: %r' % (e,))

    native_aes = _load_native_aes(
        log
    )

    if native_aes is not None:
        native_run = _make_native_aes_ige(
            native_aes
        )

        if attempt(
            'native AES-ECB / IGE',
            lambda: set_fns(native_run)
        ):
            return True

    if (
        libssl.encrypt_ige
        and libssl.decrypt_ige
        and attempt(
            'libssl (Telethon)',
            lambda: None
        )
    ):
        return True

    cands = []

    found = ctypes.util.find_library(
        'crypto'
    )

    if found:
        cands.append(
            found
        )

    android_paths = [
        '/system/lib64/libcrypto.so',
        '/system/lib/libcrypto.so',
        '/apex/com.android.conscrypt/lib64/libcrypto.so',
        '/apex/com.android.conscrypt/lib/libcrypto.so'
    ]

    for ap in android_paths:
        if os.path.exists(ap):
            cands.append(ap)

    for d in search_dirs:
        if d and os.path.isdir(d):
            for pat in (
                'libcrypto*.dll',
                'libeay32.dll',
                'libcrypto*.so*',
                'libcrypto*.dylib'
            ):
                cands.extend(
                    sorted(
                        glob.glob(
                            os.path.join(
                                d,
                                pat
                            )
                        )
                    )
                )

    unique = []

    for cand in cands:
        if cand not in unique:
            unique.append(cand)

    log(
        'AES: libcrypto-Kandidaten: %s'
        % (
            unique
            or 'keine'
        )
    )

    for cand in unique:
        try:
            run = _make_libcrypto(
                cand,
                log
            )

        except (
            OSError,
            AttributeError
        ) as e:
            log(
                'AES: %s nicht ladbar: %r'
                % (
                    cand,
                    e
                )
            )

            continue

        if attempt(
            'OpenSSL (%s)' % cand,
            lambda run=run:
            set_fns(run)
        ):
            return True

    if os.name == 'nt':
        if attempt(
            'Windows-CNG (bcrypt.dll)',
            lambda:
            set_fns(
                _make_windows_cng(
                    log
                )
            )
        ):
            return True

    log(
        'AES: KEINE schnelle Variante gefunden '
        '-> reines Python (sehr langsam)'
    )

    return False


def describe(m):
    kind = 'text'
    name = ''
    size = 0
    mime = ''
    duration = 0

    f = m.file

    if m.photo:
        kind = 'photo'

    elif (
        f is not None
        and m.document is not None
    ):
        mime = f.mime_type or ''
        name = f.name or ''

        ext = (
            os.path.splitext(
                name
            )[1]
            or f.ext
            or ''
        ).lower()

        size = f.size or 0
        duration = int(
            f.duration or 0
        )

        if (
            mime.startswith('video/')
            or ext in VIDEO_EXT
        ):
            kind = 'video'

        elif (
            mime.startswith('audio/')
            or ext in AUDIO_EXT
        ):
            kind = 'audio'

        else:
            kind = 'file'

    has_thumb = bool(
        m.photo
        or (
            m.document is not None
            and getattr(
                m.document,
                'thumbs',
                None
            )
        )
    )

    return {
        'id': m.id,
        'date':
            m.date.strftime(
                '%Y-%m-%d'
            )
            if m.date
            else '',
        'text':
            re.sub(
                r'\s+',
                ' ',
                m.message or ''
            ).strip(),
        'kind': kind,
        'name': name,
        'size': size,
        'mime': mime,
        'duration': duration,
        'has_thumb': has_thumb,
    }


def normalize_chat_id(value):
    value = str(
        value
    ).strip()

    if 't.me/' in value:
        value = value.split(
            't.me/'
        )[-1]

    value = value.lstrip(
        '@/s'
    )

    if not re.fullmatch(
        r'-?\d+',
        value
    ):
        return value

    if value.startswith('-100'):
        return int(value)

    elif value.startswith('-'):
        return int(value)

    return int(
        '-100' + value
    )


class Bridge(object):
    def __init__(
        self,
        profile_dir,
        get_credentials,
        log=print
    ):
        self.profile_dir = profile_dir
        self.get_credentials = get_credentials
        self.log = log

        self.session_file = os.path.join(
            profile_dir,
            'telegram.txt'
        )

        self.thumb_dir = os.path.join(
            profile_dir,
            'thumbs'
        )

        os.makedirs(
            self.thumb_dir,
            exist_ok=True
        )

        self.loop = None

        self._loop_ready = threading.Event()

        self.thread = threading.Thread(
            target=self._run_loop,
            name='tg-loop',
            daemon=True
        )

        self.thread.start()

        if not self._loop_ready.wait(5):
            raise RuntimeError(
                'Telegram Event-Loop konnte nicht gestartet werden.'
            )

        if self.loop is None:
            raise RuntimeError(
                'Telegram Event-Loop ist nicht verfügbar.'
            )

        self.client = None
        self._creds = None
        self._login = {}
        self._dialogs_loaded = False
        self._msg_cache = {}

    def _run_loop(self):
        try:
            self.loop = asyncio.new_event_loop()

            asyncio.set_event_loop(
                self.loop
            )

            self._loop_ready.set()

            self.loop.run_forever()

        except Exception as e:
            self.log(
                'Event-Loop Fehler: %r'
                % (e,)
            )

            self._loop_ready.set()

        finally:
            loop = self.loop

            if loop is not None:
                try:
                    pending = asyncio.all_tasks(
                        loop
                    )

                    for task in pending:
                        task.cancel()

                    if pending:
                        loop.run_until_complete(
                            asyncio.gather(
                                *pending,
                                return_exceptions=True
                            )
                        )

                except Exception:
                    pass

                try:
                    loop.close()

                except Exception:
                    pass

    def run(
        self,
        coro,
        timeout=60
    ):
        if self.loop is None:
            raise RuntimeError(
                'Event-Loop nicht verfügbar.'
            )

        return asyncio.run_coroutine_threadsafe(
            coro,
            self.loop
        ).result(
            timeout
        )

    def stop(self):
        try:
            if (
                self.client
                and self.loop
            ):
                self.run(
                    self.client.disconnect(),
                    10
                )

        except Exception:
            pass

        if self.loop:
            try:
                self.loop.call_soon_threadsafe(
                    self.loop.stop
                )
            except Exception:
                pass

    async def _get_client(self):
        from telethon import TelegramClient
        from telethon.sessions import StringSession

        api_id, api_hash = (
            self.get_credentials()
        )

        if not api_id or not api_hash:
            raise RuntimeError(
                'API ID / API Hash fehlen (Addon-Einstellungen).'
            )

        creds = (
            api_id,
            api_hash
        )

        if (
            self.client is not None
            and self._creds != creds
        ):
            await self.client.disconnect()

            self.client = None
            self._dialogs_loaded = False

        if self.client is None:
            session = ''

            if os.path.exists(
                self.session_file
            ):
                with open(
                    self.session_file,
                    'r'
                ) as fh:
                    session = fh.read().strip()

            self.client = TelegramClient(
                StringSession(session),
                api_id,
                api_hash,
                device_model='Kodi',
                app_version='1.0',
                system_version='Kodi Addon',
                timeout=30,
                connection_retries=5,
                retry_delay=1
            )

            self._creds = creds

        if not self.client.is_connected():
            await self.client.connect()

        return self.client

    def _save_session(self):
        data = self.client.session.save()

        fd = os.open(
            self.session_file,
            os.O_WRONLY
            | os.O_CREAT
            | os.O_TRUNC,
            0o600
        )

        with os.fdopen(
            fd,
            'w'
        ) as fh:
            fh.write(data)

    async def status(self):
        try:
            client = await self._get_client()

        except RuntimeError as e:
            return {
                'authorized': False,
                'message': str(e)
            }

        return {
            'authorized':
                bool(
                    await client.is_user_authorized()
                )
        }

    async def login_start(
        self,
        phone
    ):
        client = await self._get_client()

        sent = await client.send_code_request(
            phone
        )

        self._login = {
            'phone': phone,
            'hash': sent.phone_code_hash
        }

        return {
            'ok': True
        }

    async def login_code(
        self,
        code
    ):
        from telethon.errors import (
            SessionPasswordNeededError
        )

        client = await self._get_client()

        try:
            await client.sign_in(
                phone=self._login.get(
                    'phone'
                ),
                code=code,
                phone_code_hash=self._login.get(
                    'hash'
                )
            )

        except SessionPasswordNeededError:
            return {
                'need_password': True
            }

        self._save_session()

        return {
            'ok': True
        }

    async def login_password(
        self,
        password
    ):
        client = await self._get_client()

        await client.sign_in(
            password=password
        )

        self._save_session()

        return {
            'ok': True
        }

    async def logout(self):
        client = await self._get_client()

        try:
            await client.log_out()

        except Exception:
            pass

        self.client = None
        self._dialogs_loaded = False
        self._msg_cache.clear()

        if os.path.exists(
            self.session_file
        ):
            os.remove(
                self.session_file
            )

        return {
            'ok': True
        }

    async def _entity(
        self,
        chat
    ):
        client = await self._get_client()

        if not await client.is_user_authorized():
            raise RuntimeError(
                'Nicht bei Telegram angemeldet.'
            )

        chat = normalize_chat_id(
            chat
        )

        try:
            return await client.get_entity(
                chat
            )

        except ValueError:
            if not self._dialogs_loaded:
                await client.get_dialogs()
                self._dialogs_loaded = True

            try:
                return await client.get_entity(
                    chat
                )

            except ValueError:
                raise RuntimeError(
                    'Kanal %s nicht gefunden.'
                    % chat
                )

    async def chatinfo(
        self,
        chat
    ):
        ent = await self._entity(
            chat
        )

        return {
            'title':
                getattr(
                    ent,
                    'title',
                    None
                )
                or getattr(
                    ent,
                    'first_name',
                    None
                )
                or str(chat),

            'is_forum':
                bool(
                    getattr(
                        ent,
                        'forum',
                        False
                    )
                ),
        }

    async def topics(
        self,
        chat
    ):
        from telethon.tl.functions.messages import (
            GetForumTopicsRequest
        )

        ent = await self._entity(
            chat
        )

        res = await self.client(
            GetForumTopicsRequest(
                peer=ent,
                offset_date=None,
                offset_id=0,
                offset_topic=0,
                limit=100
            )
        )

        return {
            'topics': [
                {
                    'id': t.id,
                    'name': t.title
                }
                for t in res.topics
                if hasattr(
                    t,
                    'title'
                )
            ]
        }

    async def messages(
        self,
        chat,
        topic=0,
        offset_id=0,
        limit=30
    ):
        ent = await self._entity(
            chat
        )

        kw = {
            'limit': limit,
            'offset_id': offset_id
        }

        if topic:
            kw['reply_to'] = int(
                topic
            )

        items = []

        async for m in self.client.iter_messages(
            ent,
            **kw
        ):
            items.append(
                describe(m)
            )

        nxt = (
            items[-1]['id']
            if len(items) >= limit
            else 0
        )

        return {
            'items': items,
            'next_offset': nxt
        }

    async def _get_message(
        self,
        chat,
        msg_id
    ):
        key = (
            str(chat),
            int(msg_id)
        )

        hit = self._msg_cache.get(
            key
        )

        if (
            hit
            and time.time() - hit[0]
            < MSG_CACHE_TTL
        ):
            return hit[1]

        ent = await self._entity(
            chat
        )

        m = await self.client.get_messages(
            ent,
            ids=int(msg_id)
        )

        if not m or not m.media:
            raise RuntimeError(
                'Nachricht %s hat keine Medien.'
                % msg_id
            )

        if len(
            self._msg_cache
        ) > 200:
            self._msg_cache.clear()

        self._msg_cache[key] = (
            time.time(),
            m
        )

        return m

    async def media_info(
        self,
        chat,
        msg_id
    ):
        m = await self._get_message(
            chat,
            msg_id
        )

        d = describe(
            m
        )

        mime = (
            d['mime']
            or mimetypes.guess_type(
                d['name']
            )[0]
            or 'application/octet-stream'
        )

        return {
            'size': d['size'],
            'mime': mime
        }

    def stream_gen(self, chat, msg_id, start, end):
        import tgfast
        return tgfast.stream_gen(self, chat, msg_id, start, end)

    async def thumb(
        self,
        chat,
        msg_id
    ):
        safe_chat_name = re.sub(
            r'[^\w\-]',
            '_',
            str(chat)
        )

        path = os.path.join(
            self.thumb_dir,
            '%s_%s.jpg'
            % (
                safe_chat_name,
                int(msg_id)
            )
        )

        if os.path.exists(
            path
        ):
            with open(
                path,
                'rb'
            ) as fh:
                return fh.read()

        m = await self._get_message(
            chat,
            msg_id
        )

        idx = (
            1
            if (
                m.photo
                and len(
                    m.photo.sizes
                ) > 1
            )
            else -1
        )

        data = await self.client.download_media(
            m,
            file=bytes,
            thumb=idx
        )

        if data:
            with open(
                path,
                'wb'
            ) as fh:
                fh.write(data)

        return data


def make_server(
    bridge,
    token
):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'
        server_version = 'KodiTelegram/1.0'

        def log_message(
            self,
            fmt,
            *args
        ):
            pass

        def _query(self):
            u = urllib.parse.urlparse(
                self.path
            )

            return (
                u.path,
                dict(
                    urllib.parse.parse_qsl(
                        u.query
                    )
                )
            )

        def _json(
            self,
            obj,
            status=200
        ):
            body = json.dumps(
                obj
            ).encode(
                'utf-8'
            )

            self.send_response(
                status
            )

            self.send_header(
                'Content-Type',
                'application/json; charset=utf-8'
            )

            self.send_header(
                'Content-Length',
                str(len(body))
            )

            self.end_headers()

            self.wfile.write(
                body
            )

        def _bytes(
            self,
            data,
            ctype,
            status=200,
            head=False
        ):
            self.send_response(
                status
            )

            self.send_header(
                'Content-Type',
                ctype
            )

            self.send_header(
                'Content-Length',
                str(len(data))
            )

            self.end_headers()

            if not head:
                self.wfile.write(
                    data
                )

        def _auth(
            self,
            q
        ):
            return q.get(
                't'
            ) == token

        def do_HEAD(self):
            self._dispatch(
                head=True
            )

        def do_GET(self):
            self._dispatch()

        def do_POST(self):
            self._dispatch()

        def _dispatch(
            self,
            head=False
        ):
            path, q = self._query()

            try:
                if not self._auth(q):
                    return self._json(
                        {
                            'error':
                                'forbidden'
                        },
                        403
                    )

                if path.startswith(
                    '/stream'
                ):
                    return self._stream(
                        q,
                        head
                    )

                if path == '/thumb':
                    return self._thumb(
                        q,
                        head
                    )

                if path.startswith(
                    '/api/'
                ):
                    return self._api(
                        path[5:],
                        q
                    )

                self._json(
                    {
                        'error':
                            'not found'
                    },
                    404
                )

            except (
                BrokenPipeError,
                ConnectionResetError
            ):
                pass

            except Exception as e:
                bridge.log(
                    'Request-Fehler %s: %r'
                    % (
                        path,
                        e
                    )
                )

                try:
                    self._json(
                        {
                            'error':
                                str(e)
                                or e.__class__.__name__
                        }
                    )

                except Exception:
                    pass

        def _body(self):
            n = int(
                self.headers.get(
                    'Content-Length'
                )
                or 0
            )

            if not n:
                return {}

            return json.loads(
                self.rfile.read(
                    n
                ).decode(
                    'utf-8'
                )
                or '{}'
            )

        def _api(
            self,
            name,
            q
        ):
            b = bridge

            body = (
                self._body()
                if self.command == 'POST'
                else {}
            )

            if name == 'status':
                res = b.run(
                    b.status(),
                    20
                )

            elif name == 'login/start':
                res = b.run(
                    b.login_start(
                        body['phone']
                    )
                )

            elif name == 'login/code':
                res = b.run(
                    b.login_code(
                        body['code']
                    )
                )

            elif name == 'login/password':
                res = b.run(
                    b.login_password(
                        body['password']
                    )
                )

            elif name == 'logout':
                res = b.run(
                    b.logout()
                )

            elif name == 'chatinfo':
                res = b.run(
                    b.chatinfo(
                        q['chat']
                    ),
                    90
                )

            elif name == 'topics':
                res = b.run(
                    b.topics(
                        q['chat']
                    ),
                    60
                )

            elif name == 'messages':
                res = b.run(
                    b.messages(
                        q['chat'],
                        int(
                            q.get('topic')
                            or 0
                        ),
                        int(
                            q.get('offset_id')
                            or 0
                        ),
                        int(
                            q.get('limit')
                            or 30
                        )
                    ),
                    60
                )

            else:
                return self._json(
                    {
                        'error':
                            'unknown api'
                    },
                    404
                )

            self._json(
                res
            )

        def _thumb(
            self,
            q,
            head=False
        ):
            data = bridge.run(
                bridge.thumb(
                    q['chat'],
                    q['msg']
                ),
                30
            )

            if not data:
                return self._json(
                    {
                        'error':
                            'no thumb'
                    },
                    404
                )

            self._bytes(
                data,
                'image/jpeg',
                head=head
            )

        def _stream(
            self,
            q,
            head
        ):
            chat = q['chat']
            msg = q['msg']

            info = bridge.run(
                bridge.media_info(
                    chat,
                    msg
                ),
                60
            )

            size = info['size']
            ctype = info['mime']

            if size <= 0:
                return self._json(
                    {
                        'error':
                            'unbekannte Dateigroesse'
                    },
                    500
                )

            start = 0
            end = size - 1
            status = 200

            rng = self.headers.get(
                'Range'
            )

            if rng:
                m = re.match(
                    r'bytes=(\d*)-(\d*)',
                    rng.strip()
                )

                if m and (
                    m.group(1)
                    or m.group(2)
                ):
                    if m.group(1) == '':
                        start = max(
                            size
                            - int(
                                m.group(2)
                            ),
                            0
                        )

                    else:
                        start = int(
                            m.group(1)
                        )

                        if m.group(2):
                            end = min(
                                int(
                                    m.group(2)
                                ),
                                size - 1
                            )

                    if (
                        start >= size
                        or start > end
                    ):
                        self.send_response(
                            416
                        )

                        self.send_header(
                            'Content-Range',
                            'bytes */%d'
                            % size
                        )

                        self.send_header(
                            'Content-Length',
                            '0'
                        )

                        self.end_headers()

                        return

                    status = 206

            length = (
                end - start + 1
            )

            self.send_response(
                status
            )

            self.send_header(
                'Content-Type',
                ctype
            )

            self.send_header(
                'Accept-Ranges',
                'bytes'
            )

            self.send_header(
                'Content-Length',
                str(length)
            )

            if status == 206:
                self.send_header(
                    'Content-Range',
                    'bytes %d-%d/%d'
                    % (
                        start,
                        end,
                        size
                    )
                )

            self.end_headers()

            if head:
                return

            t0 = time.time()
            sent = 0

            bridge.log(
                'stream msg=%s bytes=%d-%d von %d'
                % (
                    msg,
                    start,
                    end,
                    size
                )
            )

            agen = bridge.stream_gen(
                chat,
                msg,
                start,
                end
            )

            async def _next():
                try:
                    return await agen.__anext__()

                except StopAsyncIteration:
                    return None

            def submit():
                return asyncio.run_coroutine_threadsafe(
                    _next(),
                    bridge.loop
                )

            fut = submit()

            try:
                while True:
                    chunk = fut.result(
                        120
                    )

                    if chunk is None:
                        break

                    if not sent:
                        bridge.log(
                            'stream msg=%s erstes Chunk nach %.1fs'
                            % (
                                msg,
                                time.time() - t0
                            )
                        )

                    fut = submit()

                    self.wfile.write(
                        chunk
                    )

                    sent += len(
                        chunk
                    )

            except (
                BrokenPipeError,
                ConnectionResetError,
                ConnectionAbortedError
            ):
                pass

            finally:
                bridge.log(
                    'stream msg=%s beendet: %d Bytes in %.1fs'
                    % (
                        msg,
                        sent,
                        time.time() - t0
                    )
                )

                try:
                    fut.cancel()

                    asyncio.run_coroutine_threadsafe(
                        agen.aclose(),
                        bridge.loop
                    ).result(
                        5
                    )

                except Exception:
                    pass

    class Server(
        ThreadingHTTPServer
    ):
        def handle_error(
            self,
            request,
            client_address
        ):
            pass

    server = Server(
        (
            '127.0.0.1',
            0
        ),
        Handler
    )

    server.daemon_threads = True

    return server
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren (zusatzmetall, stonetester, mr-evil1, kato14, eragon, kangool). 
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
