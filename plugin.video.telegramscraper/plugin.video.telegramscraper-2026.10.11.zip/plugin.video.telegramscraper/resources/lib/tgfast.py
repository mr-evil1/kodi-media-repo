# -*- coding: utf-8 -*-
"""
tgfast - Geschwindigkeits-Erweiterung fuer den Telegram-Scraper (Kodi, vor allem Android).

Eigenstaendiges Modul: braucht nur Telethon und (optional) PyCryptodome. Es ersetzt keinen
vorhandenen Code, sondern wird an drei Stellen eingehaengt (siehe ANLEITUNG.md):

  1. install_aes(...)    schnellere AES-IGE-Entschluesselung (der Engpass auf schwachen CPUs)
  2. stream_gen(...)     Streaming mit 1-MiB-Chunks, parallelen Requests, RAM-Cache,
                         sparsamem Start und Vorrang fuer kurze Anfragen
  3. StreamMeter         optionale Messung (Durchsatz / Wartezeit / Stocker) fuer kodi.log

Der Code in dieser Datei ist neu geschrieben und darf vom Autor des Addons frei verwendet,
veraendert und weitergegeben werden.

Hintergrund (gemessen auf einem Qualcomm-Android-Geraet):
  * Jeder Telegram-Chunk ist per AES-IGE verschluesselt. IGE laesst sich nicht blockweise
    parallelisieren (jeder Block haengt vom vorigen Klartext ab) -> die CPU ist der Engpass.
  * Der PyCryptodome-Wrapper kostet pro 16-Byte-Block viel Python-Overhead; der direkte
    ctypes-Aufruf der C-Funktion ECB_decrypt war ~2,8x schneller (1.3 -> 3.7 MB/s).
  * Kodi liest beim Start denselben Dateianfang mehrfach und sondiert mit abgebrochenen
    Requests; der Cache und der sequentielle Start vermeiden doppelte Entschluesselung.
"""
import asyncio
import ctypes
import glob
import os
import time
from collections import OrderedDict

DEFAULT_CHUNK_KB = 1024
CHUNK = DEFAULT_CHUNK_KB * 1024
DEFAULT_PARALLEL = 2
HEAD_CHUNKS = 3
PREFETCH = 1
CACHE_LIMIT = 24 * 1024 * 1024

options_provider = None


def _parallel():
    try:
        n = int((options_provider() if options_provider else {}).get('parallel') or DEFAULT_PARALLEL)
    except Exception:
        n = DEFAULT_PARALLEL
    return max(1, min(n, 8))


def _chunk_size():
    try:
        kb = int((options_provider() if options_provider else {}).get('chunk_kb') or DEFAULT_CHUNK_KB)
        valid = [64, 128, 256, 512, 1024]
        kb = min(valid, key=lambda x: abs(x - kb))
    except Exception:
        kb = DEFAULT_CHUNK_KB
    return kb * 1024


# ======================================================================================
# 1) AES-IGE
# ======================================================================================

def _native_candidates(log):
    import ctypes.util
    seen, mapped = [], []
    try:  # alle im Prozess geladenen Bibliotheken (bereits geladen -> dlopen ist billig)
        with open('/proc/self/maps') as fh:
            for line in fh:
                parts = line.split()
                path = parts[-1] if parts else ''
                if path.startswith('/') and '.so' in path and path not in mapped:
                    mapped.append(path)
    except OSError:
        pass
    interesting = [p for p in mapped if any(x in p.lower() for x in ('libcrypto', 'libssl', '_ssl', '_hashlib', 'libpython'))]
    if mapped:
        log('AES: im Prozess geladen: %d Bibliotheken; relevant: %s'
            % (len(mapped), ', '.join(p.rsplit('/', 1)[-1] for p in interesting) or '-'))
    seen.extend(p for p in mapped if 'crypto' in p.lower())
    for name in (ctypes.util.find_library('crypto'), 'libcrypto.so.3', 'libcrypto.so.1.1',
                 'libcrypto.so', 'libcrypto_3.so', None):  # None = globale Symbole des Prozesses
        if name not in seen:
            seen.append(name)
    return seen


def _make_native(log):
    """AES-IGE komplett in C: OpenSSL AES_ige_encrypt per ctypes, falls im Prozess vorhanden."""
    for name in _native_candidates(log):
        try:
            lib = ctypes.CDLL(name)
            enc_key, dec_key, ige = lib.AES_set_encrypt_key, lib.AES_set_decrypt_key, lib.AES_ige_encrypt
        except (OSError, AttributeError):
            continue
        enc_key.argtypes = dec_key.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_void_p]
        enc_key.restype = dec_key.restype = ctypes.c_int
        ige.argtypes = [ctypes.c_char_p, ctypes.c_void_p, ctypes.c_size_t,
                        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int]
        ige.restype = None

        def run(data, key, iv, encrypt, _enc=enc_key, _dec=dec_key, _ige=ige):
            data, key = bytes(data), bytes(key)
            aes_key = ctypes.create_string_buffer(512)            # AES_KEY ist 244 Byte gross
            if (_enc if encrypt else _dec)(key, len(key) * 8, aes_key) != 0:
                raise RuntimeError('AES_set_key fehlgeschlagen')
            ivbuf = ctypes.create_string_buffer(bytes(iv), 32)    # wird von OpenSSL veraendert
            out = ctypes.create_string_buffer(len(data))
            _ige(data, out, len(data), aes_key, ivbuf, 1 if encrypt else 0)
            return out.raw

        log('AES: native Bibliothek gefunden: %s' % (name,))
        return run
    log('AES: keine native OpenSSL mit AES_ige_encrypt gefunden')
    return None


def _make_direct(log):
    """
    PyCryptodome-C-Funktion ECB_decrypt direkt per ctypes aufrufen (ohne Python-Wrapper).

    IGE: p_i = D(c_i ^ p_{i-1}) ^ c_{i-1}.  Mit t_i = D(..) gilt c_i ^ p_{i-1} = (c_i ^ c_{i-2}) ^ t_{i-1}.
    Die Terme (c_i ^ c_{i-2}) und der Schlussschritt t_i ^ c_{i-1} sind je EIN Grossinteger-XOR;
    in der Schleife bleiben pro Block nur zwei 64-Bit-XORs und ein C-Aufruf.
    Entschluesseln laeuft so; Verschluesseln (selten, kleine Daten) ueber die normale Block-Funktion.
    """
    try:
        from Cryptodome.Cipher import AES, _mode_ecb  # noqa: F401
        import Cryptodome.Cipher as cipher_pkg
    except ImportError:
        from Crypto.Cipher import AES, _mode_ecb  # noqa: F401
        import Crypto.Cipher as cipher_pkg

    candidates = []
    try:  # 1) bereits geladene Bibliothek
        with open('/proc/self/maps') as fh:
            for line in fh:
                parts = line.split()
                if parts and '_raw_ecb' in parts[-1] and parts[-1] not in candidates:
                    candidates.append(parts[-1])
    except OSError:
        pass
    name = getattr(getattr(_mode_ecb, 'raw_ecb_lib', None), '_name', None)  # 2) ctypes-Backend
    if name and name not in candidates:
        candidates.append(name)
    pkg_dir = os.path.dirname(cipher_pkg.__file__)                           # 3) Paketverzeichnis
    for f in glob.glob(os.path.join(pkg_dir, '_raw_ecb*')):
        if f not in candidates:
            candidates.append(f)
    if not candidates:
        raise RuntimeError('_raw_ecb Bibliothek nicht gefunden (in %s)' % pkg_dir)

    lib = ctypes.CDLL(candidates[0])
    ecb_decrypt = lib.ECB_decrypt
    ecb_decrypt.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
    ecb_decrypt.restype = ctypes.c_int
    c_uint64 = ctypes.c_uint64
    frm = int.from_bytes

    def state_address(cipher):
        ptr = cipher._state.get()
        val = getattr(ptr, 'value', None)             # ctypes-Backend: c_void_p
        if val is None:
            try:                                      # cffi-Backend: cdata 'void *'
                from Cryptodome.Util._raw_api import ffi
            except ImportError:
                from Crypto.Util._raw_api import ffi
            val = int(ffi.cast('uintptr_t', ptr))
        if not val or val < 4096:
            raise RuntimeError('unplausibler Cipher-Zeiger')
        return val

    def run(data, key, iv, encrypt):
        cipher = AES.new(bytes(key), AES.MODE_ECB)
        if encrypt:
            from tgbridge import ige_with_block_fn

            def block(x):
                return int.from_bytes(cipher.encrypt(x.to_bytes(16, 'big')), 'big')

            return ige_with_block_fn(data, iv, True, block)
        n = len(data) // 16
        if n == 0:
            return b''
        st = state_address(cipher)
        iv1, iv2 = bytes(iv[:16]), bytes(iv[16:32])
        cp = iv1 + bytes(data)
        size = 16 * n
        T = (c_uint64 * (2 * n))()
        base = ctypes.addressof(T)
        I = (c_uint64 * 2)()
        ia = ctypes.addressof(I)
        w = memoryview((frm(cp[16:32], 'little') ^ frm(iv2, 'little')).to_bytes(16, 'little')).cast('Q')
        I[0], I[1] = w[0], w[1]
        if ecb_decrypt(st, ia, base, 16):
            raise RuntimeError('ECB_decrypt Fehler')
        if n > 1:
            a = memoryview((frm(cp[32:], 'little') ^ frm(cp[:-32], 'little'))
                           .to_bytes(size - 16, 'little')).cast('Q')
            for i in range(1, n):
                k = 2 * i
                I[0] = a[k - 2] ^ T[k - 2]
                I[1] = a[k - 1] ^ T[k - 1]
                ecb_decrypt(st, ia, base + 8 * k, 16)
        t = ctypes.string_at(base, size)
        return (frm(t, 'little') ^ frm(cp[:-16], 'little')).to_bytes(size, 'little')

    return run


def install_aes(aes, libssl, log=print, allow_direct=True):
    """
    Installiert die schnellste verfuegbare Engine in Telethon (libssl.decrypt_ige/encrypt_ige),
    jeweils abgesichert durch den Selbsttest des Addons (_selftest) und mit Benchmark im Log.
    Reihenfolge: nativ (OpenSSL) -> direkter PyCryptodome-C-Aufruf. True bei Erfolg.
    Wird NACH cryptg (Windows) und VOR dem langsamen PyCryptodome-Wrapper aufgerufen.
    """
    from tgbridge import _selftest, _benchmark

    def attempt(label, factory):
        saved = (aes.cryptg, libssl.decrypt_ige, libssl.encrypt_ige)
        try:
            run = factory(log)
            if run is None:
                return False
            libssl.decrypt_ige = lambda d, k, i: run(d, k, i, False)
            libssl.encrypt_ige = lambda d, k, i: run(d, k, i, True)
            if not _selftest(aes, libssl):
                raise RuntimeError('Selbsttest fehlgeschlagen')
            log('AES: %s aktiv' % label)
            _benchmark(aes, log)
            return True
        except Exception as e:
            aes.cryptg, libssl.decrypt_ige, libssl.encrypt_ige = saved
            log('AES: %s nicht nutzbar: %r' % (label, e))
            return False

    if attempt('OpenSSL nativ', _make_native):
        return True
    if allow_direct and attempt('PyCryptodome direkt', _make_direct):
        return True
    return False


# ======================================================================================
# 2) Streaming
# ======================================================================================

def pick_chunk(start, end):
    max_cs = _chunk_size()
    if end - start + 1 >= 4 * max_cs:
        return max_cs
    best, best_bytes, cs = max_cs, None, 64 * 1024
    while cs <= max_cs:
        fetched = ((end // cs) - (start // cs) + 1) * cs
        if best_bytes is None or fetched <= best_bytes:
            best, best_bytes = cs, fetched
        cs *= 2
    return best


def _cache_get(bridge, key):
    cache = bridge.__dict__.get('_ccache')
    data = cache.get(key) if cache is not None else None
    if data is not None:
        cache.move_to_end(key)
    return data


def _cache_put(bridge, key, data):
    cache = bridge.__dict__.setdefault('_ccache', OrderedDict())
    if key in cache:
        cache.move_to_end(key)
        return
    cache[key] = data
    total = bridge.__dict__.get('_ccache_bytes', 0) + len(data)
    while total > CACHE_LIMIT and len(cache) > 1:
        _, old = cache.popitem(last=False)
        total -= len(old)
    bridge._ccache_bytes = total


async def _yield_to_short(bridge, short):
    """Lange Streams stellen keine NEUEN Requests, solange eine kurze Pflicht-Anfrage laeuft
    (Kodi wartet beim Start darauf). Hoechstens 15 s, damit nie etwas haengen bleibt."""
    if short:
        return
    waited = 0.0
    while bridge.__dict__.get('_short_active', 0) > 0 and waited < 15:
        await asyncio.sleep(0.05)
        waited += 0.05


async def stream_gen(bridge, chat, msg_id, start, end):
    """
    Async-Generator: liefert die Bytes start..end (inklusive). Ersatz fuer Bridge.stream_gen.
    Erwartet am Bridge-Objekt: .client (Telethon), ._get_message(chat, msg_id), ._entity(chat).

      1. Bereits entschluesselte Chunks kommen aus dem RAM-Cache (Kodi liest den Anfang oft 2x).
      2. Die ersten HEAD_CHUNKS Chunks werden strikt nacheinander geholt: bricht Kodi beim
         Sondieren ab, ist kaum etwas verschwendet.
      3. Danach holen n Worker reihum die weiteren Chunks parallel (Worker i: Chunk i, i+n, ...),
         sodass die Latenz pro Request das Streaming nicht bremst.
      4. Kurze begrenzte Anfragen (< 4 MiB) haben Vorrang: laufende lange Streams stellen
         waehrenddessen keine neuen Requests.
    """
    from telethon import utils
    from telethon.client.downloads import _DirectDownloadIter

    m = await bridge._get_message(chat, msg_id)
    ent = await bridge._entity(chat)
    n_opt = _parallel()

    info = utils._get_file_info(m.media)
    size = m.file.size
    cs = pick_chunk(start, end)
    aligned = (start // cs) * cs
    skip = start - aligned
    total = (end - aligned) // cs + 1               # so viele Chunks werden gebraucht
    ckey = (str(chat), int(msg_id), size, cs)
    short = (end - start + 1) < 4 * CHUNK
    if short:
        bridge._short_active = bridge.__dict__.get('_short_active', 0) + 1

    def make_iter(first, count, stride_chunks):
        return _DirectDownloadIter(
            bridge.client, count, file=info.location, dc_id=info.dc_id,
            offset=aligned + first * cs, stride=stride_chunks * cs, chunk_size=cs,
            request_size=cs, file_size=size, msg_data=(ent, int(msg_id)))

    async def raw_chunks():
        idx = 0
        while idx < total:                           # 1) Cache (absolute Chunk-Nummer als Schluessel)
            data = _cache_get(bridge, ckey + (aligned // cs + idx,))
            if data is None:
                break
            yield idx, data, True
            idx += 1
        head_end = min(total, idx + HEAD_CHUNKS)
        workers, queues, state = [], [], {'n': 0}

        async def worker(i):
            q = queues[i]
            first = head_end + i
            cnt = len(range(first, total, state['n']))
            it = make_iter(first, cnt, state['n'])
            try:
                while True:
                    await _yield_to_short(bridge, short)
                    try:
                        data = await it.__anext__()
                    except StopAsyncIteration:
                        break
                    await q.put(data)
                await q.put(None)
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa
                await q.put(e)
            finally:
                try:
                    await it.close()                 # geliehenen Sender zurueckgeben
                except Exception:
                    pass

        def start_parallel():
            if workers or head_end >= total:
                return
            state['n'] = max(1, min(n_opt, total - head_end))
            queues.extend(asyncio.Queue(maxsize=PREFETCH) for _ in range(state['n']))
            for i in range(state['n']):
                workers.append(asyncio.ensure_future(worker(i)))

        head_it = None
        try:
            if idx < head_end:                       # 2) sequentiell
                head_it = make_iter(idx, head_end - idx, 1)
                while idx < head_end:
                    await _yield_to_short(bridge, short)
                    try:
                        data = await head_it.__anext__()
                    except StopAsyncIteration:
                        return
                    if idx == head_end - 1:
                        start_parallel()             # Parallel-Phase erst jetzt anwerfen
                    yield idx, data, False
                    idx += 1
            for k in range(head_end, total):         # 3) parallel, in Reihenfolge ausliefern
                item = await queues[(k - head_end) % state['n']].get()
                if item is None:
                    return
                if isinstance(item, Exception):
                    raise item
                yield k, item, False
        finally:
            for t in workers:
                t.cancel()
            if workers:
                await asyncio.gather(*workers, return_exceptions=True)
            if head_it is not None:
                try:
                    await head_it.close()
                except Exception:
                    pass

    remaining = end - start + 1
    raw = raw_chunks()
    try:
        async for idx, data, cached in raw:
            if not cached and (len(data) == cs or aligned + idx * cs + len(data) >= size):
                _cache_put(bridge, ckey + (aligned // cs + idx,), bytes(data))
            chunk = data
            if skip:
                chunk = chunk[skip:]
                skip = 0
            if len(chunk) > remaining:
                chunk = chunk[:remaining]
            if chunk:
                yield chunk
                remaining -= len(chunk)
            if remaining <= 0:
                break
    finally:
        if short:
            bridge._short_active = max(0, bridge.__dict__.get('_short_active', 1) - 1)
        await raw.aclose()


# ======================================================================================
# 3) Messung (optional)
# ======================================================================================

class StreamMeter(object):
    """
    Misst im HTTP-Handler, ob der Stream auf Telegram wartet (Engpass) oder Kodi zuruckhaelt
    (alles gut) und schreibt alle 30 s eine Zeile ins Log:
      stream msg=.. Durchsatz X MB/s | wartet auf Telegram Y% | Kodi-Puffer voll Z% | Stocker >1s: N
    """

    def __init__(self, log, msg, interval=30.0):
        self.log, self.msg, self.interval = log, msg, interval
        self.t0 = self._last = time.time()
        self.sent = self._last_sent = 0
        self.wait_t = self.write_t = self._last_wait = self._last_write = 0.0
        self.stalls = 0

    def waited(self, secs):
        """Zeit, die auf den naechsten Chunk von Telegram gewartet wurde."""
        self.wait_t += secs
        if self.sent and secs > 1.0:
            self.stalls += 1

    def wrote(self, secs, nbytes):
        """Zeit, die das Schreiben an Kodi dauerte (blockiert, wenn Kodis Puffer voll ist)."""
        self.write_t += secs
        self.sent += nbytes
        now = time.time()
        if now - self._last >= self.interval:
            span = now - self._last
            self.log('stream msg=%s Durchsatz %.2f MB/s | wartet auf Telegram %.0f%% | '
                     'Kodi-Puffer voll %.0f%% | Stocker >1s: %d'
                     % (self.msg, (self.sent - self._last_sent) / span / 1e6,
                        100 * (self.wait_t - self._last_wait) / span,
                        100 * (self.write_t - self._last_write) / span, self.stalls))
            self._last, self._last_sent = now, self.sent
            self._last_wait, self._last_write = self.wait_t, self.write_t

    def summary(self):
        return 'Telegram-Wartezeit %.1fs, Stocker >1s: %d' % (self.wait_t, self.stalls)
