# -*- coding: utf-8 -*-
# Telegram Scraper
# Copyright (c) 2026 Team IT('s) Possible. All rights reserved.
# Version 2026.10.11
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
import sys, urllib.parse, urllib.request, json, os, asyncio, re, html, zipfile
import secrets, threading
from datetime import datetime
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_url = sys.argv[0] if sys.argv[0] and sys.argv[0].startswith('plugin://') else f"plugin://{addon_id}/"

try:
    addon_handle = int(sys.argv[1])
except Exception:
    addon_handle = -1

PROP_PORT = 'telegramscraper.port'
PROP_TOKEN = 'telegramscraper.token'
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 and sys.argv[2] else {}
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
icon_path = os.path.join(addon_path, 'icon.png')
lib_path = os.path.join(addon_path, 'resources', 'lib')

if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

profile_dir = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(profile_dir):
    xbmcvfs.mkdirs(profile_dir)

CHANNELS_FILE = os.path.join(profile_dir, 'channels.json')
thumbs_dir = os.path.join(profile_dir, 'thumbs')

if not xbmcvfs.exists(thumbs_dir):
    xbmcvfs.mkdirs(thumbs_dir)


def set_kodi_info(item, title=None, plot=None):
    try:
        info = item.getVideoInfoTag()
        if title: info.setTitle(title)
        if plot: info.setPlot(plot)
    except AttributeError:
        kwargs = {}
        if title: kwargs['title'] = title
        if plot: kwargs['plot'] = plot
        if kwargs: item.setInfo('video', kwargs)

def exit_addon():
    try:
        xbmc.executebuiltin('Dialog.Close(all, true)')
        xbmc.executebuiltin('ActivateWindow(home)')
    except Exception as e:
        xbmc.log(f"Exit Fehler: {e}", xbmc.LOGERROR)

def finish_action():
    if addon_handle < 0:
        return
    try:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    except Exception as e:
        xbmc.log(f"finish_action: {e}", xbmc.LOGDEBUG)


def get_setting_int(setting_id, default_val):
    try:
        val = addon.getSetting(setting_id).strip()
        return int(val) if val.isdigit() and int(val) > 0 else default_val
    except Exception:
        return default_val

def get_download_path():
    custom_path = addon.getSetting('download_path').strip()
    path = custom_path if custom_path else "storage/emulated/0/Download/Telegram/Kodi/"
    translated_path = xbmcvfs.translatePath(path)
    if not xbmcvfs.exists(translated_path):
        try:
            xbmcvfs.mkdirs(translated_path)
        except Exception as e:
            xbmc.log(f"Download-Pfad Fehler: {e}", xbmc.LOGERROR)
    return translated_path

downloads_dir = get_download_path()

try:
    from telethon import TelegramClient
    from telethon import utils as tl_utils
    from telethon.sessions import StringSession
    from telethon.errors import SessionPasswordNeededError
    from telethon.tl.types import InputMessagesFilterDocument
    try:
        from telethon.tl.functions.channels import GetForumTopicsRequest
    except ImportError:
        try:
            from telethon.tl.functions.messages import GetForumTopicsRequest
        except ImportError:
            GetForumTopicsRequest = None
    TELETHON_AVAILABLE = True
except Exception as e:
    TELETHON_AVAILABLE = False
    InputMessagesFilterDocument = None
    GetForumTopicsRequest = None
    xbmc.log(f"TELETHON IMPORT FEHLER: {type(e).__name__}: {e}", xbmc.LOGERROR)

def get_telethon_client(api_id, api_hash):
    """Erstellt den passenden TelethonClient (StringSession ODER sqlite session file)."""
    session_txt = os.path.join(profile_dir, 'telegram.txt')
    if os.path.exists(session_txt):
        try:
            with open(session_txt, 'r', encoding='utf-8', errors='ignore') as f:
                s_str = f.read().strip()
            if s_str and not s_str.startswith('SQLite format 3'):
                return TelegramClient(
                    StringSession(s_str), int(api_id), api_hash,
                    device_model="Android Device", system_version="Android 12",
                    app_version="1.0.0", lang_code="de", system_lang_code="de"
                )
        except Exception as e:
            xbmc.log(f"StringSession Error: {e}", xbmc.LOGWARNING)

    session_file = os.path.join(profile_dir, 'session.txt')
    return TelegramClient(
        session_file, int(api_id), api_hash,
        device_model="Android Device", system_version="Android 12",
        app_version="1.0.0", lang_code="de", system_lang_code="de"
    )

def remove_emojis(text):
    if not text: return ""
    pattern = re.compile(r'[\U00010000-\U0010ffff]|[\u2600-\u27BF]|[\u2300-\u23FF]|[\u2B50\u2B55]', flags=re.UNICODE)
    return pattern.sub('', text)

def run_async(coro):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    except BaseException as e:
        xbmc.log(f"run_async Fehler: {type(e).__name__} - {str(e)}", xbmc.LOGERROR)
        return None
    finally:
        try:
            tasks = asyncio.all_tasks(loop=loop)
            for task in tasks: task.cancel()
            if tasks: loop.run_until_complete(asyncio.gather(*tasks, return_exceptions=True))
        except BaseException:
            pass
        try:
            loop.close()
        except BaseException:
            pass

def get_credentials():
    api_id = addon.getSetting('api_id').strip()
    api_hash = addon.getSetting('api_hash').strip()
    if not api_id.isdigit(): return None, None
    if len(api_hash) != 32: return None, None
    return api_id, api_hash

def show_api_help_dialog():
    msg = ("Du benötigst eigene Telegram API-Zugangsdaten:\n\n"
           "1. Gehe im Browser auf https://my.telegram.org\n"
           "2. Melde dich mit deiner Telefonnummer an.\n"
           "3. Klicke auf 'API development tools'.\n"
           "4. Erstelle eine App (Titel/Kurzname beliebig).\n"
           "5. Kopiere api_id und api_hash in die Einstellungen.")
    xbmcgui.Dialog().ok("Telegram API-Zugangsdaten fehlen", msg)

def normalize_chat_name(chat):
    if not chat: return ""
    value = str(chat).strip()
    if 't.me/c/' in value:
        parts = value.split('t.me/c/', 1)[1].split('/')
        cid = parts[0]
        if cid.isdigit(): return int(f"-100{cid}")
    if 't.me/' in value: value = value.split('t.me/', 1)[1]
    if value.startswith('s/'): value = value[2:]
    if value.startswith('/'): value = value[1:]
    if value.startswith('@'): value = value[1:]
    value = value.split('?', 1)[0].rstrip('/')
    if value.lstrip('-').isdigit(): return int(value)
    return value

async def get_entity_safe(client, chat_identifier, access_hash=None):
    clean_chat = normalize_chat_name(chat_identifier)
    if clean_chat == "" or clean_chat is None:
        return None
    is_id = isinstance(clean_chat, int)
    wanted = str(clean_chat).lower().lstrip('@')

    if is_id:
        try:
            return await client.get_entity(clean_chat)
        except Exception:
            pass
        raw = abs(clean_chat)
        s = str(raw)
        if access_hash is not None:
            try:
                if s.startswith('100') and len(s) > 12:
                    from telethon.tl.functions.channels import GetChannelsRequest
                    from telethon.tl.types import InputChannel
                    ch_id = int(s[3:])
                    r = await client(GetChannelsRequest([InputChannel(ch_id, int(access_hash))]))
                    if getattr(r, 'chats', None):
                        return r.chats[0]
                else:
                    from telethon.tl.functions.messages import GetChatsRequest
                    r = await client(GetChatsRequest([raw]))
                    if getattr(r, 'chats', None):
                        return r.chats[0]
            except Exception:
                pass

    async def search_dialogs():
        try:
            async for dialog in client.iter_dialogs(limit=1000):
                uname = (getattr(dialog.entity, 'username', '') or '').lower()
                d_name = (dialog.name or '').strip().lower()
                if (str(dialog.id) in (str(clean_chat), f"-100{clean_chat}")
                        or (uname and uname == wanted)
                        or (d_name and d_name == wanted)):
                    return dialog.entity
        except Exception as e:
            xbmc.log(f"get_entity_safe Dialogsuche: {e}", xbmc.LOGWARNING)
        return None

    try:
        return await client.get_entity(clean_chat)
    except Exception as e:
        xbmc.log(f"get_entity_safe get_entity({clean_chat}): {e}", xbmc.LOGDEBUG)
    entity = await search_dialogs()
    return entity

async def verify_login_status():
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash: return False
    auth_ok_file = os.path.join(profile_dir, 'auth_ok')
    client = get_telethon_client(api_id, api_hash)
    try:
        await client.connect()
        result = await client.is_user_authorized()
        if result:
            with open(auth_ok_file, 'w', encoding='utf-8') as f: f.write('ok')
            try:
                me = await client.get_me()
                if me:
                    uname = me.username or me.first_name or "User"
                    if me.username and not uname.startswith('@'): uname = f"@{uname}"
                    with open(os.path.join(profile_dir, 'username.txt'), 'w', encoding='utf-8') as f: f.write(uname)
            except Exception:
                pass
        return result
    except Exception as e:
        xbmc.log(f"Login Check Fehler: {e}", xbmc.LOGERROR)
        return False
    finally:
        try: await client.disconnect()
        except BaseException: pass

def is_logged_in():
    auth_ok_file = os.path.join(profile_dir, 'auth_ok')
    username_file = os.path.join(profile_dir, 'username.txt')
    session_sqlite = os.path.join(profile_dir, 'session.txt.session')
    session_txt = os.path.join(profile_dir, 'telegram.txt')

    has_session = os.path.exists(session_sqlite) or os.path.exists(session_txt)
    has_auth = os.path.exists(auth_ok_file) or os.path.exists(username_file)

    if has_session and has_auth:
        return True

    if not has_session:
        return False

    api_id, api_hash = get_credentials()
    if not (api_id and api_hash):
        return False
    if TELETHON_AVAILABLE:
        return bool(run_async(verify_login_status()))
    return False

def get_saved_username():
    username_file = os.path.join(profile_dir, 'username.txt')
    if os.path.exists(username_file):
        try:
            with open(username_file, 'r', encoding='utf-8') as f:
                val = f.read().strip()
                if val: return val
        except Exception:
            pass
    return "User"

def load_credentials_from_txt():
    txt_path = '/storage/emulated/0/Download/tg.txt'
    if not os.path.exists(txt_path):
        return False
    try:
        with open(txt_path, 'r', encoding='utf-8') as f:
            lines = [l.strip() for l in f.readlines()]
        lines = [l for l in lines if l and not l.startswith('#')]
        if len(lines) < 2:
            return False
        phone = lines[0]
        api_id = lines[1]
        api_hash = lines[2] if len(lines) > 2 else ''
        rsa_key = ''
        for i, l in enumerate(lines):
            if l.lower().startswith('rsa:'):
                rsa_key = l[4:].strip()
                break
            elif i >= 3:
                rsa_key = l
                break
        if not api_id.isdigit():
            xbmcgui.Dialog().notification("tg.txt", "Ungültige API ID in tg.txt", xbmcgui.NOTIFICATION_WARNING, 4000)
            return False
        if api_hash and len(api_hash) != 32:
            xbmcgui.Dialog().notification("tg.txt", "Ungültiger API Hash in tg.txt (muss 32 Zeichen haben)", xbmcgui.NOTIFICATION_WARNING, 4000)
            return False
        addon.setSetting('phone_number', phone)
        addon.setSetting('api_id', api_id)
        if api_hash:
            addon.setSetting('api_hash', api_hash)
        xbmcgui.Dialog().notification("tg.txt", "Zugangsdaten aus tg.txt geladen", xbmcgui.NOTIFICATION_INFO, 3000)
        return (phone, api_id, api_hash)
    except Exception as e:
        xbmc.log(f"tg.txt Lesefehler: {e}", xbmc.LOGERROR)
        return False

async def run_telethon_phone_login(direct_api_id=None, direct_api_hash=None, direct_phone=None):
    if direct_api_id and direct_api_hash:
        api_id, api_hash = str(direct_api_id), str(direct_api_hash)
    else:
        api_id, api_hash = get_credentials()
    if not api_id or not api_hash:
        show_api_help_dialog()
        addon.openSettings()
        return False

    session_file = os.path.join(profile_dir, 'session.txt')
    session_txt = os.path.join(profile_dir, 'telegram.txt')
    if os.path.exists(session_txt):
        try: os.remove(session_txt)
        except Exception: pass

    client = TelegramClient(session_file, int(api_id), api_hash)
    await client.connect()

    if not await client.is_user_authorized():
        phone = direct_phone or addon.getSetting('phone_number').strip()
        if not phone:
            phone = xbmcgui.Dialog().input("Telegram Telefonnummer (z.B. +491701234567)", type=xbmcgui.INPUT_ALPHANUM)
        if not phone:
            await client.disconnect()
            return False

        phone = phone.strip().replace(" ", "")
        try:
            await client.send_code_request(phone)
        except Exception as e:
            xbmcgui.Dialog().ok("Fehler", f"Code konnte nicht gesendet werden:\n{e}")
            await client.disconnect()
            return False

        code = xbmcgui.Dialog().input("Telegram Bestätigungscode")
        if not code:
            await client.disconnect()
            return False

        code = code.strip()
        try:
            await client.sign_in(phone, code)
        except SessionPasswordNeededError:
            password = xbmcgui.Dialog().input("Telegram 2FA Passwort", type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if not password:
                await client.disconnect()
                return False
            try:
                await client.sign_in(password=password.strip())
            except Exception as e:
                xbmcgui.Dialog().ok("2FA Fehler", f"Passwort falsch:\n{e}")
                await client.disconnect()
                return False
        except Exception as e:
            xbmcgui.Dialog().ok("Login Fehler", f"Anmeldung fehlgeschlagen:\n{e}")
            await client.disconnect()
            return False

    is_authed = await client.is_user_authorized()
    if is_authed:
        try:
            me = await client.get_me()
            if me:
                uname = me.username or me.first_name or "User"
                if me.username and not uname.startswith('@'): uname = f"@{uname}"
                with open(os.path.join(profile_dir, 'username.txt'), 'w', encoding='utf-8') as f: f.write(uname)
        except Exception:
            pass
        try:
            from telethon.sessions import StringSession
            session_string = StringSession.save(client.session)
            session_txt_path = os.path.join(profile_dir, 'telegram.txt')
            with open(session_txt_path, 'w', encoding='utf-8') as f: f.write(session_string)
        except Exception as e:
            xbmc.log(f"StringSession Export Fehler: {e}", xbmc.LOGWARNING)
        auth_file = os.path.join(profile_dir, 'auth_ok')
        try:
            with open(auth_file, 'w', encoding='utf-8') as f: f.write('ok')
        except Exception: pass
        xbmcgui.Dialog().notification("Telegram Scraper", "Erfolgreich eingeloggt", xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().ok("Fehler", "Anmeldung konnte nicht verifiziert werden.")

    await client.disconnect()
    return is_authed

def login_with_string_session():
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash:
        show_api_help_dialog()
        addon.openSettings()
        return
    code_file_path = os.path.join(get_download_path(), 'code.txt')
    session_key = ""

    if os.path.exists(code_file_path):
        try:
            with open(code_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                session_key = f.read()
        except Exception as e:
            xbmcgui.Dialog().ok("Fehler", f"Konnte code.txt nicht lesen:\n{e}")

    if not session_key:
        session_key = xbmcgui.Dialog().input("StringSession Key einfügen:")

    if session_key:
        session_key = session_key.strip().replace('\r', '').replace('\n', '').replace(' ', '').replace('"', '').replace("'", "")
        session_txt = os.path.join(profile_dir, 'telegram.txt')
        with open(session_txt, 'w', encoding='utf-8') as f: f.write(session_key)
        try:
            if run_async(verify_login_status()):
                xbmcgui.Dialog().notification("Telegram Scraper", "Login erfolgreich!", xbmcgui.NOTIFICATION_INFO, 3000)
                if os.path.exists(code_file_path):
                    try: os.remove(code_file_path)
                    except Exception: pass
            else:
                xbmcgui.Dialog().ok("Login Fehler", "Telegram hat die Sitzung abgelehnt (is_user_authorized = False).")
        except Exception as e:
            xbmcgui.Dialog().ok("Telethon Fehler", f"Details zum Fehler:\n{type(e).__name__}: {e}")
        xbmc.executebuiltin('Container.Refresh')

def handle_login_flow():
    choice = xbmcgui.Dialog().select("Telegram Login Methode wählen", [
        "1. Telefonnummer & Bestätigungscode (Telethon Login)",
        "2. StringSession / Key Code (code.txt oder Tastatur)"
    ])
    if choice == 0:
        run_async(run_telethon_phone_login())
    elif choice == 1:
        login_with_string_session()
    if choice >= 0:
        finish_action()
        xbmc.executebuiltin(f'Container.Update({addon_url},replace)')

def logout():
    for filename in ('session.txt', 'auth_ok', 'username.txt', 'session.txt.session', 'session.txt.session-journal', 'telegram.txt'):
        path = os.path.join(profile_dir, filename)
        if os.path.exists(path):
            try: os.remove(path)
            except Exception: pass
    addon.setSetting('api_id', '')
    addon.setSetting('api_hash', '')
    addon.setSetting('phone_number', '')
    xbmcgui.Dialog().notification("Telegram Scraper", "Abgemeldet", xbmcgui.NOTIFICATION_INFO, 3000)
    finish_action()
    xbmc.executebuiltin(f'Container.Update({addon_url},replace)')

def load_channels():
    if not os.path.exists(CHANNELS_FILE): return []
    try:
        with open(CHANNELS_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return []

def save_channels(channels):
    try:
        with open(CHANNELS_FILE, 'w', encoding='utf-8') as f:
            json.dump(channels, f, ensure_ascii=False, indent=4)
    except Exception as e:
        xbmc.log(f"Telegram Save Error: {e}", xbmc.LOGERROR)

async def resolve_chat_async(value):
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash: return None
    client = get_telethon_client(int(api_id), api_hash)
    try:
        await client.connect()
        if not await client.is_user_authorized(): return None
        entity = await get_entity_safe(client, value)
        if not entity: return None
        username = getattr(entity, 'username', None)
        title = getattr(entity, 'title', None)
        if not title:
            parts = [getattr(entity, 'first_name', None), getattr(entity, 'last_name', None)]
            title = ' '.join(p for p in parts if p)
        title = remove_emojis(title or '').strip() or username or str(value)
        identifier = f"@{username}" if username else str(tl_utils.get_peer_id(entity))
        ah = getattr(entity, 'access_hash', None)
        result = {'name': title, 'url': identifier}
        if ah is not None and not username:
            result['access_hash'] = ah
        return result
    except Exception as e:
        xbmc.log(f"resolve_chat_async Fehler: {type(e).__name__}: {e}", xbmc.LOGERROR)
        return None
    finally:
        try: await client.disconnect()
        except BaseException: pass

def add_to_kodi_favourites(name, plugin_url, thumb=''):
    try:
        n = name.replace('"', '\\"')
        u = plugin_url.replace('"', '\\"')
        t = (thumb or icon_path).replace('"', '\\"')
        xbmc.executebuiltin(f'AddFavourite("{n}","media","{u}","{t}")')
        xbmcgui.Dialog().notification("Telegram Scraper", f"Kodi-Favoriten: {name}", xbmcgui.NOTIFICATION_INFO, 2000)
    except Exception as e:
        xbmc.log(f"Kodi-Favoriten Fehler: {e}", xbmc.LOGERROR)

def ask_and_save_channel(name, url, access_hash=None):
    channel_plugin_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(url))}"
    choice = xbmcgui.Dialog().select(
        f"'{name}' hinzufügen zu:",
        ["★  Addon-Favoriten (Eigene Favoriten)", "⭐  Kodi-Favoriten"]
    )
    if choice == 0:
        channels = load_channels()
        if any(ch.get('url') == url for ch in channels):
            xbmcgui.Dialog().ok("Hinweis", "Dieser Kanal ist bereits in den Addon-Favoriten.")
            return
        entry = {'name': name, 'url': url, 'category': 'Eigene Favoriten'}
        if access_hash is not None:
            entry['access_hash'] = access_hash
        channels.append(entry)
        save_channels(channels)
        xbmcgui.Dialog().notification("Telegram Scraper", f"Addon-Favoriten: {name}", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('Container.Refresh')
    elif choice == 1:
        add_to_kodi_favourites(name, channel_plugin_url)

def add_new_channel():
    default = "kodi_reloaded" if not load_channels() else ""
    value = xbmcgui.Dialog().input("Kanalname, Link oder @kanal", defaultt=default)
    if not value: return
    value = value.strip()
    resolved = None
    if TELETHON_AVAILABLE and is_logged_in():
        resolved = run_async(resolve_chat_async(value))
    if resolved:
        name, url = resolved['name'], resolved['url']
        access_hash = resolved.get('access_hash')
    else:
        name = value.split('/')[-1].replace('@', '')
        url = f"@{name}"
        access_hash = None
    ask_and_save_channel(name, url, access_hash)

async def fetch_dialogs_async():
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash: return []
    client = get_telethon_client(api_id, api_hash)
    dialogs_list = []
    try:
        await client.connect()
        if not await client.is_user_authorized(): return []
        async for dialog in client.iter_dialogs(limit=300):
            name = dialog.name or str(dialog.id)
            name = remove_emojis(name).strip() or str(dialog.id)
            username = getattr(dialog.entity, 'username', None)
            identifier = f"@{username}" if username else str(dialog.id)
            dialogs_list.append({'name': name, 'url': identifier})
    except Exception as e:
        xbmc.log(f"Dialogs Error: {e}", xbmc.LOGERROR)
    finally:
        try: await client.disconnect()
        except BaseException: pass
    return dialogs_list

def add_friend_dialog():
    if not is_logged_in():
        xbmcgui.Dialog().ok("Telegram", "Bitte zuerst einloggen, um Freunde/Chats auszuwählen.")
        return
    choice = xbmcgui.Dialog().select("Freund / Chat hinzufügen", [
        "Manuell per Name / @username / Link",
        "Aus Telegram-Dialogen auswählen"
    ])
    if choice == 0:
        add_new_channel()
    elif choice == 1:
        dialogs = run_async(fetch_dialogs_async())
        if not dialogs:
            xbmcgui.Dialog().ok("Hinweis", "Keine Dialoge gefunden.")
            return
        names = [d['name'] for d in dialogs]
        sel = xbmcgui.Dialog().select("Wähle einen Chat / Freund", names)
        if sel >= 0:
            chosen = dialogs[sel]
            ask_and_save_channel(chosen['name'], chosen['url'])

async def send_telethon_message_async(chat_identifier, text, topic_id=None):
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash: return False
    client = get_telethon_client(api_id, api_hash)
    success = False
    try:
        await client.connect()
        if not await client.is_user_authorized(): return False
        entity = await get_entity_safe(client, chat_identifier)
        kwargs = {}
        if topic_id: kwargs['reply_to'] = int(topic_id)
        await client.send_message(entity, text, **kwargs)
        xbmcgui.Dialog().notification("Telegram Scraper", "Nachricht erfolgreich gesendet", xbmcgui.NOTIFICATION_INFO, 3000)
        success = True
    except Exception as e:
        xbmcgui.Dialog().ok("Fehler", f"Nachricht konnte nicht gesendet werden:\n{e}")
    finally:
        try: await client.disconnect()
        except BaseException: pass
    return success

def handle_send_message(chat_identifier, topic_id=None):
    if not chat_identifier: return
    text = xbmcgui.Dialog().input("Nachricht eingeben:")
    if text:
        success = run_async(send_telethon_message_async(chat_identifier, text, topic_id=topic_id))
        if success:
            xbmc.executebuiltin('Container.Refresh')

async def send_telethon_file_async(chat_identifier, file_path, caption=""):
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash: return False
    client = get_telethon_client(api_id, api_hash)
    dialog = xbmcgui.DialogProgress()
    dialog.create("Telegram Upload", "Vorbereitung...")
    cancelled = [False]

    def progress(current, total):
        if dialog.iscanceled():
            cancelled[0] = True
            return
        if total:
            percent = int(current * 100 / total)
            dialog.update(percent, f"Lade hoch... {percent}%")
        else:
            dialog.update(0, "Lade hoch...")

    success = False
    try:
        await client.connect()
        if not await client.is_user_authorized():
            dialog.close()
            xbmcgui.Dialog().ok("Telegram", "Bitte zuerst einloggen.")
            return False

        entity = await get_entity_safe(client, chat_identifier)
        if not entity:
            dialog.close()
            xbmcgui.Dialog().ok("Fehler", "Ziel-Chat konnte nicht gefunden werden.")
            return False

        upload_task = asyncio.create_task(client.send_file(entity, file_path, caption=caption, progress_callback=progress))
        while not upload_task.done():
            await asyncio.sleep(0.5)
            if dialog.iscanceled():
                cancelled[0] = True
                upload_task.cancel()
                break

        if cancelled[0]:
            dialog.close()
            xbmcgui.Dialog().notification("Telegram Scraper", "Upload abgebrochen", xbmcgui.NOTIFICATION_INFO, 2000)
            return False

        await upload_task
        dialog.close()
        xbmcgui.Dialog().notification("Telegram Scraper", "Datei erfolgreich gesendet!", xbmcgui.NOTIFICATION_INFO, 3000)
        success = True
    except asyncio.CancelledError:
        pass
    except Exception as e:
        dialog.close()
        xbmc.log(f"Telethon Upload Error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Fehler", f"Datei konnte nicht gesendet werden:\n{e}")
    finally:
        try: await client.disconnect()
        except BaseException: pass
    return success

def handle_send_file_action(file_path):
    if not file_path or not os.path.exists(file_path):
        xbmcgui.Dialog().ok("Fehler", "Die ausgewählte Datei existiert nicht.")
        return

    if not is_logged_in():
        xbmcgui.Dialog().ok("Telegram", "Bitte zuerst einloggen, um Dateien zu senden.")
        return

    channels = load_channels()
    options = ["Manuell eingeben (Name, Link oder @kanal)"]
    targets = [None]
    
    for ch in channels:
        options.append(f"Kanal/Chat: {ch.get('name', ch.get('url'))}")
        targets.append(ch.get('url'))

    sel = xbmcgui.Dialog().select("Wohin soll die Datei gesendet werden?", options)
    if sel < 0: return

    if sel == 0:
        chat_target = xbmcgui.Dialog().input("Ziel-Chat eingeben (z.B. @kanal oder Name):")
    else:
        chat_target = targets[sel]

    if not chat_target: return

    caption = xbmcgui.Dialog().input("Optionale Bildunterschrift / Text (optional):")
    success = run_async(send_telethon_file_async(chat_target, file_path, caption=caption))
    if success:
        xbmc.executebuiltin('Container.Refresh')

def delete_channel(channel_url):
    channels = [ch for ch in load_channels() if ch.get('url') != channel_url]
    save_channels(channels)
    xbmcgui.Dialog().notification("Telegram Scraper", "Kanal gelöscht", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')

def remove_from_fav(channel_url, topic_id=None):
    channels = [ch for ch in load_channels() if ch.get('url') != channel_url]
    save_channels(channels)
    xbmcgui.Dialog().notification("Telegram Scraper", "Aus Favoriten entfernt", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')

def move_to_addon_favourites(channel_url, name, topic_id=None):
    channels = load_channels()
    already = next((ch for ch in channels if ch.get('url') == channel_url and ch.get('topic_id') == topic_id), None)
    if already and already.get('category') == 'Eigene Favoriten':
        xbmcgui.Dialog().notification("Telegram Scraper", "Bereits in Eigene Favoriten", xbmcgui.NOTIFICATION_INFO, 2000)
        return
    if already:
        already['category'] = 'Eigene Favoriten'
    else:
        entry = {'name': name, 'url': channel_url, 'category': 'Eigene Favoriten'}
        if topic_id is not None:
            entry['topic_id'] = topic_id
        channels.append(entry)
    save_channels(channels)
    xbmcgui.Dialog().notification("Telegram Scraper", f"Zu Eigene Favoriten: {name}", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')

def _fav_tid(topic_id_str):
    try:
        return int(topic_id_str) if topic_id_str and str(topic_id_str).strip().isdigit() else None
    except Exception:
        return None

def _fav_refresh():
    cat = urllib.parse.quote('Eigene Favoriten')
    xbmc.executebuiltin(f'Container.Update(plugin://{addon_id}/?action=show_category&cat={cat},replace)')

def fav_reorder(url, topic_id_str, direction):
    try:
        channels = load_channels()
        topic_id = _fav_tid(topic_id_str)
        fav = [ch for ch in channels if ch.get('category', 'Eigene Favoriten') == 'Eigene Favoriten']
        other = [ch for ch in channels if ch.get('category', 'Eigene Favoriten') != 'Eigene Favoriten']
        pos = next((p for p, ch in enumerate(fav) if str(ch.get('url', '')) == str(url) and ch.get('topic_id') == topic_id), None)
        if pos is None:
            xbmc.log(f'fav_reorder: url={url!r} topic={topic_id!r} nicht gefunden', xbmc.LOGWARNING)
            return
        if direction == 'up' and pos > 0:
            fav[pos], fav[pos - 1] = fav[pos - 1], fav[pos]
        elif direction == 'down' and pos < len(fav) - 1:
            fav[pos], fav[pos + 1] = fav[pos + 1], fav[pos]
        elif direction == 'top':
            fav.insert(0, fav.pop(pos))
        elif direction == 'bottom':
            fav.append(fav.pop(pos))
        else:
            return
        save_channels(other + fav)
        xbmc.sleep(150)
        _fav_refresh()
    except Exception as e:
        xbmc.log(f'fav_reorder Fehler: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Fehler', str(e), xbmcgui.NOTIFICATION_ERROR, 3000)

def fav_rename(url, topic_id_str):
    try:
        channels = load_channels()
        topic_id = _fav_tid(topic_id_str)
        ch = next((c for c in channels if str(c.get('url', '')) == str(url) and c.get('topic_id') == topic_id), None)
        if not ch:
            xbmc.log(f'fav_rename: url={url!r} topic={topic_id!r} nicht gefunden', xbmc.LOGWARNING)
            return
        new_name = xbmcgui.Dialog().input('Umbenennen', ch.get('name', ''))
        if new_name and new_name.strip():
            ch['name'] = new_name.strip()
            save_channels(channels)
            xbmc.sleep(150)
            _fav_refresh()
    except Exception as e:
        xbmc.log(f'fav_rename Fehler: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Fehler', str(e), xbmcgui.NOTIFICATION_ERROR, 3000)

AUTO_CATEGORY = 'Automatisch Hinzugefügt'

async def _auto_import_async():
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash:
        return None
    client = get_telethon_client(api_id, api_hash)
    results = []
    try:
        await client.connect()
        if not await client.is_user_authorized():
            return None
        async for dialog in client.iter_dialogs(limit=500):
            name = dialog.name or str(dialog.id)
            name = remove_emojis(name).strip() or str(dialog.id)
            username = getattr(dialog.entity, 'username', None)
            identifier = f"@{username}" if username else str(dialog.id)
            results.append({'name': name, 'url': identifier})
    except Exception as e:
        xbmc.log(f"Auto-Import Fehler: {e}", xbmc.LOGERROR)
        return None
    finally:
        try:
            await client.disconnect()
        except BaseException:
            pass
    return results

def auto_import_channels():
    if not is_logged_in():
        xbmcgui.Dialog().ok("Telegram", "Bitte zuerst einloggen.")
        return
    progress = xbmcgui.DialogProgress()
    progress.create("Automatisch Hinzufügen", "Lade Telegram-Kanäle...")
    dialogs = run_async(_auto_import_async())
    progress.close()
    if dialogs is None:
        xbmcgui.Dialog().ok("Fehler", "Konnte Kanäle nicht laden.")
        return
    channels = load_channels()
    existing_urls = {ch.get('url') for ch in channels}
    auto_urls = {ch.get('url') for ch in channels if ch.get('category') == AUTO_CATEGORY}
    current_dialog_urls = {d['url'] for d in dialogs}
    channels = [ch for ch in channels if not (ch.get('category') == AUTO_CATEGORY and ch.get('url') not in current_dialog_urls)]
    existing_urls_after = {ch.get('url') for ch in channels}
    added = 0
    for d in dialogs:
        if d['url'] not in existing_urls_after:
            channels.append({'name': d['name'], 'url': d['url'], 'category': AUTO_CATEGORY})
            added += 1
    save_channels(channels)
    xbmcgui.Dialog().notification(
        "Telegram Scraper",
        f"{len(dialogs)} Kanäle synchronisiert, {added} neu hinzugefügt",
        xbmcgui.NOTIFICATION_INFO, 3000
    )
    xbmc.executebuiltin('Container.Refresh')

def save_text_to_file(text):
    if not text:
        xbmcgui.Dialog().ok("Hinweis", "Kein Text vorhanden.")
        return
    filename = f"TG_Text_{int(datetime.now().timestamp())}.txt"
    target = os.path.join(get_download_path(), filename)
    try:
        with open(target, 'w', encoding='utf-8') as f:
            f.write(text)
        xbmcgui.Dialog().notification("Telegram Scraper", f"Text gespeichert: {filename}", xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as e:
        xbmcgui.Dialog().ok("Fehler", f"Text konnte nicht gespeichert werden:\n{e}")

def download_file_http(url, target_path):
    dialog = xbmcgui.DialogProgress()
    try:
        dialog.create("Download", "Lade Datei herunter...")
        request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=30) as response:
            total = int(response.getheader('Content-Length', 0))
            downloaded = 0
            with open(target_path, 'wb') as output:
                while True:
                    if dialog.iscanceled():
                        dialog.close()
                        try: os.remove(target_path)
                        except Exception: pass
                        xbmcgui.Dialog().notification("Telegram Scraper", "Download abgebrochen", xbmcgui.NOTIFICATION_INFO, 2000)
                        return False
                    block = response.read(64 * 1024)
                    if not block: break
                    output.write(block)
                    downloaded += len(block)
                    if total:
                        percent = int(downloaded * 100 / total)
                        dialog.update(percent, f"{percent}%")
        dialog.close()
        xbmcgui.Dialog().notification("Telegram Scraper", "Download abgeschlossen", xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    except Exception as e:
        dialog.close()
        xbmcgui.Dialog().ok("Download Fehler", str(e))
        return False

async def download_telethon_media_async(chat, msg_id, save_path):
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash: return None
    client = get_telethon_client(api_id, api_hash)
    dialog = xbmcgui.DialogProgress()
    dialog.create("Telegram Download", "Vorbereitung...")
    cancelled = [False]

    def progress(current, total):
        if dialog.iscanceled():
            cancelled[0] = True
            return
        if total:
            percent = int(current * 100 / total)
            dialog.update(percent, f"Lade herunter... {percent}%")
        else:
            dialog.update(0, "Lade herunter...")

    try:
        await client.connect()
        entity = await get_entity_safe(client, chat)
        message = await client.get_messages(entity, ids=int(msg_id))
        if message and message.media:
            download_task = asyncio.create_task(client.download_media(message, file=save_path, progress_callback=progress))
            while not download_task.done():
                await asyncio.sleep(0.5)
                if dialog.iscanceled():
                    cancelled[0] = True
                    download_task.cancel()
                    break
            if cancelled[0]:
                dialog.close()
                if os.path.exists(save_path):
                    try: os.remove(save_path)
                    except Exception: pass
                xbmcgui.Dialog().notification("Telegram Scraper", "Download abgebrochen", xbmcgui.NOTIFICATION_INFO, 2000)
                return None
            await download_task
            dialog.close()
            return save_path
    except asyncio.CancelledError:
        pass
    except Exception as e:
        xbmc.log(f"Telethon Download Error: {e}", xbmc.LOGERROR)
    finally:
        dialog.close()
        try: await client.disconnect()
        except BaseException: pass
        if os.path.exists(save_path) and cancelled[0]:
            try: os.remove(save_path)
            except Exception: pass
    return None

def download_media_action(item_data):
    media_type = item_data.get('type')
    url = item_data.get('url')
    msg_id = item_data.get('msg_id')
    chat = item_data.get('chat')
    file_name = item_data.get('file_name')
    if file_name:
        filename = f"TG_{msg_id}_{file_name}"
    else:
        extension = '.mp4' if media_type == 'video' else '.zip' if media_type == 'archive' else '.jpg'
        filename = f"TG_{msg_id or 'file'}_{int(datetime.now().timestamp())}{extension}"
    target = os.path.join(get_download_path(), filename)
    if chat and msg_id and TELETHON_AVAILABLE:
        res = run_async(download_telethon_media_async(chat, msg_id, target))
        if res:
            xbmcgui.Dialog().notification("Telegram Scraper", f"Gespeichert: {filename}", xbmcgui.NOTIFICATION_INFO, 3000)
            return
    elif url and url.startswith('http'):
        download_file_http(url, target)

def clean_url(url):
    return html.unescape(str(url)).strip().replace('&amp;', '&').strip('"\'') if url else ""

IMAGE_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.avif')
VIDEO_EXTENSIONS = ('.mp4', '.m4v', '.webm', '.mov', '.mkv', '.avi')

def is_image_url(url):
    url = clean_url(url)
    return bool(url and urllib.parse.urlsplit(url.lower()).path.endswith(IMAGE_EXTENSIONS))

def is_video_url(url):
    url = clean_url(url)
    return bool(url and urllib.parse.urlsplit(url.lower()).path.endswith(VIDEO_EXTENSIONS))

def extract_telegram_video_urls(page_content):
    if not page_content: return []
    results = []
    for tag_body in re.findall(r'<video\b[^>]*>(.*?)</video>', page_content, flags=re.IGNORECASE | re.DOTALL):
        for url in re.findall(r'(?:src|data-src|data-video-src)\s*=\s*[\'"]([^\'"]+)[\'"]', tag_body, flags=re.IGNORECASE):
            url = clean_url(url)
            if url.startswith('http') and not is_image_url(url) and (is_video_url(url) or 'telesco.pe/file/' in url) and url not in results:
                results.append(url)
    for url in re.findall(r'<source\b[^>]*(?:src|data-src)\s*=\s*[\'"]([^\'"]+)[\'"]', page_content, flags=re.IGNORECASE):
        url = clean_url(url)
        if url.startswith('http') and not is_image_url(url) and (is_video_url(url) or 'telesco.pe/file/' in url) and url not in results:
            results.append(url)
    for url in re.findall(r'(?:src|data-src|data-video-src)\s*=\s*[\'"](https?://[^\'"]+)[\'"]', page_content, flags=re.IGNORECASE):
        url = clean_url(url)
        if is_video_url(url) and not is_image_url(url) and url not in results:
            results.append(url)
    return results

def get_direct_telegram_stream_urls(chat, msg_id, url_hint=None):
    results = []
    if url_hint:
        hint = clean_url(url_hint)
        if hint.startswith('http') and not is_image_url(hint) and (is_video_url(hint) or 'telesco.pe/file/' in hint):
            results.append(hint)
            return results
    clean_chat = normalize_chat_name(chat)
    if not clean_chat or not msg_id: return results
    msg_id = str(msg_id).strip()
    candidate_urls = [
        f"https://t.me/{clean_chat}/{msg_id}?embed=1",
        f"https://t.me/{clean_chat}/{msg_id}",
        f"https://t.me/s/{clean_chat}/{msg_id}"
    ]
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8'
    }
    for page_url in candidate_urls:
        try:
            request = urllib.request.Request(page_url, headers=headers)
            with urllib.request.urlopen(request, timeout=8) as response:
                content = response.read().decode('utf-8', errors='ignore')
            for url in extract_telegram_video_urls(content):
                if url not in results and not is_image_url(url):
                    results.append(url)
            if results: break
        except Exception as e:
            xbmc.log(f"Telegram Player URL Fehler: {e}", xbmc.LOGDEBUG)
    return results

def build_kodi_stream_url(stream_url):
    stream_url = clean_url(stream_url)
    if not stream_url: return ""
    user_agent = urllib.parse.quote('Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36', safe='')
    referer = urllib.parse.quote('https://t.me/', safe='')
    return f"{stream_url}|User-Agent={user_agent}&Referer={referer}&Accept=*/*&Connection=keep-alive"

def get_proxy_stream_url(chat, msg_id, file_name=''):
    win = xbmcgui.Window(10000)
    port = win.getProperty(PROP_PORT)
    token = win.getProperty(PROP_TOKEN)
    if not port or not token: return None
    clean_chat = normalize_chat_name(chat)
    c_str = str(clean_chat) if clean_chat else ''
    m_str = str(msg_id) if msg_id else ''
    fn_str = str(file_name) if file_name else ''
    encoded_chat = urllib.parse.quote(c_str)
    encoded_file = urllib.parse.quote(fn_str)
    return f"http://127.0.0.1:{port}/stream?chat={encoded_chat}&msg={m_str}&file={encoded_file}&t={token}"

def play_telegram_video(item_data, chat=None, fallback_msg_id=None):
    if not item_data:
        xbmcgui.Dialog().ok("Fehler", "Keine Videodaten vorhanden.")
        return
    if item_data.get('type') != 'video':
        xbmcgui.Dialog().ok("Telegram", "Dieses Medium ist kein Video.")
        return
    msg_id = item_data.get('msg_id', fallback_msg_id)
    item_chat = item_data.get('chat', chat)
    title = item_data.get('title', 'Telegram Video') or 'Telegram Video'
    file_name = item_data.get('file_name', '')
    play_url = get_proxy_stream_url(item_chat, msg_id, file_name)
    if play_url:
        xbmc.log(f"Starte Video über Proxy: {play_url}", xbmc.LOGINFO)
    if not play_url:
        stream_urls = get_direct_telegram_stream_urls(item_chat, msg_id, item_data.get('url'))
        valid_urls = [url for url in stream_urls if url and not is_image_url(clean_url(url))]
        if valid_urls:
            play_url = build_kodi_stream_url(valid_urls[0])
    if not play_url:
        xbmcgui.Dialog().ok("Telegram Video", "Es konnte kein Wiedergabe-Stream ermittelt werden.")
        return
    play_item = xbmcgui.ListItem(label=title, path=play_url)
    play_item.setProperty('IsPlayable', 'true')
    try: play_item.setContentLookup(False)
    except Exception: pass
    set_kodi_info(play_item, title=title)
    xbmc.Player().play(play_url, play_item)

def handle_multi_media(media_list, text, chat=None, msg_id=None):
    options, actions = [], []
    for item in media_list:
        media_type = item.get('type')
        item_msg_id = item.get('msg_id', msg_id)
        file_name = item.get('file_name')
        if media_type == 'video':
            options.extend(["Video abspielen", "Video herunterladen"])
            actions.extend([('play_video', item), ('download', item)])
        elif media_type == 'photo':
            options.extend(["Bild anzeigen", "Bild herunterladen"])
            actions.extend([('show_image', item.get('url'), item_msg_id), ('download', item)])
        elif media_type == 'archive':
            options.append(f"Archiv herunterladen ({file_name})" if file_name else "Archiv herunterladen")
            actions.append(('download', item))
    if text:
        options.extend(["Vollständigen Text anzeigen", "Text als .txt speichern"])
        actions.extend([('show_text', text, None), ('save_text', text, None)])
    if not options: return
    selected = xbmcgui.Dialog().select("Telegram Beitrag", options)
    if selected < 0: return
    action_type = actions[selected][0]
    action_val = actions[selected][1]
    if action_type == 'play_video':
        play_telegram_video(action_val, chat=chat, fallback_msg_id=msg_id)
    elif action_type == 'show_image':
        image_msg_id = actions[selected][2]
        if chat and image_msg_id and TELETHON_AVAILABLE:
            image_file = os.path.join(thumbs_dir, f"img_{image_msg_id}.jpg")
            if not os.path.exists(image_file):
                run_async(download_telethon_media_async(chat, image_msg_id, image_file))
            if os.path.exists(image_file):
                xbmc.executebuiltin(f'ShowPicture({image_file})')
        elif action_val:
            xbmc.executebuiltin(f'ShowPicture({action_val})')
    elif action_type == 'download':
        download_media_action(action_val)
    elif action_type == 'show_text':
        xbmcgui.Dialog().textviewer("Telegram Nachricht", action_val)
    elif action_type == 'save_text':
        save_text_to_file(action_val)

def show_local_zip_addons():
    d_dir = get_download_path()
    if not xbmcvfs.exists(d_dir):
        xbmcgui.Dialog().ok("Eigene Dateien", "Der Download-Ordner existiert noch nicht.")
        return
    dirs, files = xbmcvfs.listdir(d_dir)
    zip_files = [f for f in files if f.lower().endswith('.zip')]
    if not zip_files:
        xbmcgui.Dialog().ok("Addon Installation", "Keine .zip-Dateien im Download-Ordner gefunden.\nLade zuerst ein Addon-Archiv herunter!")
        return
    selected_idx = xbmcgui.Dialog().select("Lokale Addons (.zip) installieren", zip_files)
    if selected_idx < 0: return
    chosen_zip = zip_files[selected_idx]
    zip_path = os.path.join(d_dir, chosen_zip)
    try:
        addons_dir = xbmcvfs.translatePath('special://home/addons/')
        addon_id_target = None
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(addons_dir)
            for name in zip_ref.namelist():
                parts = name.replace('\\', '/').split('/')
                if parts and parts[0]:
                    addon_id_target = parts[0]
                    break
        xbmcgui.Dialog().notification("Telegram Scraper", "Addon erfolgreich installiert & aktiviert!", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('UpdateLocalAddons')
        if addon_id_target:
            json_payload = json.dumps({
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": addon_id_target, "enabled": True},
                "id": 1
            })
            xbmc.executeJSONRPC(json_payload)
    except Exception as e:
        xbmc.log(f"Addon Installation Fehler: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Fehler", f"Addon konnte nicht installiert werden:\n{e}")

def is_first_start():
    return addon.getSetting('first_start_done').strip() != 'true'

def mark_first_start_done():
    addon.setSetting('first_start_done', 'true')

def show_manual(from_first_start=False):
    manual_path = os.path.join(addon_path, 'manual.md')
    if not os.path.exists(manual_path):
        xbmcgui.Dialog().ok("Handbuch", "Die Datei 'manual.md' wurde im Root-Ordner nicht gefunden.")
        return

    try:
        with open(manual_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        xbmcgui.Dialog().ok("Fehler", f"Konnte manual.md nicht lesen:\n{e}")
        return

    if not content.strip():
        content = "Kein Inhalt vorhanden."

    xbmcgui.Dialog().textviewer("Addon Handbuch", content)

    if from_first_start:
        mark_first_start_done()
        if not is_logged_in():
            xbmcgui.Dialog().ok("Willkommen", "Handbuch gelesen – bitte jetzt einloggen.")
            handle_login_flow()
        xbmc.executebuiltin('Container.Refresh')


def show_root_menu(selected_category=None):
    if selected_category is None and is_first_start():
        first_start_items = [
            ("[COLOR yellow]★[/COLOR] Addon Handbuch", f"{addon_url}?action=show_manual&first_start=1", False, "Bitte lesen Sie zuerst das Handbuch, bevor Sie fortfahren."),
            ("[COLOR blue]★[/COLOR] Addon schließen", f"{addon_url}?action=close_addon", False, "Schließt das Addon (ohne Logout)."),
        ]
        for label, url, is_folder, plot in first_start_items:
            item = xbmcgui.ListItem(label=label)
            item.setArt({'icon': icon_path, 'thumb': icon_path})
            set_kodi_info(item, plot=plot)
            if not is_folder:
                item.setProperty('IsPlayable', 'false')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=item, isFolder=is_folder)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        return

    if selected_category is None:
        logged_in = is_logged_in()
        username = get_saved_username() if logged_in else "User"
        def _menu_on(setting_id):
            return addon.getSetting(setting_id).lower() != 'false'

        all_items = [
            (
                f"[COLOR blue]★[/COLOR] Status: [COLOR blue]{username}[/COLOR] Angemeldet" if logged_in else "[COLOR blue]★[/COLOR] Status: User Abgemeldet (Klick zum Einloggen)",
                f"?action={'logout' if logged_in else 'login'}",
                False,
                "Hier sehen Sie Ihren aktuellen Anmeldestatus und können sich an- oder abmelden.",
                None
            ),
            ("[COLOR blue]★[/COLOR] Einstellungen öffnen", "?action=settings", False, "Konfigurieren Sie die API-Zugangsdaten, Download-Pfade und weitere Optionen.", "menu_settings"),
            ("[COLOR blue]★[/COLOR] Kanal hinzufügen", "?action=add_channel", False, "Fügen Sie einen neuen Telegram-Kanal oder Chat über den Namen oder Link hinzu.", "menu_add_channel"),
            ("[COLOR blue]★[/COLOR] Freund / Chat hinzufügen", "?action=add_friend", False, "Fügen Sie einen Freund oder Chat (aus Dialogen oder per Eingabe) zu Ihren Favoriten hinzu.", "menu_add_friend"),
            ("[COLOR blue]★[/COLOR] Eigene Dateien", "?action=show_downloads", True, "Verwalten und öffnen Sie Ihre heruntergeladenen Medien, Dokumente und Textdateien.", "menu_downloads"),
            ("[COLOR blue]★[/COLOR] Eigene Favoriten", "?action=show_category&cat=" + urllib.parse.quote('Eigene Favoriten'), True, "Durchsuchen Sie Ihre gespeicherten Favoriten-Kanäle.", "menu_favorites"),
            ("[COLOR blue]★[/COLOR] Automatisch Hinzugefügt", "?action=show_category&cat=" + urllib.parse.quote(AUTO_CATEGORY), True, "Alle Telegram-Kanäle und Chats, denen Sie beigetreten sind.", "menu_auto_folder"),
            ("[COLOR blue]★[/COLOR] Kanäle automatisch importieren", "?action=auto_import", False, "Importiert automatisch alle Telegram-Kanäle und Gruppen in den Ordner 'Automatisch Hinzugefügt'.", "menu_auto_import"),
            ("[COLOR blue]★[/COLOR] Addons installieren", "?action=install_zip", False, "Installieren Sie lokale Addon-Pakete direkt aus dem Download-Ordner.", "menu_install_zip"),
            ("[COLOR blue]★[/COLOR] Addon Handbuch", "?action=show_manual", False, "Zeigt die Bedienungsanleitung (manual.md) im Vollbild an.", "menu_manual"),
            ("[COLOR blue]★[/COLOR] Addon schließen", "?action=close_addon", False, "Schließt das Addon (ohne Logout).", "menu_close")
        ]
        items = [(label, query, is_folder, plot) for label, query, is_folder, plot, sid in all_items if sid is None or _menu_on(sid)]
        for label, query, is_folder, plot in items:
            item = xbmcgui.ListItem(label=label)
            item.setArt({'icon': icon_path, 'thumb': icon_path})
            
            set_kodi_info(item, plot=plot)
            
            if not is_folder:
                item.setProperty('IsPlayable', 'false')
                
            xbmcplugin.addDirectoryItem(
                handle=addon_handle, 
                url=f"{addon_url}{query}", 
                listitem=item, 
                isFolder=is_folder
            )
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        return


    main_menu_item = xbmcgui.ListItem(label="[COLOR cyan] Hauptmenü[/COLOR]")
    main_menu_item.setArt({'icon': icon_path, 'thumb': icon_path})
    set_kodi_info(main_menu_item, plot="Zurück zum Hauptmenü.")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=addon_url, listitem=main_menu_item, isFolder=True)

    channels = [ch for ch in load_channels() if ch.get('category', 'Eigene Favoriten') == selected_category]
    for channel in channels:
        channel_url = channel.get('url')
        name = channel.get('name', channel_url)
        item = xbmcgui.ListItem(label=name)
        item.setArt({'icon': icon_path, 'thumb': icon_path})
        set_kodi_info(item, plot=f"Öffnen Sie den Kanal {name}, um die neuesten Beiträge und Medien anzuzeigen.")
        _topic_id = channel.get('topic_id')
        _tid_param = f"&topic_id={_topic_id}" if _topic_id is not None else ""
        _enc_url = urllib.parse.quote(str(channel_url))
        _enc_name = urllib.parse.quote(name)
        if selected_category == 'Eigene Favoriten':
            _kanal_cm_entry = ("Kanal entfernen", f"RunPlugin({addon_url}?action=remove_from_fav&url={_enc_url}{_tid_param})")
        else:
            _kanal_cm_entry = ("Kanal löschen", f"RunPlugin({addon_url}?action=delete_channel&url={_enc_url})")
        _cm = [
            ("Nachricht senden", f"RunPlugin({addon_url}?action=send_message&url={_enc_url})"),
            ("Zu Eigene Favoriten", f"RunPlugin({addon_url}?action=move_to_fav&url={_enc_url}&name={_enc_name}{_tid_param})"),
            _kanal_cm_entry
        ]
        if selected_category == 'Eigene Favoriten':
            _cm += [
                ("Nach oben", f"RunPlugin({addon_url}?action=fav_reorder&url={_enc_url}&direction=up{_tid_param})"),
                ("Nach unten", f"RunPlugin({addon_url}?action=fav_reorder&url={_enc_url}&direction=down{_tid_param})"),
                ("Ganz nach oben", f"RunPlugin({addon_url}?action=fav_reorder&url={_enc_url}&direction=top{_tid_param})"),
                ("Ganz nach unten", f"RunPlugin({addon_url}?action=fav_reorder&url={_enc_url}&direction=bottom{_tid_param})"),
                ("Umbenennen", f"RunPlugin({addon_url}?action=fav_rename&url={_enc_url}{_tid_param})")
            ]
        item.addContextMenuItems(_cm)
        _item_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(channel_url))}"
        if _topic_id:
            _item_url += f"&topic_id={_topic_id}"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=_item_url, listitem=item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
    return


    main_menu_item = xbmcgui.ListItem(label="[COLOR cyan] Hauptmenü[/COLOR]")
    main_menu_item.setArt({'icon': icon_path, 'thumb': icon_path})
    set_kodi_info(main_menu_item, plot="Zurück zum Hauptmenü.")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=addon_url, listitem=main_menu_item, isFolder=True)

    refresh_item = xbmcgui.ListItem(label="[COLOR yellow]Aktualisieren[/COLOR]")
    refresh_item.setArt({'icon': icon_path, 'thumb': icon_path})
    set_kodi_info(refresh_item, plot="Aktualisieren Sie die Ansicht.")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{addon_url}?action=show_category&cat={urllib.parse.quote(selected_category)}", listitem=refresh_item, isFolder=True)

    channels = [ch for ch in load_channels() if ch.get('category', 'Eigene Favoriten') == selected_category]
    for channel in channels:
        channel_url = channel.get('url')
        name = channel.get('name', channel_url)
        item = xbmcgui.ListItem(label=name)
        item.setArt({'icon': icon_path, 'thumb': icon_path})
        set_kodi_info(item, plot=f"Öffnen Sie den Kanal {name}, um die neuesten Beiträge und Medien anzuzeigen.")
        item.addContextMenuItems([
            ("Nachricht senden", f"RunPlugin({addon_url}?action=send_message&url={urllib.parse.quote(str(channel_url))})"),
            ("Zu Eigene Favoriten", f"RunPlugin({addon_url}?action=move_to_fav&url={urllib.parse.quote(str(channel_url))}&name={urllib.parse.quote(name)})"),
            ("Kanal löschen", f"RunPlugin({addon_url}?action=delete_channel&url={urllib.parse.quote(str(channel_url))})")
        ])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(channel_url))}", listitem=item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
    #return

    refresh_item = xbmcgui.ListItem(label="[COLOR yellow]Aktualisieren[/COLOR]")
    refresh_item.setArt({'icon': icon_path, 'thumb': icon_path})
    set_kodi_info(refresh_item, plot="Aktualisieren Sie die Ansicht.")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{addon_url}?action=show_category&cat={urllib.parse.quote(selected_category)}", listitem=refresh_item, isFolder=True)

    channels = [ch for ch in load_channels() if ch.get('category', 'Eigene Favoriten') == selected_category]
    for channel in channels:
        channel_url = channel.get('url')
        name = channel.get('name', channel_url)
        item = xbmcgui.ListItem(label=name)
        item.setArt({'icon': icon_path, 'thumb': icon_path})
        set_kodi_info(item, plot=f"Öffnen Sie den Kanal {name}, um die neuesten Beiträge und Medien anzuzeigen.")
        item.addContextMenuItems([
            ("Nachricht senden", f"RunPlugin({addon_url}?action=send_message&url={urllib.parse.quote(str(channel_url))})"),
            ("Zu Eigene Favoriten", f"RunPlugin({addon_url}?action=move_to_fav&url={urllib.parse.quote(str(channel_url))}&name={urllib.parse.quote(name)})"),
            ("Kanal löschen", f"RunPlugin({addon_url}?action=delete_channel&url={urllib.parse.quote(str(channel_url))})")
        ])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(channel_url))}", listitem=item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)

def show_downloads_folder():
    path = get_download_path()
    dirs, files = xbmcvfs.listdir(path)
    files = sorted(files)
    for filename in files:
        if filename.startswith('.'): continue
        filepath = os.path.join(path, filename)
        ext = os.path.splitext(filename)[1].lower()
        item = xbmcgui.ListItem(label=filename)
        item.setArt({'icon': icon_path, 'thumb': icon_path})
        
        delete_url = f"{addon_url}?action=delete_download&file={urllib.parse.quote(filename)}"
        send_file_url = f"RunPlugin({addon_url}?action=send_file_action&path={urllib.parse.quote(filepath)})"
        
        item.addContextMenuItems([
            ("Datei via Telegram senden", send_file_url),
            ("Datei löschen", f"RunPlugin({delete_url})")
        ])

        if ext in VIDEO_EXTENSIONS:
            item.setProperty('IsPlayable', 'true')
            set_kodi_info(item, plot=f"Heruntergeladene Videodatei: {filename}")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=filepath, listitem=item, isFolder=False)
        elif ext in IMAGE_EXTENSIONS:
            show_url = f"{addon_url}?action=show_local_image&path={urllib.parse.quote(filepath)}"
            set_kodi_info(item, plot=f"Heruntergeladenes Bild: {filename}")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=show_url, listitem=item, isFolder=False)
        elif ext == '.txt':
            show_txt_url = f"{addon_url}?action=show_local_txt&path={urllib.parse.quote(filepath)}"
            set_kodi_info(item, plot=f"Gespeicherte Textdatei: {filename}")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=show_txt_url, listitem=item, isFolder=False)
        else:
            set_kodi_info(item, plot=f"Heruntergeladene Datei: {filename}")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=filepath, listitem=item, isFolder=False)
            
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)

def delete_download_file(filename):
    if not filename: return
    path = os.path.join(get_download_path(), filename)
    if xbmcvfs.exists(path):
        try:
            xbmcvfs.delete(path)
            xbmcgui.Dialog().notification("Telegram Scraper", "Datei gelöscht", xbmcgui.NOTIFICATION_INFO, 2000)
        except Exception as e:
            xbmcgui.Dialog().ok("Fehler", f"Konnte Datei nicht löschen:\n{e}")
    xbmc.executebuiltin('Container.Refresh')

def is_archive_message(message):
    if not message:
        return False, ""
    
    file_name = ""
    text = getattr(message, 'text', '') or ''

    if getattr(message, 'file', None):
        if getattr(message.file, 'name', None):
            file_name = message.file.name
        ext = (getattr(message.file, 'ext', '') or '').lower()
        mime = (getattr(message.file, 'mime_type', '') or '').lower()
    else:
        ext, mime = "", ""

    if getattr(message, 'document', None) and getattr(message.document, 'attributes', None):
        for attr in message.document.attributes:
            if hasattr(attr, 'file_name') and attr.file_name:
                file_name = attr.file_name
                break
        if not mime and getattr(message.document, 'mime_type', None):
            mime = message.document.mime_type.lower()

    if not file_name and text:
        match = re.search(r'([\w\.-]+\.(?:zip|rar|7z|7zip|tar|gz|iso|cab|tgz|bz2|xz))', text, re.IGNORECASE)
        if match:
            file_name = match.group(1)

    if file_name and not ext:
        ext = os.path.splitext(file_name)[1].lower()

    archive_exts = ('.zip', '.rar', '.7z', '.7zip', '.tar', '.gz', '.iso', '.cab', '.tgz', '.bz2', '.xz', '.001', '.r00', '.r01', '.z01')
    fn_lower = file_name.lower() if file_name else ""

    is_arch = (
        ext in archive_exts or 
        any(x in mime for x in ('zip', 'rar', '7z', 'compressed', 'archive', 'x-tar', 'x-gzip', 'x-bzip2')) or
        any(fn_lower.endswith(x) for x in archive_exts) or
        bool(re.search(r'\.(zip|rar|7z|7zip|tar|gz|iso|cab|tgz|bz2|xz)(?:\.\d+)?$', fn_lower)) or
        ('[archiv:' in text.lower())
    )

    return is_arch, file_name

async def add_telethon_message_item(message, clean_chat, client):
    text = remove_emojis(message.text or "").strip()
    has_video = bool(message.video or (message.document and 'video' in getattr(message.document, 'mime_type', '').lower()))
    has_photo = bool(message.photo)
    archive, file_name = is_archive_message(message)

    if not text and not has_video and not has_photo and not archive and not message.document:
        return False

    sender_name = ""
    try:
        sender = await message.get_sender()
        if sender:
            if hasattr(sender, 'title') and sender.title:
                sender_name = sender.title
            elif hasattr(sender, 'first_name') and sender.first_name:
                sender_name = sender.first_name
                if getattr(sender, 'last_name', None):
                    sender_name += f" {sender.last_name}"
            elif hasattr(sender, 'username') and sender.username:
                sender_name = f"@{sender.username}"
    except Exception:
        pass

    if getattr(message, 'post_author', None):
        sender_name = message.post_author

    sender_name = remove_emojis(sender_name).strip()

    date_text = message.date.strftime('%d.%m.%Y %H:%M') if message.date else ""
    preview = text[:90] if text else (file_name if archive else "Beitrag")

    if archive: prefix = "[COLOR cyan][Archiv][/COLOR] "
    elif has_video: prefix = "[COLOR yellow][Video][/COLOR] "
    elif has_photo: prefix = "[COLOR orange][Bild][/COLOR] "
    else: prefix = "[COLOR green][Text][/COLOR] "

    sender_str = f"[COLOR magenta]{sender_name}[/COLOR]: " if sender_name else ""
    
    if date_text:
        title = f"[{date_text}] {sender_str}{prefix}{preview}"
    else:
        title = f"{sender_str}{prefix}{preview}"

    media_list, thumbnail = [], ""
    if has_video or has_photo or message.document:
        thumb_file = os.path.join(thumbs_dir, f"thumb_{message.id}.jpg")
        if not os.path.exists(thumb_file):
            try: await client.download_media(message, file=thumb_file, thumb=True)
            except Exception: pass
        if os.path.exists(thumb_file) and os.path.getsize(thumb_file) > 0:
            thumbnail = thumb_file

        media_type = 'archive' if archive else 'video' if has_video else 'photo' if has_photo else 'archive'
        media_list.append({'type': media_type, 'msg_id': message.id, 'chat': clean_chat, 'url': '', 'file_name': file_name, 'title': title})

    item = xbmcgui.ListItem(label=title)
    set_kodi_info(item, title=title, plot=text)
    if thumbnail:
        item.setArt({'icon': thumbnail, 'thumb': thumbnail})

    item_url = f"{addon_url}?action=multi_media&media={urllib.parse.quote(json.dumps(media_list, ensure_ascii=False))}&text={urllib.parse.quote(text)}&chat={urllib.parse.quote(str(clean_chat))}&msg_id={message.id}"
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=item_url, listitem=item, isFolder=False)
    return True

async def fetch_and_populate_telethon(chat_identifier, offset_id=0, filter_mode=None, topic_id=None, access_hash=None):
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash:
        show_api_help_dialog()
        addon.openSettings()
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        return

    PAGE_SIZE = get_setting_int('page_size', 25)
    MAX_SCAN = get_setting_int('max_scan', 500)

    clean_chat = normalize_chat_name(chat_identifier)
    client = get_telethon_client(api_id, api_hash)
    _eof_sent = [False]

    def safe_eof():
        if not _eof_sent[0]:
            _eof_sent[0] = True
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)

    try:
        await asyncio.wait_for(client.connect(), timeout=8.0)

        if not await asyncio.wait_for(client.is_user_authorized(), timeout=5.0):
            xbmcgui.Dialog().ok("Telegram", "Bitte zuerst einloggen.")
            await client.disconnect()
            safe_eof()
            return

    except (asyncio.TimeoutError, asyncio.CancelledError, Exception) as e:
        xbmc.log(f"Telethon connect/auth Fehler: {type(e).__name__}: {e}", xbmc.LOGERROR)
        try:
            await client.disconnect()
        except BaseException:
            pass
        safe_eof()
        return

    try:
        entity = await get_entity_safe(client, clean_chat, access_hash=access_hash)
        if not entity:
            xbmcgui.Dialog().ok("Fehler", "Kanal/Chat konnte nicht gefunden werden.")
            try:
                await client.disconnect()
            except BaseException:
                pass
            safe_eof()
            return

        if topic_id is None and not offset_id and not filter_mode:
            topics = []
            if GetForumTopicsRequest:
                try:
                    res = await client(GetForumTopicsRequest(
                        channel=entity,
                        offset_date=0,
                        offset_id=0,
                        offset_topic=0,
                        limit=100
                    ))
                    if hasattr(res, 'topics') and res.topics:
                        topics = res.topics
                except Exception:
                    try:
                        res = await client(GetForumTopicsRequest(
                            peer=entity,
                            offset_date=0,
                            offset_id=0,
                            offset_topic=0,
                            limit=100
                        ))
                        if hasattr(res, 'topics') and res.topics:
                            topics = res.topics
                    except Exception:
                        pass

            if topics:
                entity_id_str = str(tl_utils.get_peer_id(entity))
                entity_access_hash = str(getattr(entity, 'access_hash', '') or '')
                entity_display_name = getattr(entity, 'title', None) or getattr(entity, 'first_name', None) or clean_chat
                
                groups_item = xbmcgui.ListItem(label="[COLOR yellow] Zurück zu den Gruppen (Favoriten)[/COLOR]")
                groups_item.setArt({'icon': icon_path, 'thumb': icon_path})
                set_kodi_info(groups_item, plot="Zurück zur Gruppenübersicht.")
                groups_url = f"{addon_url}?action=show_category&cat={urllib.parse.quote('Eigene Favoriten')}"
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=groups_url, listitem=groups_item, isFolder=True)

                for t in topics:
                    t_title = remove_emojis(getattr(t, 'title', 'General')).strip()
                    if not t_title:
                        t_title = "General"
                    t_id = getattr(t, 'id', 1)

                    item = xbmcgui.ListItem(label=f" [COLOR grey][Thema][/COLOR] [B]{t_title}[/B]")
                    item.setArt({'icon': icon_path, 'thumb': icon_path})

                    send_topic_url = f"RunPlugin({addon_url}?action=send_message&url={urllib.parse.quote(entity_id_str)}&topic_id={t_id})"
                    if entity_access_hash:
                        send_topic_url = f"RunPlugin({addon_url}?action=send_message&url={urllib.parse.quote(entity_id_str)}&topic_id={t_id}&access_hash={entity_access_hash})"
                    _fav_name = f"{entity_display_name} / {t_title}"
                    fav_url = f"RunPlugin({addon_url}?action=move_to_fav&url={urllib.parse.quote(entity_id_str)}&name={urllib.parse.quote(_fav_name)}&topic_id={t_id})"
                    item.addContextMenuItems([("Nachricht in dieses Thema senden", send_topic_url), ("Zu Eigene Favoriten", fav_url)])

                    topic_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(entity_id_str)}&topic_id={t_id}"
                    if entity_access_hash:
                        topic_url += f"&access_hash={entity_access_hash}"
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=topic_url, listitem=item, isFolder=True)

                xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
                await client.disconnect()
                return

        refresh_url = f"{addon_url}?action=refresh"
        refresh_item = xbmcgui.ListItem(label="[COLOR yellow]Aktualisieren[/COLOR]")
        refresh_item.setArt({'icon': icon_path, 'thumb': icon_path})
        set_kodi_info(refresh_item, plot="Aktualisieren Sie die Ansicht.")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=refresh_url, listitem=refresh_item, isFolder=False)

        if topic_id is not None:
            back_item = xbmcgui.ListItem(label="[COLOR cyan] Zurück zu den Themen[/COLOR]")
            back_item.setArt({'icon': icon_path, 'thumb': icon_path})
            set_kodi_info(back_item, plot="Zurück zur Themenübersicht.")
            back_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(chat_identifier))}"
            if access_hash is not None: back_url += f"&access_hash={access_hash}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=back_item, isFolder=True)
        else:
            back_item = xbmcgui.ListItem(label="[COLOR cyan] Zurück zu den Favoriten[/COLOR]")
            back_item.setArt({'icon': icon_path, 'thumb': icon_path})
            set_kodi_info(back_item, plot="Zurück zur Favoritenübersicht.")
            back_url = f"{addon_url}?action=show_category&cat={urllib.parse.quote('Eigene Favoriten')}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=back_item, isFolder=True)

        if not offset_id:
            msg_label = " Nachricht in dieses Thema senden" if topic_id else " Nachricht in diesen Chat senden"
            send_item = xbmcgui.ListItem(label=f"[COLOR lightgreen]{msg_label}[/COLOR]")
            send_item.setArt({'icon': icon_path, 'thumb': icon_path})
            set_kodi_info(send_item, plot="Schreiben und senden Sie eine Textnachricht.")
            send_url = f"{addon_url}?action=send_message&url={urllib.parse.quote(str(chat_identifier))}"
            if topic_id: send_url += f"&topic_id={topic_id}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=send_url, listitem=send_item, isFolder=False)

        if offset_id > 0:
            first_page_item = xbmcgui.ListItem(label="[COLOR orange] Zurück zur 1. Seite (Neueste Beiträge)[/COLOR]")
            first_page_item.setArt({'icon': icon_path, 'thumb': icon_path})
            set_kodi_info(first_page_item, plot="Springen Sie zurück zur ersten Seite mit den neuesten Beiträgen.")
            first_page_url = f"{addon_url}?action=paginate&url={urllib.parse.quote(str(chat_identifier))}&offset_id=0"
            if filter_mode: first_page_url += f"&filter={urllib.parse.quote(filter_mode)}"
            if topic_id: first_page_url += f"&topic_id={topic_id}"
            if access_hash is not None: first_page_url += f"&access_hash={access_hash}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=first_page_url, listitem=first_page_item, isFolder=False)

        if not offset_id:
            if filter_mode == 'archives':
                toggle_item = xbmcgui.ListItem(label="[COLOR yellow] Alle Beiträge anzeigen[/COLOR]")
                toggle_item.setArt({'icon': icon_path, 'thumb': icon_path})
                set_kodi_info(toggle_item, plot="Heben Sie den Archiv-Filter auf, um wieder alle Beiträge anzuzeigen.")
                toggle_url = f"{addon_url}?action=toggle_filter&url={urllib.parse.quote(str(chat_identifier))}"
                if topic_id: toggle_url += f"&topic_id={topic_id}"
                if access_hash is not None: toggle_url += f"&access_hash={access_hash}"
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=toggle_url, listitem=toggle_item, isFolder=False)
            else:
                toggle_item = xbmcgui.ListItem(label="[COLOR cyan] Nur Archive anzeigen (.zip, .rar, .7z)[/COLOR]")
                toggle_item.setArt({'icon': icon_path, 'thumb': icon_path})
                set_kodi_info(toggle_item, plot="Filtern Sie die Ansicht ausschließlich nach Archiven.")
                toggle_url = f"{addon_url}?action=toggle_filter&url={urllib.parse.quote(str(chat_identifier))}&filter=archives"
                if topic_id: toggle_url += f"&topic_id={topic_id}"
                if access_hash is not None: toggle_url += f"&access_hash={access_hash}"
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=toggle_url, listitem=toggle_item, isFolder=False)
        kwargs = {}
        if offset_id: kwargs['offset_id'] = int(offset_id)
        if topic_id: kwargs['reply_to'] = int(topic_id)

        if filter_mode == 'archives' and InputMessagesFilterDocument:
            kwargs['filter'] = InputMessagesFilterDocument

        scanned_count = 0
        found_count = 0
        last_message_id = 0
        has_more = False

        max_scan_limit = max(MAX_SCAN, 2500) if filter_mode == 'archives' else MAX_SCAN

        async for message in client.iter_messages(entity, **kwargs):
            scanned_count += 1
            last_message_id = message.id
            text = remove_emojis(message.text or "").strip()

            archive, _ = is_archive_message(message)

            if filter_mode == 'archives' and not archive:
                if scanned_count >= max_scan_limit and found_count > 0:
                    has_more = True
                    break
                if scanned_count >= max_scan_limit * 2:
                    has_more = False
                    break
                continue

            if not text and not message.video and not message.photo and not message.document:
                if scanned_count >= max_scan_limit and found_count > 0:
                    has_more = True
                    break
                continue

            added = await add_telethon_message_item(message, clean_chat, client)
            if added:
                found_count += 1

            if found_count >= PAGE_SIZE:
                has_more = True
                break

            if scanned_count >= max_scan_limit:
                has_more = True
                break

        if has_more and last_message_id:
            next_url = f"{addon_url}?action=paginate&url={urllib.parse.quote(str(chat_identifier))}&offset_id={last_message_id}"
            if filter_mode: next_url += f"&filter={urllib.parse.quote(filter_mode)}"
            if topic_id: next_url += f"&topic_id={topic_id}"
            if access_hash is not None: next_url += f"&access_hash={access_hash}"
            next_item = xbmcgui.ListItem(label="[COLOR yellow] Nächste Seite ->[/COLOR]")
            next_item.setArt({'icon': icon_path, 'thumb': icon_path})
            set_kodi_info(next_item, plot="Mehr Beiträge laden.")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=next_url, listitem=next_item, isFolder=False)

    except BaseException as e:
        xbmc.log(f"fetch_and_populate_telethon: {type(e).__name__}: {e}", xbmc.LOGWARNING)
        if not isinstance(e, (asyncio.CancelledError, asyncio.TimeoutError)) and found_count == 0:
            xbmcgui.Dialog().ok("Fehler", f"Kanal/Chat konnte nicht geladen werden:\n{e}")
    finally:
        try:
            await client.disconnect()
        except BaseException:
            pass
        safe_eof()

def fetch_and_populate_web(chat_identifier):
    clean_chat = str(normalize_chat_name(chat_identifier)).lstrip('@')
    encoded_chat = urllib.parse.quote(clean_chat)
    url = params.get('url') if params.get('action') == 'page' and params.get('url') else f"https://t.me/s/{encoded_chat}"
    req = urllib.request.Request(
        url,
        headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            html_content = response.read().decode('utf-8')
    except Exception as e:
        xbmc.log(f"Telegram Scraper Error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Fehler", f"Konnte Telegram-Kanal nicht laden:\n{e}")
        return xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
    if not html_content:
        xbmcgui.Dialog().ok("Fehler", "Konnte Telegram-Kanal nicht laden.")
        return xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
    messages = html_content.split('class="tgme_widget_message ')
    if len(messages) > 1:
        messages = messages[1:]
        messages.reverse()
    before_match = re.search(r'href="([^"]*\?before=\d+)"', html_content)
    refresh_item = xbmcgui.ListItem(label="[COLOR yellow]Aktualisieren (Web-Modus)[/COLOR]")
    refresh_item.setArt({'icon': icon_path, 'thumb': icon_path})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{addon_url}?action=refresh", listitem=refresh_item, isFolder=False)
    user_agent = urllib.parse.quote('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
    referer = urllib.parse.quote('https://t.me/')
    for msg in messages:
        text_match = re.search(r'<div class="tgme_widget_message_text[^"]*"(?:[^>]*>)(.*?)</div>', msg, re.DOTALL)
        if not text_match:
            text_match = re.search(r'<div dir="auto"[^>]*>(.*?)</div>', msg, re.DOTALL)
        raw_text = text_match.group(1) if text_match else ""
        clean_text = re.sub(r'<[^>]+>', '', raw_text)
        clean_text = html.unescape(clean_text).strip()
        clean_text = re.sub(r'\s+', ' ', clean_text).strip()
        post_match = re.search(r'data-post="([^"]+)"', msg)
        msg_id = post_match.group(1).split('/')[-1] if post_match else "0"
        video_url = None
        v_match = re.search(r'<video[^>]+src=[\'"]([^\'"]+)[\'"]', msg, re.IGNORECASE)
        if v_match: video_url = clean_url(v_match.group(1))
        if not video_url:
            s_match = re.search(r'<source[^>]+src=[\'"]([^\'"]+)[\'"]', msg, re.IGNORECASE)
            if s_match: video_url = clean_url(s_match.group(1))
        if not video_url:
            cdn_urls = re.findall(r'https://cdn\d*\.telesco\.pe/file/[^"\'\s>]+', msg)
            for u in cdn_urls:
                if 't8HUD5p6GsmnfM' not in u and ('.mp4' in u or '.mov' in u):
                    video_url = clean_url(u)
                    break
        img_url = None
        bg_match = re.search(r'background-image:\s*url\([\'"]?([^\'")\s]+)[\'"]?\)', msg)
        if bg_match:
            bg_url = clean_url(bg_match.group(1))
            if 't8HUD5p6GsmnfM' not in bg_url: img_url = bg_url
        if not img_url:
            img_match = re.search(r'<img[^>]+src=[\'"]([^\'"]+)[\'"]', msg, re.IGNORECASE)
            if img_match:
                i_url = clean_url(img_match.group(1))
                if 't8HUD5p6GsmnfM' not in i_url: img_url = i_url
        has_video = video_url is not None
        has_photo = img_url is not None and not has_video
        if has_video: prefix = "[COLOR yellow][Video][/COLOR] "
        elif has_photo: prefix = "[COLOR orange][Bild][/COLOR] "
        else: prefix = "[COLOR green][Text][/COLOR] "
        title = f"{prefix}{clean_text[:50]}..." if clean_text else f"{prefix}Beitrag ohne Text"
        media_list = []
        if has_video:
            media_list.append({'type': 'video', 'msg_id': msg_id, 'chat': clean_chat, 'url': video_url, 'file_name': f"video_{msg_id}.mp4", 'title': title})
        elif has_photo:
            media_list.append({'type': 'photo', 'msg_id': msg_id, 'chat': clean_chat, 'url': img_url, 'file_name': f"photo_{msg_id}.jpg", 'title': title})
        list_item = xbmcgui.ListItem(label=title)
        set_kodi_info(list_item, title=title, plot=clean_text if clean_text else "Kein Text vorhanden.")
        if img_url:
            kodi_img_url = f"{img_url}|User-Agent={user_agent}&Referer={referer}"
            list_item.setArt({'thumb': kodi_img_url, 'icon': kodi_img_url})
        else:
            list_item.setArt({'icon': icon_path, 'thumb': icon_path})
        item_url = f"{addon_url}?action=multi_media&media={urllib.parse.quote(json.dumps(media_list, ensure_ascii=False))}&text={urllib.parse.quote(clean_text)}&chat={urllib.parse.quote(clean_chat)}&msg_id={msg_id}"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=item_url, listitem=list_item, isFolder=False)
    if before_match:
        matched_url = before_match.group(1)
        next_url = matched_url if matched_url.startswith('http') else f"https://t.me{matched_url}"
        next_item = xbmcgui.ListItem(label="[COLOR cyan][ Ältere Beiträge laden... ][/COLOR]")
        next_item.setArt({'icon': icon_path, 'thumb': icon_path})
        item_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(next_url)}"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=item_url, listitem=next_item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)

if __name__ == '__main__':
    action = params.get('action')

    if not action:
        if not is_logged_in():
            result = load_credentials_from_txt()
            if result:
                phone, api_id, api_hash = result
                run_async(run_telethon_phone_login(direct_api_id=api_id, direct_api_hash=api_hash, direct_phone=phone))
        show_root_menu()
    elif action == 'show_category':
        show_root_menu(selected_category=params.get('cat', 'Eigene Favoriten'))
    elif action == 'show_channel':
        url = params.get('url')
        offset = int(params.get('offset_id', 0)) if params.get('offset_id', '0').isdigit() else 0
        filter_mode = params.get('filter')
        topic_id = int(params.get('topic_id')) if params.get('topic_id', '').isdigit() else None
        ch_access_hash = None
        if params.get('access_hash', '').lstrip('-').isdigit():
            ch_access_hash = int(params['access_hash'])
        if ch_access_hash is None and url:
            for ch in load_channels():
                if ch.get('url') == url and ch.get('access_hash') is not None:
                    ch_access_hash = ch['access_hash']
                    break
        if is_logged_in():
            run_async(fetch_and_populate_telethon(url, offset_id=offset, filter_mode=filter_mode, topic_id=topic_id, access_hash=ch_access_hash))
        else:
            fetch_and_populate_web(url)
    elif action == 'refresh':
        xbmc.executebuiltin("Container.Refresh")
    elif action == 'paginate':
        url = params.get('url')
        offset = params.get('offset_id', '0')
        filter_mode = params.get('filter')
        topic_id = params.get('topic_id')
        access_hash_p = params.get('access_hash')
        query = f"?action=show_channel&url={urllib.parse.quote(str(url))}&offset_id={offset}"
        if filter_mode: query += f"&filter={urllib.parse.quote(filter_mode)}"
        if topic_id: query += f"&topic_id={topic_id}"
        if access_hash_p: query += f"&access_hash={access_hash_p}"
        xbmc.executebuiltin(f"Container.Update({addon_url}{query})")
    elif action == 'toggle_filter':
        url = params.get('url')
        filter_mode = params.get('filter')
        topic_id = params.get('topic_id')
        access_hash_p = params.get('access_hash')
        query = f"?action=show_channel&url={urllib.parse.quote(str(url))}&offset_id=0"
        if filter_mode: query += f"&filter={urllib.parse.quote(filter_mode)}"
        if topic_id: query += f"&topic_id={topic_id}"
        if access_hash_p: query += f"&access_hash={access_hash_p}"
        xbmc.executebuiltin(f"Container.Update({addon_url}{query})")
    elif action == 'send_message':
        chat_url = params.get('url')
        topic_id = int(params.get('topic_id')) if params.get('topic_id', '').isdigit() else None
        handle_send_message(chat_url, topic_id=topic_id)
    elif action == 'send_file_action':
        file_path = params.get('path')
        handle_send_file_action(file_path)
    elif action == 'add_channel':
        add_new_channel()
    elif action == 'auto_import':
        auto_import_channels()
    elif action == 'move_to_fav':
        move_to_addon_favourites(params.get('url'), params.get('name', params.get('url', '')), topic_id=params.get('topic_id') or None)
    elif action == 'add_to_kodi_fav':
        fav_url = params.get('url')
        fav_name = params.get('name', fav_url)
        if fav_url:
            plugin_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(fav_url))}"
            add_to_kodi_favourites(fav_name, plugin_url)
    elif action == 'add_friend':
        add_friend_dialog()
    elif action == 'delete_channel':
        delete_channel(params.get('url'))
    elif action == 'remove_from_fav':
        _tid = params.get('topic_id')
        _tid_val = int(_tid) if _tid is not None else None
        remove_from_fav(params.get('url'), topic_id=_tid_val)
    elif action == 'show_downloads':
        show_downloads_folder()
    elif action == 'delete_download':
        delete_download_file(params.get('file'))
    elif action == 'multi_media':
        media_raw = params.get('media')
        text_raw = params.get('text', '')
        chat_raw = params.get('chat')
        msg_id_raw = params.get('msg_id')
        try:
            media_list = json.loads(media_raw) if media_raw else []
            handle_multi_media(media_list, text_raw, chat=chat_raw, msg_id=msg_id_raw)
        except Exception as e:
            xbmc.log(f"MultiMedia Handle Fehler: {e}", xbmc.LOGERROR)
    elif action == 'install_zip':
        show_local_zip_addons()
    elif action == 'login':
        handle_login_flow()
    elif action == 'logout':
        if xbmcgui.Dialog().yesno("Abmelden", "Wirklich abmelden?"):
            logout()
    elif action == 'settings':
        addon.openSettings()
    elif action == 'show_manual':
        show_manual(from_first_start=params.get('first_start') == '1')
    elif action == 'fav_reorder':
        fav_reorder(params.get('url'), params.get('topic_id'), params.get('direction', ''))
    elif action == 'fav_rename':
        fav_rename(params.get('url'), params.get('topic_id'))
    elif action == 'close_addon':
        exit_addon()
    elif action == 'show_local_image':
        img_path = params.get('path')
        if img_path and os.path.exists(img_path):
            xbmc.executebuiltin(f'ShowPicture({img_path})')
    elif action == 'show_local_txt':
        txt_path = params.get('path')
        if txt_path and os.path.exists(txt_path):
            try:
                with open(txt_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                xbmcgui.Dialog().textviewer(os.path.basename(txt_path), content)
            except Exception as e:
                xbmcgui.Dialog().ok("Fehler", f"Konnte Textdatei nicht lesen:\n{e}")
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren (zusatzmetall, stonetester, mr-evil1, kato14, eragon, kangool). 
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
