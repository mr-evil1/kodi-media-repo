📖 Bedienungsanleitung: Telegram Scraper
Entwickler: Team IT('s) Possible
Version: 2026.10.11
1. Erste Schritte & Anmeldung
Bevor du Kanäle und Medien durchstöbern kannst, musst du dich mit deinem Telegram-Konto verbinden. Das Addon bietet hierfür zwei Wege:
A) Klassischer Login (Telefonnummer & Code)
 * Klicke im Hauptmenü auf „Status: User Abgemeldet“.
 * Wähle im Dialog „1. Telefonnummer & Bestätigungscode“.
 * Gib deine Telefonnummer ein (z. B. +491701234567).
 * Trage den per Telegram-App empfangenen Bestätigungscode ein.
 * Falls aktiv, gib dein 2FA-Passwort ein. Bei Erfolg wirst du eingeloggt und dein Benutzername erscheint im Hauptmenü.
B) Automatischer Login per tg.txt (Ideal für die Ersteinrichtung)
 * Erstelle auf deinem Android-Gerät im Download-Ordner eine Textdatei namens tg.txt (/storage/emulated/0/Download/tg.txt).
 * Schreibe in die erste Zeile deine Telefonnummer, in die zweite deine api_id und in die dritte deinen api_hash.
 * Beim Start des Addons liest das System die Datei automatisch ein und loggt dich im Hintergrund ein.
C) Login via StringSession (code.txt)
 * Wenn du bereits eine gültige Session besitzt, kannst du den StringSession-Key in eine Datei namens code.txt im Download-Ordner legen oder ihn über die Abfrage per Tastatur einfügen.
2. API-Zugangsdaten einrichten (my.telegram.org)
Für den vollen Telethon-Modus benötigst du eigene Telegram API-Keys:
 * Gehe im Browser auf my.telegram.org.
 * Melde dich mit deiner Handynummer an.
 * Klicke auf „API development tools“.
 * Erstelle eine neue App (Titel/Kurzname beliebig).
 * Kopiere die api_id und den api_hash in die Kodi-Addon-Einstellungen (Einstellungen öffnen).
3. Kanäle, Chats & Foren verwalten
 * Kanal hinzufügen: Klicke im Hauptmenü auf „Kanal hinzufügen“, um einen Kanal manuell über den Namen, den Link (t.me/...) oder ein @username einzutragen.
 * Freund / Chat hinzufügen: Über diesen Menüpunkt kannst du deine echten Telegram-Dialoge direkt durchsuchen und mit einem Klick zu deinen Favoriten hinzufügen.
 * Foren / Topics Support: Wenn du einen Gruppen-Chat öffnest, der Foren-Themen (Topics) unterstützt, zeigt das Addon diese übersichtlich als Ordner an. Du kannst Beiträge direkt in spezifische Themen schreiben oder lesen.
 * Kontextmenü-Optionen: Halte auf einem Kanal oder Beitrag die Bestätigungstaste gedrückt (oder Rechtsklick), um das Kontextmenü zu öffnen (z. B. „Nachricht in dieses Thema senden“, „Kanal löschen“ etc.).
4. Medien abspielen, anzeigen und herunterladen
Wenn du einen Kanal oder Chat öffnest, listet das Addon die Beiträge chronologisch auf. Ein Klick auf einen Beitrag öffnet das Multi-Media-Auswahlmenü:
 * Videos abspielen: Videos werden über den internen, sicheren Proxy-Server ([http://127.0.0.1](http://127.0.0.1):[PORT]/stream) flüssig und direkt in Kodi gestreamt oder per Direct-Stream-URL geladen.
 * Bilder anzeigen: Fotos können direkt im Vollbildmodus in Kodi betrachtet werden (ShowPicture).
 * Texte lesen & speichern: Lange Texte können über den integrierten Textviewer gelesen oder als .txt-Datei im Download-Ordner gespeichert werden.
 * Download-Manager: Lade Videos, Fotos oder Archive direkt herunter. Eine Live-Fortschrittsanzeige informiert dich über den Status.
5. Eigene Dateien & Download-Verwaltung
Über den Menüpunkt „Eigene Dateien“ greifst du auf deinen lokalen Download-Ordner zu (Standard: /storage/emulated/0/Download/Telegram/Kodi/):
 * Medien wiedergeben/anzeigen: Heruntergeladene Videos, Bilder (.jpg) oder Textdateien (.txt) lassen sich direkt aus der Liste heraus öffnen.
 * Dateien via Telegram senden: Du kannst jede beliebige lokale Datei aus deinem Download-Ordner nehmen und über das Kontextmenü („Datei via Telegram senden“) an jeden beliebigen Telegram-Chat oder Kanal hochladen (inkl. Fortschrittsbalken).
 * Löschen: Nicht mehr benötigte Dateien können direkt per Kontextmenü gelöscht werden.
6. Addons direkt aus Telegram installieren (.zip)
Ein absolutes Highlight deines Addons:
 * Lade eine .zip-Datei (z. B. ein Kodi-Addon) direkt über einen Telegram-Kanal herunter. Die Datei landet automatisch in deinem Download-Ordner.
 * Klicke im Hauptmenü auf „Addons installieren“.
 * Das Addon scannt deinen Download-Ordner nach .zip-Archiven. Wähle die gewünschte Datei aus.
 * Das Addon entpackt das Archiv automatisch in das Kodi-Addon-Verzeichnis (special://home/addons/), aktualisiert die lokalen Addons und aktiviert das installierte Addon direkt per JSON-RPC!
7. Filter & nützliche Zusatzfunktionen
 * Archiv-Filter: Nutze in Kanälen den Filter „Nur Archive anzeigen“, um gezielt nach .zip, .rar oder .7z-Paketen zu suchen.
 * Emojis & Clean-Up: Störende Emojis und Sonderzeichen werden in den Titelzeilen automatisch herausgefiltert, damit die Ansicht in Kodi sauber und übersichtlich bleibt.
 * Paginierung: Blättere bequem seitenweise durch große Kanäle und springe mit einem Klick wieder zur ersten Seite zurück.
Hinweis: Jegliche Haftung und Garantie für Schäden jeglicher Art ist laut Lizenzbestimmungen ausgeschlossen. Code und Inhalt sind das geistige Eigentum von Team IT('s) Possible.
