# -*- coding: utf-8 -*-
# Telegram Scraper
# Copyright (c) 2026 Team IT('s) Possible. All rights reserved.
# Version 2026.10.11
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
import sys
import os
import secrets
import threading

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs


addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')

addon_path = xbmcvfs.translatePath(
    addon.getAddonInfo('path')
)

lib_path = os.path.join(
    addon_path,
    'resources',
    'lib'
)

if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

profile_dir = xbmcvfs.translatePath(
    addon.getAddonInfo('profile')
)

if not xbmcvfs.exists(profile_dir):
    xbmcvfs.mkdirs(profile_dir)


PROP_PORT = 'telegramscraper.port'
PROP_TOKEN = 'telegramscraper.token'

_server = None
_thread = None
_bridge = None
_token = None
_port = None


def proxy_log(msg):
    xbmc.log(
        '[Telegram Scraper Proxy] %s' % msg,
        xbmc.LOGINFO
    )


def proxy_credentials():
    a = xbmcaddon.Addon()

    raw = a.getSetting('api_id').strip()

    return (
        int(raw) if raw.isdigit() else None,
        a.getSetting('api_hash').strip()
    )


def start_proxy():
    global _server
    global _thread
    global _bridge
    global _token
    global _port

    if _server is not None:
        return True

    try:
        import tgbridge

    except Exception as e:
        proxy_log(
            f'tgbridge Import fehlgeschlagen: {e}'
        )
        return False

    try:
        import tgfast
        tgfast.options_provider = lambda: {
            'parallel': int(xbmcaddon.Addon().getSetting('stream_parallel') or 2),
            'chunk_kb': int(xbmcaddon.Addon().getSetting('stream_chunk_kb') or 1024)}
    except Exception:
        pass

    try:
        dirs = []

        for special in (
            'special://xbmc/',
            'special://xbmc/system/python/',
            'special://xbmc/system/python/DLLs/'
        ):
            dirs.append(
                xbmcvfs.translatePath(special)
            )

        for modname in (
            '_ssl',
            '_hashlib'
        ):
            try:
                mod = __import__(modname)
                path = getattr(
                    mod,
                    '__file__',
                    ''
                ) or ''

                if path:
                    dirs.append(
                        os.path.dirname(path)
                    )

            except Exception:
                pass

        if sys.executable:
            dirs.append(
                os.path.dirname(sys.executable)
            )

        if not tgbridge.enable_fast_aes(
            dirs,
            log=proxy_log,
            lib_dir=lib_path
        ):
            xbmcgui.Dialog().notification(
                'Telegram Scraper',
                'Schnelle Verschlüsselung fehlt - Videos laden sehr langsam.',
                xbmcgui.NOTIFICATION_WARNING,
                8000
            )

    except Exception as e:
        proxy_log(
            f'AES-Einrichtung fehlgeschlagen: {e}'
        )

    try:
        _bridge = tgbridge.Bridge(
            profile_dir,
            proxy_credentials,
            log=proxy_log
        )

        _token = secrets.token_urlsafe(24)

        _server = tgbridge.make_server(
            _bridge,
            _token
        )

        _port = _server.server_address[1]

        _thread = threading.Thread(
            target=_server.serve_forever,
            name='tg-http',
            daemon=True
        )

        _thread.start()

        win = xbmcgui.Window(10000)

        win.setProperty(
            PROP_TOKEN,
            _token
        )

        win.setProperty(
            PROP_PORT,
            str(_port)
        )

        proxy_log(
            'Proxy läuft auf 127.0.0.1:%d' % _port
        )

        return True

    except Exception as e:
        proxy_log(
            f'Proxy-Start fehlgeschlagen: {e}'
        )

        try:
            if _server:
                _server.shutdown()
        except Exception:
            pass

        try:
            if _server:
                _server.server_close()
        except Exception:
            pass

        try:
            if _bridge:
                _bridge.stop()
        except Exception:
            pass

        _server = None
        _thread = None
        _bridge = None
        _token = None
        _port = None

        return False


def stop_proxy():
    global _server
    global _thread
    global _bridge
    global _token
    global _port

    win = xbmcgui.Window(10000)

    try:
        win.clearProperty(
            PROP_TOKEN
        )

        win.clearProperty(
            PROP_PORT
        )

    except Exception:
        pass

    try:
        if _server:
            _server.shutdown()

    except Exception as e:
        proxy_log(
            f'Proxy Shutdown Fehler: {e}'
        )

    try:
        if _server:
            _server.server_close()

    except Exception:
        pass

    try:
        if _bridge:
            _bridge.stop()

    except Exception as e:
        proxy_log(
            f'Bridge Stop Fehler: {e}'
        )

    _server = None
    _thread = None
    _bridge = None
    _token = None
    _port = None


def main():
    monitor = xbmc.Monitor()

    if not start_proxy():
        proxy_log(
            'Proxy konnte nicht gestartet werden.'
        )

    while not monitor.abortRequested():
        if _server is None:
            start_proxy()

        if monitor.waitForAbort(1):
            break

    stop_proxy()


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        proxy_log(
            f'Service Fehler: {type(e).__name__}: {e}'
        )
    finally:
        stop_proxy()
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren (zusatzmetall, stonetester, mr-evil1, kato14, eragon, kangool). 
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
