# -*- coding: utf-8 -*-
# Telegram Scraper
# Copyright (c) 2026 Team IT('s) Possible. All rights reserved.
# Version 2026.10.11
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren.
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
# Kodi/Windows: das C-Modul _asyncio.pyd stürzt in Kodis eingebettetem Python ab
# (EXCEPTION_ACCESS_VIOLATION). Daher die reine Python-Version von asyncio erzwingen.
import sys as _sys
if 'asyncio' not in _sys.modules:
    _sys.modules['_asyncio'] = None
import sys, urllib.parse, urllib.request, json, os, asyncio, re, html, zipfile
import secrets, threading
from datetime import datetime, timedelta
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

_addon_base = xbmcaddon.Addon()

class _AddonProxy:
    """Liest Einstellungen immer frisch. Mit reuselanguageinvoker bleibt das Addon im Speicher und
    sieht sonst neu eingetragene Werte (API-ID, Hash, TMDB-Key ...) erst nach einem Kodi-Neustart."""
    def __getattr__(self, name):
        if name.startswith('getSetting'):
            return getattr(xbmcaddon.Addon(), name)
        return getattr(_addon_base, name)

addon = _AddonProxy()
addon_id = addon.getAddonInfo('id')
addon_url = sys.argv[0] if sys.argv[0] and sys.argv[0].startswith('plugin://') else f"plugin://{addon_id}/"

try:
    addon_handle = int(sys.argv[1])
except Exception:
    addon_handle = -1

PROP_PORT = 'telegramscraper.port'
PROP_TOKEN = 'telegramscraper.token'
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 and sys.argv[2] else {}
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
icon_path = os.path.join(addon_path, 'icon.png')
video_icon_path = os.path.join(addon_path, 'resources', 'media', 'video.png')
lib_path = os.path.join(addon_path, 'resources', 'lib')

if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

profile_dir = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(profile_dir):
    xbmcvfs.mkdirs(profile_dir)

# --- Diagnose: bei einem harten Absturz (Kodi crasht) den Python-Stack in eine Datei schreiben ---
try:
    import faulthandler
    _crash_fh = open(os.path.join(profile_dir, 'crash_trace.txt'), 'a')
    faulthandler.enable(file=_crash_fh, all_threads=True)
except Exception:
    pass

CHANNELS_FILE = os.path.join(profile_dir, 'channels.json')
thumbs_dir = os.path.join(profile_dir, 'thumbs')

if not xbmcvfs.exists(thumbs_dir):
    xbmcvfs.mkdirs(thumbs_dir)


def set_action_info(item, plot=None):
    if plot:
        try:
            item.setProperty('plot', plot)
        except Exception:
            pass

def set_kodi_info(item, title=None, plot=None):
    try:
        info = item.getVideoInfoTag()
        if title: info.setTitle(title)
        if plot: info.setPlot(plot)
    except AttributeError:
        kwargs = {}
        if title: kwargs['title'] = title
        if plot: kwargs['plot'] = plot
        if kwargs: item.setInfo('video', kwargs)

def exit_addon():
    try:
        xbmc.executebuiltin('Dialog.Close(all, true)')
        xbmc.executebuiltin('ActivateWindow(home)')
    except Exception as e:
        xbmc.log(f"Exit Fehler: {e}", xbmc.LOGERROR)

def finish_action():
    if addon_handle < 0:
        return
    try:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    except Exception as e:
        xbmc.log(f"finish_action: {e}", xbmc.LOGDEBUG)


def get_setting_int(setting_id, default_val):
    try:
        val = addon.getSetting(setting_id).strip()
        return int(val) if val.isdigit() and int(val) > 0 else default_val
    except Exception:
        return default_val

def only_videos_enabled():
    """Einstellung 'Nur Videos anzeigen' (Standard: aus)."""
    try:
        return addon.getSetting('only_videos').strip().lower() == 'true'
    except Exception:
        return False

def get_download_path():
    custom_path = addon.getSetting('download_path').strip()
    path = custom_path if custom_path else "storage/emulated/0/Download/Telegram/Kodi/"
    translated_path = xbmcvfs.translatePath(path)
    if not xbmcvfs.exists(translated_path):
        try:
            xbmcvfs.mkdirs(translated_path)
        except Exception as e:
            xbmc.log(f"Download-Pfad Fehler: {e}", xbmc.LOGERROR)
    return translated_path

downloads_dir = get_download_path()

try:
    from telethon import TelegramClient
    from telethon import utils as tl_utils
    from telethon.sessions import StringSession
    from telethon.errors import SessionPasswordNeededError
    from telethon.tl.types import InputMessagesFilterDocument
    try:
        from telethon.tl.functions.channels import GetForumTopicsRequest
    except ImportError:
        try:
            from telethon.tl.functions.messages import GetForumTopicsRequest
        except ImportError:
            GetForumTopicsRequest = None
    TELETHON_AVAILABLE = True
except Exception as e:
    TELETHON_AVAILABLE = False
    InputMessagesFilterDocument = None
    GetForumTopicsRequest = None
    xbmc.log(f"TELETHON IMPORT FEHLER: {type(e).__name__}: {e}", xbmc.LOGERROR)

def get_telethon_client(api_id, api_hash):
    """Erstellt den passenden TelethonClient (StringSession ODER sqlite session file)."""
    session_txt = os.path.join(profile_dir, 'telegram.txt')
    if os.path.exists(session_txt):
        try:
            with open(session_txt, 'r', encoding='utf-8', errors='ignore') as f:
                s_str = f.read().strip()
            if s_str and not s_str.startswith('SQLite format 3'):
                return TelegramClient(
                    StringSession(s_str), int(api_id), api_hash,
                    device_model="Android Device", system_version="Android 12",
                    app_version="1.0.0", lang_code="de", system_lang_code="de",
                    receive_updates=False
                )
        except Exception as e:
            xbmc.log(f"StringSession Error: {e}", xbmc.LOGWARNING)

    session_file = os.path.join(profile_dir, 'session.txt')
    return TelegramClient(
        session_file, int(api_id), api_hash,
        device_model="Android Device", system_version="Android 12",
        app_version="1.0.0", lang_code="de", system_lang_code="de",
        receive_updates=False
    )

def remove_emojis(text):
    if not text: return ""
    pattern = re.compile(r'[\U00010000-\U0010ffff]|[\u2600-\u27BF]|[\u2300-\u23FF]|[\u2B50\u2B55]', flags=re.UNICODE)
    return pattern.sub('', text)

def make_event_loop():
    """Windows: Proactor-Loop crasht in Kodi-Threads (set_wakeup_fd only works in
    main thread). Der Selector-Loop braucht das nicht und funktioniert mit Telethon."""
    if sys.platform.startswith('win'):
        try:
            return asyncio.SelectorEventLoop()
        except Exception:
            pass
    return asyncio.new_event_loop()

def run_async(coro):
    _cname = getattr(coro, '__qualname__', None) or getattr(coro, '__name__', str(coro))
    xbmc.log(f"[TGS] run_async START {_cname}", xbmc.LOGINFO)
    loop = make_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    except BaseException as e:
        import traceback
        xbmc.log(f"run_async Fehler: {type(e).__name__} - {str(e)}\n{traceback.format_exc()}", xbmc.LOGERROR)
        return None
    finally:
        xbmc.log(f"[TGS] run_async ENDE {_cname}", xbmc.LOGINFO)
        try:
            tasks = asyncio.all_tasks(loop=loop)
            for task in tasks: task.cancel()
            if tasks: loop.run_until_complete(asyncio.gather(*tasks, return_exceptions=True))
        except BaseException:
            pass
        try:
            loop.close()
        except BaseException:
            pass

def _clean_api_id(raw):
    return re.sub(r'\D', '', raw or '')

def _clean_api_hash(raw):
    # Leerzeichen, Anführungszeichen, unsichtbare Zeichen usw. entfernen; nur 0-9 a-f bleiben
    return re.sub(r'[^0-9a-fA-F]', '', raw or '').lower()

def credentials_problem():
    """Beschreibt genau, was bei API-ID / Hash fehlt ('' wenn alles in Ordnung)."""
    a = xbmcaddon.Addon()
    raw_id, raw_hash = a.getSetting('api_id'), a.getSetting('api_hash')
    api_id, api_hash = _clean_api_id(raw_id), _clean_api_hash(raw_hash)
    lines = []
    if not raw_id.strip():
        lines.append("API ID: nicht eingetragen")
    elif not api_id:
        lines.append("API ID: enthält keine Ziffern")
    if not raw_hash.strip():
        lines.append("API Hash: nicht eingetragen")
    elif len(api_hash) != 32:
        lines.append(f"API Hash: {len(api_hash)} gültige Zeichen gefunden, erwartet werden genau 32 (0-9 und a-f)")
    return "\n".join(lines)

def get_credentials():
    a = xbmcaddon.Addon()
    api_id = _clean_api_id(a.getSetting('api_id'))
    api_hash = _clean_api_hash(a.getSetting('api_hash'))
    if not api_id: return None, None
    if len(api_hash) != 32: return None, None
    return api_id, api_hash

def show_api_help_dialog():
    problem = credentials_problem()
    msg = ((f"[COLOR red]Was fehlt:[/COLOR]\n{problem}\n\n" if problem else "") +
           "So bekommst du eigene Telegram API-Zugangsdaten:\n"
           "1. Im Browser https://my.telegram.org öffnen.\n"
           "2. Mit deiner Telefonnummer anmelden.\n"
           "3. 'API development tools' wählen.\n"
           "4. Eine App erstellen (Titel/Kurzname beliebig).\n"
           "5. api_id und api_hash in den Einstellungen eintragen (danach OK drücken).")
    xbmcgui.Dialog().ok("Telegram API-Zugangsdaten", msg)

def check_credentials_dialog():
    a = xbmcaddon.Addon()
    phone = a.getSetting('phone_number').strip()
    problem = credentials_problem()
    api_id = _clean_api_id(a.getSetting('api_id'))
    api_hash = _clean_api_hash(a.getSetting('api_hash'))
    lines = [f"API ID: {api_id if api_id else '-'}",
             f"API Hash: {len(api_hash)} von 32 Zeichen" + (" [COLOR lime]ok[/COLOR]" if len(api_hash) == 32 else " [COLOR red]falsch[/COLOR]"),
             f"Telefonnummer: {phone if phone else '-'}"]
    if problem:
        lines += ["", problem]
    elif phone and not phone.startswith('+'):
        lines += ["", "Hinweis: Die Telefonnummer sollte mit + und Landesvorwahl beginnen (z.B. +43...)."]
    else:
        lines += ["", "[COLOR lime]Alles in Ordnung.[/COLOR] Jetzt auf 'Jetzt bei Telegram einloggen' tippen."]
    xbmcgui.Dialog().ok("Zugangsdaten prüfen", "\n".join(lines))

def normalize_chat_name(chat):
    if not chat: return ""
    value = str(chat).strip()
    if 't.me/c/' in value:
        parts = value.split('t.me/c/', 1)[1].split('/')
        cid = parts[0]
        if cid.isdigit(): return int(f"-100{cid}")
    if 't.me/' in value: value = value.split('t.me/', 1)[1]
    if value.startswith('s/'): value = value[2:]
    if value.startswith('/'): value = value[1:]
    if value.startswith('@'): value = value[1:]
    value = value.split('?', 1)[0].rstrip('/')
    if value.lstrip('-').isdigit(): return int(value)
    return value

async def get_entity_safe(client, chat_identifier, access_hash=None):
    clean_chat = normalize_chat_name(chat_identifier)
    if clean_chat == "" or clean_chat is None:
        return None
    is_id = isinstance(clean_chat, int)
    wanted = str(clean_chat).lower().lstrip('@')

    if is_id:
        try:
            return await client.get_entity(clean_chat)
        except Exception:
            pass
        raw = abs(clean_chat)
        s = str(raw)
        if access_hash is not None:
            try:
                if s.startswith('100') and len(s) > 12:
                    from telethon.tl.functions.channels import GetChannelsRequest
                    from telethon.tl.types import InputChannel
                    ch_id = int(s[3:])
                    r = await client(GetChannelsRequest([InputChannel(ch_id, int(access_hash))]))
                    if getattr(r, 'chats', None):
                        return r.chats[0]
                else:
                    from telethon.tl.functions.messages import GetChatsRequest
                    r = await client(GetChatsRequest([raw]))
                    if getattr(r, 'chats', None):
                        return r.chats[0]
            except Exception:
                pass

    async def search_dialogs():
        try:
            async for dialog in client.iter_dialogs(limit=1000):
                uname = (getattr(dialog.entity, 'username', '') or '').lower()
                d_name = (dialog.name or '').strip().lower()
                if (str(dialog.id) in (str(clean_chat), f"-100{clean_chat}")
                        or (uname and uname == wanted)
                        or (d_name and d_name == wanted)):
                    return dialog.entity
        except Exception as e:
            xbmc.log(f"get_entity_safe Dialogsuche: {e}", xbmc.LOGWARNING)
        return None

    try:
        return await client.get_entity(clean_chat)
    except Exception as e:
        xbmc.log(f"get_entity_safe get_entity({clean_chat}): {e}", xbmc.LOGDEBUG)
    entity = await search_dialogs()
    return entity

async def verify_login_status():
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash: return False
    auth_ok_file = os.path.join(profile_dir, 'auth_ok')
    client = get_telethon_client(api_id, api_hash)
    try:
        await client.connect()
        result = await client.is_user_authorized()
        if result:
            with open(auth_ok_file, 'w', encoding='utf-8') as f: f.write('ok')
            try:
                me = await client.get_me()
                if me:
                    uname = me.username or me.first_name or "User"
                    if me.username and not uname.startswith('@'): uname = f"@{uname}"
                    with open(os.path.join(profile_dir, 'username.txt'), 'w', encoding='utf-8') as f: f.write(uname)
            except Exception:
                pass
        return result
    except Exception as e:
        xbmc.log(f"Login Check Fehler: {e}", xbmc.LOGERROR)
        return False
    finally:
        try: await client.disconnect()
        except BaseException: pass

def is_logged_in():
    auth_ok_file = os.path.join(profile_dir, 'auth_ok')
    username_file = os.path.join(profile_dir, 'username.txt')
    session_sqlite = os.path.join(profile_dir, 'session.txt.session')
    session_txt = os.path.join(profile_dir, 'telegram.txt')

    has_session = os.path.exists(session_sqlite) or os.path.exists(session_txt)
    has_auth = os.path.exists(auth_ok_file) or os.path.exists(username_file)

    if has_session and has_auth:
        return True

    if not has_session:
        return False

    api_id, api_hash = get_credentials()
    if not (api_id and api_hash):
        return False
    if TELETHON_AVAILABLE:
        return bool(run_async(verify_login_status()))
    return False

def get_saved_username():
    username_file = os.path.join(profile_dir, 'username.txt')
    if os.path.exists(username_file):
        try:
            with open(username_file, 'r', encoding='utf-8') as f:
                val = f.read().strip()
                if val: return val
        except Exception:
            pass
    return "User"

def load_credentials_from_txt():
    txt_path = '/storage/emulated/0/Download/tg.txt'
    if not os.path.exists(txt_path):
        return False
    try:
        with open(txt_path, 'r', encoding='utf-8') as f:
            lines = [l.strip() for l in f.readlines()]
        lines = [l for l in lines if l and not l.startswith('#')]
        if len(lines) < 2:
            return False
        phone = lines[0]
        api_id = lines[1]
        api_hash = lines[2] if len(lines) > 2 else ''
        rsa_key = ''
        for i, l in enumerate(lines):
            if l.lower().startswith('rsa:'):
                rsa_key = l[4:].strip()
                break
            elif i >= 3:
                rsa_key = l
                break
        if not api_id.isdigit():
            xbmcgui.Dialog().notification("tg.txt", "Ungültige API ID in tg.txt", xbmcgui.NOTIFICATION_WARNING, 4000)
            return False
        if api_hash and len(api_hash) != 32:
            xbmcgui.Dialog().notification("tg.txt", "Ungültiger API Hash in tg.txt (muss 32 Zeichen haben)", xbmcgui.NOTIFICATION_WARNING, 4000)
            return False
        addon.setSetting('phone_number', phone)
        addon.setSetting('api_id', api_id)
        if api_hash:
            addon.setSetting('api_hash', api_hash)
        xbmcgui.Dialog().notification("tg.txt", "Zugangsdaten aus tg.txt geladen", xbmcgui.NOTIFICATION_INFO, 3000)
        return (phone, api_id, api_hash)
    except Exception as e:
        xbmc.log(f"tg.txt Lesefehler: {e}", xbmc.LOGERROR)
        return False

async def run_telethon_phone_login(direct_api_id=None, direct_api_hash=None, direct_phone=None):
    if direct_api_id and direct_api_hash:
        api_id, api_hash = str(direct_api_id), str(direct_api_hash)
    else:
        api_id, api_hash = get_credentials()
    if not api_id or not api_hash:
        show_api_help_dialog()
        addon.openSettings()
        return False

    session_file = os.path.join(profile_dir, 'session.txt')
    session_txt = os.path.join(profile_dir, 'telegram.txt')
    if os.path.exists(session_txt):
        try: os.remove(session_txt)
        except Exception: pass

    client = TelegramClient(session_file, int(api_id), api_hash)
    await client.connect()

    if not await client.is_user_authorized():
        phone = direct_phone or addon.getSetting('phone_number').strip()
        if not phone:
            phone = xbmcgui.Dialog().input("Telegram Telefonnummer (z.B. +491701234567)", type=xbmcgui.INPUT_ALPHANUM)
        if not phone:
            await client.disconnect()
            return False

        phone = phone.strip().replace(" ", "")
        try:
            await client.send_code_request(phone)
        except Exception as e:
            xbmcgui.Dialog().ok("Fehler", f"Code konnte nicht gesendet werden:\n{e}")
            await client.disconnect()
            return False

        from telethon.errors import PhoneCodeInvalidError, PhoneCodeExpiredError, PhoneCodeEmptyError, FloodWaitError
        attempts = 0
        while True:
            code = xbmcgui.Dialog().input("Telegram Bestätigungscode (nur Ziffern)")
            if not code:
                await client.disconnect()
                return False

            # Leerzeichen, Bindestriche usw. entfernen - nur die Ziffern zählen
            code = re.sub(r'\D', '', code)
            try:
                await client.sign_in(phone, code)
                break
            except SessionPasswordNeededError:
                password = xbmcgui.Dialog().input("Telegram 2FA Passwort", type=xbmcgui.INPUT_ALPHANUM, option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if not password:
                    await client.disconnect()
                    return False
                try:
                    await client.sign_in(password=password.strip())
                except Exception as e:
                    xbmcgui.Dialog().ok("2FA Fehler", f"Passwort falsch:\n{e}")
                    await client.disconnect()
                    return False
                break
            except (PhoneCodeInvalidError, PhoneCodeEmptyError):
                attempts += 1
                if attempts >= 3:
                    xbmcgui.Dialog().ok("Code ungültig",
                        "Der Code wurde 3x falsch eingegeben.\n"
                        "Bitte den Login neu starten, damit ein frischer Code gesendet wird.")
                    await client.disconnect()
                    return False
                xbmcgui.Dialog().ok("Code ungültig",
                    "Der eingegebene Code ist falsch.\n"
                    "Bitte den ZULETZT erhaltenen Code (Telegram-App oder SMS) genau eingeben.")
                continue
            except PhoneCodeExpiredError:
                try:
                    await client.send_code_request(phone)
                    xbmcgui.Dialog().ok("Code abgelaufen",
                        "Der Code ist abgelaufen. Es wurde ein neuer Code gesendet - bitte diesen eingeben.")
                    continue
                except Exception as e:
                    xbmcgui.Dialog().ok("Fehler", f"Neuer Code konnte nicht gesendet werden:\n{e}")
                    await client.disconnect()
                    return False
            except FloodWaitError as e:
                xbmcgui.Dialog().ok("Zu viele Versuche",
                    f"Telegram verlangt eine Pause von {getattr(e, 'seconds', '?')} Sekunden. Bitte später erneut versuchen.")
                await client.disconnect()
                return False
            except Exception as e:
                xbmcgui.Dialog().ok("Login Fehler", f"Anmeldung fehlgeschlagen:\n{type(e).__name__}: {e}")
                await client.disconnect()
                return False

    is_authed = await client.is_user_authorized()
    if is_authed:
        try:
            me = await client.get_me()
            if me:
                uname = me.username or me.first_name or "User"
                if me.username and not uname.startswith('@'): uname = f"@{uname}"
                with open(os.path.join(profile_dir, 'username.txt'), 'w', encoding='utf-8') as f: f.write(uname)
        except Exception:
            pass
        try:
            from telethon.sessions import StringSession
            session_string = StringSession.save(client.session)
            session_txt_path = os.path.join(profile_dir, 'telegram.txt')
            with open(session_txt_path, 'w', encoding='utf-8') as f: f.write(session_string)
        except Exception as e:
            xbmc.log(f"StringSession Export Fehler: {e}", xbmc.LOGWARNING)
        auth_file = os.path.join(profile_dir, 'auth_ok')
        try:
            with open(auth_file, 'w', encoding='utf-8') as f: f.write('ok')
        except Exception: pass
        xbmcgui.Dialog().notification("Telegram Scraper", "Erfolgreich eingeloggt", xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().ok("Fehler", "Anmeldung konnte nicht verifiziert werden.")

    await client.disconnect()
    return is_authed

def login_with_string_session():
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash:
        show_api_help_dialog()
        addon.openSettings()
        return
    code_file_path = os.path.join(get_download_path(), 'code.txt')
    session_key = ""

    if os.path.exists(code_file_path):
        try:
            with open(code_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                session_key = f.read()
        except Exception as e:
            xbmcgui.Dialog().ok("Fehler", f"Konnte code.txt nicht lesen:\n{e}")

    if not session_key:
        session_key = xbmcgui.Dialog().input("StringSession Key einfügen:")

    if session_key:
        session_key = session_key.strip().replace('\r', '').replace('\n', '').replace(' ', '').replace('"', '').replace("'", "")
        session_txt = os.path.join(profile_dir, 'telegram.txt')
        with open(session_txt, 'w', encoding='utf-8') as f: f.write(session_key)
        try:
            if run_async(verify_login_status()):
                xbmcgui.Dialog().notification("Telegram Scraper", "Login erfolgreich!", xbmcgui.NOTIFICATION_INFO, 3000)
                if os.path.exists(code_file_path):
                    try: os.remove(code_file_path)
                    except Exception: pass
            else:
                xbmcgui.Dialog().ok("Login Fehler", "Telegram hat die Sitzung abgelehnt (is_user_authorized = False).")
        except Exception as e:
            xbmcgui.Dialog().ok("Telethon Fehler", f"Details zum Fehler:\n{type(e).__name__}: {e}")
        xbmc.executebuiltin('Container.Refresh')

def handle_login_flow():
    choice = xbmcgui.Dialog().select("Telegram Login Methode wählen", [
        "1. Telefonnummer & Bestätigungscode (Telethon Login)",
        "2. StringSession / Key Code (code.txt oder Tastatur)"
    ])
    if choice == 0:
        run_async(run_telethon_phone_login())
    elif choice == 1:
        login_with_string_session()
    if choice >= 0:
        finish_action()
        xbmc.executebuiltin(f'Container.Update({addon_url},replace)')

def logout():
    for filename in ('session.txt', 'auth_ok', 'username.txt', 'session.txt.session', 'session.txt.session-journal', 'telegram.txt'):
        path = os.path.join(profile_dir, filename)
        if os.path.exists(path):
            try: os.remove(path)
            except Exception: pass
    addon.setSetting('api_id', '')
    addon.setSetting('api_hash', '')
    addon.setSetting('phone_number', '')
    xbmcgui.Dialog().notification("Telegram Scraper", "Abgemeldet", xbmcgui.NOTIFICATION_INFO, 3000)
    finish_action()
    xbmc.executebuiltin(f'Container.Update({addon_url},replace)')

def load_channels():
    if not os.path.exists(CHANNELS_FILE): return []
    try:
        with open(CHANNELS_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return []

def save_channels(channels):
    try:
        with open(CHANNELS_FILE, 'w', encoding='utf-8') as f:
            json.dump(channels, f, ensure_ascii=False, indent=4)
    except Exception as e:
        xbmc.log(f"Telegram Save Error: {e}", xbmc.LOGERROR)

async def resolve_chat_async(value):
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash: return None
    client = get_telethon_client(int(api_id), api_hash)
    try:
        await client.connect()
        if not await client.is_user_authorized(): return None
        entity = await get_entity_safe(client, value)
        if not entity: return None
        username = getattr(entity, 'username', None)
        title = getattr(entity, 'title', None)
        if not title:
            parts = [getattr(entity, 'first_name', None), getattr(entity, 'last_name', None)]
            title = ' '.join(p for p in parts if p)
        title = remove_emojis(title or '').strip() or username or str(value)
        identifier = f"@{username}" if username else str(tl_utils.get_peer_id(entity))
        ah = getattr(entity, 'access_hash', None)
        result = {'name': title, 'url': identifier}
        if ah is not None and not username:
            result['access_hash'] = ah
        return result
    except Exception as e:
        xbmc.log(f"resolve_chat_async Fehler: {type(e).__name__}: {e}", xbmc.LOGERROR)
        return None
    finally:
        try: await client.disconnect()
        except BaseException: pass

def add_to_kodi_favourites(name, plugin_url, thumb=''):
    try:
        n = name.replace('"', '\\"')
        u = plugin_url.replace('"', '\\"')
        t = (thumb or icon_path).replace('"', '\\"')
        xbmc.executebuiltin(f'AddFavourite("{n}","media","{u}","{t}")')
        xbmcgui.Dialog().notification("Telegram Scraper", f"Kodi-Favoriten: {name}", xbmcgui.NOTIFICATION_INFO, 2000)
    except Exception as e:
        xbmc.log(f"Kodi-Favoriten Fehler: {e}", xbmc.LOGERROR)

def ask_and_save_channel(name, url, access_hash=None):
    channel_plugin_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(url))}"
    choice = xbmcgui.Dialog().select(
        f"'{name}' hinzufügen zu:",
        ["★  Addon-Favoriten (Eigene Favoriten)", "⭐  Kodi-Favoriten"]
    )
    if choice == 0:
        channels = load_channels()
        if any(ch.get('url') == url for ch in channels):
            xbmcgui.Dialog().ok("Hinweis", "Dieser Kanal ist bereits in den Addon-Favoriten.")
            return
        entry = {'name': name, 'url': url, 'category': 'Eigene Favoriten'}
        if access_hash is not None:
            entry['access_hash'] = access_hash
        channels.append(entry)
        save_channels(channels)
        xbmcgui.Dialog().notification("Telegram Scraper", f"Addon-Favoriten: {name}", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('Container.Refresh')
    elif choice == 1:
        add_to_kodi_favourites(name, channel_plugin_url)

def add_new_channel():
    value = xbmcgui.Dialog().input("Kanalname, Link oder @kanal")
    if not value: return
    value = value.strip()
    resolved = None
    if TELETHON_AVAILABLE and is_logged_in():
        resolved = run_async(resolve_chat_async(value))
    if resolved:
        name, url = resolved['name'], resolved['url']
        access_hash = resolved.get('access_hash')
    else:
        name = value.split('/')[-1].replace('@', '')
        url = f"@{name}"
        access_hash = None
    ask_and_save_channel(name, url, access_hash)

async def fetch_dialogs_async():
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash: return []
    client = get_telethon_client(api_id, api_hash)
    dialogs_list = []
    try:
        await client.connect()
        if not await client.is_user_authorized(): return []
        async for dialog in client.iter_dialogs(limit=300):
            name = dialog.name or str(dialog.id)
            name = remove_emojis(name).strip() or str(dialog.id)
            username = getattr(dialog.entity, 'username', None)
            identifier = f"@{username}" if username else str(dialog.id)
            dialogs_list.append({'name': name, 'url': identifier})
    except Exception as e:
        xbmc.log(f"Dialogs Error: {e}", xbmc.LOGERROR)
    finally:
        try: await client.disconnect()
        except BaseException: pass
    return dialogs_list

def add_friend_dialog():
    if not is_logged_in():
        xbmcgui.Dialog().ok("Telegram", "Bitte zuerst einloggen, um Freunde/Chats auszuwählen.")
        return
    choice = xbmcgui.Dialog().select("Freund / Chat hinzufügen", [
        "Manuell per Name / @username / Link",
        "Aus Telegram-Dialogen auswählen"
    ])
    if choice == 0:
        add_new_channel()
    elif choice == 1:
        dialogs = run_async(fetch_dialogs_async())
        if not dialogs:
            xbmcgui.Dialog().ok("Hinweis", "Keine Dialoge gefunden.")
            return
        names = [d['name'] for d in dialogs]
        sel = xbmcgui.Dialog().select("Wähle einen Chat / Freund", names)
        if sel >= 0:
            chosen = dialogs[sel]
            ask_and_save_channel(chosen['name'], chosen['url'])

async def send_telethon_message_async(chat_identifier, text, topic_id=None):
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash: return False
    client = get_telethon_client(api_id, api_hash)
    success = False
    try:
        await client.connect()
        if not await client.is_user_authorized(): return False
        entity = await get_entity_safe(client, chat_identifier)
        kwargs = {}
        if topic_id: kwargs['reply_to'] = int(topic_id)
        await client.send_message(entity, text, **kwargs)
        xbmcgui.Dialog().notification("Telegram Scraper", "Nachricht erfolgreich gesendet", xbmcgui.NOTIFICATION_INFO, 3000)
        success = True
    except Exception as e:
        xbmcgui.Dialog().ok("Fehler", f"Nachricht konnte nicht gesendet werden:\n{e}")
    finally:
        try: await client.disconnect()
        except BaseException: pass
    return success

def handle_send_message(chat_identifier, topic_id=None):
    if not chat_identifier: return
    text = xbmcgui.Dialog().input("Nachricht eingeben:")
    if text:
        success = run_async(send_telethon_message_async(chat_identifier, text, topic_id=topic_id))
        if success:
            xbmc.executebuiltin('Container.Refresh')

async def send_telethon_file_async(chat_identifier, file_path, caption=""):
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash: return False
    client = get_telethon_client(api_id, api_hash)
    dialog = xbmcgui.DialogProgress()
    dialog.create("Telegram Upload", "Vorbereitung...")
    cancelled = [False]

    def progress(current, total):
        if dialog.iscanceled():
            cancelled[0] = True
            return
        if total:
            percent = int(current * 100 / total)
            dialog.update(percent, f"Lade hoch... {percent}%")
        else:
            dialog.update(0, "Lade hoch...")

    success = False
    try:
        await client.connect()
        if not await client.is_user_authorized():
            dialog.close()
            xbmcgui.Dialog().ok("Telegram", "Bitte zuerst einloggen.")
            return False

        entity = await get_entity_safe(client, chat_identifier)
        if not entity:
            dialog.close()
            xbmcgui.Dialog().ok("Fehler", "Ziel-Chat konnte nicht gefunden werden.")
            return False

        upload_task = asyncio.create_task(client.send_file(entity, file_path, caption=caption, progress_callback=progress))
        while not upload_task.done():
            await asyncio.sleep(0.5)
            if dialog.iscanceled():
                cancelled[0] = True
                upload_task.cancel()
                break

        if cancelled[0]:
            dialog.close()
            xbmcgui.Dialog().notification("Telegram Scraper", "Upload abgebrochen", xbmcgui.NOTIFICATION_INFO, 2000)
            return False

        await upload_task
        dialog.close()
        xbmcgui.Dialog().notification("Telegram Scraper", "Datei erfolgreich gesendet!", xbmcgui.NOTIFICATION_INFO, 3000)
        success = True
    except asyncio.CancelledError:
        pass
    except Exception as e:
        dialog.close()
        xbmc.log(f"Telethon Upload Error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Fehler", f"Datei konnte nicht gesendet werden:\n{e}")
    finally:
        try: await client.disconnect()
        except BaseException: pass
    return success

def handle_send_file_action(file_path):
    if not file_path or not os.path.exists(file_path):
        xbmcgui.Dialog().ok("Fehler", "Die ausgewählte Datei existiert nicht.")
        return

    if not is_logged_in():
        xbmcgui.Dialog().ok("Telegram", "Bitte zuerst einloggen, um Dateien zu senden.")
        return

    channels = load_channels()
    options = ["Manuell eingeben (Name, Link oder @kanal)"]
    targets = [None]
    
    for ch in channels:
        options.append(f"Kanal/Chat: {ch.get('name', ch.get('url'))}")
        targets.append(ch.get('url'))

    sel = xbmcgui.Dialog().select("Wohin soll die Datei gesendet werden?", options)
    if sel < 0: return

    if sel == 0:
        chat_target = xbmcgui.Dialog().input("Ziel-Chat eingeben (z.B. @kanal oder Name):")
    else:
        chat_target = targets[sel]

    if not chat_target: return

    caption = xbmcgui.Dialog().input("Optionale Bildunterschrift / Text (optional):")
    success = run_async(send_telethon_file_async(chat_target, file_path, caption=caption))
    if success:
        xbmc.executebuiltin('Container.Refresh')

def delete_channel(channel_url):
    channels = [ch for ch in load_channels() if ch.get('url') != channel_url]
    save_channels(channels)
    xbmcgui.Dialog().notification("Telegram Scraper", "Kanal gelöscht", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')

def remove_from_fav(channel_url, topic_id=None):
    channels = [ch for ch in load_channels() if ch.get('url') != channel_url]
    save_channels(channels)
    xbmcgui.Dialog().notification("Telegram Scraper", "Aus Favoriten entfernt", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')

def move_to_addon_favourites(channel_url, name, topic_id=None):
    channels = load_channels()
    already = next((ch for ch in channels if ch.get('url') == channel_url and ch.get('topic_id') == topic_id), None)
    if already and already.get('category') == 'Eigene Favoriten':
        xbmcgui.Dialog().notification("Telegram Scraper", "Bereits in Eigene Favoriten", xbmcgui.NOTIFICATION_INFO, 2000)
        return
    if already:
        already['category'] = 'Eigene Favoriten'
    else:
        entry = {'name': name, 'url': channel_url, 'category': 'Eigene Favoriten'}
        if topic_id is not None:
            entry['topic_id'] = topic_id
        channels.append(entry)
    save_channels(channels)
    xbmcgui.Dialog().notification("Telegram Scraper", f"Zu Eigene Favoriten: {name}", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')

def _fav_tid(topic_id_str):
    try:
        return int(topic_id_str) if topic_id_str and str(topic_id_str).strip().isdigit() else None
    except Exception:
        return None

def _fav_refresh():
    cat = urllib.parse.quote('Eigene Favoriten')
    xbmc.executebuiltin(f'Container.Update(plugin://{addon_id}/?action=show_category&cat={cat},replace)')

def fav_reorder(url, topic_id_str, direction):
    try:
        channels = load_channels()
        topic_id = _fav_tid(topic_id_str)
        fav = [ch for ch in channels if ch.get('category', 'Eigene Favoriten') == 'Eigene Favoriten']
        other = [ch for ch in channels if ch.get('category', 'Eigene Favoriten') != 'Eigene Favoriten']
        pos = next((p for p, ch in enumerate(fav) if str(ch.get('url', '')) == str(url) and ch.get('topic_id') == topic_id), None)
        if pos is None:
            xbmc.log(f'fav_reorder: url={url!r} topic={topic_id!r} nicht gefunden', xbmc.LOGWARNING)
            return
        if direction == 'up' and pos > 0:
            fav[pos], fav[pos - 1] = fav[pos - 1], fav[pos]
        elif direction == 'down' and pos < len(fav) - 1:
            fav[pos], fav[pos + 1] = fav[pos + 1], fav[pos]
        elif direction == 'top':
            fav.insert(0, fav.pop(pos))
        elif direction == 'bottom':
            fav.append(fav.pop(pos))
        else:
            return
        save_channels(other + fav)
        xbmc.sleep(150)
        _fav_refresh()
    except Exception as e:
        xbmc.log(f'fav_reorder Fehler: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Fehler', str(e), xbmcgui.NOTIFICATION_ERROR, 3000)

def fav_rename(url, topic_id_str):
    try:
        channels = load_channels()
        topic_id = _fav_tid(topic_id_str)
        ch = next((c for c in channels if str(c.get('url', '')) == str(url) and c.get('topic_id') == topic_id), None)
        if not ch:
            xbmc.log(f'fav_rename: url={url!r} topic={topic_id!r} nicht gefunden', xbmc.LOGWARNING)
            return
        new_name = xbmcgui.Dialog().input('Umbenennen', ch.get('name', ''))
        if new_name and new_name.strip():
            ch['name'] = new_name.strip()
            save_channels(channels)
            xbmc.sleep(150)
            _fav_refresh()
    except Exception as e:
        xbmc.log(f'fav_rename Fehler: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Fehler', str(e), xbmcgui.NOTIFICATION_ERROR, 3000)

AUTO_CATEGORY = 'Automatisch Hinzugefügt'

async def _auto_import_async():
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash:
        return None
    client = get_telethon_client(api_id, api_hash)
    results = []
    try:
        await client.connect()
        if not await client.is_user_authorized():
            return None
        async for dialog in client.iter_dialogs(limit=500):
            name = dialog.name or str(dialog.id)
            name = remove_emojis(name).strip() or str(dialog.id)
            username = getattr(dialog.entity, 'username', None)
            identifier = f"@{username}" if username else str(dialog.id)
            results.append({'name': name, 'url': identifier})
    except Exception as e:
        xbmc.log(f"Auto-Import Fehler: {e}", xbmc.LOGERROR)
        return None
    finally:
        try:
            await client.disconnect()
        except BaseException:
            pass
    return results

def auto_import_channels():
    if not is_logged_in():
        xbmcgui.Dialog().ok("Telegram", "Bitte zuerst einloggen.")
        return
    progress = xbmcgui.DialogProgress()
    progress.create("Automatisch Hinzufügen", "Lade Telegram-Kanäle...")
    dialogs = run_async(_auto_import_async())
    progress.close()
    if dialogs is None:
        xbmcgui.Dialog().ok("Fehler", "Konnte Kanäle nicht laden.")
        return
    channels = load_channels()
    existing_urls = {ch.get('url') for ch in channels}
    auto_urls = {ch.get('url') for ch in channels if ch.get('category') == AUTO_CATEGORY}
    current_dialog_urls = {d['url'] for d in dialogs}
    channels = [ch for ch in channels if not (ch.get('category') == AUTO_CATEGORY and ch.get('url') not in current_dialog_urls)]
    existing_urls_after = {ch.get('url') for ch in channels}
    added = 0
    for d in dialogs:
        if d['url'] not in existing_urls_after:
            channels.append({'name': d['name'], 'url': d['url'], 'category': AUTO_CATEGORY})
            added += 1
    save_channels(channels)
    xbmcgui.Dialog().notification(
        "Telegram Scraper",
        f"{len(dialogs)} Kanäle synchronisiert, {added} neu hinzugefügt",
        xbmcgui.NOTIFICATION_INFO, 3000
    )
    xbmc.executebuiltin('Container.Refresh')

def save_text_to_file(text):
    if not text:
        xbmcgui.Dialog().ok("Hinweis", "Kein Text vorhanden.")
        return
    filename = f"TG_Text_{int(datetime.now().timestamp())}.txt"
    target = os.path.join(get_download_path(), filename)
    try:
        with open(target, 'w', encoding='utf-8') as f:
            f.write(text)
        xbmcgui.Dialog().notification("Telegram Scraper", f"Text gespeichert: {filename}", xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as e:
        xbmcgui.Dialog().ok("Fehler", f"Text konnte nicht gespeichert werden:\n{e}")

def download_file_http(url, target_path):
    dialog = xbmcgui.DialogProgress()
    try:
        dialog.create("Download", "Lade Datei herunter...")
        request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=30) as response:
            total = int(response.getheader('Content-Length', 0))
            downloaded = 0
            with open(target_path, 'wb') as output:
                while True:
                    if dialog.iscanceled():
                        dialog.close()
                        try: os.remove(target_path)
                        except Exception: pass
                        xbmcgui.Dialog().notification("Telegram Scraper", "Download abgebrochen", xbmcgui.NOTIFICATION_INFO, 2000)
                        return False
                    block = response.read(64 * 1024)
                    if not block: break
                    output.write(block)
                    downloaded += len(block)
                    if total:
                        percent = int(downloaded * 100 / total)
                        dialog.update(percent, f"{percent}%")
        dialog.close()
        xbmcgui.Dialog().notification("Telegram Scraper", "Download abgeschlossen", xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    except Exception as e:
        dialog.close()
        xbmcgui.Dialog().ok("Download Fehler", str(e))
        return False

async def download_telethon_media_async(chat, msg_id, save_path):
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash: return None
    client = get_telethon_client(api_id, api_hash)
    dialog = xbmcgui.DialogProgress()
    dialog.create("Telegram Download", "Vorbereitung...")
    cancelled = [False]

    def progress(current, total):
        if dialog.iscanceled():
            cancelled[0] = True
            return
        if total:
            percent = int(current * 100 / total)
            dialog.update(percent, f"Lade herunter... {percent}%")
        else:
            dialog.update(0, "Lade herunter...")

    try:
        await client.connect()
        entity = await get_entity_safe(client, chat)
        message = await client.get_messages(entity, ids=int(msg_id))
        if message and message.media:
            download_task = asyncio.create_task(client.download_media(message, file=save_path, progress_callback=progress))
            while not download_task.done():
                await asyncio.sleep(0.5)
                if dialog.iscanceled():
                    cancelled[0] = True
                    download_task.cancel()
                    break
            if cancelled[0]:
                dialog.close()
                if os.path.exists(save_path):
                    try: os.remove(save_path)
                    except Exception: pass
                xbmcgui.Dialog().notification("Telegram Scraper", "Download abgebrochen", xbmcgui.NOTIFICATION_INFO, 2000)
                return None
            await download_task
            dialog.close()
            return save_path
    except asyncio.CancelledError:
        pass
    except Exception as e:
        xbmc.log(f"Telethon Download Error: {e}", xbmc.LOGERROR)
    finally:
        dialog.close()
        try: await client.disconnect()
        except BaseException: pass
        if os.path.exists(save_path) and cancelled[0]:
            try: os.remove(save_path)
            except Exception: pass
    return None

def download_media_action(item_data):
    media_type = item_data.get('type')
    url = item_data.get('url')
    msg_id = item_data.get('msg_id')
    chat = item_data.get('chat')
    file_name = item_data.get('file_name')
    if file_name:
        filename = f"TG_{msg_id}_{file_name}"
    else:
        extension = '.mp4' if media_type == 'video' else '.zip' if media_type == 'archive' else '.jpg'
        filename = f"TG_{msg_id or 'file'}_{int(datetime.now().timestamp())}{extension}"
    target = os.path.join(get_download_path(), filename)
    if chat and msg_id and TELETHON_AVAILABLE:
        res = run_async(download_telethon_media_async(chat, msg_id, target))
        if res:
            xbmcgui.Dialog().notification("Telegram Scraper", f"Gespeichert: {filename}", xbmcgui.NOTIFICATION_INFO, 3000)
            return
    elif url and url.startswith('http'):
        download_file_http(url, target)

def clean_url(url):
    return html.unescape(str(url)).strip().replace('&amp;', '&').strip('"\'') if url else ""

IMAGE_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.avif')
VIDEO_EXTENSIONS = ('.mp4', '.m4v', '.webm', '.mov', '.mkv', '.avi')

def is_image_url(url):
    url = clean_url(url)
    return bool(url and urllib.parse.urlsplit(url.lower()).path.endswith(IMAGE_EXTENSIONS))

def is_video_url(url):
    url = clean_url(url)
    return bool(url and urllib.parse.urlsplit(url.lower()).path.endswith(VIDEO_EXTENSIONS))

def extract_telegram_video_urls(page_content):
    if not page_content: return []
    results = []
    for tag_body in re.findall(r'<video\b[^>]*>(.*?)</video>', page_content, flags=re.IGNORECASE | re.DOTALL):
        for url in re.findall(r'(?:src|data-src|data-video-src)\s*=\s*[\'"]([^\'"]+)[\'"]', tag_body, flags=re.IGNORECASE):
            url = clean_url(url)
            if url.startswith('http') and not is_image_url(url) and (is_video_url(url) or 'telesco.pe/file/' in url) and url not in results:
                results.append(url)
    for url in re.findall(r'<source\b[^>]*(?:src|data-src)\s*=\s*[\'"]([^\'"]+)[\'"]', page_content, flags=re.IGNORECASE):
        url = clean_url(url)
        if url.startswith('http') and not is_image_url(url) and (is_video_url(url) or 'telesco.pe/file/' in url) and url not in results:
            results.append(url)
    for url in re.findall(r'(?:src|data-src|data-video-src)\s*=\s*[\'"](https?://[^\'"]+)[\'"]', page_content, flags=re.IGNORECASE):
        url = clean_url(url)
        if is_video_url(url) and not is_image_url(url) and url not in results:
            results.append(url)
    return results

def get_direct_telegram_stream_urls(chat, msg_id, url_hint=None):
    results = []
    if url_hint:
        hint = clean_url(url_hint)
        if hint.startswith('http') and not is_image_url(hint) and (is_video_url(hint) or 'telesco.pe/file/' in hint):
            results.append(hint)
            return results
    clean_chat = normalize_chat_name(chat)
    if not clean_chat or not msg_id: return results
    msg_id = str(msg_id).strip()
    candidate_urls = [
        f"https://t.me/{clean_chat}/{msg_id}?embed=1",
        f"https://t.me/{clean_chat}/{msg_id}",
        f"https://t.me/s/{clean_chat}/{msg_id}"
    ]
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8'
    }
    for page_url in candidate_urls:
        try:
            request = urllib.request.Request(page_url, headers=headers)
            with urllib.request.urlopen(request, timeout=8) as response:
                content = response.read().decode('utf-8', errors='ignore')
            for url in extract_telegram_video_urls(content):
                if url not in results and not is_image_url(url):
                    results.append(url)
            if results: break
        except Exception as e:
            xbmc.log(f"Telegram Player URL Fehler: {e}", xbmc.LOGDEBUG)
    return results

def build_kodi_stream_url(stream_url):
    stream_url = clean_url(stream_url)
    if not stream_url: return ""
    user_agent = urllib.parse.quote('Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36', safe='')
    referer = urllib.parse.quote('https://t.me/', safe='')
    return f"{stream_url}|User-Agent={user_agent}&Referer={referer}&Accept=*/*&Connection=keep-alive"

def get_proxy_stream_url(chat, msg_id, file_name=''):
    win = xbmcgui.Window(10000)
    port = win.getProperty(PROP_PORT)
    token = win.getProperty(PROP_TOKEN)
    if not port or not token: return None
    clean_chat = normalize_chat_name(chat)
    c_str = str(clean_chat) if clean_chat else ''
    m_str = str(msg_id) if msg_id else ''
    fn_str = str(file_name) if file_name else ''
    encoded_chat = urllib.parse.quote(c_str)
    encoded_file = urllib.parse.quote(fn_str)
    return f"http://127.0.0.1:{port}/stream?chat={encoded_chat}&msg={m_str}&file={encoded_file}&t={token}"

def play_telegram_video(item_data, chat=None, fallback_msg_id=None):
    if not item_data:
        xbmcgui.Dialog().ok("Fehler", "Keine Videodaten vorhanden.")
        return
    if item_data.get('type') != 'video':
        xbmcgui.Dialog().ok("Telegram", "Dieses Medium ist kein Video.")
        return
    msg_id = item_data.get('msg_id', fallback_msg_id)
    item_chat = item_data.get('chat', chat)
    title = item_data.get('title', 'Telegram Video') or 'Telegram Video'
    file_name = item_data.get('file_name', '')
    play_url = get_proxy_stream_url(item_chat, msg_id, file_name)
    if play_url:
        xbmc.log(f"Starte Video über Proxy: {play_url}", xbmc.LOGINFO)
    if not play_url:
        stream_urls = get_direct_telegram_stream_urls(item_chat, msg_id, item_data.get('url'))
        valid_urls = [url for url in stream_urls if url and not is_image_url(clean_url(url))]
        if valid_urls:
            play_url = build_kodi_stream_url(valid_urls[0])
    if not play_url:
        xbmcgui.Dialog().ok("Telegram Video", "Es konnte kein Wiedergabe-Stream ermittelt werden.")
        return
    play_item = xbmcgui.ListItem(label=title, path=play_url)
    play_item.setProperty('IsPlayable', 'true')
    play_item.setArt({'icon': video_icon_path, 'thumb': video_icon_path})
    try: play_item.setContentLookup(False)
    except Exception: pass
    set_kodi_info(play_item, title=title)
    xbmc.Player().play(play_url, play_item)

def handle_multi_media(media_list, text, chat=None, msg_id=None):
    if text:
        direct_url = find_m3u_url(text.strip(), [text.strip()])
        if direct_url:
            _ms_add_m3u_and_open(direct_url)
            return
    options, actions = [], []
    for item in media_list:
        media_type = item.get('type')
        item_msg_id = item.get('msg_id', msg_id)
        file_name = item.get('file_name')
        if media_type == 'video':
            options.extend(["Video abspielen", "Video herunterladen"])
            actions.extend([('play_video', item), ('download', item)])
        elif media_type == 'photo':
            options.extend(["Bild anzeigen", "Bild herunterladen"])
            actions.extend([('show_image', item.get('url'), item_msg_id), ('download', item)])
        elif media_type == 'archive':
            options.append(f"Archiv herunterladen ({file_name})" if file_name else "Archiv herunterladen")
            actions.append(('download', item))
            fn_lower = (file_name or '').lower()
            if fn_lower.endswith('.zip') or fn_lower.endswith('.rar') or fn_lower.endswith('.7z'):
                options.append(f"Archiv entpacken & nach Multistream importieren")
                actions.append(('import_archive', item))
    if text:
        options.extend(["Vollständigen Text anzeigen", "Text als .txt speichern"])
        actions.extend([('show_text', text, None), ('save_text', text, None)])
    if not options: return
    selected = xbmcgui.Dialog().select("Telegram Beitrag", options)
    if selected < 0: return
    action_type = actions[selected][0]
    action_val = actions[selected][1]
    if action_type == 'play_video':
        play_telegram_video(action_val, chat=chat, fallback_msg_id=msg_id)
    elif action_type == 'show_image':
        image_msg_id = actions[selected][2]
        if chat and image_msg_id and TELETHON_AVAILABLE:
            image_file = os.path.join(thumbs_dir, f"img_{image_msg_id}.jpg")
            if not os.path.exists(image_file):
                run_async(download_telethon_media_async(chat, image_msg_id, image_file))
            if os.path.exists(image_file):
                xbmc.executebuiltin(f'ShowPicture({image_file})')
        elif action_val:
            xbmc.executebuiltin(f'ShowPicture({action_val})')
    elif action_type == 'download':
        download_media_action(action_val)
    elif action_type == 'import_archive':
        item = action_val
        msg_id = item.get('msg_id', msg_id)
        file_name = item.get('file_name') or ''
        fn_lower = file_name.lower()
        ext = '.rar' if fn_lower.endswith('.rar') else '.7z' if fn_lower.endswith('.7z') else '.zip'
        tmp_name = f"TG_{msg_id}_import{ext}"
        tmp_path = os.path.join(get_download_path(), tmp_name)
        downloaded = False
        was_temp = False
        if not os.path.exists(tmp_path):
            was_temp = True
            if chat and msg_id and TELETHON_AVAILABLE:
                res = run_async(download_telethon_media_async(chat, msg_id, tmp_path))
                downloaded = bool(res)
            else:
                url = item.get('url', '')
                if url and url.startswith('http'):
                    try:
                        download_file_http(url, tmp_path)
                        downloaded = os.path.exists(tmp_path)
                    except Exception as e:
                        xbmc.log(f'[TGScraper] import_archive http download: {e}', xbmc.LOGERROR)
        else:
            downloaded = True
        if downloaded and os.path.exists(tmp_path):
            extract_and_import_archive(tmp_path)
            if was_temp and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass
        else:
            xbmcgui.Dialog().ok('Archiv-Import', 'Download fehlgeschlagen.')
    elif action_type == 'show_text':
        xbmcgui.Dialog().textviewer("Telegram Nachricht", action_val)
    elif action_type == 'save_text':
        save_text_to_file(action_val)

def parse_mac_txt(text):
    entries = []
    portal, mac, exp_str = None, None, None
    for line in text.splitlines():
        line = line.strip()
        low = line.lower()
        if low.startswith('portal') and ':' in line:
            val = line.split(':', 1)[1].strip()
            if val:
                portal = val
        elif low.startswith('mac addr') and ':' in line:
            val = line.split(':', 1)[1].strip()
            if val:
                mac = val
        elif low.startswith('exp date') and ':' in line:
            val = line.split(':', 1)[1].strip()
            if val:
                exp_str = val
        if portal and mac:
            entries.append((portal, mac, exp_str))
            portal, mac, exp_str = None, None, None
    return entries


def _ask_archive_password(hint=''):
    label = f'Archiv-Passwort{(" – " + hint) if hint else ""}'
    pwd = xbmcgui.Dialog().input(
        label,
        type=xbmcgui.INPUT_ALPHANUM,
        option=xbmcgui.ALPHANUM_HIDE_INPUT
    )
    return pwd if pwd else None


def _extract_single_archive(archive_path, dest_dir, user_pwd=None):
    ext = os.path.splitext(archive_path)[1].lower()
    fname = os.path.basename(archive_path)

    if ext == '.zip':
        try:
            import aeszip as _aeszip
            _has_aeszip = True
        except ImportError:
            _has_aeszip = False

        def _try_zip_extract(archive_path, dest_dir, pwd):
            pwd_s = pwd.decode() if isinstance(pwd, bytes) else pwd
            if _has_aeszip:
                try:
                    _aeszip.extractall_aes(archive_path, dest_dir, password=pwd_s)
                    return True
                except RuntimeError:
                    return False
                except Exception:
                    pass
            try:
                pwd_b = pwd_s.encode() if isinstance(pwd_s, str) else pwd_s
                with zipfile.ZipFile(archive_path, 'r') as zf:
                    zf.extractall(dest_dir, pwd=pwd_b)
                return True
            except Exception:
                return False

        candidates = [None, 'telegram']
        if user_pwd and user_pwd not in candidates:
            candidates.append(user_pwd)
        for pwd in candidates:
            if _try_zip_extract(archive_path, dest_dir, pwd):
                return True, pwd
        asked = _ask_archive_password(fname)
        if asked is None:
            return False, 'Kein Passwort eingegeben.'
        if _try_zip_extract(archive_path, dest_dir, asked):
            return True, asked
        return False, 'Falsches Passwort oder nicht unterstütztes ZIP-Format.'

    elif ext == '.rar':
        try:
            import rarfile
        except ImportError:
            return False, 'RAR-Unterstützung nicht verfügbar.\nrarfile-Bibliothek fehlt.'
        candidates = [None, 'telegram']
        if user_pwd and user_pwd not in candidates:
            candidates.append(user_pwd)
        for pwd in candidates:
            try:
                with rarfile.RarFile(archive_path, 'r') as rf:
                    rf.extractall(dest_dir, pwd=pwd)
                return True, pwd
            except (rarfile.BadRarPassword, rarfile.RarWrongPassword, rarfile.RarCRCError):
                continue
            except Exception as e:
                if 'password' in str(e).lower() or 'encrypt' in str(e).lower():
                    continue
                return False, str(e)
        asked = _ask_archive_password(fname)
        if asked is None:
            return False, 'Kein Passwort eingegeben.'
        try:
            with rarfile.RarFile(archive_path, 'r') as rf:
                rf.extractall(dest_dir, pwd=asked)
            return True, asked
        except Exception as e:
            return False, str(e)

    elif ext == '.7z':
        try:
            _py7zr_lib = os.path.join(xbmcaddon.Addon('script.module.py7zr').getAddonInfo('path'), 'lib')
            if _py7zr_lib not in sys.path:
                sys.path.insert(0, _py7zr_lib)
        except Exception:
            try:
                xbmc.executebuiltin('InstallAddon(script.module.py7zr)')
                for _ in range(60):
                    xbmc.sleep(500)
                    if xbmc.getCondVisibility('System.HasAddon(script.module.py7zr)'):
                        break
                _py7zr_lib = os.path.join(xbmcaddon.Addon('script.module.py7zr').getAddonInfo('path'), 'lib')
                if _py7zr_lib not in sys.path:
                    sys.path.insert(0, _py7zr_lib)
            except Exception as _ie:
                return False, f'py7zr konnte nicht installiert werden:\n{_ie}'
        import py7zr
        candidates = [None, 'telegram']
        if user_pwd and user_pwd not in candidates:
            candidates.append(user_pwd)
        for pwd in candidates:
            try:
                with py7zr.SevenZipFile(archive_path, mode='r', password=pwd) as sz:
                    sz.extractall(path=dest_dir)
                return True, pwd
            except (py7zr.exceptions.PasswordRequired, py7zr.exceptions.Bad7zFile):
                continue
            except Exception as e:
                if 'password' in str(e).lower() or 'encrypt' in str(e).lower():
                    continue
                return False, str(e)
        asked = _ask_archive_password(fname)
        if asked is None:
            return False, 'Kein Passwort eingegeben.'
        try:
            with py7zr.SevenZipFile(archive_path, mode='r', password=asked) as sz:
                sz.extractall(path=dest_dir)
            return True, asked
        except Exception as e:
            return False, str(e)

    return False, f'Nicht unterstütztes Archivformat: {ext}'


def _extract_recursive(archive_path, dest_dir, user_pwd=None, depth=0):
    if depth > 10:
        xbmc.log(f'[TGScraper] max recursion depth reached: {archive_path}', xbmc.LOGWARNING)
        return user_pwd

    ok, result = _extract_single_archive(archive_path, dest_dir, user_pwd)
    if not ok:
        xbmcgui.Dialog().ok('Archiv-Import', f'Fehler bei {os.path.basename(archive_path)}:\n{result}')
        return user_pwd

    if isinstance(result, str):
        user_pwd = result

    archive_exts = {'.zip', '.rar', '.7z'}
    for root, dirs, files in os.walk(dest_dir):
        for fn in files:
            if os.path.splitext(fn)[1].lower() in archive_exts:
                inner_path = os.path.join(root, fn)
                inner_dest = os.path.join(root, fn + '_extracted')
                os.makedirs(inner_dest, exist_ok=True)
                user_pwd = _extract_recursive(inner_path, inner_dest, user_pwd, depth + 1)
                try:
                    os.remove(inner_path)
                except Exception:
                    pass

    return user_pwd


def extract_and_import_archive(archive_path):
    import tempfile, shutil
    ext = os.path.splitext(archive_path)[1].lower()
    if ext not in ('.zip', '.rar', '.7z'):
        xbmcgui.Dialog().ok('Archiv-Import', f'Nicht unterstütztes Archivformat: {ext}')
        return

    tmp_dir = tempfile.mkdtemp(prefix='tgs_arc_')
    try:
        _extract_recursive(archive_path, tmp_dir)

        txt_files = []
        for root, dirs, files in os.walk(tmp_dir):
            for fn in files:
                if fn.lower().endswith('.txt'):
                    txt_files.append(os.path.join(root, fn))

        if not txt_files:
            xbmcgui.Dialog().ok('Archiv-Import', 'Keine .txt-Dateien im Archiv gefunden.')
            return

        all_entries = []
        for tf in txt_files:
            try:
                with open(tf, 'r', encoding='utf-8', errors='replace') as fh:
                    content = fh.read()
                all_entries.extend(parse_mac_txt(content))
            except Exception as e:
                xbmc.log(f'[TGScraper] extract_and_import_archive txt read: {e}', xbmc.LOGWARNING)

        if not all_entries:
            xbmcgui.Dialog().ok('Archiv-Import', f'{len(txt_files)} .txt-Datei(en) gefunden,\naber keine Portal+MAC-Einträge erkannt.')
            return

        added, skipped = 0, 0
        existing = mp_load_portals()

        for portal_url, mac_addr, exp_str in all_entries:
            try:
                base = mac_portal.normalise_base(portal_url)
                mac_up = mac_addr.strip().upper()
                if any(_mp_key(p) == ('mac', base, mac_up) for p in existing):
                    skipped += 1
                    continue
                exp_epoch = mp_parse_expiry(exp_str) if exp_str else None
                host = urllib.parse.urlparse(base).netloc or base
                entry = {'type': 'mac', 'url': base, 'mac': mac_up, 'name': host, 'ok': None}
                if exp_epoch:
                    entry['exp'] = exp_epoch
                existing.insert(0, entry)
                added += 1
            except Exception as e:
                xbmc.log(f'[TGScraper] extract_and_import_archive entry: {e}', xbmc.LOGWARNING)

        if added:
            mp_save_portals(existing)

        msg = f'{added} Portal+MAC-Einträge in den Scraper importiert (ungeprüft)'
        if skipped:
            msg += f', {skipped} übersprungen (bereits vorhanden)'
        msg += f'\n({len(txt_files)} .txt-Datei(en) verarbeitet)'
        msg += '\n\nJetzt unter MAC-Portale prüfen und bei Bedarf nach Multistream exportieren.'
        xbmcgui.Dialog().ok('Archiv-Import', msg)

        if added:
            xbmc.executebuiltin(f'Container.Update({addon_url}?action=mp_home,replace)')

    finally:
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass


def show_local_zip_addons():
    d_dir = get_download_path()
    if not xbmcvfs.exists(d_dir):
        xbmcgui.Dialog().ok("Eigene Dateien", "Der Download-Ordner existiert noch nicht.")
        return
    dirs, files = xbmcvfs.listdir(d_dir)
    zip_files = [f for f in files if f.lower().endswith('.zip')]
    if not zip_files:
        xbmcgui.Dialog().ok("Addon Installation", "Keine .zip-Dateien im Download-Ordner gefunden.\nLade zuerst ein Addon-Archiv herunter!")
        return
    selected_idx = xbmcgui.Dialog().select("Lokale Addons (.zip) installieren", zip_files)
    if selected_idx < 0: return
    chosen_zip = zip_files[selected_idx]
    zip_path = os.path.join(d_dir, chosen_zip)
    try:
        addons_dir = xbmcvfs.translatePath('special://home/addons/')
        addon_id_target = None
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(addons_dir)
            for name in zip_ref.namelist():
                parts = name.replace('\\', '/').split('/')
                if parts and parts[0]:
                    addon_id_target = parts[0]
                    break
        xbmcgui.Dialog().notification("Telegram Scraper", "Addon erfolgreich installiert & aktiviert!", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('UpdateLocalAddons')
        if addon_id_target:
            json_payload = json.dumps({
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": addon_id_target, "enabled": True},
                "id": 1
            })
            xbmc.executeJSONRPC(json_payload)
    except Exception as e:
        xbmc.log(f"Addon Installation Fehler: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Fehler", f"Addon konnte nicht installiert werden:\n{e}")

def is_first_start():
    return addon.getSetting('first_start_done').strip() != 'true'

def mark_first_start_done():
    addon.setSetting('first_start_done', 'true')

def show_manual(from_first_start=False):
    manual_path = os.path.join(addon_path, 'manual.md')
    if not os.path.exists(manual_path):
        xbmcgui.Dialog().ok("Handbuch", "Die Datei 'manual.md' wurde im Root-Ordner nicht gefunden.")
        return

    try:
        with open(manual_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        xbmcgui.Dialog().ok("Fehler", f"Konnte manual.md nicht lesen:\n{e}")
        return

    if not content.strip():
        content = "Kein Inhalt vorhanden."

    xbmcgui.Dialog().textviewer("Addon Handbuch", content)

    if from_first_start:
        mark_first_start_done()
        if not is_logged_in():
            xbmcgui.Dialog().ok("Willkommen", "Handbuch gelesen – bitte jetzt einloggen.")
            handle_login_flow()
        xbmc.executebuiltin('Container.Refresh')


def show_root_menu(selected_category=None):
    if selected_category is None and is_first_start():
        first_start_items = [
            ("[COLOR yellow]★[/COLOR] Addon Handbuch", f"{addon_url}?action=show_manual&first_start=1", False, "Bitte lesen Sie zuerst das Handbuch, bevor Sie fortfahren."),
            ("[COLOR blue]★[/COLOR] Addon schließen", f"{addon_url}?action=close_addon", False, "Schließt das Addon (ohne Logout)."),
        ]
        for label, url, is_folder, plot in first_start_items:
            item = xbmcgui.ListItem(label=label)
            item.setArt({'icon': icon_path, 'thumb': icon_path})
            set_kodi_info(item, plot=plot)
            if not is_folder:
                item.setProperty('IsPlayable', 'false')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=item, isFolder=is_folder)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        return

    if selected_category is None:
        logged_in = is_logged_in()
        username = get_saved_username() if logged_in else "User"
        def _menu_on(setting_id):
            return addon.getSetting(setting_id).lower() != 'false'

        all_items = [
            (
                f"[COLOR blue]★[/COLOR] Status: [COLOR blue]{username}[/COLOR] Angemeldet" if logged_in else "[COLOR blue]★[/COLOR] Status: User Abgemeldet (Klick zum Einloggen)",
                f"?action={'logout' if logged_in else 'login'}",
                False,
                "Hier sehen Sie Ihren aktuellen Anmeldestatus und können sich an- oder abmelden.",
                None
            ),
            ("[COLOR blue]★[/COLOR] Einstellungen öffnen", "?action=settings", False, "Konfigurieren Sie die API-Zugangsdaten, Download-Pfade und weitere Optionen.", "menu_settings"),
            ("[COLOR blue]★[/COLOR] Kanal hinzufügen", "?action=add_channel", False, "Fügen Sie einen neuen Telegram-Kanal oder Chat über den Namen oder Link hinzu.", "menu_add_channel"),
            ("[COLOR blue]★[/COLOR] Freund / Chat hinzufügen", "?action=add_friend", False, "Fügen Sie einen Freund oder Chat (aus Dialogen oder per Eingabe) zu Ihren Favoriten hinzu.", "menu_add_friend"),
            ("[COLOR blue]★[/COLOR] Eigene Dateien", "?action=show_downloads", True, "Verwalten und öffnen Sie Ihre heruntergeladenen Medien, Dokumente und Textdateien.", "menu_downloads"),
            ("[COLOR blue]★[/COLOR] Eigene Favoriten", "?action=show_category&cat=" + urllib.parse.quote('Eigene Favoriten'), True, "Durchsuchen Sie Ihre gespeicherten Favoriten-Kanäle.", "menu_favorites"),
            ("[COLOR blue]★[/COLOR] Automatisch Hinzugefügt", "?action=show_category&cat=" + urllib.parse.quote(AUTO_CATEGORY), True, "Alle Telegram-Kanäle und Chats, denen Sie beigetreten sind.", "menu_auto_folder"),
            ("[COLOR blue]★[/COLOR] Kanäle automatisch importieren", "?action=auto_import", False, "Importiert automatisch alle Telegram-Kanäle und Gruppen in den Ordner 'Automatisch Hinzugefügt'.", "menu_auto_import"),
            ("[COLOR blue]★[/COLOR] MAC-Portale & gespeicherte Zugänge", "?action=mp_home", True, "Gespeicherte MAC-Portale und Xtream-Playlist-Links (mit Ablaufdatum und Status). Hier kannst du auch neue Portale hinzufügen.", "menu_mac_portal"),
            ("[COLOR blue]★[/COLOR] Addons installieren", "?action=install_zip", False, "Installieren Sie lokale Addon-Pakete direkt aus dem Download-Ordner.", "menu_install_zip"),
            ("[COLOR blue]★[/COLOR] Addon Handbuch", "?action=show_manual", False, "Zeigt die Bedienungsanleitung (manual.md) im Vollbild an.", "menu_manual"),
            ("[COLOR blue]★[/COLOR] Addon schließen", "?action=close_addon", False, "Schließt das Addon (ohne Logout).", "menu_close")
        ]
        items = [(label, query, is_folder, plot) for label, query, is_folder, plot, sid in all_items if sid is None or _menu_on(sid)]
        for label, query, is_folder, plot in items:
            item = xbmcgui.ListItem(label=label)
            item.setArt({'icon': icon_path, 'thumb': icon_path})
            
            set_kodi_info(item, plot=plot)
            
            if not is_folder:
                item.setProperty('IsPlayable', 'false')
                
            xbmcplugin.addDirectoryItem(
                handle=addon_handle, 
                url=f"{addon_url}{query}", 
                listitem=item, 
                isFolder=is_folder
            )
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        return


    main_menu_item = xbmcgui.ListItem(label="[COLOR cyan] Hauptmenü[/COLOR]")
    main_menu_item.setArt({'icon': icon_path, 'thumb': icon_path})
    set_kodi_info(main_menu_item, plot="Zurück zum Hauptmenü.")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=addon_url, listitem=main_menu_item, isFolder=True)

    channels = [ch for ch in load_channels() if ch.get('category', 'Eigene Favoriten') == selected_category]
    for channel in channels:
        channel_url = channel.get('url')
        name = channel.get('name', channel_url)
        item = xbmcgui.ListItem(label=name)
        item.setArt({'icon': icon_path, 'thumb': icon_path})
        set_kodi_info(item, plot=f"Öffnen Sie den Kanal {name}, um die neuesten Beiträge und Medien anzuzeigen.")
        _topic_id = channel.get('topic_id')
        _tid_param = f"&topic_id={_topic_id}" if _topic_id is not None else ""
        _enc_url = urllib.parse.quote(str(channel_url))
        _enc_name = urllib.parse.quote(name)
        if selected_category == 'Eigene Favoriten':
            _kanal_cm_entry = ("Kanal entfernen", f"RunPlugin({addon_url}?action=remove_from_fav&url={_enc_url}{_tid_param})")
        else:
            _kanal_cm_entry = ("Kanal löschen", f"RunPlugin({addon_url}?action=delete_channel&url={_enc_url})")
        _cm = [
            ("Nachricht senden", f"RunPlugin({addon_url}?action=send_message&url={_enc_url})"),
            ("Zu Eigene Favoriten", f"RunPlugin({addon_url}?action=move_to_fav&url={_enc_url}&name={_enc_name}{_tid_param})"),
            _kanal_cm_entry
        ]
        if selected_category == 'Eigene Favoriten':
            _cm += [
                ("Nach oben", f"RunPlugin({addon_url}?action=fav_reorder&url={_enc_url}&direction=up{_tid_param})"),
                ("Nach unten", f"RunPlugin({addon_url}?action=fav_reorder&url={_enc_url}&direction=down{_tid_param})"),
                ("Ganz nach oben", f"RunPlugin({addon_url}?action=fav_reorder&url={_enc_url}&direction=top{_tid_param})"),
                ("Ganz nach unten", f"RunPlugin({addon_url}?action=fav_reorder&url={_enc_url}&direction=bottom{_tid_param})"),
                ("Umbenennen", f"RunPlugin({addon_url}?action=fav_rename&url={_enc_url}{_tid_param})")
            ]
        item.addContextMenuItems(_cm)
        _item_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(channel_url))}"
        if _topic_id:
            _item_url += f"&topic_id={_topic_id}"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=_item_url, listitem=item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
    return


    main_menu_item = xbmcgui.ListItem(label="[COLOR cyan] Hauptmenü[/COLOR]")
    main_menu_item.setArt({'icon': icon_path, 'thumb': icon_path})
    set_kodi_info(main_menu_item, plot="Zurück zum Hauptmenü.")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=addon_url, listitem=main_menu_item, isFolder=True)

    refresh_item = xbmcgui.ListItem(label="[COLOR yellow]Aktualisieren[/COLOR]")
    refresh_item.setArt({'icon': icon_path, 'thumb': icon_path})
    set_kodi_info(refresh_item, plot="Aktualisieren Sie die Ansicht.")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{addon_url}?action=show_category&cat={urllib.parse.quote(selected_category)}", listitem=refresh_item, isFolder=True)

    channels = [ch for ch in load_channels() if ch.get('category', 'Eigene Favoriten') == selected_category]
    for channel in channels:
        channel_url = channel.get('url')
        name = channel.get('name', channel_url)
        item = xbmcgui.ListItem(label=name)
        item.setArt({'icon': icon_path, 'thumb': icon_path})
        set_kodi_info(item, plot=f"Öffnen Sie den Kanal {name}, um die neuesten Beiträge und Medien anzuzeigen.")
        item.addContextMenuItems([
            ("Nachricht senden", f"RunPlugin({addon_url}?action=send_message&url={urllib.parse.quote(str(channel_url))})"),
            ("Zu Eigene Favoriten", f"RunPlugin({addon_url}?action=move_to_fav&url={urllib.parse.quote(str(channel_url))}&name={urllib.parse.quote(name)})"),
            ("Kanal löschen", f"RunPlugin({addon_url}?action=delete_channel&url={urllib.parse.quote(str(channel_url))})")
        ])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(channel_url))}", listitem=item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
    #return

    refresh_item = xbmcgui.ListItem(label="[COLOR yellow]Aktualisieren[/COLOR]")
    refresh_item.setArt({'icon': icon_path, 'thumb': icon_path})
    set_kodi_info(refresh_item, plot="Aktualisieren Sie die Ansicht.")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{addon_url}?action=show_category&cat={urllib.parse.quote(selected_category)}", listitem=refresh_item, isFolder=True)

    channels = [ch for ch in load_channels() if ch.get('category', 'Eigene Favoriten') == selected_category]
    for channel in channels:
        channel_url = channel.get('url')
        name = channel.get('name', channel_url)
        item = xbmcgui.ListItem(label=name)
        item.setArt({'icon': icon_path, 'thumb': icon_path})
        set_kodi_info(item, plot=f"Öffnen Sie den Kanal {name}, um die neuesten Beiträge und Medien anzuzeigen.")
        item.addContextMenuItems([
            ("Nachricht senden", f"RunPlugin({addon_url}?action=send_message&url={urllib.parse.quote(str(channel_url))})"),
            ("Zu Eigene Favoriten", f"RunPlugin({addon_url}?action=move_to_fav&url={urllib.parse.quote(str(channel_url))}&name={urllib.parse.quote(name)})"),
            ("Kanal löschen", f"RunPlugin({addon_url}?action=delete_channel&url={urllib.parse.quote(str(channel_url))})")
        ])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(channel_url))}", listitem=item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)

def show_downloads_folder():
    path = get_download_path()
    dirs, files = xbmcvfs.listdir(path)
    files = sorted(files)
    for filename in files:
        if filename.startswith('.'): continue
        filepath = os.path.join(path, filename)
        ext = os.path.splitext(filename)[1].lower()
        item = xbmcgui.ListItem(label=filename)
        item.setArt({'icon': icon_path, 'thumb': icon_path})
        
        delete_url = f"{addon_url}?action=delete_download&file={urllib.parse.quote(filename)}"
        send_file_url = f"RunPlugin({addon_url}?action=send_file_action&path={urllib.parse.quote(filepath)})"
        
        item.addContextMenuItems([
            ("Datei via Telegram senden", send_file_url),
            ("Datei löschen", f"RunPlugin({delete_url})")
        ])

        if ext in VIDEO_EXTENSIONS:
            item.setArt({'icon': video_icon_path, 'thumb': video_icon_path})
            item.setProperty('IsPlayable', 'true')
            set_kodi_info(item, plot=f"Heruntergeladene Videodatei: {filename}")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=filepath, listitem=item, isFolder=False)
        elif ext in IMAGE_EXTENSIONS:
            show_url = f"{addon_url}?action=show_local_image&path={urllib.parse.quote(filepath)}"
            set_kodi_info(item, plot=f"Heruntergeladenes Bild: {filename}")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=show_url, listitem=item, isFolder=False)
        elif ext == '.txt':
            show_txt_url = f"{addon_url}?action=show_local_txt&path={urllib.parse.quote(filepath)}"
            set_kodi_info(item, plot=f"Gespeicherte Textdatei: {filename}")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=show_txt_url, listitem=item, isFolder=False)
        else:
            set_kodi_info(item, plot=f"Heruntergeladene Datei: {filename}")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=filepath, listitem=item, isFolder=False)
            
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)

def delete_download_file(filename):
    if not filename: return
    path = os.path.join(get_download_path(), filename)
    if xbmcvfs.exists(path):
        try:
            xbmcvfs.delete(path)
            xbmcgui.Dialog().notification("Telegram Scraper", "Datei gelöscht", xbmcgui.NOTIFICATION_INFO, 2000)
        except Exception as e:
            xbmcgui.Dialog().ok("Fehler", f"Konnte Datei nicht löschen:\n{e}")
    xbmc.executebuiltin('Container.Refresh')

def is_archive_message(message):
    if not message:
        return False, ""
    
    file_name = ""
    text = getattr(message, 'text', '') or ''

    if getattr(message, 'file', None):
        if getattr(message.file, 'name', None):
            file_name = message.file.name
        ext = (getattr(message.file, 'ext', '') or '').lower()
        mime = (getattr(message.file, 'mime_type', '') or '').lower()
    else:
        ext, mime = "", ""

    if getattr(message, 'document', None) and getattr(message.document, 'attributes', None):
        for attr in message.document.attributes:
            if hasattr(attr, 'file_name') and attr.file_name:
                file_name = attr.file_name
                break
        if not mime and getattr(message.document, 'mime_type', None):
            mime = message.document.mime_type.lower()

    if not file_name and text:
        match = re.search(r'([\w\.-]+\.(?:zip|rar|7z|7zip|tar|gz|iso|cab|tgz|bz2|xz))', text, re.IGNORECASE)
        if match:
            file_name = match.group(1)

    if file_name and not ext:
        ext = os.path.splitext(file_name)[1].lower()

    archive_exts = ('.zip', '.rar', '.7z', '.7zip', '.tar', '.gz', '.iso', '.cab', '.tgz', '.bz2', '.xz', '.001', '.r00', '.r01', '.z01')
    fn_lower = file_name.lower() if file_name else ""

    is_arch = (
        ext in archive_exts or 
        any(x in mime for x in ('zip', 'rar', '7z', 'compressed', 'archive', 'x-tar', 'x-gzip', 'x-bzip2')) or
        any(fn_lower.endswith(x) for x in archive_exts) or
        bool(re.search(r'\.(zip|rar|7z|7zip|tar|gz|iso|cab|tgz|bz2|xz)(?:\.\d+)?$', fn_lower)) or
        ('[archiv:' in text.lower())
    )

    return is_arch, file_name

# ======================================================================
# TMDB-Poster für Videos
# ======================================================================
import time, unicodedata, difflib
import urllib.error

TMDB_CACHE_FILE = os.path.join(profile_dir, 'tmdb_cache.json')
TMDB_IMG_BASE = 'https://image.tmdb.org/t/p/w500'
TMDB_NEG_TTL = 7 * 24 * 3600      # "nichts gefunden" nach 7 Tagen erneut versuchen
TMDB_MIN_SIMILARITY = 0.72        # Mindest-Ähnlichkeit Suchtitel <-> TMDB-Titel
_tmdb_cache = None
_tmdb_bad_key = [None]
_tmdb_lock = threading.Lock()

_TMDB_QUALITY_RE = re.compile(
    r'\b(?:2160p|1080[pi]|720p|576p|480p|4k|uhd|hdr10?|web[ .\-]?dl|web[ .\-]?rip|webrip|web|'
    r'blu[ .\-]?ray|bdrip|brrip|hdrip|hdtv|dvdrip|dvd|x26[45]|h[ .]?26[45]|hevc|avc|xvid|divx|'
    r'aac|ac3|eac3|dts|dd5|german|deutsch|dubbed|dl|multi|ml|remux|proper|repack|extended|'
    r'uncut|unrated|imax|mkv|mp4|avi)\b', re.I)
_TMDB_TV_RE = re.compile(
    r'\bS\d{1,2}\s?E\d{1,3}\b|\bS\d{1,2}\b|\b\d{1,2}x\d{2}\b|\b(?:staffel|season|folge|episode)\s*\d+', re.I)

def tmdb_enabled():
    try:
        if addon.getSetting('tmdb_enabled').strip().lower() == 'false':
            return False
        return bool(addon.getSetting('tmdb_api_key').strip())
    except Exception:
        return False

def photo_match_enabled():
    """Foto-Zuordnung (Foto max. 5 Min vor/nach Video) – Standard: aus."""
    try:
        return addon.getSetting('photo_match').strip().lower() == 'true'
    except Exception:
        return False

def _tmdb_norm(s):
    s = (s or '').replace('ß', 'ss')
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode('ascii').lower()
    return re.sub(r'[^a-z0-9]+', ' ', s).strip()

def tmdb_guess_title(raw):
    """Macht aus Dateiname/Beitragstext (Titel, Jahr, ist_serie) – oder None."""
    if not raw:
        return None
    lines = [l.strip() for l in str(raw).splitlines() if l.strip()]
    if not lines:
        return None
    s = remove_emojis(lines[0]).strip()
    s = re.sub(r'https?://\S+|www\.\S+|[@#]\S+', ' ', s)
    s = re.sub(r'\.(?:mkv|mp4|avi|mov|m4v|ts|wmv|flv|webm)\s*$', '', s, flags=re.I)
    s = re.sub(r'^\s*\[[^\]]{1,30}\]\s*', '', s)
    if s.count('.') >= 2 and s.count(' ') <= s.count('.'):
        s = s.replace('.', ' ')
    s = s.replace('_', ' ')
    s = re.sub(r'\s+', ' ', s).strip()
    if not s:
        return None

    cur_year = datetime.now().year
    cut, is_tv, year = len(s), False, None

    m = _TMDB_TV_RE.search(s)
    if m and m.start() > 0:
        is_tv, cut = True, min(cut, m.start())

    ym = re.search(r'[\(\[]\s*((?:19|20)\d{2})\s*[\)\]]', s)
    if ym and ym.start() > 0 and int(ym.group(1)) <= cur_year + 1:
        year, cut = int(ym.group(1)), min(cut, ym.start())
    else:
        for ym in re.finditer(r'(?<!\d)((?:19|20)\d{2})(?!\d)', s):
            if ym.start() > 0 and int(ym.group(1)) <= cur_year + 1:
                year, cut = int(ym.group(1)), min(cut, ym.start())
                break

    qm = _TMDB_QUALITY_RE.search(s)
    if qm and qm.start() > 0:
        cut = min(cut, qm.start())

    marker_found = cut < len(s)
    title = s[:cut]
    title = re.sub(r'[\[\(\{][^\]\)\}]*[\]\)\}]', ' ', title)
    title = re.sub(r'[\[\(\{].*$', '', title)
    title = re.sub(r'^[\s\-–—:|,._]+|[\s\-–—:|,._]+$', '', title)
    title = re.sub(r'\s+', ' ', title).strip()
    if len(title) < 2:
        return None
    if not (year and title.isdigit()) and re.fullmatch(r'(?:video|vid|file|clip|mov|movie|img|pxl|dsc|screen ?recording|untitled)?[\s_\-]*[\d\s\-]*', title, re.I):
        return None   # generischer Dateiname wie video_12345
    if not marker_found and len(title) > 60:
        return None   # sieht nach Beschreibungstext aus, nicht nach Titel
    return title[:100], year, is_tv

def _tmdb_load_cache():
    global _tmdb_cache
    if _tmdb_cache is None:
        try:
            with open(TMDB_CACHE_FILE, 'r', encoding='utf-8') as f:
                _tmdb_cache = json.load(f)
        except Exception:
            _tmdb_cache = {}
    return _tmdb_cache

def _tmdb_save_cache():
    try:
        with open(TMDB_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(_tmdb_cache or {}, f, ensure_ascii=False)
    except Exception as e:
        xbmc.log(f"TMDB-Cache speichern: {e}", xbmc.LOGDEBUG)

def tmdb_clear_cache():
    global _tmdb_cache
    _tmdb_cache = {}
    try:
        if os.path.exists(TMDB_CACHE_FILE):
            os.remove(TMDB_CACHE_FILE)
    except Exception:
        pass

def _tmdb_get(path, query):
    key = addon.getSetting('tmdb_api_key').strip()
    headers = {'User-Agent': 'Kodi-TelegramScraper', 'Accept': 'application/json'}
    q = dict(query)
    if key.startswith('eyJ'):                     # v4 "API Read Access Token"
        headers['Authorization'] = 'Bearer ' + key
    else:                                         # v3 API-Key
        q['api_key'] = key
    url = 'https://api.themoviedb.org/3' + path + '?' + urllib.parse.urlencode(q)
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=6) as r:
            return json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        if e.code in (401, 403) and _tmdb_bad_key[0] != key:
            _tmdb_bad_key[0] = key
            try:
                xbmcgui.Dialog().notification("TMDB", "API-Key ungültig oder abgelehnt",
                                              xbmcgui.NOTIFICATION_ERROR, 4000)
            except Exception:
                pass
        raise

def _tmdb_pick(results, title, year):
    q = _tmdb_norm(title)
    if not q:
        return ""
    best_url, best_score = "", 0.0
    for r in (results or [])[:10]:
        if not r.get('poster_path'):
            continue
        date = r.get('release_date') or r.get('first_air_date') or ''
        if year and date[:4].isdigit() and abs(int(date[:4]) - year) > 1:
            continue
        score = max(
            [difflib.SequenceMatcher(None, q, _tmdb_norm(r.get(k))).ratio()
             for k in ('title', 'original_title', 'name', 'original_name') if r.get(k)] or [0.0])
        if score >= TMDB_MIN_SIMILARITY and score > best_score:
            best_url, best_score = TMDB_IMG_BASE + r['poster_path'], score
    return best_url

def _tmdb_lookup(title, year, is_tv, lang):
    for kind in (('tv', 'movie') if is_tv else ('movie', 'tv')):
        q = {'query': title, 'language': lang, 'include_adult': 'false'}
        if year:
            q['first_air_date_year' if kind == 'tv' else 'year'] = year
        data = _tmdb_get(f'/search/{kind}', q)
        url = _tmdb_pick(data.get('results'), title, year)
        if url:
            return url
    return ""

def tmdb_find_poster(candidates):
    """Sucht anhand von Dateiname / Beitragstext ein TMDB-Poster. '' wenn keins sicher passt."""
    if not tmdb_enabled():
        return ""
    if _tmdb_bad_key[0] and _tmdb_bad_key[0] == addon.getSetting('tmdb_api_key').strip():
        return ""
    lang = addon.getSetting('tmdb_language').strip() or 'de-DE'
    cache = _tmdb_load_cache()
    for cand in candidates:
        guess = tmdb_guess_title(cand)
        if not guess:
            continue
        title, year, is_tv = guess
        ck = f"{_tmdb_norm(title)}|{year or ''}|{'tv' if is_tv else 'mv'}|{lang}"
        hit = cache.get(ck)
        if hit:
            if hit.get('p'):
                return hit['p']
            if time.time() - hit.get('t', 0) < TMDB_NEG_TTL:
                continue
        try:
            poster = _tmdb_lookup(title, year, is_tv, lang)
        except Exception as e:
            xbmc.log(f"TMDB Fehler: {type(e).__name__}: {e}", xbmc.LOGDEBUG)
            return ""         # Netzwerkfehler: nichts zwischenspeichern
        with _tmdb_lock:
            cache[ck] = {'p': poster, 't': time.time()}
            _tmdb_save_cache()
        if poster:
            return poster
    return ""

def tmdb_test_connection():
    if not addon.getSetting('tmdb_api_key').strip():
        xbmcgui.Dialog().ok("TMDB", "Bitte zuerst einen TMDB API-Key in den Einstellungen eintragen.")
        return
    _tmdb_bad_key[0] = None
    try:
        _tmdb_get('/configuration', {})
        xbmcgui.Dialog().ok("TMDB", "Verbindung erfolgreich. Der API-Key funktioniert.")
    except urllib.error.HTTPError as e:
        xbmcgui.Dialog().ok("TMDB", f"Der API-Key wurde abgelehnt (HTTP {e.code}).")
    except Exception as e:
        xbmcgui.Dialog().ok("TMDB", f"Keine Verbindung zu TMDB:\n{e}")

PHOTO_MATCH_SECONDS = 300   # Foto und Video max. 5 Minuten auseinander
PHOTO_MATCH_ID_RANGE = 10    # so viele Nachrichten davor/danach werden geprüft

async def find_nearby_photo_thumb(message, client):
    """Sucht ein Foto im selben Chat, das höchstens 5 Minuten vor/nach dem Video
    hochgeladen wurde, und gibt den Pfad zum Vorschaubild zurück ('' wenn keins)."""
    try:
        if not message.date:
            return ""
        chat_key = str(getattr(message, 'chat_id', '') or 'x').replace('-', 'm')
        cache_file = os.path.join(thumbs_dir, f"vthumb_{chat_key}_{message.id}.jpg")
        none_file = os.path.join(thumbs_dir, f"vthumb_{chat_key}_{message.id}.none")
        if os.path.exists(cache_file) and os.path.getsize(cache_file) > 0:
            return cache_file
        if os.path.exists(none_file):
            return ""

        peer = await message.get_input_chat()
        ids = [i for i in range(message.id - PHOTO_MATCH_ID_RANGE, message.id + PHOTO_MATCH_ID_RANGE + 1)
               if i > 0 and i != message.id]
        neighbours = await client.get_messages(peer, ids=ids)
        best, best_diff = None, None
        for m in (neighbours or []):
            if not m or not getattr(m, 'photo', None) or not m.date:
                continue
            diff = abs((m.date - message.date).total_seconds())
            if diff <= PHOTO_MATCH_SECONDS and (best is None or diff < best_diff):
                best, best_diff = m, diff

        if best is not None:
            try: await client.download_media(best, file=cache_file, thumb=True)
            except Exception: pass
            if os.path.exists(cache_file) and os.path.getsize(cache_file) > 0:
                return cache_file

        # Nur "kein Foto gefunden" merken, wenn das Video schon älter ist
        # (ein passendes Foto könnte sonst noch nachkommen).
        try:
            now = datetime.now(message.date.tzinfo)
            if now - message.date > timedelta(seconds=PHOTO_MATCH_SECONDS * 2):
                open(none_file, 'w').close()
        except Exception:
            pass
    except Exception as e:
        xbmc.log(f"find_nearby_photo_thumb: {type(e).__name__}: {e}", xbmc.LOGDEBUG)
    return ""

# ======================================================================
# M3U-Playlists aus Telegram lesen und abspielen
# ======================================================================
M3U_DIR = os.path.join(profile_dir, 'm3u')
M3U_PAGE_SIZE = 100
M3U_MAX_BYTES = 30 * 1024 * 1024
_M3U_EXTS = ('.m3u', '.m3u8')
_M3U_MIMES = ('audio/x-mpegurl', 'audio/mpegurl', 'application/x-mpegurl',
              'application/vnd.apple.mpegurl', 'application/mpegurl')
_M3U_SCHEMES = re.compile(r'^(?:https?|rtmps?|rtsp|udp|rtp|mms|mmsh|ftp|smb|nfs|plugin)://', re.I)

def is_m3u_message(message):
    """Ist die Nachricht eine .m3u/.m3u8-Datei? -> (True/False, Dateiname)"""
    try:
        f = getattr(message, 'file', None)
        if not f:
            return False, ""
        name = getattr(f, 'name', '') or ''
        if not name and getattr(message, 'document', None):
            for attr in (getattr(message.document, 'attributes', None) or []):
                if getattr(attr, 'file_name', None):
                    name = attr.file_name
        ext = (getattr(f, 'ext', '') or '').lower()
        mime = (getattr(f, 'mime_type', '') or '').lower()
        low = name.lower()
        if low.endswith(_M3U_EXTS) or ext in _M3U_EXTS or mime in _M3U_MIMES:
            return True, name or "Playlist.m3u"
    except Exception:
        pass
    return False, ""

def parse_m3u(text):
    """Liest eine M3U-Datei. Gibt Liste von Einträgen zurück:
    {'name','url','logo','group','duration','ua','referer'}"""
    entries = []
    cur = {}
    ua = referer = None
    group_ext = ""
    for raw in (text or "").replace('\ufeff', '').splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith('#EXTINF'):
            m = re.match(r'#EXTINF:\s*(-?\d+(?:\.\d+)?)\s*(.*)$', line, re.I)
            dur, rest = (0.0, "")
            if m:
                dur, rest = float(m.group(1)), m.group(2)
            attrs = {k.lower(): v for k, v in re.findall(r'([\w\-]+)="([^"]*)"', rest)}
            rest_clean = re.sub(r'[\w\-]+="[^"]*"', '', rest)
            name = rest_clean.split(',', 1)[1].strip() if ',' in rest_clean else ''
            cur = {'name': name or attrs.get('tvg-name', ''), 'logo': attrs.get('tvg-logo', ''),
                   'group': attrs.get('group-title', ''), 'duration': dur}
        elif line.upper().startswith('#EXTGRP:'):
            group_ext = line.split(':', 1)[1].strip()
        elif line.upper().startswith('#EXTVLCOPT:'):
            opt = line.split(':', 1)[1]
            if '=' in opt:
                k, v = opt.split('=', 1)
                k = k.strip().lower()
                if k == 'http-user-agent': ua = v.strip()
                elif k in ('http-referrer', 'http-referer'): referer = v.strip()
        elif line.startswith('#'):
            continue
        else:
            if not _M3U_SCHEMES.match(line):
                cur, ua, referer = {}, None, None
                continue
            name = cur.get('name') or urllib.parse.unquote(line.split('?')[0].rstrip('/').split('/')[-1]) or line
            entries.append({
                'name': name, 'url': line, 'logo': cur.get('logo', ''),
                'group': cur.get('group') or group_ext, 'duration': cur.get('duration', 0.0),
                'ua': ua, 'referer': referer})
            cur, ua, referer = {}, None, None
    return entries

def _m3u_is_vod(e):
    """Film/Serie (statt Live-TV)? Dann lohnt sich die TMDB-Suche."""
    url = e['url'].lower().split('?')[0]
    return (e.get('duration', 0) or 0) > 0 or url.endswith(VIDEO_EXTENSIONS) \
        or '/movie/' in url or '/series/' in url

def _m3u_clean_name(name):
    # Länder-/Sprach-Präfixe wie "DE | " oder "|DE| " entfernen
    return re.sub(r'^\s*(?:\|[^|]{1,10}\|\s*|[A-Za-z]{2,3}\s*[|:]\s*)', '', name or '').strip()

def _m3u_play_url(e):
    url = e['url']
    if url.lower().startswith(('http://', 'https://')) and '|' not in url:
        hdr = []
        if e.get('ua'): hdr.append('User-Agent=' + urllib.parse.quote(e['ua']))
        if e.get('referer'): hdr.append('Referer=' + urllib.parse.quote(e['referer']))
        if hdr:
            url += '|' + '&'.join(hdr)
    return url

_M3U_LINK_RE = re.compile(r'https?://[^\s<>"\']+', re.I)
_M3U_LINK_HINT = re.compile(r'(?i)\.m3u8?(?:[?&#]|$)|[?&](?:type|output)=m3u|/get\.php\?')

def find_m3u_url(text, extra_urls=None):
    """Sucht in einem Beitrag einen Link auf eine M3U-Playlist (z.B. .../get.php?...&type=m3u)."""
    cands = list(extra_urls or []) + _M3U_LINK_RE.findall(text or '')
    for u in cands:
        u = html.unescape(u or '').strip().rstrip('.,;:!?)]}»')
        if u.lower().startswith(('http://', 'https://')) and _M3U_LINK_HINT.search(u):
            return u
    return None

def m3u_fetch_url_text(url, force=False):
    """Lädt eine M3U-Playlist von einer URL (30 Min. lokal zwischengespeichert).
    Mit Fortschrittsdialog und Abbrechen-Knopf, damit Kodi nicht 'hängt'."""
    import hashlib, zlib
    os.makedirs(M3U_DIR, exist_ok=True)
    path = os.path.join(M3U_DIR, 'url_' + hashlib.md5(url.encode('utf-8')).hexdigest() + '.m3u')
    host = urllib.parse.urlparse(url).netloc
    dlg = None
    try:
        if not (os.path.exists(path) and os.path.getsize(path) > 0 and time.time() - os.path.getmtime(path) < (0 if force else get_setting_int('m3u_cache_hours', 24) * 3600)):
            dlg = xbmcgui.DialogProgress()
            dlg.create("Playlist", f"Verbinde mit {host} ...\nDer Server braucht dafür manchmal etwas länger.")
            req = urllib.request.Request(url, headers={
                'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20', 'Accept': '*/*', 'Accept-Encoding': 'gzip'})
            start = time.time()
            DEADLINE = 300                      # max. 5 Minuten insgesamt
            parts, total_bytes = [], 0
            with urllib.request.urlopen(req, timeout=20) as r:
                length = int(r.headers.get('Content-Length') or 0)
                dec = zlib.decompressobj(16 + zlib.MAX_WBITS) if (r.headers.get('Content-Encoding') or '').lower() == 'gzip' else None
                received = 0
                while True:
                    if dlg.iscanceled():
                        xbmc.log("M3U-Download abgebrochen", xbmc.LOGINFO)
                        return None
                    if time.time() - start > DEADLINE:
                        xbmcgui.Dialog().ok("Playlist", "Der Server antwortet zu langsam (Zeitlimit 5 Minuten).")
                        return None
                    chunk = r.read(256 * 1024)
                    if not chunk:
                        break
                    received += len(chunk)
                    data = dec.decompress(chunk) if dec else chunk
                    total_bytes += len(data)
                    if total_bytes > M3U_MAX_BYTES:
                        xbmcgui.Dialog().ok("Playlist", "Die Playlist ist zu groß (über 30 MB).")
                        return None
                    parts.append(data)
                    pct = int(received * 100 / length) if length else min(95, int(total_bytes / (M3U_MAX_BYTES / 100.0)))
                    dlg.update(pct, f"Lade Playlist von {host} ...\n{total_bytes / 1048576:.1f} MB geladen")
                if dec:
                    parts.append(dec.flush())
            with open(path + '.part', 'wb') as f:
                for part in parts:
                    f.write(part)
            os.replace(path + '.part', path)
        with open(path, 'rb') as f:
            data = f.read()
        try: return data.decode('utf-8-sig')
        except UnicodeDecodeError: return data.decode('latin-1')
    except Exception as e:
        xbmc.log(f"M3U-Link Fehler ({host}): {type(e).__name__}: {e}", xbmc.LOGERROR)
        return None
    finally:
        if dlg is not None:
            try: dlg.close()
            except Exception: pass

# ======================================================================
# Xtream-Codes API: statt 30 MB M3U nur Kategorien/Listen on demand laden
# ======================================================================
XT_PAGE_SIZE = 100

_COUNTRY_RE = re.compile(r'^[\s|\[\(]*([A-Za-z]{2,3})\s*[|:\-–\]\)]')
_COUNTRY_ALIASES = {'GERMAN': 'DE', 'GERMANY': 'DE', 'DEUTSCH': 'DE', 'DEUTSCHLAND': 'DE',
                    'AUSTRIA': 'AT', 'OESTERREICH': 'AT', 'ÖSTERREICH': 'AT',
                    'SWISS': 'CH', 'SCHWEIZ': 'CH', 'SWITZERLAND': 'CH', 'UK': 'GB'}
_COUNTRY_NAMES = {'DE': 'Deutschland', 'AT': 'Österreich', 'CH': 'Schweiz', 'GB': 'Großbritannien', 'US': 'USA',
                  'FR': 'Frankreich', 'TR': 'Türkei', 'ES': 'Spanien', 'IT': 'Italien', 'NL': 'Niederlande',
                  'PL': 'Polen', 'PT': 'Portugal', 'RU': 'Russland', 'AR': 'Arabisch', 'BE': 'Belgien',
                  'GR': 'Griechenland', 'RO': 'Rumänien', 'SE': 'Schweden', 'NO': 'Norwegen', 'DK': 'Dänemark',
                  'FI': 'Finnland', 'CA': 'Kanada', 'IN': 'Indien', 'BR': 'Brasilien', 'AL': 'Albanien'}

def category_country(name):
    """Ländercode aus Kategorienamen wie 'DE | Sport', '|DE| News', '[DE] Kino', 'GERMANY ...'."""
    n = (name or '').strip()
    m = _COUNTRY_RE.match(n)
    code = m.group(1).upper() if m else ''
    if not code and n:
        code = re.split(r'[\s|:\-–/]+', n.strip(' |[]()'), 1)[0].upper()
        code = _COUNTRY_ALIASES.get(code, '')
    return _COUNTRY_ALIASES.get(code, code)

def preferred_countries():
    raw = addon.getSetting('pref_countries')
    raw = raw if raw.strip() else 'DE,AT,CH'
    return [c.strip().upper() for c in re.split(r'[,; ]+', raw) if c.strip()]

def country_rank(code):
    pref = preferred_countries()
    return pref.index(code) if code in pref else len(pref)

def sort_preferred(names):
    """Bevorzugte Länder zuerst; sonst bleibt die Reihenfolge des Anbieters."""
    return sorted(names, key=lambda n: country_rank(category_country(n)))

def group_by_country_enabled():
    return addon.getSetting('group_by_country').strip().lower() != 'false'
_XT_CACHE = {}

def xtream_from_url(url):
    """Erkennt Xtream-Links (.../get.php?username=U&password=P&type=m3u) -> (base, user, pass) oder None."""
    try:
        u = urllib.parse.urlparse(url)
        q = {k.lower(): v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        if q.get('username') and q.get('password') and u.scheme in ('http', 'https') and \
                re.search(r'(?i)(get|player_api|panel_api)\.php$', u.path):
            return f"{u.scheme}://{u.netloc}", q['username'], q['password']
    except Exception:
        pass
    return None

def xt_api(creds, action=None, ttl=900, **extra):
    """Ruft player_api.php auf (JSON). Ergebnisse werden 15 Min. im Speicher gehalten."""
    base, user, pwd = creds
    q = {'username': user, 'password': pwd}
    if action:
        q['action'] = action
    q.update({k: v for k, v in extra.items() if v is not None})
    url = f"{base}/player_api.php?" + urllib.parse.urlencode(q)
    hit = _XT_CACHE.get(url)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    disk = dcache_get('xt', url, ttl)
    if disk is not None:
        _XT_CACHE[url] = (time.time(), disk)
        return disk
    req = urllib.request.Request(url, headers={'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20', 'Accept-Encoding': 'gzip'})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = r.read(40 * 1024 * 1024)
        if (r.headers.get('Content-Encoding') or '').lower() == 'gzip':
            import gzip
            data = gzip.decompress(data)
    js = json.loads(data.decode('utf-8', 'replace'))
    _XT_CACHE[url] = (time.time(), js)
    dcache_put('xt', url, js)
    return js

def xt_play_url(creds, kind, sid, ext=None):
    base, user, pwd = creds
    u, p = urllib.parse.quote(user, safe=''), urllib.parse.quote(pwd, safe='')
    if kind == 'live':
        return f"{base}/live/{u}/{p}/{sid}.{ext or 'ts'}"
    if kind == 'vod':
        return f"{base}/movie/{u}/{p}/{sid}.{ext or 'mp4'}"
    return f"{base}/series/{u}/{p}/{sid}.{ext or 'mp4'}"

def xt_posters(names):
    """TMDB-Poster für Namen parallel holen (nur wenn aktiviert)."""
    out = {}
    if not tmdb_enabled() or not names:
        return out
    from concurrent.futures import ThreadPoolExecutor
    try:
        with ThreadPoolExecutor(max_workers=6) as ex:
            res = list(ex.map(lambda n: tmdb_find_poster([_m3u_clean_name(n)]), names))
        out = {n: p for n, p in zip(names, res) if p}
    except Exception as e:
        xbmc.log(f"XT TMDB Fehler: {e}", xbmc.LOGDEBUG)
    return out

def xt_fail(e):
    xbmc.log(f"[Xtream] Fehler: {type(e).__name__}: {e}", xbmc.LOGERROR)
    xbmcgui.Dialog().ok("Playlist", f"Server hat nicht geantwortet:\n{type(e).__name__}: {e}")
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False, cacheToDisc=False)

def show_xt_menu():
    src = params.get('src')
    if not src:
        return
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False, cacheToDisc=False)
    _ms_add_m3u_and_open(src)

def show_xt_info():
    creds = xtream_from_url(params.get('src'))
    if not creds:
        return
    try:
        ui = (xt_api(creds, ttl=0) or {}).get('user_info') or {}
    except Exception as e:
        return xt_fail(e)
    lines = [f"Server: {urllib.parse.urlparse(creds[0]).netloc}", f"Status: {ui.get('status', '?')}"]
    exp = str(ui.get('exp_date') or '')
    if exp.isdigit():
        lines.append("Gültig bis: " + datetime.fromtimestamp(int(exp)).strftime('%d.%m.%Y %H:%M'))
    elif ui.get('exp_date') is None:
        lines.append("Gültig bis: unbegrenzt")
    if ui.get('max_connections'):
        lines.append(f"Verbindungen: {ui.get('active_cons', '0')} von {ui.get('max_connections')}")
    xbmcgui.Dialog().ok("Konto-Info", "\n".join(lines))

def show_xt_cats():
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False, cacheToDisc=False)

def show_xt_list():
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False, cacheToDisc=False)

def show_xt_seasons():
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False, cacheToDisc=False)

def show_xt_episodes():
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False, cacheToDisc=False)



M3U_CACHE_MAX_AGE_DAYS = 7

def cleanup_m3u_cache(max_age_days=M3U_CACHE_MAX_AGE_DAYS, everything=False):
    """Löscht gespeicherte Playlists (alle oder nur älter als X Tage). Gibt freigegebene Bytes zurück."""
    freed = 0
    limit = time.time() - max_age_days * 86400
    for folder in (M3U_DIR, DCACHE_DIR):
        try:
            if not os.path.isdir(folder):
                continue
            for fn in os.listdir(folder):
                fp = os.path.join(folder, fn)
                try:
                    if os.path.isfile(fp) and (everything or os.path.getmtime(fp) < limit):
                        size = os.path.getsize(fp)
                        os.remove(fp)
                        freed += size
                except Exception:
                    pass
        except Exception as e:
            xbmc.log(f"Cache aufräumen: {e}", xbmc.LOGDEBUG)
    return freed

_m3u_parsed = {'key': None, 'entries': None}

def m3u_parse_cached(key, text):
    k = (key, len(text))
    if _m3u_parsed['key'] != k:
        _m3u_parsed['entries'] = parse_m3u(text)
        _m3u_parsed['key'] = k
    return _m3u_parsed['entries']

async def m3u_get_text_async(chat, msg_id):
    """Lädt die M3U-Datei aus Telegram (mit lokalem Cache) und gibt den Text zurück."""
    os.makedirs(M3U_DIR, exist_ok=True)
    key = re.sub(r'[^\w\-]', '_', str(chat))
    path = os.path.join(M3U_DIR, f"{key}_{msg_id}.m3u")
    if not (os.path.exists(path) and os.path.getsize(path) > 0):
        api_id, api_hash = get_credentials()
        if not api_id or not api_hash:
            return None
        client = get_telethon_client(api_id, api_hash)
        try:
            await client.connect()
            entity = await get_entity_safe(client, chat)
            message = await client.get_messages(entity, ids=int(msg_id))
            if not message or not message.media:
                return None
            size = getattr(message.file, 'size', 0) or 0
            if size > M3U_MAX_BYTES:
                xbmcgui.Dialog().ok("Playlist", "Die Playlist ist zu groß (über 30 MB).")
                return None
            await client.download_media(message, file=path)
        except Exception as e:
            xbmc.log(f"M3U Download Fehler: {type(e).__name__}: {e}", xbmc.LOGERROR)
            return None
        finally:
            try: await client.disconnect()
            except BaseException: pass
    try:
        with open(path, 'rb') as f:
            data = f.read()
        try: return data.decode('utf-8-sig')
        except UnicodeDecodeError: return data.decode('latin-1')
    except Exception:
        return None

def show_m3u_playlist(chat, msg_id, group=None, page=0, src=None):
    if not src:
        if not is_logged_in():
            xbmcgui.Dialog().ok("Telegram", "Bitte zuerst bei Telegram einloggen, um Playlists zu laden.")
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            return
        url = run_async(_m3u_resolve_url_async(chat, msg_id))
        if not url:
            xbmcgui.Dialog().ok("Playlist", "Keine M3U-URL in dieser Nachricht gefunden.")
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            return
        src = url
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False, cacheToDisc=False)
    _ms_add_m3u_and_open(src)


async def _m3u_resolve_url_async(chat, msg_id):
    try:
        api_id, api_hash = get_credentials()
        if not api_id or not api_hash:
            return None
        client = get_telethon_client(api_id, api_hash)
        await client.connect()
        try:
            entity = await get_entity_safe(client, chat)
            message = await client.get_messages(entity, ids=int(msg_id))
            if not message:
                return None
            text = message.text or ''
            ent_urls = [getattr(e, 'url', None) for e in (message.entities or [])]
            url = find_m3u_url(text, ent_urls)
            if url:
                return url
            if message.document:
                os.makedirs(M3U_DIR, exist_ok=True)
                key = re.sub(r'[^\w\-]', '_', str(chat))
                dest = os.path.join(M3U_DIR, f"{key}_{msg_id}.m3u")
                path = await client.download_media(message, file=dest)
                if path and os.path.exists(path):
                    with open(path, 'r', encoding='utf-8', errors='replace') as f:
                        first = f.read(200)
                    if first.strip().startswith('#EXTM3U') or 'http' in first:
                        return 'file://' + path
        finally:
            try: await client.disconnect()
            except BaseException: pass
    except Exception as e:
        xbmc.log(f"[TGScraper] _m3u_resolve_url_async: {e}", xbmc.LOGERROR)
    return None


def _local_m3u_to_proxy_url(file_path):
    win = xbmcgui.Window(10000)
    port = win.getProperty(PROP_PORT)
    token = win.getProperty(PROP_TOKEN)
    if not port or not token:
        return None
    return f"http://127.0.0.1:{port}/m3u?file={urllib.parse.quote(file_path, safe='')}&t={token}"

_MS_GENERIC_NAMES = {'get', 'playlist', 'index', 'stream', 'live', 'iptv', 'm3u', 'channel', 'channels'}

def _ms_derive_name(m3u_url):
    try:
        parsed = urllib.parse.urlparse(m3u_url)
        qs = urllib.parse.parse_qs(parsed.query)
        if parsed.hostname in ('127.0.0.1', 'localhost') and 'file' in qs:
            base = os.path.splitext(os.path.basename(qs['file'][0]))[0]
            base = re.sub(r'_\d+$', '', base).replace('_', ' ').strip()
            if base:
                return base
        if not parsed.scheme or parsed.scheme == 'file':
            base = os.path.splitext(os.path.basename(parsed.path))[0]
            base = re.sub(r'_\d+$', '', base).replace('_', ' ').strip()
            if base:
                return base
        for key in ('username', 'user', 'name', 'title'):
            val = (qs.get(key) or [''])[0].strip()
            if val:
                return val
        base = os.path.splitext(os.path.basename(parsed.path.rstrip('/')))[0]
        if base and base.lower() not in _MS_GENERIC_NAMES:
            return base
        return parsed.netloc or m3u_url[:60]
    except Exception:
        return m3u_url[:60]


def _ms_add_m3u_and_open(m3u_url):
    if m3u_url.startswith('file://'):
        m3u_url = m3u_url[7:]
    conn = _ms_open_db()
    if conn is None:
        return
    new_id = None
    try:
        existing = conn.execute("SELECT m3uUrl FROM providers WHERE type='m3u'").fetchall()
        already = any((r[0] or '').strip() == m3u_url.strip() for r in existing)
        if not already:
            name = _ms_derive_name(m3u_url)
            cur = conn.execute(
                'INSERT INTO providers (name, type, m3uUrl, isEnabled, createdAt) VALUES (?,?,?,1,?)',
                (name, 'm3u', m3u_url, int(time.time()))
            )
            new_id = cur.lastrowid
            conn.commit()
    except Exception as e:
        xbmc.log(f"[TGScraper] _ms_add_m3u_and_open: {e}", xbmc.LOGERROR)
    finally:
        conn.close()
    if new_id:
        xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.multistream/?action=silent_sync_provider&id={new_id}&source=telegramscraper)')
    _open_multistream()

# ======================================================================
# MAC-Portale (Stalker): Live-TV, Filme, Serien aus Portal-URL + MAC
# ======================================================================
import mac_portal

PORTALS_FILE = os.path.join(profile_dir, 'portals.json')

# --- Festplatten-Cache: Kodi startet das Addon bei jedem Klick neu, Arbeitsspeicher bleibt nicht erhalten ---
DCACHE_DIR = os.path.join(profile_dir, 'cache')
MP_SESSION_TTL = 1200            # Sitzung (Token) 20 Min. weiterverwenden
MP_VERIFY_TTL = 12 * 3600        # Handshake+Bild-Test gilt 12 Std. als erledigt

def _dc_path(ns, key):
    import hashlib
    return os.path.join(DCACHE_DIR, ns + '_' + hashlib.md5(str(key).encode('utf-8')).hexdigest() + '.json')

def dcache_get(ns, key, ttl):
    try:
        p_ = _dc_path(ns, key)
        if time.time() - os.path.getmtime(p_) < ttl:
            with open(p_, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return None

def dcache_put(ns, key, data, max_bytes=20 * 1024 * 1024):
    try:
        raw = json.dumps(data, ensure_ascii=False)
        if len(raw) > max_bytes:
            return
        os.makedirs(DCACHE_DIR, exist_ok=True)
        p_ = _dc_path(ns, key)
        with open(p_ + '.tmp', 'w', encoding='utf-8') as f:
            f.write(raw)
        os.replace(p_ + '.tmp', p_)
    except Exception as e:
        xbmc.log(f"dcache_put: {e}", xbmc.LOGDEBUG)

def dcache_drop(ns, key):
    try:
        os.remove(_dc_path(ns, key))
    except Exception:
        pass
MP_PAGE_SIZE = 100
_MP_CLIENTS = {}
_MP_CACHE = {}

def mp_url(**kw):
    return addon_url + '?' + urllib.parse.urlencode({k: v for k, v in kw.items() if v is not None})

def mp_load_portals():
    try:
        with open(PORTALS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []

def mp_save_portals(items):
    try:
        with open(PORTALS_FILE, 'w', encoding='utf-8') as f:
            json.dump(items[:200], f, ensure_ascii=False, indent=1)
    except Exception as e:
        xbmc.log(f"[MAC-Portal] speichern: {e}", xbmc.LOGDEBUG)

def mp_parse_expiry(val):
    """Ablaufdatum aus Text/Epoch -> Epoch-Sekunden oder None."""
    s_ = str(val or '').strip()
    if not s_:
        return None
    if s_.isdigit():
        return int(s_) if int(s_) > 10 ** 9 else None
    for fmt in ('%B %d, %Y, %I:%M %p', '%B %d, %Y, %I %p', '%B %d, %Y', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%d.%m.%Y', '%d.%m.%Y %H:%M'):
        try:
            return int(datetime.strptime(s_, fmt).timestamp())
        except ValueError:
            continue
    return None

def _mp_key(p):
    return (p.get('type', 'mac'), p.get('url'), p.get('mac', ''))

def _ms_auto_write(kind, url, mac, name):
    try:
        conn = _ms_open_db()
        if conn is None:
            return False
        now = int(time.time())
        new_id = 0
        if kind == 'mac':
            server = _ms_normalise_url(url) + '/c/'
            mac_up = (mac or '').strip().upper()
            dup = conn.execute(
                'SELECT 1 FROM providers WHERE type=? AND lower(serverUrl)=? AND upper(stalkerMacAddress)=?',
                ('stalker', _ms_normalise_url(server).lower(), mac_up)
            ).fetchone()
            if not dup:
                cur = conn.execute(
                    'INSERT INTO providers (name, type, serverUrl, stalkerMacAddress, isEnabled, createdAt) VALUES (?,?,?,?,1,?)',
                    (name, 'stalker', server, mac_up, now)
                )
                new_id = cur.lastrowid
        elif kind == 'xt':
            creds = xtream_from_url(url)
            if creds:
                host, user, pwd = creds
                dup = conn.execute(
                    'SELECT 1 FROM providers WHERE type=? AND lower(rtrim(serverUrl,"/"))=? AND username=?',
                    ('xtream', host.rstrip('/').lower(), user)
                ).fetchone()
                if not dup:
                    cur = conn.execute(
                        'INSERT INTO providers (name, type, serverUrl, username, password, isEnabled, createdAt) VALUES (?,?,?,?,?,1,?)',
                        (name, 'xtream', host, user, pwd, now)
                    )
                    new_id = cur.lastrowid
        else:
            dup = conn.execute(
                'SELECT 1 FROM providers WHERE type=? AND m3uUrl=?',
                ('m3u', url)
            ).fetchone()
            if not dup:
                cur = conn.execute(
                    'INSERT INTO providers (name, type, m3uUrl, isEnabled, createdAt) VALUES (?,?,?,1,?)',
                    (name, 'm3u', url, now)
                )
                new_id = cur.lastrowid
        conn.commit()
        conn.close()
        return new_id
    except Exception as e:
        xbmc.log(f'[TelegramScraper] Multistream auto-write: {e}', xbmc.LOGDEBUG)
        return False


def mp_remember(portal, mac, exp=None, ok=True, kind='mac', why='', unclear=False):
    """Portal/Playlist-Zugang speichern bzw. aktualisieren (nach oben = zuletzt benutzt)."""
    base = mac_portal.normalise_base(portal) if kind == 'mac' else portal
    key = (kind, base, mac or '')
    items = mp_load_portals()
    old = next((p for p in items if _mp_key(p) == key), None)
    items = [p for p in items if _mp_key(p) != key]
    entry = dict(old or {})
    host = urllib.parse.urlparse(base).netloc
    entry.update({'type': kind, 'url': base, 'mac': mac or '', 'name': entry.get('name') or host,
                  'checked': int(time.time()), 'ok': ok, 'why': '' if ok else why, 'unclear': bool(unclear and ok)})
    if exp:
        entry['exp'] = exp
    items.insert(0, entry)
    mp_save_portals(items)
    if ok is True:
        new_id = _ms_auto_write(kind, base, mac, entry.get('name') or host)
        if new_id:
            xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.multistream/?action=silent_sync_provider&id={new_id}&source=telegramscraper)')
            _open_multistream()

def mp_touch(portal, mac):
    """Eintrag nur als 'zuletzt benutzt' nach oben schieben (Status/Prüfzeit bleiben)."""
    base = mac_portal.normalise_base(portal)
    items = mp_load_portals()
    for k, p_ in enumerate(items):
        if _mp_key(p_) == ('mac', base, mac):
            items.insert(0, items.pop(k))
            mp_save_portals(items)
            return

def mp_add_if_missing(portal, mac):
    """MAC speichern, ohne einen bekannten Status zu überschreiben."""
    base = mac_portal.normalise_base(portal)
    if not any(_mp_key(p) == ('mac', base, mac) for p in mp_load_portals()):
        mp_remember(base, mac, ok=None)

def mp_forget(portal, mac, kind='mac'):
    base = mac_portal.normalise_base(portal) if kind == 'mac' else portal
    key = (kind, base, mac or '')
    mp_save_portals([p for p in mp_load_portals() if _mp_key(p) != key])

def mp_is_bad(p):
    exp = p.get('exp')
    return p.get('ok') is False or bool(exp and exp < time.time())

def mp_status_text(p):
    now, exp = time.time(), p.get('exp')
    if p.get('ok') is False:
        return "[COLOR red]kein Bild[/COLOR]" if p.get('why') == 'picture' else "[COLOR red]kein Zugang[/COLOR]"
    if exp:
        d = datetime.fromtimestamp(exp).strftime('%d.%m.%Y')
        if exp < now:
            return f"[COLOR red]abgelaufen {d}[/COLOR]"
        tail = " [COLOR yellow](Bildtest unklar)[/COLOR]" if p.get('unclear') else ""
        if exp - now < 7 * 86400:
            return f"[COLOR orange]bis {d}[/COLOR]{tail}"
        return f"[COLOR lime]bis {d}[/COLOR]{tail}"
    if p.get('ok') and p.get('unclear'):
        return "[COLOR yellow]Zugang ok (Bildtest unklar)[/COLOR]"
    return "[COLOR gray]ungeprüft[/COLOR]" if p.get('ok') is None else ""

def mp_expiry_of(cl):
    try:
        inf = cl.account_info()
        return mp_parse_expiry(inf.get('end_date') or inf.get('phone'))
    except Exception:
        return None

def mp_picture_test_enabled():
    try:
        return addon.getSetting('mp_picture_test').strip().lower() != 'false'
    except Exception:
        return True

def mp_verify(cl):
    """-> (ok, unclear, Grund). Unklare Ergebnisse (Serverfehler/Timeout) blockieren nichts."""
    if not mp_picture_test_enabled():
        return True, False, ''
    state, why = cl.verify_playback()
    if state is None:
        return True, True, why
    return bool(state), False, why

def mp_check_one(portal, mac):
    """Voller Test einer MAC: Handshake, Zugang UND ob ein Bild kommt. -> (ok, exp, why, grund)"""
    cl = mac_portal.MacPortalClient(portal, mac)
    try:
        cl.connect()
    except Exception as e:
        return False, None, 'access', f"Portal nicht erreichbar ({type(e).__name__})"
    if not cl.check():
        return False, None, 'access', "MAC hat keinen Zugang (abgelaufen oder ungültig)"
    exp = mp_expiry_of(cl)
    ok, unclear, why = mp_verify(cl)
    return ok, exp, ('' if ok else 'picture'), (('unclear:' + why) if unclear else why)

def mp_get_client(portal, macs):
    """Verbundenen Client liefern. Prüft auch, ob wirklich ein Bild kommt (nicht nur der Handshake)."""
    macs = [m.strip().upper() for m in (macs or []) if m and m.strip()]
    base = mac_portal.normalise_base(portal)
    host = urllib.parse.urlparse(base).netloc
    log = lambda m: xbmc.log(f"[MAC-Portal] {m}", xbmc.LOGDEBUG)
    for mac in macs:
        # 1) Sitzung im Speicher oder auf der Festplatte: kein Handshake, kein Test, kein Dialog
        cl = _MP_CLIENTS.get((base, mac))
        if cl and time.time() - cl.connected_at < MP_SESSION_TTL:
            return cl
        sess = dcache_get('mpsess', f"{base}|{mac}", MP_SESSION_TTL)
        if sess:
            cl = mac_portal.MacPortalClient(base, mac, log=log)
            if cl.restore(sess):
                _MP_CLIENTS[(base, mac)] = cl
                mp_touch(base, mac)
                return cl
    # 2) Kürzlich schon geprüft (Handshake + Bild): nur neuer Handshake, ohne Tests
    if len(macs) == 1:
        mac = macs[0]
        entry = next((x for x in mp_load_portals() if _mp_key(x) == ('mac', base, mac)), None)
        if entry and entry.get('ok') and time.time() - (entry.get('checked') or 0) < MP_VERIFY_TTL:
            cl = mac_portal.MacPortalClient(base, mac, log=log)
            try:
                cl.connect()
                _MP_CLIENTS[(base, mac)] = cl
                dcache_put('mpsess', f"{base}|{mac}", cl.export_session())
                mp_touch(base, mac)
                return cl
            except Exception as e:
                log(f"Schnellverbindung fehlgeschlagen ({type(e).__name__}) - voller Test")
    # 3) Voller Test (Handshake, Zugang, Bild)
    dlg = xbmcgui.DialogProgress()
    dlg.create("MAC-Portal", f"Verbinde mit {host} ...")
    last_err = ""
    try:
        for i, mac in enumerate(macs):
            if dlg.iscanceled():
                return None
            dlg.update(int(i * 100 / max(1, len(macs))), f"Verbinde mit {host}\nMAC {i + 1}/{len(macs)}: {mac}")
            cl = mac_portal.MacPortalClient(base, mac, log=lambda m: xbmc.log(f"[MAC-Portal] {m}", xbmc.LOGDEBUG))
            try:
                cl.connect()
                if not cl.check():
                    last_err = "MAC hat keinen Zugang (abgelaufen oder ungültig)"
                    mp_remember(base, mac, ok=False, why='access')
                    continue
                dlg.update(60, f"{mac}\nPrüfe, ob ein Bild kommt ...")
                ok, unclear, why = mp_verify(cl)
            except Exception as e:
                last_err = str(e)
                xbmc.log(f"[MAC-Portal] {mac}: {last_err}", xbmc.LOGDEBUG)
                mp_remember(base, mac, ok=False, why='access')
                continue
            exp = mp_expiry_of(cl)
            if not ok:
                mp_remember(base, mac, exp=exp, ok=False, why='picture')
                last_err = f"Handshake ok, aber kein Bild: {why}"
                if len(macs) == 1:
                    try: dlg.close()
                    except Exception: pass
                    if xbmcgui.Dialog().yesno("Kein Bild",
                            f"{why}\nDas Portal meldet sich an, liefert aber keinen Stream.\nTrotzdem öffnen?"):
                        _MP_CLIENTS[(base, mac)] = cl
                        dcache_put('mpsess', f"{base}|{mac}", cl.export_session())
                        return cl
                continue
            _MP_CLIENTS[(base, mac)] = cl
            dcache_put('mpsess', f"{base}|{mac}", cl.export_session())
            mp_remember(base, mac, exp=exp, ok=True, unclear=unclear)
            return cl
    finally:
        try: dlg.close()
        except Exception: pass
    if last_err and "kein Bild" not in last_err or len(macs) != 1:
        xbmcgui.Dialog().ok("MAC-Portal", "Keine Verbindung möglich.\n"
                            + (last_err or "Portal nicht erreichbar.")
                            + "\nTipp: Die MAC-Adresse ist oft abgelaufen oder das Portal gesperrt.")
    return None

def mp_finish(ok=True):
    xbmcplugin.endOfDirectory(addon_handle, succeeded=ok, cacheToDisc=False)

def mp_item(label, url, folder=True, art=None, plot=None, playable=False):
    li = xbmcgui.ListItem(label=label)
    pic = art or icon_path
    li.setArt({'icon': pic, 'thumb': pic, 'poster': pic})
    if plot:
        set_kodi_info(li, title=label, plot=plot)
    if playable:
        li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=folder)
    return li

def mp_cached(client, key, loader, ttl=1800):
    ck = (client.base, client.mac, key)
    hit = dcache_get('mp', ck, ttl)
    if hit is not None:
        return hit
    data = loader()
    dcache_put('mp', ck, data)
    return data

def mp_client_from_params():
    macs = [m for m in (params.get('mac') or params.get('macs') or '').split(',') if m]
    return mp_get_client(params.get('portal'), macs)

def show_mp_home():
    mp_item("[COLOR yellow][+][/COLOR] Portal manuell hinzufügen (URL + MAC)", mp_url(action='mp_add'), folder=False,
            plot="Portal-Adresse und MAC-Adresse eingeben.")
    entries = mp_load_portals()
    entries = [p for p in entries if not mp_is_bad(p)] + [p for p in entries if mp_is_bad(p)]   # funktionierende zuerst
    for p in entries:
        kind = p.get('type', 'mac')
        status = mp_status_text(p)
        who = p.get('mac', '')
        tag = "MAC" if kind == 'mac' else "Xtream"
        label = f"[COLOR orange]{tag}[/COLOR] {p.get('name') or p.get('url')}  [COLOR gray]{who}[/COLOR]  {status}".rstrip()
        if kind == 'mac':
            target = mp_url(action='mp_menu', portal=p.get('url'), mac=who)
        else:
            target = f"{addon_url}?action=xt_menu&src={urllib.parse.quote(p.get('url', ''), safe='')}"
        checked = datetime.fromtimestamp(p['checked']).strftime('%d.%m.%Y %H:%M') if p.get('checked') else '-'
        li = mp_item(label, target, plot=f"{p.get('name')}\nZuletzt benutzt/geprüft: {checked}")
        ctx_args = dict(portal=p.get('url'), mac=who, kind=kind)
        li.addContextMenuItems([("Umbenennen", f"RunPlugin({mp_url(action='mp_rename', **ctx_args)})"),
                                ("Entfernen", f"RunPlugin({mp_url(action='mp_remove', **ctx_args)})")])
    if entries:
        mp_item("[COLOR gray][ Alle prüfen ][/COLOR]", mp_url(action='mp_check_all'), folder=False,
                plot="Prüft jeden gespeicherten Zugang erneut (Zugang + Ablaufdatum).")
        mp_item("[COLOR gray][ Abgelaufene / defekte entfernen ][/COLOR]", mp_url(action='mp_clean'), folder=False)
        mp_item("[COLOR gray][ Portale nach Multistream kopieren ][/COLOR]", mp_url(action='mp_export_multistream'), folder=False,
                plot="Kopiert ausgewählte Zugänge in die Datenbank von plugin.video.multistream und startet Multistream.")
    mp_finish()

def mp_rename():
    kind = params.get('kind', 'mac')
    base = mac_portal.normalise_base(params.get('portal')) if kind == 'mac' else params.get('portal')
    key = (kind, base, params.get('mac', ''))
    items = mp_load_portals()
    for p in items:
        if _mp_key(p) == key:
            new = xbmcgui.Dialog().input("Neuer Name", defaultt=p.get('name') or '')
            if new:
                p['name'] = new.strip()
                mp_save_portals(items)
            break
    xbmc.executebuiltin('Container.Refresh')

def mp_check_all():
    items = mp_load_portals()
    if not items:
        return
    dlg = xbmcgui.DialogProgress()
    dlg.create("Zugänge prüfen", "Starte ...")
    good = 0
    try:
        for i, p in enumerate(items):
            if dlg.iscanceled():
                break
            kind = p.get('type', 'mac')
            dlg.update(int(i * 100 / len(items)), f"{i + 1}/{len(items)}: {p.get('name')} {p.get('mac', '')}")
            ok, exp = False, None
            try:
                if kind == 'xt':
                    creds = xtream_from_url(p.get('url'))
                    ui = (xt_api(creds, ttl=0) or {}).get('user_info') or {}
                    ok = str(ui.get('auth', '1')) != '0' and str(ui.get('status', 'Active')).lower() in ('active', '')
                    exp = int(ui['exp_date']) if str(ui.get('exp_date', '')).isdigit() else None
                else:
                    ok, exp, why, _msg = mp_check_one(p.get('url'), p.get('mac'))
                    p['why'] = why
                    p['unclear'] = bool(ok and str(_msg).startswith('unclear:'))
            except Exception as e:
                xbmc.log(f"[MAC-Portal] prüfen {p.get('name')}: {type(e).__name__}", xbmc.LOGDEBUG)
            p['ok'], p['checked'] = ok, int(time.time())
            if ok:
                p['why'] = ''
            if exp:
                p['exp'] = exp
            good += 1 if (ok and not mp_is_bad(p)) else 0
    finally:
        try: dlg.close()
        except Exception: pass
        mp_save_portals(items)
    xbmcgui.Dialog().notification("Zugänge prüfen", f"{good} von {len(items)} funktionieren", xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.executebuiltin('Container.Refresh')

def mp_clean():
    items = mp_load_portals()
    bad = [p for p in items if mp_is_bad(p)]
    if not bad:
        xbmcgui.Dialog().notification("Zugänge", "Nichts zu entfernen", xbmcgui.NOTIFICATION_INFO, 3000)
        return
    if xbmcgui.Dialog().yesno("Entfernen", f"{len(bad)} abgelaufene/defekte Einträge löschen?"):
        mp_save_portals([p for p in items if not mp_is_bad(p)])
        xbmc.executebuiltin('Container.Refresh')

IPTVMASTER_ID = 'plugin.video.iptvmaster'

def iptvmaster_dir():
    return xbmcvfs.translatePath(f'special://profile/addon_data/{IPTVMASTER_ID}/')

def _strip_colors(txt):
    return re.sub(r'\[/?COLOR[^\]]*\]', '', txt or '')

def _im_entry_from_ours(p):
    """Unseren Eintrag in das Format von IPTV Master umwandeln."""
    import uuid
    now = int(time.time())
    kind = p.get('type', 'mac')
    base_entry = {'id': str(uuid.uuid4()), 'enabled': False, 'm3u_url': '', 'xc_host': '', 'xc_user': '',
                  'xc_pass': '', 'stb_url': '', 'stb_mac': '', 'epg_url': '', 'epg_show': True,
                  'created': now, 'updated': now}
    name = p.get('name') or urllib.parse.urlparse(p.get('url', '')).netloc
    if kind == 'mac':
        base_entry.update({'name': f"{name} {p.get('mac', '')[-8:]}".strip(), 'type': 'stb',
                           'stb_url': mac_portal.normalise_base(p.get('url')) + '/c/', 'stb_mac': p.get('mac', '')})
        return base_entry
    creds = xtream_from_url(p.get('url'))
    if creds:
        base_entry.update({'name': f"{name} {creds[1]}".strip(), 'type': 'xc',
                           'xc_host': creds[0], 'xc_user': creds[1], 'xc_pass': creds[2]})
    else:
        base_entry.update({'name': name, 'type': 'm3u', 'm3u_url': p.get('url', '')})
    return base_entry

def _im_same(a, b):
    """Gleicher Zugang? (Portal+MAC bzw. Host+Benutzer+Passwort bzw. M3U-URL)"""
    if a.get('type') != b.get('type'):
        return False
    if a.get('type') == 'stb':
        return (mac_portal.normalise_base(a.get('stb_url')).lower() == mac_portal.normalise_base(b.get('stb_url')).lower()
                and (a.get('stb_mac') or '').strip().upper() == (b.get('stb_mac') or '').strip().upper())
    if a.get('type') == 'xc':
        return ((a.get('xc_host') or '').strip().rstrip('/').lower() == (b.get('xc_host') or '').strip().rstrip('/').lower()
                and a.get('xc_user') == b.get('xc_user') and a.get('xc_pass') == b.get('xc_pass'))
    return (a.get('m3u_url') or '').strip() == (b.get('m3u_url') or '').strip()

def mp_export_to_iptvmaster():
    ours = mp_load_portals()
    if not ours:
        xbmcgui.Dialog().ok("Kopieren", "Es sind keine gespeicherten Zugänge vorhanden.")
        return
    target_dir = iptvmaster_dir()
    target = os.path.join(target_dir, 'portals.json')
    installed = xbmc.getCondVisibility(f'System.HasAddon({IPTVMASTER_ID})')
    if not os.path.isdir(target_dir) and not installed:
        xbmcgui.Dialog().ok("Kopieren", f"IPTV Master ({IPTVMASTER_ID}) wurde nicht gefunden.\n"
                            f"Ordner nicht vorhanden:\n{target_dir}")
        return
    # Ziel einlesen (kaputte Datei NIE überschreiben)
    existing = []
    if os.path.exists(target):
        try:
            with open(target, 'r', encoding='utf-8') as f:
                existing = json.load(f)
            if not isinstance(existing, list):
                raise ValueError("keine Liste")
        except Exception as e:
            xbmcgui.Dialog().ok("Kopieren", f"Die portals.json von IPTV Master ist nicht lesbar ({e}).\nNichts wurde verändert.")
            return

    ordered = [p for p in ours if not mp_is_bad(p)] + [p for p in ours if mp_is_bad(p)]
    labels = []
    for p in ordered:
        tag = "MAC" if p.get('type', 'mac') == 'mac' else "Xtream"
        labels.append(_strip_colors(f"{tag}: {p.get('name') or p.get('url')} {p.get('mac', '')} {mp_status_text(p)}").strip())
    # Nichts vorab ankreuzen: Antippen = ankreuzen. (Vorher waren alle vorangekreuzt, Antippen hat abgewählt.)
    all_label = "★ Alle funktionierenden Zugänge"
    picked = xbmcgui.Dialog().multiselect("Nach IPTV Master kopieren (antippen = ankreuzen)", [all_label] + labels)
    if not picked:
        return
    chosen = sorted({i - 1 for i in picked if i > 0})
    if 0 in picked:
        chosen = sorted(set(chosen) | {i for i, p in enumerate(ordered) if not mp_is_bad(p)})
    if not chosen:
        return

    added, skipped = 0, 0
    for i in chosen:
        new = _im_entry_from_ours(ordered[i])
        if any(_im_same(new, old) for old in existing if isinstance(old, dict)):
            skipped += 1
            continue
        existing.append(new)
        added += 1
    if not added:
        xbmcgui.Dialog().ok("Kopieren", f"Nichts kopiert: {skipped} Portal(e) sind dort schon vorhanden.")
        return
    try:
        os.makedirs(target_dir, exist_ok=True)
        if os.path.exists(target):
            import shutil
            shutil.copy2(target, target + '.bak')           # Sicherung der alten Datei
        with open(target + '.tmp', 'w', encoding='utf-8') as f:
            json.dump(existing, f, ensure_ascii=False, indent=2)
        os.replace(target + '.tmp', target)
    except Exception as e:
        xbmcgui.Dialog().ok("Kopieren", f"Schreiben fehlgeschlagen:\n{e}")
        return
    xbmcgui.Dialog().ok("Kopieren", f"{added} Portal(e) nach IPTV Master kopiert"
                        + (f", {skipped} übersprungen (schon vorhanden)" if skipped else "") + ".\n\n"
                        "In IPTV Master sind sie zunächst ausgeschaltet. Dort aktivieren und IPTV Master "
                        "ggf. einmal neu öffnen.\nSicherung: portals.json.bak")

MULTISTREAM_ID = 'plugin.video.multistream'

def _open_multistream():
    pbar = xbmcgui.DialogProgress()
    pbar.create('Multistream', 'Wird gestartet …')
    pbar.update(0)
    def _run():
        for i in range(101):
            if pbar.iscanceled():
                break
            secs = 5 - int(i / 20)
            pbar.update(i, f'Multistream öffnet in {secs} Sekunde{"n" if secs != 1 else ""} …')
            xbmc.sleep(50)
        pbar.close()
        xbmc.executebuiltin(f'ActivateWindow(10025,plugin://{MULTISTREAM_ID}/,return)')
    threading.Thread(target=_run, daemon=True).start()

def _ms_db_path():
    return xbmcvfs.translatePath(f'special://profile/addon_data/{MULTISTREAM_ID}/multistream.db')

def _ms_normalise_url(url):
    url = (url or '').strip().rstrip('/')
    for suffix in ('/c', '/c/'):
        if url.endswith(suffix):
            url = url[:-len(suffix)].rstrip('/')
    return url

def _ms_install():
    if not xbmcgui.Dialog().yesno('Multistream', f'{MULTISTREAM_ID} ist nicht installiert.\nJetzt installieren?'):
        return False
    xbmc.executebuiltin(f'InstallAddon({MULTISTREAM_ID})')
    for _ in range(60):
        xbmc.sleep(500)
        if xbmc.getCondVisibility(f'System.HasAddon({MULTISTREAM_ID})'):
            return True
    xbmcgui.Dialog().ok('Multistream', 'Installation nicht abgeschlossen.\nBitte manuell installieren und erneut versuchen.')
    return False

def _ms_open_db():
    db_path = _ms_db_path()
    installed = xbmc.getCondVisibility(f'System.HasAddon({MULTISTREAM_ID})')
    if not os.path.exists(db_path) and not installed:
        if not _ms_install():
            return None
    import sqlite3
    try:
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        conn = sqlite3.connect(db_path)
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute("""CREATE TABLE IF NOT EXISTS providers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT NOT NULL,
            serverUrl TEXT NOT NULL DEFAULT '',
            username TEXT NOT NULL DEFAULT '',
            password TEXT NOT NULL DEFAULT '',
            m3uUrl TEXT NOT NULL DEFAULT '',
            epgUrl TEXT NOT NULL DEFAULT '',
            stalkerMacAddress TEXT NOT NULL DEFAULT '',
            stalkerDeviceProfile TEXT NOT NULL DEFAULT 'MAG250',
            stalkerDeviceTimezone TEXT NOT NULL DEFAULT 'Europe/Berlin',
            stalkerDeviceLocale TEXT NOT NULL DEFAULT 'de',
            stalkerCompatMode INTEGER NOT NULL DEFAULT -1,
            stalkerSerialNumber TEXT NOT NULL DEFAULT '',
            userAgent TEXT NOT NULL DEFAULT '',
            isEnabled INTEGER NOT NULL DEFAULT 1,
            lastSyncedAt INTEGER NOT NULL DEFAULT 0,
            lastSyncError TEXT NOT NULL DEFAULT '',
            createdAt INTEGER NOT NULL DEFAULT 0,
            epgOffset INTEGER NOT NULL DEFAULT 0,
            epgSyncInterval INTEGER NOT NULL DEFAULT 0,
            catchupType TEXT NOT NULL DEFAULT '',
            altEpgUrls TEXT NOT NULL DEFAULT '',
            lineExpiry INTEGER NOT NULL DEFAULT 0,
            useInternalEpg INTEGER NOT NULL DEFAULT -1,
            telegramChannel TEXT NOT NULL DEFAULT '',
            vodMode INTEGER NOT NULL DEFAULT 0
        )""")
        conn.commit()
        return conn
    except Exception as e:
        xbmcgui.Dialog().ok('Multistream', f'Datenbankfehler:\n{e}')
        return None

def mp_export_to_multistream():
    ours = mp_load_portals()
    if not ours:
        xbmcgui.Dialog().ok('Multistream', 'Keine gespeicherten Portale vorhanden.')
        return

    conn = _ms_open_db()
    if conn is None:
        return

    try:
        existing_rows = conn.execute('SELECT type, serverUrl, stalkerMacAddress, username, m3uUrl FROM providers').fetchall()
    except Exception:
        existing_rows = []

    def _dup_stalker(url, mac):
        norm = _ms_normalise_url(url).lower()
        for row in existing_rows:
            if row[0] == 'stalker' and _ms_normalise_url(row[1]).lower() == norm:
                if (row[2] or '').strip().upper() == mac.strip().upper():
                    return True
        return False

    def _dup_xtream(host, user):
        h = (host or '').strip().rstrip('/').lower()
        for row in existing_rows:
            if row[0] == 'xtream':
                if (row[1] or '').strip().rstrip('/').lower() == h and (row[3] or '') == user:
                    return True
        return False

    def _dup_m3u(m3u_url):
        u = (m3u_url or '').strip()
        for row in existing_rows:
            if row[0] == 'm3u' and (row[4] or '').strip() == u:
                return True
        return False

    ordered = [p for p in ours if not mp_is_bad(p)] + [p for p in ours if mp_is_bad(p)]
    labels = []
    for p in ordered:
        kind = p.get('type', 'mac')
        if kind == 'mac':
            tag = 'MAC'
        elif kind == 'xt':
            tag = 'Xtream'
        else:
            tag = 'M3U'
        labels.append(_strip_colors(f"{tag}: {p.get('name') or p.get('url')} {p.get('mac', '')} {mp_status_text(p)}").strip())

    all_label = '★ Alle funktionierenden Zugänge'
    picked = xbmcgui.Dialog().multiselect('Nach Multistream kopieren (antippen = ankreuzen)', [all_label] + labels)
    if not picked:
        conn.close()
        return

    chosen = sorted({i - 1 for i in picked if i > 0})
    if 0 in picked:
        chosen = sorted(set(chosen) | {i for i, p in enumerate(ordered) if not mp_is_bad(p)})
    if not chosen:
        conn.close()
        return

    added, skipped = 0, 0
    now = int(time.time())
    for i in chosen:
        p = ordered[i]
        kind = p.get('type', 'mac')
        url = p.get('url', '')
        name = _strip_colors(p.get('name') or urllib.parse.urlparse(url).netloc or url)

        if kind == 'mac':
            server = _ms_normalise_url(url) + '/c/'
            mac = (p.get('mac') or '').strip().upper()
            if _dup_stalker(server, mac):
                skipped += 1
                continue
            conn.execute(
                'INSERT INTO providers (name, type, serverUrl, stalkerMacAddress, isEnabled, createdAt) VALUES (?,?,?,?,1,?)',
                (name, 'stalker', server, mac, now)
            )

        elif kind == 'xt':
            creds = xtream_from_url(url)
            if not creds:
                skipped += 1
                continue
            host, user, pwd = creds
            if _dup_xtream(host, user):
                skipped += 1
                continue
            conn.execute(
                'INSERT INTO providers (name, type, serverUrl, username, password, isEnabled, createdAt) VALUES (?,?,?,?,?,1,?)',
                (name, 'xtream', host, user, pwd, now)
            )

        else:
            if _dup_m3u(url):
                skipped += 1
                continue
            conn.execute(
                'INSERT INTO providers (name, type, m3uUrl, isEnabled, createdAt) VALUES (?,?,?,1,?)',
                (name, 'm3u', url, now)
            )

        added += 1

    conn.commit()
    conn.close()

    if not added:
        xbmcgui.Dialog().ok('Multistream', f'Nichts kopiert: {skipped} Eintrag/Einträge bereits vorhanden.')
        return

    msg = f'{added} Eintrag/Einträge nach Multistream kopiert'
    if skipped:
        msg += f', {skipped} übersprungen'
    xbmcgui.Dialog().ok('Multistream', msg + '.')
    _open_multistream()


def mp_add_manual():
    url = xbmcgui.Dialog().input("Portal-URL (z.B. http://host:8080/c/)")
    if not url:
        return
    mac = xbmcgui.Dialog().input("MAC-Adresse (z.B. 00:1A:79:12:34:56)")
    mac = (mac or '').strip().upper().replace('-', ':')
    if not mac_portal.MAC_RE.fullmatch(mac):
        xbmcgui.Dialog().ok("MAC-Portal", "Ungültige MAC-Adresse. Format: 00:1A:79:12:34:56")
        return
    mp_remember(url, mac, ok=None)
    xbmc.executebuiltin(f"Container.Update({mp_url(action='mp_menu', portal=url, mac=mac)})")

def mp_status_for(portal, mac):
    base = mac_portal.normalise_base(portal)
    p = next((x for x in mp_load_portals() if _mp_key(x) == ('mac', base, mac)), None)
    return mp_status_text(p) if p else "[COLOR gray]ungeprüft[/COLOR]"

def show_mp_macs(portal, macs):
    """Mehrere MACs aus einem Beitrag: alle merken und zur Auswahl anzeigen."""
    base = mac_portal.normalise_base(portal)
    for m in macs:
        mp_add_if_missing(base, m)
    entries = {m: next((x for x in mp_load_portals() if _mp_key(x) == ('mac', base, m)), {}) for m in macs}
    ordered = sorted(macs, key=lambda m: 1 if mp_is_bad(entries[m]) else 0)       # funktionierende zuerst
    xbmcplugin.setContent(addon_handle, 'videos')
    for m in ordered:
        mp_item(f"{m}  {mp_status_for(base, m)}", mp_url(action='mp_menu', portal=base, mac=m),
                plot=f"Portal: {urllib.parse.urlparse(base).netloc}\nMAC: {m}")
    mp_item(f"[COLOR gray][ Alle {len(macs)} MACs prüfen (Handshake + Bild) ][/COLOR]",
            mp_url(action='mp_check_macs', portal=base, macs=','.join(macs)), folder=False,
            plot="Testet jede MAC wirklich: Zugang und ob ein Stream Daten liefert.")
    mp_finish()

def mp_check_macs():
    macs = [m for m in (params.get('macs') or '').split(',') if m]
    base = mac_portal.normalise_base(params.get('portal'))
    dlg = xbmcgui.DialogProgress()
    dlg.create("MACs prüfen", "Starte ...")
    good = 0
    try:
        for i, m in enumerate(macs):
            if dlg.iscanceled():
                break
            dlg.update(int(i * 100 / max(1, len(macs))), f"{i + 1}/{len(macs)}: {m}\nPrüfe Zugang und Bild ...")
            ok, exp, why, _msg = mp_check_one(base, m)
            mp_remember(base, m, exp=exp, ok=ok, why=why, unclear=str(_msg).startswith('unclear:'))
            good += 1 if ok else 0
    finally:
        try: dlg.close()
        except Exception: pass
    xbmcgui.Dialog().notification("MACs prüfen", f"{good} von {len(macs)} liefern ein Bild", xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.executebuiltin('Container.Refresh')

def show_mp_menu():
    macs_in = [m.strip().upper() for m in (params.get('mac') or params.get('macs') or '').split(',') if m.strip()]
    if len(macs_in) > 1:
        return show_mp_macs(params.get('portal'), macs_in)
    cl = mp_client_from_params()
    if not cl:
        return mp_finish(False)
    mp_finish(False)
    _open_multistream()

def show_mp_diag():
    cl = mp_client_from_params()
    if not cl:
        return
    lines = [f"Portal: {cl.host}", f"MAC: {cl.mac}",
             f"Verbindung: {'Compat-Modus (ohne Handshake)' if cl.compat else 'Handshake'}, Pfad {cl.endpoint}", ""]
    genres, chans = [], []
    try:
        genres = cl.genres()
        lines.append(f"get_genres: {len(genres)} Einträge" + (": " + ", ".join(str(g.get('title') or g.get('name')) for g in genres[:6]) if genres else " (leer!)"))
    except Exception as e:
        lines.append(f"get_genres: FEHLER {type(e).__name__}: {e}")
    try:
        chans = cl.channels()
        lines.append(f"get_all_channels: {len(chans)} Kanäle")
    except Exception as e:
        lines.append(f"get_all_channels: FEHLER {type(e).__name__}: {e}")
    if chans:
        cg = {}
        for ch in chans:
            cg[str(ch.get('tv_genre_id'))] = cg.get(str(ch.get('tv_genre_id')), 0) + 1
        gids = {str(g.get('id')) for g in genres}
        matched = sum(n for k, n in cg.items() if k in gids)
        lines += [f"Kanäle mit tv_genre_id: {len(chans) - cg.get('None', 0)} von {len(chans)}",
                  f"Verschiedene Genre-IDs in den Kanälen: {len([k for k in cg if k != 'None'])}",
                  f"Kanäle, deren Genre-ID in get_genres vorkommt: {matched} von {len(chans)}",
                  f"Beispiel-Felder eines Kanals: {', '.join(sorted(chans[0].keys())[:14])}"]
        if genres and matched == 0:
            lines.append("-> Genre-IDs passen nicht zusammen (Portal-Eigenheit)")
        elif not genres:
            lines.append("-> Das Portal liefert keine Genre-Liste; Genres werden aus den Kanaldaten abgeleitet")
    xbmcgui.Dialog().textviewer("MAC-Portal Diagnose", "\n".join(lines))

def show_mp_info():
    cl = mp_client_from_params()
    if not cl:
        return
    info = cl.account_info()
    lines = [f"Portal: {cl.host}", f"MAC: {cl.mac}"]
    for key, label in (('phone', 'Gültig bis'), ('end_date', 'Gültig bis'), ('tariff_plan', 'Tarif'), ('status', 'Status')):
        if info.get(key):
            lines.append(f"{label}: {info.get(key)}")
    xbmcgui.Dialog().ok("MAC-Portal Info", "\n".join(lines))

def show_mp_live():
    mp_finish(False)

def show_mp_vod():
    mp_finish(False)

def show_mp_seasons():
    mp_finish(False)

def show_mp_episodes():
    mp_finish(False)

def play_mp():
    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

async def add_telethon_message_item(message, clean_chat, client, only_videos=False):
    text = remove_emojis(message.text or "").strip()
    has_video = bool(message.video or (message.document and 'video' in getattr(message.document, 'mime_type', '').lower()))
    has_photo = bool(message.photo)
    archive, file_name = is_archive_message(message)

    is_m3u, m3u_name = is_m3u_message(message)
    if is_m3u:
        d_txt = message.date.strftime('%d.%m.%Y %H:%M') if message.date else ""
        m_title = f"{'[' + d_txt + '] ' if d_txt else ''}[COLOR lime][Playlist][/COLOR] {m3u_name}"
        m_item = xbmcgui.ListItem(label=m_title)
        set_action_info(m_item, plot=text or None)
        m_item.setArt({'icon': icon_path, 'thumb': icon_path})
        m_url = f"{addon_url}?action=show_m3u&chat={urllib.parse.quote(str(clean_chat))}&msg_id={message.id}"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=m_url, listitem=m_item, isFolder=False)
        return True

    if not has_video:
        try: ent_urls = [getattr(e, 'url', None) for e in (message.entities or [])]
        except Exception: ent_urls = []
        link = find_m3u_url(text, ent_urls)
        if link:
            d_txt = message.date.strftime('%d.%m.%Y %H:%M') if message.date else ""
            host = urllib.parse.urlparse(link).netloc
            l_title = f"{'[' + d_txt + '] ' if d_txt else ''}[COLOR lime][Playlist-Link][/COLOR] {host}"
            l_item = xbmcgui.ListItem(label=l_title)
            set_action_info(l_item, plot=f"M3U-Playlist von {host}")
            l_item.setArt({'icon': icon_path, 'thumb': icon_path})
            l_url = f"{addon_url}?action={'xt_menu' if xtream_from_url(link) else 'show_m3u'}&src={urllib.parse.quote(link, safe='')}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=l_url, listitem=l_item, isFolder=False)
            return True
        portal = mac_portal.find_portal(text, ent_urls)
        if portal:
            p_url, p_macs = portal
            d_txt = message.date.strftime('%d.%m.%Y %H:%M') if message.date else ""
            host = urllib.parse.urlparse(p_url if '://' in p_url else 'http://' + p_url).netloc
            more = f" (+{len(p_macs) - 1} MAC)" if len(p_macs) > 1 else ""
            p_title = f"{'[' + d_txt + '] ' if d_txt else ''}[COLOR orange][MAC-Portal][/COLOR] {host}{more}"
            p_item = xbmcgui.ListItem(label=p_title)
            set_kodi_info(p_item, title=p_title, plot=f"Portal {host}\nMAC: {', '.join(p_macs[:5])}")
            p_item.setArt({'icon': icon_path, 'thumb': icon_path})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=mp_url(action='mp_menu', portal=p_url, macs=','.join(p_macs)),
                                        listitem=p_item, isFolder=True)
            return True

    if only_videos and not has_video:
        return False

    if not text and not has_video and not has_photo and not archive and not message.document:
        return False

    sender_name = ""
    try:
        sender = await message.get_sender()
        if sender:
            if hasattr(sender, 'title') and sender.title:
                sender_name = sender.title
            elif hasattr(sender, 'first_name') and sender.first_name:
                sender_name = sender.first_name
                if getattr(sender, 'last_name', None):
                    sender_name += f" {sender.last_name}"
            elif hasattr(sender, 'username') and sender.username:
                sender_name = f"@{sender.username}"
    except Exception:
        pass

    if getattr(message, 'post_author', None):
        sender_name = message.post_author

    sender_name = remove_emojis(sender_name).strip()

    date_text = message.date.strftime('%d.%m.%Y %H:%M') if message.date else ""
    preview = text[:90] if text else (file_name if archive else "Beitrag")

    if archive: prefix = "[COLOR cyan][Archiv][/COLOR] "
    elif has_video: prefix = "[COLOR yellow][Video][/COLOR] "
    elif has_photo: prefix = "[COLOR orange][Bild][/COLOR] "
    else: prefix = "[COLOR green][Text][/COLOR] "

    sender_str = f"[COLOR magenta]{sender_name}[/COLOR]: " if sender_name else ""
    
    if date_text:
        title = f"[{date_text}] {sender_str}{prefix}{preview}"
    else:
        title = f"{sender_str}{prefix}{preview}"

    media_list, thumbnail, tmdb_poster = [], "", ""
    if has_video or has_photo or message.document:
        if has_video:
            # 1) TMDB-Poster (Dateiname + Beitragstext), 2) optional Foto-Zuordnung
            if tmdb_enabled():
                vname = ""
                try: vname = (message.file.name or "") if message.file else ""
                except Exception: pass
                tmdb_poster = await asyncio.get_event_loop().run_in_executor(
                    None, tmdb_find_poster, [vname, text])
                thumbnail = tmdb_poster
            if not thumbnail and photo_match_enabled():
                thumbnail = await find_nearby_photo_thumb(message, client)
        if not thumbnail:
            thumb_file = os.path.join(thumbs_dir, f"thumb_{message.id}.jpg")
            if not os.path.exists(thumb_file):
                try: await client.download_media(message, file=thumb_file, thumb=True)
                except Exception: pass
            if os.path.exists(thumb_file) and os.path.getsize(thumb_file) > 0:
                thumbnail = thumb_file

        media_type = 'archive' if archive else 'video' if has_video else 'photo' if has_photo else 'archive'
        media_list.append({'type': media_type, 'msg_id': message.id, 'chat': clean_chat, 'url': '', 'file_name': file_name, 'title': title})

    item = xbmcgui.ListItem(label=title)
    set_kodi_info(item, title=title, plot=text)
    if has_video and tmdb_poster:
        item.setArt({'poster': tmdb_poster, 'thumb': tmdb_poster, 'icon': tmdb_poster})
    elif has_video:
        # Video: echtes Telegram-Vorschaubild, sonst Video-Icon als Ersatz
        item.setArt({'icon': video_icon_path, 'thumb': thumbnail or video_icon_path})
    elif thumbnail:
        item.setArt({'icon': thumbnail, 'thumb': thumbnail})

    item_url = f"{addon_url}?action=multi_media&media={urllib.parse.quote(json.dumps(media_list, ensure_ascii=False))}&text={urllib.parse.quote(text)}&chat={urllib.parse.quote(str(clean_chat))}&msg_id={message.id}"
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=item_url, listitem=item, isFolder=False)
    return True

async def fetch_and_populate_telethon(chat_identifier, offset_id=0, filter_mode=None, topic_id=None, access_hash=None):
    api_id, api_hash = get_credentials()
    if not api_id or not api_hash:
        show_api_help_dialog()
        addon.openSettings()
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        return

    PAGE_SIZE = get_setting_int('page_size', 25)
    MAX_SCAN = get_setting_int('max_scan', 500)

    clean_chat = normalize_chat_name(chat_identifier)
    client = get_telethon_client(api_id, api_hash)
    _eof_sent = [False]

    def safe_eof():
        if not _eof_sent[0]:
            _eof_sent[0] = True
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)

    try:
        await asyncio.wait_for(client.connect(), timeout=8.0)

        if not await asyncio.wait_for(client.is_user_authorized(), timeout=5.0):
            xbmcgui.Dialog().ok("Telegram", "Bitte zuerst einloggen.")
            await client.disconnect()
            safe_eof()
            return

    except (asyncio.TimeoutError, asyncio.CancelledError, Exception) as e:
        xbmc.log(f"Telethon connect/auth Fehler: {type(e).__name__}: {e}", xbmc.LOGERROR)
        try:
            await client.disconnect()
        except BaseException:
            pass
        safe_eof()
        return

    try:
        entity = await get_entity_safe(client, clean_chat, access_hash=access_hash)
        if not entity:
            xbmcgui.Dialog().ok("Fehler", "Kanal/Chat konnte nicht gefunden werden.")
            try:
                await client.disconnect()
            except BaseException:
                pass
            safe_eof()
            return

        if topic_id is None and not offset_id and not filter_mode:
            topics = []
            if GetForumTopicsRequest:
                try:
                    res = await client(GetForumTopicsRequest(
                        channel=entity,
                        offset_date=0,
                        offset_id=0,
                        offset_topic=0,
                        limit=100
                    ))
                    if hasattr(res, 'topics') and res.topics:
                        topics = res.topics
                except Exception:
                    try:
                        res = await client(GetForumTopicsRequest(
                            peer=entity,
                            offset_date=0,
                            offset_id=0,
                            offset_topic=0,
                            limit=100
                        ))
                        if hasattr(res, 'topics') and res.topics:
                            topics = res.topics
                    except Exception:
                        pass

            if topics:
                entity_id_str = str(tl_utils.get_peer_id(entity))
                entity_access_hash = str(getattr(entity, 'access_hash', '') or '')
                entity_display_name = getattr(entity, 'title', None) or getattr(entity, 'first_name', None) or clean_chat
                
                groups_item = xbmcgui.ListItem(label="[COLOR yellow] Zurück zu den Gruppen (Favoriten)[/COLOR]")
                groups_item.setArt({'icon': icon_path, 'thumb': icon_path})
                set_kodi_info(groups_item, plot="Zurück zur Gruppenübersicht.")
                groups_url = f"{addon_url}?action=show_category&cat={urllib.parse.quote('Eigene Favoriten')}"
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=groups_url, listitem=groups_item, isFolder=True)

                for t in topics:
                    t_title = remove_emojis(getattr(t, 'title', 'General')).strip()
                    if not t_title:
                        t_title = "General"
                    t_id = getattr(t, 'id', 1)

                    item = xbmcgui.ListItem(label=f" [COLOR grey][Thema][/COLOR] [B]{t_title}[/B]")
                    item.setArt({'icon': icon_path, 'thumb': icon_path})

                    send_topic_url = f"RunPlugin({addon_url}?action=send_message&url={urllib.parse.quote(entity_id_str)}&topic_id={t_id})"
                    if entity_access_hash:
                        send_topic_url = f"RunPlugin({addon_url}?action=send_message&url={urllib.parse.quote(entity_id_str)}&topic_id={t_id}&access_hash={entity_access_hash})"
                    _fav_name = f"{entity_display_name} / {t_title}"
                    fav_url = f"RunPlugin({addon_url}?action=move_to_fav&url={urllib.parse.quote(entity_id_str)}&name={urllib.parse.quote(_fav_name)}&topic_id={t_id})"
                    item.addContextMenuItems([("Nachricht in dieses Thema senden", send_topic_url), ("Zu Eigene Favoriten", fav_url)])

                    topic_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(entity_id_str)}&topic_id={t_id}"
                    if entity_access_hash:
                        topic_url += f"&access_hash={entity_access_hash}"
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=topic_url, listitem=item, isFolder=True)

                xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
                await client.disconnect()
                return

        refresh_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(chat_identifier))}&offset_id=0"
        if topic_id is not None: refresh_url += f"&topic_id={topic_id}"
        if access_hash is not None: refresh_url += f"&access_hash={access_hash}"
        refresh_item = xbmcgui.ListItem(label="[COLOR yellow]Aktualisieren[/COLOR]")
        refresh_item.setArt({'icon': icon_path, 'thumb': icon_path})
        set_kodi_info(refresh_item, plot="Aktualisieren Sie die Ansicht.")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=refresh_url, listitem=refresh_item, isFolder=True)

        if topic_id is not None:
            back_item = xbmcgui.ListItem(label="[COLOR cyan] Zurück zu den Themen[/COLOR]")
            back_item.setArt({'icon': icon_path, 'thumb': icon_path})
            set_kodi_info(back_item, plot="Zurück zur Themenübersicht.")
            back_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(chat_identifier))}"
            if access_hash is not None: back_url += f"&access_hash={access_hash}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=back_item, isFolder=True)
        else:
            back_item = xbmcgui.ListItem(label="[COLOR cyan] Zurück zu den Favoriten[/COLOR]")
            back_item.setArt({'icon': icon_path, 'thumb': icon_path})
            set_kodi_info(back_item, plot="Zurück zur Favoritenübersicht.")
            back_url = f"{addon_url}?action=show_category&cat={urllib.parse.quote('Eigene Favoriten')}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=back_item, isFolder=True)

        if not offset_id:
            msg_label = " Nachricht in dieses Thema senden" if topic_id else " Nachricht in diesen Chat senden"
            send_item = xbmcgui.ListItem(label=f"[COLOR lightgreen]{msg_label}[/COLOR]")
            send_item.setArt({'icon': icon_path, 'thumb': icon_path})
            set_kodi_info(send_item, plot="Schreiben und senden Sie eine Textnachricht.")
            send_url = f"{addon_url}?action=send_message&url={urllib.parse.quote(str(chat_identifier))}"
            if topic_id: send_url += f"&topic_id={topic_id}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=send_url, listitem=send_item, isFolder=False)

        if offset_id > 0:
            first_page_item = xbmcgui.ListItem(label="[COLOR orange] Zurück zur 1. Seite (Neueste Beiträge)[/COLOR]")
            first_page_item.setArt({'icon': icon_path, 'thumb': icon_path})
            set_kodi_info(first_page_item, plot="Springen Sie zurück zur ersten Seite mit den neuesten Beiträgen.")
            first_page_url = f"{addon_url}?action=paginate&url={urllib.parse.quote(str(chat_identifier))}&offset_id=0"
            if filter_mode: first_page_url += f"&filter={urllib.parse.quote(filter_mode)}"
            if topic_id: first_page_url += f"&topic_id={topic_id}"
            if access_hash is not None: first_page_url += f"&access_hash={access_hash}"
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=first_page_url, listitem=first_page_item, isFolder=False)

        if not offset_id:
            if filter_mode == 'archives':
                toggle_item = xbmcgui.ListItem(label="[COLOR yellow] Alle Beiträge anzeigen[/COLOR]")
                toggle_item.setArt({'icon': icon_path, 'thumb': icon_path})
                set_kodi_info(toggle_item, plot="Heben Sie den Archiv-Filter auf, um wieder alle Beiträge anzuzeigen.")
                toggle_url = f"{addon_url}?action=toggle_filter&url={urllib.parse.quote(str(chat_identifier))}"
                if topic_id: toggle_url += f"&topic_id={topic_id}"
                if access_hash is not None: toggle_url += f"&access_hash={access_hash}"
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=toggle_url, listitem=toggle_item, isFolder=False)
            else:
                toggle_item = xbmcgui.ListItem(label="[COLOR cyan] Nur Archive anzeigen (.zip, .rar, .7z)[/COLOR]")
                toggle_item.setArt({'icon': icon_path, 'thumb': icon_path})
                set_kodi_info(toggle_item, plot="Filtern Sie die Ansicht ausschließlich nach Archiven.")
                toggle_url = f"{addon_url}?action=toggle_filter&url={urllib.parse.quote(str(chat_identifier))}&filter=archives"
                if topic_id: toggle_url += f"&topic_id={topic_id}"
                if access_hash is not None: toggle_url += f"&access_hash={access_hash}"
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=toggle_url, listitem=toggle_item, isFolder=False)
        kwargs = {}
        if offset_id: kwargs['offset_id'] = int(offset_id)
        if topic_id: kwargs['reply_to'] = int(topic_id)

        if filter_mode == 'archives' and InputMessagesFilterDocument:
            kwargs['filter'] = InputMessagesFilterDocument

        # Nur Videos anzeigen (der Archiv-Filter bleibt davon unberührt)
        videos_only = only_videos_enabled() and filter_mode != 'archives'
        scanned_count = 0
        found_count = 0
        last_message_id = 0
        has_more = False

        max_scan_limit = max(MAX_SCAN, 2500) if filter_mode == 'archives' else MAX_SCAN

        kwargs.setdefault('min_id', 0)
        kwargs.setdefault('wait_time', 0)
        kwargs.setdefault('limit', max_scan_limit)
        async for message in client.iter_messages(entity, **kwargs):
            scanned_count += 1
            last_message_id = message.id
            text = remove_emojis(message.text or "").strip()

            archive, _ = is_archive_message(message)

            if filter_mode == 'archives' and not archive:
                if scanned_count >= max_scan_limit and found_count > 0:
                    has_more = True
                    break
                if scanned_count >= max_scan_limit * 2:
                    has_more = False
                    break
                continue

            if not text and not message.video and not message.photo and not message.document:
                if scanned_count >= max_scan_limit and found_count > 0:
                    has_more = True
                    break
                continue

            added = await add_telethon_message_item(message, clean_chat, client, only_videos=videos_only)
            if added:
                found_count += 1

            if found_count >= PAGE_SIZE:
                has_more = True
                break

            if scanned_count >= max_scan_limit:
                has_more = True
                break

        if found_count >= PAGE_SIZE and last_message_id:
            has_more = True

        if has_more and last_message_id:
            next_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(chat_identifier))}&offset_id={last_message_id}"
            if filter_mode: next_url += f"&filter={urllib.parse.quote(filter_mode)}"
            if topic_id: next_url += f"&topic_id={topic_id}"
            if access_hash is not None: next_url += f"&access_hash={access_hash}"
            next_item = xbmcgui.ListItem(label="[COLOR yellow] Nächste Seite ->[/COLOR]")
            next_item.setArt({'icon': icon_path, 'thumb': icon_path})
            set_kodi_info(next_item, plot="Mehr Beiträge laden.")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=next_url, listitem=next_item, isFolder=True)

    except BaseException as e:
        xbmc.log(f"fetch_and_populate_telethon: {type(e).__name__}: {e}", xbmc.LOGWARNING)
        if not isinstance(e, (asyncio.CancelledError, asyncio.TimeoutError)) and found_count == 0:
            xbmcgui.Dialog().ok("Fehler", f"Kanal/Chat konnte nicht geladen werden:\n{e}")
    finally:
        try:
            await client.disconnect()
        except BaseException:
            pass
        safe_eof()

def web_extract_media(msg):
    """Liest Video-URL und Bild-URL aus einem Web-Beitrag (t.me/s/...)."""
    video_url = None
    v_match = re.search(r'<video[^>]+src=[\'"]([^\'"]+)[\'"]', msg, re.IGNORECASE)
    if v_match: video_url = clean_url(v_match.group(1))
    if not video_url:
        s_match = re.search(r'<source[^>]+src=[\'"]([^\'"]+)[\'"]', msg, re.IGNORECASE)
        if s_match: video_url = clean_url(s_match.group(1))
    if not video_url:
        cdn_urls = re.findall(r'https://cdn\d*\.telesco\.pe/file/[^"\'\s>]+', msg)
        for u in cdn_urls:
            if 't8HUD5p6GsmnfM' not in u and ('.mp4' in u or '.mov' in u):
                video_url = clean_url(u)
                break
    img_url = None
    bg_match = re.search(r'background-image:\s*url\([\'"]?([^\'")\s]+)[\'"]?\)', msg)
    if bg_match:
        bg_url = clean_url(bg_match.group(1))
        if 't8HUD5p6GsmnfM' not in bg_url: img_url = bg_url
    if not img_url:
        img_match = re.search(r'<img[^>]+src=[\'"]([^\'"]+)[\'"]', msg, re.IGNORECASE)
        if img_match:
            i_url = clean_url(img_match.group(1))
            if 't8HUD5p6GsmnfM' not in i_url: img_url = i_url
    return video_url, img_url

def web_message_date(msg):
    m = re.search(r'<time[^>]*datetime="([^"]+)"', msg)
    if not m:
        return None
    try:
        return datetime.fromisoformat(m.group(1).replace('Z', '+00:00'))
    except Exception:
        return None

def web_find_nearby_photo(video_date, photos, seconds=300):
    """Nächstes Foto (img_url) innerhalb von 'seconds' Sekunden zum Video."""
    if not video_date:
        return None
    best, best_diff = None, None
    for d, url in photos:
        try:
            diff = abs((d - video_date).total_seconds())
        except Exception:
            continue
        if diff <= seconds and (best is None or diff < best_diff):
            best, best_diff = url, diff
    return best

def fetch_and_populate_web(chat_identifier):
    clean_chat = str(normalize_chat_name(chat_identifier)).lstrip('@')
    encoded_chat = urllib.parse.quote(clean_chat)
    url = params.get('url') if params.get('action') == 'page' and params.get('url') else f"https://t.me/s/{encoded_chat}"
    req = urllib.request.Request(
        url,
        headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            html_content = response.read().decode('utf-8')
    except Exception as e:
        xbmc.log(f"Telegram Scraper Error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Fehler", f"Konnte Telegram-Kanal nicht laden:\n{e}")
        return xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
    if not html_content:
        xbmcgui.Dialog().ok("Fehler", "Konnte Telegram-Kanal nicht laden.")
        return xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
    messages = html_content.split('class="tgme_widget_message ')
    if len(messages) > 1:
        messages = messages[1:]
        messages.reverse()
    before_match = re.search(r'href="([^"]*\?before=\d+)"', html_content)
    refresh_item = xbmcgui.ListItem(label="[COLOR yellow]Aktualisieren (Web-Modus)[/COLOR]")
    refresh_item.setArt({'icon': icon_path, 'thumb': icon_path})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(chat_identifier))}&offset_id=0", listitem=refresh_item, isFolder=True)
    user_agent = urllib.parse.quote('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
    referer = urllib.parse.quote('https://t.me/')
    page_photos = []
    for _m in messages:
        _v, _i = web_extract_media(_m)
        _d = web_message_date(_m)
        if _i and not _v and _d:
            page_photos.append((_d, _i))
    for msg in messages:
        text_match = re.search(r'<div class="tgme_widget_message_text[^"]*"(?:[^>]*>)(.*?)</div>', msg, re.DOTALL)
        if not text_match:
            text_match = re.search(r'<div dir="auto"[^>]*>(.*?)</div>', msg, re.DOTALL)
        raw_text = text_match.group(1) if text_match else ""
        clean_text = re.sub(r'<[^>]+>', '', raw_text)
        clean_text = html.unescape(clean_text).strip()
        clean_text = re.sub(r'\s+', ' ', clean_text).strip()
        post_match = re.search(r'data-post="([^"]+)"', msg)
        msg_id = post_match.group(1).split('/')[-1] if post_match else "0"
        video_url, img_url = web_extract_media(msg)
        has_video = video_url is not None
        if not has_video:
            _hrefs = re.findall(r'href="([^"]+)"', raw_text)
            link = find_m3u_url(clean_text, _hrefs)
            if link:
                host = urllib.parse.urlparse(link).netloc
                l_item = xbmcgui.ListItem(label=f"[COLOR lime][Playlist-Link][/COLOR] {host}")
                set_action_info(l_item, plot=f"M3U-Playlist von {host}")
                l_item.setArt({'icon': icon_path, 'thumb': icon_path})
                xbmcplugin.addDirectoryItem(addon_handle, f"{addon_url}?action={'xt_menu' if xtream_from_url(link) else 'show_m3u'}&src={urllib.parse.quote(link, safe='')}", l_item, isFolder=False)
                continue
            portal = mac_portal.find_portal(clean_text, [html.unescape(h) for h in _hrefs])
            if portal:
                p_url, p_macs = portal
                host = urllib.parse.urlparse(p_url if '://' in p_url else 'http://' + p_url).netloc
                more = f" (+{len(p_macs) - 1} MAC)" if len(p_macs) > 1 else ""
                p_item = xbmcgui.ListItem(label=f"[COLOR orange][MAC-Portal][/COLOR] {host}{more}")
                set_kodi_info(p_item, title=f"[MAC-Portal] {host}", plot=f"Portal {host}\nMAC: {', '.join(p_macs[:5])}")
                p_item.setArt({'icon': icon_path, 'thumb': icon_path})
                xbmcplugin.addDirectoryItem(addon_handle, mp_url(action='mp_menu', portal=p_url, macs=','.join(p_macs)), p_item, isFolder=True)
                continue
        tmdb_poster = tmdb_find_poster([clean_text]) if (has_video and tmdb_enabled()) else ""
        if has_video and not tmdb_poster and photo_match_enabled():
            photo_for_video = web_find_nearby_photo(web_message_date(msg), page_photos)
            if photo_for_video:
                img_url = photo_for_video
        if only_videos_enabled() and not has_video:
            continue
        has_photo = img_url is not None and not has_video
        if has_video: prefix = "[COLOR yellow][Video][/COLOR] "
        elif has_photo: prefix = "[COLOR orange][Bild][/COLOR] "
        else: prefix = "[COLOR green][Text][/COLOR] "
        title = f"{prefix}{clean_text[:50]}..." if clean_text else f"{prefix}Beitrag ohne Text"
        media_list = []
        if has_video:
            media_list.append({'type': 'video', 'msg_id': msg_id, 'chat': clean_chat, 'url': video_url, 'file_name': f"video_{msg_id}.mp4", 'title': title})
        elif has_photo:
            media_list.append({'type': 'photo', 'msg_id': msg_id, 'chat': clean_chat, 'url': img_url, 'file_name': f"photo_{msg_id}.jpg", 'title': title})
        list_item = xbmcgui.ListItem(label=title)
        set_kodi_info(list_item, title=title, plot=clean_text if clean_text else "Kein Text vorhanden.")
        if img_url:
            kodi_img_url = f"{img_url}|User-Agent={user_agent}&Referer={referer}"
            if has_video:
                list_item.setArt({'thumb': kodi_img_url, 'icon': video_icon_path})
            else:
                list_item.setArt({'thumb': kodi_img_url, 'icon': kodi_img_url})
        elif has_video:
            list_item.setArt({'icon': video_icon_path, 'thumb': video_icon_path})
        else:
            list_item.setArt({'icon': icon_path, 'thumb': icon_path})
        if tmdb_poster:
            list_item.setArt({'poster': tmdb_poster, 'thumb': tmdb_poster, 'icon': tmdb_poster})
        item_url = f"{addon_url}?action=multi_media&media={urllib.parse.quote(json.dumps(media_list, ensure_ascii=False))}&text={urllib.parse.quote(clean_text)}&chat={urllib.parse.quote(clean_chat)}&msg_id={msg_id}"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=item_url, listitem=list_item, isFolder=False)
    if before_match:
        matched_url = before_match.group(1)
        next_url = matched_url if matched_url.startswith('http') else f"https://t.me{matched_url}"
        next_item = xbmcgui.ListItem(label="[COLOR cyan][ Ältere Beiträge laden... ][/COLOR]")
        next_item.setArt({'icon': icon_path, 'thumb': icon_path})
        item_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(next_url)}"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=item_url, listitem=next_item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)

if __name__ == '__main__':
    action = params.get('action')
    cleanup_m3u_cache()    # Playlists älter als 7 Tage automatisch löschen

    if not action:
        if not is_logged_in():
            result = load_credentials_from_txt()
            if result:
                phone, api_id, api_hash = result
                run_async(run_telethon_phone_login(direct_api_id=api_id, direct_api_hash=api_hash, direct_phone=phone))
        show_root_menu()
    elif action == 'show_category':
        show_root_menu(selected_category=params.get('cat', 'Eigene Favoriten'))
    elif action == 'show_channel':
        url = params.get('url')
        offset = int(params.get('offset_id', 0)) if params.get('offset_id', '0').isdigit() else 0
        filter_mode = params.get('filter')
        topic_id = int(params.get('topic_id')) if params.get('topic_id', '').isdigit() else None
        ch_access_hash = None
        if params.get('access_hash', '').lstrip('-').isdigit():
            ch_access_hash = int(params['access_hash'])
        if ch_access_hash is None and url:
            for ch in load_channels():
                if ch.get('url') == url and ch.get('access_hash') is not None:
                    ch_access_hash = ch['access_hash']
                    break
        if is_logged_in():
            run_async(fetch_and_populate_telethon(url, offset_id=offset, filter_mode=filter_mode, topic_id=topic_id, access_hash=ch_access_hash))
        else:
            fetch_and_populate_web(url)
    elif action == 'refresh':
        xbmc.executebuiltin("Container.Refresh")
    elif action == 'paginate':
        url = params.get('url')
        offset = params.get('offset_id', '0')
        filter_mode = params.get('filter')
        topic_id = params.get('topic_id')
        access_hash_p = params.get('access_hash')
        query = f"?action=show_channel&url={urllib.parse.quote(str(url))}&offset_id={offset}"
        if filter_mode: query += f"&filter={urllib.parse.quote(filter_mode)}"
        if topic_id: query += f"&topic_id={topic_id}"
        if access_hash_p: query += f"&access_hash={access_hash_p}"
        xbmc.executebuiltin(f"Container.Update({addon_url}{query})")
    elif action == 'toggle_filter':
        url = params.get('url')
        filter_mode = params.get('filter')
        topic_id = params.get('topic_id')
        access_hash_p = params.get('access_hash')
        query = f"?action=show_channel&url={urllib.parse.quote(str(url))}&offset_id=0"
        if filter_mode: query += f"&filter={urllib.parse.quote(filter_mode)}"
        if topic_id: query += f"&topic_id={topic_id}"
        if access_hash_p: query += f"&access_hash={access_hash_p}"
        xbmc.executebuiltin(f"Container.Update({addon_url}{query})")
    elif action == 'send_message':
        chat_url = params.get('url')
        topic_id = int(params.get('topic_id')) if params.get('topic_id', '').isdigit() else None
        handle_send_message(chat_url, topic_id=topic_id)
    elif action == 'send_file_action':
        file_path = params.get('path')
        handle_send_file_action(file_path)
    elif action == 'add_channel':
        add_new_channel()
    elif action == 'auto_import':
        auto_import_channels()
    elif action == 'move_to_fav':
        move_to_addon_favourites(params.get('url'), params.get('name', params.get('url', '')), topic_id=params.get('topic_id') or None)
    elif action == 'add_to_kodi_fav':
        fav_url = params.get('url')
        fav_name = params.get('name', fav_url)
        if fav_url:
            plugin_url = f"{addon_url}?action=show_channel&url={urllib.parse.quote(str(fav_url))}"
            add_to_kodi_favourites(fav_name, plugin_url)
    elif action == 'add_friend':
        add_friend_dialog()
    elif action == 'delete_channel':
        delete_channel(params.get('url'))
    elif action == 'remove_from_fav':
        _tid = params.get('topic_id')
        _tid_val = int(_tid) if _tid is not None else None
        remove_from_fav(params.get('url'), topic_id=_tid_val)
    elif action == 'show_downloads':
        show_downloads_folder()
    elif action == 'delete_download':
        delete_download_file(params.get('file'))
    elif action == 'multi_media':
        media_raw = params.get('media')
        text_raw = params.get('text', '')
        chat_raw = params.get('chat')
        msg_id_raw = params.get('msg_id')
        try:
            media_list = json.loads(media_raw) if media_raw else []
            handle_multi_media(media_list, text_raw, chat=chat_raw, msg_id=msg_id_raw)
        except Exception as e:
            xbmc.log(f"MultiMedia Handle Fehler: {e}", xbmc.LOGERROR)
    elif action == 'install_zip':
        show_local_zip_addons()
    elif action == 'login':
        handle_login_flow()
    elif action == 'logout':
        if xbmcgui.Dialog().yesno("Abmelden", "Wirklich abmelden?"):
            logout()
    elif action == 'settings':
        addon.openSettings()
    elif action == 'show_manual':
        show_manual(from_first_start=params.get('first_start') == '1')
    elif action == 'fav_reorder':
        fav_reorder(params.get('url'), params.get('topic_id'), params.get('direction', ''))
    elif action == 'fav_rename':
        fav_rename(params.get('url'), params.get('topic_id'))
    elif action == 'close_addon':
        exit_addon()
    elif action == 'show_local_image':
        img_path = params.get('path')
        if img_path and os.path.exists(img_path):
            xbmc.executebuiltin(f'ShowPicture({img_path})')
    elif action == 'show_m3u':
        show_m3u_playlist(params.get('chat'), params.get('msg_id'),
                          src=params.get('src'),
                          group=params.get('group'),
                          page=int(params.get('page', 0)) if params.get('page', '0').isdigit() else 0)
    elif action == 'xt_menu':
        show_xt_menu()
    elif action == 'xt_cats':
        show_xt_cats()
    elif action == 'xt_list':
        show_xt_list()
    elif action == 'xt_seasons':
        show_xt_seasons()
    elif action == 'xt_episodes':
        show_xt_episodes()
    elif action == 'xt_info':
        show_xt_info()
    elif action == 'check_credentials':
        check_credentials_dialog()
    elif action == 'mp_home':
        show_mp_home()
    elif action == 'mp_add':
        mp_add_manual()
    elif action == 'mp_export_multistream':
        mp_export_to_multistream()
    elif action == 'ms_launch':
        _open_multistream()
    elif action == 'mp_check_macs':
        mp_check_macs()
    elif action == 'mp_remove':
        mp_forget(params.get('portal'), params.get('mac'), params.get('kind', 'mac'))
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'mp_rename':
        mp_rename()
    elif action == 'mp_check_all':
        mp_check_all()
    elif action == 'mp_clean':
        mp_clean()
    elif action == 'mp_menu':
        show_mp_menu()
    elif action == 'mp_diag':
        show_mp_diag()
    elif action == 'mp_info':
        show_mp_info()
    elif action == 'mp_live':
        show_mp_live()
    elif action == 'mp_vod':
        show_mp_vod()
    elif action == 'mp_seasons':
        show_mp_seasons()
    elif action == 'mp_episodes':
        show_mp_episodes()
    elif action == 'mp_play':
        play_mp()
    elif action == 'clear_m3u_cache':
        freed = cleanup_m3u_cache(everything=True)
        _m3u_parsed['key'] = None
        _m3u_parsed['entries'] = None
        xbmcgui.Dialog().notification("Playlists", f"Cache geleert ({freed / 1048576:.1f} MB frei)",
                                      xbmcgui.NOTIFICATION_INFO, 3000)
    elif action == 'tmdb_test':
        tmdb_test_connection()
    elif action == 'tmdb_clear_cache':
        tmdb_clear_cache()
        xbmcgui.Dialog().notification("TMDB", "Poster-Cache geleert", xbmcgui.NOTIFICATION_INFO, 3000)
    elif action == 'show_local_txt':
        txt_path = params.get('path')
        if txt_path and os.path.exists(txt_path):
            try:
                with open(txt_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                xbmcgui.Dialog().textviewer(os.path.basename(txt_path), content)
            except Exception as e:
                xbmcgui.Dialog().ok("Fehler", f"Konnte Textdatei nicht lesen:\n{e}")
# RECHTLICHER HINWEIS:
# Jegliche Haftung und Garantie für Schäden jeglicher Art ist ausgeschlossen. 
# Dieser Code ist das geistige Eigentum der Autoren (zusatzmetall, stonetester, mr-evil1, kato14, eragon, kangool). 
# Das Modifizieren, Verändern, Umschreiben oder die unautorisierte 
# Weiterverbreitung des Codes ist strengstens untersagt.
