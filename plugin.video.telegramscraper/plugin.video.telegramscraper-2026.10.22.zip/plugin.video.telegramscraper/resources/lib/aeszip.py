import zipfile
import struct
import hmac as _hmac
import hashlib
import zlib
import os

try:
    from pyaes.aes import AES as _AES
    _HAS_PYAES = True
except ImportError:
    _HAS_PYAES = False

_SALT_LENGTHS = {1: 8, 2: 12, 3: 16}
_KEY_LENGTHS  = {1: 16, 2: 24, 3: 32}
_MAC_LENGTH   = 10


def _parse_aes_extra(zinfo):
    raw = zinfo.extra
    i = 0
    while i + 4 <= len(raw):
        tag, size = struct.unpack_from('<HH', raw, i)
        val = raw[i+4:i+4+size]
        if tag == 0x9901 and len(val) >= 7:
            strength        = val[4]
            actual_compress = struct.unpack_from('<H', val, 5)[0]
            return strength, actual_compress
        i += 4 + size
    return 3, 8


def _read_raw_entry(zip_path, zinfo):
    with open(zip_path, 'rb') as f:
        f.seek(zinfo.header_offset + 26)
        fn_len, ex_len = struct.unpack('<HH', f.read(4))
        f.seek(zinfo.header_offset + 30 + fn_len + ex_len)
        return f.read(zinfo.compress_size)


def _derive_keys(password, salt, key_len):
    if isinstance(password, str):
        password = password.encode('utf-8')
    dk = hashlib.pbkdf2_hmac('sha1', password, salt, 1000, dklen=2 * key_len + 2)
    return dk[:key_len], dk[key_len:2 * key_len], dk[2 * key_len:]


def _aes_ctr_decrypt_winzip(aes_key, ciphertext):
    aes_cipher = _AES(aes_key)
    out = bytearray()
    block_num = 1
    for i in range(0, len(ciphertext), 16):
        ctr_block = struct.pack('<I', block_num) + b'\x00' * 12
        keystream = aes_cipher.encrypt(ctr_block)
        chunk = ciphertext[i:i + 16]
        out += bytes(a ^ b for a, b in zip(keystream, chunk))
        block_num += 1
    return bytes(out)


def _is_aes_encrypted(zinfo):
    return bool(zinfo.flag_bits & 0x1) and zinfo.compress_type == 99


def _decrypt_entry(zip_path, zinfo, password):
    if isinstance(password, str):
        password = password.encode('utf-8')

    strength, actual_compress = _parse_aes_extra(zinfo)
    salt_len = _SALT_LENGTHS.get(strength, 16)
    key_len  = _KEY_LENGTHS.get(strength, 32)

    raw        = _read_raw_entry(zip_path, zinfo)
    salt       = raw[:salt_len]
    pwd_verify = raw[salt_len:salt_len + 2]
    ciphertext = raw[salt_len + 2:-_MAC_LENGTH]
    stored_mac = raw[-_MAC_LENGTH:]

    aes_key, hmac_key, derived_verify = _derive_keys(password, salt, key_len)

    if derived_verify != pwd_verify:
        raise RuntimeError('Wrong password')

    calc_mac = _hmac.new(hmac_key, ciphertext, hashlib.sha1).digest()[:_MAC_LENGTH]
    if calc_mac != stored_mac:
        raise RuntimeError('MAC mismatch — corrupt file or wrong password')

    plaintext = _aes_ctr_decrypt_winzip(aes_key, ciphertext)

    if actual_compress == 8:
        plaintext = zlib.decompress(plaintext, -15)
    elif actual_compress == 0:
        pass
    else:
        raise RuntimeError(f'Unsupported inner compression method: {actual_compress}')

    return plaintext


def extractall_aes(archive_path, dest_dir, password=None):
    if not _HAS_PYAES:
        raise ImportError('pyaes not available')

    with zipfile.ZipFile(archive_path, 'r') as zf:
        for zinfo in zf.infolist():
            out_path = os.path.join(dest_dir, zinfo.filename)
            if zinfo.is_dir():
                os.makedirs(out_path, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(out_path), exist_ok=True)

            if _is_aes_encrypted(zinfo):
                if password is None:
                    raise RuntimeError('Password required')
                data = _decrypt_entry(archive_path, zinfo, password)
                with open(out_path, 'wb') as f:
                    f.write(data)
            else:
                pwd_b = password.encode() if isinstance(password, str) else password
                data = zf.read(zinfo, pwd=pwd_b)
                with open(out_path, 'wb') as f:
                    f.write(data)
