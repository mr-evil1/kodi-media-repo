import os
import time

import xbmc
import xbmcaddon

ADDON_ID = "plugin.video.deezer"
GUARD_SECONDS = 1.5


class DeezerPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._last = 0.0

    def _is_deezer(self):
        try:
            path = self.getPlayingFile()
        except RuntimeError:
            return False
        return ADDON_ID in path or os.path.basename(path).startswith("deezer_")

    def onPlayBackSpeedChanged(self, speed):
        if speed in (0, 1):
            return
        if time.time() - self._last < GUARD_SECONDS:
            return
        try:
            if not xbmcaddon.Addon(ADDON_ID).getSettingBool("skip_buttons"):
                return
        except Exception:
            return
        if not self._is_deezer():
            return
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        size = playlist.size()
        pos = playlist.getposition()
        if speed > 1 and pos < size - 1:
            self._last = time.time()
            self.playnext()
        elif speed < 0 and pos > 0:
            self._last = time.time()
            self.playprevious()


def main():
    monitor = xbmc.Monitor()
    player = DeezerPlayer()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
    del player


main()
