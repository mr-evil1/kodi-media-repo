import sys
import os
import time
import json
import uuid
import hashlib
import re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "lib"))

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from urllib.parse import parse_qsl, urlencode, urlparse

import api as deezer_api
import proxy
import remote_arl
from i18n import t, lang, ARL_GUIDE_EN, MAIL_GUIDE_EN
from logger import log

_CH_KATEGORIEN = [
    ("96e8fae2-055f-439a-b304-acbfa33ea296", "podcasts", "Podcasts", "55dd289c7de652a42ca9d27aad53464b", "misc"),
    ("2e2a3c1f-ef0b-4c79-960f-f509c0a3c768", "new", "Neuheiten", "", "misc"),
    ("90c81be3-645d-4f2f-ac18-94ab98692473", "charts", "Charts", "", "misc"),
    ("60bf2d9c-6495-4e6e-8b55-dcb5327947b7", "foryou", "Für dich", "", "misc"),
    ("81e77d40-2d8e-44e8-aaba-9613e748fbe9", "next", "Deezer Next", "", "misc"),
    ("277dd746-e2e8-4721-92b1-997e238dce80", "chill", "Chill Out", "", "misc"),
    ("8e245368-617b-4d96-aaae-d4dcf2226c73", "workout", "Workout", "", "misc"),
    ("13dac720-f2b3-47d9-ba70-cb0aa52e6c49", "piano", "Klavier", "", "misc"),
    ("3691d513-01bc-412d-a661-c2feb494ef36", "party", "Party", "", "misc"),
    ("69d55684-5609-4042-b4e2-dc85a7d2e224", "discovery", "Musik entdecken", "", "misc"),
    ("bf6d1f3b-4a97-4acc-873d-4d5d8d49fea0", "animeverse", "AnimeVerse", "", "misc"),
    ("1a9b754a-0331-4cd4-a478-d801cc9e4b16", "lofi", "Lofi", "", "misc"),
    ("0a1174dd-143e-4ad1-acc1-8ee2b188b4a0", "2000s", "2000er", "", "misc"),
    ("2bd1a79e-502a-493f-8e5b-9ea348350fd7", "homelife", "Zu Hause", "", "misc"),
    ("79bb1c08-655c-4485-ae16-6ccdfdaf5064", "1980s", "1980er", "", "misc"),
    ("5d1d8521-02b2-45ae-bc16-6f8ed0bc3d5b", "sleep", "Schlafen", "", "misc"),
    ("8e4c4577-4a70-4af2-acc7-94b7ed51509f", "feel-good", "Happy", "", "misc"),
    ("679b6671-e672-4217-8bc1-7230df4adbef", "1990s", "1990er", "", "misc"),
    ("62c850fe-9b3e-46e6-906f-9b8eee2117a6", "kids", "Kids", "", "misc"),
    ("c3f95e4c-0f69-459a-b262-0de6d23f7173", "focus", "Konzentration", "", "misc"),
    ("49659dd8-1cb9-4d4f-8bab-aaeb8930b0ba", "2010s", "2010er", "", "misc"),
    ("fdc23bb3-9b93-478f-b5eb-5102d1bbd0bd", "acoustic", "Akustik", "", "misc"),
    ("19799de8-e2cf-4c87-8d93-f2ac6f269867", "essentials", "Essentials", "", "misc"),
    ("41bd97d4-08da-484a-b304-154282cd2d33", "summer", "Sommer", "", "misc"),
    ("fabadb7a-e17e-4e16-8b41-3247c73306a5", "feelingblue", "Feeling Sad", "", "misc"),
    ("22500fa0-c8f4-46bd-864b-9a5a569a4970", "gaming", "Gaming", "", "misc"),
    ("1dc957df-d945-4c1f-b0d5-c50f913d8538", "1970s", "1970er", "", "misc"),
    ("c892a70d-5705-44f9-a626-8d1c65b2491f", "bubble", "Bubble ", "", "misc"),
    ("35bc9854-5af9-4872-8cbd-ddb02efa3fac", "asmr", "ASMR", "", "misc"),
    ("ed8897f7-08a7-444e-bb85-956b85d2c0b8", "queerculture", "Queere Kultur", "", "misc"),
    ("e8372898-c2fd-485a-8be5-7eb8a9174d3c", "hiphop50", "Hip-Hop 50", "", "misc"),
]

_CH_GENRES = [
    ("25c78c12-561b-4a05-a89c-72ffc1ae00ab", "rock", "Rock", "", "misc"),
    ("fcd6d4bb-2288-4733-bc15-6aa0c198a7c4", "pop", "Pop", "", "misc"),
    ("cee82e63-e51e-4c81-9330-de6e47ab1ac8", "alternative", "Indie & Alternative", "", "misc"),
    ("4be4811a-852e-426d-bc23-4f2a11bdabf6", "soundtracks", "Filme & Serien", "", "misc"),
    ("7ff8d5d6-807c-4207-80c1-21a07ca2f457", "electronic", "Electro", "", "misc"),
    ("2ab8d537-a74c-4def-8e71-f6ce6d341415", "dance", "Dance & EDM", "", "misc"),
    ("8f035074-398a-4dc6-b072-62d66e226851", "folk", "Folk/Singer-Songwriter", "", "misc"),
    ("3327280c-cebb-4401-b4c5-eb033bf5751f", "soulfunk", "Soul & Funk", "", "misc"),
    ("9f734405-710a-4371-80c7-88932788b24e", "metal", "Metal", "", "misc"),
    ("7dc42495-d8c3-409b-9a55-9831362a5524", "french", "Französische Musik", "", "misc"),
    ("960e53e9-899f-4e15-8088-9cae057cea26", "rap", "Rap", "", "misc"),
    ("46a612dd-c949-469a-b077-79a5a45271fe", "house", "House", "ef9d07328e8d10ea6082b335b5e8c5a4", "misc"),
    ("b1ad7fcf-d7d8-4271-970b-75818e593ca5", "rnb", "R&B", "", "misc"),
    ("d81722c4-a1be-401f-8e24-fd9eb867e58a", "schlager", "Schlager", "", "misc"),
    ("b67dd4de-8ec3-4267-944a-0613d1a6072c", "jazz", "Jazz", "", "misc"),
    ("6fa8354b-b86e-4f5f-bcf6-f21f0cd6e6d4", "blues", "Blues", "", "misc"),
    ("64acabec-ae77-4ad4-8856-83a3880b3896", "caribbean", "Carribean", "", "misc"),
    ("9eb068ce-7f6b-449c-8928-5726e1af2dd0", "country", "Country", "", "misc"),
    ("e02a4c14-e76e-4de7-a59f-2059ef5147fc", "reggae", "Reggae", "", "misc"),
    ("b0df4b40-e107-4553-a009-59ad373ff68c", "latin", "Latin Musik", "", "misc"),
    ("b511effe-4da3-4e5f-ac07-4a5091eac454", "japanesemusic", "Japanische Musik", "", "misc"),
    ("95eb2efa-cdd5-4816-b95d-a82c000222d9", "afro", "Afro", "", "misc"),
    ("0a81e8c4-bd54-4081-a07f-20252624ed00", "flamenco", "Flamenco", "", "misc"),
    ("973baebc-01f1-41d4-bb9e-214b3032aea4", "reggaeton", "Reggaeton", "", "misc"),
    ("ad0e81cc-7d70-40d3-b8db-607e3d38536b", "classical", "Klassik", "", "misc"),
    ("9f474074-2a71-47a8-8e48-f0dcffed1dea", "k-pop", "K-Pop", "", "misc"),
    ("91bed8bd-55b0-4436-b7f6-629678704fd9", "brazilian", "Brasilianische Musik", "", "misc"),
    ("8bd8a1ed-0545-4830-931d-0c02d41b7787", "salsa", "Salsa", "", "misc"),
    ("1f8e7d82-8b98-440d-b387-d69f81dee3f6", "sambapagode", "Samba/Pagode", "", "misc"),
    ("7997d1a5-8935-4519-ae69-f7dd693f2f4f", "brazilianfunk", "Funk", "", "misc"),
    ("e9771c69-0f1f-4cdb-b1c4-217cf5fe10c6", "forro", "Forró", "", "misc"),
    ("11bc4646-5322-433d-9e61-6495126c75d3", "sertanejo", "Sertanejo", "", "misc"),
]

_CH_PODCASTS = [
    ("2024d5f3-bf1c-482b-b923-e2442ad5493c", "podcast-charts", "Podcast Charts", "e85521207586b547b39a837120253e50", "misc"),
    ("9b248e45-14a9-4054-a88f-0871b651312e", "news", "Nachrichten & Politik", "35c2e1f6eec6094aded3ec6c1bc93bbd", "misc"),
    ("355d2dc4-6b4d-4e68-98e6-94dd49d0ad77", "comedy", "Comedy", "0b4e397154f197697be6197b131a08d4", "misc"),
    ("75de79de-a97e-47a6-8142-6e3cac0737d1", "truecrime", "True Crime", "fd935039612491c1b6dd278fede05f07", "misc"),
    ("73c9a9fc-ea06-45b4-b823-61f9e287d2e6", "testimonies", "Erfahrungsberichte", "218b9c703206df18f8dff46b9bcdb8cc", "misc"),
    ("d607be3d-3b21-41bc-8855-67e11cbfc058", "storytelling", "Erzählungen", "53e4bbc0f5be74e0804c541cd4289f02", "misc"),
    ("dd448c88-ca3d-43f8-9e78-2f2324eed1f5", "mentalhealth", "Mentale Gesundheit", "9efe3c34692431b5f7337668d5c46a5d", "misc"),
    ("f988a437-79a3-4717-b2aa-01707b27eb55", "sportscoaching", "Sportcoaching", "e705dc11a7f8bf8e06bb41b4dc07407f", "misc"),
    ("df4d12c0-bb11-4024-9c97-04412a093eb5", "history", "Geschichte", "eb99c6be491cd9da115c257379dc0103", "misc"),
    ("42f77c5f-e31a-431c-a984-48744cd3b2cb", "kidspodcasts", "Podcasts für Kids", "f0cce403a6b5131565a6644bd6ea1330", "misc"),
    ("c75462c3-7138-4a99-94fd-56bd5198b7b7", "culture", "Gesellschaft", "eb70d65b953d1ea6143ace4f69944f65", "misc"),
    ("215afc2c-62a4-4d1a-be3e-addf80105754", "musiccommentaries", "Musik-Podcasts", "1fc316719f74d7a4917dbe310ff20292", "misc"),
    ("02a11d17-69f8-42c5-986d-d2fc28b1410b", "business", "Business", "26458af6c4fefd296603df5bd0c16be1", "misc"),
    ("449a75ce-a0f5-44bc-b3fb-dcf81f061a7b", "sport", "Sport", "e645c082cb21f80a374ae9e69af0878e", "misc"),
    ("72d56e62-45dd-423b-a30c-b86937ef1a65", "lifestyle", "Lifestyle & Hobbys", "eb8d3cda935d53d63b64b5d274d13949", "misc"),
    ("ac19f7b6-ebac-4ff1-bb2d-8cf6b480abe2", "popculture", "Popkultur", "737588ef6d7be5ab6a4f3ea1dd4cdc2d", "misc"),
    ("8601db2c-7470-4611-90c5-14e95a62c6e7", "selfhelp", "Persönliche Entwicklung", "9b2d6c09d650ecd4642b1dd97bc9e637", "misc"),
    ("1ad2765b-d6cf-4bd0-988d-2318d7564de7", "technology", "Technologie", "3ddcf67586d723dae9f39e98b90ec941", "misc"),
    ("eb8990df-302c-4c9a-beee-38531504cb8a", "science", "Wissenschaft & Medizin", "e310439560a73d16bb4c70b41c1579aa", "misc"),
    ("22500fa0-c8f4-46bd-864b-9a5a569a4970", "gaming", "Gaming", "", "misc"),
    ("2b1eed1d-ea45-4aad-ad7a-5387e3fb709e", "spirituality", "Spirituelles & Religion", "c072134ea963e7d366aa2b77e57ff714", "misc"),
    ("037a5504-48b1-47fc-8761-a4018b28cc0b", "football", "Fußball", "", "misc"),
    ("ea667969-e795-4966-88de-10616b10f0fe", "entrepreneurship", "Für Firmengründer", "2584f3cbd6377e714833c048801b1a12", "misc"),
    ("d4d4528d-5b4d-4139-8982-a855e6cd3e46", "ecology", "Ökologie", "d6428242c75c64ff2036911d1cee4f5a", "misc"),
    ("7713326c-f1f0-4de1-967e-8201ce980a35", "parenthood", "Elternsein", "cdb5da9ac58214c5f1a06473bfed3e62", "misc"),
    ("ed2bb806-6473-4770-8924-03194c60704c", "inspirationalwomen", "Frauen heute", "40130dda25b3dfd0bbf47e24e80ae3a3", "misc"),
    ("2dfa5fe1-558c-4c2e-8080-a27c0af9e8d9", "careergrowth", "Berufliche Entwicklung", "67df36030f70c91896c26299aed6fed1", "misc"),
    ("bab5f0dc-1eec-4ff8-a297-b23a10bd8d87", "booklovers", "Für Bücherwürmer", "0aaa6bd02c7b09ea6cf8cbeb006937a2", "misc"),
    ("97b29d67-3874-43cf-9eb5-bc9e2fd6b879", "forfoodies", "Für Foodies", "029cdbbff1ee8672231f13c35fa1f415", "misc"),
    ("6921b00b-2043-4115-b2cb-8c1db247d68c", "travel", "Reisen", "4f9841eb9f6d0ad3b0dfdafb9b268c27", "misc"),
    ("1b656181-1646-4242-91ba-4a857a648105", "esports", "Esports", "9ad4f63910cf434f6ee09379752b80b9", "misc"),
    ("a41d0b4f-cff3-405d-9dbd-cd9978e45220", "filmtv", "Film & Fernsehen", "eb3d63f02cb437efc0d686430d5da324", "misc"),
    ("be635491-c825-40c4-a897-359d8546f68e", "finearts", "Bildende Künste", "de2dcefa3690acbe72c7d346fde3d173", "misc"),
    ("92c34df1-b72e-4ff3-a210-8f8a5026aeef", "finance", "Finanzen", "bf6fba3551733eb7af4894ca4c7725fd", "misc"),
    ("4a36ae0d-c1df-42ee-846d-b7482080ecd3", "scarystories", "Gruselige Geschichten", "73437e84c5fa1668d757f719eddd4262", "misc"),
]

_CH_AUDIOBOOKS = [
    ("732c1997-b1a6-4970-bba0-bca5456982b9", "audiobooks", "Hörbücher", "bc1c9bb121d64f001794a1da9e548a41", "misc"),
    ("c0fdc33d-6bb7-4ea6-b893-96d0fa296795", "newaudiobooks", "Neue Hörbücher", "4f42e67e2a68cfc2b97693ce09fc1dc5", "misc"),
    ("e110ec55-cc53-45a9-aac8-d5cc7b0e5024", "topaudiobooks", "Top-Hörbücher", "a0b6dd357ffaa7d130075ef15a73bbce", "misc"),
    ("8d62c8f5-fd4a-4c88-bb4d-941d8cd8ce02", "suspense", "Spannung", "d4a844e645bd48073f1925f5e4bdc3ea", "misc"),
    ("adee9b13-d411-4133-8ec0-09d1f66fef2c", "fantasy", "Fantasy", "026435bc2f53a8e22b82a50169c2e687", "misc"),
    ("1712253f-66d7-45d6-a247-0db3f27db394", "kidsstories", "Geschichten für Kinder", "76dcab189c6249bf09503da153752667", "misc"),
    ("d2f77654-6472-4618-a5dd-5a20584a636c", "audioplays", "Hörspiele", "75ee4a6a068223550cf1e73411ed3a85", "misc"),
    ("b3565b97-bab4-4aad-bf93-25f16aa0bdc9", "scifi", "Sci-Fi", "e3a4c5f61995d9c95c8b9c1487e77982", "misc"),
    ("ffb3c30a-80c7-4339-b7db-1ef032ff77e4", "wellbeing", "Wohlbefinden", "0e56c344f1b15fb12689d372728a70db", "misc"),
    ("adeb4804-bb58-4e43-bcd0-933977641969", "classics", "Klassiker", "4a290f82bfcac5f342577a6831f3d1fc", "misc"),
    ("7ed254a0-d53b-41e2-94dc-5aa7cb4b04a5", "englishcorner", "Englische Ecke", "9cbf17da226905647c1bf317dc3c6e0e", "misc"),
]

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON_PATH = ADDON.getAddonInfo("path")
ICON = os.path.join(ADDON_PATH, "icon.png")
FANART = os.path.join(ADDON_PATH, "fanart.jpg")
MENU_ART = {"thumb": ICON, "icon": ICON, "fanart": FANART}
_PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
_SESSION_FILE = os.path.join(_PROFILE_DIR, "session.json")
_HISTORY_FILE = os.path.join(_PROFILE_DIR, "search_history.json")
_HISTORY_MAX = 30
_FAVORITES_FILE = os.path.join(_PROFILE_DIR, "my_favorites.json")
_PLAYLISTS_FILE = os.path.join(_PROFILE_DIR, "my_playlists.json")
_QUEUE_FILE = os.path.join(_PROFILE_DIR, "queue.json")
_QUEUE_KEYS_MAX = 12
_FAV_KINDS = [
    ("track", "kind_track"),
    ("album", "kind_album"),
    ("artist", "kind_artist"),
    ("playlist", "kind_playlist"),
]

deezer_api.set_logger(log)
proxy.set_logger(log)

_dz = None


def _arl_hash(arl):
    return hashlib.sha256(arl.encode("utf-8")).hexdigest()


_ARL_FILE = "/storage/emulated/0/Download/arl.txt"
_ARL_FILE_ALT = [
    "/sdcard/Download/arl.txt",
    "/storage/self/primary/Download/arl.txt",
]
_ARL_PATTERN = re.compile(r"^\S{32,400}$")


def _read_raw_file(path):
    try:
        with open(path, "rb") as f:
            return f.read()
    except Exception as e:
        log(f"_read_arl_file open({path}): {e}")
    try:
        f = xbmcvfs.File(path)
        try:
            data = f.readBytes()
        finally:
            f.close()
        if data:
            return bytes(data)
    except Exception as e:
        log(f"_read_arl_file xbmcvfs({path}): {e}")
    return None


def _clean_arl(text):
    for line in text.replace("\ufeff", "").splitlines():
        line = line.strip()
        if not line:
            continue
        if "=" in line:
            line = line.split("=", 1)[1]
        elif ":" in line and not line.startswith("http"):
            line = line.split(":", 1)[1]
        line = line.strip().strip("\"'`").strip()
        return line
    return ""


def _read_arl_file():
    for path in [_ARL_FILE] + _ARL_FILE_ALT:
        raw = _read_raw_file(path)
        if raw is None:
            continue
        text = raw.decode("utf-8", "ignore")
        value = _clean_arl(text)
        log(f"_read_arl_file: {path} gelesen, {len(raw)} Bytes, Wert {len(value)} Zeichen")
        if value and _ARL_PATTERN.match(value):
            return value
        log("_read_arl_file: ungueltiges Format")
    return ""


def _ensure_arl_file():
    if not xbmc.getCondVisibility("System.Platform.Android"):
        return
    if os.path.exists(_ARL_FILE) or xbmcvfs.exists(_ARL_FILE):
        return
    try:
        os.makedirs(os.path.dirname(_ARL_FILE), exist_ok=True)
        with open(_ARL_FILE, "w", encoding="utf-8") as f:
            f.write("")
        log("_ensure_arl_file: arl.txt erstellt")
    except Exception as e:
        log(f"_ensure_arl_file: {e}", xbmc.LOGWARNING)


_mail_failed = False


_CREDS_FILE = "profile.dat"


def _save_creds(mail, password):
    remote_arl.store_blob(_PROFILE_DIR, _CREDS_FILE, json.dumps({"m": mail, "p": password}))


def _load_creds():
    raw = remote_arl.load_blob(_PROFILE_DIR, _CREDS_FILE)
    if not raw:
        return "", ""
    try:
        d = json.loads(raw)
        return d.get("m", ""), d.get("p", "")
    except Exception:
        return "", ""


def _renew_from_stored():
    global _mail_failed
    if _mail_failed:
        return ""
    mail, password = _load_creds()
    if not mail or not password:
        return ""
    try:
        arl = deezer_api.DeezerAPI().login_mail(mail, password)
    except Exception as e:
        _mail_failed = True
        log(f"_renew_from_stored: {e}", xbmc.LOGWARNING)
        return ""
    ADDON.setSetting("arl", arl)
    log("_renew_from_stored: ok")
    return arl


def _login_with_mail():
    global _mail_failed
    mail = ADDON.getSetting("mail").strip()
    password = ADDON.getSetting("password")
    if not mail or not password or _mail_failed:
        return ""
    try:
        api = deezer_api.DeezerAPI()
        arl = api.login_mail(mail, password)
    except Exception as e:
        _mail_failed = True
        log(f"_login_with_mail: {e}", xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("Deezer", t("mail_login_failed"))
        return ""
    _save_creds(mail, password)
    ADDON.setSetting("arl", arl)
    ADDON.setSetting("password", "")
    log("_login_with_mail: ok")
    return arl


def _resolve_arl(force_refresh=False, skip_file=False):
    manual = ADDON.getSetting("arl").strip()
    if manual:
        return manual, "settings"
    if not skip_file:
        file_arl = _read_arl_file()
        if file_arl:
            try:
                ADDON.setSetting("arl", file_arl)
            except Exception as e:
                log(f"_resolve_arl setSetting: {e}", xbmc.LOGWARNING)
            return file_arl, "file"
    mail_arl = _login_with_mail()
    if mail_arl:
        return mail_arl, "settings"
    if force_refresh:
        arl = remote_arl.refresh(_PROFILE_DIR, ADDON.getSetting("arl_url").strip())
        if arl:
            return arl, "remote"
    url = ADDON.getSetting("arl_url").strip()
    arl = remote_arl.get(_PROFILE_DIR, url)
    if not arl and url:
        _show_arl_url_error("arl_url_download_failed")
    return arl, "remote"


def _save_session(dz, arl):
    try:
        os.makedirs(os.path.dirname(_SESSION_FILE), exist_ok=True)
        with open(_SESSION_FILE, "w") as f:
            json.dump({
                "api_token": dz.api_token,
                "user_id": dz.user_id,
                "license_token": dz.license_token,
                "can_stream": dz.can_stream,
                "arl_hash": _arl_hash(arl),
            }, f)
        log(f"_save_session: gespeichert user_id={dz.user_id}")
    except Exception as e:
        log(f"_save_session: Fehler – {e}", xbmc.LOGWARNING)


def _load_session(dz, current_arl):
    try:
        with open(_SESSION_FILE) as f:
            s = json.load(f)
        if s.get("user_id", 0) == 0:
            return False
        if s.get("arl_hash", "") != _arl_hash(current_arl):
            log("_load_session: ARL geändert, Session ungültig")
            return False
        if "can_stream" not in s:
            return False
        dz.restore_session(s["api_token"], s["user_id"], s["license_token"], current_arl, can_stream=s["can_stream"])
        log(f"_load_session: wiederhergestellt user_id={dz.user_id}")
        return True
    except (FileNotFoundError, KeyError, json.JSONDecodeError):
        return False
    except Exception as e:
        log(f"_load_session: Fehler – {e}", xbmc.LOGWARNING)
        return False


_invalid_arl_shown = False


def _try_login(arl):
    try:
        return _dz.login_arl(arl)
    except Exception as e:
        log(f"login_arl Fehler: {e}", xbmc.LOGWARNING)
        return False


def _show_invalid_arl():
    global _invalid_arl_shown
    if _invalid_arl_shown:
        return
    _invalid_arl_shown = True
    xbmcgui.Dialog().ok("Deezer", t("invalid_arl"))


_arl_url_error_shown = False


def _show_arl_url_error(key):
    global _arl_url_error_shown
    if _arl_url_error_shown:
        return
    _arl_url_error_shown = True
    xbmcgui.Dialog().ok("Deezer", t(key))


_arl_source = ""


def get_api():
    global _dz, _arl_source
    if _dz is None:
        _dz = deezer_api.DeezerAPI()
    arl, source = _resolve_arl()
    first_source = source
    _arl_source = source
    if not arl:
        log("get_api: kein ARL Token verfuegbar")
        return None
    if _dz.user_id == 0:
        if _load_session(_dz, arl):
            _dz._on_relogin = lambda: _save_session(_dz, arl)
            _dz._renew_arl = _renew_from_stored
            return _dz
        log("get_api: login_arl wird ausgefuehrt")
        ok = _try_login(arl)
        if not ok and source in ("settings", "file"):
            new_arl = _renew_from_stored()
            if new_arl:
                arl = new_arl
                source = "settings"
                _arl_source = source
                ok = _try_login(arl)
        if not ok and source == "file":
            new_arl, _ = _resolve_arl(skip_file=True)
            if new_arl:
                arl = new_arl
                source = "remote"
                _arl_source = source
                ok = _try_login(arl)
        if not ok and source == "remote":
            new_arl, _ = _resolve_arl(force_refresh=True, skip_file=True)
            if new_arl:
                arl = new_arl
                ok = _try_login(arl)
        if not ok:
            log("get_api: login_arl fehlgeschlagen", xbmc.LOGERROR)
            if first_source in ("settings", "file"):
                _show_invalid_arl()
            elif ADDON.getSetting("arl_url").strip():
                _show_arl_url_error("arl_url_login_failed")
            return None
        log(f"get_api: eingeloggt als user_id={_dz.user_id}")
        _save_session(_dz, arl)
        _dz._on_relogin = lambda: _save_session(_dz, arl)
        _dz._renew_arl = _renew_from_stored
    return _dz


def url_for(**params):
    return BASE_URL + "?" + urlencode(params)


def _fav_add_menu(kind, item_id, title, artist="", album="", pic="", duration=0):
    url = url_for(action="fav_add", kind=kind, id=str(item_id), title=title, artist=artist,
                  album=album, pic=pic, duration=str(duration))
    return [(t("fav_add"), "RunPlugin(" + url + ")")]


def _fav_remove_menu(kind, item_id):
    url = url_for(action="fav_remove", kind=kind, id=str(item_id))
    return [(t("fav_remove"), "RunPlugin(" + url + ")")]


def _pl_add_menu(item_id, title, artist="", album="", pic="", duration=0):
    url = url_for(action="pl_add", id=str(item_id), title=title, artist=artist,
                  album=album, pic=pic, duration=str(duration))
    return [(t("add_to_playlist"), "RunPlugin(" + url + ")")]


def _set_info(li, info):
    get_tag = getattr(li, "getVideoInfoTag", None)
    tag = get_tag() if get_tag else None
    if tag is None or not hasattr(tag, "setTitle"):
        li.setInfo("video", info)
        return
    if info.get("title"):
        tag.setTitle(info["title"])
    if info.get("mediatype"):
        tag.setMediaType(info["mediatype"])
    artists = info.get("artist")
    if artists:
        tag.setArtists(artists if isinstance(artists, list) else [artists])
    if info.get("album"):
        tag.setAlbum(info["album"])
    if info.get("plot"):
        tag.setPlot(info["plot"])
    if info.get("duration"):
        tag.setDuration(int(info["duration"]))
    if info.get("tracknumber"):
        tag.setTrackNumber(int(info["tracknumber"]))
    if info.get("year"):
        tag.setYear(int(info["year"]))


def add_dir(label, params, is_folder=True, art=None, info=None, menu=None):
    li = xbmcgui.ListItem(label)
    li.setArt(art if art else MENU_ART)
    if info:
        _set_info(li, info)
    if menu:
        li.addContextMenuItems(menu)
    xbmcplugin.addDirectoryItem(HANDLE, url_for(**params), li, is_folder)


def _video_info(title, artist, album, duration, track_num=0, year=0):
    info = {
        "mediatype": "musicvideo",
        "title": title,
        "artist": [artist] if artist else [],
        "album": album,
        "plot": f"{artist}\n{album}".strip(),
        "duration": duration,
    }
    if track_num:
        info["tracknumber"] = track_num
    if year:
        info["year"] = year
    return info


def _norm_track(t):
    return {
        "id": str(t.get("SNG_ID", "")),
        "title": t.get("SNG_TITLE", "?"),
        "artist": t.get("ART_NAME", ""),
        "album": t.get("ALB_TITLE", ""),
        "pic": t.get("ALB_PICTURE", ""),
        "duration": int(t.get("DURATION", 0) or 0),
    }


def _entry_to_track(x):
    return {
        "SNG_ID": x["id"], "SNG_TITLE": x.get("title", "?"), "ART_NAME": x.get("artist", ""),
        "ALB_TITLE": x.get("album", ""), "ALB_PICTURE": x.get("pic", ""),
        "DURATION": x.get("duration", 0),
    }


def _queue_read():
    try:
        with open(_QUEUE_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (FileNotFoundError, ValueError, OSError):
        return {}


def _queue_store(key, tracks):
    data = _queue_read()
    data.pop(key, None)
    data[key] = [_norm_track(t) for t in tracks if t.get("SNG_ID")]
    while len(data) > _QUEUE_KEYS_MAX:
        data.pop(next(iter(data)))
    try:
        os.makedirs(_PROFILE_DIR, exist_ok=True)
        with open(_QUEUE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
    except OSError as e:
        log(f"_queue_store Fehler: {e}", xbmc.LOGWARNING)


def add_track_list(tracks, key, quality, menu_fn=None, fav_remove=False):
    tracks = [tr for tr in tracks if tr.get("SNG_ID")]
    _queue_store(key, tracks)
    for idx, tr in enumerate(tracks):
        extra = menu_fn(idx, len(tracks)) if menu_fn else None
        add_track(tr, quality, fav_remove=fav_remove, extra_menu=extra, queue=(key, idx))


def queue_play(key, idx, quality):
    entries = _queue_read().get(key, [])
    if not entries:
        xbmcgui.Dialog().notification("Deezer", t("list_unavailable"), xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    idx = max(0, min(idx, len(entries) - 1))
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    for x in entries:
        title = x.get("title", "")
        artist = x.get("artist", "")
        cover = deezer_api.cover_url(x.get("pic", ""))
        li = xbmcgui.ListItem(f"{artist} – {title}")
        _set_info(li, _video_info(title, artist, x.get("album", ""), int(x.get("duration", 0) or 0)))
        li.setArt({"thumb": cover, "icon": cover, "poster": cover, "fanart": cover})
        li.setProperty("IsPlayable", "true")
        playlist.add(url_for(action="play", track_id=x["id"], quality=quality), li)
    xbmc.Player().play(playlist, startpos=idx)


def add_track(track, quality="MP3_128", fav_remove=False, extra_menu=None, queue=None):
    title = track.get("SNG_TITLE", "?")
    artist = track.get("ART_NAME", "")
    album = track.get("ALB_TITLE", "")
    track_id = str(track.get("SNG_ID", ""))
    duration = int(track.get("DURATION", 0) or 0)
    alb_md5 = track.get("ALB_PICTURE", "")
    cover = deezer_api.cover_url(alb_md5)
    art = {"thumb": cover, "icon": deezer_api.cover_url(alb_md5, 250), "poster": cover, "fanart": cover} if cover else MENU_ART
    year = int((track.get("PHYSICAL_RELEASE_DATE", "0000") or "0000")[:4] or 0)
    li = xbmcgui.ListItem(f"{artist} – {title}")
    li.setArt(art)
    _set_info(li, _video_info(title, artist, album, duration,
                                    int(track.get("TRACK_NUMBER", 0) or 0), year))
    if not queue:
        li.setProperty("IsPlayable", "true")
    menu = list(extra_menu or [])
    menu += _pl_add_menu(track_id, title, artist, album, alb_md5, duration)
    if fav_remove:
        menu += _fav_remove_menu("track", track_id)
    else:
        menu += _fav_add_menu("track", track_id, title, artist, album, alb_md5, duration)
    li.addContextMenuItems(menu)
    if queue:
        play_url = url_for(action="queue_play", key=queue[0], idx=queue[1], quality=quality)
    else:
        play_url = url_for(action="play", track_id=track_id, quality=quality)
    xbmcplugin.addDirectoryItem(HANDLE, play_url, li, False)


def _public_track_to_sng(x):
    artist = x.get("artist", {}) or {}
    album = x.get("album", {}) or {}
    return {
        "SNG_ID": x.get("id", ""),
        "SNG_TITLE": x.get("title") or x.get("title_short") or "?",
        "ART_NAME": artist.get("name", ""),
        "ALB_TITLE": album.get("title", ""),
        "ALB_PICTURE": album.get("cover_medium") or album.get("cover") or "",
        "DURATION": x.get("duration", 0),
    }


def _art_from_pic(pic):
    if not pic:
        return MENU_ART
    return {"thumb": pic, "icon": pic, "poster": pic, "fanart": pic}


def show_explore():
    add_dir(t("charts"), {"action": "chart_menu", "id": 0})
    add_dir(t("genres"), {"action": "genres"})
    xbmcplugin.endOfDirectory(HANDLE)


def show_genres():
    dz = get_api()
    if not dz:
        return
    log("show_genres")
    data = dz.get_genres()
    genres = data.get("data", []) if isinstance(data, dict) else []
    for g in genres:
        gid = g.get("id")
        if gid in (0, None):
            continue
        name = g.get("name", "?")
        pic = g.get("picture_medium") or g.get("picture") or ""
        add_dir(name, {"action": "chart_menu", "id": gid}, art=_art_from_pic(pic))
    xbmcplugin.endOfDirectory(HANDLE)


def show_chart_menu(genre_id):
    add_dir(t("chart_tracks"), {"action": "chart_tracks", "id": genre_id})
    add_dir(t("chart_playlists"), {"action": "chart_playlists", "id": genre_id})
    add_dir(t("chart_albums"), {"action": "chart_albums", "id": genre_id})
    add_dir(t("chart_artists"), {"action": "chart_artists", "id": genre_id})
    xbmcplugin.endOfDirectory(HANDLE)


def show_chart_tracks(genre_id):
    dz = get_api()
    if not dz:
        return
    log(f"show_chart_tracks genre_id={genre_id}")
    quality = _quality()
    data = dz.get_chart(genre_id, "tracks")
    items = data.get("data", []) if isinstance(data, dict) else []
    tracks = [_public_track_to_sng(x) for x in items]
    log(f"  {len(tracks)} tracks geladen")
    add_track_list(tracks, f"chart_tracks:{genre_id}", quality)
    xbmcplugin.endOfDirectory(HANDLE)


def show_chart_playlists(genre_id):
    dz = get_api()
    if not dz:
        return
    log(f"show_chart_playlists genre_id={genre_id}")
    data = dz.get_chart(genre_id, "playlists")
    items = data.get("data", []) if isinstance(data, dict) else []
    for p in items:
        pid = p.get("id", "")
        title = p.get("title", "?")
        pic = p.get("picture_medium") or p.get("picture") or ""
        add_dir(title, {"action": "playlist", "id": pid}, art=_art_from_pic(pic))
    xbmcplugin.endOfDirectory(HANDLE)


def show_chart_albums(genre_id):
    dz = get_api()
    if not dz:
        return
    log(f"show_chart_albums genre_id={genre_id}")
    data = dz.get_chart(genre_id, "albums")
    items = data.get("data", []) if isinstance(data, dict) else []
    for a in items:
        aid = a.get("id", "")
        title = a.get("title", "?")
        artist = (a.get("artist", {}) or {}).get("name", "")
        pic = a.get("cover_medium") or a.get("cover") or ""
        label = f"{artist} – {title}" if artist else title
        add_dir(label, {"action": "album", "id": aid}, art=_art_from_pic(pic))
    xbmcplugin.endOfDirectory(HANDLE)


def show_chart_artists(genre_id):
    dz = get_api()
    if not dz:
        return
    log(f"show_chart_artists genre_id={genre_id}")
    data = dz.get_chart(genre_id, "artists")
    items = data.get("data", []) if isinstance(data, dict) else []
    for ar in items:
        arid = ar.get("id", "")
        name = ar.get("name", "?")
        pic = ar.get("picture_medium") or ar.get("picture") or ""
        add_dir(name, {"action": "artist", "id": arid}, art=_art_from_pic(pic))
    xbmcplugin.endOfDirectory(HANDLE)


def _channel_art(pic, ptype):
    if not pic:
        return MENU_ART
    url = deezer_api.cover_url(pic)
    return _art_from_pic(url)


def show_categories():
    add_dir(t("cat_kategorien"), {"action": "cat_list", "group": "kategorien"})
    add_dir(t("cat_genres"), {"action": "cat_list", "group": "genres"})
    add_dir(t("cat_podcasts"), {"action": "cat_list", "group": "podcasts"})
    add_dir(t("cat_audiobooks"), {"action": "cat_list", "group": "audiobooks"})
    xbmcplugin.endOfDirectory(HANDLE)


_CH_GROUPS = {
    "kategorien": _CH_KATEGORIEN,
    "genres": _CH_GENRES,
    "podcasts": _CH_PODCASTS,
    "audiobooks": _CH_AUDIOBOOKS,
}


def show_cat_list(group):
    items = _CH_GROUPS.get(group, [])
    log(f"show_cat_list group={group} ({len(items)} items)")
    for cid, slug, title, pic, ptype in items:
        add_dir(title, {"action": "channel", "slug": slug}, art=_channel_art(pic, ptype))
    xbmcplugin.endOfDirectory(HANDLE)


def show_channel(slug):
    dz = get_api()
    if not dz:
        return
    log(f"show_channel slug={slug}")
    quality = _quality()
    state = dz.get_channel_page(slug)
    sections = state.get("sections", []) if isinstance(state, dict) else []
    any_item = False
    for sec in sections:
        for it in sec.get("items", []):
            d = it.get("data", {}) or {}
            dtype = d.get("type", "")
            if dtype == "channel" and d.get("slug"):
                any_item = True
                pics = d.get("pictures") or []
                pic = pics[0].get("md5", "") if pics else ""
                add_dir(d.get("title") or d.get("name", "?"),
                        {"action": "channel", "slug": d["slug"]}, art=_channel_art(pic, "misc"))
            elif dtype == "show" and d.get("id"):
                any_item = True
                pics = d.get("pictures") or []
                pic = pics[0].get("md5", "") if pics else ""
                add_dir(d.get("title", "?"), {"action": "show", "id": d["id"]},
                        art=_channel_art(pic, "talk"))
            elif dtype == "playlist" and d.get("id"):
                any_item = True
                pics = d.get("pictures") or []
                pic = pics[0].get("md5", "") if pics else ""
                add_dir(d.get("title", "?"), {"action": "playlist", "id": d["id"]},
                        art=_channel_art(pic, "playlist"))
            elif dtype == "album" and d.get("id"):
                any_item = True
                pics = d.get("pictures") or []
                pic = pics[0].get("md5", "") if pics else ""
                add_dir(d.get("title", "?"), {"action": "album", "id": d["id"]},
                        art=_channel_art(pic, "cover"))
            elif dtype == "artist" and d.get("id"):
                any_item = True
                pics = d.get("pictures") or []
                pic = pics[0].get("md5", "") if pics else ""
                add_dir(d.get("name") or d.get("title", "?"), {"action": "artist", "id": d["id"]},
                        art=_channel_art(pic, "artist"))
    if not any_item:
        xbmcgui.Dialog().notification("Deezer", t("channel_empty"), xbmcgui.NOTIFICATION_INFO, 3000)
    xbmcplugin.endOfDirectory(HANDLE)


def show_podcast(show_id):
    dz = get_api()
    if not dz:
        return
    log(f"show_podcast id={show_id}")
    episodes = dz.get_show_episodes(show_id)
    shown = 0
    for ep in episodes:
        if not isinstance(ep, dict) or not ep.get("id") or ep.get("available") is False:
            continue
        title = ep.get("title", "?")
        pic = ep.get("picture_big") or ep.get("picture_medium") or ""
        li = xbmcgui.ListItem(title)
        li.setArt(_art_from_pic(pic))
        _set_info(li, {
            "mediatype": "musicvideo",
            "title": title,
            "plot": ep.get("description", ""),
            "duration": int(ep.get("duration", 0) or 0),
        })
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(HANDLE, url_for(action="episode_play", id=str(ep["id"])), li, False)
        shown += 1
    log(f"  {shown} episoden")
    if not shown:
        xbmcgui.Dialog().notification("Deezer", t("channel_empty"), xbmcgui.NOTIFICATION_INFO, 3000)
    xbmcplugin.endOfDirectory(HANDLE)


def play_episode(episode_id):
    dz = get_api()
    if not dz:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    if not _playback_allowed(dz):
        _deny_playback()
        return
    url = dz.get_episode_stream(episode_id)
    log(f"play_episode id={episode_id} url={'ja' if url else 'nein'}")
    if not url:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=url)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def router(params):
    action = params.get("action", "root")
    log(f"router action={action} params={params}")

    if action == "root":
        show_root()
    elif action == "my_music":
        show_my_music()
    elif action == "favorite_tracks":
        show_favorite_tracks()
    elif action == "playlists":
        show_playlists()
    elif action == "playlist":
        show_playlist(params["id"])
    elif action == "favorite_albums":
        show_favorite_albums()
    elif action == "album":
        show_album(params["id"])
    elif action == "favorite_artists":
        show_favorite_artists()
    elif action == "artist":
        show_artist(params["id"])
    elif action == "artist_top":
        show_artist_top(params["id"])
    elif action == "search":
        show_search()
    elif action == "queue_play":
        queue_play(params["key"], int(params.get("idx", 0)), params.get("quality", "MP3_128"))
    elif action == "pl_new":
        pl_new()
    elif action == "pl_open":
        show_my_playlist(params["id"])
    elif action == "pl_rename":
        pl_rename(params["id"])
    elif action == "pl_delete":
        pl_delete(params["id"])
    elif action == "pl_move":
        pl_move(params["id"], params.get("dir", "up"))
    elif action == "pl_add":
        pl_add(params)
    elif action == "pl_track_remove":
        pl_track_remove(params["id"], int(params.get("idx", -1)))
    elif action == "pl_track_move":
        pl_track_move(params["id"], int(params.get("idx", -1)), params.get("dir", "up"))
    elif action == "my_favorites":
        show_my_favorites()
    elif action == "fav_list":
        show_fav_list(params["kind"])
    elif action == "fav_add":
        fav_add(params)
    elif action == "fav_remove":
        fav_remove(params["kind"], params["id"])
    elif action == "search_new":
        show_search_new()
    elif action == "search_edit":
        search_edit(params["query"])
    elif action == "search_delete":
        search_delete(params["query"])
    elif action == "search_clear":
        search_clear()
    elif action == "search_results":
        show_search_results(params["query"])
    elif action == "flow":
        show_flow(int(params.get("page", 0) or 0))
    elif action == "explore":
        show_explore()
    elif action == "genres":
        show_genres()
    elif action == "chart_menu":
        show_chart_menu(params.get("id", 0))
    elif action == "chart_tracks":
        show_chart_tracks(params.get("id", 0))
    elif action == "chart_playlists":
        show_chart_playlists(params.get("id", 0))
    elif action == "chart_albums":
        show_chart_albums(params.get("id", 0))
    elif action == "chart_artists":
        show_chart_artists(params.get("id", 0))
    elif action == "categories":
        show_categories()
    elif action == "cat_list":
        show_cat_list(params.get("group", ""))
    elif action == "channel":
        show_channel(params["slug"])
    elif action == "show":
        show_podcast(params["id"])
    elif action == "episode_play":
        play_episode(params["id"])
    elif action in ("play", "play_token"):
        play_track(params["track_id"], params.get("quality", "MP3_128"))
    elif action == "settings":
        ADDON.openSettings()
    elif action == "register":
        open_register()
    elif action == "guide":
        show_guide_menu()
    elif action == "guide_mail":
        xbmcgui.Dialog().textviewer(t("guide_mail_title"), _mail_guide())
        xbmc.executebuiltin(f"Container.Update({BASE_URL},replace)")
    elif action == "guide_arl":
        xbmcgui.Dialog().textviewer(t("guide_arl_title"), _arl_guide())
        xbmc.executebuiltin(f"Container.Update({BASE_URL},replace)")


_FIRST_START_FILE = os.path.join(_PROFILE_DIR, "first_start_done")

_ARL_GUIDE_DE = (
    "So kommst du an deine Deezer ARL:\n\n"
    "Vorbereitung\n"
    "1. Öffne auf einem Computer https://www.deezer.com und melde dich mit deinem Deezer-Konto an. Die Seite muss danach offen bleiben.\n\n"
    "Google Chrome / Microsoft Edge\n"
    "2. Drücke die Taste F12 (oder Strg+Umschalt+I). Rechts oder unten öffnen sich die Entwicklertools.\n"
    "3. Klicke oben in der Leiste der Entwicklertools auf den Reiter \"Anwendung\" (englisch \"Application\"). "
    "Ist er nicht sichtbar, klicke auf die beiden Pfeile \">>\" am Ende der Leiste und wähle ihn dort aus.\n"
    "4. Klicke links in der Seitenleiste unter \"Speicher\" (\"Storage\") auf den kleinen Pfeil vor \"Cookies\", damit sich der Eintrag aufklappt.\n"
    "5. Klicke darunter auf \"https://www.deezer.com\". Rechts erscheint eine Tabelle mit den Spalten Name, Wert (Value), Domain und so weiter.\n"
    "6. Suche in der Spalte \"Name\" die Zeile \"arl\". Tipp: Oben im Feld \"Cookies filtern\" einfach arl eintippen.\n"
    "7. Klicke auf die Zeile \"arl\". Unten im Fenster wird der komplette Wert angezeigt. "
    "Klicke in diesen Wert, markiere alles mit Strg+A und kopiere mit Strg+C. "
    "Alternativ doppelklicke in der Tabelle in die Spalte \"Wert\", Strg+A, Strg+C.\n\n"
    "Mozilla Firefox\n"
    "2. Drücke F12. Wähle oben den Reiter \"Speicher\" (\"Storage\"), sonst über die Pfeile \">>\".\n"
    "3. Links \"Cookies\" aufklappen und \"https://www.deezer.com\" anklicken.\n"
    "4. Zeile \"arl\" anklicken, der Wert erscheint rechts im Detailbereich. Wert markieren (Strg+A) und kopieren (Strg+C).\n\n"
    "Prüfen\n"
    "Die ARL ist eine lange Zeichenfolge aus Buchstaben und Zahlen mit ca. 192 Zeichen. Ist sie viel kürzer, wurde nicht der richtige Wert kopiert.\n\n"
    "In Kodi eintragen\n"
    "8. Addon-Einstellungen > Konto > ARL Token öffnen, den Wert einfügen und mit OK bestätigen. Ohne Leerzeichen und ohne Anführungszeichen.\n\n"
    "Alternative nur für Android: ARL per Datei\n"
    "Statt die ARL in Kodi einzutippen, kannst du sie in eine Datei einfügen. Das Addon legt die leere Datei beim Start automatisch an:\n"
    "9. Öffne den Dateimanager deines Geräts und gehe in den Ordner Download (/storage/emulated/0/Download).\n"
    "10. Öffne dort die Datei arl.txt mit einem Texteditor.\n"
    "11. Füge die kopierte ARL als einzigen Inhalt ein, ohne Leerzeichen und Anführungszeichen, und speichere.\n"
    "12. Starte das Addon neu. Es liest die Datei automatisch aus.\n"
    "Die Datei wird nur verwendet, wenn eine gültige ARL darin steht. Ein Eintrag in den Addon-Einstellungen hat immer Vorrang.\n"
    "Wird die Datei nicht angelegt oder gelesen, prüfe in den Android-Einstellungen unter Apps > Kodi > Berechtigungen, ob Kodi Zugriff auf Dateien und Medien bzw. Speicher hat.\n\n"
    "Hinweis: Die ARL ist wie ein Passwort. Gib sie niemals weiter. Meldest du dich bei Deezer ab, wird sie ungültig und du musst eine neue holen."
)


_MAIL_GUIDE_DE = (
    "So meldest du dich mit E-Mail und Passwort an:\n\n"
    "1. Öffne die Addon-Einstellungen. Du findest sie im Hauptmenü des Addons unter \"Einstellungen\" oder über das Kontextmenü des Addons.\n\n"
    "2. Gehe auf die Kategorie \"Konto\".\n\n"
    "3. Trage im Feld \"E-Mail\" die E-Mail-Adresse deines Deezer-Kontos ein.\n\n"
    "4. Trage im Feld \"Passwort\" dein Deezer-Passwort ein. Die Eingabe wird verdeckt angezeigt.\n\n"
    "5. Bestätige mit OK und schließe die Einstellungen.\n\n"
    "6. Öffne das Addon neu. Es meldet sich automatisch an, holt sich die ARL und trägt sie selbst im Feld \"ARL Token\" ein.\n\n"
    "7. Nach erfolgreichem Login wird das Passwort aus den Einstellungen gelöscht und verschlüsselt im Addon gespeichert.\n\n"
    "Hinweise\n"
    "Du musst die Anmeldung nur einmal durchführen. Läuft die ARL irgendwann ab, meldet sich das Addon mit dem gespeicherten Passwort automatisch neu an und erneuert sie.\n"
    "Meldest du dich mit Facebook, Google oder Apple bei Deezer an, hast du kein Passwort. Nutze dann die Anleitung für die ARL.\n"
    "Erscheint die Meldung, dass der Login fehlgeschlagen ist, prüfe E-Mail und Passwort oder nutze die Anleitung für die ARL."
)


def _arl_guide():
    return _ARL_GUIDE_DE if lang() == "de" else ARL_GUIDE_EN


def _mail_guide():
    return _MAIL_GUIDE_DE if lang() == "de" else MAIL_GUIDE_EN


_REGISTER_URL = "https://www.deezer.com/register"


def open_register():
    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmc.executebuiltin(f'StartAndroidActivity("","android.intent.action.VIEW","","{_REGISTER_URL}")')
        return
    xbmcgui.Dialog().textviewer(t("register_title"), t("register_text").format(url=_REGISTER_URL))


def show_guide_menu():
    add_dir(t("register_item"), {"action": "register"}, is_folder=False)
    add_dir(t("guide_mail_item"), {"action": "guide_mail"}, is_folder=False)
    add_dir(t("guide_arl_item"), {"action": "guide_arl"}, is_folder=False)
    add_dir(ADDON.getLocalizedString(32038), {"action": "settings"}, is_folder=False)
    xbmcplugin.endOfDirectory(HANDLE)


_GUIDE_LABEL = None


def _mark_first_start_done():
    try:
        os.makedirs(_PROFILE_DIR, exist_ok=True)
        with open(_FIRST_START_FILE, "w") as f:
            f.write("1")
    except Exception as e:
        log(f"first_start: Fehler – {e}", xbmc.LOGWARNING)


def _first_start_guide():
    _ensure_arl_file()
    if os.path.exists(_FIRST_START_FILE):
        log("first_start: bereits erledigt")
        return False
    has_own = bool(ADDON.getSetting("arl").strip()) or bool(_read_arl_file()) \
        or bool(ADDON.getSetting("mail").strip() and ADDON.getSetting("password"))
    if has_own:
        log("first_start: eigene Zugangsdaten vorhanden, keine Anleitung")
        _mark_first_start_done()
        return False
    log("first_start: oeffne Anleitungsmenue")
    _mark_first_start_done()
    return True


def _open_guide_menu():
    xbmc.sleep(300)
    xbmc.executebuiltin(f"Container.Update({url_for(action='guide')})")


def show_root():
    if not ADDON.getSetting("arl").strip():
        _ensure_arl_file()
    open_guide = _first_start_guide()
    arl, _ = _resolve_arl()
    dz = get_api() if arl else None
    if not dz:
        log("show_root: kein Login moeglich, zeige Anleitung")
        add_dir(t("guide_label"), {"action": "guide"})
        add_dir(ADDON.getLocalizedString(32038), {"action": "settings"}, is_folder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        if open_guide:
            _open_guide_menu()
        return
    log("show_root")
    if _arl_source not in ("settings", "file"):
        add_dir(t("guide_label"), {"action": "guide"})
    add_dir(ADDON.getLocalizedString(32039), {"action": "flow"})
    add_dir(t("explore"), {"action": "explore"})
    add_dir(t("categories"), {"action": "categories"})
    add_dir(ADDON.getLocalizedString(32020), {"action": "my_music"})
    add_dir(ADDON.getLocalizedString(32021), {"action": "search"})
    add_dir(ADDON.getLocalizedString(32038), {"action": "settings"}, is_folder=False)
    xbmcplugin.endOfDirectory(HANDLE)
    if open_guide:
        _open_guide_menu()


def show_my_music():
    log("show_my_music")
    add_dir(ADDON.getLocalizedString(32022), {"action": "favorite_tracks"})
    add_dir(ADDON.getLocalizedString(32023), {"action": "playlists"})
    add_dir(ADDON.getLocalizedString(32024), {"action": "favorite_albums"})
    add_dir(ADDON.getLocalizedString(32025), {"action": "favorite_artists"})
    add_dir(t("deezer_favorites"), {"action": "my_favorites"})
    xbmcplugin.endOfDirectory(HANDLE)


def show_favorite_tracks():
    dz = get_api()
    if not dz:
        return
    log("show_favorite_tracks")
    quality = _quality()
    data = dz.get_favorite_tracks()
    tracks = data.get("data", [])
    log(f"  {len(tracks)} tracks geladen")
    add_track_list(tracks, "favtracks", quality)
    xbmcplugin.endOfDirectory(HANDLE)


def _pl_load():
    try:
        with open(_PLAYLISTS_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return [x for x in data if isinstance(x, dict) and x.get("id") and isinstance(x.get("tracks"), list)]
    except (FileNotFoundError, ValueError, OSError):
        return []


def _pl_save(items):
    try:
        os.makedirs(_PROFILE_DIR, exist_ok=True)
        with open(_PLAYLISTS_FILE, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False)
        return True
    except OSError as e:
        log(f"_pl_save Fehler: {e}", xbmc.LOGWARNING)
        return False


def _pl_find(items, pl_id):
    for i, x in enumerate(items):
        if x["id"] == pl_id:
            return i
    return -1


def _pl_ask_name(default=""):
    kb = xbmc.Keyboard(default, t("pl_name_prompt"))
    kb.doModal()
    if not kb.isConfirmed():
        return ""
    return kb.getText().strip()


def _pl_create(name):
    items = _pl_load()
    pl = {"id": uuid.uuid4().hex[:12], "name": name, "tracks": []}
    items.append(pl)
    _pl_save(items)
    return pl["id"]


def _move(seq, idx, direction):
    new = idx - 1 if direction == "up" else idx + 1
    if idx < 0 or new < 0 or new >= len(seq) or idx >= len(seq):
        return False
    seq[idx], seq[new] = seq[new], seq[idx]
    return True


def pl_new():
    name = _pl_ask_name()
    if not name:
        return
    _pl_create(name)
    xbmc.executebuiltin("Container.Refresh")


def pl_rename(pl_id):
    items = _pl_load()
    i = _pl_find(items, pl_id)
    if i < 0:
        return
    name = _pl_ask_name(items[i]["name"])
    if not name or name == items[i]["name"]:
        return
    items[i]["name"] = name
    _pl_save(items)
    xbmc.executebuiltin("Container.Refresh")


def pl_delete(pl_id):
    items = _pl_load()
    i = _pl_find(items, pl_id)
    if i < 0:
        return
    if not xbmcgui.Dialog().yesno("Deezer", t("delete_playlist_q", items[i]["name"])):
        return
    del items[i]
    _pl_save(items)
    xbmc.executebuiltin("Container.Refresh")


def pl_move(pl_id, direction):
    items = _pl_load()
    if _move(items, _pl_find(items, pl_id), direction):
        _pl_save(items)
        xbmc.executebuiltin("Container.Refresh")


def pl_add(params):
    track_id = params.get("id", "")
    if not track_id:
        return
    entry = {
        "id": track_id,
        "title": params.get("title", ""),
        "artist": params.get("artist", ""),
        "album": params.get("album", ""),
        "pic": params.get("pic", ""),
        "duration": int(params.get("duration", 0) or 0),
    }
    items = _pl_load()
    if not items:
        name = _pl_ask_name()
        if not name:
            return
        _pl_create(name)
        items = _pl_load()
        target = len(items) - 1
    elif len(items) == 1:
        target = 0
    else:
        names = [t("new_playlist_plus")] + [f"{x['name']} ({len(x['tracks'])})" for x in items]
        choice = xbmcgui.Dialog().select(t("add_to_playlist"), names)
        if choice < 0:
            return
        if choice == 0:
            name = _pl_ask_name()
            if not name:
                return
            _pl_create(name)
            items = _pl_load()
            target = len(items) - 1
        else:
            target = choice - 1
    items[target]["tracks"].append(entry)
    if _pl_save(items):
        xbmcgui.Dialog().notification("Deezer", t("added_to", items[target]["name"]),
                                      xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().notification("Deezer", t("save_failed"), xbmcgui.NOTIFICATION_ERROR, 3000)


def pl_track_remove(pl_id, idx):
    items = _pl_load()
    i = _pl_find(items, pl_id)
    if i < 0:
        return
    tracks = items[i]["tracks"]
    if 0 <= idx < len(tracks):
        del tracks[idx]
        _pl_save(items)
        xbmc.executebuiltin("Container.Refresh")


def pl_track_move(pl_id, idx, direction):
    items = _pl_load()
    i = _pl_find(items, pl_id)
    if i < 0:
        return
    if _move(items[i]["tracks"], idx, direction):
        _pl_save(items)
        xbmc.executebuiltin("Container.Refresh")


def show_my_playlist(pl_id):
    items = _pl_load()
    i = _pl_find(items, pl_id)
    if i < 0:
        xbmcplugin.endOfDirectory(HANDLE, False)
        return
    quality = _quality()
    tracks = items[i]["tracks"]
    def menu_fn(idx, total):
        menu = []
        if idx > 0:
            menu.append((t("move_up"), "RunPlugin(" + url_for(action="pl_track_move", id=pl_id, idx=idx, dir="up") + ")"))
        if idx < total - 1:
            menu.append((t("move_down"), "RunPlugin(" + url_for(action="pl_track_move", id=pl_id, idx=idx, dir="down") + ")"))
        menu.append((t("remove_from_playlist"), "RunPlugin(" + url_for(action="pl_track_remove", id=pl_id, idx=idx) + ")"))
        return menu

    add_track_list([_entry_to_track(x) for x in tracks], "pl:" + pl_id, quality, menu_fn=menu_fn)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def show_playlists():
    add_dir(t("new_playlist"), {"action": "pl_new"}, is_folder=False,
            art=MENU_ART)
    local = _pl_load()
    for idx, pl in enumerate(local):
        menu = [
            (t("rename"), "RunPlugin(" + url_for(action="pl_rename", id=pl["id"]) + ")"),
        ]
        if idx > 0:
            menu.append((t("move_up"), "RunPlugin(" + url_for(action="pl_move", id=pl["id"], dir="up") + ")"))
        if idx < len(local) - 1:
            menu.append((t("move_down"), "RunPlugin(" + url_for(action="pl_move", id=pl["id"], dir="down") + ")"))
        menu.append((t("delete_playlist"), "RunPlugin(" + url_for(action="pl_delete", id=pl["id"]) + ")"))
        add_dir(f"{pl['name']} ({len(pl['tracks'])})", {"action": "pl_open", "id": pl["id"]},
                art=MENU_ART, menu=menu)

    playlists = []
    dz = get_api()
    if dz:
        try:
            data = dz.get_user_playlists()
            if isinstance(data, dict):
                playlists = data.get("TAB", {}).get("playlists", {}).get("data", [])
        except Exception as e:
            log(f"show_playlists Deezer Fehler: {e}", xbmc.LOGWARNING)
    log(f"  {len(playlists)} playlists geladen")
    for p in playlists:
        pid = str(p.get("PLAYLIST_ID", ""))
        title = p.get("TITLE", "?")
        nb = p.get("NB_SONG", 0)
        md5 = p.get("PLAYLIST_PICTURE", "")
        pic = f"{p.get('PICTURE_TYPE') or 'cover'}:{md5}" if md5 else ""
        cover = deezer_api.playlist_img_url(pic)
        add_dir(f"{title} ({nb})", {"action": "playlist", "id": pid},
                art={"thumb": cover, "icon": cover, "poster": cover},
                menu=_fav_add_menu("playlist", pid, title, pic=pic))
    xbmcplugin.endOfDirectory(HANDLE)


def show_playlist(playlist_id):
    dz = get_api()
    if not dz:
        return
    log(f"show_playlist id={playlist_id}")
    quality = _quality()
    data = dz.get_playlist(playlist_id)
    songs = data.get("SONGS", {}).get("data", [])
    log(f"  {len(songs)} songs geladen")
    add_track_list(songs, "dzpl:" + str(playlist_id), quality)
    xbmcplugin.endOfDirectory(HANDLE)


def show_favorite_albums():
    dz = get_api()
    if not dz:
        return
    log("show_favorite_albums")
    data = dz.get_favorite_albums()
    albums = []
    if isinstance(data, dict):
        albums = data.get("TAB", {}).get("albums", {}).get("data", [])
    log(f"  {len(albums)} alben geladen")
    for a in albums:
        aid = str(a.get("ALB_ID", ""))
        title = a.get("ALB_TITLE", "?")
        artist = a.get("ART_NAME", "")
        cover = deezer_api.cover_url(a.get("ALB_PICTURE", ""))
        add_dir(f"{artist} – {title}", {"action": "album", "id": aid},
                art={"thumb": cover, "icon": cover},
                info={"title": title, "artist": artist},
                menu=_fav_add_menu("album", aid, title, artist, pic=a.get("ALB_PICTURE", "")))
    xbmcplugin.endOfDirectory(HANDLE)


def show_album(album_id):
    dz = get_api()
    if not dz:
        return
    log(f"show_album id={album_id}")
    quality = _quality()
    data = dz.get_album(album_id)
    songs = data.get("SONGS", {}).get("data", [])
    log(f"  {len(songs)} songs geladen")
    add_track_list(songs, "album:" + str(album_id), quality)
    xbmcplugin.endOfDirectory(HANDLE)


def show_favorite_artists():
    dz = get_api()
    if not dz:
        return
    log("show_favorite_artists")
    try:
        data = dz.get_favorite_artists()
    except Exception as e:
        log(f"show_favorite_artists Fehler: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Deezer", ADDON.getLocalizedString(32037), xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.endOfDirectory(HANDLE, False)
        return
    artists = []
    if isinstance(data, dict):
        artists = data.get("TAB", {}).get("artists", {}).get("data", [])
    log(f"  {len(artists)} künstler geladen")
    for a in artists:
        aid = str(a.get("ART_ID", ""))
        name = a.get("ART_NAME", "?")
        img = deezer_api.artist_img_url(a.get("ART_PICTURE", ""))
        add_dir(name, {"action": "artist", "id": aid},
                art={"thumb": img, "icon": img, "fanart": img},
                menu=_fav_add_menu("artist", aid, name, pic=a.get("ART_PICTURE", "")))
    xbmcplugin.endOfDirectory(HANDLE)


def show_artist(artist_id):
    dz = get_api()
    if not dz:
        return
    log(f"show_artist id={artist_id}")
    quality = _quality()
    data = dz.get_artist(artist_id)
    top = data.get("TOP", {}).get("data", [])
    albums = data.get("ALBUMS", {}).get("data", [])
    log(f"  top={len(top)} alben={len(albums)}")
    add_dir(ADDON.getLocalizedString(32033) + f" ({len(top)})",
            {"action": "artist_top", "id": artist_id})
    for a in albums[:50]:
        aid = str(a.get("ALB_ID", ""))
        title = a.get("ALB_TITLE", "?")
        cover = deezer_api.cover_url(a.get("ALB_PICTURE", ""))
        year = (a.get("PHYSICAL_RELEASE_DATE", "") or "")[:4]
        label = f"{title} ({year})" if year else title
        add_dir(label, {"action": "album", "id": aid},
                art={"thumb": cover, "icon": cover},
                menu=_fav_add_menu("album", aid, title, pic=a.get("ALB_PICTURE", "")))
    xbmcplugin.endOfDirectory(HANDLE)


def show_artist_top(artist_id):
    dz = get_api()
    if not dz:
        return
    quality = _quality()
    data = dz.get_artist(artist_id)
    add_track_list(data.get("TOP", {}).get("data", []), "top:" + str(artist_id), quality)
    xbmcplugin.endOfDirectory(HANDLE)


def _fav_load():
    try:
        with open(_FAVORITES_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return [x for x in data if isinstance(x, dict) and x.get("kind") and x.get("id")]
    except (FileNotFoundError, ValueError, OSError):
        return []


def _fav_save(items):
    try:
        os.makedirs(_PROFILE_DIR, exist_ok=True)
        with open(_FAVORITES_FILE, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False)
        return True
    except OSError as e:
        log(f"_fav_save Fehler: {e}", xbmc.LOGWARNING)
        return False


def fav_add(params):
    kind = params.get("kind", "")
    item_id = params.get("id", "")
    if not kind or not item_id:
        return
    entry = {
        "kind": kind,
        "id": item_id,
        "title": params.get("title", ""),
        "artist": params.get("artist", ""),
        "album": params.get("album", ""),
        "pic": params.get("pic", ""),
        "duration": int(params.get("duration", 0) or 0),
    }
    items = [x for x in _fav_load() if not (x["kind"] == kind and str(x["id"]) == item_id)]
    items.insert(0, entry)
    saved = _fav_save(items)
    remote = False
    dz = get_api()
    if dz:
        try:
            dz.set_favorite(kind, item_id, True)
            remote = True
        except Exception as e:
            log(f"fav_add Deezer Fehler: {e}", xbmc.LOGWARNING)
    if saved and remote:
        msg = t("fav_added")
    elif saved:
        msg = t("saved_local")
    else:
        msg = t("save_failed")
    xbmcgui.Dialog().notification("Deezer", msg, xbmcgui.NOTIFICATION_INFO if saved else xbmcgui.NOTIFICATION_ERROR, 3000)


def fav_remove(kind, item_id):
    items = [x for x in _fav_load() if not (x["kind"] == kind and str(x["id"]) == str(item_id))]
    _fav_save(items)
    dz = get_api()
    if dz:
        try:
            dz.set_favorite(kind, item_id, False)
        except Exception as e:
            log(f"fav_remove Deezer Fehler: {e}", xbmc.LOGWARNING)
    xbmc.executebuiltin("Container.Refresh")


def show_my_favorites():
    items = _fav_load()
    for kind, label_key in _FAV_KINDS:
        count = sum(1 for x in items if x["kind"] == kind)
        add_dir(f"{t(label_key)} ({count})", {"action": "fav_list", "kind": kind})
    xbmcplugin.endOfDirectory(HANDLE)


def show_fav_list(kind):
    items = [x for x in _fav_load() if x["kind"] == kind]
    quality = _quality()
    if kind == "track":
        add_track_list([_entry_to_track(x) for x in items], "fav", quality, fav_remove=True)
    for x in items:
        item_id = str(x["id"])
        title = x.get("title", "?")
        artist = x.get("artist", "")
        pic = x.get("pic", "")
        menu = _fav_remove_menu(kind, item_id)
        if kind == "track":
            continue
        elif kind == "album":
            cover = deezer_api.cover_url(pic)
            label = f"{artist} – {title}" if artist else title
            add_dir(label, {"action": "album", "id": item_id},
                    art={"thumb": cover, "icon": cover}, menu=menu)
        elif kind == "artist":
            img = deezer_api.artist_img_url(pic)
            add_dir(title, {"action": "artist", "id": item_id},
                    art={"thumb": img, "icon": img, "fanart": img}, menu=menu)
        elif kind == "playlist":
            cover = deezer_api.playlist_img_url(pic)
            add_dir(title, {"action": "playlist", "id": item_id},
                    art={"thumb": cover, "icon": cover}, menu=menu)
    xbmcplugin.endOfDirectory(HANDLE)


def _history_load():
    try:
        with open(_HISTORY_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return [str(x) for x in data if str(x).strip()]
    except (FileNotFoundError, ValueError, OSError):
        return []


def _history_save(items):
    try:
        os.makedirs(_PROFILE_DIR, exist_ok=True)
        with open(_HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(items[:_HISTORY_MAX], f, ensure_ascii=False)
    except OSError as e:
        log(f"_history_save Fehler: {e}", xbmc.LOGWARNING)


def _history_add(query):
    items = [x for x in _history_load() if x.lower() != query.lower()]
    items.insert(0, query)
    _history_save(items)


def _history_remove(query):
    _history_save([x for x in _history_load() if x != query])


def show_search():
    add_dir(t("new_search"), {"action": "search_new"}, art=MENU_ART)
    for term in _history_load():
        li = xbmcgui.ListItem(term)
        li.setArt(MENU_ART)
        li.addContextMenuItems([
            (t("edit"), "RunPlugin(" + url_for(action="search_edit", query=term) + ")"),
            (t("delete"), "RunPlugin(" + url_for(action="search_delete", query=term) + ")"),
            (t("clear_history"), "RunPlugin(" + url_for(action="search_clear") + ")"),
        ])
        xbmcplugin.addDirectoryItem(HANDLE, url_for(action="search_results", query=term), li, True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_search_new():
    kb = xbmc.Keyboard("", ADDON.getLocalizedString(32032))
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE, False)
        return
    query = kb.getText().strip()
    log(f"show_search_new query={query!r}")
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, False)
        return
    show_search_results(query)


def search_edit(query):
    kb = xbmc.Keyboard(query, "Suchbegriff bearbeiten")
    kb.doModal()
    if not kb.isConfirmed():
        return
    new = kb.getText().strip()
    if not new or new == query:
        return
    items = _history_load()
    items = [x for x in items if x.lower() != new.lower()]
    try:
        idx = _history_load().index(query)
    except ValueError:
        idx = 0
    items = [x for x in items if x != query]
    items.insert(min(idx, len(items)), new)
    _history_save(items)
    xbmc.executebuiltin("Container.Refresh")


def search_delete(query):
    _history_remove(query)
    xbmc.executebuiltin("Container.Refresh")


def search_clear():
    if xbmcgui.Dialog().yesno("Deezer", t("clear_history_q")):
        _history_save([])
        xbmc.executebuiltin("Container.Refresh")


def show_search_results(query):
    dz = get_api()
    if not dz:
        return
    log(f"show_search_results query={query!r}")
    _history_add(query)
    quality = _quality()
    data = dz.search(query)
    tracks = data.get("TRACK", {}).get("data", [])
    albums = data.get("ALBUM", {}).get("data", [])
    artists = data.get("ARTIST", {}).get("data", [])
    playlists = data.get("PLAYLIST", {}).get("data", [])
    log(f"  tracks={len(tracks)} alben={len(albums)} künstler={len(artists)} playlists={len(playlists)}")
    if artists:
        add_dir(f"── {ADDON.getLocalizedString(32035)} ({len(artists)}) ──",
                {"action": "search_results", "query": query}, is_folder=False)
        for a in artists[:5]:
            aid = str(a.get("ART_ID", ""))
            name = a.get("ART_NAME", "?")
            img = deezer_api.artist_img_url(a.get("ART_PICTURE", ""))
            add_dir(name, {"action": "artist", "id": aid},
                    art={"thumb": img, "icon": img},
                    menu=_fav_add_menu("artist", aid, name, pic=a.get("ART_PICTURE", "")))
    if albums:
        add_dir(f"── {ADDON.getLocalizedString(32034)} ({len(albums)}) ──",
                {"action": "search_results", "query": query}, is_folder=False)
        for a in albums[:10]:
            aid = str(a.get("ALB_ID", ""))
            title = a.get("ALB_TITLE", "?")
            artist = a.get("ART_NAME", "")
            cover = deezer_api.cover_url(a.get("ALB_PICTURE", ""))
            add_dir(f"{artist} – {title}", {"action": "album", "id": aid},
                    art={"thumb": cover, "icon": cover},
                    menu=_fav_add_menu("album", aid, title, artist, pic=a.get("ALB_PICTURE", "")))
    if tracks:
        add_dir(f"── {ADDON.getLocalizedString(32033)} ({len(tracks)}) ──",
                {"action": "search_results", "query": query}, is_folder=False)
        add_track_list(tracks[:30], "search", quality)
    xbmcplugin.endOfDirectory(HANDLE)


def show_flow(page=0):
    dz = get_api()
    if not dz:
        return
    log(f"show_flow page={page}")
    quality = _quality()
    data = dz.get_flow(100)
    raw = data.get("data", []) if isinstance(data, dict) else []
    seen = set()
    tracks = []
    for track in raw:
        sid = track.get("SNG_ID")
        if sid and sid not in seen:
            seen.add(sid)
            tracks.append(track)
    log(f"  {len(tracks)} tracks geladen")
    key = "flow" if page == 0 else f"flow{page}"
    add_track_list(tracks, key, quality)
    add_dir(t("more_recs"), {"action": "flow", "page": page + 1})
    xbmcplugin.endOfDirectory(HANDLE)


def _playback_allowed(dz):
    if ADDON.getSettingBool("deezer_stat"):
        return True
    return bool(dz.can_stream)


def _deny_playback():
    home = xbmcgui.Window(10000)
    now = time.time()
    try:
        last = float(home.getProperty("deezer_denied_ts") or 0)
    except ValueError:
        last = 0
    if now - last > 15:
        xbmcgui.Dialog().notification("Deezer", ADDON.getLocalizedString(32049), xbmcgui.NOTIFICATION_WARNING, 5000)
    home.setProperty("deezer_denied_ts", str(now))
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def _fail(msg=None):
    xbmc.Player().stop()
    if msg:
        xbmcgui.Dialog().notification("Deezer", msg, xbmcgui.NOTIFICATION_ERROR, 4000)
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def _cleanup_tmp(keep):
    tmp_dir = xbmcvfs.translatePath("special://temp")
    try:
        for name in os.listdir(tmp_dir):
            if name.startswith("deezer_") and (name.endswith(".mp3") or name.endswith(".mp4") or name.endswith(".part")) and name != keep:
                try:
                    os.remove(os.path.join(tmp_dir, name))
                except OSError:
                    pass
    except OSError:
        pass


def play_track(track_id, quality="MP3_128"):
    log(f"play_track id={track_id} quality={quality}")
    try:
        _play_track(track_id, quality)
    except Exception as e:
        log(f"play_track Fehler: {type(e).__name__}: {e}", xbmc.LOGERROR)
        xbmc.log(f"[plugin.video.deezer] play_track Fehler: {type(e).__name__}: {e}", xbmc.LOGERROR)
        _fail(ADDON.getLocalizedString(32037))


def _play_track(track_id, quality):
    dz = get_api()
    if not dz:
        _fail()
        return
    if not _playback_allowed(dz):
        _deny_playback()
        return
    track = dz.get_track_info(track_id)
    if not track:
        _fail(ADDON.getLocalizedString(32037))
        return
    track_token = track.get("TRACK_TOKEN", "")
    if not track_token:
        log("play_track: kein TRACK_TOKEN", xbmc.LOGERROR)
        _fail(ADDON.getLocalizedString(32037))
        return

    stream_url, no_premium = dz.get_stream_url(
        track_token, quality, track.get("MD5_ORIGIN", ""), track_id, track.get("MEDIA_VERSION", "1"))
    if not stream_url:
        if no_premium:
            xbmcgui.Dialog().ok("Deezer", ADDON.getLocalizedString(32049))
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        else:
            _fail(ADDON.getLocalizedString(32037))
        return

    name = f"deezer_{track_id}.mp4"
    tmp_path = os.path.join(xbmcvfs.translatePath("special://temp"), name)
    _cleanup_tmp(name)

    monitor = xbmc.Monitor()
    dialog = xbmcgui.DialogProgress()
    dialog.create("Deezer", "Lade Track...")

    def on_progress(done, total):
        if total:
            dialog.update(min(99, int(done * 100 / total)), "Lade Track...")
        return dialog.iscanceled()

    ok = False
    try:
        proxy.decrypt_to_file(stream_url, track_id, tmp_path, progress=on_progress, monitor=monitor)
        ok = True
    except Exception as e:
        log(f"decrypt_to_file Fehler: {type(e).__name__}: {e}", xbmc.LOGERROR)
    finally:
        dialog.close()

    if not ok:
        _fail(t("download_failed"))
        return

    title = track.get("SNG_TITLE", "")
    artist = track.get("ART_NAME", "")
    album = track.get("ALB_TITLE", "")
    thumb = deezer_api.cover_url(track.get("ALB_PICTURE", ""))
    duration = int(track.get("DURATION", 0) or 0)
    cover = thumb
    li = xbmcgui.ListItem(f"{artist} – {title}", path=tmp_path)
    _set_info(li, _video_info(title, artist, album, duration))
    li.setArt({"thumb": cover, "icon": cover, "poster": cover, "fanart": cover})
    li.setMimeType("video/mp4")
    li.setContentLookup(False)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def _quality():
    idx = int(ADDON.getSetting("quality") or 0)
    return ["MP3_128", "MP3_320", "FLAC"][idx]


def main():
    params = dict(parse_qsl(urlparse(sys.argv[2]).query))
    router(params)


if __name__ == "__main__":
    main()
