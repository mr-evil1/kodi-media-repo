import os
import re
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.deezer"
CORE_FILE = "special://profile/playercorefactory.xml"


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)


def _download_dir():
    addon = xbmcaddon.Addon(ADDON_ID)
    path = addon.getSetting("download_path").strip()
    if not path:
        path = xbmcvfs.translatePath("special://home/downloads")
    return path


def _wanted_rules():
    dl = re.escape(_download_dir().rstrip("/\\"))
    return {
        "deezer-temp": {"filename": r".*[/\\]deezer_[^/\\]*"},
        "deezer-downloads": {"filename": dl + r"[/\\].*"},
    }


def _indent(elem, level=0):
    pad = "\n" + level * "  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = pad + "  "
        for child in elem:
            _indent(child, level + 1)
            if not child.tail or not child.tail.strip():
                child.tail = pad + "  "
        if not child.tail or not child.tail.strip():
            child.tail = pad
    if level and (not elem.tail or not elem.tail.strip()):
        elem.tail = pad


def ensure_player_rules():
    path = xbmcvfs.translatePath(CORE_FILE)
    existed = os.path.exists(path)
    if existed:
        try:
            tree = ET.parse(path)
            root = tree.getroot()
        except (ET.ParseError, OSError) as e:
            _log(f"playercorefactory.xml nicht lesbar: {e}", xbmc.LOGWARNING)
            return False
        if root.tag != "playercorefactory":
            _log("playercorefactory.xml hat unerwartetes Format", xbmc.LOGWARNING)
            return False
    else:
        root = ET.Element("playercorefactory")
        tree = ET.ElementTree(root)

    rules = None
    for r in root.findall("rules"):
        if r.get("action", "").lower() == "prepend":
            rules = r
            break
    if rules is None:
        rules = ET.Element("rules", {"action": "prepend"})
        root.insert(0, rules)

    changed = False
    for name, attrs in _wanted_rules().items():
        rule = None
        for r in rules.findall("rule"):
            if r.get("name") == name:
                rule = r
                break
        if rule is None:
            rule = ET.Element("rule", {"name": name})
            rules.insert(0, rule)
            changed = True
        for k, v in attrs.items():
            if rule.get(k) != v:
                rule.set(k, v)
                changed = True
        if rule.get("player") != "paplayer":
            rule.set("player", "paplayer")
            changed = True

    if not changed:
        return False
    _indent(root)
    try:
        tree.write(path, encoding="utf-8", xml_declaration=True)
    except OSError as e:
        _log(f"playercorefactory.xml nicht schreibbar: {e}", xbmc.LOGERROR)
        return False
    _log("playercorefactory.xml geschrieben")
    return True


class DeezerPlayer(xbmc.Player):
    def _is_deezer(self):
        try:
            path = self.getPlayingFile()
        except RuntimeError:
            return False
        resolved = xbmcgui.Window(10000).getProperty("deezer_resolved")
        if resolved and resolved == path:
            return True
        return ADDON_ID in path or os.path.basename(path).startswith("deezer_")

    def onAVStarted(self):
        if not self.isPlayingAudio() or not self._is_deezer():
            return
        if xbmc.getCondVisibility("Window.IsActive(visualisation)"):
            return
        xbmc.executebuiltin("ActivateWindow(visualisation)")


class SettingsMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self._path = None

    def sync(self, prompt=True):
        try:
            current = _download_dir()
            if current == self._path:
                return
            self._path = current
            if ensure_player_rules() and prompt:
                if xbmcgui.Dialog().yesno("Deezer", "Player-Regeln wurden an den Download-Pfad angepasst. Kodi jetzt neu starten?"):
                    xbmc.executebuiltin("RestartApp")
        except Exception as e:
            _log(f"sync Fehler: {type(e).__name__}: {e}", xbmc.LOGERROR)

    def onSettingsChanged(self):
        self.sync()


def main():
    monitor = SettingsMonitor()
    monitor.sync()
    player = DeezerPlayer()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
    del player


main()
