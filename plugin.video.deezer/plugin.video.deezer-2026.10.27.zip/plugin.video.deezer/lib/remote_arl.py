import os
import re
import hmac
import base64
import hashlib
import urllib.request

import crypto

_FILE_NAME = "cache.dat"
_SALT = b"plugin.video.deezer|remote_arl|v1"
_VALID = re.compile(r"^[A-Za-z0-9_\-]{32,300}$")

def _keys(profile_dir):
    base = hashlib.sha256(_SALT + profile_dir.encode("utf-8")).digest()
    return base[:16], hashlib.sha256(base + b"mac").digest()


def _ctr(key, nonce, data):
    out = bytearray()
    for i in range(0, len(data), 16):
        counter = nonce[:8] + (int.from_bytes(nonce[8:], "big") + i // 16).to_bytes(8, "big")
        stream = crypto.aes128_ecb_encrypt(key, counter)
        chunk = data[i:i + 16]
        out.extend(b ^ s for b, s in zip(chunk, stream))
    return bytes(out)


def _encrypt(profile_dir, text):
    enc_key, mac_key = _keys(profile_dir)
    nonce = os.urandom(16)
    body = _ctr(enc_key, nonce, text.encode("utf-8"))
    tag = hmac.new(mac_key, nonce + body, hashlib.sha256).digest()[:16]
    return base64.b64encode(nonce + body + tag)


def _decrypt(profile_dir, blob):
    raw = base64.b64decode(blob)
    if len(raw) < 33:
        return ""
    enc_key, mac_key = _keys(profile_dir)
    nonce, body, tag = raw[:16], raw[16:-16], raw[-16:]
    expected = hmac.new(mac_key, nonce + body, hashlib.sha256).digest()[:16]
    if not hmac.compare_digest(tag, expected):
        return ""
    return _ctr(enc_key, nonce, body).decode("utf-8")


def _path(profile_dir, url=""):
    if url:
        return os.path.join(profile_dir, "cache_" + hashlib.sha1(url.encode("utf-8")).hexdigest()[:10] + ".dat")
    return os.path.join(profile_dir, _FILE_NAME)


def load_stored(profile_dir, url=""):
    try:
        with open(_path(profile_dir, url), "rb") as f:
            return _decrypt(profile_dir, f.read()).strip()
    except Exception:
        return ""


def store(profile_dir, arl, url=""):
    try:
        os.makedirs(profile_dir, exist_ok=True)
        with open(_path(profile_dir, url), "wb") as f:
            f.write(_encrypt(profile_dir, arl))
        return True
    except Exception:
        return False


def store_blob(profile_dir, name, text):
    try:
        os.makedirs(profile_dir, exist_ok=True)
        with open(os.path.join(profile_dir, name), "wb") as f:
            f.write(_encrypt(profile_dir, text))
        return True
    except Exception:
        return False


def load_blob(profile_dir, name):
    try:
        with open(os.path.join(profile_dir, name), "rb") as f:
            return _decrypt(profile_dir, f.read())
    except Exception:
        return ""


def delete_blob(profile_dir, name):
    try:
        os.remove(os.path.join(profile_dir, name))
    except OSError:
        pass


def fetch_remote(timeout=10, url=""):
    target = (url or "").strip()
    if not target.lower().startswith(("http://", "https://")):
        return ""
    try:
        req = urllib.request.Request(target, headers={"User-Agent": "Mozilla/5.0", "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            text = resp.read().decode("utf-8", "ignore").strip()
    except Exception:
        return ""
    text = text.strip("\"'` \t\r\n")
    if not _VALID.match(text):
        return ""
    return text


def refresh(profile_dir, url=""):
    arl = fetch_remote(url=url)
    if arl:
        store(profile_dir, arl, url)
    return arl


def clear_legacy_flag(profile_dir):
    for name in ("remote_arl.disabled", "remote_arl.bin", "remote_arl_r13.bin"):
        try:
            os.remove(os.path.join(profile_dir, name))
        except OSError:
            pass


def get(profile_dir, url=""):
    clear_legacy_flag(profile_dir)
    arl = load_stored(profile_dir, url)
    if arl:
        return arl
    return refresh(profile_dir, url)
