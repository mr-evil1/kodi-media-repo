import xbmc


def lang():
    try:
        code = xbmc.getLanguage(xbmc.ISO_639_1).lower()
    except Exception:
        code = "en"
    return "de" if code.startswith("de") else "en"


_S = {
    "guide_label": ("Nicht Angemeldet, Hier zur Anleitung", "Not logged in, tap here for the guide"),
    "guide_mail_item": ("Anleitung: Login mit E-Mail und Passwort", "Guide: Login with email and password"),
    "register_item": ("Neues Deezer-Konto erstellen", "Create a new Deezer account"),
    "register_title": ("Neues Deezer-Konto erstellen", "Create a new Deezer account"),
    "register_text": (
        "Öffne diese Adresse in einem Browser und lege dort dein Konto an:\n\n{url}\n\nDanach trägst du E-Mail und Passwort in den Addon-Einstellungen ein.",
        "Open this address in a browser and create your account there:\n\n{url}\n\nThen enter your email and password in the add-on settings.",
    ),
    "guide_arl_item": ("Anleitung: Login mit ARL", "Guide: Login with ARL"),
    "guide_mail_title": ("Anleitung: E-Mail und Passwort", "Guide: Email and password"),
    "guide_arl_title": ("Anleitung: ARL", "Guide: ARL"),
    "invalid_arl": ("Ungültige ARL", "Invalid ARL"),
    "explore": ("Entdecken", "Explore"),
    "charts": ("Charts", "Charts"),
    "genres": ("Genres", "Genres"),
    "chart_tracks": ("Top Titel", "Top Tracks"),
    "chart_playlists": ("Top Playlists", "Top Playlists"),
    "chart_albums": ("Top Alben", "Top Albums"),
    "chart_artists": ("Top Künstler*innen", "Top Artists"),
    "categories": ("Kategorien", "Categories"),
    "cat_kategorien": ("Kategorien", "Categories"),
    "cat_genres": ("Genres", "Genres"),
    "cat_podcasts": ("Podcasts nach Kategorie", "Podcasts by Category"),
    "cat_audiobooks": ("Hörbücher", "Audiobooks"),
    "channel_empty": ("Keine Inhalte in dieser Kategorie gefunden", "No content found in this category"),
    "arl_url_download_failed": (
        "Der ARL-Download von der eingetragenen URL ist fehlgeschlagen. Bitte die URL in den Einstellungen prüfen.",
        "The ARL download from the entered URL failed. Please check the URL in the settings.",
    ),
    "arl_url_login_failed": (
        "Die von der eingetragenen URL geladene ARL ist ungültig oder der Login ist fehlgeschlagen. Bitte die URL in den Einstellungen prüfen.",
        "The ARL downloaded from the entered URL is invalid or the login failed. Please check the URL in the settings.",
    ),
    "mail_login_failed": (
        "Login mit E-Mail und Passwort fehlgeschlagen. Bitte Eingaben prüfen oder die ARL manuell eintragen.",
        "Login with email and password failed. Please check your input or enter the ARL manually.",
    ),
    "list_unavailable": ("Liste nicht mehr verfügbar, bitte neu öffnen", "List no longer available, please reopen it"),
    "save_failed": ("Speichern fehlgeschlagen", "Saving failed"),
    "delete_playlist_q": ("Playlist \"{}\" löschen?", "Delete playlist \"{}\"?"),
    "added_to": ("Zu \"{}\" hinzugefügt", "Added to \"{}\""),
    "pl_name_prompt": ("Name der Playlist", "Playlist name"),
    "new_playlist_plus": ("+ Neue Playlist", "+ New playlist"),
    "new_playlist": ("Neue Playlist anlegen", "Create new playlist"),
    "add_to_playlist": ("Zu Playlist hinzufügen", "Add to playlist"),
    "fav_add": ("Zu Deezer-Favoriten hinzufügen", "Add to Deezer favorites"),
    "fav_remove": ("Aus Favoriten entfernen", "Remove from favorites"),
    "fav_added": ("Zu Deezer-Favoriten hinzugefügt", "Added to Deezer favorites"),
    "saved_local": ("Lokal gespeichert (Deezer-Konto nicht erreicht)", "Saved locally (Deezer account not reached)"),
    "new_search": ("Neue Suche", "New search"),
    "clear_history_q": ("Gesamten Suchverlauf löschen?", "Delete entire search history?"),
    "edit": ("Bearbeiten", "Edit"),
    "delete": ("Löschen", "Delete"),
    "clear_history": ("Verlauf löschen", "Clear history"),
    "more_recs": ("Weitere Empfehlungen laden  >>", "Load more recommendations  >>"),
    "move_up": ("Nach oben", "Move up"),
    "move_down": ("Nach unten", "Move down"),
    "remove_from_playlist": ("Aus Playlist entfernen", "Remove from playlist"),
    "rename": ("Umbenennen", "Rename"),
    "delete_playlist": ("Playlist löschen", "Delete playlist"),
    "deezer_favorites": ("Deezer Favoriten", "Deezer favorites"),
    "download_failed": ("Download fehlgeschlagen", "Download failed"),
    "download_track": ("Track herunterladen", "Download track"),
    "downloading": ("Wird heruntergeladen...", "Downloading..."),
    "download_done": ("Download abgeschlossen:", "Download complete:"),
    "download_path_browse": ("Download-Ordner wählen", "Select download folder"),
    "download_path_kodi": ("Kodi-interner Ordner (standard)", "Kodi internal folder (default)"),
    "download_path_device": ("Geräte-Downloadordner: {}", "Device download folder: {}"),
    "download_path_manual_browse": ("Ordner manuell auswählen...", "Browse manually..."),
    "download_path_set": ("Download-Pfad gesetzt: {}", "Download path set: {}"),
    "downloads": ("Downloads", "Downloads"),
    "downloads_empty": ("Keine Downloads vorhanden", "No downloads found"),
    "delete_download": ("Download löschen", "Delete download"),
    "delete_download_q": ("\"{}\" löschen?", "Delete \"{}\"?"),
    "delete_download_done": ("Datei gelöscht", "File deleted"),
    "kind_track": ("Tracks", "Tracks"),
    "kind_album": ("Alben", "Albums"),
    "kind_artist": ("Künstler", "Artists"),
    "kind_playlist": ("Playlists", "Playlists"),
}


def t(key, *args):
    de, en = _S[key]
    text = de if lang() == "de" else en
    return text.format(*args) if args else text


ARL_GUIDE_EN = (
    "How to get your Deezer ARL:\n\n"
    "Preparation\n"
    "1. On a computer, open https://www.deezer.com and log in with your Deezer account. Keep the page open afterwards.\n\n"
    "Google Chrome / Microsoft Edge\n"
    "2. Press F12 (or Ctrl+Shift+I). The developer tools open on the right or at the bottom.\n"
    "3. In the bar at the top of the developer tools, click the \"Application\" tab. "
    "If it is not visible, click the two arrows \">>\" at the end of the bar and choose it there.\n"
    "4. In the left sidebar under \"Storage\", click the small arrow in front of \"Cookies\" to expand it.\n"
    "5. Click \"https://www.deezer.com\" below it. A table with the columns Name, Value, Domain and so on appears on the right.\n"
    "6. In the \"Name\" column, find the row \"arl\". Tip: type arl into the \"Filter cookies\" field at the top.\n"
    "7. Click the row \"arl\". The full value is shown at the bottom of the window. "
    "Click into the value, select everything with Ctrl+A and copy with Ctrl+C. "
    "Alternatively, double-click the \"Value\" column in the table, then Ctrl+A, Ctrl+C.\n\n"
    "Mozilla Firefox\n"
    "2. Press F12. Select the \"Storage\" tab at the top, or use the arrows \">>\" if it is hidden.\n"
    "3. Expand \"Cookies\" on the left and click \"https://www.deezer.com\".\n"
    "4. Click the row \"arl\". The value appears in the detail pane on the right. Select the value (Ctrl+A) and copy it (Ctrl+C).\n\n"
    "Check\n"
    "The ARL is a long string of letters and numbers with about 192 characters. If it is much shorter, you did not copy the right value.\n\n"
    "Enter it in Kodi\n"
    "8. Open add-on settings > Account > ARL Token, paste the value and confirm with OK. No spaces and no quotation marks.\n\n"
    "Android only: ARL via file\n"
    "Instead of typing the ARL into Kodi, you can paste it into a file. The add-on creates the empty file automatically on start:\n"
    "9. Open your device's file manager and go to the Download folder (/storage/emulated/0/Download).\n"
    "10. Open the file arl.txt there with a text editor.\n"
    "11. Paste the copied ARL as the only content, without spaces or quotation marks, and save.\n"
    "12. Restart the add-on. It reads the file automatically.\n"
    "The file is only used if it contains a valid ARL. An entry in the add-on settings always takes priority.\n"
    "If the file is not created or read, check in Android settings under Apps > Kodi > Permissions whether Kodi has access to files and media or storage.\n\n"
    "Note: The ARL is like a password. Never share it. If you log out of Deezer, it becomes invalid and you need to get a new one."
)

MAIL_GUIDE_EN = (
    "How to log in with email and password:\n\n"
    "1. Open the add-on settings. You find them in the add-on's main menu under \"Settings\" or via the add-on's context menu.\n\n"
    "2. Go to the \"Account\" category.\n\n"
    "3. Enter the email address of your Deezer account in the \"Email\" field.\n\n"
    "4. Enter your Deezer password in the \"Password\" field. The input is hidden.\n\n"
    "5. Confirm with OK and close the settings.\n\n"
    "6. Open the add-on again. It logs in automatically, fetches the ARL and enters it into the \"ARL Token\" field itself.\n\n"
    "7. After a successful login, the password is removed from the settings and stored encrypted inside the add-on.\n\n"
    "Notes\n"
    "You only need to log in once. If the ARL expires at some point, the add-on logs in again with the stored password and renews it automatically.\n"
    "If you log in to Deezer with Facebook, Google or Apple, you have no password. Use the ARL guide instead.\n"
    "If a message says the login failed, check your email and password or use the ARL guide."
)
