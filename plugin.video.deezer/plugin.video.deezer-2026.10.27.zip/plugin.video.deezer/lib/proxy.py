import hashlib
import http.server
import threading
import urllib.request
import urllib.error
import urllib.parse
import os
import json
import socket

import xbmcvfs


_SECRET = "g4el58wc0zvf9na1"
_DEFAULT_PORT = 9876
_lock = threading.Lock()
_active_port = None

_TEMP_DIR = xbmcvfs.translatePath("special://temp/")
_PORT_FILE = os.path.join(_TEMP_DIR, "deezer_proxy.port")
_ROUTES_FILE = os.path.join(_TEMP_DIR, "deezer_proxy_routes.json")

_log = None


def set_logger(fn):
    global _log
    _log = fn


def _l(msg):
    if _log:
        _log("[proxy] " + msg)


def _resolve_url(url):
    parsed = urllib.parse.urlparse(url)
    return url, parsed.hostname


def _bf_key(track_id):
    h = hashlib.md5(str(track_id).encode()).hexdigest()
    return bytes(ord(h[i]) ^ ord(h[i + 16]) ^ ord(_SECRET[i]) for i in range(16))


_IV = b"\x00\x01\x02\x03\x04\x05\x06\x07"


def _make_decryptor(key):
    try:
        try:
            from Cryptodome.Cipher import Blowfish
        except ImportError:
            from Crypto.Cipher import Blowfish
        return lambda block: Blowfish.new(key, Blowfish.MODE_CBC, _IV).decrypt(block)
    except ImportError:
        import crypto
        bf = crypto._Blowfish(key)
        return lambda block: bf.decrypt_cbc(_IV, block)


def _open_stream(url, timeout):
    req = urllib.request.Request(url, headers={
        "User-Agent": "Deezer/9.0.14.8 (Android; 6.0.1; Tablet; de) samsung SM-G980F/DS",
        "Accept": "*/*",
    })
    return urllib.request.urlopen(req, timeout=timeout)


def _decrypt_stream(url, track_id, out):
    decrypt = _make_decryptor(_bf_key(track_id))
    with _open_stream(url, 30) as resp:
        index = 0
        buf = b""
        while True:
            chunk = resp.read(65536)
            if not chunk:
                break
            buf += chunk
            while len(buf) >= 2048:
                block = buf[:2048]
                buf = buf[2048:]
                if index % 3 == 0:
                    block = decrypt(block)
                out.write(block)
                index += 1
        if buf:
            out.write(buf)


def _read_routes():
    try:
        with open(_ROUTES_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def _write_route(token, url, track_id):
    with _lock:
        routes = _read_routes()
        routes[token] = [url, str(track_id)]
        with open(_ROUTES_FILE, "w") as f:
            json.dump(routes, f)


class _Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        path = self.path.lstrip("/")
        if path == "_ping":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")
            return
        routes = _read_routes()
        entry = routes.get(path)
        _l(f"GET /{path} → {'found' if entry else 'NOT FOUND'} (routes: {list(routes.keys())})")
        if not entry:
            self.send_response(404)
            self.end_headers()
            return
        url, track_id = entry
        self.send_response(200)
        self.send_header("Content-Type", "audio/mpeg")
        self.send_header("Connection", "close")
        self.end_headers()
        try:
            _decrypt_stream(url, track_id, self.wfile)
        except urllib.error.HTTPError as e:
            _l(f"decrypt_stream HTTPError {e.code}: {e.reason}")
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            _l(f"decrypt_stream error: {type(e).__name__}: {e}")


def _port_alive(port):
    try:
        conn = socket.create_connection(("127.0.0.1", port), timeout=0.3)
        conn.close()
        return True
    except OSError:
        return False


def _read_port_file():
    try:
        with open(_PORT_FILE) as f:
            return int(f.read().strip())
    except Exception:
        return None


def _write_port_file(port):
    try:
        with open(_PORT_FILE, "w") as f:
            f.write(str(port))
    except Exception:
        pass


def start():
    global _active_port

    saved = _read_port_file()
    if saved and _port_alive(saved):
        _active_port = saved
        _l(f"reusing existing proxy on port {saved}")
        return

    for port in range(_DEFAULT_PORT, _DEFAULT_PORT + 20):
        try:
            srv = http.server.HTTPServer(("127.0.0.1", port), _Handler)
            _active_port = port
            _write_port_file(port)
            _l(f"started proxy on port {port}")
            t = threading.Thread(target=srv.serve_forever, daemon=True)
            t.start()
            return
        except OSError:
            continue

    raise OSError("Kein freier Port für Deezer-Proxy gefunden")


def decrypt_to_file(url, track_id, dest_path, progress=None, monitor=None):
    decrypt = _make_decryptor(_bf_key(track_id))
    tmp_path = dest_path + ".part"
    with _open_stream(url, 60) as resp:
        total = int(resp.headers.get("content-length") or 0)
        done = 0
        index = 0
        buf = b""
        with open(tmp_path, "wb") as out:
            while True:
                if monitor and monitor.abortRequested():
                    raise IOError("abgebrochen")
                if progress and progress(done, total):
                    raise IOError("abgebrochen")
                chunk = resp.read(65536)
                if not chunk:
                    break
                done += len(chunk)
                buf += chunk
                while len(buf) >= 2048:
                    block = buf[:2048]
                    buf = buf[2048:]
                    if index % 3 == 0:
                        block = decrypt(block)
                    out.write(block)
                    index += 1
            if buf:
                out.write(buf)
    if os.path.getsize(tmp_path) < 4096:
        with open(tmp_path, "rb") as f:
            head = f.read(200)
        os.remove(tmp_path)
        raise IOError("Antwort ist keine Audiodatei: {!r}".format(head))
    if os.path.exists(dest_path):
        os.remove(dest_path)
    os.rename(tmp_path, dest_path)
    _l("decrypt_to_file fertig, chunks={}".format(index))


def register(token, url, track_id):
    _l(f"register token={token[:8]}… url={url[:60]}…")
    _write_route(token, url, track_id)


def proxy_url(token):
    return f"http://127.0.0.1:{_active_port}/{token}"


def stop():
    pass
