import xbmc
import xbmcaddon


def log(msg, level=xbmc.LOGDEBUG):
    addon = xbmcaddon.Addon()
    if addon.getSettingBool("debug.enable"):
        xbmc.log(f"[plugin.video.deezer] {msg}", level)
