import html as _html
import random
import re
import hashlib
import json
import os
import urllib.request
import urllib.parse
import urllib.error

CDN_TEMPLATE = "https://e-cdns-proxy-{n}.dzcdn.net/mobile/1/{hash}"
_FORMAT_IDS = {"MP3_128": "1", "MP3_320": "3", "FLAC": "9"}


def _cdn_url(md5_origin, track_id, quality, media_version="1"):
    import crypto
    fmt = _FORMAT_IDS.get(quality, "1")
    step1 = "\xa4".join([md5_origin, fmt, str(track_id), str(media_version)])
    step1 = hashlib.md5(step1.encode("latin-1")).hexdigest() + "\xa4" + step1 + "\xa4"
    step1 += " " * ((-len(step1)) % 16)
    try:
        try:
            from Cryptodome.Cipher import AES
        except ImportError:
            from Crypto.Cipher import AES
        encrypted = AES.new(b"jo6aey6haid2Teih", AES.MODE_ECB).encrypt(step1.encode("latin-1"))
    except ImportError:
        encrypted = crypto.aes128_ecb_encrypt(b"jo6aey6haid2Teih", step1.encode("latin-1"))
    return CDN_TEMPLATE.format(n=md5_origin[0], hash=encrypted.hex())


GW_API = "https://www.deezer.com/ajax/gw-light.php"
MEDIA_API = "https://media.deezer.com/v1/get_url"
APP_ID = 632384
OAUTH_APP_ID = 447462
OAUTH_SALT = "a83bf7f38ad2f137e444727cfc3775cf"
OAUTH_SID_URL = "https://connect.deezer.com/oauth/auth.php"
OAUTH_LOGIN_URL = "https://connect.deezer.com/oauth/user_auth.php"
QUALITIES = {
    "MP3_128": {"cipher": "BF_CBC_STRIPE", "format": "MP3_128"},
    "MP3_320": {"cipher": "BF_CBC_STRIPE", "format": "MP3_320"},
    "FLAC":    {"cipher": "BF_CBC_STRIPE", "format": "FLAC"},
}

_log = None


def set_logger(fn):
    global _log
    _log = fn


def _l(msg):
    if _log:
        _log(msg)


def _cid():
    return random.randint(0, 999999999)


_HTML_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) "
                  "SamsungBrowser/30.0 Chrome/143.0.0.0 Mobile Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,"
              "image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Accept-Language": "de-AT,de-DE;q=0.9,de;q=0.8,en-US;q=0.7,en;q=0.6",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
}
_THUMB_RE = re.compile(
    r'<a\s+class="tempo-thumbnail-cover-container[^"]*"[^>]*?href="([^"]+)"[^>]*>(.*?)</a>', re.S)
_H2_RE = re.compile(r'<h2[^>]*>(.*?)</h2>', re.S)
_HREF_RE = re.compile(
    r'^(?:https?://www\.deezer\.com)?/(?:[a-z]{2}(?:-[a-z]{2})?/)?(album|playlist|artist|show|channels)/([^/?#]+)')
_IMG_RE = re.compile(r'/images/([a-z]+)/([a-f0-9]{32})/')
_KIND_BY_TYPE = {"channel": "misc", "album": "cover", "playlist": "playlist", "artist": "artist", "show": "talk"}
_KNOWN_KINDS = ("cover", "playlist", "artist", "misc", "talk")
_SKIP_SLUGS = ("explore", "module")


def _clean(text):
    return re.sub(r"\s+", " ", _html.unescape(re.sub(r"<[^>]+>", "", text))).strip()


def _img(kind, md5, size=500):
    return f"https://cdn-images.dzcdn.net/images/{kind}/{md5}/{size}x{size}-000000-80-0-0.jpg"


def _entry(dtype, ident, title, kind, md5):
    pics = [{"md5": _img(kind, md5)}] if md5 else []
    if dtype == "channel":
        return {"data": {"type": "channel", "slug": ident, "title": title or ident, "pictures": pics}}
    if dtype == "artist":
        return {"data": {"type": "artist", "id": ident, "name": title or ident, "pictures": pics}}
    return {"data": {"type": dtype, "id": ident, "title": title or ident, "pictures": pics}}


def _html_info(raw_html):
    bundle = re.search(r"cache/js/(app-[a-z]+)\.", raw_html)
    body = re.search(r"<body[^>]*\bid=\"([^\"]+)\"", raw_html)
    bundle_name = bundle.group(1) if bundle else "-"
    body_id = body.group(1) if body else "-"
    has_state = "__DZR_APP_STATE__" in raw_html
    thumbs = raw_html.count("tempo-thumbnail-cover-container")
    return f"bundle={bundle_name} body={body_id} state={has_state} thumbs={thumbs}"


def _parse_state(raw_html):
    marker = re.search(r"__DZR_APP_STATE__\s*=\s*", raw_html)
    if not marker:
        return []
    start = raw_html.find("{", marker.end())
    if start < 0:
        return []
    try:
        state, _ = json.JSONDecoder().raw_decode(raw_html[start:])
    except ValueError as e:
        _l(f"get_channel_page: __DZR_APP_STATE__ Parse-Fehler: {e}")
        return []
    if not isinstance(state, dict):
        return []
    sections = []
    for sec in state.get("sections") or []:
        if not isinstance(sec, dict):
            continue
        items = []
        for it in sec.get("items") or []:
            d = it.get("data") if isinstance(it, dict) else None
            if not isinstance(d, dict):
                continue
            dtype = d.get("type", "")
            if dtype not in _KIND_BY_TYPE:
                continue
            ident = d.get("slug") if dtype == "channel" else d.get("id")
            if not ident:
                continue
            pics = d.get("pictures") or []
            first = pics[0] if pics and isinstance(pics[0], dict) else {}
            kind = first.get("type") if first.get("type") in _KNOWN_KINDS else _KIND_BY_TYPE[dtype]
            title = d.get("title") or d.get("name") or ""
            items.append(_entry(dtype, str(ident), title, kind, first.get("md5", "")))
        if items:
            sections.append({"title": sec.get("title", ""), "items": items})
    return sections


def _parse_discovery(raw_html, current_slug):
    heads = [(m.start(), _clean(m.group(1))) for m in _H2_RE.finditer(raw_html)]
    sections = []
    cur = None
    seen = set()
    hi = -1
    title = ""
    for m in _THUMB_RE.finditer(raw_html):
        while hi + 1 < len(heads) and heads[hi + 1][0] < m.start():
            hi += 1
            title = heads[hi][1]
            cur = None
            seen = set()
        href_m = _HREF_RE.match(m.group(1))
        if not href_m:
            continue
        path_kind = href_m.group(1)
        ident = urllib.parse.unquote(href_m.group(2))
        dtype = "channel" if path_kind == "channels" else path_kind
        if dtype == "channel" and (ident in _SKIP_SLUGS or ident == current_slug):
            continue
        if (dtype, ident) in seen:
            continue
        inner = m.group(2)
        name = ""
        if dtype == "channel":
            tm = re.search(r'<p class="title-text">(.*?)</p>', inner, re.S)
            if tm:
                name = _clean(tm.group(1))
        else:
            lm = re.search(
                r'<a href="' + re.escape(m.group(1)) + r'"><span class="tempo-thumbnail-text[^"]*">(.*?)</span></a>',
                raw_html[m.end():m.end() + 2500], re.S)
            if lm:
                name = _clean(lm.group(1))
            if not name:
                am = re.search(r'alt="([^"]*)"', inner)
                if am:
                    name = re.sub(r"^Album cover of\s+", "", _clean(am.group(1)))
        im = _IMG_RE.search(inner)
        kind = im.group(1) if im else _KIND_BY_TYPE[dtype]
        md5 = im.group(2) if im else ""
        if cur is None:
            cur = {"title": title, "items": []}
            sections.append(cur)
        seen.add((dtype, ident))
        cur["items"].append(_entry(dtype, ident, name, kind, md5))
    return sections



class DeezerAPI:
    def __init__(self):
        self._cookie_jar = urllib.request.HTTPCookieProcessor()
        self._opener = urllib.request.build_opener(self._cookie_jar)
        self._opener.addheaders = [
            ("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 "
                           "(KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36"),
            ("Accept-Language", "de-AT,de;q=0.9,en;q=0.8"),
            ("Accept", "application/json, text/plain, */*"),
        ]
        self.api_token = ""
        self.license_token = ""
        self.can_stream = False
        self.user_id = 0
        self.jwt = ""
        self._arl = ""
        self._on_relogin = None
        self._renew_arl = None

    def _set_cookie(self, name, value, domain=".deezer.com"):
        import http.cookiejar
        cookie = http.cookiejar.Cookie(
            version=0, name=name, value=value,
            port=None, port_specified=False,
            domain=domain, domain_specified=True, domain_initial_dot=True,
            path="/", path_specified=True,
            secure=False, expires=None, discard=True,
            comment=None, comment_url=None, rest={},
        )
        self._cookie_jar.cookiejar.set_cookie(cookie)

    def _request(self, url, params=None, body=None):
        if params:
            url = url + "?" + urllib.parse.urlencode(params)
        data = json.dumps(body or {}).encode("utf-8")
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        _l(f"_request → {req.full_url}")
        _l(f"  body: {json.dumps(body or {})[:300]}")
        with self._opener.open(req, timeout=15) as resp:
            raw = resp.read().decode("utf-8")
        _l(f"  response ({len(raw)} bytes): {raw[:500]}")
        return json.loads(raw)

    def _gw(self, method, body=None):
        params = {
            "method": method,
            "input": 3,
            "api_version": "1.0",
            "api_token": self.api_token,
            "cid": _cid(),
        }
        _l(f"_gw method={method}")
        data = self._request(GW_API, params=params, body=body or {})
        error = data.get("error")
        if isinstance(error, dict) and error:
            if "VALID_TOKEN_REQUIRED" in error and self._arl:
                _l("  VALID_TOKEN_REQUIRED – Token abgelaufen, erneuere Session…")
                try:
                    self.login_arl(self._arl)
                except Exception:
                    new_arl = self._renew_arl() if self._renew_arl else ""
                    if not new_arl:
                        raise
                    self.login_arl(new_arl)
                if self._on_relogin:
                    self._on_relogin()
                params["api_token"] = self.api_token
                params["cid"] = _cid()
                data = self._request(GW_API, params=params, body=body or {})
                error = data.get("error")
                if isinstance(error, dict) and error:
                    _l(f"  API error nach Retry: {error}")
                    raise Exception(f"API error: {error}")
            else:
                _l(f"  API error: {error}")
                raise Exception(f"API error: {error}")
        return data.get("results", data)

    def login_arl(self, arl):
        _l("login_arl")
        self._arl = arl
        self._set_cookie("arl", arl)
        r = self._gw("deezer_userAutolog", {
            "APP_NAME": "Deezer",
            "APPLICATION_ID": APP_ID,
            "AUTHORIZE_UNLOGGED": True,
            "CHECKFORM": True,
        })
        checkform = r.get("checkform", "")
        if checkform:
            self.api_token = checkform
        self.jwt = r.get("JWT", "")
        _l(f"  checkform={'ok' if checkform else 'missing'} jwt={'ok' if self.jwt else 'missing'}")
        return self._load_user_data()

    def _quiet_json(self, url, body=None, headers=None, method="GET"):
        data = None if body is None else json.dumps(body).encode("utf-8")
        req = urllib.request.Request(url, data=data, method=method)
        if data is not None:
            req.add_header("Content-Type", "text/plain;charset=UTF-8")
        for k, v in (headers or {}).items():
            req.add_header(k, v)
        with self._opener.open(req, timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def _login_oauth(self, mail, password):
        import hashlib
        pw_md5 = hashlib.md5(password.encode("utf-8")).hexdigest()
        digest = hashlib.md5(f"{OAUTH_APP_ID}{mail}{pw_md5}{OAUTH_SALT}".encode("utf-8")).hexdigest()
        try:
            self._opener.open(urllib.request.Request(OAUTH_SID_URL), timeout=15).read()
        except Exception:
            pass
        query = urllib.parse.urlencode({
            "app_id": OAUTH_APP_ID,
            "login": mail,
            "password": pw_md5,
            "hash": digest,
        })
        res = self._quiet_json(f"{OAUTH_LOGIN_URL}?{query}")
        token = res.get("access_token", "") if isinstance(res, dict) else ""
        if not token:
            raise Exception("oauth: kein access_token")
        params = urllib.parse.urlencode({
            "method": "user.getArl",
            "input": 3,
            "api_version": "1.0",
            "api_token": "",
            "cid": _cid(),
        })
        data = self._quiet_json(f"{GW_API}?{params}", body={},
                                headers={"Authorization": f"Bearer {token}"}, method="POST")
        results = data.get("results") if isinstance(data, dict) else None
        arl = ""
        if isinstance(results, dict):
            arl = results.get("arl", "")
        elif isinstance(results, str):
            arl = results
        if not arl:
            raise Exception("oauth: keine arl erhalten")
        return arl

    def _login_web(self, mail, password):
        self._gw("deezer.getUserData")
        params = {
            "method": "deezer_userAuth",
            "input": 3,
            "api_version": "1.0",
            "api_token": self.api_token,
            "cid": _cid(),
        }
        body = {
            "MAIL": mail,
            "PASSWORD": password,
            "APP_NAME": "Deezer",
            "APPLICATION_ID": APP_ID,
            "DEVICE_TOKEN": os.urandom(32).hex(),
        }
        data = self._quiet_json(GW_API + "?" + urllib.parse.urlencode(params), body=body,
                                headers={"Origin": "https://www.deezer.com",
                                         "Referer": "https://www.deezer.com/"}, method="POST")
        error = data.get("error")
        if isinstance(error, dict) and error:
            raise Exception(f"web: {sorted(error.keys())}")
        res = data.get("results") or {}
        arl = res.get("arl", "") if isinstance(res, dict) else ""
        if not arl:
            for c in self._cookie_jar.cookiejar:
                if c.name == "arl" and c.value:
                    arl = c.value
        if not arl:
            raise Exception("web: keine arl erhalten")
        return arl

    def login_mail(self, mail, password):
        errors = []
        for fn in (self._login_oauth, self._login_web):
            try:
                return fn(mail, password)
            except Exception as e:
                errors.append(str(e))
        raise Exception("login_mail: " + " | ".join(errors))

    def restore_session(self, api_token, user_id, license_token, arl, jwt="", can_stream=False):
        _l(f"restore_session user_id={user_id}")
        self.api_token = api_token
        self.user_id = user_id
        self.license_token = license_token
        self.can_stream = can_stream
        self.jwt = jwt
        self._arl = arl
        self._set_cookie("arl", arl)

    def _load_user_data(self):
        _l("_load_user_data")
        data = self._gw("deezer.getUserData")
        self.api_token = data.get("checkForm", self.api_token)
        user = data.get("USER", {})
        self.user_id = user.get("USER_ID", 0)
        options = user.get("OPTIONS", {})
        self.license_token = options.get("license_token", "")
        self.can_stream = any(options.get(k) for k in ("web_hq", "web_lossless", "mobile_hq", "mobile_lossless"))
        _l(f"  user_id={self.user_id} license_token={'ok' if self.license_token else 'missing'} can_stream={self.can_stream}")
        return self.user_id != 0

    def search(self, query, nb=30):
        _l(f"search query={query!r}")
        return self._gw("deezer.pageSearch", {
            "query": query, "nb": nb, "start": 0,
            "suggest": True, "artist_suggest": True, "top_tracks": True,
        })

    def get_album(self, album_id):
        _l(f"get_album id={album_id}")
        return self._gw("deezer.pageAlbum", {"ALB_ID": album_id, "lang": "de", "tab": 0})

    def get_artist(self, artist_id):
        _l(f"get_artist id={artist_id}")
        return self._gw("deezer.pageArtist", {"ART_ID": artist_id, "lang": "de", "nb": 100})

    def get_playlist(self, playlist_id):
        _l(f"get_playlist id={playlist_id}")
        return self._gw("deezer.pagePlaylist", {
            "PLAYLIST_ID": playlist_id, "lang": "de",
            "nb": 200, "start": 0, "tab": 0, "tags": True,
        })

    def get_favorite_tracks(self, nb=200):
        _l("get_favorite_tracks")
        data = self._gw("deezer.getUserData")
        loved_id = data.get("USER", {}).get("LOVEDTRACKS_ID", f"1{self.user_id}")
        return self._gw("playlist.getSongs", {"PLAYLIST_ID": loved_id, "nb": nb, "start": 0})

    def get_user_playlists(self, nb=50):
        _l("get_user_playlists")
        return self._gw("deezer.pageProfile", {
            "USER_ID": self.user_id, "tab": "playlists", "nb": nb,
        })

    def get_favorite_albums(self, nb=50):
        _l("get_favorite_albums")
        return self._gw("deezer.pageProfile", {
            "USER_ID": self.user_id, "tab": "albums", "nb": nb,
        })

    def get_favorite_artists(self, nb=100):
        _l("get_favorite_artists")
        return self._gw("deezer.pageProfile", {
            "USER_ID": self.user_id, "tab": "artists", "nb": nb,
        })

    _FAV_METHODS = {
        "track": ("favorite_song.add", "SNG_ID", "favorite_song.remove", "SNG_ID"),
        "album": ("album.addFavorite", "ALB_ID", "album.deleteFavorite", "ALB_ID"),
        "artist": ("artist.addFavorite", "ART_ID", "artist.deleteFavorite", "ART_ID"),
        "playlist": ("playlist.addFavorite", "PARENT_PLAYLIST_ID", "playlist.deleteFavorite", "PLAYLIST_ID"),
    }

    def set_favorite(self, kind, item_id, add=True):
        add_method, add_key, del_method, del_key = self._FAV_METHODS[kind]
        method, key = (add_method, add_key) if add else (del_method, del_key)
        _l(f"set_favorite kind={kind} id={item_id} add={add}")
        return self._gw(method, {key: int(item_id)})

    def get_flow(self, nb=40):
        _l("get_flow")
        return self._gw("radio.getUserRadio", {"USER_ID": self.user_id, "nb": nb})

    def public_get(self, path, params=None):
        url = "https://api.deezer.com/" + path
        if params:
            url = url + "?" + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, method="GET")
        _l(f"public_get → {url}")
        try:
            with self._opener.open(req, timeout=15) as resp:
                raw = resp.read().decode("utf-8")
        except Exception as e:
            _l(f"public_get Fehler: {e}")
            return {}
        _l(f"  response ({len(raw)} bytes): {raw[:500]}")
        try:
            return json.loads(raw)
        except Exception:
            return {}

    def get_genres(self):
        _l("get_genres")
        return self.public_get("genre")

    def _fetch_html(self, opener, url):
        req = urllib.request.Request(url, method="GET")
        for key, value in _HTML_HEADERS.items():
            req.add_header(key, value)
        try:
            with opener.open(req, timeout=20) as resp:
                final_url = resp.geturl()
                raw_html = resp.read().decode("utf-8", "ignore")
        except Exception as e:
            _l(f"get_channel_page HTML-Fehler: {e}")
            return ""
        _l(f"get_channel_page: url={final_url} len={len(raw_html)} {_html_info(raw_html)}")
        return raw_html

    def get_channel_page(self, slug):
        import xbmcaddon as _xa
        verbose = _xa.Addon().getSettingBool("debug.channel")
        _l(f"get_channel_page slug={slug}")
        url = f"https://www.deezer.com/de/channels/{urllib.parse.quote(slug)}"
        openers = (
            ("session", self._opener),
            ("anon", urllib.request.build_opener(urllib.request.HTTPCookieProcessor())),
        )
        for label, opener in openers:
            raw_html = self._fetch_html(opener, url)
            if not raw_html:
                continue
            if verbose:
                _l(f"get_channel_page[{label}]: HTML-Anfang={raw_html[:300]!r}")
            sections = _parse_state(raw_html) or _parse_discovery(raw_html, slug)
            if sections:
                total = sum(len(s["items"]) for s in sections)
                _l(f"get_channel_page[{label}]: {total} Eintraege in {len(sections)} Sektionen")
                return {"sections": sections}
            _l(f"get_channel_page[{label}]: keine Eintraege gefunden")
        return {}

    def get_show_episodes(self, show_id, nb=100):
        _l(f"get_show_episodes id={show_id}")
        data = self.public_get(f"podcast/{show_id}/episodes", {"limit": nb})
        items = data.get("data", []) if isinstance(data, dict) else []
        return items if isinstance(items, list) else []

    def get_episode_stream(self, episode_id):
        _l(f"get_episode_stream id={episode_id}")
        try:
            data = self._gw("episode.getListData", {"episode_ids": [str(episode_id)]})
        except Exception as e:
            _l(f"get_episode_stream Fehler: {e}")
            return ""
        rows = data.get("data", []) if isinstance(data, dict) else []
        if not rows or not isinstance(rows[0], dict):
            _l("get_episode_stream: keine Daten")
            return ""
        return rows[0].get("EPISODE_DIRECT_STREAM_URL", "") or ""

    def get_chart(self, genre_id=0, kind="tracks", nb=50):
        _l(f"get_chart genre_id={genre_id} kind={kind}")
        return self.public_get(f"chart/{genre_id}/{kind}", {"limit": nb})

    def get_track_info(self, track_id):
        _l(f"get_track_info id={track_id}")
        return self._gw("song.getData", {"SNG_ID": int(track_id)})

    def _do_media_request(self, track_token, quality):
        import gzip as _gzip
        body = json.dumps({
            "license_token": self.license_token,
            "media": [{"type": "FULL", "formats": [QUALITIES[quality]]}],
            "track_tokens": [track_token],
            "app_id": "1",
        }).encode("utf-8")
        req = urllib.request.Request(MEDIA_API, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                     "AppleWebKit/537.36 (KHTML, like Gecko) "
                                     "Chrome/124.0.0.0 Safari/537.36")
        req.add_header("Accept-Encoding", "identity")
        if self.jwt:
            req.add_header("Authorization", f"Bearer {self.jwt}")
        with urllib.request.urlopen(req, timeout=15) as resp:
            raw = resp.read()
            if resp.headers.get("content-encoding") == "gzip":
                raw = _gzip.decompress(raw)
            return json.loads(raw.decode("utf-8"))

    def get_stream_url(self, track_token, quality="MP3_128", md5_origin="", track_id="", media_version="1"):
        if not track_token:
            _l("get_stream_url: leeres track_token")
            return None, False
        if not self.license_token:
            self._load_user_data()
        data = None
        for attempt in (1, 2):
            try:
                data = self._do_media_request(track_token, quality)
                break
            except urllib.error.HTTPError as e:
                _l("get_url HTTP {} (Versuch {})".format(e.code, attempt))
                if attempt == 1:
                    try:
                        self._load_user_data()
                    except Exception as e2:
                        _l("license_token Erneuerung fehlgeschlagen: {}".format(e2))
            except (urllib.error.URLError, ValueError, OSError) as e:
                _l("get_url Fehler: {}".format(e))
                break
        if data is not None:
            try:
                media = data["data"][0]["media"]
                if media:
                    return media[0]["sources"][0]["url"], False
                _l("get_url: kein Medium fuer {} - {}".format(quality, json.dumps(data["data"][0].get("errors"))[:200]))
            except (KeyError, IndexError, TypeError):
                _l("get_url: unerwartete Antwort {}".format(json.dumps(data)[:300]))
        if md5_origin and track_id:
            _l("Fallback auf berechnete CDN-URL")
            return _cdn_url(md5_origin, track_id, quality, media_version), False
        return None, quality != "MP3_128"


def cover_url(md5, size=500):
    if not md5:
        return ""
    if md5.startswith("http://") or md5.startswith("https://"):
        return md5
    return f"https://e-cdns-images.dzcdn.net/images/cover/{md5}/{size}x{size}-000000-80-0-0.jpg"


def playlist_img_url(pic, size=500):
    if not pic:
        return ""
    kind, _, md5 = pic.partition(":")
    if not md5:
        md5, kind = kind, "cover"
    if kind not in ("cover", "playlist"):
        kind = "cover"
    return f"https://e-cdns-images.dzcdn.net/images/{kind}/{md5}/{size}x{size}-000000-80-0-0.jpg"


def artist_img_url(md5, size=500):
    if not md5:
        return ""
    return f"https://e-cdns-images.dzcdn.net/images/artist/{md5}/{size}x{size}-000000-80-0-0.jpg"
