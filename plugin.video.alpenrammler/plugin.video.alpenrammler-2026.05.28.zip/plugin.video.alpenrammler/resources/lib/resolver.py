import re
import json
import ssl

try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError, HTTPError
    from urllib.parse import urlparse, urlencode
except ImportError:
    from urllib2 import urlopen, Request, URLError, HTTPError
    from urlparse import urlparse
    from urllib import urlencode

try:
    import xbmc
    def _log(msg):
        xbmc.log('[AlpenRammler/resolver] ' + str(msg), xbmc.LOGINFO)
except Exception:
    def _log(msg):
        pass

UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/124.0.0.0 Safari/537.36'
)

# SSL context with disabled verification -- needed on some Android/Kodi builds
try:
    _SSL_CTX = ssl.create_default_context()
    _SSL_CTX.check_hostname = False
    _SSL_CTX.verify_mode = ssl.CERT_NONE
except Exception:
    _SSL_CTX = None


def _get(url, referer=None):
    headers = {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
        'Accept-Encoding': 'identity',   # no gzip -- we decode manually
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.5',
        'Referer': referer or url,
        'Connection': 'keep-alive',
    }
    req = Request(url, headers=headers)
    try:
        if _SSL_CTX:
            resp = urlopen(req, context=_SSL_CTX, timeout=20)
        else:
            resp = urlopen(req, timeout=20)
        data = resp.read()
        charset = 'utf-8'
        try:
            ct = resp.headers.get('Content-Type', '') or ''
            if 'charset=' in ct:
                charset = ct.split('charset=')[-1].split(';')[0].strip()
        except Exception:
            pass
        text = data.decode(charset, errors='replace')
        _log('_get OK url=%s bytes=%d' % (url, len(text)))
        return text, resp.geturl()
    except Exception as e:
        _log('_get ERROR url=%s err=%s' % (url, e))
        return '', url


def resolve(url, referer=None):
    parsed = urlparse(url)
    host = parsed.netloc.lower()
    _log('resolve url=%s' % url)

    if 'lapippa' in host:
        return _resolve_lapippa(url, referer=referer)
    if 'pornoente' in host:
        return _resolve_pornoente(url, referer=referer)
    if 'pornohirsch' in host:
        return _resolve_pornohirsch(url, referer=referer)
    if 'xhamster' in host:
        return _resolve_xhamster(url)
    if 'dood' in host or 'doodstream' in host:
        return _resolve_dood(url)
    if 'streamtape' in host:
        return _resolve_streamtape(url)
    if 'voe' in host:
        return _resolve_voe(url)
    if 'mixdrop' in host:
        return _resolve_mixdrop(url)
    if 'upstream' in host or 'upstreamcdn' in host:
        return _resolve_upstream(url)
    if 'mp4upload' in host:
        return _resolve_mp4upload(url)
    if any(url.lower().endswith(x) or (x + '?') in url.lower() for x in ['.mp4', '.m3u8', '.mkv']):
        _log('resolve direct url=%s' % url)
        return url
    html, final_url = _get(url)
    direct = re.search(r'["\']((https?://[^"\']+\.(?:mp4|m3u8)(?:\?[^"\']*)?)["\'])', html)
    if direct:
        return direct.group(2)
    return None


def _resolve_lapippa(url, referer=None):
    html, _ = _get(url, referer=referer or 'https://alpenrammler.com/')
    if not html:
        _log('_resolve_lapippa: empty response for %s' % url)
        return None
    # <source src="URL" type='video/mp4' label='480p' res='480'/>
    sources = re.findall(
        r'<source[^>]+src=["\']([^"\']+\.mp4[^"\']*)["\'][^>]*res=["\'](\d+)["\']',
        html, re.I
    )
    if not sources:
        # try reversed attribute order: res= before src=
        sources = re.findall(
            r'<source[^>]+res=["\'](\d+)["\'][^>]*src=["\']([^"\']+\.mp4[^"\']*)["\']',
            html, re.I
        )
        if sources:
            sources = [(url, res) for res, url in sources]
    if sources:
        sources.sort(key=lambda x: int(x[1]), reverse=True)
        _log('_resolve_lapippa: best=%s res=%s' % (sources[0][0], sources[0][1]))
        return sources[0][0]
    # Fallback: any quoted mp4 URL
    m = re.search(r'["\']((https?://[^"\']+\.mp4[^"\']*)["\'])', html)
    if m:
        _log('_resolve_lapippa fallback: %s' % m.group(2))
        return m.group(2)
    _log('_resolve_lapippa: no mp4 found, html_start=%s' % html[:200])
    return None


def _resolve_xhamster(url):
    html, _ = _get(url, referer='https://alpenrammler.com/')
    m = re.search(r'"url"\s*:\s*"(https?://[^"]+\.mp4[^"]*)"', html)
    if m:
        return m.group(1)
    m = re.search(r'"hls"\s*:\s*\{\s*"url"\s*:\s*"([^"]+)"', html)
    if m:
        return m.group(1)
    return None


def _resolve_dood(url):
    html, _ = _get(url, referer='https://alpenrammler.com/')
    pass_m = re.search(r"pass_md5/([^'\"]+)['\"]", html)
    token_m = re.search(r"[?&]token=([^&'\"]+)", html)
    if not pass_m:
        return None
    pass_url = 'https://dood.to/pass_md5/' + pass_m.group(1)
    token = token_m.group(1) if token_m else ''
    raw, _ = _get(pass_url, referer=url)
    if not raw:
        return None
    import random
    import string
    rnd = ''.join(random.choices(string.ascii_letters + string.digits, k=10))
    import time
    ts = str(int(time.time() * 1000))
    stream = raw.strip() + rnd + '?token=' + token + '&expiry=' + ts
    return stream


def _resolve_streamtape(url):
    html, _ = _get(url, referer='https://alpenrammler.com/')
    robot_m = re.search(r"robotlink'\).innerHTML = '([^']+)'.*?innerHTML \+= '([^']+)'", html, re.S)
    if robot_m:
        return 'https:' + robot_m.group(1) + robot_m.group(2)
    direct = re.search(r'(https://[^"\']+streamtape[^"\']+\.mp4[^"\']*)', html)
    if direct:
        return direct.group(1)
    return None


def _resolve_voe(url):
    html, _ = _get(url, referer='https://alpenrammler.com/')
    m = re.search(r"'hls'\s*:\s*'([^']+)'", html)
    if m:
        return m.group(1)
    m = re.search(r'"hls"\s*:\s*"([^"]+)"', html)
    if m:
        return m.group(1)
    m = re.search(r'(https?://[^"\']+\.m3u8[^"\']*)', html)
    if m:
        return m.group(1)
    return None


def _resolve_mixdrop(url):
    html, _ = _get(url, referer='https://alpenrammler.com/')
    m = re.search(r'MDCore\.wurl\s*=\s*"([^"]+)"', html)
    if m:
        stream = m.group(1)
        if not stream.startswith('http'):
            stream = 'https:' + stream
        return stream
    return None


def _resolve_upstream(url):
    html, _ = _get(url, referer='https://alpenrammler.com/')
    m = re.search(r'(https?://[^"\']+upstream[^"\']+\.m3u8[^"\']*)', html)
    if m:
        return m.group(1)
    m = re.search(r'"file"\s*:\s*"([^"]+\.m3u8[^"]*)"', html)
    if m:
        return m.group(1)
    return None


def _resolve_mp4upload(url):
    html, _ = _get(url, referer='https://alpenrammler.com/')
    m = re.search(r'"?file"?\s*:\s*"(https?://[^"]+\.mp4[^"]*)"', html)
    if m:
        return m.group(1)
    return None


def _resolve_source_tags(html):
    """Gemeinsamer Parser fuer <source src=...mp4 data-res=N> (pornoente, pornohirsch)."""
    # src vor data-res
    sources = re.findall(
        r'<source[^>]+src=["\']([^"\']+\.mp4[^"\']*)["\'][^>]*data-res=["\'](\d+)["\']',
        html, re.I)
    if not sources:
        # data-res vor src
        sources = re.findall(
            r'<source[^>]+data-res=["\'](\d+)["\'][^>]*src=["\']([^"\']+\.mp4[^"\']*)["\']',
            html, re.I)
        if sources:
            sources = [(u, r) for r, u in sources]
    if sources:
        sources.sort(key=lambda x: int(x[1]), reverse=True)
        _log('_resolve_source_tags best=%s res=%s' % (sources[0][0], sources[0][1]))
        return sources[0][0]
    # Fallback: erster mp4-Link
    m = re.search(r'(https?://[^"\'<>\s]+\.mp4[^"\'<>\s]*)', html)
    if m:
        _log('_resolve_source_tags fallback mp4=%s' % m.group(1))
        return m.group(1)
    return None


def _resolve_pornoente(url, referer=None):
    _log('_resolve_pornoente url=%s' % url)
    html, _ = _get(url, referer=referer or 'https://xnxxpornos.com/')
    if not html:
        return None
    return _resolve_source_tags(html)


def _resolve_pornohirsch(url, referer=None):
    _log('_resolve_pornohirsch url=%s' % url)
    html, _ = _get(url, referer=referer or 'https://xnxxpornos.com/')
    if not html:
        return None
    result = _resolve_source_tags(html)
    if result:
        return result
    # Fallback: pornohirsch kann selbst nochmal einen iframe haben
    iframe_m = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)
    if iframe_m:
        inner, _ = _get(iframe_m.group(1), referer=url)
        return _resolve_source_tags(inner) if inner else None
    return None
