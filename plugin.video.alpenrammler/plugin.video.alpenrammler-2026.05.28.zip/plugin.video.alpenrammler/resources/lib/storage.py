"""
Persistente Speicherung von Favoriten und Wiedergabe-Verlauf.
Datei: addon_data/plugin.video.alpenrammler/userdata.json
"""
import json
import os

try:
    import xbmcvfs
    import xbmcaddon
    def _data_dir():
        path = xbmcvfs.translatePath(
            xbmcaddon.Addon().getAddonInfo('profile')
        )
        if not xbmcvfs.exists(path):
            xbmcvfs.mkdirs(path)
        return path
except Exception:
    def _data_dir():
        return '/tmp'

HISTORY_MAX = 10
_FILE = None

def _path():
    global _FILE
    if _FILE is None:
        _FILE = os.path.join(_data_dir(), 'userdata.json')
    return _FILE

def _load():
    p = _path()
    try:
        if os.path.exists(p):
            with open(p, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if 'favorites' not in data:
                    data['favorites'] = []
                if 'history' not in data:
                    data['history'] = []
                if 'plots' not in data:
                    data['plots'] = {}
                return data
    except Exception:
        pass
    return {'favorites': [], 'history': [], 'plots': {}}

def _save(data):
    try:
        with open(_path(), 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False

def favorites_get():
    return _load()['favorites']

def favorites_is(post_id):
    return any(f['post_id'] == str(post_id) for f in _load()['favorites'])

def favorites_add(item):
    """item = dict mit post_id, title, post_url, thumb, duration, views"""
    data = _load()
    pid = str(item['post_id'])
    if not any(f['post_id'] == pid for f in data['favorites']):
        data['favorites'].append({
            'post_id':  pid,
            'title':    item.get('title', ''),
            'post_url': item.get('post_url', ''),
            'thumb':    item.get('thumb', ''),
            'duration': item.get('duration', ''),
            'views':    item.get('views', ''),
        })
        _save(data)
    return True

def favorites_remove(post_id):
    data = _load()
    data['favorites'] = [f for f in data['favorites']
                         if f['post_id'] != str(post_id)]
    return _save(data)

def favorites_edit_title(post_id, new_title):
    data = _load()
    for f in data['favorites']:
        if f['post_id'] == str(post_id):
            f['title'] = new_title
            break
    return _save(data)

def history_get():
    return _load()['history']

def history_add(item):
    """Trägt einen gestarteten Video-Eintrag ein (neueste zuerst, max 10)."""
    import datetime
    data = _load()
    pid = str(item['post_id'])
    data['history'] = [h for h in data['history'] if h['post_id'] != pid]
    entry = {
        'post_id':      pid,
        'title':        item.get('title', ''),
        'post_url':     item.get('post_url', ''),
        'thumb':        item.get('thumb', ''),
        'duration':     item.get('duration', ''),
        'views':        item.get('views', ''),
        'last_watched': datetime.datetime.now().strftime('%d.%m.%Y %H:%M'),
    }
    data['history'].insert(0, entry)
    data['history'] = data['history'][:HISTORY_MAX]
    return _save(data)

def history_remove(post_id):
    data = _load()
    data['history'] = [h for h in data['history']
                       if h['post_id'] != str(post_id)]
    return _save(data)

def history_clear():
    data = _load()
    data['history'] = []
    return _save(data)

def plot_save(post_id, plot_text):
    """Speichert die Beschreibung eines Videos im Cache."""
    if not plot_text:
        return
    data = _load()
    data['plots'][str(post_id)] = plot_text
    _save(data)

def plot_get(post_id):
    """Gibt die gecachte Beschreibung zurück, oder leeren String."""
    data = _load()
    return data['plots'].get(str(post_id), '')
