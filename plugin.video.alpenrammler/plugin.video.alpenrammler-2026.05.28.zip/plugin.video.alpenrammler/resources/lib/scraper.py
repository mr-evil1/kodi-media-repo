import re
import sys
import xbmc
import xbmcaddon
import xbmcvfs

try:
    from urllib.parse import urlencode, quote_plus, unquote_plus, urlparse, parse_qs
    from urllib.request import urlopen, Request
    from urllib.error import URLError, HTTPError
except ImportError:
    from urlparse import urlparse, parse_qs
    from urllib import urlencode, quote_plus, unquote_plus
    from urllib2 import urlopen, Request, URLError, HTTPError

ADDON = xbmcaddon.Addon()
BASE_URL    = 'https://alpenrammler.com'
BASE_URL_PD = 'https://pornodeutsch.xxx'
BASE_URL_SF = 'https://www.sexfilme.xxx'
BASE_URL_BP = 'https://bravoporno.net'
BASE_URL_XNXX = 'https://xnxxpornos.com'
BASE_URL_AP = 'https://alpenporno.com'
UA = ADDON.getSetting('user_agent') or (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/124.0.0.0 Safari/537.36'
)

CATEGORIES = [
    ('Alt fickt Jung', 'alt-fickt-jung-pornos'),
    ('Amateur', 'amateuresex'),
    ('Anal', 'analsex'),
    ('Arabisch', 'arabische-pornos'),
    ('Asian', 'asiansex'),
    ('BBW', 'bbwsex'),
    ('Blasen / Lutschen', 'blasen-lutschen-pornos'),
    ('Blonde', 'blonde'),
    ('Casting', 'castingsex'),
    ('Deutsche Pornos', 'deutsche-pornos'),
    ('Deutsche Sexfilme', 'deutsche-sexfilme'),
    ('Dreier', 'dreiersex'),
    ('Fetisch', 'fetischpornos'),
    ('Fisting / Faustsex', 'fistingpornos-faustsex'),
    ('Free Porn', 'free-porn'),
    ('Gangbang', 'gangbangsex'),
    ('Gay', 'gay-pornos'),
    ('Große Hintern', 'grosse-hintern-porno'),
    ('Große Schwänze', 'grosseschwaenzesex'),
    ('Große Titten', 'grossetittensex'),
    ('Gruppensex', 'gruppensex'),
    ('HD Pornos', 'hd-pornos'),
    ('Latina', 'latinasex'),
    ('Lesben', 'lesbensex'),
    ('Milf', 'milfsex'),
    ('Oma', 'omasex-pornos'),
    ('POV', 'pov-pornos'),
    ('Glory Hole', 'glory-hole-porno'),
    ('Swinger', 'swingersex'),
    ('Teen', 'teensex'),
    ('Shemale', 'shemale-porn'),
    ('xHamster', 'xhamster-pornos'),
    ('XXX', 'xxx-sex'),
    ('Zeichentrick', 'zeichentricksex'),
    ('Pornohirsch', 'pornohirsch'),
    ('Youporn', 'youporn'),
]

CATEGORIES_PD = [
    ('Amateure',              'amateure'),
    ('Arschficken',           'arschficken'),
    ('Blasen',                'blasen'),
    ('Blondinen',             'blondinen'),
    ('Bruenetten',            'bruenetten'),
    ('Deutsche Pornos',       'deutsche-pornos'),
    ('Dicke Titten',          'dicke-titten'),
    ('Fetisch',               'fetisch'),
    ('Gangbang',              'gangbang'),
    ('Ich-Perspektive (POV)', 'ich-perspektive-pov'),
    ('Inzest',                'inzest'),
    ('Lesben',                'lesben'),
    ('Milf',                  'milf'),
    ('Mutter ficken',         'mutter-ficken'),
    ('Oma',                   'omasex'),
    ('Abspritzen',            'abspritzen'),
    ('Sexfilme',              'sexfilme'),
    ('Sperma Schlucken',      'sperma-schlucken'),
    ('Squirting',             'squirting'),
    ('Strippen',              'strippen'),
    ('Teen 18+',              'teen'),
    ('Wichsanleitung',        'wichsanleitung'),
    ('Youporn',               'youporn'),
]

CATEGORIES_BP = [
    ('Amateur',               'amateur-pornofilme'),
    ('Anal',                  'anal-pornofilme'),
    ('Arabisch',              'arabische-pornofilme'),
    ('Asiatisch',             'asiatische-pornofilme'),
    ('Blasen',                'blasen-pornofilme'),
    ('Blondinen',             'blondinen-pornofilme'),
    ('Alt & Jung',            'alt-und-jung-pornofilme'),
    ('Brünetten',             'brunette-schlampen'),
    ('Deutsche Pornos',       'deutsche-pornofilme'),
    ('Dicke Titten',          'dicke-titten-pornofilme'),
    ('Dirty Talk',            'dirty-talk-pornofilme'),
    ('Fetisch',               'fetisch-pornofilme'),
    ('Fisting',               'fisting-pornofilme'),
    ('Free Porn',             'free-porn-pornofilme'),
    ('Gay',                   'gay-pornofilme'),
    ('Gruppensex',            'gruppensex-pornofilme'),
    ('HD',                    'hd-pornofilme'),
    ('Hentai',                'hentai-pornofilme'),
    ('International',         'internationale-pornofilme'),
    ('Latina',                'latina-pornofilme'),
    ('Lesben',                'lesben-pornofilme'),
    ('Masturbation',          'masturbation-pornofilme'),
    ('Milf',                  'milf-pornofilme'),
    ('Oma',                   'oma-pornofilme'),
    ('Outdoor',               'outdoor-pornofilme'),
    ('Pornohirsch',           'pornohirsch-pornofilme'),
    ('Pornostars',            'pornostars'),
    ('Rothaarige',            'rothaarige-schlampen'),
    ('Schwarzhaarige',        'schwarzhaarige-schlampen'),
    ('Sexspielzeuge',         'sexspielzeuge'),
    ('Swinger',               'swinger-pornofilme'),
    ('Teen 18+',              'teen-pornofilme'),
    ('Transen',               'transen-pornofilme'),
    ('Webcam',                'webcam-pornofilme'),
    ('Wichsanleitung',        'wichsanleitung'),
    ('xHamster',              'xhamster-pornofilme'),
    ('XNXX',                  'xnxx-pornofilme'),
    ('Youporn',               'youporn-pornofilme'),
]

CATEGORIES_XNXX = [
    ('Alt fickt Jung',        'alt-fickt-jung'),
    ('Amateur',               'amateur-porn'),
    ('Anal',                  'arschficken-porn'),
    ('Asian',                 'asia-porn'),
    ('Blasen',                'blasen-porn'),
    ('Blonde',                'blondinen-porn'),
    ('Brünetten',             'bruenetten-porn'),
    ('Deutsch',               'deutscher-porn'),
    ('Dicke Frauen',          'dicke-frauen-porn'),
    ('Dicke Titten',          'dicke-titten-porn'),
    ('Dirty Talk',            'dirty-talk'),
    ('Dreier',                'dreier-porn'),
    ('Fetisch',               'fetisch-porn'),
    ('Ficken',                'ficken-porn'),
    ('Fisting',               'fisting-porn'),
    ('Fotze lecken',          'fotze-lecken'),
    ('Free Porn',             'free-porn'),
    ('Gay',                   'gay-porn'),
    ('Geile Frauen',          'geile-frauen-porn'),
    ('Gruppensex',            'gruppensex-porn'),
    ('International',         'international-porn'),
    ('Inzest',                'inzest-porn'),
    ('Latina',                'latina-porn'),
    ('Lesben',                'lesben-porn'),
    ('Livecam',               'livecam-porn'),
    ('Mature / Reif',         'mature-porn'),
    ('Mutter',                'mutter-porn'),
    ('Oma',                   'oma-porn'),
    ('Outdoor',               'outdoor-porn'),
    ('Party',                 'party-porn'),
    ('Pornoente',             'pornoente-porn'),
    ('Pornohirsch',           'pornohirsch-porn'),
    ('Pornostars',            'pornostars'),
    ('Selbstbefriedigung',    'selbstbefriedigung'),
    ('Sexspielzeug',          'sexspielzeug'),
    ('Sperma schlucken',      'sperma-schlucken'),
    ('Squirting',             'squirting-porn'),
    ('Teen 18+',              'teen-porn'),
    ('Transen',               'transen-porn'),
    ('Wichsanleitung',        'wichsanleitung'),
]

STORY_CATS_AP = [
    ('Allgemein',     'allgemein'),
    ('BDSM',          'bdsm'),
    ('Bürosex',       'buerosex'),
    ('Gruppensex',    'gruppensex'),
    ('Nutten',        'nutten'),
    ('Schwule / Gay', 'schwule-gays'),
    ('Voyeurismus',   'voyeurismus'),
]

def _log(msg):
    xbmc.log('[AlpenRammler] ' + str(msg), xbmc.LOGINFO)

def _request(url, referer=None):
    headers = {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'de-DE,de;q=0.9,en;q=0.5',
        'Connection': 'keep-alive',
    }
    if referer:
        headers['Referer'] = referer
    req = Request(url, headers=headers)
    try:
        response = urlopen(req, timeout=20)
        data = response.read()
        charset = response.headers.get_content_charset() or 'utf-8'
        html = data.decode(charset, errors='replace')
        _log('_request OK url=%s bytes=%d' % (url, len(html)))
        return html
    except (URLError, HTTPError) as e:
        _log('_request ERROR url=%s err=%s' % (url, e))
        return ''

def _parse_articles(html):
    items = []
    parts = re.split(r'(?=<article[\s>])', html)
    for part in parts:
        if not part.strip().startswith('<article'):
            continue
        post_id = ''
        pid_m = re.search(r'id=["\']post-(\d+)["\']', part)
        if pid_m:
            post_id = pid_m.group(1)
        else:
            pid_m = re.search(r'class=["\'][^"\']*\bpost-(\d+)\b', part)
            if pid_m:
                post_id = pid_m.group(1)

        url = ''
        title = ''
        href_m = re.search(
            r'href=["\']([^"\']+/(?:pornofilme|pornos)/[^"\']+)["\'][^>]*title=["\']([^"\']+)["\']',
            part)
        if not href_m:
            href_m = re.search(
                r'title=["\']([^"\']+)["\'][^>]*href=["\']([^"\']+/(?:pornofilme|pornos)/[^"\']+)["\']',
                part)
            if href_m:
                title = href_m.group(1)
                url = href_m.group(2)
                href_m = None
        if href_m:
            url = href_m.group(1)
            title = href_m.group(2)
        if not url:
            href_m = re.search(
                r'href=["\'](https://(?:alpenrammler|pornodeutsch)\.(?:com|xxx)/[^"\']+)["\']',
                part)
            title_m = re.search(r'<(?:span|h\d)[^>]*>\s*([^<]{5,}?)\s*</(?:span|h\d)>', part)
            if href_m:
                url = href_m.group(1)
            if title_m:
                title = title_m.group(1).strip()

        if not url or not title:
            continue

        thumb_m = re.search(r'src=["\']([^"\']+wp-content/uploads/[^"\']+\.(?:jpg|png|webp))["\']', part)
        thumb = thumb_m.group(1) if thumb_m else ''

        dur_m = re.search(r'class=["\'][^"\']*duration[^"\']*["\'][^>]*>.*?</i>\s*([^<]+)<', part, re.S)
        if not dur_m:
            dur_m = re.search(r'fa-clock[^<]*</i>\s*([^<]+)<', part, re.S)
        duration = dur_m.group(1).strip() if dur_m else ''

        views_m = re.search(r'class=["\'][^"\']*views[^"\']*["\'][^>]*>.*?</i>\s*([^<]+)<', part, re.S)
        if not views_m:
            views_m = re.search(r'fa-eye[^<]*</i>\s*([^<]+)<', part, re.S)
        views = views_m.group(1).strip() if views_m else ''

        items.append({
            'post_id': post_id,
            'url': url,
            'title': title,
            'thumb': thumb,
            'duration': duration,
            'views': views,
        })
    return items

def _parse_next_page(html, current_url):
    pag_m = re.search(r'<div[^>]*class=["\'][^"\']*pagination[^"\']*["\'][^>]*>(.*?)</div>', html, re.S)
    if not pag_m:
        return None
    pag = pag_m.group(1)
    next_m = re.search(r'href="(https://alpenrammler\.com/[^"]+/page/\d+[^"]*)"[^>]*class=["\'][^"\']*next[^"\']*["\']', pag)
    if not next_m:
        next_m = re.search(r'class=["\'][^"\']*next[^"\']*["\'][^>]*href="(https://[^"]+)"', pag)
    if not next_m:
        links = re.findall(r'href="(https://[^"]+/page/(\d+)[^"]*)"', pag)
        if links:
            current_page = _page_from_url(current_url)
            for lurl, lpage in links:
                if int(lpage) == current_page + 1:
                    return lurl
        return None
    return next_m.group(1)

def _page_from_url(url):
    m = re.search(r'/page/(\d+)', url)
    return int(m.group(1)) if m else 1

def _fetch_plot_for_item(item):
    """Holt og:description von der Video-Einzelseite (für Threading)."""
    try:
        html = _request(item['url'])
        if html:
            item['plot'] = get_video_plot(html)
    except Exception:
        item['plot'] = ''
    return item


def _data_saver():
    try:
        return ADDON.getSetting('data_saver') == 'true'
    except Exception:
        return False


def get_video_listing(page_url):
    html = _request(page_url)
    if not html:
        return [], None
    items = _parse_articles(html)
    _log('get_video_listing url=%s items=%d' % (page_url, len(items)))

    if not _data_saver():
        try:
            from concurrent.futures import ThreadPoolExecutor, as_completed
            with ThreadPoolExecutor(max_workers=8) as ex:
                futures = {ex.submit(_fetch_plot_for_item, item): item for item in items}
                for f in as_completed(futures):
                    pass
        except Exception as e:
            _log('get_video_listing threading error: %s' % e)
            for item in items:
                item.setdefault('plot', '')
    else:
        for item in items:
            item['plot'] = ''

    next_page = _parse_next_page(html, page_url)
    return items, next_page

def get_categories():
    return CATEGORIES

def get_stories(page_url=None):
    url = page_url or (BASE_URL + '/blog-category/erotische-sexgeschichten/')
    html = _request(url)
    if not html:
        return [], None
    items = []
    for m in re.finditer(r'<article[^>]+>(.*?)</article>', html, re.S):
        art = m.group(1)
        href_m = re.search(r'href="(https://alpenrammler\.com/blog/[^"]+)"\s+title="([^"]+)"', art)
        if not href_m:
            href_m = re.search(r'<a\s+href="(https://alpenrammler\.com/blog/[^"]+)"[^>]*>([^<]+)<', art)
        if not href_m:
            continue
        items.append({
            'url': href_m.group(1),
            'title': href_m.group(2).strip(),
            'thumb': '',
            'type': 'story',
        })
    next_page = _parse_next_page(html, url)
    return items, next_page

def get_story_text(url):
    html = _request(url)
    if not html:
        return '', ''
    title_m = re.search(r'<h1[^>]*class=["\'][^"\']*entry-title[^"\']*["\'][^>]*>([^<]+)<', html)
    title = title_m.group(1).strip() if title_m else ''
    content_m = re.search(r'<div[^>]*class=["\'][^"\']*entry-content[^"\']*["\'][^>]*>(.*?)</div>\s*(?:</div>|<aside)', html, re.S)
    if content_m:
        raw = content_m.group(1)
        raw = re.sub(r'<[^>]+>', '', raw)
        raw = re.sub(r'\s{3,}', '\n\n', raw).strip()
        return title, raw
    return title, ''

def get_video_plot(html):
    """Extracts og:description from already-fetched HTML as plot text."""
    m = re.search(r'<meta\s+property=["\']og:description["\']\s+content=["\'](.*?)["\']', html, re.S)
    if m:
        plot = m.group(1).strip()
        plot = re.sub(r'&amp;', '&', plot)
        plot = re.sub(r'&quot;', '"', plot)
        plot = re.sub(r'&#(\d+);', lambda x: chr(int(x.group(1))), plot)
        return plot
    return ''


def get_video_sources(post_url, post_id):
    html = _request(post_url)
    if not html:
        return [], ''

    plot = get_video_plot(html)
    sources = []

    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\'][^>]*>', html, re.I)
    _log('get_video_sources post_id=%s iframes=%s' % (post_id, iframes))

    for src in iframes:
        if any(h in src for h in ['xhamster', 'xvideos', 'pornhub', 'xnxx', 'dood', 'streamtape',
                                   'voe', 'upstream', 'mixdrop', 'mp4upload', 'vidoza',
                                   'fantecio', 'sexfilme', 'alpenporno', 'pornodeutsch',
                                   'lapippa', 'pornoente', 'pornohirsch']):
            sources.append({'label': _host_label(src), 'url': src})

    vx_data = re.findall(r'data-(?:src|id|url)=["\']([^"\']+)["\']', html)
    _log('get_video_sources vx_data=%s' % vx_data[:5])
    for ds in vx_data:
        if ds.startswith('http') or ds.startswith('//'):
            if not ds.startswith('http'):
                ds = 'https:' + ds
            sources.append({'label': _host_label(ds), 'url': ds})

    direct = re.findall(r'["\']((https?://[^"\']+\.(?:mp4|m3u8)(?:\?[^"\']*)?)["\'])', html)
    for _, url in direct:
        if 'videopreview' in url or 'xvideos-cdn' in url:
            continue
        sources.append({'label': 'Direct', 'url': url})

    if not sources and post_id:
        vx_sources = _resolve_vx_api(post_id, post_url)
        _log('get_video_sources fantecio sources=%s' % vx_sources)
        sources.extend(vx_sources)

    _log('get_video_sources total sources=%d plot_len=%d' % (len(sources), len(plot)))
    return sources, plot

def _resolve_vx_api(post_id, referer, site_base='https://alpenrammler.com'):
    vx_url = 'https://www.fantecio.com/VX/SI/Tiny?w=' + str(post_id)
    try:
        from urllib.request import urlopen, Request
        from urllib.error import URLError, HTTPError
    except ImportError:
        from urllib2 import urlopen, Request, URLError, HTTPError

    headers = {
        'User-Agent': UA,
        'Referer': referer,
        'Origin': site_base,
        'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
        'Accept-Language': 'de-DE,de;q=0.9',
    }
    req = Request(vx_url, headers=headers)
    try:
        resp = urlopen(req, timeout=20)
        html = resp.read().decode('utf-8', errors='replace')
        _log('_resolve_vx_api OK bytes=%d' % len(html))
        return _parse_vx_html(html)
    except Exception as e:
        _log('_resolve_vx_api ERROR %s' % e)
        return []

def _parse_vx_html(html):
    sources = []
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\'][^>]*>', html, re.I)
    for src in iframes:
        sources.append({'label': _host_label(src), 'url': src})
    links = re.findall(r'href=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*vx-(?:host|video)[^"\']*["\']', html)
    for lnk in links:
        sources.append({'label': _host_label(lnk), 'url': lnk})
    data_srcs = re.findall(r'data-(?:src|href|url|video)=["\']([^"\']+)["\']', html)
    for ds in data_srcs:
        if ds.startswith('http') or ds.startswith('//'):
            if not ds.startswith('http'):
                ds = 'https:' + ds
            sources.append({'label': _host_label(ds), 'url': ds})
    return sources

def _host_label(url):
    parsed = urlparse(url)
    host = parsed.netloc.replace('www.', '').replace('embed.', '')
    parts = host.split('.')
    return parts[0].capitalize() if parts else host

def get_pornodeutsch_categories():
    return CATEGORIES_PD

def get_pornodeutsch_listing(page_url):
    """Wie get_video_listing, aber fuer pornodeutsch.xxx."""
    html = _request(page_url, referer=BASE_URL_PD)
    if not html:
        return [], None
    items = []
    parts = re.split(r'(?=<article[\s>])', html)
    for part in parts:
        if not part.strip().startswith('<article'):
            continue
        post_id = ''
        pid_m = re.search(r'data-post-id=["\'](\d+)["\']', part)
        if pid_m:
            post_id = pid_m.group(1)
        else:
            pid_m = re.search(r'class=["\'][^"\']*\bpost-(\d+)\b', part)
            if pid_m:
                post_id = pid_m.group(1)

        url = ''
        title = ''
        href_m = re.search(
            r'href=["\']([^"\']+/pornos/[^"\']+)["\'][^>]*title=["\']([^"\']+)["\']',
            part)
        if not href_m:
            href_m = re.search(
                r'title=["\']([^"\']+)["\'][^>]*href=["\']([^"\']+/pornos/[^"\']+)["\']',
                part)
            if href_m:
                title = href_m.group(1)
                url   = href_m.group(2)
                href_m = None
        if href_m:
            url   = href_m.group(1)
            title = href_m.group(2)
        if not url:
            href_m  = re.search(r'href=["\'](https://pornodeutsch\.xxx/pornos/[^"\']+)["\']', part)
            title_m = re.search(r'<(?:span|header)[^>]*>\s*([^<]{5,}?)\s*</(?:span|header)>', part)
            if href_m: url   = href_m.group(1)
            if title_m: title = title_m.group(1).strip()

        if not url or not title:
            continue

        thumb_m = re.search(
            r'(?:data-main-thumb|src)=["\']([^"\']+wp-content/uploads/[^"\']+\.(?:jpg|png|webp))["\']',
            part)
        thumb = thumb_m.group(1) if thumb_m else ''

        dur_m = re.search(r'class=["\'][^"\']*duration[^"\']*["\'][^>]*>.*?</i>\s*([^<]+)<', part, re.S)
        if not dur_m:
            dur_m = re.search(r'fa-clock[^<]*</i>\s*([^<]+)<', part, re.S)
        duration = dur_m.group(1).strip() if dur_m else ''

        views_m = re.search(r'class=["\'][^"\']*views[^"\']*["\'][^>]*>.*?</i>\s*([^<]+)<', part, re.S)
        if not views_m:
            views_m = re.search(r'fa-eye[^<]*</i>\s*([^<]+)<', part, re.S)
        views = views_m.group(1).strip() if views_m else ''

        items.append({
            'post_id': post_id,
            'url':     url,
            'title':   title,
            'thumb':   thumb,
            'duration': duration,
            'views':   views,
        })

    _log('get_pornodeutsch_listing url=%s items=%d' % (page_url, len(items)))

    if not _data_saver():
        try:
            from concurrent.futures import ThreadPoolExecutor, as_completed
            with ThreadPoolExecutor(max_workers=8) as ex:
                futures = {ex.submit(_fetch_plot_for_item, item): item for item in items}
                for f in as_completed(futures):
                    pass
        except Exception as e:
            _log('get_pornodeutsch_listing threading error: %s' % e)
            for item in items:
                item.setdefault('plot', '')
    else:
        for item in items:
            item['plot'] = ''

    next_page = _parse_next_page(html, page_url)
    return items, next_page

def get_sexfilme_listing(page_url):
    html = _request(page_url, referer=BASE_URL_SF)
    if not html:
        return [], None
    items = []
    for m in re.finditer(
            r'<a\s+href="(/video/[^"]+)"\s+class="video-card">(.*?)</a>',
            html, re.S):
        path = m.group(1)
        card = m.group(2)

        title_m = re.search(r'<h3[^>]*>(.*?)</h3>', card, re.S)
        title = re.sub(r'<[^>]+>', '', title_m.group(1)).strip() if title_m else ''
        title = title.lstrip('*').strip()

        thumb_m = re.search(r'<img[^>]+src="(/thumbs/[^"]+)"', card)
        thumb = (BASE_URL_SF + thumb_m.group(1)) if thumb_m else ''

        dur_m = re.search(r'class="video-duration">([^<]+)<', card)
        duration = dur_m.group(1).strip() if dur_m else ''

        views_m = re.search(r'<span>(\d[\d\s.]*)\s+Aufruf', card)
        views = views_m.group(1).strip() if views_m else ''

        pid_m = re.search(r'/thumbs/(\d+)/', card)
        post_id = pid_m.group(1) if pid_m else path.split('/')[-1]

        if title:
            items.append({
                'post_id':  post_id,
                'url':      BASE_URL_SF + path,
                'title':    title,
                'thumb':    thumb,
                'duration': duration,
                'views':    views,
            })

    next_page = None
    next_m = re.search(r'<a[^>]+href="(/[^"]*page[^"]*)"[^>]*>\s*(?:&raquo;|>>|Weiter)', html, re.I)
    if next_m:
        next_page = BASE_URL_SF + next_m.group(1)
    else:
        cur = _page_from_url(page_url)
        nm2 = re.search(r'href="(/[^"]+/page/%d[^"]*)"' % (cur + 1), html)
        if nm2:
            next_page = BASE_URL_SF + nm2.group(1)

    _log('get_sexfilme_listing url=%s items=%d next=%s' % (page_url, len(items), next_page))
    return items, next_page

def get_sexfilme_sources(video_url):
    html = _request(video_url, referer=BASE_URL_SF)
    if not html:
        return []
    sources = []
    for src in re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I):
        if src.startswith('//'):
            src = 'https:' + src
        if src.startswith('http'):
            sources.append({'label': _host_label(src), 'url': src})
    for src in re.findall(r'<source[^>]+src=["\']([^"\']+)["\']', html, re.I):
        if src.startswith('http'):
            sources.append({'label': 'Direct', 'url': src})
    for url in re.findall(r'["\']((https?://[^"\']+\.(?:mp4|m3u8)(?:\?[^"\']*)?)["\'])', html):
        sources.append({'label': 'Direct', 'url': url[0]})
    for ds in re.findall(r'data-(?:src|video|url)=["\']([^"\']+)["\']', html):
        if ds.startswith('http'):
            sources.append({'label': _host_label(ds), 'url': ds})
    _log('get_sexfilme_sources url=%s sources=%d' % (video_url, len(sources)))
    return sources


# ---------------------------------------------------------------------------
# Gemeinsamer Parser für retrotube/ultimatube WordPress-Themes
# (bravoporno.net, xnxxpornos.com)
# ---------------------------------------------------------------------------

def _parse_retrotube_listing(html, base_url):
    """Parst Artikel-Listings der retrotube/ultimatube WP-Themes."""
    items = []
    parts = re.split(r'(?=<article[\s>])', html)
    for part in parts:
        if not part.strip().startswith('<article'):
            continue

        # Post-ID
        pid_m = re.search(r'data-post-id=["\'](\d+)["\']', part)
        if not pid_m:
            pid_m = re.search(r'class=["\'][^"\']*\bpost-(\d+)\b', part)
        post_id = pid_m.group(1) if pid_m else ''

        # Thumbnail (data-main-thumb hat Vorrang)
        thumb_m = re.search(r'data-main-thumb=["\']([^"\']+)["\']', part)
        if not thumb_m:
            thumb_m = re.search(
                r'<img[^>]+src=["\']([^"\']+wp-content/uploads/[^"\']+\.(?:jpg|png|webp))["\']',
                part)
        thumb = thumb_m.group(1) if thumb_m else ''

        # URL + Titel aus <a href="BASE/..." title="...">
        href_m = re.search(
            r'<a\s+href=["\'](' + re.escape(base_url) + r'/[^"\']+)["\'][^>]*'
            r'title=["\']([^"\']+)["\']',
            part)
        if not href_m:
            href_m = re.search(
                r'href=["\'](' + re.escape(base_url) + r'/[^"\']+)["\'][^>]*'
                r'title=["\']([^"\']+)["\']',
                part)
        if not href_m:
            continue
        url   = href_m.group(1)
        title = href_m.group(2)

        # Dauer – <span class="duration"> (mit oder ohne Icon)
        dur_m = re.search(r'<span\s+class=["\']duration["\'][^>]*>(.*?)</span>', part, re.S)
        if not dur_m:
            dur_m = re.search(r'fa-clock[^<]*</i>\s*([^<]+)<', part, re.S)
        duration = ''
        if dur_m:
            duration = re.sub(r'<[^>]+>', '', dur_m.group(1)).strip()

        # Views – <span class="views">
        views_m = re.search(r'<span\s+class=["\']views["\'][^>]*>(.*?)</span>', part, re.S)
        if not views_m:
            views_m = re.search(r'fa-eye[^<]*</i>\s*([^<]+)<', part, re.S)
        views = ''
        if views_m:
            views = re.sub(r'<[^>]+>', '', views_m.group(1)).strip()

        items.append({
            'post_id':  post_id,
            'url':      url,
            'title':    title,
            'thumb':    thumb,
            'duration': duration,
            'views':    views,
        })
    return items


def _parse_retrotube_next_page(html, current_url):
    """Nächste Seite für retrotube/ultimatube pagination."""
    cur = _page_from_url(current_url)
    pag_m = re.search(
        r'class=["\'][^"\']*pagination[^"\']*["\'][^>]*>(.*?)(?:</div>|</nav>)',
        html, re.S)
    if not pag_m:
        return None
    pag = pag_m.group(1)
    next_num = cur + 1
    # Suche /page/N+1/
    m = re.search(r'href=["\']([^"\']+/page/%d/[^"\']*)["\']' % next_num, pag)
    if m:
        return m.group(1)
    # Fallback: class="next"
    m2 = re.search(r'href=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*\bnext\b', pag)
    if m2:
        return m2.group(1)
    return None


def _get_generic_video_sources(post_url, post_id, site_base):
    """Generischer Quellen-Extraktor für externe Partnersites."""
    html = _request(post_url, referer=site_base)
    if not html:
        return []
    sources = []
    known_hosts = [
        'xhamster', 'xvideos', 'pornhub', 'xnxx', 'dood', 'streamtape',
        'voe', 'upstream', 'mixdrop', 'mp4upload', 'vidoza',
        'fantecio', 'lapippa', 'alpenporno',
        'pornoente', 'pornohirsch',
    ]
    for src in re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\'][^>]*>', html, re.I):
        if any(h in src for h in known_hosts):
            sources.append({'label': _host_label(src), 'url': src})
    # Direkte MP4/M3U8
    for m in re.findall(r'["\']((https?://[^"\']+\.(?:mp4|m3u8)(?:\?[^"\']*)?)["\'])', html):
        sources.append({'label': 'Direct', 'url': m[0]})
    # VX-API Fallback (gleiche Plattform wie alpenrammler)
    if not sources and post_id:
        vx = _resolve_vx_api(post_id, post_url, site_base)
        _log('_get_generic_video_sources vx=%s' % vx)
        sources.extend(vx)
    return sources


# ---------------------------------------------------------------------------
# BravoPorno.net
# ---------------------------------------------------------------------------

def get_bravoporno_categories():
    return CATEGORIES_BP


def get_bravoporno_listing(page_url):
    html = _request(page_url, referer=BASE_URL_BP)
    if not html:
        return [], None
    items = _parse_retrotube_listing(html, BASE_URL_BP)
    _log('get_bravoporno_listing url=%s items=%d' % (page_url, len(items)))
    next_page = _parse_retrotube_next_page(html, page_url)
    return items, next_page


def get_bravoporno_sources(post_url, post_id):
    return _get_generic_video_sources(post_url, post_id, BASE_URL_BP)


# ---------------------------------------------------------------------------
# XNXXPornos.com
# ---------------------------------------------------------------------------

def get_xnxx_categories():
    return CATEGORIES_XNXX


def get_xnxx_listing(page_url):
    html = _request(page_url, referer=BASE_URL_XNXX)
    if not html:
        return [], None
    items = _parse_retrotube_listing(html, BASE_URL_XNXX)
    _log('get_xnxx_listing url=%s items=%d' % (page_url, len(items)))
    next_page = _parse_retrotube_next_page(html, page_url)
    return items, next_page


def get_xnxx_sources(post_url, post_id):
    return _get_generic_video_sources(post_url, post_id, BASE_URL_XNXX)


# ---------------------------------------------------------------------------
# AlpenPorno.com – Sexgeschichten
# ---------------------------------------------------------------------------

def get_alpenporno_story_categories():
    return STORY_CATS_AP


def get_alpenporno_stories(page_url=None):
    url = page_url or (BASE_URL_AP + '/sexgeschichten/')
    html = _request(url)
    if not html:
        return [], None
    items = []
    for m in re.finditer(r'<article[^>]+>(.*?)</article>', html, re.S):
        art = m.group(1)
        # Href + Titel
        href_m = re.search(
            r'href=["\'](' + re.escape(BASE_URL_AP) + r'/sexgeschichten/[^"\']+)["\']'
            r'[^>]*(?:title=["\']([^"\']+)["\'])?',
            art)
        if not href_m:
            href_m = re.search(
                r'<a\s+href=["\'](' + re.escape(BASE_URL_AP) + r'/sexgeschichten/[^"\']+)["\'][^>]*>'
                r'([^<]+)<',
                art)
        if not href_m:
            continue
        story_url = href_m.group(1)
        title = (href_m.group(2) or '').strip()
        if not title:
            t_m = re.search(r'<h[1-4][^>]*>([^<]+)<', art)
            title = t_m.group(1).strip() if t_m else story_url.rstrip('/').split('/')[-1]
        items.append({'url': story_url, 'title': title})
    next_page = _parse_next_page(html, url)
    return items, next_page


def get_alpenporno_story_text(url):
    html = _request(url)
    if not html:
        return '', ''
    title_m = re.search(
        r'<h1[^>]*class=["\'][^"\']*entry-title[^"\']*["\'][^>]*>([^<]+)<', html)
    title = title_m.group(1).strip() if title_m else ''
    content_m = re.search(
        r'<div[^>]*class=["\'][^"\']*entry-content[^"\']*["\'][^>]*>(.*?)</div>\s*(?:</div>|<aside)',
        html, re.S)
    if content_m:
        raw = content_m.group(1)
        raw = re.sub(r'<[^>]+>', '', raw)
        raw = re.sub(r'\s{3,}', '\n\n', raw).strip()
        return title, raw
    return title, ''
