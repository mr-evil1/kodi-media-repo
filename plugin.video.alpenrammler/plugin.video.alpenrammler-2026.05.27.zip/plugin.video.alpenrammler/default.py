import sys
import re

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

try:
    from urllib.parse import parse_qsl, urlencode, quote_plus
except ImportError:
    from urlparse import parse_qsl
    from urllib import urlencode, quote_plus

sys.path.insert(0, xbmcaddon.Addon().getAddonInfo('path') + '/resources/lib')
import scraper
import resolver
import storage

ADDON    = xbmcaddon.Addon()
HANDLE   = int(sys.argv[1])
BASE     = sys.argv[0]
BASE_URL = 'https://alpenrammler.com'
ICON     = ADDON.getAddonInfo('path') + '/icon.png'
FANART   = ADDON.getAddonInfo('path') + '/fanart.jpg'

_HOME      = xbmcgui.Window(10000)
_AUTH_PROP = 'AlpenRammler_SessionAuth'

def _dbg(msg):
    try:
        if ADDON.getSetting('enable_debug') == 'true':
            xbmc.log('[AlpenRammler DEBUG] ' + str(msg), xbmc.LOGINFO)
    except Exception:
        pass

def _info(msg):
    xbmc.log('[AlpenRammler] ' + str(msg), xbmc.LOGINFO)

def _url(**kwargs):
    return BASE + '?' + urlencode(
        {k: v for k, v in kwargs.items() if v is not None}
    )

def _params():
    return dict(parse_qsl(sys.argv[2][1:]))

def _check_password():
    if ADDON.getSetting('enable_password_lock') != 'true':
        return True
    stored = ADDON.getSetting('password')
    if not stored:
        return True
    if _HOME.getProperty(_AUTH_PROP) == '1':
        return True
    entered = xbmcgui.Dialog().input(
        'Passwort eingeben', option=xbmcgui.ALPHANUM_HIDE_INPUT
    )
    if not entered:
        return False
    if entered == stored:
        _HOME.setProperty(_AUTH_PROP, '1')
        return True
    return False

def _duration_secs(duration):
    """'12:34' oder '1:23:45' → int Sekunden, sonst 0."""
    if not duration:
        return 0
    parts = duration.split(':')
    try:
        if len(parts) == 2:
            return int(parts[0]) * 60 + int(parts[1])
        if len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
    except ValueError:
        pass
    return 0

def _make_video_li(title, thumb='', duration='', views='', plot='',
                   post_id='', post_url='', in_favorites=False):
    """
    Erstellt ein vollständiges ListItem für ein Video inkl. Kontextmenü.
    """
    li = xbmcgui.ListItem(title)
    li.setArt({'thumb': thumb, 'icon': thumb})
    li.setProperty('IsPlayable', 'true')

    info = {'title': title}
    secs = _duration_secs(duration)
    if secs:
        info['duration'] = secs
    if plot:
        info['plot'] = plot
    elif views:
        info['plot'] = 'Views: ' + views
    li.setInfo('video', info)

    ctx = []

    if in_favorites:
        ctx.append((
            'Titel bearbeiten',
            'RunPlugin(%s)' % _url(action='fav_edit', post_id=post_id,
                                   title=title)
        ))
        ctx.append((
            'Aus Meine Videos entfernen',
            'RunPlugin(%s)' % _url(action='fav_remove', post_id=post_id)
        ))
    else:
        ctx.append((
            'Zu Meine Videos hinzufügen',
            'RunPlugin(%s)' % _url(action='fav_add', post_id=post_id,
                                   title=title, thumb=thumb,
                                   duration=duration, views=views,
                                   post_url=post_url)
        ))

    ctx.append((
        'Aus Verlauf entfernen',
        'RunPlugin(%s)' % _url(action='hist_remove', post_id=post_id)
    ))

    li.addContextMenuItems(ctx, replaceItems=False)

    return li

def root():
    _dbg('root()')
    favs = storage.favorites_get()
    hist = storage.history_get()

    fav_count  = len(favs)
    hist_count = len(hist)

    my_label = 'Meine Videos'
    if fav_count or hist_count:
        my_label += '  [COLOR grey](%d gespeichert - %d gesehen)[/COLOR]' % (
            fav_count, hist_count
        )
    li_my = xbmcgui.ListItem(my_label)
    li_my.setArt({'thumb': ICON, 'icon': ICON, 'fanart': FANART})
    xbmcplugin.addDirectoryItem(HANDLE, _url(action='my_videos'), li_my, True)

    entries = [
        ('Suche',          {'action': 'search'}),
        ('Neue Videos',    {'action': 'listing',
                            'page_url': BASE_URL + '/neue-pornos-und-sexfilme/'}),
        ('Top Videos',     {'action': 'listing',
                            'page_url': BASE_URL + '/top-pornos-und-sexfilme/'}),
        ('Lange Videos',   {'action': 'listing',
                            'page_url': BASE_URL + '/lange-pornos-und-sexfilme/'}),
        ('Kategorien',     {'action': 'categories'}),
        ('Porno Deutsch',  {'action': 'pd_menu'}),
        ('Sexfilme',       {'action': 'sf_listing',
                            'page_url': 'https://www.sexfilme.xxx/'}),
        ('Sexgeschichten', {'action': 'stories'}),
        ('Einstellungen',  {'action': 'settings'}),
    ]
    for label, params in entries:
        li = xbmcgui.ListItem(label)
        li.setArt({'thumb': ICON, 'icon': ICON, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(HANDLE, _url(**params), li, True)

    xbmcplugin.endOfDirectory(HANDLE)

def show_my_videos():
    """Zwei Unterordner: Gespeicherte + Verlauf."""
    _dbg('show_my_videos()')
    favs = storage.favorites_get()
    hist = storage.history_get()

    fav_li = xbmcgui.ListItem(
        'Gespeicherte Videos  [COLOR grey](%d)[/COLOR]' % len(favs)
    )
    fav_li.setArt({'thumb': ICON, 'icon': ICON, 'fanart': FANART})
    xbmcplugin.addDirectoryItem(
        HANDLE, _url(action='my_favorites'), fav_li, True
    )

    hist_li = xbmcgui.ListItem(
        'Zuletzt angesehen  [COLOR grey](%d / max 10)[/COLOR]' % len(hist)
    )
    hist_li.setArt({'thumb': ICON, 'icon': ICON, 'fanart': FANART})
    hist_li.addContextMenuItems([
        ('Gesamten Verlauf löschen',
         'RunPlugin(%s)' % _url(action='hist_clear'))
    ], replaceItems=False)
    xbmcplugin.addDirectoryItem(
        HANDLE, _url(action='my_history'), hist_li, True
    )

    xbmcplugin.endOfDirectory(HANDLE)

def show_my_favorites():
    """Liste aller manuell gespeicherten Videos."""
    _dbg('show_my_favorites()')
    favs = storage.favorites_get()

    if not favs:
        li = xbmcgui.ListItem('[COLOR grey]Noch keine Videos gespeichert.[/COLOR]')
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for item in favs:
        pid = item['post_id']
        li = _make_video_li(
            title=item['title'], thumb=item['thumb'],
            duration=item['duration'], views=item['views'],
            post_id=pid, post_url=item['post_url'], in_favorites=True
        )
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action='video', post_url=item['post_url'], post_id=pid,
                 title=item['title'], thumb=item['thumb'],
                 duration=item['duration'], views=item['views']),
            li, False
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def show_my_history():
    """Liste der letzten 10 gestarteten Videos."""
    _dbg('show_my_history()')
    hist = storage.history_get()

    if not hist:
        li = xbmcgui.ListItem('[COLOR grey]Noch keine Videos angesehen.[/COLOR]')
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for item in hist:
        pid  = item['post_id']
        in_fav = storage.favorites_is(pid)
        when = item.get('last_watched', '')
        label = item['title']
        if when:
            label += '  [COLOR grey](%s)[/COLOR]' % when

        li = _make_video_li(
            title=label, thumb=item['thumb'],
            duration=item['duration'], views=item['views'],
            post_id=pid, post_url=item['post_url'], in_favorites=in_fav
        )
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action='video', post_url=item['post_url'], post_id=pid,
                 title=item['title'], thumb=item['thumb'],
                 duration=item['duration'], views=item['views']),
            li, False
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def fav_add(params):
    pid = params.get('post_id', '')
    _dbg('fav_add post_id=%s' % pid)
    storage.favorites_add({
        'post_id':  pid,
        'title':    params.get('title', ''),
        'post_url': params.get('post_url', ''),
        'thumb':    params.get('thumb', ''),
        'duration': params.get('duration', ''),
        'views':    params.get('views', ''),
    })
    xbmcgui.Dialog().notification(
        'Meine Videos', 'Hinzugefügt: ' + params.get('title', ''),
        xbmcgui.NOTIFICATION_INFO, 2500
    )
    xbmc.executebuiltin('Container.Refresh')

def fav_remove(params):
    pid = params.get('post_id', '')
    _dbg('fav_remove post_id=%s' % pid)
    if xbmcgui.Dialog().yesno('Entfernen',
                               'Video aus Meine Videos entfernen?'):
        storage.favorites_remove(pid)
        xbmcgui.Dialog().notification(
            'Meine Videos', 'Entfernt',
            xbmcgui.NOTIFICATION_INFO, 2000
        )
        xbmc.executebuiltin('Container.Refresh')

def fav_edit(params):
    pid       = params.get('post_id', '')
    old_title = params.get('title', '')
    _dbg('fav_edit post_id=%s' % pid)
    new_title = xbmcgui.Dialog().input('Titel bearbeiten', defaultt=old_title)
    if new_title and new_title != old_title:
        storage.favorites_edit_title(pid, new_title)
        xbmc.executebuiltin('Container.Refresh')

def hist_remove(params):
    pid = params.get('post_id', '')
    _dbg('hist_remove post_id=%s' % pid)
    storage.history_remove(pid)
    xbmc.executebuiltin('Container.Refresh')

def hist_clear(params):
    _dbg('hist_clear()')
    if xbmcgui.Dialog().yesno('Verlauf löschen',
                               'Gesamten Verlauf löschen?'):
        storage.history_clear()
        xbmc.executebuiltin('Container.Refresh')

def show_categories():
    _dbg('show_categories()')
    cats = scraper.get_categories()
    _dbg('Kategorien: %d' % len(cats))
    for name, slug in cats:
        cat_url = BASE_URL + '/category/' + slug + '/'
        li = xbmcgui.ListItem(name)
        xbmcplugin.addDirectoryItem(
            HANDLE, _url(action='listing', page_url=cat_url), li, True
        )
    xbmcplugin.endOfDirectory(HANDLE)

def show_listing(page_url):
    _dbg('show_listing() url=%s' % page_url)
    items, next_page = scraper.get_video_listing(page_url)
    _dbg('Listing: %d Items' % len(items))

    for item in items:
        pid     = item['post_id']
        in_fav  = storage.favorites_is(pid)
        label   = item['title']
        if item.get('duration'):
            label += '  [' + item['duration'] + ']'
        if in_fav:
            label = '[FAV] ' + label

        cached_plot = item.get('plot') or storage.plot_get(pid)
        li = _make_video_li(
            title=item['title'], thumb=item['thumb'],
            duration=item.get('duration', ''), views=item.get('views', ''),
            plot=cached_plot,
            post_id=pid, post_url=item['url'], in_favorites=in_fav
        )
        li.setLabel(label)
        if cached_plot and pid:
            storage.plot_save(pid, cached_plot)

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action='video', post_url=item['url'], post_id=pid,
                 title=item['title'], thumb=item['thumb'],
                 duration=item.get('duration', ''),
                 views=item.get('views', '')),
            li, False
        )

    if next_page:
        li_next = xbmcgui.ListItem(
            '[COLOR yellow]>> Weiter (Seite %s)[/COLOR]' %
            str(scraper._page_from_url(next_page))
        )
        xbmcplugin.addDirectoryItem(
            HANDLE, _url(action='listing', page_url=next_page), li_next, True
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def show_video_sources(params):
    post_url = params.get('post_url', '')
    post_id  = params.get('post_id', '')
    title    = params.get('title', '')
    thumb    = params.get('thumb', '')
    duration = params.get('duration', '')
    views    = params.get('views', '')

    _dbg('show_video_sources() post_id=%s' % post_id)

    sources, plot = scraper.get_video_sources(post_url, post_id)
    _dbg('Quellen: %d  → %s' % (len(sources), [s.get('url') for s in sources]))

    if plot and post_id:
        storage.plot_save(post_id, plot)

    if not sources:
        _dbg('KEINE Quellen')
        xbmcgui.Dialog().notification(
            'Alpenrammler', 'Keine Streams gefunden',
            xbmcgui.NOTIFICATION_WARNING
        )
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    storage.history_add({
        'post_id': post_id, 'title': title, 'post_url': post_url,
        'thumb': thumb, 'duration': duration, 'views': views,
    })
    _dbg('Verlauf aktualisiert für post_id=%s' % post_id)

    if len(sources) == 1:
        _play_source(sources[0]['url'], title, thumb, duration, views, plot)
        return

    labels = [s['label'] for s in sources]
    _dbg('Quellen-Dialog: %s' % labels)
    idx = xbmcgui.Dialog().select('Quelle wählen', labels)
    _dbg('Auswahl: idx=%d' % idx)
    if idx < 0:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    _play_source(sources[idx]['url'], title, thumb, duration, views, plot)

def play_source(params):
    stream_url = params.get('stream_url', '')
    _dbg('play_source() stream_url=%s' % stream_url)
    _play_source(
        stream_url, params.get('title', ''), params.get('thumb', ''),
        params.get('duration', ''), params.get('views', ''), params.get('plot', '')
    )

def _play_source(stream_url, title, thumb, duration, views, plot=''):
    _dbg('_play_source() → resolver.resolve(%s)' % stream_url)
    resolved = resolver.resolve(stream_url)
    _dbg('resolver Ergebnis: %s' % resolved)

    if not resolved:
        _dbg('FEHLER: resolver → None')
        xbmcgui.Dialog().notification(
            'Alpenrammler', 'Stream konnte nicht aufgelöst werden',
            xbmcgui.NOTIFICATION_ERROR
        )
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(title, path=resolved)
    li.setArt({'thumb': thumb})
    info = {'title': title}
    secs = _duration_secs(duration)
    if secs:
        info['duration'] = secs
    if plot:
        info['plot'] = plot
    elif views:
        info['plot'] = 'Views: ' + views
    li.setInfo('video', info)
    li.setProperty('IsPlayable', 'true')

    if '.m3u8' in resolved:
        li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)
        _dbg('MIME: application/x-mpegURL')

    _dbg('setResolvedUrl HANDLE=%d  url=%s' % (HANDLE, resolved))
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

def show_stories(page_url=None):
    _dbg('show_stories()')
    items, next_page = scraper.get_stories(page_url)
    for item in items:
        li = xbmcgui.ListItem(item['title'])
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action='story', story_url=item['url'], title=item['title']),
            li, True
        )
    if next_page:
        li_n = xbmcgui.ListItem('[COLOR yellow]>> Weiter[/COLOR]')
        xbmcplugin.addDirectoryItem(
            HANDLE, _url(action='stories', page_url=next_page), li_n, True
        )
    xbmcplugin.endOfDirectory(HANDLE)

def show_story(params):
    story_url = params.get('story_url', '')
    title, text = scraper.get_story_text(story_url)
    _dbg('show_story() url=%s' % story_url)
    if not text:
        xbmcgui.Dialog().notification(
            'Alpenrammler', 'Text konnte nicht geladen werden',
            xbmcgui.NOTIFICATION_WARNING
        )
        xbmcplugin.endOfDirectory(HANDLE, False)
        return
    xbmcgui.Dialog().textviewer(title or params.get('title', ''), text)
    xbmcplugin.endOfDirectory(HANDLE, False)

def show_pd_menu():
    """Unterordner fuer pornodeutsch.xxx."""
    _dbg('show_pd_menu()')
    PD = 'https://pornodeutsch.xxx'
    entries = [
        ('Neue Videos',    {'action': 'pd_listing', 'page_url': PD + '/neu-auf-pornodeutsch/'}),
        ('Lange Videos',   {'action': 'pd_listing', 'page_url': PD + '/lange-pornos/'}),
        ('Kategorien',     {'action': 'pd_categories'}),
    ]
    for label, params in entries:
        li = xbmcgui.ListItem(label)
        li.setArt({'thumb': ICON, 'icon': ICON, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(HANDLE, _url(**params), li, True)
    xbmcplugin.endOfDirectory(HANDLE)

def show_pd_categories():
    _dbg('show_pd_categories()')
    PD = 'https://pornodeutsch.xxx'
    for name, slug in scraper.get_pornodeutsch_categories():
        li = xbmcgui.ListItem(name)
        li.setArt({'thumb': ICON, 'icon': ICON, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action='pd_listing', page_url=PD + '/kategorie/' + slug + '/'),
            li, True
        )
    xbmcplugin.endOfDirectory(HANDLE)

def show_pd_listing(page_url):
    """Video-Listing fuer pornodeutsch.xxx."""
    _dbg('show_pd_listing() url=%s' % page_url)
    items, next_page = scraper.get_pornodeutsch_listing(page_url)
    _dbg('PD Listing: %d Items' % len(items))

    for item in items:
        pid    = item['post_id']
        label  = item['title']
        if item.get('duration'):
            label += '  [' + item['duration'] + ']'

        plot = item.get('plot') or storage.plot_get(pid)
        li = xbmcgui.ListItem(label)
        li.setArt({'thumb': item['thumb'] or ICON,
                   'icon':  item['thumb'] or ICON,
                   'fanart': FANART})
        li.setProperty('IsPlayable', 'true')
        info = {'title': item['title']}
        secs = _duration_secs(item.get('duration', ''))
        if secs:
            info['duration'] = secs
        if plot:
            info['plot'] = plot
            storage.plot_save(pid, plot)
        elif item.get('views'):
            info['plot'] = 'Views: ' + item['views']
        li.setInfo('video', info)

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action='video', post_url=item['url'], post_id=pid,
                 title=item['title'], thumb=item['thumb'],
                 duration=item.get('duration', ''),
                 views=item.get('views', '')),
            li, False
        )

    if next_page:
        li_next = xbmcgui.ListItem(
            '[COLOR yellow]>> Weiter (Seite %s)[/COLOR]' %
            str(scraper._page_from_url(next_page))
        )
        xbmcplugin.addDirectoryItem(
            HANDLE, _url(action='pd_listing', page_url=next_page), li_next, True
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def show_sf_listing(page_url):
    """Video-Listing fuer sexfilme.xxx."""
    _dbg('show_sf_listing() url=%s' % page_url)
    items, next_page = scraper.get_sexfilme_listing(page_url)
    _dbg('SF Listing: %d Items' % len(items))

    if not items:
        li = xbmcgui.ListItem('[COLOR grey]Keine Videos gefunden.[/COLOR]')
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for item in items:
        label = item['title']
        if item.get('duration'):
            label += '  [' + item['duration'] + ']'

        li = xbmcgui.ListItem(label)
        li.setArt({'thumb': item['thumb'] or ICON,
                   'icon':  item['thumb'] or ICON,
                   'fanart': FANART})
        li.setProperty('IsPlayable', 'true')
        info = {'title': item['title']}
        secs = _duration_secs(item.get('duration', ''))
        if secs:
            info['duration'] = secs
        if item.get('views'):
            info['plot'] = 'Views: ' + item['views']
        li.setInfo('video', info)

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action='sf_video', post_url=item['url'],
                 title=item['title'], thumb=item['thumb'],
                 duration=item.get('duration', '')),
            li, False
        )

    if next_page:
        li_next = xbmcgui.ListItem('[COLOR yellow]>> Weiter[/COLOR]')
        xbmcplugin.addDirectoryItem(
            HANDLE, _url(action='sf_listing', page_url=next_page), li_next, True
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def show_sf_video(params):
    """Stream-Aufloesung fuer sexfilme.xxx."""
    post_url = params.get('post_url', '')
    title    = params.get('title', '')
    thumb    = params.get('thumb', '')
    duration = params.get('duration', '')

    _dbg('show_sf_video() url=%s' % post_url)
    sources = scraper.get_sexfilme_sources(post_url)
    _dbg('SF Quellen: %d' % len(sources))

    if not sources:
        xbmcgui.Dialog().notification(
            'Sexfilme', 'Keine Streams gefunden', xbmcgui.NOTIFICATION_WARNING
        )
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    if len(sources) == 1:
        _play_source(sources[0]['url'], title, thumb, duration, '')
        return

    labels = [s['label'] for s in sources]
    idx = xbmcgui.Dialog().select('Quelle waehlen', labels)
    if idx < 0:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    _play_source(sources[idx]['url'], title, thumb, duration, '')

def show_search(query=None, page_url=None):
    _dbg('show_search() query=%r page_url=%r' % (query, page_url))

    if page_url and query:
        search_url = page_url
    else:
        if not query:
            query = xbmcgui.Dialog().input('Stichwortsuche')
        if not query:
            xbmcplugin.endOfDirectory(HANDLE, False)
            return
        search_url = BASE_URL + '/?s=' + quote_plus(query)
    items, next_page = scraper.get_video_listing(search_url)
    _dbg('Suche "%s": %d Ergebnisse' % (query, len(items)))

    if not items:
        li = xbmcgui.ListItem('[COLOR grey]Keine Ergebnisse gefunden.[/COLOR]')
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for item in items:
        pid    = item['post_id']
        in_fav = storage.favorites_is(pid)
        label  = item['title']
        if item.get('duration'):
            label += '  [' + item['duration'] + ']'
        if in_fav:
            label = '[FAV] ' + label

        cached_plot = item.get('plot') or storage.plot_get(pid)
        li = _make_video_li(
            title=item['title'], thumb=item['thumb'],
            duration=item.get('duration', ''), views=item.get('views', ''),
            plot=cached_plot,
            post_id=pid, post_url=item['url'], in_favorites=in_fav
        )
        li.setLabel(label)
        if item['thumb']:
            li.setArt({'thumb': item['thumb'], 'fanart': FANART})
        if cached_plot and pid:
            storage.plot_save(pid, cached_plot)

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _url(action='video', post_url=item['url'], post_id=pid,
                 title=item['title'], thumb=item['thumb'],
                 duration=item.get('duration', ''),
                 views=item.get('views', '')),
            li, False
        )

    if next_page:
        li_next = xbmcgui.ListItem(
            '[COLOR yellow]>> Weiter (Seite %s)[/COLOR]' %
            str(scraper._page_from_url(next_page))
        )
        xbmcplugin.addDirectoryItem(
            HANDLE, _url(action='search', page_url=next_page, query=query),
            li_next, True
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def main():
    params = _params()
    action = params.get('action', '')
    _dbg('main() action=%r  HANDLE=%d' % (action, HANDLE))

    if not _check_password():
        xbmcgui.Dialog().notification(
            'Alpenrammler', 'Falsches Passwort', xbmcgui.NOTIFICATION_ERROR
        )
        xbmcplugin.endOfDirectory(HANDLE, False)
        return

    if action == 'fav_add':
        fav_add(params)
        return
    if action == 'fav_remove':
        fav_remove(params)
        return
    if action == 'fav_edit':
        fav_edit(params)
        return
    if action == 'hist_remove':
        hist_remove(params)
        return
    if action == 'hist_clear':
        hist_clear(params)
        return

    if not action:
        root()
    elif action == 'my_videos':
        show_my_videos()
    elif action == 'my_favorites':
        show_my_favorites()
    elif action == 'my_history':
        show_my_history()
    elif action == 'pd_menu':
        show_pd_menu()
    elif action == 'pd_categories':
        show_pd_categories()
    elif action == 'pd_listing':
        show_pd_listing(params.get('page_url', 'https://pornodeutsch.xxx/neu-auf-pornodeutsch/'))
    elif action == 'sf_listing':
        show_sf_listing(params.get('page_url', 'https://www.sexfilme.xxx/'))
    elif action == 'sf_video':
        show_sf_video(params)
    elif action == 'categories':
        show_categories()
    elif action == 'search':
        page_url = params.get('page_url')
        query    = params.get('query', '')
        show_search(query=query, page_url=page_url)
    elif action == 'listing':
        show_listing(params.get('page_url', BASE_URL + '/neue-pornos-und-sexfilme/'))
    elif action == 'video':
        show_video_sources(params)
    elif action == 'play':
        play_source(params)
    elif action == 'stories':
        show_stories(params.get('page_url'))
    elif action == 'story':
        show_story(params)
    elif action == 'settings':
        ADDON.openSettings()
        xbmcplugin.endOfDirectory(HANDLE, False)
    else:
        _dbg('Unbekannte action=%r' % action)
        root()

if __name__ == '__main__':
    main()
