import xbmc
import xbmcvfs
import json
import time
import urllib.request
import os

_BASE = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.vodkool/"
)
_SIG_FILE      = _BASE + "mediahubmx_signature.txt"
_CHANNEL_FILE  = _BASE + "channels_cache.json"

_LOKKE_URL     = "https://www.lokke.app/api/app/ping"
_LOKKE_UA      = "electron-fetch/1.0 electron (+https://github.com/arantes555/electron-fetch)"
_DEVICE_TOKEN  = "VnPX5t9tSWccXKBF5tIFuL_Fk8-003ZCH2Ns6as20OegRliqWc_Xz3dTVBxa7tN-HAVNp0wIN0sEyDfHtk_SrdE-qyVrtQ4P3ZWoY66k_BOrM1BNu8FxMbuINVzXYiiJABS0"
_DEVICE_ID     = "57eca59a-bfae-4300-a1d5-9e06061e985d"
_FIRST_START   = 1773926709904

_CATALOG_URL   = "https://www.kool.to/mediahubmx-catalog.json"
_CHANNEL_TTL   = 3600
_SIG_MARGIN    = 120
_POLL_INTERVAL = 30


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[vodkool.service] {msg}", level)



def _build_ping_payload():
    now_ms = int(time.time() * 1000)
    return json.dumps({
        "adblockEnabled": True,
        "appFocusTime": now_ms - _FIRST_START,
        "castConnected": False,
        "devMode": False,
        "firstAppStart": _FIRST_START,
        "hasAddon": True,
        "iap": {"supported": False},
        "ipLocation": {"city": "Ladendorf", "country": "AT", "ip": "178.113.252.97"},
        "lastAppStart": now_ms,
        "locale": "de",
        "metadata": {
            "app": {"platform": "electron"},
            "device": {"type": "desktop", "uniqueId": _DEVICE_ID},
            "os": {"abis": ["x64"], "host": "DESKTOP-2OH9ER9",
                   "name": "win32", "version": "Windows 10 Enterprise LTSC 2024"},
            "platform": {"isAndroid": False, "isElectron": True, "isIOS": False,
                         "isMobile": False, "isTV": False, "isWeb": False, "isWebTV": False},
            "version": {"binary": "4.1.1", "js": "4.1.1", "package": "app.lokke.main"},
        },
        "package": "app.lokke.main",
        "playDuration": 0,
        "playerActive": False,
        "process": "app",
        "proxy": {"autoServer": True, "enabled": False, "engine": "ss",
                  "id": "cz-prg", "ssVersion": 0, "supported": ["ss", "openvpn"]},
        "reason": "app-focus",
        "theme": "dark",
        "token": _DEVICE_TOKEN,
        "version": "4.1.1",
    }).encode("utf-8")


def _sig_valid_until(sig):
    try:
        import base64
        d = json.loads(base64.b64decode(sig + "==").decode())
        return json.loads(d["data"])["validUntil"]
    except Exception:
        return 0


def _sig_needs_refresh(sig):
    vu = _sig_valid_until(sig)
    if vu == 0:
        return True
    return (vu / 1000) - time.time() < _SIG_MARGIN


def _fetch_signature():
    try:
        req = urllib.request.Request(
            _LOKKE_URL,
            data=_build_ping_payload(),
            headers={
                "accept": "application/json",
                "content-type": "application/json; charset=utf-8",
                "user-agent": _LOKKE_UA,
                "Accept-Language": "de",
            },
        )
        with urllib.request.urlopen(req, timeout=20) as r:
            data = json.loads(r.read())
        sig = (
            data.get("addonSig") or data.get("signature") or
            data.get("mediahubmxSignature") or data.get("mediahubmx-signature") or
            data.get("token") or ""
        ).strip()
        if sig:
            _log("Neue Signatur erhalten")
            return sig
        _log(f"Ping OK aber keine Signatur. Keys: {list(data.keys())}", xbmc.LOGWARNING)
    except Exception as e:
        _log(f"Ping fehlgeschlagen: {e}", xbmc.LOGWARNING)
    return None


def _load_sig():
    try:
        if xbmcvfs.exists(_SIG_FILE):
            with xbmcvfs.File(_SIG_FILE, "r") as f:
                return f.read().strip() or None
    except Exception:
        pass
    return None


def _save_sig(sig):
    try:
        with xbmcvfs.File(_SIG_FILE, "w") as f:
            f.write(sig.strip())
    except Exception as e:
        _log(f"Signatur speichern fehlgeschlagen: {e}", xbmc.LOGWARNING)


def ensure_signature():
    sig = _load_sig()
    if sig and not _sig_needs_refresh(sig):
        return sig
    _log("Signatur abgelaufen oder fehlt – hole neue...")
    new_sig = _fetch_signature()
    if new_sig:
        _save_sig(new_sig)
        return new_sig
    return sig



def _channel_cache_age():
    try:
        if xbmcvfs.exists(_CHANNEL_FILE):
            with xbmcvfs.File(_CHANNEL_FILE, "r") as f:
                cached = json.loads(f.read())
            return time.time() - cached.get("ts", 0)
    except Exception:
        pass
    return 999999


def _fetch_channels(sig):
    groups = {}
    cursor = 0
    headers = {
        "content-type": "application/json; charset=utf-8",
        "user-agent": "MediaHubMX/2",
        "accept": "*/*",
        "Accept-Language": "de",
        "mediahubmx-signature": sig,
    }
    while True:
        body = json.dumps({
            "language": "de",
            "region": "AT",
            "catalogId": "iptv",
            "id": "iptv",
            "adult": False,
            "search": "",
            "sort": "",
            "filter": {"group": None},
            "cursor": cursor,
            "clientVersion": "3.0.3",
        }).encode("utf-8")
        try:
            req = urllib.request.Request(_CATALOG_URL, data=body, headers=headers)
            with urllib.request.urlopen(req, timeout=20) as r:
                data = json.loads(r.read())
        except Exception as e:
            _log(f"Catalog-Request fehlgeschlagen (cursor={cursor}): {e}", xbmc.LOGWARNING)
            break

        for c in data.get("items", []):
            grp = c.get("group", "Other")
            if grp not in groups:
                groups[grp] = {}
            g = groups[grp]
            name = c.get("name", "")
            if name not in g:
                g[name] = []
            g[name].append(c)

        try:
            cursor = int(data["nextCursor"])
        except (KeyError, TypeError, ValueError):
            break


    return groups


def ensure_channels(sig):
    age = _channel_cache_age()
    if age < _CHANNEL_TTL:
        _log(f"Channel-Cache noch frisch ({int(age)}s alt), ueberspringe")
        return

    _log("Lade Kanalliste im Hintergrund...")
    groups = _fetch_channels(sig)
    if groups is None:
        return
    try:
        with xbmcvfs.File(_CHANNEL_FILE, "w") as f:
            f.write(json.dumps({"ts": time.time(), "groups": groups}))
        total = sum(len(v) for v in groups.values())
        _log(f"Channel-Cache aktualisiert: {len(groups)} Gruppen, {total} Kanaele")
    except Exception as e:
        _log(f"Channel-Cache schreiben fehlgeschlagen: {e}", xbmc.LOGWARNING)



class VodkoolService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self._last_channel_refresh = 0

    def run(self):
        _log("Service gestartet")

        if not xbmcvfs.exists(_BASE):
            xbmcvfs.mkdirs(_BASE)

        xbmc.sleep(2000)

        if 1==1:
            try:
                sig = ensure_signature()
                if sig:
                    ensure_channels(sig)
            except Exception as e:
                _log(f"Service-Fehler: {e}", xbmc.LOGERROR)

            for _ in range(_POLL_INTERVAL):
                if self.waitForAbort(1):
                    _log("Service beendet")
                    return

        _log("Service beendet")


