import sys
import xbmc
import xbmcaddon
import xbmcplugin
import os as _os
import xbmcgui
import urllib.parse
import urllib.request
import json

from resources.lib.playhoster import play_hoster
from resources.lib.signaturehandler import SignatureHandler
from resources.lib.playhelper import play_m3u8_stream

def show_error_dialog(title, message):
    xbmcgui.Dialog().ok(title, message)

import threading
import time

import xbmcvfs as _xbmcvfs
_ADDON_DATA_PATH = _xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.vodkool/"
)
if not _xbmcvfs.exists(_ADDON_DATA_PATH):
    _xbmcvfs.mkdirs(_ADDON_DATA_PATH)
    xbmc.log(f"[vodkool] Addon-Datenverzeichnis erstellt: {_ADDON_DATA_PATH}", xbmc.LOGINFO)

_ADDON = xbmcaddon.Addon()
_ADDON_PATH = _xbmcvfs.translatePath(_ADDON.getAddonInfo('path'))
ICON = _os.path.join(_ADDON_PATH, 'icon.png')

def _use_addon_icon():
    return _ADDON.getSetting('menu.use_addon_icon') == 'true'

def _set_art(li, thumb="", icon="", poster="", fanart=""):
    if not _use_addon_icon():
        icon = thumb if thumb else ""
        fanart = ""
    li.setArt({"thumb": thumb, "icon": icon, "poster": poster, "fanart": fanart})

sig_handler = SignatureHandler()

_token_cache = {"token": None, "time": 0, "validation_done": False}

def _get_cached_token():
    try:
        current_time = time.time()
        
        if _token_cache["token"] and (current_time - _token_cache["time"]) < 900:
            xbmc.log(f"[vodkool] Token aus Cache (gültig noch {int(900 - (current_time - _token_cache['time']))}s)", xbmc.LOGDEBUG)
            return _token_cache["token"]
        
        sd = sig_handler.read_signature()
        if sd and sd.get("mediahubmx-raw"):
            token = sd.get("mediahubmx-raw", "")
            xbmc.log(f"[vodkool] Token aus File geladen", xbmc.LOGINFO)
        else:
            token = sig_handler.get_new_signature()
            if token:
                sig_handler.save_signature(token)
                xbmc.log(f"[vodkool] Neuer Token geholt und gespeichert", xbmc.LOGINFO)
            else:
                xbmc.log(f"[vodkool] WARNUNG: Kein Token verfügbar!", xbmc.LOGWARNING)
                token = ""
        
        _token_cache["token"] = token
        _token_cache["time"] = current_time
        
        return token
        
    except Exception as e:
        xbmc.log(f"[vodkool] Token-Cache Fehler: {e} - Fallback zu Original", xbmc.LOGERROR)
        try:
            sd = sig_handler.read_signature()
            return sd.get("mediahubmx-raw", "") if sd else ""
        except:
            return ""

signature_raw = _get_cached_token()

if signature_raw and not _token_cache["validation_done"]:
    _token_cache["validation_done"] = True
    
    def _validate_token():
        try:
            req = urllib.request.Request(
                "https://kool.to/mediahubmx.json",
                headers={"User-Agent": "Dezor/1.5.4", "mediahubmx-jwt": signature_raw}
            )
            with urllib.request.urlopen(req, timeout=10) as r:
                rj = json.loads(r.read())
            
            if (rj.get("error", "") or "").startswith("Malformed"):
                xbmc.log(f"[vodkool] Token ungültig, wird zurückgesetzt", xbmc.LOGWARNING)
                sig_handler.reset_signature()
                _token_cache["token"] = None
                _token_cache["time"] = 0
            else:
                sig_handler.save_signature(signature_raw)
                xbmc.log(f"[vodkool] Token erfolgreich validiert", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[vodkool] Token-Validierung fehlgeschlagen: {e}", xbmc.LOGWARNING)
    
    threading.Thread(target=_validate_token, daemon=True).start()
    xbmc.log(f"[vodkool] Token-Validierung gestartet", xbmc.LOGDEBUG)

_action = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?") if len(sys.argv) > 2 else "")).get("action", "")



HANDLE = int(sys.argv[1])

import random as _random_mod

_LOKKE_UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) lokke/4.1.1 Chrome/106.0.5249.199 Electron/21.4.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) lokke/4.1.1 Chrome/108.0.5359.124 Electron/21.4.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) lokke/4.1.1 Chrome/110.0.5481.177 Electron/21.4.0 Safari/537.36",
]

def _kool_request(url):
    for ua in (_random_mod.choice(_LOKKE_UAS), "Mozilla/5.0"):
        try:
            headers = {
                "User-Agent": ua,
                "Referer": "https://www.kool.to/web-vod/",
                "Origin": "https://www.kool.to",
                "Accept-Language": "de",
            }
            req = urllib.request.Request(url, headers=headers)
            response = urllib.request.urlopen(req, timeout=15)
            return json.loads(response.read().decode("utf-8"))
        except Exception as e:
            xbmc.log(f"[vodkool] _kool_request ua={ua[:30]} err={e}", xbmc.LOGWARNING)
    return {}

def _mhub_request(url, body=None):
    data = body.encode("utf-8") if isinstance(body, str) else body
    _tok = _get_cached_token()
    attempts = [
        {
            "User-Agent": "MediaHubMX/2",
            "content-type": "application/json; charset=utf-8",
            "accept": "*/*",
            "Accept-Language": "de",
            **({"mediahubmx-signature": _tok} if _tok else {}),
        },
        {
            "User-Agent": _random_mod.choice(_LOKKE_UAS),
            "content-type": "application/json; charset=utf-8",
            "accept": "*/*",
            "Accept-Language": "de",
            "Referer": "https://kool.to/",
            **({"mediahubmx-signature": _tok} if _tok else {}),
        },
        {
            "User-Agent": "Mozilla/5.0",
            "content-type": "application/json; charset=utf-8",
            "accept": "*/*",
            "Accept-Language": "de",
        },
    ]
    for headers in attempts:
        try:
            req = urllib.request.Request(url, data=data, headers=headers)
            response = urllib.request.urlopen(req, timeout=15)
            return json.loads(response.read().decode("utf-8"))
        except Exception as e:
            xbmc.log(f"[vodkool] _mhub_request ua={headers['User-Agent'][:30]} err={e}", xbmc.LOGWARNING)
    return {}

def _show_catalog_items(items, next_cursor, action_self, next_action, is_series, fav_type):
    for item in items:
        name = item.get("name", "")
        poster = item.get("images", {}).get("poster", "")
        desc = item.get("description", "")
        tmdb_id = item.get("ids", {}).get("tmdb_id", "")
        item_json = json.dumps({
            "type": item.get("type", "series" if is_series else "movie"),
            "ids": item.get("ids", {}),
            "name": name,
            "nameTranslations": item.get("nameTranslations", {}),
            "originalName": item.get("originalName", ""),
        })
        li = xbmcgui.ListItem(label=name)
        _set_art(li, thumb=poster, icon=ICON, poster=poster)
        li.setInfo("video", {"plot": desc})
        if is_series:
            url_params = urllib.parse.urlencode({"action": "staffeln", "item_json": item_json})
            _fav_params = f"action=staffeln&item_json={urllib.parse.quote(item_json)}"
        else:
            url_params = urllib.parse.urlencode({"action": "hoster", "item_json": item_json})
            _fav_params = f"action=hoster&item_json={urllib.parse.quote(item_json)}"
        _cm_fav = urllib.parse.urlencode({"action": "fav_add", "type": fav_type,
            "url": _fav_params, "label": name, "logo": poster})
        li.addContextMenuItems([("Zu Kool-Fav hinzufuegen", f"RunPlugin({sys.argv[0]}?{_cm_fav})")])
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)
    if next_cursor is not None:
        li = xbmcgui.ListItem(label="Nächste Seite ▶")
        url_params = urllib.parse.urlencode({"action": next_action, "cursor": str(next_cursor)})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)


def show_filme(cursor=None, genre=None, sort="popularity"):
    try:
        genre_filter = {}
        if genre:
            genre_filter = {"genre": genre}
        body = {
            "language": "de", "region": "XX",
            "catalogId": "tmdb.movie", "id": "movie/popular",
            "adult": False, "search": "", "sort": sort,
            "filter": genre_filter,
            "cursor": int(cursor) if cursor else None,
            "clientVersion": "3.1.0",
        }
        j = _mhub_post(_KOOL_CATALOG_URL, body)
        items = j.get("items", [])
        next_cursor = j.get("nextCursor")
        _show_catalog_items(items, next_cursor, "filme", "filme", False, "vod")
    except Exception as e:
        show_error_dialog("Uuups!!!", f"Konnte Filme nicht laden:\n{e}")
    xbmcplugin.endOfDirectory(HANDLE)

def show_filme_trending(cursor=None):
    try:
        body = {
            "language": "de", "region": "XX",
            "catalogId": "tmdb.movie", "id": "movie/trending",
            "adult": False, "search": "", "sort": "trendingDay",
            "filter": {}, "cursor": int(cursor) if cursor else None,
            "clientVersion": "3.1.0",
        }
        j = _mhub_post(_KOOL_CATALOG_URL, body)
        _show_catalog_items(j.get("items", []), j.get("nextCursor"), "filme_trending", "filme_trending", False, "vod")
    except Exception as e:
        show_error_dialog("Uuups!!!", f"Konnte Filme nicht laden:\n{e}")
    xbmcplugin.endOfDirectory(HANDLE)

def show_filme_popular(cursor=None):
    show_filme(cursor=cursor, sort="popularity")

def show_filme_filter():
    genres = [
        ("Action",          "Action"),
        ("Abenteuer",       "Adventure"),
        ("Animation",       "Animation"),
        ("Komoedie",        "Comedy"),
        ("Krimi",           "Crime"),
        ("Dokumentarfilm",  "Documentary"),
        ("Drama",           "Drama"),
        ("Familie",         "Family"),
        ("Fantasy",         "Fantasy"),
        ("Historie",        "History"),
        ("Horror",          "Horror"),
        ("Musik",           "Music"),
        ("Mystery",         "Mystery"),
        ("Liebesfilm",      "Romance"),
        ("Science Fiction", "Science Fiction"),
        ("TV-Film",         "TV Movie"),
        ("Thriller",        "Thriller"),
        ("Kriegsfilm",      "War"),
        ("Western",         "Western"),
    ]
    for label, genre in genres:
        li = xbmcgui.ListItem(label=label)
        _set_art(li, thumb=ICON, icon=ICON)
        url_params = urllib.parse.urlencode({"action": "filme_genre", "genre": genre})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)
    xbmcplugin.endOfDirectory(HANDLE)

def show_filme_year():
    jahre = [str(y) for y in range(2026, 1999, -1)]
    idx = xbmcgui.Dialog().select("Jahr wählen", jahre)
    if idx == -1:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    jahr = jahre[idx]
    try:
        body = {
            "language": "de", "region": "XX",
            "catalogId": "tmdb.movie", "id": "movie/popular",
            "adult": False, "search": "", "sort": "releaseDate",
            "filter": {"year": int(jahr)},
            "cursor": None, "clientVersion": "3.1.0",
        }
        j = _mhub_post(_KOOL_CATALOG_URL, body)
        _show_catalog_items(j.get("items", []), j.get("nextCursor"), "filme_year", "filme_year", False, "vod")
    except Exception as e:
        show_error_dialog("Uuups!!!", f"Konnte Filme nicht laden:\n{e}")
    xbmcplugin.endOfDirectory(HANDLE)

def show_serien(cursor=None, sort="popularity"):
    try:
        body = {
            "language": "de", "region": "XX",
            "catalogId": "tmdb.series", "id": "series/popular",
            "adult": False, "search": "", "sort": sort,
            "filter": {}, "cursor": int(cursor) if cursor else None,
            "clientVersion": "3.1.0",
        }
        j = _mhub_post(_KOOL_CATALOG_URL, body)
        _show_catalog_items(j.get("items", []), j.get("nextCursor"), "serien", "serien", True, "serie")
    except Exception as e:
        show_error_dialog("Uuups!!!", f"Konnte Serien nicht laden:\n{e}")
    xbmcplugin.endOfDirectory(HANDLE)

def show_serien_trending(cursor=None):
    try:
        body = {
            "language": "de", "region": "XX",
            "catalogId": "tmdb.series", "id": "series/trending",
            "adult": False, "search": "", "sort": "trendingDay",
            "filter": {}, "cursor": int(cursor) if cursor else None,
            "clientVersion": "3.1.0",
        }
        j = _mhub_post(_KOOL_CATALOG_URL, body)
        _show_catalog_items(j.get("items", []), j.get("nextCursor"), "serien_trending", "serien_trending", True, "serie")
    except Exception as e:
        show_error_dialog("Uuups!!!", f"Konnte Serien nicht laden:\n{e}")
    xbmcplugin.endOfDirectory(HANDLE)

def show_serien_popular(cursor=None):
    show_serien(cursor=cursor, sort="popularity")

def show_serien_year():
    jahre = [str(y) for y in range(2026, 1999, -1)]
    idx = xbmcgui.Dialog().select("Jahr wählen", jahre)
    if idx == -1:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    show_serien(sort="releaseDate")

def show_staffeln(series_id=None, item_json=None):
    try:
        if item_json:
            item_obj = json.loads(item_json)
        else:
            show_error_dialog("Fehler", "Keine Serie-Daten übergeben!")
            xbmcplugin.endOfDirectory(HANDLE)
            return
        j = _mhub_item(item_obj, episode_obj={})
        episodes = j.get("episodes", [])
        seasons = sorted(set(str(ep.get("season", 0)) for ep in episodes), key=lambda x: int(x))
        for season_nr in seasons:
            label = f"Staffel {season_nr}" if season_nr != "0" else "Extras"
            li = xbmcgui.ListItem(label=label)
            _set_art(li, thumb=ICON, icon=ICON)
            url_params = urllib.parse.urlencode({
                "action": "episoden",
                "item_json": item_json,
                "season": season_nr,
            })
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)
    except Exception as e:
        show_error_dialog("Uuups!!!", f"Konnte Staffeln nicht laden:\n{e}")
    xbmcplugin.endOfDirectory(HANDLE)

def show_episoden(series_id=None, season_nr=None, item_json=None):
    try:
        if item_json:
            item_obj = json.loads(item_json)
        else:
            show_error_dialog("Fehler", "Keine Serie-Daten übergeben!")
            xbmcplugin.endOfDirectory(HANDLE)
            return
        j = _mhub_item(item_obj, episode_obj={})
        episodes = j.get("episodes", [])
        season_filter = str(season_nr) if season_nr else None
        for ep in episodes:
            if season_filter and str(ep.get("season", "")) != season_filter:
                continue
            label = f"S{ep.get('season','?')}E{ep.get('episode','?')} - {ep.get('name', '')}"
            li = xbmcgui.ListItem(label=label)
            poster = ep.get("poster", "")
            _set_art(li, thumb=poster, icon=ICON)
            li.setInfo("video", {"plot": ep.get("description", ""),
                                 "season": ep.get("season"), "episode": ep.get("episode")})
            ep_obj = {
                "ids": ep.get("ids", {}),
                "season": ep.get("season"),
                "episode": ep.get("episode"),
            }
            url_params = urllib.parse.urlencode({
                "action": "hoster",
                "item_json": item_json,
                "episode_json": json.dumps(ep_obj),
            })
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)
    except Exception as e:
        show_error_dialog("Uuups!!!", f"Konnte Episoden nicht laden:\n{e}")
    xbmcplugin.endOfDirectory(HANDLE)

def show_hoster(series_id=None, season_nr=None, episode_nr=None, epid=None, item_json=None, episode_json=None):
    try:
        if item_json:
            item_obj = json.loads(item_json)
            ep_obj = json.loads(episode_json) if episode_json else None
        else:
            show_error_dialog("Fehler", "Keine Item-Daten übergeben!")
            xbmcplugin.endOfDirectory(HANDLE)
            return
        hoster_list = _mhub_source(item_obj, ep_obj)
        if not hoster_list:
            show_error_dialog("Keine Hoster", "Keine Streams gefunden für diesen Titel.")
            xbmcplugin.endOfDirectory(HANDLE)
            return
        if not isinstance(hoster_list, list):
            hoster_list = [hoster_list]
        for h in hoster_list:
            hoster_url = h.get("url", "")
            if not hoster_url:
                continue
            lang = ", ".join(h.get("languages", []))
            tag = h.get("tag", "")
            sName = h.get("name", hoster_url)
            label_parts = [sName]
            if tag:
                label_parts.append(tag)
            if lang:
                label_parts.append(f"[{lang}]")
            li = xbmcgui.ListItem(label=" | ".join(label_parts))
            li.setProperty("IsPlayable", "true")
            url_params = urllib.parse.urlencode({"action": "play_mhub", "hoster_url": hoster_url})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, False)
    except Exception as e:
        show_error_dialog("Uuups!!!", f"Konnte Hoster nicht holen:\n{e}")
    xbmcplugin.endOfDirectory(HANDLE)

_KOOL_CATALOG_URL = "https://www.kool.to/mediahubmx-catalog.json"
_KOOL_RESOLVE_URL = "https://www.kool.to/mediahubmx-resolve.json"
_KOOL_ITEM_URL    = "https://www.kool.to/mediahubmx-item.json"
_KOOL_SOURCE_URL  = "https://www.kool.to/mediahubmx-source.json"

_CHANNELS_CACHE_FILE = _xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.vodkool/channels_cache.json"
)
_CHANNELS_CACHE_TTL = 3600

def _mhub_post(url, body):
    _tok = _get_cached_token()
    data = json.dumps(body).encode("utf-8")
    attempts = [
        {
            "User-Agent": "MediaHubMX/2",
            "content-type": "application/json; charset=utf-8",
            "accept": "*/*",
            "Accept-Language": "de",
            **( {"mediahubmx-signature": _tok} if _tok else {} ),
        },
        {
            "User-Agent": _random_mod.choice(_LOKKE_UAS),
            "content-type": "application/json; charset=utf-8",
            "accept": "*/*",
            "Accept-Language": "de",
            "Referer": "https://kool.to/",
            **( {"mediahubmx-signature": _tok} if _tok else {} ),
        },
    ]
    for headers in attempts:
        try:
            req = urllib.request.Request(url, data=data, headers=headers)
            response = urllib.request.urlopen(req, timeout=20)
            return json.loads(response.read().decode("utf-8"))
        except Exception as e:
            xbmc.log(f"[vodkool] _mhub_post {url} err={e}", xbmc.LOGWARNING)
    return {}


def _mhub_catalog(catalog_id, item_type, sort="popularity", search="", cursor=None):
    body = {
        "language": "de",
        "region": "XX",
        "catalogId": catalog_id,
        "id": item_type,
        "adult": False,
        "search": search,
        "sort": sort,
        "filter": {},
        "cursor": cursor,
        "clientVersion": "3.1.0",
    }
    return _mhub_post(_KOOL_CATALOG_URL, body)


def _mhub_item(item_obj, episode_obj=None):
    body = dict(item_obj)
    body["language"] = "de"
    body["region"] = "XX"
    body["clientVersion"] = "3.1.0"
    if episode_obj is not None:
        body["episode"] = episode_obj
    return _mhub_post(_KOOL_ITEM_URL, body)


def _mhub_source(item_obj, episode_obj=None):
    body = dict(item_obj)
    body["language"] = "de"
    body["region"] = "XX"
    body["clientVersion"] = "3.1.0"
    if episode_obj is not None:
        body["episode"] = episode_obj
    return _mhub_post(_KOOL_SOURCE_URL, body)


def _mhub_resolve(hoster_url):
    import ssl, urllib.error
    body = {
        "language": "de",
        "region": "XX",
        "url": hoster_url,
        "clientVersion": "3.1.0",
    }
    _tok = _get_cached_token()
    base_headers = {
        "User-Agent": "MediaHubMX/2",
        "content-type": "application/json; charset=utf-8",
        "accept": "*/*",
        "Accept-Language": "de",
        **( {"mediahubmx-signature": _tok} if _tok else {} ),
    }

    for _ in range(5):
        data = json.dumps(body).encode("utf-8")
        try:
            req = urllib.request.Request(_KOOL_RESOLVE_URL, data=data, headers=base_headers)
            resp = json.loads(urllib.request.urlopen(req, timeout=20).read().decode("utf-8"))
        except Exception as e:
            xbmc.log(f"[vodkool] _mhub_resolve network err: {e}", xbmc.LOGERROR)
            return None

        kind = resp.get("kind")

        if kind == "taskRequest":
            task = resp.get("data", {})
            task_id = resp.get("id")
            task_url = task.get("url", "")
            task_params = task.get("params", {})
            task_method = task_params.get("method", "GET").upper()
            task_headers = task_params.get("headers", {})
            task_redirect = task_params.get("redirect", "follow") == "follow"

            try:
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                task_req = urllib.request.Request(task_url, headers=task_headers, method=task_method)
                opener = urllib.request.build_opener(urllib.request.HTTPRedirectHandler())
                with opener.open(task_req, timeout=15) as r:
                    task_result_url = r.url
                    task_body = r.read().decode("utf-8", errors="replace")
                body = {
                    "kind": "taskResponse",
                    "id": task_id,
                    "data": {
                        "status": r.status,
                        "url": task_result_url,
                        "text": task_body[:4096],
                    }
                }
            except Exception as e:
                xbmc.log(f"[vodkool] _mhub_resolve task fetch err: {e}", xbmc.LOGWARNING)
                body = {
                    "kind": "taskResponse",
                    "id": task_id,
                    "data": {"error": str(e)},
                }
            continue

        if kind is None:
            if isinstance(resp, list) and resp:
                url_val = resp[0].get("url")
                if url_val and url_val.startswith("http"):
                    return url_val
            elif isinstance(resp, dict):
                url_val = resp.get("url")
                if url_val and url_val.startswith("http"):
                    return url_val
            xbmc.log(f"[vodkool] _mhub_resolve unexpected resp: {resp}", xbmc.LOGWARNING)
            return None

    xbmc.log("[vodkool] _mhub_resolve: max iterations reached", xbmc.LOGWARNING)
    return None


def _mhub_catalog_items_to_list(items, is_series=False):
    result = []
    for item in items:
        ids = item.get("ids", {})
        tmdb_id = ids.get("tmdb_id", "")
        name = item.get("name", "")
        poster = item.get("images", {}).get("poster", "")
        desc = item.get("description", "")
        result.append({
            "tmdb_id": tmdb_id,
            "name": name,
            "poster": poster,
            "description": desc,
            "type": "series" if is_series else "movie",
            "ids": ids,
            "nameTranslations": item.get("nameTranslations", {}),
            "originalName": item.get("originalName", ""),
        })
    return result


def _kool_live_request(url, body):
    token = _get_cached_token()
    if not token:
        raise Exception("Keine gueltige Signatur verfuegbar. Bitte Internetverbindung pruefen.")
    _h = {
        "content-type": "application/json; charset=utf-8",
        "user-agent": "MediaHubMX/2",
        "accept": "*/*",
        "Accept-Language": "de",
        "mediahubmx-signature": token,
    }
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=_h)
    return json.loads(urllib.request.urlopen(req, timeout=15).read())


def _kool_live_geturl(channel_url):
    resp = _kool_live_request(_KOOL_RESOLVE_URL, {
        "language": "de",
        "region": "AT",
        "url": channel_url,
    })
    return resp[0]["url"]


def _kool_live_fetch_channels():
    try:
        if _xbmcvfs.exists(_CHANNELS_CACHE_FILE):
            with _xbmcvfs.File(_CHANNELS_CACHE_FILE, "r") as f:
                cached = json.loads(f.read())
            if time.time() - cached.get("ts", 0) < _CHANNELS_CACHE_TTL:
                xbmc.log("[vodkool] Kanalliste aus Datei-Cache", xbmc.LOGINFO)
                return cached["groups"]
    except Exception as e:
        xbmc.log(f"[vodkool] Cache lesen fehlgeschlagen: {e}", xbmc.LOGWARNING)

    xbmc.log("[vodkool] Lade Kanalliste von API...", xbmc.LOGINFO)
    groups = {}
    cursor = 0
    while True:
        body = {
            "language": "de",
            "region": "AT",
            "catalogId": "iptv",
            "id": "iptv",
            "adult": False,
            "search": "",
            "sort": "",
            "filter": {"group": None},
            "cursor": cursor,
            "clientVersion": "3.0.3",
        }
        data = _kool_live_request(_KOOL_CATALOG_URL, body)
        for c in data.get("items", []):
            grp = c.get("group", "Other")
            if grp not in groups:
                groups[grp] = {}
            g = groups[grp]
            name = c.get("name", "")
            if name not in g:
                g[name] = []
            g[name].append(c)
        try:
            cursor = int(data["nextCursor"])
        except (KeyError, TypeError, ValueError):
            break

    try:
        with _xbmcvfs.File(_CHANNELS_CACHE_FILE, "w") as f:
            f.write(json.dumps({"ts": time.time(), "groups": groups}))
        xbmc.log(f"[vodkool] Kanalliste gecacht: {len(groups)} Gruppen", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[vodkool] Cache schreiben fehlgeschlagen: {e}", xbmc.LOGWARNING)

    return groups


def show_kool_live_countries():
    try:
        data = _kool_live_fetch_channels()
        if isinstance(data, dict):
            countries = {k: sum(len(v) for v in grp.values())
                         for k, grp in data.items()}
        else:
            countries = {}
            for ch in data:
                c = ch.get("country", "Unbekannt")
                countries[c] = countries.get(c, 0) + 1
        for country in sorted(countries):
            li = xbmcgui.ListItem(label=f"{country} ({countries[country]})")
            _set_art(li, thumb=ICON, icon=ICON)
            url_params = urllib.parse.urlencode({"action": "kool_live_sort", "country": country})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)
    except Exception as e:
        show_error_dialog("Uuups!!!", f"Konnte Länderliste nicht laden:\n{e}")
    xbmcplugin.endOfDirectory(HANDLE)


def show_kool_live_sort(country):
    for label, sort in [("Trending", "trending"), ("Name", "name")]:
        li = xbmcgui.ListItem(label=label)
        _set_art(li, thumb=ICON, icon=ICON)
        url_params = urllib.parse.urlencode({"action": "kool_live_channels", "country": country, "sort": sort})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_kool_live_channels(country, sort="trending"):
    try:
        data = _kool_live_fetch_channels()

        channels = []
        seen_urls = set()
        if isinstance(data, dict):
            group_data = data.get(country, {})
            for ch_name, streams in group_data.items():
                for s in streams:
                    u = s.get("url", "")
                    if not u or u in seen_urls:
                        continue
                    seen_urls.add(u)
                    lang = s.get("language") or s.get("languages") or ""
                    if isinstance(lang, list):
                        lang = ", ".join(lang)
                    channels.append({
                        "name": s.get("name", ch_name),
                        "url":  u,
                        "logo": s.get("logo", ""),
                        "lang": lang,
                    })
        else:
            channels = [c for c in data if c.get("country") == country]

        if sort == "name":
            channels.sort(key=lambda x: x.get("name", "").lower())

        for ch in channels:
            name   = ch.get("name", "")
            ch_url = ch.get("url", "")
            logo   = ch.get("logo", "")
            lang   = ch.get("lang", "")
            if not ch_url:
                continue
            display = f"{name}  [{lang}]" if lang else name
            li = xbmcgui.ListItem(label=display)
            _set_art(li, thumb=logo or ICON, icon=logo or ICON)
            li.setProperty("IsPlayable", "true")
            url_params = urllib.parse.urlencode({
                "action": "play_kool_live",
                "url":    ch_url,
                "label":  name,
                "logo":   logo,
            })
            cm_add = urllib.parse.urlencode({"action": "fav_add", "url": ch_url, "label": name, "logo": logo})
            li.addContextMenuItems([("Zu Favoriten hinzufuegen", f"RunPlugin({sys.argv[0]}?{cm_add})")])
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, False)
    except Exception as e:
        show_error_dialog("Uuups!!!", f"Konnte Senderliste nicht laden:\n{e}")
    xbmcplugin.endOfDirectory(HANDLE)


def play_kool_live(channel_url, label="Live TV", logo=""):
    progress = xbmcgui.DialogProgress()
    progress.create("KOOL.TO", f"Starte {label}...")
    progress.update(20)
    try:
        stream_url = _kool_live_geturl(channel_url)
    except Exception as e:
        progress.close()
        xbmc.log(f"[vodkool] geturl failed: {e}", xbmc.LOGWARNING)
        show_error_dialog("Uuups!!!", f"Stream konnte nicht aufgelöst werden:\n{e}")
        return
    progress.update(60)
    xbmc.log(f"[vodkool] LiveTV stream: {stream_url[:80]}", xbmc.LOGINFO)
    progress.update(90)
    progress.close()
    from resources.lib.playhelper import play_m3u8_stream
    play_m3u8_stream(stream_url, label=label, thumb=logo if logo else None)


def show_iptv_countries():
    countries = [
        {"name": "Deutschland", "code": "de"},
        {"name": "Österreich", "code": "at"},
        {"name": "Schweiz", "code": "ch"},
        {"name": "Italien", "code": "it"},
        {"name": "Serbien", "code": "rs"},
        {"name": "Kroatien", "code": "hr"},
        {"name": "Bosnien & Herzegowina", "code": "ba"},
        {"name": "Montenegro", "code": "me"},
        {"name": "Mazedonien", "code": "mk"},
        {"name": "Albanien", "code": "al"},
        {"name": "Bulgarien", "code": "bg"},
        {"name": "Slowenien", "code": "si"},
        {"name": "Kosovo", "code": "xk"},
    ]
    for country in countries:
        li = xbmcgui.ListItem(country["name"])
        _set_art(li, thumb=ICON, icon=ICON)
        url_params = urllib.parse.urlencode({"action": "iptv_channels", "country": country["code"]})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)
    xbmcplugin.endOfDirectory(HANDLE)

def show_iptv_channels(country_code):
    m3u_url = f"https://iptv-org.github.io/iptv/countries/{country_code}.m3u"
    cache_channels = []
    try:
        response = urllib.request.urlopen(m3u_url)
        playlist = response.read().decode("utf-8")
        entries = playlist.split("#EXTINF")
        for entry in entries[1:]:
            lines = entry.strip().splitlines()
            info = lines[0]
            url = lines[1] if len(lines) > 1 else None
            if not url or not url.startswith("http") or ".m3u8" not in url:
                continue
            name = info.split(",")[-1].strip() if "," in info else info.strip()
            logo = ""
            if "tvg-logo=" in info:
                logo = info.split('tvg-logo="')[1].split('"')[0]
            li = xbmcgui.ListItem(label=name)
            li.setProperty('IsPlayable', 'true')
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setMimeType('application/vnd.apple.mpegurl')
            li.setContentLookup(False)
            _set_art(li, thumb=logo or ICON, icon=logo or ICON, poster=logo)
            url_params = urllib.parse.urlencode({"action": "play_m3u8", "url": url, "label": name})
            _cm_fav = urllib.parse.urlencode({"action": "fav_add", "type": "iptv",
                "url": f"action=play_m3u8&url={urllib.parse.quote(url)}&label={urllib.parse.quote(name)}",
                "label": name, "logo": logo})
            li.addContextMenuItems([("Zu Kool-Fav hinzufuegen", f"RunPlugin({sys.argv[0]}?{_cm_fav})")])
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, False)
            cache_channels.append({"name": name, "url": url, "logo": logo, "country": country_code})
        if cache_channels:
            _iptv_update_search_cache(country_code, cache_channels)
    except Exception as e:
        show_error_dialog("Uuups!!!", f"Konnte Senderliste fuer {country_code} nicht laden:\n{e}")
    xbmcplugin.endOfDirectory(HANDLE)

def _iptv_update_search_cache(country_code, channels):
    try:
        cache_file = _xbmcvfs.translatePath(
            "special://userdata/addon_data/plugin.video.vodkool/iptv_search_cache.json"
        )
        existing = []
        if _xbmcvfs.exists(cache_file):
            with _xbmcvfs.File(cache_file, "r") as f:
                existing = json.loads(f.read())
        existing = [c for c in existing if c.get("country") != country_code]
        existing.extend(channels)
        with _xbmcvfs.File(cache_file, "w") as f:
            f.write(json.dumps(existing, ensure_ascii=False))
    except Exception as e:
        xbmc.log(f"[vodkool] iptv cache update: {e}", xbmc.LOGWARNING)

def _suche_header(label):
    li = xbmcgui.ListItem(label=f"── {label} ──")
    xbmcplugin.addDirectoryItem(HANDLE, "", li, False)

def suche():
    text = xbmcgui.Dialog().input("Suchbegriff eingeben")
    if not text:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    term = text.strip().lower()
    found_any = False

    try:
        groups = _kool_live_fetch_channels()
        live_hits = []
        seen_urls = set()
        for grp, channels in groups.items():
            for ch_name, streams in channels.items():
                if term in ch_name.lower():
                    for s in streams:
                        stream_url = s.get("url", "")
                        if not stream_url or stream_url in seen_urls:
                            continue
                        seen_urls.add(stream_url)
                        lang = s.get("language") or s.get("languages") or ""
                        if isinstance(lang, list):
                            lang = ", ".join(lang)
                        country = s.get("country") or grp or ""
                        display = s.get("name", ch_name)
                        meta_parts = [p for p in [country, lang] if p and p.lower() not in display.lower()]
                        if meta_parts:
                            display = f"{display}  [{', '.join(meta_parts)}]"
                        live_hits.append({
                            "name":    s.get("name", ch_name),
                            "display": display,
                            "url":     stream_url,
                            "logo":    s.get("logo", ""),
                        })
        if live_hits:
            _suche_header(f"kool.to Live TV ({len(live_hits)})")
            for ch in live_hits:
                li = xbmcgui.ListItem(label=ch["display"])
                _logo = ch["logo"]
                _set_art(li, thumb=_logo or ICON, icon=_logo or ICON)
                li.setProperty("IsPlayable", "true")
                url_params = urllib.parse.urlencode({
                    "action": "play_kool_live",
                    "url":    ch["url"],
                    "label":  ch["name"],
                    "logo":   ch["logo"],
                })
                _cm = urllib.parse.urlencode({"action": "fav_add", "type": "live",
                    "url": ch["url"], "label": ch["name"], "logo": ch["logo"]})
                li.addContextMenuItems([("Zu Kool-Fav hinzufuegen",
                    f"RunPlugin({sys.argv[0]}?{_cm})")])
                xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, False)
                found_any = True
    except Exception as e:
        xbmc.log(f"[vodkool] Suche LiveTV: {e}", xbmc.LOGWARNING)

    try:
        iptv_cache_file = _xbmcvfs.translatePath(
            "special://userdata/addon_data/plugin.video.vodkool/iptv_search_cache.json"
        )
        iptv_channels = []
        if _xbmcvfs.exists(iptv_cache_file):
            with _xbmcvfs.File(iptv_cache_file, "r") as f:
                iptv_channels = json.loads(f.read())
        iptv_hits = [c for c in iptv_channels if term in c.get("name", "").lower()]
        if iptv_hits:
            _suche_header(f"Oeffentliche ({len(iptv_hits)})")
            for ch in iptv_hits:
                country_label = ch.get("country", "").upper()
                display_label = f"{ch['name']}  [{country_label}]" if country_label else ch["name"]
                li = xbmcgui.ListItem(label=display_label)
                li.setProperty("IsPlayable", "true")
                li.setMimeType("application/vnd.apple.mpegurl")
                li.setContentLookup(False)
                _logo = ch.get("logo", "")
                _set_art(li, thumb=_logo or ICON, icon=_logo or ICON)
                url_params = urllib.parse.urlencode({"action": "play_m3u8",
                    "url": ch["url"], "label": ch["name"]})
                _cm = urllib.parse.urlencode({"action": "fav_add", "type": "iptv",
                    "url": f"action=play_m3u8&url={urllib.parse.quote(ch['url'])}&label={urllib.parse.quote(ch['name'])}",
                    "label": ch["name"], "logo": ch.get("logo", "")})
                li.addContextMenuItems([("Zu Kool-Fav hinzufuegen",
                    f"RunPlugin({sys.argv[0]}?{_cm})")])
                xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, False)
                found_any = True
    except Exception as e:
        xbmc.log(f"[vodkool] Suche IPTV: {e}", xbmc.LOGWARNING)

    try:
        vod_body = {
            "language": "de", "region": "XX",
            "catalogId": "tmdb.movie", "id": "movie/popular",
            "adult": False, "search": text, "sort": "popularity",
            "filter": {}, "cursor": None, "clientVersion": "3.1.0",
        }
        j = _mhub_post(_KOOL_CATALOG_URL, vod_body)
        vod_items = j.get("items", [])
        if vod_items:
            _suche_header(f"Filme ({len(vod_items)})")
            for item in vod_items:
                name = item.get("name", "")
                poster = item.get("images", {}).get("poster", "")
                desc = item.get("description", "")
                item_obj = {
                    "type": "movie",
                    "ids": item.get("ids", {}),
                    "name": name,
                    "nameTranslations": item.get("nameTranslations", {}),
                    "originalName": item.get("originalName", ""),
                }
                item_json = json.dumps(item_obj)
                li = xbmcgui.ListItem(label=name)
                _set_art(li, thumb=poster, icon=ICON, poster=poster)
                li.setInfo("video", {"plot": desc})
                url_params = urllib.parse.urlencode({"action": "hoster", "item_json": item_json})
                _vod_p = f"action=hoster&item_json={urllib.parse.quote(item_json)}"
                _cm = urllib.parse.urlencode({"action": "fav_add", "type": "vod",
                    "url": _vod_p, "label": name, "logo": poster})
                li.addContextMenuItems([("Zu Kool-Fav hinzufuegen",
                    f"RunPlugin({sys.argv[0]}?{_cm})")])
                xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)
                found_any = True
    except Exception as e:
        xbmc.log(f"[vodkool] Suche VOD: {e}", xbmc.LOGWARNING)

    try:
        ser_body = {
            "language": "de", "region": "XX",
            "catalogId": "tmdb.series", "id": "series/popular",
            "adult": False, "search": text, "sort": "popularity",
            "filter": {}, "cursor": None, "clientVersion": "3.1.0",
        }
        js = _mhub_post(_KOOL_CATALOG_URL, ser_body)
        ser_items = js.get("items", [])
        if ser_items:
            _suche_header(f"Serien ({len(ser_items)})")
            for item in ser_items:
                name = item.get("name", "")
                poster = item.get("images", {}).get("poster", "")
                desc = item.get("description", "")
                item_obj = {
                    "type": "series",
                    "ids": item.get("ids", {}),
                    "name": name,
                    "nameTranslations": item.get("nameTranslations", {}),
                    "originalName": item.get("originalName", ""),
                }
                item_json = json.dumps(item_obj)
                li = xbmcgui.ListItem(label=name)
                _set_art(li, thumb=poster, icon=ICON, poster=poster)
                li.setInfo("video", {"plot": desc})
                url_params = urllib.parse.urlencode({"action": "staffeln", "item_json": item_json})
                _ser_p = f"action=staffeln&item_json={urllib.parse.quote(item_json)}"
                _cm = urllib.parse.urlencode({"action": "fav_add", "type": "serie",
                    "url": _ser_p, "label": name, "logo": poster})
                li.addContextMenuItems([("Zu Kool-Fav hinzufuegen",
                    f"RunPlugin({sys.argv[0]}?{_cm})")])
                xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)
                found_any = True
    except Exception as e:
        xbmc.log(f"[vodkool] Suche Serien: {e}", xbmc.LOGWARNING)

    if not found_any:
        li = xbmcgui.ListItem(label=f"Keine Ergebnisse fuer: {text}")
        xbmcplugin.addDirectoryItem(HANDLE, "", li, False)

    xbmcplugin.endOfDirectory(HANDLE)
    
def play_stream(api_url):
    data = _kool_request(api_url)
    hoster_url = data.get("url")
    if not hoster_url:
        show_error_dialog("Uuups!!!", "Keine Hoster-URL in API-Antwort gefunden!")
        return
    stream_url = resolver.resolve(hoster_url)
    if stream_url:
        li = xbmcgui.ListItem(path=stream_url)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    else:
        show_error_dialog("Uuups!!!", "Kein Stream gefunden! (resolveurl konnte nicht auflösen)")    

def suche_paging(next_id=None, text=None):
    if not text:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    try:
        body = {
            "language": "de", "region": "XX",
            "catalogId": "tmdb.movie", "id": "movie/popular",
            "adult": False, "search": text, "sort": "popularity",
            "filter": {}, "cursor": int(next_id) if next_id else None,
            "clientVersion": "3.1.0",
        }
        j = _mhub_post(_KOOL_CATALOG_URL, body)
        for item in j.get("items", []):
            name = item.get("name", "")
            poster = item.get("images", {}).get("poster", "")
            item_json = json.dumps({"type": "movie", "ids": item.get("ids", {}), "name": name,
                                    "nameTranslations": {}, "originalName": item.get("originalName", "")})
            li = xbmcgui.ListItem(label=name)
            _set_art(li, thumb=poster, icon=ICON)
            url_params = urllib.parse.urlencode({"action": "hoster", "item_json": item_json})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)
        next_id = j.get("nextCursor")
        if next_id:
            li = xbmcgui.ListItem(label="Nächste Seite ▶")
            url_params = urllib.parse.urlencode({"action": "suchen", "next": next_id, "search": text})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)
    except Exception as e:
        show_error_dialog("Uuups!!!", f"Konnte Suche nicht ausführen:\n{e}")
    xbmcplugin.endOfDirectory(HANDLE)


_FAV_FILE = _xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.vodkool/favourites.json"
)

def _fav_load():
    try:
        if _xbmcvfs.exists(_FAV_FILE):
            with _xbmcvfs.File(_FAV_FILE, "r") as f:
                return json.loads(f.read())
    except Exception as e:
        xbmc.log(f"[vodkool] fav_load: {e}", xbmc.LOGWARNING)
    return []

def _fav_save(favs):
    try:
        with _xbmcvfs.File(_FAV_FILE, "w") as f:
            f.write(json.dumps(favs, ensure_ascii=False))
    except Exception as e:
        xbmc.log(f"[vodkool] fav_save: {e}", xbmc.LOGERROR)

def show_favourites():
    favs = _fav_load()
    if not favs:
        li = xbmcgui.ListItem(label="[Keine Kool-Fav Eintraege]")
        xbmcplugin.addDirectoryItem(HANDLE, "", li, False)
    for i, fav in enumerate(favs):
        li = xbmcgui.ListItem(label=fav.get("label", "?"))
        logo = fav.get("logo", "")
        if logo:
            li.setArt({"thumb": logo, "icon": logo, "poster": logo})
        fav_type = fav.get("type", "live")
        fav_url  = fav.get("url", "")
        if fav_type in ("live", "iptv"):
            li.setProperty("IsPlayable", "true")
            if fav_type == "live":
                target_url = f"{sys.argv[0]}?" + urllib.parse.urlencode({
                    "action": "play_kool_live",
                    "url":    fav_url,
                    "label":  fav.get("label", ""),
                    "logo":   logo,
                })
            else:
                target_url = f"{sys.argv[0]}?{fav_url}"
            is_folder = False
        else:
            target_url = f"{sys.argv[0]}?{fav_url}"
            is_folder = True
        cm = []
        cm.append(("Umbenennen", f"RunPlugin({sys.argv[0]}?{urllib.parse.urlencode({'action':'fav_rename','idx':i,'label':fav.get('label','')})})"))
        cm.append(("Entfernen",  f"RunPlugin({sys.argv[0]}?{urllib.parse.urlencode({'action':'fav_remove','idx':i})})"))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(HANDLE, target_url, li, is_folder)
    xbmcplugin.endOfDirectory(HANDLE)

def fav_add(url, label, logo="", fav_type="live"):
    favs = _fav_load()
    for f in favs:
        if f.get("url") == url:
            xbmcgui.Dialog().notification("Kool-Fav", f"{label} bereits vorhanden", xbmcgui.NOTIFICATION_INFO, 2500)
            return
    favs.append({"url": url, "label": label, "logo": logo, "type": fav_type})
    _fav_save(favs)
    xbmcgui.Dialog().notification("Kool-Fav", f"{label} hinzugefuegt", xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")

def fav_remove(idx):
    favs = _fav_load()
    try:
        removed = favs.pop(int(idx))
        _fav_save(favs)
        xbmcgui.Dialog().notification("Kool-Fav", f"{removed.get('label','')} entfernt", xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmc.log(f"[vodkool] fav_remove: {e}", xbmc.LOGWARNING)

def fav_rename(idx, old_label):
    new_label = xbmcgui.Dialog().input("Neuer Name", defaultt=old_label)
    if not new_label:
        return
    favs = _fav_load()
    try:
        favs[int(idx)]["label"] = new_label
        _fav_save(favs)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmc.log(f"[vodkool] fav_rename: {e}", xbmc.LOGWARNING)

def main_menu():
    menu_items = [
        ("Kool-Fav", "favourites"),
        ("kool.to Live TV", "kool_live_countries"),
        ("Öffentliche", "iptv_countries"),
        ("Filme Genre", "filme_filter"),          
        ("Angesagte Filme", "filme_trending"),
        ("Beliebte Filme", "filme_popular"),
        ("Angesagte Serien", "serien_trending"),
        ("Beliebte Serien", "serien_popular"),
        ("Filme nach Jahr", "filme_year"),
        ("Serien nach Jahr", "serien_year"),         
        ("Suche", "suchen"),
    ]
    for label, action in menu_items:
        url_params = urllib.parse.urlencode({"action": action})
        li = xbmcgui.ListItem(label)
        _set_art(li, thumb=ICON, icon=ICON, fanart=ICON)
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{url_params}", li, True)
    xbmcplugin.endOfDirectory(HANDLE)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')

    if action == "kool_live_countries":
        show_kool_live_countries()
    elif action == "kool_live_sort":
        show_kool_live_sort(params.get("country", ""))
    elif action == "kool_live_channels":
        show_kool_live_channels(params.get("country", ""), sort=params.get("sort", "trending"))
    elif action == "play_kool_live":
        play_kool_live(params.get("url", ""), label=params.get("label", "Live TV"), logo=params.get("logo", ""))
    elif action == 'play' or action == 'play_hoster':
        hoster_url = params.get('hoster_url') or params.get('url')
        if not hoster_url:
            show_error_dialog("Fehler", "Keine Hoster-URL übergeben!")
            return
        play_hoster(hoster_url)
    elif action == "play_mhub":
        hoster_url = params.get("hoster_url", "")
        if not hoster_url:
            show_error_dialog("Fehler", "Keine Hoster-URL übergeben!")
            return
        stream_url = _mhub_resolve(hoster_url)
        if stream_url and stream_url.startswith("http"):
            li = xbmcgui.ListItem(path=stream_url)
            li.setProperty("IsPlayable", "true")
            xbmcplugin.setResolvedUrl(HANDLE, True, li)
        else:
            play_hoster(hoster_url)
    elif action == "filme":
        show_filme(cursor=params.get("cursor"), genre=params.get("genre"))
    elif action == "filme_trending":
        show_filme_trending(cursor=params.get("cursor"))
    elif action == "filme_popular":
        show_filme_popular(cursor=params.get("cursor"))
    elif action == "filme_filter":
        show_filme_filter()
    elif action == "filme_genre":
        show_filme(genre=params.get("genre"))
    elif action == "filme_year":
        show_filme_year()
    elif action == "serien":
        show_serien(cursor=params.get("cursor"))
    elif action == "serien_trending":
        show_serien_trending(cursor=params.get("cursor"))
    elif action == "serien_popular":
        show_serien_popular(cursor=params.get("cursor"))
    elif action == "serien_year":
        show_serien_year()
    elif action == "staffeln":
        show_staffeln(
            series_id=params.get("id"),
            item_json=params.get("item_json"),
        )
    elif action == "episoden":
        show_episoden(
            series_id=params.get("id"),
            season_nr=params.get("season"),
            item_json=params.get("item_json"),
        )
    elif action == "hoster":
        show_hoster(
            series_id=params.get("id"),
            season_nr=params.get("season"),
            episode_nr=params.get("episode"),
            epid=params.get("epid"),
            item_json=params.get("item_json"),
            episode_json=params.get("episode_json"),
        )
    elif action == "play_stream":
        play_stream(params.get("api_url"))
    elif action == "suchen":
        next_id     = params.get("next")
        search_text = params.get("search")
        if next_id and search_text:
            suche_paging(next_id=next_id, text=search_text)
        else:
            suche()
    elif action == "iptv_countries":
        show_iptv_countries()
    elif action == "iptv_channels":
        show_iptv_channels(params.get("country"))
    elif action == "play_m3u8":
        play_m3u8_stream(params.get("url"), label=params.get("label", "Live TV"))
    elif action == "favourites":
        show_favourites()
    elif action == "fav_add":
        fav_add(params.get("url", ""), params.get("label", ""), params.get("logo", ""), params.get("type", "live"))
    elif action == "fav_remove":
        fav_remove(params.get("idx", 0))
    elif action == "fav_rename":
        fav_rename(params.get("idx", 0), params.get("label", ""))
    else:
        main_menu()

