import xbmcvfs, xbmc, base64, json, time
import urllib.request

_LOKKE_URL = "https://www.lokke.app/api/app/ping"
_LOKKE_UA  = "electron-fetch/1.0 electron (+https://github.com/arantes555/electron-fetch)"

_DEVICE_TOKEN = "VnPX5t9tSWccXKBF5tIFuL_Fk8-003ZCH2Ns6as20OegRliqWc_Xz3dTVBxa7tN-HAVNp0wIN0sEyDfHtk_SrdE-qyVrtQ4P3ZWoY66k_BOrM1BNu8FxMbuINVzXYiiJABS0"
_DEVICE_ID    = "57eca59a-bfae-4300-a1d5-9e06061e985d"
_FIRST_START  = 1773926709904


def _build_payload():
    now_ms = int(time.time() * 1000)
    return {
        "adblockEnabled": True,
        "appFocusTime": now_ms - _FIRST_START,
        "castConnected": False,
        "devMode": False,
        "firstAppStart": _FIRST_START,
        "hasAddon": True,
        "iap": {"supported": False},
        "ipLocation": {"city": "Ladendorf", "country": "AT", "ip": "178.113.252.97"},
        "lastAppStart": now_ms,
        "locale": "de",
        "metadata": {
            "app": {"platform": "electron"},
            "device": {"type": "desktop", "uniqueId": _DEVICE_ID},
            "os": {"abis": ["x64"], "host": "DESKTOP-2OH9ER9", "name": "win32",
                   "version": "Windows 10 Enterprise LTSC 2024"},
            "platform": {"isAndroid": False, "isElectron": True, "isIOS": False,
                         "isMobile": False, "isTV": False, "isWeb": False, "isWebTV": False},
            "version": {"binary": "4.1.1", "js": "4.1.1", "package": "app.lokke.main"},
        },
        "package": "app.lokke.main",
        "playDuration": 0,
        "playerActive": False,
        "process": "app",
        "proxy": {"autoServer": True, "enabled": False, "engine": "ss",
                  "id": "cz-prg", "ssVersion": 0, "supported": ["ss", "openvpn"]},
        "reason": "app-focus",
        "theme": "dark",
        "token": _DEVICE_TOKEN,
        "version": "4.1.1",
    }


def _is_sig_valid(sig):
    try:
        d = json.loads(base64.b64decode(sig + "==").decode())
        valid_until = json.loads(d["data"])["validUntil"]
        return (int(time.time() * 1000) + 60_000) < valid_until
    except Exception:
        return True


class SignatureHandler:
    def __init__(self, path="special://userdata/addon_data/plugin.video.vodkool/mediahubmx_signature.txt"):
        self.path = xbmcvfs.translatePath(path)
        self._tok = None

    def read_signature(self):
        if self._tok and _is_sig_valid(self._tok):
            return self._parse(self._tok)
        try:
            if xbmcvfs.exists(self.path):
                with xbmcvfs.File(self.path, "r") as f:
                    sig = f.read().strip()
                if sig and _is_sig_valid(sig):
                    self._tok = sig
                    xbmc.log("[vodkool] Signatur aus Datei geladen", xbmc.LOGINFO)
                    return self._parse(sig)
        except Exception as e:
            xbmc.log(f"[vodkool] read_sig: {e}", xbmc.LOGWARNING)
        sig = self.get_new_signature()
        if sig:
            self.save_signature(sig)
            return self._parse(sig)
        return None

    def get_new_signature(self):
        if self._tok and _is_sig_valid(self._tok):
            return self._tok
        payload = json.dumps(_build_payload()).encode("utf-8")
        headers = {
            "accept": "application/json",
            "content-type": "application/json; charset=utf-8",
            "user-agent": _LOKKE_UA,
            "Accept-Language": "de",
        }
        try:
            req = urllib.request.Request(_LOKKE_URL, data=payload, headers=headers)
            with urllib.request.urlopen(req, timeout=20) as r:
                data = json.loads(r.read())
            sig = (data.get("addonSig") or data.get("signature") or
                   data.get("mediahubmxSignature") or data.get("mediahubmx-signature") or
                   data.get("token") or "").strip()
            if sig:
                self._tok = sig
                xbmc.log("[vodkool] Neue Signatur von lokke.app", xbmc.LOGINFO)
                return sig
            xbmc.log(f"[vodkool] Ping OK, keine Signatur. Keys: {list(data.keys())}", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[vodkool] Ping fehlgeschlagen: {e}", xbmc.LOGERROR)
        return None

    def save_signature(self, sig):
        try:
            with xbmcvfs.File(self.path, "w") as f:
                f.write(sig.strip())
        except Exception as e:
            xbmc.log(f"[vodkool] save_sig: {e}", xbmc.LOGERROR)

    def reset_signature(self):
        try:
            if xbmcvfs.exists(self.path):
                xbmcvfs.delete(self.path)
            self._tok = None
        except Exception:
            pass

    def _parse(self, sig):
        parts = sig.split(".")
        if len(parts) == 3:
            try:
                pad = lambda s: s + "=" * (-len(s) % 4)
                pl = json.loads(base64.urlsafe_b64decode(pad(parts[1])))
                return {"mediahubmx-jwt": sig, "mediahubmx-raw": sig,
                        "mediahubmx-signature": parts[2],
                        "mediahubmx-data-json": json.dumps(pl), "mediahubmx-data-b64": parts[1]}
            except Exception:
                pass
        try:
            d = json.loads(base64.b64decode(sig + "=" * (-len(sig) % 4)))
            return {"mediahubmx-signature": d.get("signature", sig), "mediahubmx-raw": sig}
        except Exception:
            pass
        return {"mediahubmx-signature": sig, "mediahubmx-raw": sig}
