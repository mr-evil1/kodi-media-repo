import xbmcgui, xbmcplugin, xbmcaddon, xbmc, sys

def play_m3u8_stream(m3u8_url, label="Live TV", thumb=None):
    li = xbmcgui.ListItem(label=label, path=m3u8_url)
    li.setProperty('IsPlayable', 'true')
    li.setMimeType('application/vnd.apple.mpegurl')
    li.setContentLookup(False)

    try:
        xbmcaddon.Addon('inputstream.ffmpegdirect')
        has_ffmpegdirect = True
    except Exception:
        has_ffmpegdirect = False

    if has_ffmpegdirect:
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        li.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift')
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        li.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        li.setProperty('inputstream.ffmpegdirect.protocol_whitelist',
                        'http,https,tcp,tls,crypto')

        stream_opts = ':'.join([
            'http_persistent=1',
            'multiple_requests=1',
            'reconnect=1',
            'reconnect_streamed=1',
            'reconnect_delay_max=2',
            'timeout=10000000',
        ])
        li.setProperty('inputstream.ffmpegdirect.stream_opts', stream_opts)

        li.setProperty('inputstream.ffmpegdirect.user_agent', 'libmpv')

        xbmc.log('[vodkool] FFmpegDirect mit keep-alive aktiviert', xbmc.LOGINFO)

    else:
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')
        li.setProperty('inputstream.adaptive.chooser_bandwidth_mode', '0')
        xbmc.log('[vodkool] Fallback auf adaptive (FFmpegDirect nicht verfügbar)', xbmc.LOGWARNING)

    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})

    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
