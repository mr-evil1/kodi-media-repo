import xbmc, xbmcplugin, xbmcgui, sys, requests, re, ssl, random, resolveurl

ssl._create_default_https_context = ssl._create_unverified_context
HANDLE = int(sys.argv[1]) if len(sys.argv)>1 else 1

_UA = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
]

def _err(msg):
    xbmcgui.Dialog().ok("Uuups", msg)
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

def play_hoster(hoster_url):
    real_url = hoster_url
    if re.match(r"^[a-zA-Z0-9\-_]+$", hoster_url) and len(hoster_url)>30:
        api_url = f"https://www.kool.to/web-vod/api/get?link={hoster_url}"
        headers = {"User-Agent":random.choice(_UA),"Referer":"https://www.kool.to/","Origin":"https://www.kool.to"}
        for attempt in range(2):
            try:
                r = requests.get(api_url, headers=headers, verify=False, timeout=10, allow_redirects=True)
                real_url = r.url
                if real_url==api_url or not real_url.startswith("http"):
                    if attempt==0: continue
                    return _err("Mögliche Ursachen:\n- Der Link ist abgelaufen\n- Server überlastet\n\nTipp: VPN/Proxy hilft oft!")
                break
            except Exception as e:
                if attempt==0: continue
                return _err(f"Netzwerkfehler:\n{e}")

    if "vidoza.net" in real_url:
        m = re.search(r'vidoza\.net/(?:embed-|e/)?([a-zA-Z0-9]+)', real_url)
        if m:
            try:
                r = requests.post(f"https://vidoza.net/api/source/{m.group(1)}",
                                  headers={"Origin":"https://vidoza.net","Referer":real_url,"User-Agent":random.choice(_UA)},
                                  data={}, timeout=10)
                url = r.json().get("file")
                if url:
                    li = xbmcgui.ListItem(path=url)
                    li.setProperty('IsPlayable','true')
                    xbmcplugin.setResolvedUrl(HANDLE,True,li); return
            except Exception as e:
                xbmc.log(f"[vodkool] Vidoza: {e}", xbmc.LOGERROR)
        return _err("Vidoza: Stream nicht auflösbar")

    try:
        url = resolveurl.resolve(real_url)
        if url and url.startswith("http"):
            li = xbmcgui.ListItem(path=url)
            li.setProperty('IsPlayable','true')
            xbmcplugin.setResolvedUrl(HANDLE,True,li)
        else:
            _err("Kein Direktlink gefunden.\nVPN/Proxy versuchen!")
    except Exception as e:
        _err(f"resolveurl Fehler:\n{e}")
