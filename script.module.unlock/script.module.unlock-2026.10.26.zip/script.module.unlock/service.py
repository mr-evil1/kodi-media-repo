import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import xbmc
import core

INTERVAL = 6 * 3600


def wait_for_gui(monitor):
    while xbmc.getCondVisibility('Window.IsVisible(startup)') or xbmc.getCondVisibility('Window.IsActive(busydialog)'):
        if monitor.waitForAbort(2):
            return False
    return True


def run():
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(10):
        return
    if core.is_first_run():
        if not wait_for_gui(monitor):
            return
        if not core.show_first_run_disclaimer():
            return
        core.apply_after_confirm(monitor)
        if monitor.waitForAbort(INTERVAL):
            return
    while not monitor.abortRequested():
        core.apply_all(monitor)
        if monitor.waitForAbort(INTERVAL):
            break


if __name__ == '__main__':
    run()
