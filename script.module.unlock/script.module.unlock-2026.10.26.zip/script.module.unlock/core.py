import os
import ssl
import json
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError
except ImportError:
    from urllib2 import urlopen, Request, URLError

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE_FILE = os.path.join(PROFILE, 'addons_cache.json')
DISCLAIMER_MARKER = os.path.join(PROFILE, '.disclaimer_confirmed')
FALLBACK_URL = 'https://raw.githubusercontent.com/mr-evil1/kodi-media-repo/refs/heads/main/script.module.unlock/addons.json'
LAST_ERROR = ['']
MARKERS = {'plugin.video.moviescout': ['.disclaimer_asked']}


def is_german():
    lang = xbmc.getInfoLabel('System.Language').lower()
    return 'german' in lang or 'deutsch' in lang or 'austria' in lang or 'oesterreich' in lang


def t(de, en):
    return de if is_german() else en


def is_first_run():
    return not os.path.exists(DISCLAIMER_MARKER)


def mark_confirmed():
    try:
        os.makedirs(PROFILE, exist_ok=True)
        with open(DISCLAIMER_MARKER, 'w') as f:
            f.write('1')
    except Exception:
        pass


def show_first_run_disclaimer():
    german = is_german()

    if german:
        title = 'Rechtlicher Hinweis'
        msg = (
            'RECHTLICHER HINWEIS\n\n'
            'Dieses Script kann Einstellungen in installierten Kodi-Addons verändern, '
            'um gesperrte oder nicht lizenzierte Inhalte freizuschalten.\n'
            'Dies kann in deinem Land illegal sein.\n\n'
            'Der Ersteller übernimmt KEINE Haftung.\n\n'
            'Mit "Einverstanden" bestätigst du:\n'
            '- Du kennst die Rechtslage in deinem Land\n'
            '- Du trägst die volle Verantwortung\n\n'
            'Möchtest du fortfahren?'
        )
        yes_label = 'Einverstanden'
        no_label = 'Ablehnen'
        confirm_title = 'Bitte bestätigen'
        confirm_msg = (
            'Du hast "[B]Einverstanden[/B]" gewählt.\n\n'
            'Bitte bestätige, dass du die Verantwortung für die Nutzung dieses Scripts übernimmst.'
        )
        confirm_yes = 'Ja, ich bestätige'
        confirm_no = 'Nein, abbrechen'
    else:
        title = 'Legal Disclaimer'
        msg = (
            'LEGAL DISCLAIMER\n\n'
            'This script can modify settings in installed Kodi addons to unlock '
            'restricted or non-licensed content.\n'
            'This may be illegal in your country.\n\n'
            'The creator does NOT accept any liability.\n\n'
            'By clicking "I Agree" you confirm that:\n'
            '- You are aware of the legal situation in your country\n'
            '- You accept full personal responsibility\n\n'
            'Do you wish to continue?'
        )
        yes_label = 'I Agree'
        no_label = 'Decline'
        confirm_title = 'Please Confirm'
        confirm_msg = (
            'You selected "[B]I Agree[/B]".\n\n'
            'Please confirm that you accept full responsibility for using this script.'
        )
        confirm_yes = 'Yes, I confirm'
        confirm_no = 'No, cancel'

    if not xbmcgui.Dialog().yesno(
        f'{ADDON_NAME} – {title}', msg,
        nolabel=no_label, yeslabel=yes_label
    ):
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            t('Abgelehnt – Script wird beendet.', 'Declined – script closed.'),
            xbmcgui.NOTIFICATION_INFO, 3000
        )
        return False

    if not xbmcgui.Dialog().yesno(
        f'{ADDON_NAME} – {confirm_title}', confirm_msg,
        nolabel=confirm_no, yeslabel=confirm_yes
    ):
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            t('Abgebrochen.', 'Cancelled.'),
            xbmcgui.NOTIFICATION_INFO, 2000
        )
        return False

    mark_confirmed()
    xbmcgui.Dialog().notification(
        ADDON_NAME,
        t('Bestätigt – Script freigeschaltet.', 'Confirmed – script unlocked.'),
        xbmcgui.NOTIFICATION_INFO, 3000
    )
    return True


def normalize(addon_entry):
    if 'key' in addon_entry:
        s = {
            'key': addon_entry['key'],
            'unlock': addon_entry['unlock'],
            'lock': addon_entry.get('lock', 'false' if addon_entry['unlock'] == 'true' else 'true'),
            'method': addon_entry.get('method', 'auto'),
            'xml_format': addon_entry.get('xml_format'),
        }
        return dict(addon_entry, settings=[s])
    for s in addon_entry.get('settings', []):
        s.setdefault('method', 'auto')
        s.setdefault('xml_format', None)
        if 'lock' not in s:
            s['lock'] = 'false' if s['unlock'] == 'true' else 'true'
    return addon_entry


def log(msg):
    xbmc.log(f'[{ADDON_NAME}] {msg}', xbmc.LOGWARNING)


def download(url):
    req = Request(url, headers={'User-Agent': 'Mozilla/5.0 (Linux; Android) Kodi/21 script.module.unlock'})
    contexts = [None]
    try:
        unverified = ssl.create_default_context()
        unverified.check_hostname = False
        unverified.verify_mode = ssl.CERT_NONE
        contexts.append(unverified)
    except Exception:
        pass
    last = None
    for ctx in contexts:
        try:
            if ctx is None:
                raw = urlopen(req, timeout=15).read()
            else:
                raw = urlopen(req, timeout=15, context=ctx).read()
            return json.loads(raw.decode('utf-8-sig'))
        except Exception as e:
            last = e
            log(f'download failed ({url}): {e!r}')
    raise last


def fetch_list(url):
    candidates = [url]
    if FALLBACK_URL not in candidates:
        candidates.append(FALLBACK_URL)
    for u in candidates:
        try:
            data = download(u)
            os.makedirs(PROFILE, exist_ok=True)
            with open(CACHE_FILE, 'w', encoding='utf-8') as fh:
                json.dump(data, fh)
            return data, True
        except Exception as e:
            LAST_ERROR[0] = repr(e)
    return load_cache(), False


def load_cache():
    try:
        with open(CACHE_FILE, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return None


def is_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except Exception:
        return False


def _get_settings_path(addon_id):
    try:
        profile = xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('profile'))
        return os.path.join(profile, 'settings.xml'), profile
    except Exception:
        return None, None


def _set_elem_value(elem, value, xml_format):
    elem.attrib.pop('default', None)
    if xml_format == 'text':
        elem.attrib.pop('value', None)
        elem.text = value
    else:
        elem.set('value', value)
        elem.text = None


def _detect_format(root, elem):
    if elem is not None:
        return 'attr' if elem.get('value') is not None else 'text'
    for e in root.findall('setting'):
        if e.get('value') is not None:
            return 'attr'
    return 'text'


def read_xml_setting(addon_id, key):
    path, _ = _get_settings_path(addon_id)
    if not path or not os.path.exists(path):
        return None
    try:
        root = ET.parse(path).getroot()
        for elem in root.findall('setting'):
            if elem.get('id') == key:
                if elem.get('default') == 'true':
                    return None
                if elem.get('value') is not None:
                    return elem.get('value')
                return (elem.text or '').strip()
    except Exception as e:
        log(f'read failed {addon_id}: {e!r}')
    return None


def write_xml_setting(addon_id, key, value, xml_format=None):
    path, profile = _get_settings_path(addon_id)
    if not path:
        return False
    try:
        os.makedirs(profile, exist_ok=True)
        if os.path.exists(path):
            tree = ET.parse(path)
            root = tree.getroot()
        else:
            root = ET.Element('settings', {'version': '2'})
            tree = ET.ElementTree(root)

        target = None
        for elem in root.findall('setting'):
            if elem.get('id') == key:
                target = elem
                break
        fmt = xml_format or _detect_format(root, target)
        if target is None:
            target = ET.SubElement(root, 'setting')
            target.set('id', key)
        _set_elem_value(target, value, fmt)

        tree.write(path, encoding='utf-8', xml_declaration=True)
        return True
    except Exception as e:
        log(f'write failed {addon_id}: {e!r}')
        return False


def api_get(addon_id, key):
    try:
        return xbmcaddon.Addon(addon_id).getSetting(key)
    except Exception as e:
        log(f'api get failed {addon_id}: {e!r}')
        return None


def apply(addon_entry, unlock):
    addon_id = addon_entry['id']
    success = True
    for s in addon_entry.get('settings', []):
        value = s['unlock'] if unlock else s['lock']
        key = s['key']
        try:
            if api_get(addon_id, key) == value:
                log(f'{addon_id} {key} already {value}')
                continue
            if s['method'] in ('api', 'auto'):
                try:
                    xbmcaddon.Addon(addon_id).setSetting(key, value)
                except Exception as e:
                    log(f'api set failed {addon_id}: {e!r}')
                if api_get(addon_id, key) == value:
                    log(f'{addon_id} {key} set to {value} via api')
                    continue
            if write_xml_setting(addon_id, key, value, s.get('xml_format')):
                log(f'{addon_id} {key} set to {value} via xml')
            else:
                log(f'{addon_id} {key} FAILED')
                success = False
        except Exception as e:
            log(f'apply failed {addon_id}: {e!r}')
            success = False
    return success


def write_markers(entry):
    names = list(MARKERS.get(entry['id'], [])) + list(entry.get('marker_files', []))
    if not names:
        return
    _, profile = _get_settings_path(entry['id'])
    if not profile:
        return
    try:
        os.makedirs(profile, exist_ok=True)
        for name in names:
            path = os.path.join(profile, name)
            if not os.path.exists(path):
                with open(path, 'w') as f:
                    f.write('1')
                log(f"{entry['id']} marker {name} written")
    except Exception as e:
        log(f"marker failed {entry['id']}: {e!r}")


def get_list(url, monitor):
    data = None
    for _ in range(3):
        data, online = fetch_list(url)
        if online:
            return data
        if monitor.waitForAbort(10):
            break
    return data


def apply_all(monitor):
    url = ADDON.getSetting('list_url').strip() or FALLBACK_URL
    data = get_list(url, monitor)
    if not data:
        log('no list available')
        return
    log(f"list loaded with {len(data.get('addons', []))} entries")
    for entry in data.get('addons', []):
        try:
            if not is_installed(entry['id']):
                continue
            entry = normalize(entry)
            write_markers(entry)
            if not apply(entry, True):
                log(f"could not apply {entry['id']}")
        except Exception as e:
            log(f'error {e!r}')


def apply_after_confirm(monitor):
    apply_all(monitor)
    if monitor.waitForAbort(5):
        return
    apply_all(monitor)
