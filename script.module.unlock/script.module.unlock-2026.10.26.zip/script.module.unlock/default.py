import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import xbmc
import core


if __name__ == '__main__':
    monitor = xbmc.Monitor()
    if core.is_first_run():
        if core.show_first_run_disclaimer():
            core.apply_after_confirm(monitor)
    else:
        core.apply_all(monitor)
