import urllib .parse 
import xbmc 
import xbmcgui 
import xbmcplugin 

from .api import BedrockAPI 
from .auth import USER_AGENT 

DRM_LICENSE_URL ='https://lic.drmtoday.com/license-proxy-widevine/cenc/'

def _log (msg ):
    xbmc .log (f'[RTL+ Player] {msg }',xbmc .LOGDEBUG )

def _q (value ):
    return urllib .parse .quote (str (value ).encode ('utf8'))

class RTLPlayer :
    def __init__ (self ,handle ):
        self .handle =handle 
        self .api =BedrockAPI ()

    def play_vod (self ,video_id ,title ='Video',video_seo ='',program_seo ='',program_id =''):
        _log (f'play_vod id={video_id }')

        assets =self .api .get_video_assets (video_id ,video_seo =video_seo ,program_seo =program_seo ,program_id =program_id )
        if not assets :
            xbmcgui .Dialog ().notification ('RTL+','Stream nicht gefunden',xbmcgui .NOTIFICATION_ERROR ,5000 )
            xbmcplugin .setResolvedUrl (self .handle ,False ,xbmcgui .ListItem ())
            return 

        asset =self ._best_asset (assets )
        _log (f'Asset: quality={asset ["quality"]} drm_type={asset ["drm_type"]}')

        drm_cfg =asset .get ('drm_config',{})
        service_code =drm_cfg .get ('serviceCode','video_tv')
        content_id =drm_cfg .get ('contentId',video_id )

        drm_token =self .api .auth .get_drm_token (service_code ,'video',content_id )
        self ._resolve (asset ['path'],drm_token ,title ,is_live =False )

    def play_audio (self ,audio_id ,title ='Audio'):
        _log (f'play_audio id={audio_id }')

        assets =self .api .get_audio_assets (audio_id )
        if not assets :
            xbmcgui .Dialog ().notification ('RTL+','Audio-Stream nicht gefunden',
            xbmcgui .NOTIFICATION_ERROR ,5000 )
            xbmcplugin .setResolvedUrl (self .handle ,False ,xbmcgui .ListItem ())
            return 

        def _audio_score (a ):
            fmt =a .get ('format','')
            return {'mp3':10 ,'passthrough_mp3_mpeg':9 ,'aac':7 ,'hls':5 ,'m3u8':5 }.get (fmt ,3 )

        asset =max (assets ,key =_audio_score )
        _log (f'Audio asset: format={asset ["format"]} path={asset ["path"][:80 ]}')

        self ._resolve_audio (asset ['path'],title )

    def play_radio (self ,radio_id ,title ='Radio'):
        _log (f'play_radio id={radio_id }')

        assets =self .api .get_radio_assets (radio_id )

        if assets :

            def _radio_score (a ):
                fmt =a .get ('format','')
                return {'hls':10 ,'m3u8':10 ,'mp3':8 ,'aac':7 ,
                'dash':3 ,'dashcenc':2 }.get (fmt ,5 )
            asset =max (assets ,key =_radio_score )
            stream_url =asset ['path']
            fmt =asset .get ('format','')
            _log (f'Radio asset: format={fmt } url={stream_url [:80 ]}')

            if fmt in ('hls','m3u8','mp3','aac','passthrough_mp3_mpeg'):
                self ._resolve_audio (stream_url ,title )
                return 

            drm_cfg =asset .get ('drm_config',{})
            service_code =drm_cfg .get ('serviceCode','rtlplus_root')
            content_id =drm_cfg .get ('contentId',radio_id )
            drm_token =self .api .auth .get_drm_token (service_code ,'live',content_id )if drm_cfg else None 
            self ._resolve (stream_url ,drm_token ,title ,is_live =True )
        else :
            xbmcgui .Dialog ().notification ('RTL+','Radio-Stream nicht gefunden',
            xbmcgui .NOTIFICATION_ERROR ,5000 )
            xbmcplugin .setResolvedUrl (self .handle ,False ,xbmcgui .ListItem ())

    def play_live (self ,channel_id ,service_code ='rtlplus_root',content_id ='',title ='Live'):
        _log (f'play_live channel={channel_id }')

        if not content_id :
            content_id =f'dashcenc_rtlde_{channel_id }'

        assets =self .api .get_live_assets (channel_id )

        if assets :
            asset =self ._best_asset (assets )
            mpd_url =asset ['path']
            drm_cfg =asset .get ('drm_config',{})
            service_code =drm_cfg .get ('serviceCode',service_code )
            live_content_id =drm_cfg .get ('contentId',content_id )
        else :
            _log ('No assets, using fallback URL')
            mpd_url =(f'https://origin.live.rtlde.bedrock.tech/out/v1/rtlde/'
            f'rtlde-{channel_id }/cmaf_cenc71/dash-short-hd720.mpd')
            live_content_id =content_id 

        _log (f'Live MPD: {mpd_url }')

        drm_token =self .api .auth .get_drm_token (service_code ,'live',live_content_id )
        self ._resolve (mpd_url ,drm_token ,title ,is_live =True )

    def _resolve (self ,mpd_url ,drm_token ,title ,is_live =False ):
        li =xbmcgui .ListItem (label =title ,path =mpd_url )
        li .setInfo ('video',{'title':title ,'mediatype':'video'})

        li .setProperty ('inputstream','inputstream.adaptive')
        li .setProperty ('inputstream.adaptive.manifest_type','mpd')

        stream_headers =(
        f'User-Agent={_q (USER_AGENT )}'
        f'&Origin={_q ("https://plus.rtl.de")}'
        f'&Referer={_q ("https://plus.rtl.de/")}'
        )
        li .setProperty ('inputstream.adaptive.stream_headers',stream_headers )
        li .setProperty ('inputstream.adaptive.manifest_headers',stream_headers )

        if drm_token :
            lic_headers =(
            f'Content-Type=application%2Foctet-stream'
            f'&User-Agent={_q (USER_AGENT )}'
            f'&Origin={_q ("https://plus.rtl.de")}'
            f'&Referer={_q ("https://plus.rtl.de/")}'
            f'&x-dt-auth-token={_q (drm_token )}'
            )
            license_key =f'{DRM_LICENSE_URL }|{lic_headers }|R{{SSM}}|JBlicense'
            li .setProperty ('inputstream.adaptive.license_type','com.widevine.alpha')
            li .setProperty ('inputstream.adaptive.license_key',license_key )
            _log ('DRM: license_key mit JBlicense Response-Filter gesetzt')
        else :
            _log ('Kein DRM-Token verfügbar')

        xbmcplugin .setResolvedUrl (self .handle ,True ,li )

    def _resolve_audio (self ,url ,title ):
        _log (f'_resolve_audio url={url [:100 ]}')

        stream_headers =urllib .parse .urlencode ({
        'User-Agent':USER_AGENT ,
        'Referer':'https://plus.rtl.de/',
        'Origin':'https://plus.rtl.de',
        })
        full_url =f'{url }|{stream_headers }'

        li =xbmcgui .ListItem (label =title ,path =full_url )
        li .setInfo ('music',{'title':title })
        li .setProperty ('IsPlayable','true')

        xbmcplugin .setResolvedUrl (self .handle ,True ,li )

    def _best_asset (self ,assets ):
        def score (a ):
            drm_score =10 if a .get ('drm_type')=='software'else 5 
            q =a .get ('video_quality',a .get ('quality','sd'))
            quality_score ={'hd':3 ,'hd2':4 ,'sd':1 ,'fhd':5 }.get (q ,2 )
            return drm_score +quality_score 
        return max (assets ,key =score )
