import os
import urllib .parse
import hashlib
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

from .api import BedrockAPI

IMAGE_CDN ='https://images-fio.rtlde.bedrock.tech'

_IMAGE_KEY ='x9vGg4RNeNBqV2nBfhqLV6cN4n'

def _sign_image (path_and_query :str )->str :
    return hashlib .sha1 ((path_and_query +_IMAGE_KEY ).encode ()).hexdigest ()

CHANNEL_IMAGES ={
'rtl':'channel/rtl.png',
'vox':'channel/vox.png',
'rtlzwei':'channel/rtl2.png',
'rtl2':'channel/rtl2.png',
'nitro':'channel/nitro.png',
'ntv':'channel/ntv.png',
'rtlup':'channel/rtlup.png',
'rtlplus':'channel/rtlplus.png',
'voxup':'channel/voxup.png',
'super_rtl':'channel/superrtl.png',
'superrtl':'channel/superrtl.png',
'toggo_plus':'channel/toggoplus.png',
'toggoplus':'channel/toggoplus.png',
'now':'channel/tvnow.png',
'tvnow':'channel/tvnow.png',
'tvnowkids':'channel/tvnowkids.png',
'geo':'channel/geo.png',
'crime':'channel/crime.png',
'living':'channel/living.png',
'passion':'channel/passion.png',
'nowus':'channel/nowus.png',
'watchbox':'channel/watchbox.png',
}

def _log (msg ):
    xbmc .log (f'[RTL+ Nav] {msg }',xbmc .LOGDEBUG )

_PREMIUM_STATUS_CACHE = {}

def _get_premium_status ():
    import time as _time
    cached = _PREMIUM_STATUS_CACHE.get('result')
    cached_ts = _PREMIUM_STATUS_CACHE.get('ts', 0)
    if cached is not None and (_time.time() - cached_ts) < 21600:
        return cached
    try:
        from .auth import RTLAuth
        result = RTLAuth().get_subscription_tier()
    except Exception:
        result = 'Free'
    _PREMIUM_STATUS_CACHE['result'] = result
    _PREMIUM_STATUS_CACHE['ts'] = _time.time()
    return result

def _premium_title (title ):
    return f'[COLOR gold]{title} (Premium)[/COLOR]'

def _quality_label ():
    """Gibt ein Qualitäts-Label basierend auf der quality_max-Einstellung zurück."""
    try :
        idx =int (xbmcaddon .Addon ().getSetting ('quality_max')or '0')
        return ('1080p','720p','576p','360p')[idx ]if 0 <=idx <=3 else ''
    except Exception :
        return ''

def _clean_title (title ):
    import re as _re
    title = _re.sub(r'\s*(Main Root Service|Root Service|Main Service|Main Root)\b', '', title, flags=_re.IGNORECASE)
    return title.strip()

def _ep_sort_key (ic ):
    import re as _re
    hl =ic .get ('highlight','')or ''
    s ,e ,date_str =0 ,0 ,''
    for part in hl .split ('•'):
        pl =part .strip ().lower ()
        if pl .startswith ('staffel'):
            m =_re .search (r'\d+',pl )
            if m :
                try :s =int (m .group ())
                except :pass
        elif pl .startswith ('folge'):
            m =_re .search (r'\d+',pl )
            if m :
                try :e =int (m .group ())
                except :pass
        else :
            dm =_re .search (r'(\d{2})\.(\d{2})\.(\d{4})',part )
            if dm and not date_str :
                date_str =f'{dm .group (3 )}-{dm .group (2 )}-{dm .group (1 )}'
    return (s ,e ,date_str )

def _image_url (image_data ,width =320 ,height =180 ,preferred_ratio ='16:9'):
    if not image_data :
        return ''
    if isinstance (image_data ,str ):
        img_id =image_data
    elif isinstance (image_data ,dict ):
        ids_by_ratio =image_data .get ('idsByRatio',{})or {}
        img_id =(ids_by_ratio .get (preferred_ratio ,'')
        or ids_by_ratio .get ('16:9','')
        or ids_by_ratio .get ('2:3','')
        or next (iter (ids_by_ratio .values ()),'')
        or image_data .get ('id',''))
    else :
        return ''
    if not img_id :
        return ''

    params =(f'auto=avif&blur=0&fit=max'
    f'&height={height }&interlace=1&quality=100&width={width }')
    path_and_query =f'/v2/images/{img_id }/raw?{params }'
    sig =_sign_image (path_and_query )

    headers =urllib .parse .urlencode ({
    'Referer':'https://plus.rtl.de/',
    'User-Agent':'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36',
    })
    return f'{IMAGE_CDN }{path_and_query }&hash={sig }|{headers }'

class Navigator :
    def __init__ (self ,handle ,base_url ):
        self .handle =handle
        self .base_url =base_url
        self .api =BedrockAPI ()

    def _img (self ,fname ):
        import os ,xbmcaddon ,xbmcvfs
        _addon =xbmcaddon .Addon ()
        _addon_path =xbmcvfs .translatePath (_addon .getAddonInfo ('path'))
        return os .path .join (_addon_path ,'resources','media',fname )

    def build_url (self ,params ):
        return self .base_url +'?'+urllib .parse .urlencode (params )

    def show_main_menu (self ):
        import os
        import xbmcaddon
        import xbmcvfs
        _addon =xbmcaddon .Addon ()
        _addon_path =xbmcvfs .translatePath (_addon .getAddonInfo ('path'))
        _profile =xbmcvfs .translatePath (_addon .getAddonInfo ('profile'))
        _token_file =os .path .join (_profile ,'tokens.json')
        _logged_in =os .path .exists (_token_file )and _addon .getSetting ('username')!=''

        if _logged_in :

            reality_id ='1'
            kids_id ='148'
            anime_id ='165'
            try :
                nav_data =self .api .get_navigation ()
                if nav_data :
                    def _find_folder (obj ,keywords ):
                        if isinstance (obj ,dict ):
                            label =str (obj .get ('label','')or obj .get ('title','')or '').lower ()
                            vl =obj .get ('value_layout',{})or {}
                            if any (k in label for k in keywords )and vl .get ('type')=='folder':
                                return str (vl .get ('id',''))
                            for v in obj .values ():
                                r =_find_folder (v ,keywords )
                                if r :return r
                        elif isinstance (obj ,list ):
                            for v in obj :
                                r =_find_folder (v ,keywords )
                                if r :return r
                        return ''
                    reality_id =_find_folder (nav_data ,['reality','dating','show'])or reality_id
                    anime_id =_find_folder (nav_data ,['anime'])or anime_id
                    kids_id =_find_folder (nav_data ,['kids','kinder','toggo'])or kids_id
            except Exception :
                pass

            _account_type = _get_premium_status()
            _mein_label = f'Mein {_account_type} RTL+'

            items =[

            (_mein_label,{'mode':'show_meine_inhalte'},self._img ('favourites.png')),

            ('Startseite',{'mode':'show_alias','alias':'home'},self._img ('icon.png')),
            *([ ('Live-TV',{'mode':'show_live'},self._img ('icon.png')) ] if _account_type in ('Premium','Basic') else []),
            ('Filme',{'mode':'show_folder','folder_id':'4'},self._img ('icon.png')),
            ('Filme A-Z',{'mode':'show_jw_az','obj_type':'MOVIE','page':'1'},self._img ('icon.png')),
            ('Serien',{'mode':'show_folder','folder_id':'3'},self._img ('icon.png')),
            ('Serien A-Z',{'mode':'show_jw_az','obj_type':'SHOW','page':'1'},self._img ('icon.png')),
            ('Shows',{'mode':'show_folder','folder_id':'2','seo':'shows-rtl'},self._img ('icon.png')),
            ('Reality',{'mode':'show_folder','folder_id':reality_id },self._img ('icon.png')),
            ('Anime',{'mode':'show_folder','folder_id':anime_id },self._img ('icon.png')),
            ('Sport',{'mode':'show_folder','folder_id':'6'},self._img ('icon.png')),
            ('Kids',{'mode':'show_folder','folder_id':kids_id },self._img ('icon.png')),
            ('Neuheiten entdecken',{'mode':'show_folder','folder_id':'17','seo':'neu-auf-rtl-main-root-service-f_17'},self._img ('icon.png')),
            ('Adrenalin & Spannung',{'mode':'show_folder','folder_id':'150','seo':'action-main-root-service-f_150'},self._img ('icon.png')),

            ('Podcasts',{'mode':'show_service','service':'podcast',
            'label':urllib .parse .quote_plus ('Podcasts')},self._img ('icon.png')),
            ('Hörbücher',{'mode':'show_service','service':'hoerbuecher',
            'label':urllib .parse .quote_plus ('Hörbücher')},self._img ('icon.png')),
            ('Radio',{'mode':'show_service','service':'live-radios',
            'label':urllib .parse .quote_plus ('Radio')},self._img ('icon.png')),
            ]

            items.append(('[COLOR gold]Gast Inhalte[/COLOR]',{'mode':'show_guest_free'},self._img ('icon.png')))

            if _addon.getSetting('show_az_menu') == 'true':
                items.append(('A-Z',{'mode':'show_az'},self._img ('basesearch.png')if os .path .exists (self._img ('basesearch.png'))else self._img ('icon.png')))

            items.extend([
            ('Suche',{'mode':'search'},self._img ('basesearch.png')if os .path .exists (self._img ('basesearch.png'))else self._img ('icon.png')),

            ('Einstellungen',{'mode':'settings'},self._img ('settings.png')),
            ('Addon Reset',{'mode':'reset'},self._img ('remove.png')),
            ('Logout',{'mode':'logout'},self._img ('remove.png')),
            ])
        else :
            try :
                from resources .lib .auth import RTLAuth as _RTLAuth
                _RTLAuth ().guest_login ()
            except Exception :
                pass
            items =[
            ('Anmelden',{'mode':'login'},self._img ('icon.png')),
            ('[COLOR gold]Gast Inhalte[/COLOR]',{'mode':'show_guest_free'},self._img ('icon.png')),
            ('Addon Reset',{'mode':'reset'},self._img ('remove.png')),
            ]

        for label ,params ,thumb in items :
            li =xbmcgui .ListItem (label =label )
            li .setProperty ('IsPlayable','false')
            if os .path .exists (thumb ):
                li .setArt ({'thumb':thumb ,'icon':thumb })
            li .setInfo ('video',{'title':label })
            xbmcplugin .addDirectoryItem (
            handle =self .handle ,
            url =self .build_url (params ),
            listitem =li ,
            isFolder =params .get ('mode')not in ('settings','logout','login','reset')
            )
        xbmcplugin .endOfDirectory (self .handle )

    def show_guest_free (self ):
        import os ,hashlib
        import xbmcaddon ,xbmcvfs
        _addon =xbmcaddon .Addon ()
        _addon_path =xbmcvfs .translatePath (_addon .getAddonInfo ('path'))
        _profile =xbmcvfs .translatePath (_addon .getAddonInfo ('profile'))
        _token_file =os .path .join (_profile ,'tokens.json')
        _logged_in =(not self .api .auth ._guest_tokens .get ('is_guest',False )
                     and bool (self .api .auth ._tokens .get ('access_token','')))

        _log (f'show_guest_free: lade Gast-Inhalte (logged_in={_logged_in })')
        data =self .api .get_folder_guest ('193',nb_pages =5 )
        if not data and not _logged_in :
            try :
                from resources .lib .auth import RTLAuth as _RTLAuth
                _RTLAuth ().guest_login ()
            except Exception :
                pass
            data =self .api .get_folder_guest ('193',nb_pages =5 )
        if not data :
            xbmcgui .Dialog ().notification (
                'RTL+','Gast Inhalte nicht ladbar.',
                xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        _IMAGE_KEY ='x9vGg4RNeNBqV2nBfhqLV6cN4n'
        def _thumb (img ):
            if not img or not isinstance (img ,dict ):return ''
            ids =img .get ('idsByRatio',{})or {}
            img_id =(ids .get ('16:9','')or ids .get ('2:3','')
                     or next (iter (ids .values ()),''))
            if not img_id :return ''
            pq =f'/v2/images/{img_id }/raw?auto=webp&blur=0&fit=max&width=320&height=180&interlace=1&quality=65'
            sig =hashlib .sha1 ((pq +_IMAGE_KEY ).encode ()).hexdigest ()
            return f'https://images-fio.rtlde.bedrock.tech{pq }&hash={sig }'

        xbmcplugin .setContent (self .handle ,'videos')

        live_entries =[]
        other_entries =[]

        _log (f'show_guest_free DEBUG: {len (data .get ("blocks",[]))} Bloecke total')
        for _bi ,_block in enumerate (data .get ('blocks',[])):
            _bc =_block .get ('content',{})
            _items =_bc .get ('items',[])
            _log (f'  Block[{_bi }]: {len (_items )} items')
            for _ii ,_it in enumerate (_items [:3 ]):
                _ic =_it .get ('itemContent',{})
                _act =(_ic .get ('action')or {})
                _tgt =(_act .get ('target')or {})
                _vl =(_tgt .get ('value_layout')or {})
                _vp =(_tgt .get ('value_player')or {})
                _log (f'    item[{_ii }]: t_type={_tgt .get ("type","?")!r} vl_type={_vl .get ("type","?")!r} vl_id={str (_vl .get ("id",""))!r} vp_type={_vp .get ("type","")!r} title={str (_ic .get ("title",""))[:30]!r}')

        for block in data .get ('blocks',[]):
            bc =block .get ('content',{})
            bt =bc .get ('title',{})
            bt =(bt .get ('short','')or bt .get ('long',''))if isinstance (bt ,dict )else str (bt or '')
            for it in bc .get ('items',[]):
                ic =it .get ('itemContent',{})
                _title_raw =ic .get ('title','')or ''
                _extra_title =ic .get ('extraTitle','')or ''
                _action_tmp =(ic .get ('action')or {})
                _target_tmp =(_action_tmp .get ('target')or {})
                _vl_tmp =(_target_tmp .get ('value_layout')or {})
                _seo_tmp =str (_vl_tmp .get ('seo',''))
                _highlight =ic .get ('highlight','')or ''
                _seo_title =_seo_tmp .replace ('-',' ').title ()if _seo_tmp else ''
                if _title_raw and _extra_title :
                    title =f'{_title_raw } - {_extra_title }'
                elif _title_raw :
                    title =_title_raw
                elif _extra_title :
                    title =_extra_title
                elif _seo_title :
                    title =_seo_title
                elif _highlight :
                    title =_highlight .split ('•')[0 ].strip ()
                else :
                    title ='Unbekannt'
                action =(ic .get ('action')or {})
                target =(action .get ('target')or {})
                t_type =target .get ('type','')
                if t_type =='lock':
                    _inner =target .get ('value_lock',{})or {}
                    while _inner .get ('originalTarget',{}).get ('type','')=='lock':
                        _inner =_inner .get ('originalTarget',{}).get ('value_lock',{})or {}
                    _orig =_inner .get ('originalTarget',{})or {}
                    if _orig .get ('type','')in ('layout','player'):
                        target =_orig
                        t_type =_orig .get ('type','')
                vl =(target .get ('value_layout')or {})
                vl_type =vl .get ('type','')
                vl_id =str (vl .get ('id',''))
                vl_seo =str (vl .get ('seo',''))
                vp =(target .get ('value_player')or {})
                vp_id =str (vp .get ('id',''))
                vp_content_type =vp .get ('type','')
                thumb =_thumb (ic .get ('image'))

                if vl_type =='live'and vl_id :
                    channel_slug =vl_id .replace ('rtlde_','')
                    live_label =f'[COLOR gold][B]LIVE - {title }[/B][/COLOR]'
                    url =self .build_url ({
                        'mode':'play_live',
                        'channel_id':channel_slug ,
                        'title':urllib .parse .quote_plus (title ),
                    })
                    li =xbmcgui .ListItem (label =live_label )
                    li .setProperty ('IsPlayable','true')
                    local_img =self ._channel_image (channel_slug )
                    art_img =local_img or thumb
                    if art_img :
                        li .setArt ({'thumb':art_img ,'icon':art_img ,'clearlogo':art_img ,'fanart':art_img })
                    li .setInfo ('video',{'title':'\u0001'+live_label ,'plot':ic .get ('description','')or '','tvshowtitle':bt })
                    live_entries .append ((url ,li ,False ))
                    continue

                if t_type =='player'and vp_id :
                    if vp_content_type in ('live','livetv','channel','event','live_event','event_stream'):
                        live_label =f'[COLOR gold][B]LIVE - {title }[/B][/COLOR]'
                        url =self .build_url ({
                            'mode':'play_live',
                            'channel_id':vp_id ,
                            'title':urllib .parse .quote_plus (title ),
                        })
                        li =xbmcgui .ListItem (label =live_label )
                        li .setProperty ('IsPlayable','true')
                        local_img =self ._channel_image (vp_id )
                        art_img =local_img or thumb
                        if art_img :
                            li .setArt ({'thumb':art_img ,'icon':art_img ,'clearlogo':art_img ,'fanart':art_img })
                        li .setInfo ('video',{'title':'\u0001'+live_label ,'plot':ic .get ('description','')or '','tvshowtitle':bt })
                        live_entries .append ((url ,li ,False ))
                        continue
                    url =self .build_url ({
                        'mode':'play_vod',
                        'video_id':vp_id ,
                        'title':urllib .parse .quote_plus (title ),
                    })
                    li =xbmcgui .ListItem (label =(title) + (f" [{_quality_label()}]" if _quality_label() else ""))
                    li .setProperty ('IsPlayable','true')
                    li .setArt ({'thumb':thumb ,'icon':thumb ,'fanart':thumb })
                    li .setInfo ('video',{'title':title ,'plot':ic .get ('description','')or '','tvshowtitle':bt })
                    other_entries .append ((url ,li ,False ))
                    continue

                if not vl_id :continue
                li =xbmcgui .ListItem (label =title )
                li .setArt ({'thumb':thumb ,'icon':thumb ,'fanart':thumb })
                li .setInfo ('video',{'title':title ,'plot':ic .get ('description','')or '','tvshowtitle':bt })
                if vl_type =='program':
                    url =self .build_url ({'mode':'show_program','program_id':vl_id ,'seo':vl_seo })
                    is_folder =True
                elif vl_type =='video':
                    url =self .build_url ({'mode':'play_vod','video_id':vl_id ,'video_seo':vl_seo ,'title':urllib .parse .quote_plus (title )})
                    li .setProperty ('IsPlayable','true')
                    is_folder =False
                else :
                    continue
                other_entries .append ((url ,li ,is_folder ))

        _show_live =os .path .exists (_token_file )
        _entries_to_show =(live_entries if _show_live else [])+other_entries
        if not _show_live and live_entries :
            _log (f'show_guest_free: {len (live_entries )} Live-Eintraege ausgeblendet (nicht eingeloggt)')

        found =0
        for url ,li ,is_folder in _entries_to_show :
            xbmcplugin .addDirectoryItem (handle =self .handle ,url =url ,listitem =li ,isFolder =is_folder )
            found +=1

        xbmcplugin .addSortMethod (self .handle ,xbmcplugin .SORT_METHOD_NONE )
        _log (f'show_guest_free: {found } Eintraege (davon {len (live_entries ) if _show_live else 0} LIVE)')
        if found ==0 :
            xbmcgui .Dialog ().notification (
                'RTL+','Keine Inhalte gefunden.',xbmcgui .NOTIFICATION_WARNING ,3000 )
        xbmcplugin .endOfDirectory (self .handle )

    _meine_cache ={}

    def show_meine_inhalte (self ):
        _log ('show_meine_inhalte')

        _bt =self .api .auth .get_bedrock_token ()
        if not _bt :
            _log ('show_meine_inhalte: kein Bedrock-Token – OIDC abgelaufen, Neu-Login nötig')
            xbmcgui .Dialog ().notification (
                'RTL+',
                'Sitzung abgelaufen – bitte erneut anmelden.',
                xbmcgui .NOTIFICATION_WARNING ,6000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        from .evil import bookmarks as _bookmarks
        local_data =_bookmarks .get ()

        data =self .api .get_frontspace ('bookmarks',page =1 ,nb_pages =2 )
        if not data and not local_data :
            xbmcgui .Dialog ().notification (
            'RTL+','Mein RTL+: Anmeldung erforderlich oder Serverfehler.',
            xbmcgui .NOTIFICATION_ERROR ,5000
            )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        Navigator ._meine_cache ['local']=local_data or []
        Navigator ._meine_cache ['api']=data or {}

        folder_count =0

        if local_data :
            url =self .build_url ({'mode':'show_meine_block','block_key':'weiterschauen','label':urllib .parse .quote_plus ('Weiterschauen')})
            li =xbmcgui .ListItem (label ='Weiterschauen')
            li .setProperty ('IsPlayable','false')
            li .setArt ({'thumb':os .path .join (xbmcvfs .translatePath (xbmcaddon .Addon ().getAddonInfo ('path')),'resources','media','favourites.png')})
            li .setInfo ('video',{'title':'Weiterschauen','plot':f'{len (local_data )} gespeicherte Inhalte'})
            xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
            folder_count +=1

        if data :
            blocks =data .get ('blocks',[])
            def _is_real_block (b ):
                items =b .get ('content',{}).get ('items',[])
                return any (
                    ((it .get ('itemContent',{})or {}).get ('action',{})or {}).get ('target',{}).get ('value_layout',{}).get ('type','')!='frontspace'
                    for it in items )
            valid_blocks =[b for b in blocks if _is_real_block (b )]
            if not valid_blocks and blocks :
                _log ('show_meine_inhalte: Nur frontspace-Items → Neu anmelden')
                xbmcgui .Dialog ().notification ('RTL+','Bitte neu anmelden.',xbmcgui .NOTIFICATION_WARNING ,5000 )
            _log (f'show_meine_inhalte: {len (valid_blocks )} API-Blöcke mit Inhalten')
            for idx ,block in enumerate (valid_blocks ):
                content_b =block .get ('content',{})
                block_title_obj =content_b .get ('title')or {}
                if isinstance (block_title_obj ,dict ):
                    block_title =block_title_obj .get ('short','')or block_title_obj .get ('long','')or ''
                else :
                    block_title =str (block_title_obj )if block_title_obj else ''
                if not block_title :
                    block_title =f'Meine Inhalte {idx +1 }'
                if block_title .lower ()=='jetzt weiterschauen':
                    block_title ='Jetzt weiterschauen (Online Liste)'
                items =content_b .get ('items',[])
                block_key =f'api_{idx }'
                url =self .build_url ({'mode':'show_meine_block','block_key':block_key ,'label':urllib .parse .quote_plus (block_title )})
                li =xbmcgui .ListItem (label =block_title )
                li .setProperty ('IsPlayable','false')
                li .setArt ({'thumb':os .path .join (xbmcvfs .translatePath (xbmcaddon .Addon ().getAddonInfo ('path')),'resources','media','favourites.png')})
                li .setInfo ('video',{'title':block_title ,'plot':f'{len (items )} Inhalte'})
                xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
                folder_count +=1

        if folder_count ==0 :
            xbmcgui .Dialog ().notification (
            'RTL+','Mein RTL+ ist leer – noch nichts gemerkt oder angesehen.',
            xbmcgui .NOTIFICATION_INFO ,4000
            )
            li =xbmcgui .ListItem (label ='[Keine Inhalte]')
            xbmcplugin .addDirectoryItem (self .handle ,'',li ,False )

        xbmcplugin .endOfDirectory (self .handle )

    def show_meine_block (self ,block_key ,label =''):
        _log (f'show_meine_block key={block_key }')

        if block_key =='weiterschauen':
            local_data =Navigator ._meine_cache .get ('local',[])
            if not local_data :
                from .evil import bookmarks as _bookmarks
                local_data =_bookmarks .get ()
            if not local_data :
                xbmcgui .Dialog ().notification ('RTL+','Keine gespeicherten Inhalte.',xbmcgui .NOTIFICATION_INFO ,3000 )
                xbmcplugin .endOfDirectory (self .handle )
                return
            for item in local_data :
                li =xbmcgui .ListItem (label =item ['label'])
                li .setArt ({'thumb':item .get ('thumb','')})
                li .setProperty ('IsPlayable','true'if item .get ('playable')else 'false')
                li .setInfo ('video',{'title':item ['label']})
                cmd =f'RunPlugin({self .base_url }?mode=remove_bookmark&path={urllib .parse .quote_plus (item ["path"])})'
                li .addContextMenuItems ([('Von Weiterschauen entfernen',cmd )])
                xbmcplugin .addDirectoryItem (self .handle ,item ['path'],li ,bool (item .get ('folder',0)))
            xbmcplugin .setContent (self .handle ,'videos')
            xbmcplugin .endOfDirectory (self .handle )
            return

        try :
            idx =int (block_key .replace ('api_',''))
        except ValueError :
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        data =Navigator ._meine_cache .get ('api')
        if not data :
            data =self .api .get_frontspace ('bookmarks',page =1 ,nb_pages =2 )
            if not data :
                xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden.',xbmcgui .NOTIFICATION_ERROR ,4000 )
                xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
                return
            Navigator ._meine_cache ['api']=data

        blocks =data .get ('blocks',[])
        valid_blocks =[b for b in blocks if b .get ('content',{}).get ('items')]
        if idx >=len (valid_blocks ):
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        items =valid_blocks [idx ].get ('content',{}).get ('items',[])
        total =0
        for item in items :
            if self ._add_item_as_folder (item ):
                total +=1

        if total ==0 :
            li =xbmcgui .ListItem (label ='[Keine Inhalte]')
            xbmcplugin .addDirectoryItem (self .handle ,'',li ,False )

        xbmcplugin .setContent (self .handle ,'videos')
        xbmcplugin .endOfDirectory (self .handle )

    def _add_item_as_folder (self ,item ):
        try :
            ic =item .get ('itemContent',{})
            if not ic :
                return False
            action =ic .get ('action',{})or {}
            target =action .get ('target',{})or {}
            t_type =target .get ('type','')
            if t_type =='lock':
                target =(target .get ('value_lock',{})or {}).get ('originalTarget',{})or {}
                t_type =target .get ('type','')
            vl =target .get ('value_layout',{})or {}
            layout_type =vl .get ('type','')
            layout_id =vl .get ('id','')
            layout_seo =vl .get ('seo','')

            if not layout_id :
                return self ._add_item (item )

            title_raw =ic .get ('title','')or ''
            extra_title =ic .get ('extraTitle','')or ''
            highlight =ic .get ('highlight','')or ''
            seo_title =layout_seo .replace ('-',' ').title ()if layout_seo else ''
            if title_raw and extra_title :
                full_title =f'{title_raw } - {extra_title }'
            elif title_raw :
                full_title =title_raw
            elif extra_title :
                full_title =extra_title
            elif seo_title :
                full_title =seo_title
            elif highlight :
                full_title =highlight .split ('•')[0 ].strip ()
            else :
                return False

            thumb =_image_url (ic .get ('image',{}),width =320 ,height =180 ,preferred_ratio ='16:9')
            fanart =_image_url (ic .get ('secondaryImage',{}),width =640 ,height =360 ,preferred_ratio ='16:9')or thumb
            poster =_image_url (ic .get ('image',{}),width =213 ,height =320 ,preferred_ratio ='2:3')or thumb
            description =ic .get ('description','')or highlight

            if layout_type =='program':
                url =self .build_url ({'mode':'show_program','program_id':layout_id ,'seo':layout_seo })
                li =xbmcgui .ListItem (label =full_title )
                li .setProperty ('IsPlayable','false')
                art ={'thumb':thumb or poster ,'fanart':fanart }
                if poster :art ['poster']=poster
                li .setArt (art )
                li .setInfo ('video',{'title':full_title ,'plot':description ,'mediatype':'tvshow'})
                bookmark_url =self .build_url ({'mode':'toggle_bookmark','program_id':layout_id ,'title':urllib .parse .quote_plus (full_title ),'subscribed':'1'})
                unmark_url =self .build_url ({'mode':'toggle_bookmark','program_id':layout_id ,'title':urllib .parse .quote_plus (full_title ),'subscribed':'0'})
                li .addContextMenuItems ([('Merken',f'RunPlugin({bookmark_url })'),('Nicht mehr merken',f'RunPlugin({unmark_url })')])
                xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
                return True

            elif layout_type =='video':
                parent =vl .get ('parent',{})or {}
                parent_id =str (parent .get ('id',''))
                parent_seo =parent .get ('seo','')
                if parent_id :
                    url =self .build_url ({'mode':'show_program','program_id':parent_id ,'seo':parent_seo })
                    li =xbmcgui .ListItem (label =title_raw or full_title )
                    li .setProperty ('IsPlayable','false')
                    art ={'thumb':thumb or poster ,'fanart':fanart }
                    if poster :art ['poster']=poster
                    li .setArt (art )
                    li .setInfo ('video',{'title':title_raw or full_title ,'plot':description ,'mediatype':'tvshow'})
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
                    return True
                return self ._add_item (item )

            elif layout_type =='frontspace':
                _log (f'_add_item_as_folder: frontspace-Item uebersprungen id={layout_id }')
                return False

            else :
                return self ._add_item (item )

        except Exception as e :
            _log (f'_add_item_as_folder error: {e }')
            return False

    def _render_layout_with_headers (self ,data ):
        blocks =data .get ('blocks',[])
        total =0

        for block in blocks :
            content =block .get ('content',{})
            block_title_obj =content .get ('title')or {}
            if isinstance (block_title_obj ,dict ):
                block_title =block_title_obj .get ('short','')or block_title_obj .get ('long','')or ''
            else :
                block_title =str (block_title_obj )if block_title_obj else ''

            items =content .get ('items',[])
            if not items :
                continue

            if block_title :
                sep =xbmcgui .ListItem (label =f'[COLOR gold]── {block_title } ──[/COLOR]')
                sep .setProperty ('IsPlayable','false')
                sep .setInfo ('video',{'title':block_title })
                xbmcplugin .addDirectoryItem (self .handle ,'',sep ,False )

            for item in items :
                if self ._add_item (item ):
                    total +=1

        if total ==0 :
            li =xbmcgui .ListItem (label ='[Keine Inhalte]')
            xbmcplugin .addDirectoryItem (self .handle ,'',li ,False )

        xbmcplugin .setContent (self .handle ,'videos')
        xbmcplugin .endOfDirectory (self .handle )

    def _add_context_menu (self ,li ,params ,title ,thumb ):
        url =self .build_url (params )
        enc_url =urllib .parse .quote_plus (url )
        enc_title =urllib .parse .quote_plus (title )
        enc_thumb =urllib .parse .quote_plus (thumb or '')
        cmd =f'RunPlugin({self .base_url }?mode=add_bookmark&path={enc_url }&label={enc_title }&thumb={enc_thumb })'
        li .addContextMenuItems ([('Zu Weiterschauen hinzufuegen',cmd )])

    def show_service (self ,service ,label ='',page =1 ):
        _log (f'show_service service={service } page={page }')
        data =self .api .get_service (service ,page =page ,nb_pages =2 )
        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        self ._render_layout (data ,next_params ={
        'mode':'show_service',
        'service':service ,
        'label':urllib .parse .quote_plus (label or service ),
        })

    def show_alias (self ,alias ,page =1 ):
        _log (f'show_alias alias={alias } page={page }')
        data =self .api .get_alias (alias ,page =page )
        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        if alias =='home':
            blocks =data .get ('blocks',[])
            highlights_block =None
            other_blocks =[]
            for block in blocks :
                ct =block .get ('content',{})
                title_obj =ct .get ('title')or {}
                btitle =(title_obj .get ('short','')or title_obj .get ('long','')
                if isinstance (title_obj ,dict )else str (title_obj ))
                if 'highlight'in btitle .lower ()or 'neu'in btitle .lower ():
                    if highlights_block is None :
                        highlights_block =block
                    else :
                        other_blocks .append (block )
                else :
                    other_blocks .append (block )
            if highlights_block :
                data =dict (data )
                data ['blocks']=[highlights_block ]+other_blocks

        self ._render_layout (data ,next_params ={'mode':'show_alias','alias':alias })

    def show_folder (self ,folder_id ,seo ='',page =1 ):
        _log (f'show_folder id={folder_id } page={page }')
        data =self .api .get_folder (folder_id ,seo =seo ,page =page )
        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        blocks =data .get ('blocks',[])
        named_blocks =[]
        actionless_blocks =[]
        inline_blocks =[]
        for i ,block in enumerate (blocks ):
            content =block .get ('content',{})
            title_obj =content .get ('title')or {}
            if isinstance (title_obj ,dict ):
                btitle =title_obj .get ('short','')or title_obj .get ('long','')or ''
            else :
                btitle =str (title_obj )
            items =content .get ('items',[])
            if not items :
                continue
            has_action =any ((it .get ('itemContent',{})or {}).get ('action')for it in items )
            if not has_action :
                actionless_blocks .append ((i ,btitle ,items ))
            elif btitle and len (items )>1 :
                named_blocks .append ((i ,btitle ,items ))
            else :
                inline_blocks .append ((i ,btitle ,items ))

        if actionless_blocks or len (named_blocks )>=2 :
            _log (f'show_folder: {len (named_blocks )} named + {len (actionless_blocks )} actionless + {len (inline_blocks )} inline')
            for block_idx ,btitle ,items in inline_blocks :
                for item in items :
                    self ._add_item (item )
            for block_idx ,btitle ,items in actionless_blocks :
                for item in items :
                    ic =item .get ('itemContent',{})or {}
                    analytics =ic .get ('analytics',{})or {}
                    tealium =analytics .get ('tealiumImpression',{})or {}
                    folder_id_str =str (tealium .get ('item_id',''))
                    item_title =tealium .get ('item_title','')
                    img =ic .get ('image',{})or {}
                    caption =img .get ('caption','')
                    label =item_title or caption
                    if not label or not folder_id_str :
                        continue
                    thumb =_image_url (img ,width =320 ,height =180 ,preferred_ratio ='16:9')
                    url =self .build_url ({'mode':'show_folder','folder_id':folder_id_str })
                    li =xbmcgui .ListItem (label =label )
                    li .setProperty ('IsPlayable','false')
                    if thumb :
                        li .setArt ({'thumb':thumb ,'fanart':thumb })
                    li .setInfo ('video',{'title':label })
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
            for block_idx ,btitle ,items in named_blocks :
                cat_thumb =''
                for it in items [:3 ]:
                    ic =it .get ('itemContent',{})
                    cat_thumb =_image_url (ic .get ('image',{}),preferred_ratio ='16:9')
                    if cat_thumb :
                        break
                url =self .build_url ({
                'mode':'show_folder_block',
                'folder_id':folder_id ,
                'block_index':block_idx ,
                'seo':seo ,
                })
                clean_btitle =_clean_title (btitle )
                li =xbmcgui .ListItem (label =clean_btitle )
                li .setProperty ('IsPlayable','false')
                if cat_thumb :
                    li .setArt ({'thumb':cat_thumb ,'fanart':cat_thumb })
                li .setInfo ('video',{'title':clean_btitle ,'plot':clean_btitle })
                xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
            xbmcplugin .setContent (self .handle ,'videos')
            xbmcplugin .endOfDirectory (self .handle )
        else :
            self ._render_layout (data ,next_params ={'mode':'show_folder','folder_id':folder_id })

    def show_folder_block (self ,folder_id ,block_index ,seo ='',page =1 ):
        import math as _math
        _log (f'show_folder_block id={folder_id } block={block_index }')
        data =self .api .get_folder (folder_id ,seo =seo ,page =page )
        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        blocks =data .get ('blocks',[])
        if block_index >=len (blocks ):
            xbmcplugin .endOfDirectory (self .handle )
            return

        block =blocks [block_index ]
        block_id =block .get ('id','')
        content =block .get ('content',{})
        items =list (content .get ('items',[]))

        pagination =content .get ('pagination',{})or {}
        total_items =pagination .get ('totalItems',0 )
        ipp =pagination .get ('itemsPerPage',6 )or 6
        next_page =pagination .get ('nextPage')

        if block_id and next_page and total_items >len (items ):
            NB =3
            total_pages =_math .ceil (total_items /ipp )
            cur_page =next_page
            while cur_page <=total_pages :
                _log (f'show_folder_block: fetching block page {cur_page } of {total_pages }')
                page_data =self .api .get_block_page (folder_id ,block_id ,page =cur_page ,nb_pages =NB )
                if not page_data :
                    break
                page_items =page_data .get ('content',{}).get ('items',[])or []
                if not page_items :
                    break
                items .extend (page_items )
                _log (f'show_folder_block: got {len (page_items )} items, total now {len (items )}')
                cur_page +=NB

        total =0
        for item in items :
            if self ._add_item (item ):
                total +=1

        if total ==0 :
            li =xbmcgui .ListItem (label ='[Keine Inhalte]')
            xbmcplugin .addDirectoryItem (self .handle ,'',li ,False )

        xbmcplugin .setContent (self .handle ,'movies')
        xbmcplugin .endOfDirectory (self .handle )

    _SEASON_PATTERNS =('staffel','season','saison','serie ','teil ')
    _MOVIE_KEYWORDS =('film','spielfilm','kinofilm','movie','dokumentarfilm')
    _SERIES_KEYWORDS =('staffel','folge','season','episode','serie','show')

    def _is_movie_highlight (self ,highlight ,extra_details ='',details =''):
        hl =(highlight or '').lower ()
        ed =(extra_details or '').lower ()
        det =(details or '').lower ()
        combined =hl +' '+ed +' '+det
        has_movie_kw =any (k in combined for k in self ._MOVIE_KEYWORDS )
        has_series_kw =any (k in combined for k in self ._SERIES_KEYWORDS )
        import re as _re
        has_duration =bool (_re .search (r'\d+\s*min',combined ))
        return (has_movie_kw or has_duration )and not has_series_kw

    def play_program (self ,program_id ,seo ='',title ='Film'):
        data =self .api .get_program_layout (program_id ,seo =seo ,page =1 )
        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        blocks =data .get ('blocks',[])
        all_clips =[]
        for block in blocks :
            bc =block .get ('content',{})
            btitle_obj =bc .get ('title')or {}
            btitle =(btitle_obj .get ('short','')or btitle_obj .get ('long','')
            if isinstance (btitle_obj ,dict )else str (btitle_obj ))
            if 'empfehlung'in btitle .lower ()or 'recommendation'in btitle .lower ():
                continue
            for item in bc .get ('items',[]):
                ic =item .get ('itemContent',{})
                action =ic .get ('action',{})or {}
                target =action .get ('target',{})or {}
                if target .get ('type')=='lock':
                    target =(target .get ('value_lock',{})or {}).get ('originalTarget',{})or {}
                vl =target .get ('value_layout',{})or {}
                if target .get ('type')=='layout'and vl .get ('type')=='video':
                    all_clips .append ((vl .get ('id',''),vl .get ('seo',''),ic ))

        unique_ids =list (dict .fromkeys (cid for cid ,_ ,_ in all_clips if cid ))
        if not unique_ids :

            self .show_program (program_id ,seo =seo )
            return

        clip_id =unique_ids [0 ]
        ic =next ((ic for cid ,_ ,ic in all_clips if cid ==clip_id ),all_clips [0 ][2 ])
        vl_seo =next ((s for cid ,s ,_ in all_clips if cid ==clip_id ),'')

        resolved_title =(ic .get ('title')or ic .get ('extraTitle')or title )
        thumb =_image_url (ic .get ('image',{}),width =320 ,height =180 ,preferred_ratio ='16:9')
        fanart =_image_url (ic .get ('secondaryImage',{}),width =640 ,height =360 ,preferred_ratio ='16:9')or thumb
        poster =_image_url (ic .get ('image',{}),width =213 ,height =320 ,preferred_ratio ='2:3')or thumb

        play_url =self .build_url ({
        'mode':'play_vod',
        'video_id':clip_id ,
        'title':urllib .parse .quote_plus (resolved_title ),
        'video_seo':vl_seo ,
        'program_id':program_id ,
        })
        li =xbmcgui .ListItem (label =(resolved_title) + (f" [{_quality_label()}]" if _quality_label() else ""),path =play_url )
        li .setProperty ('IsPlayable','true')
        if thumb :
            li .setArt ({'thumb':thumb ,'poster':poster ,'fanart':fanart })
        li .setInfo ('video',{
        'title':resolved_title ,
        'plot':ic .get ('description','')or '',
        'mediatype':'movie',
        })
        xbmcplugin .setResolvedUrl (self .handle ,True ,li )

    def _is_season_block (self ,btitle ):
        bl =btitle .lower ().strip ()
        return any (bl .startswith (p )for p in self ._SEASON_PATTERNS )or (
        bl .startswith ('s')and len (bl )<=4 and bl [1 :].isdigit ()
        )or 'spieltag'in bl

    def show_program (self ,program_id ,seo ='',page =1 ):
        _log (f'show_program id={program_id } page={page }')
        if str (program_id )=='bookmarks':
            _log ('show_program: bookmarks-ID → show_meine_inhalte')
            return self .show_meine_inhalte ()
        data =self .api .get_program_layout (program_id ,seo =seo ,page =page )
        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        blocks =data .get ('blocks',[])
        import re as _re

        direct_seasons =[]
        concurrent_seasons =[]

        for block in blocks :
            bc =block .get ('content',{})
            btitle_obj =bc .get ('title')or {}
            btitle =(btitle_obj .get ('short','')or btitle_obj .get ('long','')
            if isinstance (btitle_obj ,dict )else str (btitle_obj or ''))
            block_id =block .get ('id','')

            if btitle and block_id and self ._is_season_block (btitle ):
                btitle =_clean_title (btitle )
                block_items =bc .get ('items',[])or []
                direct_seasons .append ((btitle ,block_id ,block_items ))

            alt =block .get ('alternativeContent')
            if not alt or not isinstance (alt ,dict ):
                continue
            concurrent =alt .get ('concurrentBlocks')
            if not concurrent or not isinstance (concurrent ,list ):
                continue
            for cb in concurrent :
                if not cb or not isinstance (cb ,dict ):
                    continue
                cb_title =cb .get ('title','')
                cb_id =cb .get ('id','')
                if cb_title and cb_id :
                    cb_title =_clean_title (cb_title )
                    cb_items =cb .get ('content',{}).get ('items',[])or []
                    concurrent_seasons .append ((cb_title ,cb_id ,cb_items ))

        all_seasons =direct_seasons +concurrent_seasons

        if len (all_seasons )>=1 :
            _log (f'show_program {program_id }: {len (direct_seasons )} direkte + {len (concurrent_seasons )} concurrentBlocks-Staffeln')

            def _season_sort_key (entry ):
                m =_re .search (r'\d+',entry [0 ])
                return int (m .group ())if m else 0

            all_seasons .sort (key =_season_sort_key ,reverse =True )

            seen_ids =set ()
            for idx ,(s_title ,s_block_id ,s_items )in enumerate (all_seasons ):
                if s_block_id in seen_ids :
                    continue
                seen_ids .add (s_block_id )
                m =_re .search (r'\d+',s_title )
                s_num =int (m .group ())if m else (idx +1 )
                cat_thumb =''
                for it in s_items [:3 ]:
                    ic2 =it .get ('itemContent',{})
                    cat_thumb =_image_url (ic2 .get ('image',{}),preferred_ratio ='16:9')
                    if cat_thumb :
                        break
                url =self .build_url ({
                'mode':'show_season',
                'program_id':program_id ,
                'season_title':urllib .parse .quote_plus (s_title ),
                'block_index':idx ,
                'season_block_id':s_block_id ,
                'seo':seo ,
                })
                li =xbmcgui .ListItem (label =s_title )
                li .setProperty ('IsPlayable','false')
                if cat_thumb :
                    li .setArt ({'thumb':cat_thumb ,'fanart':cat_thumb })
                li .setInfo ('video',{'title':s_title ,'season':s_num ,'mediatype':'season'})
                xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
            xbmcplugin .setContent (self .handle ,'tvshows')
            xbmcplugin .endOfDirectory (self .handle )
            return

        content_blocks =[]
        for block in blocks :
            bc =block .get ('content',{})
            btitle_obj =bc .get ('title')or {}
            btitle =(btitle_obj .get ('short','')or btitle_obj .get ('long','')
            if isinstance (btitle_obj ,dict )else str (btitle_obj ))
            if 'empfehlung'in btitle .lower ()or 'recommendation'in btitle .lower ():
                continue
            items =bc .get ('items',[])
            if items :
                content_blocks .append ((btitle ,items ))

        all_clips =[]
        for btitle ,items in content_blocks :
            for item in items :
                ic =item .get ('itemContent',{})
                action =ic .get ('action',{})or {}
                target =action .get ('target',{})or {}
                if target .get ('type')=='lock':
                    target =(target .get ('value_lock',{})or {}).get ('originalTarget',{})or {}
                vl =target .get ('value_layout',{})or {}
                if target .get ('type')=='layout'and vl .get ('type')=='video':
                    all_clips .append ((vl .get ('id',''),ic ))

        unique_clip_ids =list (dict .fromkeys (cid for cid ,_ in all_clips if cid ))
        if len (all_clips )>=1 and len (unique_clip_ids )==1 :
            clip_id ,ic =all_clips [0 ]
            action =ic .get ('action',{})or {}
            vl =(action .get ('target',{})or {}).get ('value_layout',{})or {}
            seo =vl .get ('seo','')
            seo_title =seo .replace ('-',' ').title ()if seo else ''
            title =(ic .get ('title')or ic .get ('extraTitle')or seo_title or
            ic .get ('highlight','').split ('•')[-1 ].strip ()or clip_id )
            play_url =self .build_url ({
            'mode':'play_vod',
            'video_id':clip_id ,
            'title':urllib .parse .quote_plus (title ),
            })
            li =xbmcgui .ListItem (label =(title) + (f" [{_quality_label()}]" if _quality_label() else ""),path =play_url )
            li .setProperty ('IsPlayable','true')
            thumb =_image_url (ic .get ('image',{}),width =320 ,height =180 ,preferred_ratio ='16:9')
            fanart =_image_url (ic .get ('secondaryImage',{}),width =640 ,height =360 ,preferred_ratio ='16:9')or thumb
            poster =_image_url (ic .get ('image',{}),width =213 ,height =320 ,preferred_ratio ='2:3')or thumb
            if thumb :
                li .setArt ({'thumb':thumb ,'poster':poster ,'fanart':fanart })
            li .setInfo ('video',{
            'title':title ,
            'plot':ic .get ('description','')or '',
            'mediatype':'movie',
            })
            xbmcplugin .addDirectoryItem (self .handle ,play_url ,li ,False )
            xbmcplugin .setContent (self .handle ,'movies')
            xbmcplugin .endOfDirectory (self .handle )
            return

        season_blocks =[(bt ,it )for bt ,it in content_blocks if self ._is_season_block (bt )]

        if len (season_blocks )>=2 :
            _log (f'show_program {program_id }: {len (season_blocks )} Staffeln (Titel-Erkennung)')
            for block_idx ,(btitle ,items )in enumerate (season_blocks ):
                m =_re .search (r'\d+',btitle )
                s_num =int (m .group ())if m else (block_idx +1 )
                cat_thumb =''
                for it in items [:3 ]:
                    ic2 =it .get ('itemContent',{})
                    cat_thumb =_image_url (ic2 .get ('image',{}),preferred_ratio ='16:9')
                    if cat_thumb :
                        break
                url =self .build_url ({
                'mode':'show_season',
                'program_id':program_id ,
                'season_title':urllib .parse .quote_plus (btitle ),
                'block_index':block_idx ,
                })
                li =xbmcgui .ListItem (label =btitle )
                li .setProperty ('IsPlayable','false')
                if cat_thumb :
                    li .setArt ({'thumb':cat_thumb ,'fanart':cat_thumb })
                li .setInfo ('video',{'title':btitle ,'season':s_num ,'mediatype':'season'})
                xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
            xbmcplugin .setContent (self .handle ,'tvshows')
            xbmcplugin .endOfDirectory (self .handle )
            return

        episode_items =[]
        for btitle ,items in content_blocks :
            for item in items :
                ic =item .get ('itemContent',{})
                episode_items .append ((_ep_sort_key (ic ),item ))

        episode_items .sort (key =lambda x :x [0 ])

        total =0
        for _ ,item in episode_items :
            if self ._add_item (item ):
                total +=1

        if total ==0 :
            xbmcgui .Dialog ().notification ('RTL+','Keine Episoden vorhanden',xbmcgui .NOTIFICATION_INFO ,3000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        xbmcplugin .setContent (self .handle ,'episodes')
        xbmcplugin .endOfDirectory (self .handle )

    def _fetch_all_block_items (self ,program_id ,season_block_id ,seo =''):
        import math as _math
        NB =3
        all_items =[]

        first =self .api .get_program_block (program_id ,season_block_id ,page =1 ,nb_pages =NB ,seo =seo )
        if not first :
            return all_items

        def _extract (block_data ):
            c =block_data .get ('content',{})
            it =c .get ('items',[])or []
            if not it :
                for b in block_data .get ('blocks',[]):
                    bi =b .get ('content',{}).get ('items',[])or []
                    it .extend (bi )
            if not it :
                it =block_data .get ('items',[])or []
            fixed =[]
            for item in it :
                if 'itemContent' not in item and ('title' in item or 'action' in item or 'video' in item ):
                    fixed .append ({'itemContent':item })
                else :
                    fixed .append (item )
            return c ,fixed

        first_content ,first_items =_extract (first )
        all_items .extend (first_items )

        pagination =first_content .get ('pagination')or {}
        total_items =pagination .get ('totalItems',0 )
        ipp =pagination .get ('itemsPerPage',6 )or 6
        if not total_items :
            _log (f'_fetch_all_block_items: kein totalItems, nur erste {len (all_items )} items')
            return all_items

        total_pages =_math .ceil (total_items /ipp )
        _log (f'_fetch_all_block_items: totalItems={total_items } ipp={ipp } totalPages={total_pages }')

        page =1 +NB
        while page <=total_pages :
            block_data =self .api .get_program_block (program_id ,season_block_id ,page =page ,nb_pages =NB ,seo =seo )
            if not block_data :
                break
            _ ,page_items =_extract (block_data )
            all_items .extend (page_items )
            _log (f'_fetch_all_block_items page={page } got={len (page_items )} total={len (all_items )}')
            page +=NB

        return all_items

    def show_season (self ,program_id ,block_index ,season_title ='',season_block_id ='',seo =''):
        _log (f'show_season id={program_id } block={block_index } block_id={season_block_id }')
        items =[]

        if season_block_id and program_id :
            _log (f'show_season: fetching all pages via /program/{program_id }/block/{season_block_id }')
            items =self ._fetch_all_block_items (program_id ,season_block_id ,seo =seo )
            _log (f'show_season block API total: {len (items )} items')

        if not items :
            data =self .api .get_program_layout (program_id ,page =1 ,nb_pages =5 )
            if not data :
                xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
                xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
                return

            blocks =data .get ('blocks',[])
            season_blocks =[]
            for block in blocks :
                bc =block .get ('content',{})
                btitle_obj =bc .get ('title')or {}
                btitle =(btitle_obj .get ('short','')or btitle_obj .get ('long','')
                if isinstance (btitle_obj ,dict )else str (btitle_obj ))
                if 'empfehlung'in btitle .lower ()or 'recommendation'in btitle .lower ():
                    continue
                block_items =bc .get ('items',[])
                if block_items and self ._is_season_block (btitle ):
                    season_blocks .append ((btitle ,block_items ))
            if block_index <len (season_blocks ):
                _ ,items =season_blocks [block_index ]

        episode_items =[]
        for item in items :
            ic =item .get ('itemContent',{})
            episode_items .append ((_ep_sort_key (ic ),item ))

        episode_items .sort (key =lambda x :x [0 ])

        total =0
        for _ ,item in episode_items :
            if self ._add_item (item ):
                total +=1

        if total ==0 :
            xbmcgui .Dialog ().notification ('RTL+','Keine Episoden vorhanden',xbmcgui .NOTIFICATION_INFO ,3000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        xbmcplugin .setContent (self .handle ,'episodes')
        xbmcplugin .endOfDirectory (self .handle )

    def _epg_current_program (self ,epgbox ):
        import time as _time
        from datetime import datetime as _dt
        import re as _re
        now_ts = _time.time ()
        current = None
        next_ep = None

        def _parse_ts (date_str ):
            try :
                s = _re.sub (r'([+-]\d{2}):(\d{2})$',lambda m :f'{m.group(1)}{m.group(2)}',date_str )
                return _dt.strptime (s ,'%Y-%m-%dT%H:%M:%S%z').timestamp ()
            except Exception :
                return None

        for ep in epgbox :
            pb = ep.get ('progressBar')
            if pb is not None :
                start_ts = _parse_ts (ep.get ('start',{}).get ('date',''))
                end_ts = _parse_ts (ep.get ('end',{}).get ('date',''))
                if start_ts is not None and end_ts is not None :
                    if start_ts <= now_ts <= end_ts :
                        current = ep
                        break

                else :

                    current = ep
                    break

        if current is None :
            for ep in epgbox :
                start_ts = _parse_ts (ep.get ('start',{}).get ('date',''))
                end_ts = _parse_ts (ep.get ('end',{}).get ('date',''))
                if start_ts is None or end_ts is None :
                    continue
                if start_ts <= now_ts <= end_ts :
                    current = ep
                    break

        for ep in epgbox:
            if current and ep is current:
                continue
            try:
                from datetime import datetime as _dt
                import re as _re
                start_str = ep.get ('start',{}).get ('date','')
                if not start_str:
                    continue
                start_str_utc = _re.sub (r'([+-]\d{2}):(\d{2})$',lambda m:f'{m.group(1)}{m.group(2)}',start_str)
                start_ts = _dt.strptime (start_str_utc,'%Y-%m-%dT%H:%M:%S%z').timestamp ()
                if start_ts > now_ts:
                    next_ep = ep
                    break
            except Exception:
                continue
        return current,next_ep

    def _add_fast_channels (self ):
        import os as _os ,xbmcaddon as _xad ,xbmcvfs as _xvfs
        _profile =_xvfs .translatePath (_xad .Addon ().getAddonInfo ('profile'))
        if not _os .path .exists (_os .path .join (_profile ,'tokens.json')):
            _log ('_add_fast_channels: nicht eingeloggt – FAST-Kanäle werden nicht angezeigt')
            return 0
        _log ('_add_fast_channels: lade FAST-Kanäle aus folder/193')

        def _fetch_data ():
            return self .api .get_folder_guest ('193')

        def _render (data ):
            count =0
            for block in data .get ('blocks',[]):
                for item in block .get ('content',{}).get ('items',[]):
                    ic =item .get ('itemContent',{})
                    action =(ic .get ('action')or {})
                    target =(action .get ('target')or {})
                    t_type =target .get ('type','')
                    if t_type !='layout':
                        continue
                    vl =(target .get ('value_layout')or {})
                    if vl .get ('type','')!='live':
                        continue
                    vl_id =str (vl .get ('id',''))
                    if not vl_id or not vl_id .startswith ('rtlde_fast'):
                        continue
                    channel_slug =vl_id .replace ('rtlde_','')
                    title =ic .get ('title','')or channel_slug .upper ()
                    live_label =f'[COLOR gold][B]LIVE - {title }[/B][/COLOR]'
                    url =self .build_url ({
                        'mode':'play_live',
                        'channel_id':channel_slug ,
                        'title':urllib .parse .quote_plus (title ),
                    })
                    li =xbmcgui .ListItem (label =live_label )
                    li .setProperty ('IsPlayable','true')
                    local_img =self ._channel_image (channel_slug )
                    thumb =''
                    img_data =ic .get ('image')
                    if img_data and isinstance (img_data ,dict ):
                        thumb =_image_url (img_data ,width =320 ,height =180 ,preferred_ratio ='16:9')
                    art_img =local_img or thumb
                    if art_img :
                        li .setArt ({'thumb':art_img ,'icon':art_img ,'clearlogo':art_img ,'fanart':art_img })
                    li .setInfo ('video',{'title':'\u0001'+live_label ,'plot':ic .get ('description','')or ''})
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,False )
                    count +=1
            return count

        try :
            data =_fetch_data ()
            if not data :
                _log ('_add_fast_channels: kein Ergebnis – erneuere Tokens und versuche erneut')
                self .api .auth ._guest_tokens .pop ('guest_bedrock_token',None )
                self .api .auth ._guest_tokens .pop ('guest_bedrock_expires',None )
                self .api .auth ._save_guest_tokens ()
                self .api .auth .get_guest_bedrock_token ()
                data =_fetch_data ()
            if not data :
                _log ('_add_fast_channels: auch nach Token-Erneuerung kein Ergebnis')
                return 0
            count =_render (data )
            _log (f'_add_fast_channels: {count } FAST-Kanäle hinzugefuegt')
            return count
        except Exception as e :
            _log (f'_add_fast_channels error: {e }')
            return 0

    def show_live_channels (self ):
        _log ('show_live_channels')

        import time as _time
        data = self.api.get_epg_grid ()
        if not data:
            xbmcgui.Dialog ().notification ('RTL+','Fehler beim Laden der Senderliste',xbmcgui.NOTIFICATION_ERROR,4000)
            xbmcplugin.endOfDirectory (self.handle,succeeded=False)
            return

        items = data.get ('content',{}).get ('items',[])
        if not items:
            for b in data.get ('blocks',[]):
                items += b.get ('content',{}).get ('items',[])

        _log (f'show_live_channels: {len (items)} EPG items via get_epg_grid')

        count = 0
        for item in items:
            li = self._create_live_listitem_epg (item)
            if li:
                count += 1

        fast_count = self._add_fast_channels ()
        count += fast_count

        xbmcplugin.setContent (self.handle,'videos')
        if count == 0:
            _log ('show_live_channels: Keine Kanäle')
            li = xbmcgui.ListItem (label='[COLOR yellow]Bitte erneut öffnen (Anmeldung wird erneuert...)[/COLOR]')
            xbmcplugin.addDirectoryItem (self.handle,'',li,False)
            xbmcplugin.endOfDirectory (self.handle,succeeded=True)
        else:
            xbmcplugin.endOfDirectory (self.handle,succeeded=True)

    def show_epg (self ):
        _log ('show_epg')
        data = self.api.get_epg_grid ()
        if not data:
            xbmcgui.Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui.NOTIFICATION_ERROR,4000)
            xbmcplugin.endOfDirectory (self.handle,succeeded=False)
            return
        items = data.get ('content',{}).get ('items',[])
        if not items:
            for b in data.get ('blocks',[]):
                items += b.get ('content',{}).get ('items',[])

        added = 0
        for item in items:
            li = self._create_live_listitem_epg (item)
            if li:
                added += 1

        xbmcplugin.setContent (self.handle,'videos')
        xbmcplugin.endOfDirectory (self.handle)

    _MIDDLEWARE_BASE ='https://pc.middleware.rtlde.bedrock.tech/6play/v2/platforms/m6group_web/services/rtlplus_root'

    def _middleware_headers (self ):
        from .auth import USER_AGENT ,CLIENT_RELEASE
        return {
        'User-Agent':USER_AGENT ,
        'x-client-release':CLIENT_RELEASE ,
        'x-customer-name':'rtlde',
        'Referer':'https://plus.rtl.de/',
        'Origin':'https://plus.rtl.de',
        }

    def _middleware_image_url (self ,images ,role ='landscape',width =320 ,height =180 ):
        if not images :
            return ''
        role_prio =[role ,'landscape','vignette','banner','square']
        img_id =''
        for r in role_prio :
            for img in images :
                if img .get ('role')==r :
                    img_id =str (img .get ('external_key','')or img .get ('id',''))
                    if img_id :
                        break
            if img_id :
                break
        if not img_id :
            img_id =str (images [0 ].get ('external_key','')or images [0 ].get ('id',''))
        if not img_id :
            return ''
        params =f'auto=avif&blur=0&fit=max&height={height }&interlace=1&quality=100&width={width }'
        path_and_query =f'/v2/images/{img_id }/raw?{params }'
        sig =_sign_image (path_and_query )
        headers_enc =urllib .parse .urlencode ({
        'Referer':'https://plus.rtl.de/',
        'User-Agent':'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36',
        })
        return f'{IMAGE_CDN }{path_and_query }&hash={sig }|{headers_enc }'

    def show_jw_az (self ,obj_type ='SHOW',page =1 ):
        import requests ,uuid ,os ,json ,time as _time
        import xbmcaddon ,xbmcvfs
        _log (f'show_jw_az type={obj_type } page={page }')

        JW_GQL ='https://apis.justwatch.com/graphql'
        _page_label ='Serien'if obj_type =='SHOW'else 'Filme'
        _page_path ='/de/Anbieter/rtl-plus/{}?sort_by=title&sort_asc=true&page={}'.format (_page_label ,page )

        _profile =xbmcvfs .translatePath (xbmcaddon .Addon ().getAddonInfo ('profile'))
        _jw_id_file =os .path .join (_profile ,'jw_device_id.json')
        _jw_id =''
        try :
            if os .path .exists (_jw_id_file ):
                with open (_jw_id_file ,'r')as _f :
                    _jw_id =json .load (_f ).get ('id','')
        except Exception :
            pass
        if not _jw_id :
            import base64 ,struct
            raw =uuid .uuid4 ().bytes +uuid .uuid4 ().bytes [:8]
            _jw_id =base64 .b64encode (raw ).decode ().rstrip ('=').replace ('+','').replace ('/','')[:22]
            try :
                os .makedirs (_profile ,exist_ok =True )
                with open (_jw_id_file ,'w')as _f :
                    json .dump ({'id':_jw_id },_f )
            except Exception :
                pass
        _pv_id =str (uuid .uuid4 ())

        JW_HEADERS ={
            'Content-Type':'application/json',
            'Accept':'*/*',
            'Origin':'https://www.justwatch.com',
            'Referer':'https://www.justwatch.com/',
            'app-version':'3.13.0-web-web',
            'device-id':_jw_id ,
            'sg':f'c=DE&l=de&pv={_pv_id }&d={_jw_id }&p=3.13.0-web-web&pa={_page_path }&e=',
            'User-Agent':'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36',
            'accept-language':'de-DE,de;q=0.9,en-US;q=0.7,en;q=0.6',
        }
        PER_PAGE =40
        offset =(page -1 )*PER_PAGE

        QUERY ="""query GetPopularTitles($country: Country!, $first: Int! = 70, $format: ImageFormat, $language: Language!, $after: String, $popularTitlesFilter: TitleFilter, $popularTitlesSortBy: PopularTitlesSorting! = POPULAR, $profile: PosterProfile, $sortRandomSeed: Int! = 0, $watchNowFilter: WatchNowOfferFilter!, $offset: Int = 0) {

}"""
