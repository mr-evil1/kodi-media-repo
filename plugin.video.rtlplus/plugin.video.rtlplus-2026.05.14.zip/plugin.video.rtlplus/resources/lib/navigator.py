import os 
import urllib .parse 
import hashlib 
import xbmc 
import xbmcgui 
import xbmcplugin 
import xbmcaddon 
import xbmcvfs 

from .api import BedrockAPI 

IMAGE_CDN ='https://images-fio.rtlde.bedrock.tech'

_IMAGE_KEY ='x9vGg4RNeNBqV2nBfhqLV6cN4n'

def _sign_image (path_and_query :str )->str :
    return hashlib .sha1 ((path_and_query +_IMAGE_KEY ).encode ()).hexdigest ()

CHANNEL_IMAGES ={
'rtl':'channel/rtl.png',
'vox':'channel/vox.png',
'rtlzwei':'channel/rtl2.png',
'rtl2':'channel/rtl2.png',
'nitro':'channel/nitro.png',
'ntv':'channel/ntv.png',
'rtlup':'channel/rtlup.png',
'rtlplus':'channel/rtlplus.png',
'voxup':'channel/voxup.png',
'super_rtl':'channel/superrtl.png',
'superrtl':'channel/superrtl.png',
'toggo_plus':'channel/toggoplus.png',
'toggoplus':'channel/toggoplus.png',
'now':'channel/tvnow.png',
'tvnow':'channel/tvnow.png',
'tvnowkids':'channel/tvnowkids.png',
'geo':'channel/geo.png',
'crime':'channel/crime.png',
'living':'channel/living.png',
'passion':'channel/passion.png',
'nowus':'channel/nowus.png',
'watchbox':'channel/watchbox.png',
}

def _log (msg ):
    xbmc .log (f'[RTL+ Nav] {msg }',xbmc .LOGDEBUG )

_PREMIUM_STATUS_CACHE = {}

def _get_premium_status ():
    import time as _time
    cached = _PREMIUM_STATUS_CACHE.get('result')
    cached_ts = _PREMIUM_STATUS_CACHE.get('ts', 0)
    if cached is not None and (_time.time() - cached_ts) < 21600:
        return cached
    try:
        from .auth import RTLAuth
        result = 'Premium' if RTLAuth().is_premium() else 'Free'
    except Exception:
        result = 'Free'
    _PREMIUM_STATUS_CACHE['result'] = result
    _PREMIUM_STATUS_CACHE['ts'] = _time.time()
    return result

def _premium_title (title ):
    return f'[COLOR gold]{title} (Premium)[/COLOR]'

def _ep_sort_key (ic ):
    import re as _re 
    hl =ic .get ('highlight','')or ''
    s ,e ,date_str =0 ,0 ,''
    for part in hl .split ('•'):
        pl =part .strip ().lower ()
        if pl .startswith ('staffel'):
            m =_re .search (r'\d+',pl )
            if m :
                try :s =int (m .group ())
                except :pass 
        elif pl .startswith ('folge'):
            m =_re .search (r'\d+',pl )
            if m :
                try :e =int (m .group ())
                except :pass 
        else :
            dm =_re .search (r'(\d{2})\.(\d{2})\.(\d{4})',part )
            if dm and not date_str :
                date_str =f'{dm .group (3 )}-{dm .group (2 )}-{dm .group (1 )}'
    return (s ,e ,date_str )

def _image_url (image_data ,width =480 ,height =270 ,preferred_ratio ='16:9'):
    if not image_data :
        return ''
    if isinstance (image_data ,str ):
        img_id =image_data 
    elif isinstance (image_data ,dict ):
        ids_by_ratio =image_data .get ('idsByRatio',{})or {}
        img_id =(ids_by_ratio .get (preferred_ratio ,'')
        or ids_by_ratio .get ('16:9','')
        or ids_by_ratio .get ('2:3','')
        or next (iter (ids_by_ratio .values ()),'')
        or image_data .get ('id',''))
    else :
        return ''
    if not img_id :
        return ''

    params =(f'auto=avif&blur=0&fit=scale_crop'
    f'&height={height }&interlace=1&quality=100&width={width }')
    path_and_query =f'/v2/images/{img_id }/raw?{params }'
    sig =_sign_image (path_and_query )

    headers =urllib .parse .urlencode ({
    'Referer':'https://plus.rtl.de/',
    'User-Agent':'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
    })
    return f'{IMAGE_CDN }{path_and_query }&hash={sig }|{headers }'

class Navigator :
    def __init__ (self ,handle ,base_url ):
        self .handle =handle 
        self .base_url =base_url 
        self .api =BedrockAPI ()

    def build_url (self ,params ):
        return self .base_url +'?'+urllib .parse .urlencode (params )

    def show_main_menu (self ):
        import os 
        import xbmcaddon 
        import xbmcvfs 
        _addon =xbmcaddon .Addon ()
        _addon_path =xbmcvfs .translatePath (_addon .getAddonInfo ('path'))
        _profile =xbmcvfs .translatePath (_addon .getAddonInfo ('profile'))
        _token_file =os .path .join (_profile ,'tokens.json')
        _logged_in =os .path .exists (_token_file )and _addon .getSetting ('username')!=''

        def _img (fname ):
            return os .path .join (_addon_path ,'resources','media',fname )

        if _logged_in :

            reality_id ='1'
            kids_id ='148'
            anime_id ='165'
            try :
                nav_data =self .api .get_navigation ()
                if nav_data :
                    def _find_folder (obj ,keywords ):
                        if isinstance (obj ,dict ):
                            label =str (obj .get ('label','')or obj .get ('title','')or '').lower ()
                            vl =obj .get ('value_layout',{})or {}
                            if any (k in label for k in keywords )and vl .get ('type')=='folder':
                                return str (vl .get ('id',''))
                            for v in obj .values ():
                                r =_find_folder (v ,keywords )
                                if r :return r 
                        elif isinstance (obj ,list ):
                            for v in obj :
                                r =_find_folder (v ,keywords )
                                if r :return r 
                        return ''
                    reality_id =_find_folder (nav_data ,['reality','dating','show'])or reality_id 
                    anime_id =_find_folder (nav_data ,['anime'])or anime_id 
                    kids_id =_find_folder (nav_data ,['kids','kinder','toggo'])or kids_id 
            except Exception :
                pass 

            _account_type = _get_premium_status()
            _mein_label = f'Mein {_account_type} RTL+'

            items =[

            (_mein_label,{'mode':'show_meine_inhalte'},_img ('favourites.png')),

            ('Startseite',{'mode':'show_alias','alias':'home'},_img ('icon.png')),
            ('Live-TV',{'mode':'show_live'},_img ('icon.png')),
            ('Filme',{'mode':'show_folder','folder_id':'4'},_img ('icon.png')),
            ('Serien',{'mode':'show_folder','folder_id':'3'},_img ('icon.png')),
            ('Shows',{'mode':'show_folder','folder_id':'2','seo':'shows-rtl'},_img ('icon.png')),
            ('Reality',{'mode':'show_folder','folder_id':reality_id },_img ('icon.png')),
            ('Anime',{'mode':'show_folder','folder_id':anime_id },_img ('icon.png')),
            ('Sport',{'mode':'show_folder','folder_id':'6'},_img ('icon.png')),
            ('Kids',{'mode':'show_folder','folder_id':kids_id },_img ('icon.png')),

            ('Podcasts',{'mode':'show_service','service':'podcast',
            'label':urllib .parse .quote_plus ('Podcasts')},_img ('icon.png')),
            ('Hörbücher',{'mode':'show_service','service':'hoerbuecher',
            'label':urllib .parse .quote_plus ('Hörbücher')},_img ('icon.png')),
            ('Radio',{'mode':'show_service','service':'live-radios',
            'label':urllib .parse .quote_plus ('Radio')},_img ('icon.png')),
            ]

            items.append(('[COLOR gold]Gast Inhalte[/COLOR]',{'mode':'show_guest_free'},_img ('icon.png')))

            if _addon.getSetting('show_az_menu') == 'true':
                items.append(('A-Z',{'mode':'show_az'},_img ('basesearch.png')if os .path .exists (_img ('basesearch.png'))else _img ('icon.png')))

            items.extend([
            ('Suche',{'mode':'search'},_img ('basesearch.png')if os .path .exists (_img ('basesearch.png'))else _img ('icon.png')),

            ('Einstellungen',{'mode':'settings'},_img ('settings.png')),
            ('Addon Reset',{'mode':'reset'},_img ('remove.png')),
            ('Logout',{'mode':'logout'},_img ('remove.png')),
            ])
        else :
            try :
                from resources .lib .auth import RTLAuth as _RTLAuth
                _RTLAuth ().guest_login ()
            except Exception :
                pass
            items =[
            ('Anmelden',{'mode':'login'},_img ('icon.png')),
            ('[COLOR gold]Gast Inhalte[/COLOR]',{'mode':'show_guest_free'},_img ('icon.png')),
            ('Addon Reset',{'mode':'reset'},_img ('remove.png')),
            ]

        for label ,params ,thumb in items :
            li =xbmcgui .ListItem (label =label )
            li .setProperty ('IsPlayable','false')
            if os .path .exists (thumb ):
                li .setArt ({'thumb':thumb ,'icon':thumb })
            li .setInfo ('video',{'title':label })
            xbmcplugin .addDirectoryItem (
            handle =self .handle ,
            url =self .build_url (params ),
            listitem =li ,
            isFolder =params .get ('mode')not in ('settings','logout','login','reset')
            )
        xbmcplugin .endOfDirectory (self .handle )

    def show_guest_free (self ):
        import os ,hashlib
        import xbmcaddon ,xbmcvfs
        _addon =xbmcaddon .Addon ()
        _addon_path =xbmcvfs .translatePath (_addon .getAddonInfo ('path'))

        _log ('show_guest_free: lade Gast-Inhalte')
        data =self .api .get_folder_guest ('193')
        if not data :
            xbmcgui .Dialog ().notification (
                'RTL+','Gast Inhalte nicht ladbar.',
                xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        _IMAGE_KEY ='x9vGg4RNeNBqV2nBfhqLV6cN4n'
        def _thumb (img ):
            if not img or not isinstance (img ,dict ):return ''
            ids =img .get ('idsByRatio',{})or {}
            img_id =(ids .get ('16:9','')or ids .get ('2:3','')
                     or next (iter (ids .values ()),''))
            if not img_id :return ''
            pq =f'/v2/images/{img_id }/raw?auto=webp&blur=0&fit=max&width=480&height=270&interlace=1&quality=65'
            sig =hashlib .sha1 ((pq +_IMAGE_KEY ).encode ()).hexdigest ()
            return f'https://images-fio.rtlde.bedrock.tech{pq }&hash={sig }'

        xbmcplugin .setContent (self .handle ,'videos')

        live_entries =[]
        other_entries =[]

        for block in data .get ('blocks',[]):
            bc =block .get ('content',{})
            bt =bc .get ('title',{})
            bt =(bt .get ('short','')or bt .get ('long',''))if isinstance (bt ,dict )else str (bt or '')
            for it in bc .get ('items',[]):
                ic =it .get ('itemContent',{})
                _title_raw =ic .get ('title','')or ''
                _extra_title =ic .get ('extraTitle','')or ''
                _action_tmp =(ic .get ('action')or {})
                _target_tmp =(_action_tmp .get ('target')or {})
                _vl_tmp =(_target_tmp .get ('value_layout')or {})
                _seo_tmp =str (_vl_tmp .get ('seo',''))
                _highlight =ic .get ('highlight','')or ''
                _seo_title =_seo_tmp .replace ('-',' ').title ()if _seo_tmp else ''
                if _title_raw and _extra_title :
                    title =f'{_title_raw } - {_extra_title }'
                elif _title_raw :
                    title =_title_raw
                elif _extra_title :
                    title =_extra_title
                elif _seo_title :
                    title =_seo_title
                elif _highlight :
                    title =_highlight .split ('•')[0 ].strip ()
                else :
                    title ='Unbekannt'
                action =(ic .get ('action')or {})
                target =(action .get ('target')or {})
                t_type =target .get ('type','')
                vl =(target .get ('value_layout')or {})
                vl_type =vl .get ('type','')
                vl_id =str (vl .get ('id',''))
                vl_seo =str (vl .get ('seo',''))
                vp =(target .get ('value_player')or {})
                vp_id =str (vp .get ('id',''))
                vp_content_type =vp .get ('type','')
                thumb =_thumb (ic .get ('image'))

                if vl_type =='live'and vl_id :
                    channel_slug =vl_id .replace ('rtlde_','')
                    live_label =f'[COLOR gold][B]LIVE - {title }[/B][/COLOR]'
                    url =self .build_url ({
                        'mode':'play_live',
                        'channel_id':channel_slug ,
                        'title':urllib .parse .quote_plus (title ),
                    })
                    li =xbmcgui .ListItem (label =live_label )
                    li .setProperty ('IsPlayable','true')
                    local_img =self ._channel_image (channel_slug )
                    art_img =local_img or thumb
                    if art_img :
                        li .setArt ({'thumb':art_img ,'icon':art_img ,'clearlogo':art_img ,'fanart':art_img })
                    li .setInfo ('video',{'title':'\u0001'+live_label ,'plot':ic .get ('description','')or '','tvshowtitle':bt })
                    live_entries .append ((url ,li ,False ))
                    continue

                if t_type =='player'and vp_id :
                    if vp_content_type in ('live','livetv','channel','event','live_event','event_stream'):
                        live_label =f'[COLOR gold][B]LIVE - {title }[/B][/COLOR]'
                        url =self .build_url ({
                            'mode':'play_live',
                            'channel_id':vp_id ,
                            'title':urllib .parse .quote_plus (title ),
                        })
                        li =xbmcgui .ListItem (label =live_label )
                        li .setProperty ('IsPlayable','true')
                        local_img =self ._channel_image (vp_id )
                        art_img =local_img or thumb
                        if art_img :
                            li .setArt ({'thumb':art_img ,'icon':art_img ,'clearlogo':art_img ,'fanart':art_img })
                        li .setInfo ('video',{'title':'\u0001'+live_label ,'plot':ic .get ('description','')or '','tvshowtitle':bt })
                        live_entries .append ((url ,li ,False ))
                    continue

                if not vl_id :continue
                li =xbmcgui .ListItem (label =title )
                li .setArt ({'thumb':thumb ,'icon':thumb ,'fanart':thumb })
                li .setInfo ('video',{'title':title ,'plot':ic .get ('description','')or '','tvshowtitle':bt })
                if vl_type =='program':
                    url =self .build_url ({'mode':'show_program','program_id':vl_id ,'seo':vl_seo })
                    is_folder =True
                elif vl_type =='video':
                    url =self .build_url ({'mode':'play_vod','video_id':vl_id ,'video_seo':vl_seo ,'title':urllib .parse .quote_plus (title )})
                    li .setProperty ('IsPlayable','true')
                    is_folder =False
                else :
                    continue
                other_entries .append ((url ,li ,is_folder ))

        found =0
        for url ,li ,is_folder in live_entries +other_entries :
            xbmcplugin .addDirectoryItem (handle =self .handle ,url =url ,listitem =li ,isFolder =is_folder )
            found +=1

        xbmcplugin .addSortMethod (self .handle ,xbmcplugin .SORT_METHOD_NONE )
        _log (f'show_guest_free: {found } Eintraege')
        if found ==0 :
            xbmcgui .Dialog ().notification (
                'RTL+','Keine Inhalte gefunden.',xbmcgui .NOTIFICATION_WARNING ,3000 )
        xbmcplugin .endOfDirectory (self .handle )

    # Cache for meine_inhalte API data within a session
    _meine_cache ={}

    def show_meine_inhalte (self ):
        _log ('show_meine_inhalte')

        from .evil import bookmarks as _bookmarks
        local_data =_bookmarks .get ()

        data =self .api .get_frontspace ('bookmarks',page =1 ,nb_pages =2 )
        if not data and not local_data :
            xbmcgui .Dialog ().notification (
            'RTL+','Mein RTL+: Anmeldung erforderlich oder Serverfehler.',
            xbmcgui .NOTIFICATION_ERROR ,5000 
            )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return 

        Navigator ._meine_cache ['local']=local_data or []
        Navigator ._meine_cache ['api']=data or {}

        folder_count =0

        # Folder: Weiterschauen (local bookmarks)
        if local_data :
            url =self .build_url ({'mode':'show_meine_block','block_key':'weiterschauen','label':urllib .parse .quote_plus ('Weiterschauen')})
            li =xbmcgui .ListItem (label ='Weiterschauen')
            li .setProperty ('IsPlayable','false')
            li .setArt ({'thumb':os .path .join (xbmcvfs .translatePath (xbmcaddon .Addon ().getAddonInfo ('path')),'resources','media','favourites.png')})
            li .setInfo ('video',{'title':'Weiterschauen','plot':f'{len (local_data )} gespeicherte Inhalte'})
            xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
            folder_count +=1

        # Folders from API blocks
        if data :
            blocks =data .get ('blocks',[])
            valid_blocks =[b for b in blocks if b .get ('content',{}).get ('items')]
            _log (f'show_meine_inhalte: {len (valid_blocks )} API-Blöcke mit Inhalten')
            for idx ,block in enumerate (valid_blocks ):
                content_b =block .get ('content',{})
                block_title_obj =content_b .get ('title')or {}
                if isinstance (block_title_obj ,dict ):
                    block_title =block_title_obj .get ('short','')or block_title_obj .get ('long','')or ''
                else :
                    block_title =str (block_title_obj )if block_title_obj else ''
                if not block_title :
                    block_title =f'Meine Inhalte {idx +1 }'
                if block_title .lower ()=='jetzt weiterschauen':
                    block_title ='Jetzt weiterschauen (Online Liste)'
                items =content_b .get ('items',[])
                block_key =f'api_{idx }'
                url =self .build_url ({'mode':'show_meine_block','block_key':block_key ,'label':urllib .parse .quote_plus (block_title )})
                li =xbmcgui .ListItem (label =block_title )
                li .setProperty ('IsPlayable','false')
                li .setArt ({'thumb':os .path .join (xbmcvfs .translatePath (xbmcaddon .Addon ().getAddonInfo ('path')),'resources','media','favourites.png')})
                li .setInfo ('video',{'title':block_title ,'plot':f'{len (items )} Inhalte'})
                xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
                folder_count +=1

        if folder_count ==0 :
            xbmcgui .Dialog ().notification (
            'RTL+','Mein RTL+ ist leer – noch nichts gemerkt oder angesehen.',
            xbmcgui .NOTIFICATION_INFO ,4000 
            )
            li =xbmcgui .ListItem (label ='[Keine Inhalte]')
            xbmcplugin .addDirectoryItem (self .handle ,'',li ,False )

        xbmcplugin .endOfDirectory (self .handle )

    def show_meine_block (self ,block_key ,label =''):
        _log (f'show_meine_block key={block_key }')

        if block_key =='weiterschauen':
            local_data =Navigator ._meine_cache .get ('local',[])
            if not local_data :
                from .evil import bookmarks as _bookmarks
                local_data =_bookmarks .get ()
            if not local_data :
                xbmcgui .Dialog ().notification ('RTL+','Keine gespeicherten Inhalte.',xbmcgui .NOTIFICATION_INFO ,3000 )
                xbmcplugin .endOfDirectory (self .handle )
                return 
            for item in local_data :
                li =xbmcgui .ListItem (label =item ['label'])
                li .setArt ({'thumb':item .get ('thumb','')})
                li .setProperty ('IsPlayable','true'if item .get ('playable')else 'false')
                li .setInfo ('video',{'title':item ['label']})
                cmd =f'RunPlugin({self .base_url }?mode=remove_bookmark&path={urllib .parse .quote_plus (item ["path"])})'
                li .addContextMenuItems ([('Von Weiterschauen entfernen',cmd )])
                xbmcplugin .addDirectoryItem (self .handle ,item ['path'],li ,bool (item .get ('folder',0)))
            xbmcplugin .setContent (self .handle ,'videos')
            xbmcplugin .endOfDirectory (self .handle )
            return 

        try :
            idx =int (block_key .replace ('api_',''))
        except ValueError :
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return 

        data =Navigator ._meine_cache .get ('api')
        if not data :
            data =self .api .get_frontspace ('bookmarks',page =1 ,nb_pages =2 )
            if not data :
                xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden.',xbmcgui .NOTIFICATION_ERROR ,4000 )
                xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
                return 
            Navigator ._meine_cache ['api']=data

        blocks =data .get ('blocks',[])
        valid_blocks =[b for b in blocks if b .get ('content',{}).get ('items')]
        if idx >=len (valid_blocks ):
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return 

        items =valid_blocks [idx ].get ('content',{}).get ('items',[])
        total =0
        for item in items :
            if self ._add_item_as_folder (item ):
                total +=1

        if total ==0 :
            li =xbmcgui .ListItem (label ='[Keine Inhalte]')
            xbmcplugin .addDirectoryItem (self .handle ,'',li ,False )

        xbmcplugin .setContent (self .handle ,'videos')
        xbmcplugin .endOfDirectory (self .handle )

    def _add_item_as_folder (self ,item ):
        """Render item as folder if it is a program; fall back to _add_item otherwise."""
        try :
            ic =item .get ('itemContent',{})
            if not ic :
                return False
            action =ic .get ('action',{})or {}
            target =action .get ('target',{})or {}
            t_type =target .get ('type','')
            if t_type =='lock':
                target =(target .get ('value_lock',{})or {}).get ('originalTarget',{})or {}
                t_type =target .get ('type','')
            vl =target .get ('value_layout',{})or {}
            layout_type =vl .get ('type','')
            layout_id =vl .get ('id','')
            layout_seo =vl .get ('seo','')

            if not layout_id :
                return self ._add_item (item )

            title_raw =ic .get ('title','')or ''
            extra_title =ic .get ('extraTitle','')or ''
            highlight =ic .get ('highlight','')or ''
            seo_title =layout_seo .replace ('-',' ').title ()if layout_seo else ''
            if title_raw and extra_title :
                full_title =f'{title_raw } - {extra_title }'
            elif title_raw :
                full_title =title_raw
            elif extra_title :
                full_title =extra_title
            elif seo_title :
                full_title =seo_title
            elif highlight :
                full_title =highlight .split ('•')[0 ].strip ()
            else :
                return False

            thumb =_image_url (ic .get ('image',{}),width =320 ,height =180 ,preferred_ratio ='16:9')
            fanart =_image_url (ic .get ('secondaryImage',{}),width =960 ,height =540 ,preferred_ratio ='16:9')or thumb
            poster =_image_url (ic .get ('image',{}),width =320 ,height =480 ,preferred_ratio ='2:3')or thumb
            description =ic .get ('description','')or highlight

            if layout_type =='program':
                url =self .build_url ({'mode':'show_program','program_id':layout_id ,'seo':layout_seo })
                li =xbmcgui .ListItem (label =full_title )
                li .setProperty ('IsPlayable','false')
                art ={'thumb':thumb or poster ,'fanart':fanart }
                if poster :art ['poster']=poster
                li .setArt (art )
                li .setInfo ('video',{'title':full_title ,'plot':description ,'mediatype':'tvshow'})
                bookmark_url =self .build_url ({'mode':'toggle_bookmark','program_id':layout_id ,'title':urllib .parse .quote_plus (full_title ),'subscribed':'1'})
                unmark_url =self .build_url ({'mode':'toggle_bookmark','program_id':layout_id ,'title':urllib .parse .quote_plus (full_title ),'subscribed':'0'})
                li .addContextMenuItems ([('Merken',f'RunPlugin({bookmark_url })'),('Nicht mehr merken',f'RunPlugin({unmark_url })')])
                xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
                return True

            elif layout_type =='video':
                parent =vl .get ('parent',{})or {}
                parent_id =str (parent .get ('id',''))
                parent_seo =parent .get ('seo','')
                if parent_id :
                    url =self .build_url ({'mode':'show_program','program_id':parent_id ,'seo':parent_seo })
                    li =xbmcgui .ListItem (label =title_raw or full_title )
                    li .setProperty ('IsPlayable','false')
                    art ={'thumb':thumb or poster ,'fanart':fanart }
                    if poster :art ['poster']=poster
                    li .setArt (art )
                    li .setInfo ('video',{'title':title_raw or full_title ,'plot':description ,'mediatype':'tvshow'})
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
                    return True
                return self ._add_item (item )

            else :
                return self ._add_item (item )

        except Exception as e :
            _log (f'_add_item_as_folder error: {e }')
            return False

    def _render_layout_with_headers (self ,data ):
        """Flat renderer with section headers (used outside Meine Inhalte)."""
        blocks =data .get ('blocks',[])
        total =0 

        for block in blocks :
            content =block .get ('content',{})
            block_title_obj =content .get ('title')or {}
            if isinstance (block_title_obj ,dict ):
                block_title =block_title_obj .get ('short','')or block_title_obj .get ('long','')or ''
            else :
                block_title =str (block_title_obj )if block_title_obj else ''

            items =content .get ('items',[])
            if not items :
                continue 

            if block_title :
                sep =xbmcgui .ListItem (label =f'[COLOR gold]── {block_title } ──[/COLOR]')
                sep .setProperty ('IsPlayable','false')
                sep .setInfo ('video',{'title':block_title })
                xbmcplugin .addDirectoryItem (self .handle ,'',sep ,False )

            for item in items :
                if self ._add_item (item ):
                    total +=1 

        if total ==0 :
            li =xbmcgui .ListItem (label ='[Keine Inhalte]')
            xbmcplugin .addDirectoryItem (self .handle ,'',li ,False )

        xbmcplugin .setContent (self .handle ,'videos')
        xbmcplugin .endOfDirectory (self .handle )

    def _add_context_menu (self ,li ,params ,title ,thumb ):
        url =self .build_url (params )
        enc_url =urllib .parse .quote_plus (url )
        enc_title =urllib .parse .quote_plus (title )
        enc_thumb =urllib .parse .quote_plus (thumb or '')
        cmd =f'RunPlugin({self .base_url }?mode=add_bookmark&path={enc_url }&label={enc_title }&thumb={enc_thumb })'
        li .addContextMenuItems ([('Zu Weiterschauen hinzufuegen',cmd )])

    def show_service (self ,service ,label ='',page =1 ):
        _log (f'show_service service={service } page={page }')
        data =self .api .get_service (service ,page =page ,nb_pages =2 )
        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return 

        self ._render_layout (data ,next_params ={
        'mode':'show_service',
        'service':service ,
        'label':urllib .parse .quote_plus (label or service ),
        })

    def show_alias (self ,alias ,page =1 ):
        _log (f'show_alias alias={alias } page={page }')
        data =self .api .get_alias (alias ,page =page )
        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return 

        if alias =='home':
            blocks =data .get ('blocks',[])
            highlights_block =None 
            other_blocks =[]
            for block in blocks :
                ct =block .get ('content',{})
                title_obj =ct .get ('title')or {}
                btitle =(title_obj .get ('short','')or title_obj .get ('long','')
                if isinstance (title_obj ,dict )else str (title_obj ))
                if 'highlight'in btitle .lower ()or 'neu'in btitle .lower ():
                    if highlights_block is None :
                        highlights_block =block 
                    else :
                        other_blocks .append (block )
                else :
                    other_blocks .append (block )
            if highlights_block :
                data =dict (data )
                data ['blocks']=[highlights_block ]+other_blocks 

        self ._render_layout (data ,next_params ={'mode':'show_alias','alias':alias })

    def show_folder (self ,folder_id ,seo ='',page =1 ):
        _log (f'show_folder id={folder_id } page={page }')
        data =self .api .get_folder (folder_id ,seo =seo ,page =page )
        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return

        blocks =data .get ('blocks',[])
        named_blocks =[]
        actionless_blocks =[]
        inline_blocks =[]
        for i ,block in enumerate (blocks ):
            content =block .get ('content',{})
            title_obj =content .get ('title')or {}
            if isinstance (title_obj ,dict ):
                btitle =title_obj .get ('short','')or title_obj .get ('long','')or ''
            else :
                btitle =str (title_obj )
            items =content .get ('items',[])
            if not items :
                continue
            has_action =any ((it .get ('itemContent',{})or {}).get ('action')for it in items )
            if not has_action :
                actionless_blocks .append ((i ,btitle ,items ))
            elif btitle and len (items )>1 :
                named_blocks .append ((i ,btitle ,items ))
            else :
                inline_blocks .append ((i ,btitle ,items ))

        if actionless_blocks or len (named_blocks )>=2 :
            _log (f'show_folder: {len (named_blocks )} named + {len (actionless_blocks )} actionless + {len (inline_blocks )} inline')
            for block_idx ,btitle ,items in inline_blocks :
                for item in items :
                    self ._add_item (item )
            for block_idx ,btitle ,items in actionless_blocks :
                for item in items :
                    ic =item .get ('itemContent',{})or {}
                    analytics =ic .get ('analytics',{})or {}
                    tealium =analytics .get ('tealiumImpression',{})or {}
                    folder_id_str =str (tealium .get ('item_id',''))
                    item_title =tealium .get ('item_title','')
                    img =ic .get ('image',{})or {}
                    caption =img .get ('caption','')
                    label =item_title or caption
                    if not label or not folder_id_str :
                        continue
                    thumb =_image_url (img ,width =480 ,height =270 ,preferred_ratio ='16:9')
                    url =self .build_url ({'mode':'show_folder','folder_id':folder_id_str })
                    li =xbmcgui .ListItem (label =label )
                    li .setProperty ('IsPlayable','false')
                    if thumb :
                        li .setArt ({'thumb':thumb ,'fanart':thumb })
                    li .setInfo ('video',{'title':label })
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
            for block_idx ,btitle ,items in named_blocks :
                cat_thumb =''
                for it in items [:3 ]:
                    ic =it .get ('itemContent',{})
                    cat_thumb =_image_url (ic .get ('image',{}),preferred_ratio ='16:9')
                    if cat_thumb :
                        break
                url =self .build_url ({
                'mode':'show_folder_block',
                'folder_id':folder_id ,
                'block_index':block_idx ,
                'seo':seo ,
                })
                li =xbmcgui .ListItem (label =btitle )
                li .setProperty ('IsPlayable','false')
                if cat_thumb :
                    li .setArt ({'thumb':cat_thumb ,'fanart':cat_thumb })
                li .setInfo ('video',{'title':btitle ,'plot':btitle })
                xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
            xbmcplugin .setContent (self .handle ,'videos')
            xbmcplugin .endOfDirectory (self .handle )
        else :
            self ._render_layout (data ,next_params ={'mode':'show_folder','folder_id':folder_id })

    def show_folder_block (self ,folder_id ,block_index ,seo ='',page =1 ):
        _log (f'show_folder_block id={folder_id } block={block_index }')
        data =self .api .get_folder (folder_id ,seo =seo ,page =page )
        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return 

        blocks =data .get ('blocks',[])
        if block_index >=len (blocks ):
            xbmcplugin .endOfDirectory (self .handle )
            return 

        block =blocks [block_index ]
        items =block .get ('content',{}).get ('items',[])
        total =0 
        for item in items :
            if self ._add_item (item ):
                total +=1 

        if total ==0 :
            li =xbmcgui .ListItem (label ='[Keine Inhalte]')
            xbmcplugin .addDirectoryItem (self .handle ,'',li ,False )

        xbmcplugin .setContent (self .handle ,'movies')
        xbmcplugin .endOfDirectory (self .handle )

    _SEASON_PATTERNS =('staffel','season','saison','serie ','teil ')
    _MOVIE_KEYWORDS =('film','spielfilm','kinofilm','movie','dokumentarfilm')
    _SERIES_KEYWORDS =('staffel','folge','season','episode','serie','show')

    def _is_movie_highlight (self ,highlight ,extra_details ='',details =''):
        hl =(highlight or '').lower ()
        ed =(extra_details or '').lower ()
        det =(details or '').lower ()
        combined =hl +' '+ed +' '+det
        has_movie_kw =any (k in combined for k in self ._MOVIE_KEYWORDS )
        has_series_kw =any (k in combined for k in self ._SERIES_KEYWORDS )
        import re as _re 
        has_duration =bool (_re .search (r'\d+\s*min',combined ))
        return (has_movie_kw or has_duration )and not has_series_kw 

    def play_program (self ,program_id ,seo ='',title ='Film'):
        data =self .api .get_program_layout (program_id ,seo =seo ,page =1 )
        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return 

        blocks =data .get ('blocks',[])
        all_clips =[]
        for block in blocks :
            bc =block .get ('content',{})
            btitle_obj =bc .get ('title')or {}
            btitle =(btitle_obj .get ('short','')or btitle_obj .get ('long','')
            if isinstance (btitle_obj ,dict )else str (btitle_obj ))
            if 'empfehlung'in btitle .lower ()or 'recommendation'in btitle .lower ():
                continue 
            for item in bc .get ('items',[]):
                ic =item .get ('itemContent',{})
                action =ic .get ('action',{})or {}
                target =action .get ('target',{})or {}
                if target .get ('type')=='lock':
                    target =(target .get ('value_lock',{})or {}).get ('originalTarget',{})or {}
                vl =target .get ('value_layout',{})or {}
                if target .get ('type')=='layout'and vl .get ('type')=='video':
                    all_clips .append ((vl .get ('id',''),vl .get ('seo',''),ic ))

        unique_ids =list (dict .fromkeys (cid for cid ,_ ,_ in all_clips if cid ))
        if not unique_ids :

            self .show_program (program_id ,seo =seo )
            return 

        clip_id =unique_ids [0 ]
        ic =next ((ic for cid ,_ ,ic in all_clips if cid ==clip_id ),all_clips [0 ][2 ])
        vl_seo =next ((s for cid ,s ,_ in all_clips if cid ==clip_id ),'')

        resolved_title =(ic .get ('title')or ic .get ('extraTitle')or title )
        thumb =_image_url (ic .get ('image',{}),width =320 ,height =180 ,preferred_ratio ='16:9')
        fanart =_image_url (ic .get ('secondaryImage',{}),width =960 ,height =540 ,preferred_ratio ='16:9')or thumb 
        poster =_image_url (ic .get ('image',{}),width =320 ,height =480 ,preferred_ratio ='2:3')or thumb 

        play_url =self .build_url ({
        'mode':'play_vod',
        'video_id':clip_id ,
        'title':urllib .parse .quote_plus (resolved_title ),
        'video_seo':vl_seo ,
        'program_id':program_id ,
        })
        li =xbmcgui .ListItem (label =resolved_title ,path =play_url )
        li .setProperty ('IsPlayable','true')
        if thumb :
            li .setArt ({'thumb':thumb ,'poster':poster ,'fanart':fanart })
        li .setInfo ('video',{
        'title':resolved_title ,
        'plot':ic .get ('description','')or '',
        'mediatype':'movie',
        })
        xbmcplugin .setResolvedUrl (self .handle ,True ,li )

    def _is_season_block (self ,btitle ):
        bl =btitle .lower ().strip ()
        return any (bl .startswith (p )for p in self ._SEASON_PATTERNS )or (
        bl .startswith ('s')and len (bl )<=4 and bl [1 :].isdigit ()
        )

    def show_program (self ,program_id ,seo ='',page =1 ):
        _log (f'show_program id={program_id } page={page }')
        data =self .api .get_program_layout (program_id ,seo =seo ,page =page )
        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
            xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
            return 

        blocks =data .get ('blocks',[])
        import re as _re 

        concurrent_seasons =[]
        for block in blocks :
            alt =block .get ('alternativeContent')
            if not alt or not isinstance (alt ,dict ):
                continue 
            concurrent =alt .get ('concurrentBlocks')
            if not concurrent or not isinstance (concurrent ,list ):
                continue 
            for cb in concurrent :
                if not cb or not isinstance (cb ,dict ):
                    continue 
                cb_title =cb .get ('title','')
                cb_id =cb .get ('id','')
                if cb_title and cb_id :
                    cb_items =cb .get ('content',{}).get ('items',[])or []
                    concurrent_seasons .append ((cb_title ,cb_id ,cb_items ))

        if len (concurrent_seasons )>=1 :
            _log (f'show_program {program_id }: {len (concurrent_seasons )} concurrentBlocks-Staffeln')
            for idx ,(s_title ,s_block_id ,s_items )in enumerate (concurrent_seasons ):
                m =_re .search (r'\d+',s_title )
                s_num =int (m .group ())if m else (idx +1 )
                cat_thumb =''
                for it in s_items [:3 ]:
                    ic2 =it .get ('itemContent',{})
                    cat_thumb =_image_url (ic2 .get ('image',{}),preferred_ratio ='16:9')
                    if cat_thumb :
                        break 
                url =self .build_url ({
                'mode':'show_season',
                'program_id':program_id ,
                'season_title':urllib .parse .quote_plus (s_title ),
                'block_index':idx ,
                'season_block_id':s_block_id ,
                'seo':seo ,
                })
                li =xbmcgui .ListItem (label =s_title )
                li .setProperty ('IsPlayable','false')
                if cat_thumb :
                    li .setArt ({'thumb':cat_thumb ,'fanart':cat_thumb })
                li .setInfo ('video',{'title':s_title ,'season':s_num ,'mediatype':'season'})
                xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
            _skip_extra ={'empfehlung','recommendation','alle staffeln'}
            for block in blocks :
                bc =block .get ('content',{})
                btitle_obj =bc .get ('title')or {}
                btitle =(btitle_obj .get ('short','')or btitle_obj .get ('long','')
                if isinstance (btitle_obj ,dict )else str (btitle_obj ))
                if not btitle :
                    continue
                if any (s in btitle .lower ()for s in _skip_extra ):
                    continue
                if self ._is_season_block (btitle ):
                    continue
                block_id =block .get ('id','')
                if not block_id :
                    continue
                extra_items =bc .get ('items',[])
                if not extra_items :
                    continue
                cat_thumb =''
                for it in extra_items [:3 ]:
                    ic2 =it .get ('itemContent',{})
                    cat_thumb =_image_url (ic2 .get ('image',{}),preferred_ratio ='16:9')
                    if cat_thumb :
                        break
                url =self .build_url ({
                'mode':'show_season',
                'program_id':program_id ,
                'season_title':urllib .parse .quote_plus (btitle ),
                'block_index':0 ,
                'season_block_id':block_id ,
                'seo':seo ,
                })
                li =xbmcgui .ListItem (label =btitle )
                li .setProperty ('IsPlayable','false')
                if cat_thumb :
                    li .setArt ({'thumb':cat_thumb ,'fanart':cat_thumb })
                li .setInfo ('video',{'title':btitle ,'mediatype':'season'})
                xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
            xbmcplugin .setContent (self .handle ,'tvshows')
            xbmcplugin .endOfDirectory (self .handle )
            return 

        content_blocks =[]
        for block in blocks :
            bc =block .get ('content',{})
            btitle_obj =bc .get ('title')or {}
            btitle =(btitle_obj .get ('short','')or btitle_obj .get ('long','')
            if isinstance (btitle_obj ,dict )else str (btitle_obj ))
            if 'empfehlung'in btitle .lower ()or 'recommendation'in btitle .lower ():
                continue 
            items =bc .get ('items',[])
            if items :
                content_blocks .append ((btitle ,items ))

        all_clips =[]
        for btitle ,items in content_blocks :
            for item in items :
                ic =item .get ('itemContent',{})
                action =ic .get ('action',{})or {}
                target =action .get ('target',{})or {}
                if target .get ('type')=='lock':
                    target =(target .get ('value_lock',{})or {}).get ('originalTarget',{})or {}
                vl =target .get ('value_layout',{})or {}
                if target .get ('type')=='layout'and vl .get ('type')=='video':
                    all_clips .append ((vl .get ('id',''),ic ))

        unique_clip_ids =list (dict .fromkeys (cid for cid ,_ in all_clips if cid ))
        if len (all_clips )>=1 and len (unique_clip_ids )==1 :
            clip_id ,ic =all_clips [0 ]
            action =ic .get ('action',{})or {}
            vl =(action .get ('target',{})or {}).get ('value_layout',{})or {}
            seo =vl .get ('seo','')
            seo_title =seo .replace ('-',' ').title ()if seo else ''
            title =(ic .get ('title')or ic .get ('extraTitle')or seo_title or 
            ic .get ('highlight','').split ('•')[-1 ].strip ()or clip_id )
            play_url =self .build_url ({
            'mode':'play_vod',
            'video_id':clip_id ,
            'title':urllib .parse .quote_plus (title ),
            })
            li =xbmcgui .ListItem (label =title ,path =play_url )
            li .setProperty ('IsPlayable','true')
            thumb =_image_url (ic .get ('image',{}),width =320 ,height =180 ,preferred_ratio ='16:9')
            fanart =_image_url (ic .get ('secondaryImage',{}),width =960 ,height =540 ,preferred_ratio ='16:9')or thumb 
            poster =_image_url (ic .get ('image',{}),width =320 ,height =480 ,preferred_ratio ='2:3')or thumb 
            if thumb :
                li .setArt ({'thumb':thumb ,'poster':poster ,'fanart':fanart })
            li .setInfo ('video',{
            'title':title ,
            'plot':ic .get ('description','')or '',
            'mediatype':'movie',
            })
            xbmcplugin .addDirectoryItem (self .handle ,play_url ,li ,False )
            xbmcplugin .setContent (self .handle ,'movies')
            xbmcplugin .endOfDirectory (self .handle )
            return 

        season_blocks =[(bt ,it )for bt ,it in content_blocks if self ._is_season_block (bt )]

        if len (season_blocks )>=2 :
            _log (f'show_program {program_id }: {len (season_blocks )} Staffeln (Titel-Erkennung)')
            for block_idx ,(btitle ,items )in enumerate (season_blocks ):
                m =_re .search (r'\d+',btitle )
                s_num =int (m .group ())if m else (block_idx +1 )
                cat_thumb =''
                for it in items [:3 ]:
                    ic2 =it .get ('itemContent',{})
                    cat_thumb =_image_url (ic2 .get ('image',{}),preferred_ratio ='16:9')
                    if cat_thumb :
                        break 
                url =self .build_url ({
                'mode':'show_season',
                'program_id':program_id ,
                'season_title':urllib .parse .quote_plus (btitle ),
                'block_index':block_idx ,
                })
                li =xbmcgui .ListItem (label =btitle )
                li .setProperty ('IsPlayable','false')
                if cat_thumb :
                    li .setArt ({'thumb':cat_thumb ,'fanart':cat_thumb })
                li .setInfo ('video',{'title':btitle ,'season':s_num ,'mediatype':'season'})
                xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
            xbmcplugin .setContent (self .handle ,'tvshows')
            xbmcplugin .endOfDirectory (self .handle )
            return 

        episode_items =[]
        for btitle ,items in content_blocks :
            for item in items :
                ic =item .get ('itemContent',{})
                episode_items .append ((_ep_sort_key (ic ),item ))

        episode_items .sort (key =lambda x :x [0 ])

        total =0 
        for _ ,item in episode_items :
            if self ._add_item (item ):
                total +=1 

        if total ==0 :
            li =xbmcgui .ListItem (label ='[Keine Episoden]')
            xbmcplugin .addDirectoryItem (self .handle ,'',li ,False )

        xbmcplugin .setContent (self .handle ,'episodes')
        xbmcplugin .endOfDirectory (self .handle )

    def _fetch_all_block_items (self ,program_id ,season_block_id ,seo =''):
        import math as _math 
        NB =3 
        all_items =[]

        first =self .api .get_program_block (program_id ,season_block_id ,page =1 ,nb_pages =NB ,seo =seo )
        if not first :
            return all_items 

        def _extract (block_data ):
            c =block_data .get ('content',{})
            it =c .get ('items',[])or []
            if not it :
                for b in block_data .get ('blocks',[]):
                    bi =b .get ('content',{}).get ('items',[])or []
                    it .extend (bi )
            if not it :
                it =block_data .get ('items',[])or []
            return c ,it 

        first_content ,first_items =_extract (first )
        all_items .extend (first_items )

        pagination =first_content .get ('pagination')or {}
        total_items =pagination .get ('totalItems',0 )
        ipp =pagination .get ('itemsPerPage',6 )or 6 
        if not total_items :
            _log (f'_fetch_all_block_items: kein totalItems, nur erste {len (all_items )} items')
            return all_items 

        total_pages =_math .ceil (total_items /ipp )
        _log (f'_fetch_all_block_items: totalItems={total_items } ipp={ipp } totalPages={total_pages }')

        page =1 +NB 
        while page <=total_pages :
            block_data =self .api .get_program_block (program_id ,season_block_id ,page =page ,nb_pages =NB ,seo =seo )
            if not block_data :
                break 
            _ ,page_items =_extract (block_data )
            all_items .extend (page_items )
            _log (f'_fetch_all_block_items page={page } got={len (page_items )} total={len (all_items )}')
            page +=NB 

        return all_items 

    def show_season (self ,program_id ,block_index ,season_title ='',season_block_id ='',seo =''):
        _log (f'show_season id={program_id } block={block_index } block_id={season_block_id }')
        items =[]

        if season_block_id and program_id :
            _log (f'show_season: fetching all pages via /program/{program_id }/block/{season_block_id }')
            items =self ._fetch_all_block_items (program_id ,season_block_id ,seo =seo )
            _log (f'show_season block API total: {len (items )} items')

        if not items :
            data =self .api .get_program_layout (program_id ,page =1 ,nb_pages =5 )
            if not data :
                xbmcgui .Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui .NOTIFICATION_ERROR ,4000 )
                xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
                return 

            blocks =data .get ('blocks',[])
            season_blocks =[]
            for block in blocks :
                bc =block .get ('content',{})
                btitle_obj =bc .get ('title')or {}
                btitle =(btitle_obj .get ('short','')or btitle_obj .get ('long','')
                if isinstance (btitle_obj ,dict )else str (btitle_obj ))
                if 'empfehlung'in btitle .lower ()or 'recommendation'in btitle .lower ():
                    continue 
                block_items =bc .get ('items',[])
                if block_items and self ._is_season_block (btitle ):
                    season_blocks .append ((btitle ,block_items ))
            if block_index <len (season_blocks ):
                _ ,items =season_blocks [block_index ]

        episode_items =[]
        for item in items :
            ic =item .get ('itemContent',{})
            episode_items .append ((_ep_sort_key (ic ),item ))

        episode_items .sort (key =lambda x :x [0 ])

        total =0 
        for _ ,item in episode_items :
            if self ._add_item (item ):
                total +=1 

        if total ==0 :
            li =xbmcgui .ListItem (label ='[Keine Episoden]')
            xbmcplugin .addDirectoryItem (self .handle ,'',li ,False )

        xbmcplugin .setContent (self .handle ,'episodes')
        xbmcplugin .endOfDirectory (self .handle )

    def _epg_current_program (self ,epgbox ):
        import time as _time
        from datetime import datetime as _dt
        import re as _re
        now_ts = _time.time ()
        current = None
        next_ep = None

        def _parse_ts (date_str ):
            try :
                s = _re.sub (r'([+-]\d{2}):(\d{2})$',lambda m :f'{m.group(1)}{m.group(2)}',date_str )
                return _dt.strptime (s ,'%Y-%m-%dT%H:%M:%S%z').timestamp ()
            except Exception :
                return None

        for ep in epgbox :
            pb = ep.get ('progressBar')
            if pb is not None :
                start_ts = _parse_ts (ep.get ('start',{}).get ('date',''))
                end_ts = _parse_ts (ep.get ('end',{}).get ('date',''))
                if start_ts is not None and end_ts is not None :
                    if start_ts <= now_ts <= end_ts :
                        current = ep
                        break

                else :

                    current = ep
                    break

        if current is None :
            for ep in epgbox :
                start_ts = _parse_ts (ep.get ('start',{}).get ('date',''))
                end_ts = _parse_ts (ep.get ('end',{}).get ('date',''))
                if start_ts is None or end_ts is None :
                    continue
                if start_ts <= now_ts <= end_ts :
                    current = ep
                    break

        for ep in epgbox:
            if current and ep is current:
                continue
            try:
                from datetime import datetime as _dt
                import re as _re
                start_str = ep.get ('start',{}).get ('date','')
                if not start_str:
                    continue
                start_str_utc = _re.sub (r'([+-]\d{2}):(\d{2})$',lambda m:f'{m.group(1)}{m.group(2)}',start_str)
                start_ts = _dt.strptime (start_str_utc,'%Y-%m-%dT%H:%M:%S%z').timestamp ()
                if start_ts > now_ts:
                    next_ep = ep
                    break
            except Exception:
                continue
        return current,next_ep

    def show_live_channels (self ):
        _log ('show_live_channels')

        import time as _time
        data = self.api.get_epg_grid ()
        if not data:
            xbmcgui.Dialog ().notification ('RTL+','Fehler beim Laden der Senderliste',xbmcgui.NOTIFICATION_ERROR,4000)
            xbmcplugin.endOfDirectory (self.handle,succeeded=False)
            return

        items = data.get ('content',{}).get ('items',[])
        if not items:
            for b in data.get ('blocks',[]):
                items += b.get ('content',{}).get ('items',[])

        _log (f'show_live_channels: {len (items)} EPG items via get_epg_grid')

        count = 0
        for item in items:
            li = self._create_live_listitem_epg (item)
            if li:
                count += 1

        xbmcplugin.setContent (self.handle,'videos')
        if count == 0:
            _log ('show_live_channels: Keine Kanäle')
            li = xbmcgui.ListItem (label='[COLOR yellow]Bitte erneut öffnen (Anmeldung wird erneuert...)[/COLOR]')
            xbmcplugin.addDirectoryItem (self.handle,'',li,False)
            xbmcplugin.endOfDirectory (self.handle,succeeded=True)
        else:
            xbmcplugin.endOfDirectory (self.handle,succeeded=True)

    def show_epg (self ):
        _log ('show_epg')
        data = self.api.get_epg_grid ()
        if not data:
            xbmcgui.Dialog ().notification ('RTL+','Fehler beim Laden',xbmcgui.NOTIFICATION_ERROR,4000)
            xbmcplugin.endOfDirectory (self.handle,succeeded=False)
            return
        items = data.get ('content',{}).get ('items',[])
        if not items:
            for b in data.get ('blocks',[]):
                items += b.get ('content',{}).get ('items',[])

        added = 0
        for item in items:
            li = self._create_live_listitem_epg (item)
            if li:
                added += 1

        xbmcplugin.setContent (self.handle,'videos')
        xbmcplugin.endOfDirectory (self.handle)

    _MIDDLEWARE_BASE ='https://pc.middleware.rtlde.bedrock.tech/6play/v2/platforms/m6group_web/services/rtlplus_root'

    def _middleware_headers (self ):
        from .auth import USER_AGENT ,CLIENT_RELEASE 
        return {
        'User-Agent':USER_AGENT ,
        'x-client-release':CLIENT_RELEASE ,
        'x-customer-name':'rtlde',
        'Referer':'https://plus.rtl.de/',
        'Origin':'https://plus.rtl.de',
        }

    def _middleware_image_url (self ,images ,role ='landscape',width =480 ,height =270 ):
        if not images :
            return ''
        role_prio =[role ,'landscape','vignette','banner','square']
        img_id =''
        for r in role_prio :
            for img in images :
                if img .get ('role')==r :
                    img_id =str (img .get ('external_key','')or img .get ('id',''))
                    if img_id :
                        break 
            if img_id :
                break 
        if not img_id :
            img_id =str (images [0 ].get ('external_key','')or images [0 ].get ('id',''))
        if not img_id :
            return ''
        params =f'auto=avif&blur=0&fit=scale_crop&height={height }&interlace=1&quality=100&width={width }'
        path_and_query =f'/v2/images/{img_id }/raw?{params }'
        sig =_sign_image (path_and_query )
        headers_enc =urllib .parse .urlencode ({
        'Referer':'https://plus.rtl.de/',
        'User-Agent':'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
        })
        return f'{IMAGE_CDN }{path_and_query }&hash={sig }|{headers_enc }'

    def show_az (self ):
        import os 
        import requests 
        import xbmcaddon 
        import xbmcvfs 
        _addon =xbmcaddon .Addon ()
        _addon_path =xbmcvfs .translatePath (_addon .getAddonInfo ('path'))

        def _alpha_img (letter ):
            fname =letter if letter !='#'else '0-9'
            path =os .path .join (_addon_path ,'resources','media','alphabet',f'{fname }.jpg')
            if os .path .exists (path ):
                return path 
            return os .path .join (_addon_path ,'resources','media','icon.png')

        letter_counts ={}
        import json ,os ,time 
        _addon2 =xbmcaddon .Addon ()
        _profile2 =xbmcvfs .translatePath (_addon2 .getAddonInfo ('profile'))
        _letters_cache =os .path .join (_profile2 ,'az_cache_letters.json')
        _cache_ok =False 
        if os .path .exists (_letters_cache ):
            try :
                with open (_letters_cache ,'r',encoding ='utf-8')as _f :
                    _cd =json .load (_f )
                if time .time ()-_cd .get ('ts',0 )<86400 :
                    letter_counts =_cd .get ('counts',{})
                    _cache_ok =True 
                    _log ('A-Z first-letters cache hit')
            except Exception as _e :
                _log (f'A-Z first-letters cache load error: {_e }')
        if not _cache_ok :
            try :
                resp =requests .get (
                f'{self ._MIDDLEWARE_BASE }/programs/first-letters',
                headers =self ._middleware_headers (),
                params ={'csa':6 },
                timeout =15 ,
                )
                resp .raise_for_status ()
                letter_counts =resp .json ()or {}
                try :
                    xbmcvfs .mkdirs (_profile2 )
                    with open (_letters_cache ,'w',encoding ='utf-8')as _f :
                        json .dump ({'ts':time .time (),'counts':letter_counts },_f )
                except Exception as _e :
                    _log (f'A-Z first-letters cache save error: {_e }')
            except Exception as e :
                _log (f'A-Z first-letters error: {e }')

        letters =['#']+list ('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
        for letter in letters :
            label ='0-9 / #'if letter =='#'else letter 
            count =letter_counts .get ('@',0 )if letter =='#'else letter_counts .get (letter .lower (),0 )
            if count :
                label =f'{label }  ({count })'
            url =self .build_url ({'mode':'show_az_letter','letter':letter })
            li =xbmcgui .ListItem (label =label )
            li .setProperty ('IsPlayable','false')
            img =_alpha_img (letter )
            li .setArt ({'thumb':img ,'icon':img })
            li .setInfo ('video',{'title':label })
            xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )

        xbmcplugin .setContent (self .handle ,'videos')
        xbmcplugin .endOfDirectory (self .handle )

    def _az_cache_path (self ,letter ):
        import xbmcaddon ,xbmcvfs ,os 
        profile =xbmcvfs .translatePath (xbmcaddon .Addon ().getAddonInfo ('profile'))
        xbmcvfs .mkdirs (profile )
        safe ='0-9'if letter =='#'else letter .upper ()
        return os .path .join (profile ,f'az_cache_{safe }.json')

    def _az_cache_load (self ,letter ):
        import json ,os ,time 
        path =self ._az_cache_path (letter )
        if not os .path .exists (path ):
            return None 
        try :
            with open (path ,'r',encoding ='utf-8')as f :
                data =json .load (f )
            if time .time ()-data .get ('ts',0 )<86400 :
                _log (f'A-Z cache hit for {letter }')
                return data ['programs']
        except Exception as e :
            _log (f'A-Z cache load error: {e }')
        return None 

    def _az_cache_save (self ,letter ,programs ):
        import json ,time 
        path =self ._az_cache_path (letter )
        try :
            with open (path ,'w',encoding ='utf-8')as f :
                json .dump ({'ts':time .time (),'programs':programs },f )
            _log (f'A-Z cache saved for {letter } ({len (programs )} items)')
        except Exception as e :
            _log (f'A-Z cache save error: {e }')

    def show_az_letter (self ,letter ):
        _log (f'show_az_letter letter={letter }')
        import requests 

        all_programs =self ._az_cache_load (letter )

        if all_programs is None :
            first_letter =''if letter =='#'else letter .lower ()
            all_programs =[]
            offset =0 
            limit =100 

            try :
                while True :
                    params ={'csa':6 ,'offset':offset ,'limit':limit ,'with':'rights'}
                    if first_letter :
                        params ['firstLetter']=first_letter 
                    resp =requests .get (
                    f'{self ._MIDDLEWARE_BASE }/programs',
                    headers =self ._middleware_headers (),
                    params =params ,
                    timeout =20 ,
                    )
                    resp .raise_for_status ()
                    page =resp .json ()
                    if not isinstance (page ,list )or not page :
                        break 
                    all_programs .extend (page )
                    if len (page )<limit :
                        break 
                    offset +=limit 
                    if offset >5000 :
                        break 
                self ._az_cache_save (letter ,all_programs )
            except Exception as e :
                _log (f'A-Z middleware error: {e }')
                xbmcgui .Dialog ().notification ('RTL+',f'Fehler: {e }',xbmcgui .NOTIFICATION_ERROR ,4000 )
                xbmcplugin .endOfDirectory (self .handle ,succeeded =False )
                return 

        if not all_programs :
            xbmcgui .Dialog ().notification ('RTL+','Keine Programme gefunden',xbmcgui .NOTIFICATION_INFO ,3000 )
            xbmcplugin .endOfDirectory (self .handle )
            return 

        filtered =[]
        for p in all_programs :
            title =str (p .get ('title')or '').strip ()
            if not title :
                continue 
            first_char =title [0 ].upper ()
            if letter =='#':
                if first_char .isalpha ():
                    continue 
            else :
                if first_char !=letter .upper ():
                    continue 
            filtered .append (p )

        filtered .sort (key =lambda p :str (p .get ('title')or '').lower ())

        total =0 
        seen_ids =set ()

        for p in filtered :
            program_id =str (p .get ('id',''))
            if not program_id or program_id in seen_ids :
                continue 
            seen_ids .add (program_id )

            title =str (p .get ('title')or '').strip ()
            description =str (p .get ('description')or p .get ('summary')or '').strip ()
            images =p .get ('images')or []
            thumb =self ._middleware_image_url (images ,'landscape',480 ,270 )
            poster =self ._middleware_image_url (images ,'vignette',320 ,480 )
            fanart =self ._middleware_image_url (images ,'landscape',960 ,540 )

            program_seo =str (p .get ('seo','')or '').strip ()
            url =self .build_url ({'mode':'show_program','program_id':program_id ,'seo':program_seo })
            li =xbmcgui .ListItem (label =title )
            li .setProperty ('IsPlayable','false')
            art ={}
            if thumb :art ['thumb']=thumb 
            if fanart :art ['fanart']=fanart 
            if poster :art ['poster']=poster 
            if art :li .setArt (art )
            li .setInfo ('video',{'title':title ,'plot':description ,'mediatype':'tvshow'})
            xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
            total +=1 

        if total ==0 :
            li =xbmcgui .ListItem (label =f'[Keine Inhalte unter {letter }]')
            xbmcplugin .addDirectoryItem (self .handle ,'',li ,False )

        xbmcplugin .setContent (self .handle ,'tvshows')
        xbmcplugin .endOfDirectory (self .handle )

    def show_search (self ,query =''):
        if not query :
            kb =xbmc .Keyboard ('','RTL+ Suche')
            kb .doModal ()
            if not kb .isConfirmed ()or not kb .getText ():
                xbmcplugin .endOfDirectory (self .handle )
                return 
            query =kb .getText ()

        _log (f'search query={query }')
        import requests 
        from .api import LAYOUT_BASE 

        from .api import RTL_WEB 
        headers =self .api ._headers (x_location =f'{RTL_WEB }/suche?query={query }')

        try :
            resp =requests .get (
            f'{LAYOUT_BASE }/frontspace/search/layout',
            headers =headers ,
            params ={'blockPage':1 ,'nbPages':2 ,'query':query },
            timeout =20 
            )
            resp .raise_for_status ()
            data =resp .json ()
        except Exception as e :
            _log (f'Search error: {e }')
            data =None 

        if not data :
            xbmcgui .Dialog ().notification ('RTL+','Keine Ergebnisse',xbmcgui .NOTIFICATION_INFO ,3000 )
            xbmcplugin .endOfDirectory (self .handle )
            return 

        self ._render_layout (data ,next_params ={'mode':'search','query':query })

    def _render_layout (self ,data ,next_params =None ,skip_block_titles =None ):
        blocks =data .get ('blocks',[])
        skip_block_titles =[s .lower ()for s in (skip_block_titles or [])]

        all_items =[]
        for block in blocks :
            content =block .get ('content',{})
            block_title_obj =content .get ('title')or {}
            if isinstance (block_title_obj ,dict ):
                block_title =block_title_obj .get ('short','')or block_title_obj .get ('long','')or ''
            else :
                block_title =str (block_title_obj )
            if skip_block_titles and any (s in block_title .lower ()for s in skip_block_titles ):
                continue
            all_items .extend (content .get ('items',[]))

        def _is_live_item (item ):
            ic =item .get ('itemContent',{})or {}
            action =ic .get ('action',{})or {}
            target =action .get ('target',{})or {}
            t_type =target .get ('type','')
            if t_type =='lock':
                target =(target .get ('value_lock',{})or {}).get ('originalTarget',{})or {}
                t_type =target .get ('type','')
            if t_type =='layout':
                vl =target .get ('value_layout',{})or {}
                return vl .get ('type','')in ('live','channel')
            if t_type =='player':
                vp =target .get ('value_player',{})or {}
                return vp .get ('type','')in ('live','livetv','channel','event','live_event','event_stream')
            return False

        live_items =[i for i in all_items if _is_live_item (i )]
        other_items =[i for i in all_items if not _is_live_item (i )]
        ordered =live_items +other_items

        total =0
        for item in ordered :
            if self ._add_item (item ):
                total +=1

        if total ==0 :
            li =xbmcgui .ListItem (label ='[Keine Inhalte]')
            xbmcplugin .addDirectoryItem (self .handle ,'',li ,False )

        xbmcplugin .setContent (self .handle ,'videos')
        xbmcplugin .endOfDirectory (self .handle )

    def _add_item (self ,item ):
        try :
            item_type =item .get ('itemType','')
            ic =item .get ('itemContent',{}
            )
            if not ic :
                return False 

            title =ic .get ('title','')or ''
            extra_title =ic .get ('extraTitle','')or ''
            highlight =ic .get ('highlight','')or ''
            extra_details =ic .get ('extraDetails','')or ''
            details =ic .get ('details','')or ''
            description =ic .get ('description','')or ''

            action_tmp =ic .get ('action',{})or {}
            vl_tmp =(action_tmp .get ('target',{})or {}).get ('value_layout',{})or {}
            seo_raw =vl_tmp .get ('seo','')
            seo_title =seo_raw .replace ('-',' ').title ()if seo_raw else ''

            if title and extra_title :
                full_title =f'{title } - {extra_title }'
            elif title :
                full_title =title 
            elif extra_title :
                full_title =extra_title 
            elif seo_title :
                full_title =seo_title 
            elif highlight :
                parts =[p .strip ()for p in highlight .split ('•')]
                full_title =parts [0 ]if parts else highlight 
            else :
                return False 

            import re as _re 
            episode_label =full_title 
            season_num =0 
            episode_num =0 
            episode_name =''
            air_date =''

            if highlight and '•'in highlight :
                parts =[p .strip ()for p in highlight .split ('•')]

                for part in parts :
                    pl =part .lower ().strip ()
                    if pl .startswith ('staffel'):
                        m =_re .search (r'\d+',pl )
                        if m :
                            try :season_num =int (m .group ())
                            except :pass 
                    elif pl .startswith ('folge'):
                        m =_re .search (r'\d+',pl )
                        if m :
                            try :episode_num =int (m .group ())
                            except :pass 
                    elif _re .search (r'\d{2}\.\d{2}\.\d{4}',part ):
                        air_date =part .strip ()
                    elif _re .fullmatch (r'\d{4}-\d{2}',pl ):
                        pass 
                    else :
                        if part .strip ().lower ()!=title .lower ():
                            episode_name =part .strip ()

                if episode_num and not season_num and (air_date or episode_name ):
                    parts_label =[f'Folge {episode_num }']
                    if air_date :
                        parts_label .append (air_date )
                    if episode_name :
                        parts_label .append (episode_name )
                    episode_label =' • '.join (parts_label )
                    full_title =episode_label 

                elif season_num and episode_num :
                    if episode_name :
                        episode_label =f'S{season_num :02d}E{episode_num :02d} - {episode_name }'
                    else :
                        episode_label =f'S{season_num :02d}E{episode_num :02d}'
                    full_title =episode_label 

                elif episode_num and not season_num :
                    episode_label =f'Folge {episode_num }'
                    if episode_name :
                        episode_label +=f' - {episode_name }'
                    full_title =episode_label 

            if not description :
                parts =[]
                if highlight :parts .append (highlight )
                if extra_details :parts .append (extra_details )
                description =' | '.join (parts )

            genre =''
            year =0 
            if highlight and '•'in highlight :
                hparts =[p .strip ()for p in highlight .split ('•')]
                genre_parts =[p for p in hparts if p .lower ()not in ('film','serie','show','episode')]
                genre =', '.join (genre_parts )if genre_parts else ''
            if extra_details :
                for part in extra_details .split ('•'):
                    part =part .strip ()
                    if part .isdigit ()and len (part )==4 :
                        try :year =int (part )
                        except :pass 
            if not genre and details :
                genre =details 

            thumb =_image_url (ic .get ('image',{}),width =320 ,height =180 ,preferred_ratio ='16:9')
            fanart =_image_url (ic .get ('secondaryImage',{}),width =960 ,height =540 ,preferred_ratio ='16:9')or thumb 
            poster =_image_url (ic .get ('image',{}),width =320 ,height =480 ,preferred_ratio ='2:3')or thumb 

            action =ic .get ('action',{})or {}
            target =action .get ('target',{})or {}
            t_type =target .get ('type','')

            is_premium_content =False 
            if t_type =='lock':
                is_premium_content =True 
                target =(target .get ('value_lock',{})or {}).get ('originalTarget',{})or {}
                t_type =target .get ('type','')

            if is_premium_content and _get_premium_status () == 'Free':
                full_title =_premium_title (full_title )
                episode_label =_premium_title (episode_label )if episode_label else full_title 

            if t_type =='layout':
                vl =target .get ('value_layout',{})or {}
                layout_type =vl .get ('type','')
                layout_id =vl .get ('id','')

                if not layout_id :
                    return False 

                if layout_type =='video':
                    vl_seo =vl .get ('seo','')
                    parent =vl .get ('parent',{})or {}
                    url =self .build_url ({
                    'mode':'play_vod',
                    'video_id':layout_id ,
                    'title':urllib .parse .quote_plus (episode_label or full_title ),
                    'video_seo':vl_seo ,
                    'program_seo':parent .get ('seo',''),
                    'program_id':str (parent .get ('id','')),
                    })
                    li =xbmcgui .ListItem (label =episode_label or full_title )
                    li .setProperty ('IsPlayable','true')
                    if thumb :
                        li .setArt ({'thumb':thumb ,'poster':poster ,'fanart':fanart })
                    info ={
                    'title':episode_label or full_title ,
                    'plot':description ,
                    'genre':genre ,
                    }
                    if year :info ['year']=year 
                    if season_num :info ['season']=season_num 
                    if episode_num :info ['episode']=episode_num 
                    if episode_name :info ['originaltitle']=episode_name 
                    li .setInfo ('video',info )
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,False )
                    return True 

                elif layout_type =='audio':
                    url =self .build_url ({
                    'mode':'play_audio',
                    'audio_id':layout_id ,
                    'title':urllib .parse .quote_plus (full_title ),
                    })
                    li =xbmcgui .ListItem (label =full_title )
                    li .setProperty ('IsPlayable','true')
                    if thumb :
                        li .setArt ({'thumb':thumb ,'poster':poster ,'fanart':fanart })
                    li .setInfo ('music',{
                    'title':full_title ,
                    'comment':description ,
                    'genre':genre ,
                    })
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,False )
                    return True 

                elif layout_type =='radio':
                    url =self .build_url ({
                    'mode':'play_radio',
                    'radio_id':layout_id ,
                    'title':urllib .parse .quote_plus (full_title ),
                    })
                    li =xbmcgui .ListItem (label =full_title )
                    li .setProperty ('IsPlayable','true')
                    art_img =self ._channel_image (layout_id )or thumb 
                    if art_img :
                        li .setArt ({'thumb':art_img ,'icon':art_img })
                    li .setInfo ('video',{'title':full_title ,'plot':description })
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,False )
                    return True 

                elif layout_type =='program':
                    is_movie =self ._is_movie_highlight (highlight ,extra_details ,details )
                    if is_movie :
                        play_url =self .build_url ({
                        'mode':'play_program',
                        'program_id':layout_id ,
                        'seo':vl .get ('seo',''),
                        'title':urllib .parse .quote_plus (full_title ),
                        })
                        li =xbmcgui .ListItem (label =full_title ,path =play_url )
                        li .setProperty ('IsPlayable','true')
                        art ={'thumb':thumb or poster ,'fanart':fanart }
                        if poster :art ['poster']=poster 
                        li .setArt (art )
                        info ={
                        'title':full_title ,
                        'plot':description ,
                        'genre':genre ,
                        'mediatype':'movie',
                        }
                        if year :info ['year']=year 
                        li .setInfo ('video',info )
                        bookmark_url =self .build_url ({'mode':'toggle_bookmark','program_id':layout_id ,'title':urllib .parse .quote_plus (full_title ),'subscribed':'1'})
                        unmark_url =self .build_url ({'mode':'toggle_bookmark','program_id':layout_id ,'title':urllib .parse .quote_plus (full_title ),'subscribed':'0'})
                        li .addContextMenuItems ([
                        ('Merken',f'RunPlugin({bookmark_url })'),
                        ('Nicht mehr merken',f'RunPlugin({unmark_url })'),
                        ])
                        xbmcplugin .addDirectoryItem (self .handle ,play_url ,li ,False )
                    else :
                        url =self .build_url ({
                        'mode':'show_program',
                        'program_id':layout_id ,
                        'seo':vl .get ('seo',''),
                        })
                        li =xbmcgui .ListItem (label =full_title )
                        li .setProperty ('IsPlayable','false')
                        art ={'thumb':thumb or poster ,'fanart':fanart }
                        if poster :art ['poster']=poster 
                        li .setArt (art )
                        info ={
                        'title':full_title ,
                        'plot':description ,
                        'genre':genre ,
                        'mediatype':'tvshow',
                        }
                        if year :info ['year']=year 
                        li .setInfo ('video',info )
                        bookmark_url =self .build_url ({'mode':'toggle_bookmark','program_id':layout_id ,'title':urllib .parse .quote_plus (full_title ),'subscribed':'1'})
                        unmark_url =self .build_url ({'mode':'toggle_bookmark','program_id':layout_id ,'title':urllib .parse .quote_plus (full_title ),'subscribed':'0'})
                        li .addContextMenuItems ([
                        ('Merken',f'RunPlugin({bookmark_url })'),
                        ('Nicht mehr merken',f'RunPlugin({unmark_url })'),
                        ])
                        xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
                    return True 

                elif layout_type in ('folder','serie','season'):
                    url =self .build_url ({
                    'mode':'show_folder',
                    'folder_id':layout_id ,
                    'seo':vl .get ('seo',''),
                    })
                    li =xbmcgui .ListItem (label =full_title )
                    li .setProperty ('IsPlayable','false')
                    if thumb :
                        li .setArt ({'thumb':thumb ,'fanart':fanart })
                    li .setInfo ('video',{'title':full_title ,'plot':description })
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
                    return True 

                elif layout_type =='alias':
                    url =self .build_url ({'mode':'show_alias','alias':layout_id })
                    li =xbmcgui .ListItem (label =full_title )
                    li .setProperty ('IsPlayable','false')
                    if thumb :
                        li .setArt ({'thumb':thumb })
                    li .setInfo ('video',{'title':full_title })
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
                    return True 

                elif layout_type in ('live','channel'):
                    live_label =f'[COLOR gold][B]LIVE - {full_title }[/B][/COLOR]'
                    url =self .build_url ({
                    'mode':'play_live',
                    'channel_id':layout_id ,
                    'title':urllib .parse .quote_plus (full_title ),
                    })
                    li =xbmcgui .ListItem (label =live_label )
                    li .setProperty ('IsPlayable','true')
                    local_img =self ._channel_image (layout_id )
                    art_img =local_img or thumb 
                    if art_img :
                        li .setArt ({'thumb':art_img ,'icon':art_img ,'clearlogo':art_img })
                    li .setInfo ('video',{'title':'\u0001'+live_label })
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,False )
                    return True 

                else :
                    _log (f'Unknown layout_type={layout_type!r} id={layout_id }')
                    url =self .build_url ({'mode':'show_program','program_id':layout_id })
                    li =xbmcgui .ListItem (label =full_title )
                    li .setProperty ('IsPlayable','false')
                    if thumb :
                        li .setArt ({'thumb':thumb ,'fanart':fanart })
                    li .setInfo ('video',{'title':full_title ,'plot':description })
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
                    return True 

            elif t_type =='app':
                va =target .get ('value_app',{})or {}
                ref =va .get ('reference','')

                if ref =='play':
                    video_obj =ic .get ('video',{})or {}
                    video_id =video_obj .get ('id','')or item .get ('ucid','')

                    if not video_id :
                        return False 

                    url =self .build_url ({
                    'mode':'play_vod',
                    'video_id':video_id ,
                    'title':urllib .parse .quote_plus (full_title ),
                    })
                    li =xbmcgui .ListItem (label =full_title )
                    li .setProperty ('IsPlayable','true')
                    if thumb :
                        li .setArt ({'thumb':thumb ,'poster':poster ,'fanart':fanart })
                    li .setInfo ('video',{
                    'title':full_title ,
                    'plot':description ,
                    'genre':extra_details ,
                    })
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,False )
                    return True 
                return False 

            elif t_type =='player':
                vp =target .get ('value_player',{})or {}
                vid =vp .get ('id','')
                content_type =vp .get ('type','vod')

                if content_type in ('live','livetv','channel','event','live_event','event_stream'):
                    live_label =f'[COLOR gold][B]LIVE - {full_title }[/B][/COLOR]'
                    url =self .build_url ({
                    'mode':'play_live',
                    'channel_id':vid ,
                    'title':urllib .parse .quote_plus (full_title ),
                    })
                    li =xbmcgui .ListItem (label =live_label )
                    li .setProperty ('IsPlayable','true')
                    local_img =self ._channel_image (vid )
                    art_img =local_img or thumb 
                    if art_img :
                        li .setArt ({'thumb':art_img ,'icon':art_img ,'clearlogo':art_img })
                    li .setInfo ('video',{'title':'\u0001'+live_label })
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,False )
                else :
                    url =self .build_url ({
                    'mode':'play_vod',
                    'video_id':vid ,
                    'title':urllib .parse .quote_plus (full_title ),
                    })
                    li =xbmcgui .ListItem (label =full_title )
                    li .setProperty ('IsPlayable','true')
                    if thumb :
                        li .setArt ({'thumb':thumb ,'poster':poster ,'fanart':fanart })
                    li .setInfo ('video',{'title':full_title ,'plot':description })
                    xbmcplugin .addDirectoryItem (self .handle ,url ,li ,False )
                return True 

            else :
                return False 

        except Exception as e :
            _log (f'_add_item error: {e }')
            import traceback 
            _log (traceback .format_exc ())
            return False 

    def _channel_image (self ,channel_slug ):
        import os 
        import xbmcaddon 
        import xbmcvfs 
        _addon_path =xbmcvfs .translatePath (xbmcaddon .Addon ().getAddonInfo ('path'))
        raw =(channel_slug or '').lower ()
        slug =raw .replace ('rtlde_','')
        rel =CHANNEL_IMAGES .get (slug ,'')
        if rel :
            return os .path .join (_addon_path ,'resources','media',rel )
        return ''

    def _create_live_listitem (self ,item ):
        try :
            ic =item .get ('itemContent',{})
            title =ic .get ('title','')or ic .get ('label','')
            thumb =_image_url (ic .get ('image',{}))

            action =ic .get ('action',{})or {}
            target =action .get ('target',{})or {}
            t_type =target .get ('type','')

            if t_type =='lock':
                inner =target .get ('value_lock',{})or {}

                while inner .get ('originalTarget',{}).get ('type','')=='lock':
                    inner =inner .get ('originalTarget',{}).get ('value_lock',{})or {}
                orig =inner .get ('originalTarget',{})or {}
                if orig .get ('type','')in ('layout','player'):
                    target =orig 
                    t_type =orig .get ('type','')

            channel_slug =''
            content_id =''

            if t_type =='layout':
                vl =target .get ('value_layout',{})
                raw_id =vl .get ('id','')
                channel_slug =raw_id .replace ('rtlde_','')
            elif t_type =='player':
                vp =target .get ('value_player',{})
                raw_id =vp .get ('id','')
                channel_slug =raw_id .replace ('rtlde_','')
            else :
                video =ic .get ('video',{})
                if video :
                    content_id =video .get ('id','')
                    channel_slug =content_id .replace ('rtlde_','')

            if not channel_slug and not content_id :
                return None 

            local_img =self ._channel_image (channel_slug or content_id )
            art_img =local_img or thumb 

            li =xbmcgui .ListItem (label =title or channel_slug )
            li .setProperty ('IsPlayable','true')
            if art_img :
                li .setArt ({'thumb':art_img ,'icon':art_img ,'clearlogo':art_img })
            li .setInfo ('video',{'title':title ,'mediatype':'video'})

            url =self .build_url ({
            'mode':'play_live',
            'channel_id':channel_slug ,
            'content_id':content_id ,
            'title':urllib .parse .quote_plus (title or channel_slug ),
            })

            xbmcplugin .addDirectoryItem (self .handle ,url ,li ,False )
            return li 

        except Exception as e :
            _log (f'_create_live_listitem error: {e }')
            return None 

    def _create_live_listitem_epg (self ,item ):
        try:
            ic = item.get ('itemContent',{})

            action = ic.get ('action',{}) or {}
            target = action.get ('target',{}) or {}
            t_type = target.get ('type','')

            if t_type == 'lock':
                inner = target.get ('value_lock',{}) or {}
                while inner.get ('originalTarget',{}).get ('type','') == 'lock':
                    inner = inner.get ('originalTarget',{}).get ('value_lock',{}) or {}
                orig = inner.get ('originalTarget',{}) or {}
                if orig.get ('type','') in ('layout','player'):
                    target = orig
                    t_type = orig.get ('type','')

            channel_slug = ''
            if t_type == 'layout':
                raw_id = target.get ('value_layout',{}).get ('id','')
                channel_slug = raw_id.replace ('rtlde_','')
            elif t_type == 'player':
                raw_id = target.get ('value_player',{}).get ('id','')
                channel_slug = raw_id.replace ('rtlde_','')

            if not channel_slug:
                return None

            channel = ic.get ('channel',{}) or {}
            channel_title = channel.get ('title','') or channel_slug.upper ()
            channel_img_data = channel.get ('image',{}) or {}
            channel_logo = _image_url (channel_img_data,width=200,height=200,preferred_ratio='1:1')

            local_img = self._channel_image (channel_slug)
            channel_art = local_img or channel_logo

            epgbox = ic.get ('epgBox',[]) or []
            current,next_ep = self._epg_current_program (epgbox)

            if current:
                cur_title = current.get ('title','')
                cur_extra = current.get ('extraTitle','')
                cur_start = current.get ('start',{}).get ('title','')
                cur_end = current.get ('end',{}).get ('title','')
                cur_end_date = current.get ('end',{}).get ('date','')

                if cur_extra:
                    program_label = f'{cur_title} - {cur_extra}'
                else:
                    program_label = cur_title

                restzeit_str = ''
                try:
                    from datetime import datetime as _dt, timezone as _tz
                    import re as _re
                    end_str_utc = _re.sub (r'([+-]\d{2}):(\d{2})$',lambda m:f'{m.group(1)}{m.group(2)}',cur_end_date)
                    end_ts = _dt.strptime (end_str_utc,'%Y-%m-%dT%H:%M:%S%z').timestamp ()
                    import time as _time
                    remaining = int (end_ts - _time.time ())
                    if remaining > 0:
                        h,r = divmod (remaining,3600)
                        m,s = divmod (r,60)
                        if h:
                            restzeit_str = f'noch {h}h {m:02d}min'
                        else:
                            restzeit_str = f'noch {m}min'
                except Exception:
                    pass

                time_label = f'[{cur_start}-{cur_end}]' if cur_start and cur_end else ''

                nxt_title = ''
                nxt_extra = ''
                nxt_start = ''
                nxt_end = ''
                nxt_label = ''
                nxt_time_label = ''
                if next_ep:
                    nxt_title = next_ep.get ('title','')
                    nxt_extra = next_ep.get ('extraTitle','')
                    nxt_start = next_ep.get ('start',{}).get ('title','')
                    nxt_end = next_ep.get ('end',{}).get ('title','')
                    nxt_label = f'{nxt_title} - {nxt_extra}' if nxt_extra else nxt_title
                    nxt_time_label = f'[{nxt_start}-{nxt_end}]' if nxt_start and nxt_end else ''

                rest_suffix = f'  ({restzeit_str})' if restzeit_str else ''
                label = f'[B]{channel_title}[/B]  {time_label}  {program_label}{rest_suffix}'

                ep_img_id = current.get ('image',{})
                if ep_img_id:
                    thumb = _image_url (ep_img_id,width=480,height=270,preferred_ratio='16:9')
                else:
                    modal_id = (current.get ('action',{}) or {}).get ('target',{}).get ('value_modal',{}).get ('id','')
                    if modal_id:
                        thumb = self._get_epg_modal_thumb (modal_id)
                    else:
                        thumb = ''

                thumb = thumb or channel_art

                if nxt_label:
                    plot = f'Danach {nxt_time_label}: {nxt_label}'
                else:
                    plot = ''
            else:
                label = f'[B]{channel_title}[/B]'
                thumb = channel_art
                plot = channel_title

            url = self.build_url ({
                'mode':'play_live',
                'channel_id':channel_slug,
                'title':urllib.parse.quote_plus (channel_title),
            })

            li = xbmcgui.ListItem (label=label)
            li.setProperty ('IsPlayable','true')
            art = {}
            if thumb:
                art['thumb'] = thumb
                art['fanart'] = thumb
            if channel_art:
                art['icon'] = channel_art
                art['clearlogo'] = channel_art
            if art:
                li.setArt (art)
            li.setInfo ('video',{
                'title':label,
                'plot':plot,
                'mediatype':'video',
            })

            xbmcplugin.addDirectoryItem (self.handle,url,li,False)
            return li

        except Exception as e:
            _log (f'_create_live_listitem_epg error: {e}')
            import traceback
            _log (traceback.format_exc ())
            return None

    def _get_epg_modal_thumb (self ,modal_id ):
        try:
            data = self.api.get_epg_modal (modal_id)
            if not data:
                return ''
            for block in data.get ('blocks',[]):
                for item in block.get ('content',{}).get ('items',[]):
                    ic = item.get ('itemContent',{})
                    img = ic.get ('image',{})
                    if img:
                        return _image_url (img,width=480,height=270,preferred_ratio='16:9')
            return ''
        except Exception as e:
            _log (f'_get_epg_modal_thumb error: {e}')
            return ''

    def _add_next_page (self ,folder_id ,block_id ,next_page ):
        li =xbmcgui .ListItem (label ='[COLOR yellow]>> Mehr laden >>[/COLOR]')
        url =self .build_url ({
        'mode':'show_folder',
        'folder_id':folder_id ,
        'page':next_page ,
        })
        xbmcplugin .addDirectoryItem (self .handle ,url ,li ,True )
