# -*- coding: utf-8 -*-
# Express.de News & Videos
# IT('s) Possible
# 2026.10.06
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import html
import json
import re
import sys
import urllib.parse

from bs4 import BeautifulSoup
import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])
ADDON = xbmcaddon.Addon()
ADDON_ICON = ADDON.getAddonInfo("icon")

BASE_URL = "https://www.express.de"
PER_PAGE = 32

FRONT_CHECK_HASH = "021a356684d118a91b7a076a8ade63ea8f04d583"


def get_dynamic_mix_hash():
  try:
    response = SESSION.get(BASE_URL, timeout=8)
    if response.status_code == 200:
      html_content = response.text
      match = re.search(r"mixes/([a-fA-F0-9]{40})/", html_content)
      if match:
        found_hash = match.group(1)
        xbmc.log(
            f"EXPRESS CHECK HASH DYNAMIC FOUND: {found_hash}", xbmc.LOGINFO
        )
        return found_hash
  except Exception as e:
    xbmc.log(f"EXPRESS CHECK HASH GENERATOR ERROR: {e}", xbmc.LOGWARNING)

  xbmc.log(
      f"EXPRESS CHECK HASH: Using fallback hash: {FRONT_CHECK_HASH}",
      xbmc.LOGWARNING,
  )
  return FRONT_CHECK_HASH


def get_dynamic_video_kategorien():
  kategorien = {
      "1": "GbzYiHVN",
      "2": "VhRaNvXL",
      "3": "mwMUstde",
      "4": "XHwP4VTw",
  }

  try:
    response = SESSION.get(BASE_URL, timeout=8)
    if response.status_code == 200:
      html_content = response.text
      matches = re.findall(r"mixes/[a-zA-Z0-9_-]+/([a-zA-Z0-9]{8})", html_content)
      for m in matches:
        if len(m) == 8 and not m.islower() and m not in kategorien.values():
          key = f"Mix_{m}"
          kategorien[key] = m
  except Exception as e:
    xbmc.log(f"EXPRESS TOKEN GENERATOR ERROR: {e}", xbmc.LOGWARNING)

  return kategorien


USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/140.0.0.0 Safari/537.36"
)

HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "de-DE,de;q=0.9,en;q=0.7",
    "Origin": "https://www.express.de",
    "Referer": "https://www.express.de/",
}

SESSION = requests.Session()
SESSION.headers.update(HEADERS)

CATEGORIES = {
    "Startseite": "https://www.express.de/",
    "Aktuelle Videos": "VIDEO_TOKEN:All",
    "1. FC Köln": "https://www.express.de/sport/fussball/1-fc-koeln",
    "Köln": "https://www.express.de/koeln",
    "Sport": "https://www.express.de/sport",
    "Promi & Show": "https://www.express.de/promi-und-show",
    "NRW": "https://www.express.de/nrw",
    "Politik & Wirtschaft": "https://www.express.de/politik-und-wirtschaft",
    "Panorama": "https://www.express.de/panorama",
}

CATEGORY_DESCRIPTIONS = {
    "Startseite": (
        "Die wichtigsten Nachrichten und Top-Themen des Tages auf EXPRESS.de."
    ),
    "Aktuelle Videos": (
        "Alle aktuellen Video-Beiträge und Streams von EXPRESS.de gebündelt in"
        " einer Liste."
    ),
    "1. FC Köln": (
        "Alles rund um den 1. FC Köln: News, Transfers, Spielberichte und"
        " Hintergründe."
    ),
    "Köln": (
        "Lokale Nachrichten, Veedels-Geschichten und Aktuelles aus Köln und"
        " Umgebung."
    ),
    "Sport": (
        "Sportnachrichten, Fußball, Handball, Eishockey und mehr aus der Region"
        " und der Welt."
    ),
    "Promi & Show": (
        "Stars, Sternchen, Klatsch, TV-Formate und Unterhaltung aus der"
        " Promiwelt."
    ),
    "NRW": (
        "Aktuelle Nachrichten und Blaulicht-Meldungen aus"
        " Nordrhein-Westfalen."
    ),
    "Politik & Wirtschaft": (
        "Hintergründe, Analysen und News aus Politik, Wirtschaft und"
        " Gesellschaft."
    ),
    "Panorama": (
        "Spannende, kuriose und weltweite Geschichten im Panorama."
    ),
}


def build_url(query):
  return sys.argv[0] + "?" + urllib.parse.urlencode(query)


def absolute_url(url):
  if not url:
    return ""
  url = html.unescape(str(url).strip())
  if url.startswith("//"):
    return "https:" + url
  if url.startswith("/"):
    return BASE_URL + url
  if url.startswith("http://") or url.startswith("https://"):
    return url
  return urllib.parse.urljoin(BASE_URL + "/", url)


def clean_text(value):
  if value is None:
    return ""
  value = html.unescape(str(value))
  value = re.sub(r"\s+", " ", value)
  return value.strip()


def format_pub_date(raw_date):
  if not raw_date:
    return "Unbekanntes Datum"
  try:
    dt = datetime.fromisoformat(raw_date.replace("Z", "+00:00"))
    return dt.strftime("%d.%m.%Y, %H:%M Uhr")
  except Exception:
    clean_date = re.sub(r"(\.\d+)?([+-]\d{2}:\d{2}|Z)$", "", raw_date)
    return clean_date.replace("T", " ")


def add_fallback_item(message="Nicht verfügbar"):
  li = xbmcgui.ListItem(label=message)
  li.setArt({"icon": ADDON_ICON, "thumb": ADDON_ICON})
  try:
    tag = li.getVideoInfoTag()
    tag.setTitle(message)
    tag.setPlot("Inhalte nicht verfügbar.")
  except Exception:
    li.setInfo("video", {"title": message, "plot": "Inhalte nicht verfügbar."})
  xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)


def show_categories():
  for title, cat_url in CATEGORIES.items():
    if cat_url.startswith("VIDEO_TOKEN:"):
      genor_key = cat_url.split("VIDEO_TOKEN:", 1)[1]
      url = build_url({"mode": "videos", "filter": genor_key, "page": 1})
    else:
      url = build_url(
          {"mode": "list", "url": cat_url, "title": title, "page": 1}
      )

    li = xbmcgui.ListItem(label=title)
    li.setArt({"icon": ADDON_ICON, "thumb": ADDON_ICON})
    plot = CATEGORY_DESCRIPTIONS.get(
        title, f"Aktuelle Artikel aus der Rubrik {title}."
    )
    try:
      tag = li.getVideoInfoTag()
      tag.setTitle(title)
      tag.setPlot(plot)
    except Exception:
      li.setInfo("video", {"title": title, "plot": plot})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

  xbmcplugin.endOfDirectory(HANDLE)


def is_valid_article(url, title):
  if not url or not title:
    return False

  parsed = urllib.parse.urlparse(url)
  path = parsed.path
  match = re.search(r"-(\d+)$", path)
  if not match:
    return False

  if len(title) < 12 or len(title) > 140:
    return False

  if re.match(r"^\d+\s+[A-Za-zÄÖÜäöüß]+", title):
    return False

  lower_title = title.lower()
  blocked_terms = [
      "stimmen zum spiel",
      "spieltagstipp",
      "kommentare",
      "startseite",
      "mehr anzeigen",
      "impressum",
      "datenschutz",
      "kontakt",
      "aktuelle meldungen",
      "verkehr",
  ]
  if any(term in lower_title for term in blocked_terms):
    return False

  return True


def fetch_article_date(article_url):
  try:
    response = SESSION.get(article_url, headers=HEADERS, timeout=10)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")

    time_tag = soup.find("time")
    if time_tag:
      return clean_text(time_tag.get_text(" ", strip=True))

    meta_date = soup.find("meta", property="article:published_time") or soup.find(
        "meta", attrs={"name": "pubdate"}
    )
    if meta_date and meta_date.get("content"):
      return format_pub_date(meta_date.get("content"))
  except Exception:
    pass
  return ""


def fetch_article_dates(article_urls):
  results = {}
  with ThreadPoolExecutor(max_workers=2) as executor:
    futures = {
        executor.submit(fetch_article_date, url): url for url in article_urls
    }
    for future in futures:
      url = futures[future]
      try:
        results[url] = future.result()
      except Exception:
        results[url] = ""
  return results


def parse_articles_from_page(cat_url):
  try:
    response = SESSION.get(cat_url, headers=HEADERS, timeout=20)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")

    main_content = soup.find("main") or soup.find(
        "div", class_=re.compile(r"content|main|article-list", re.I)
    ) or soup

    for noise in main_content.find_all(["nav", "header", "footer", "aside"]):
      noise.decompose()

    parsed_cat = urllib.parse.urlparse(cat_url)
    cat_path = parsed_cat.path.rstrip("/").lower()
    is_startseite = cat_path == "" or cat_path == "/"

    articles = []
    seen = set()

    for a in main_content.find_all("a", href=True):
      href = a["href"]
      if "#" in href:
        continue

      url = absolute_url(href)
      if not url or not url.startswith(BASE_URL):
        continue

      parsed_url = urllib.parse.urlparse(url)
      article_path = parsed_url.path.lower()

      if not is_startseite and cat_path:
        if not article_path.startswith(cat_path):
          continue

      title = ""
      heading = a.find(["h2", "h3", "h4"])
      if heading:
        title = clean_text(heading.get_text(" ", strip=True))
      else:
        raw_text = clean_text(a.get_text(" ", strip=True))
        half = len(raw_text) // 2
        if (
            len(raw_text) > 20
            and len(raw_text) % 2 == 0
            and raw_text[:half] == raw_text[half:]
        ):
          title = raw_text[:half].strip()
        else:
          title = raw_text

      if not is_valid_article(url, title):
        continue

      key = article_path
      if key in seen:
        continue
      seen.add(key)

      id_match = re.search(r"-(\d+)$", article_path)
      article_id = int(id_match.group(1)) if id_match else 0

      thumb = ADDON_ICON
      img = a.find("img") or (a.parent and a.parent.find("img"))
      if img:
        for attr in ("src", "data-src", "data-original", "data-lazy-src"):
          val = img.get(attr)
          if val and absolute_url(val):
            thumb = absolute_url(val)
            break

      plot_text = f"Artikel auf EXPRESS: {title}"
      container = a.find_parent(["article", "div", "li"])
      if container:
        p = container.find("p")
        if p:
          p_text = clean_text(p.get_text(" ", strip=True))
          if len(p_text) > 20:
            plot_text = p_text

      articles.append({
          "title": title,
          "url": url,
          "thumb": thumb,
          "plot_text": plot_text,
          "id": article_id,
      })

    if is_startseite:
      articles.sort(key=lambda x: x["id"], reverse=True)

    return articles
  except Exception as e:
    xbmc.log(f"EXPRESS PARSE ERROR: {e}", xbmc.LOGERROR)
    return []


def list_articles(cat_url, page=1):
  try:
    page = int(page)
    cat_url = urllib.parse.unquote(cat_url)
    articles = parse_articles_from_page(cat_url)

    start_idx = (page - 1) * PER_PAGE
    end_idx = start_idx + PER_PAGE
    page_articles = articles[start_idx:end_idx]

    if not page_articles:
      add_fallback_item("Nicht verfügbar")
      xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
      return

    article_urls = [article["url"] for article in page_articles]
    article_dates = fetch_article_dates(article_urls)

    for article in page_articles:
      title = article["title"]
      article_url = article["url"]
      thumb = article["thumb"]
      plot_text = article["plot_text"]

      date_str = article_dates.get(article_url, "")
      if date_str:
        plot = f"[COLOR gold]Veröffentlicht am: {date_str}[/COLOR]\n\n{plot_text}"
      else:
        plot = plot_text

      url = build_url({"mode": "article", "title": title, "link": article_url})
      li = xbmcgui.ListItem(label=title)
      li.setArt(
          {"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": thumb}
      )

      try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        tag.setPlot(plot)
        tag.setStudio("EXPRESS")
      except Exception:
        li.setInfo(
            "video", {"title": title, "plot": plot, "studio": "EXPRESS"}
        )

      xbmcplugin.addDirectoryItem(
          handle=HANDLE, url=url, listitem=li, isFolder=False
      )

    if len(articles) > end_idx:
      next_url = build_url({
          "mode": "list",
          "url": cat_url,
          "title": "Nächste Seite",
          "page": page + 1,
      })
      next_li = xbmcgui.ListItem(label="Nächste Seite >>")
      next_li.setArt({"icon": ADDON_ICON, "thumb": ADDON_ICON})
      try:
        tag = next_li.getVideoInfoTag()
        tag.setTitle("Nächste Seite")
        tag.setPlot("Weitere Artikel in dieser Rubrik laden.")
      except Exception:
        next_li.setInfo(
            "video",
            {
                "title": "Nächste Seite",
                "plot": "Weitere Artikel in dieser Rubrik laden.",
            },
        )
      xbmcplugin.addDirectoryItem(
          handle=HANDLE, url=next_url, listitem=next_li, isFolder=True
      )

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
  except Exception as e:
    xbmc.log(f"EXPRESS LIST ERROR: {e}", xbmc.LOGERROR)
    add_fallback_item("Nicht verfügbar")
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)


def extract_items_from_json(data):
  if isinstance(data, list):
    return data
  if isinstance(data, dict):
    for key in ["items", "results", "videos", "data", "payload", "mixes"]:
      if key in data and isinstance(data[key], list):
        return data[key]
    for k, v in data.items():
      if isinstance(v, list) and len(v) > 0:
        return v
    return [data]
  return []


def select_best_hd_stream(streams):
  if not streams:
    return None

  def score_stream(url):
    u = url.lower()
    score = 0
    if ".m3u8" in u:
      score += 15
    if any(k in u for k in ["hd", "1080", "720", "hq", "high"]):
      score += 10
    if any(k in u for k in ["sd", "480", "360", "lq", "low"]):
      score -= 10
    return score

  sorted_streams = sorted(streams, key=score_stream, reverse=True)
  return sorted_streams[0]


def list_express_videos(cat_filter="All", page=1):
  try:
    page = int(page)
    API_LIMIT = 88
    global_start = (page - 1) * PER_PAGE
    api_offset = (global_start // API_LIMIT) * API_LIMIT

    all_videos = []
    seen_video_ids = set()
    seen_base_streams = set()

    current_mix_hash = get_dynamic_mix_hash()
    VIDEO_TOKENS = get_dynamic_video_kategorien()

    kategorien_to_process = VIDEO_TOKENS

    for cat_name, genor in kategorien_to_process.items():
      mix_url = f"https://media-api-prod.greenvideo.io/api/v1/mixes/{current_mix_hash}/{genor}?ncr=1&resolve=true&limit={API_LIMIT}&offset={api_offset}"
      try:
        res = SESSION.get(mix_url, headers=HEADERS, timeout=15)
        if res.status_code != 200:
          continue
        data = res.json()
        items = extract_items_from_json(data)

        for item in items:
          if not isinstance(item, dict):
            continue

          title = "Unbekannter Titel"
          for key in ["title", "headline", "name", "caption"]:
            if key in item and item[key]:
              title = str(item[key]).strip()
              break

          published = ""
          for key in ["publishedAt", "published", "date", "createdAt", "pubDate"]:
            if key in item and item[key]:
              published = str(item[key]).strip()
              break

          vid_id = None
          for key in ["id", "videoId", "uuid", "guid"]:
            if key in item and item[key]:
              vid_id = str(item[key])
              break

          if vid_id and vid_id in seen_video_ids:
            continue

          item_str = json.dumps(item)
          mp4s = re.findall(r'https://[^\s"\'<>]*?\.mp4[^\s"\'<>]*', item_str)
          m3u8s = re.findall(r'https://[^\s"\'<>]*?\.m3u8[^\s"\'<>]*', item_str)
          streams = list(set(mp4s + m3u8s))

          valid_streams = [
              s
              for s in streams
              if "video-websearch-indexing.mes.glomex.cloud" not in s
          ]

          if valid_streams:
            best_stream = select_best_hd_stream(valid_streams)
            base_stream = re.sub(
                r"(_(hd|sd|hq|lq)|\b(1080|720|480|360)p?)\b",
                "",
                best_stream,
                flags=re.IGNORECASE,
            )

            if base_stream in seen_base_streams:
              continue

            seen_base_streams.add(base_stream)
            if vid_id:
              seen_video_ids.add(vid_id)

            all_videos.append({
                "title": title,
                "published_raw": published,
                "published_formatted": format_pub_date(published),
                "stream": best_stream,
                "category": cat_name,
            })
      except Exception as e:
        xbmc.log(
            f"EXPRESS VIDEO TOKEN FETCH ERROR ({cat_name}): {e}",
            xbmc.LOGERROR,
        )

    def sort_key(v):
      try:
        return datetime.fromisoformat(v["published_raw"].replace("Z", "+00:00"))
      except Exception:
        return datetime.min

    all_videos.sort(key=sort_key, reverse=True)

    local_start = global_start % API_LIMIT
    local_end = local_start + PER_PAGE
    page_items = all_videos[local_start:local_end]

    xbmcplugin.setContent(HANDLE, "videos")

    if not page_items:
      add_fallback_item("Nicht verfügbar")
      xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
      return

    for item in page_items:
      url = build_url({"mode": "play_direct_stream", "link": item["stream"]})

      title = item["title"]
      pub_str = item["published_formatted"]
      plot = f"[COLOR orange]Veröffentlicht am: {pub_str}[/COLOR]\n\n{title}"

      li = xbmcgui.ListItem(label=title)
      li.setArt({
          "icon": ADDON_ICON,
          "thumb": ADDON_ICON,
          "poster": ADDON_ICON,
          "fanart": ADDON_ICON,
      })
      li.setProperty("IsPlayable", "true")

      try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        tag.setPlot(plot)
        tag.setMediaType("video")
        tag.setStudio("EXPRESS Video")
      except Exception:
        li.setInfo(
            "video",
            {
                "title": title,
                "plot": plot,
                "mediatype": "video",
                "studio": "EXPRESS Video",
            },
        )

      xbmcplugin.addDirectoryItem(
          handle=HANDLE, url=url, listitem=li, isFolder=False
      )

    if len(page_items) == PER_PAGE or (len(all_videos) > local_end):
      next_url = build_url({
          "mode": "videos",
          "filter": cat_filter,
          "title": "Nächste Seite",
          "page": page + 1,
      })
      next_li = xbmcgui.ListItem(label="Nächste Seite >>")
      next_li.setArt({"icon": ADDON_ICON, "thumb": ADDON_ICON})
      try:
        tag = next_li.getVideoInfoTag()
        tag.setTitle("Nächste Seite")
        tag.setPlot("Weitere Videos laden.")
      except Exception:
        next_li.setInfo(
            "video",
            {"title": "Nächste Seite", "plot": "Weitere Videos laden."},
        )
      xbmcplugin.addDirectoryItem(
          handle=HANDLE, url=next_url, listitem=next_li, isFolder=True
      )

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)
  except Exception as e:
    xbmc.log(f"EXPRESS VIDEO LIST ERROR: {e}", xbmc.LOGERROR)
    add_fallback_item("Nicht verfügbar")
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)


def play_direct_stream(stream_url):
  try:
    xbmc.log(f"EXPRESS PLAY DIRECT STREAM: {stream_url}", xbmc.LOGINFO)
    play_item = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=play_item)
  except Exception as e:
    xbmc.log(f"EXPRESS PLAY DIRECT ERROR: {e}", xbmc.LOGERROR)
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def get_article_media_and_text(url):
  try:
    response = SESSION.get(url, headers=HEADERS, timeout=20)
    response.raise_for_status()
    html_text = response.text
    soup = BeautifulSoup(html_text, "html.parser")

    date_str = fetch_article_date(url)

    selectors = [
        "article p",
        ".article-body p",
        ".content p",
        "div[data-component='ArticleBody'] p",
        ".paragraph p",
    ]
    article_text = []
    for selector in selectors:
      paragraphs = soup.select(selector)
      if not paragraphs:
        continue
      for p in paragraphs:
        text = clean_text(p.get_text(" ", strip=True))
        if len(text) > 30 and text not in article_text:
          article_text.append(text)
      if article_text:
        break

    if not article_text:
      final_text = "Kein Artikeltext gefunden."
    else:
      final_text = "\n\n".join(article_text)
      if date_str:
        final_text = (
            f"[COLOR gold]Veröffentlicht am: {date_str}[/COLOR]\n\n"
            + final_text
        )

    main_image = ""
    og_img = soup.find("meta", property="og:image")
    if og_img and og_img.get("content"):
      main_image = absolute_url(og_img.get("content"))

    if not main_image:
      for img in soup.find_all("img"):
        for attr in ("src", "data-src", "data-original", "data-lazy-src"):
          val = img.get(attr)
          if val:
            img_url = absolute_url(val)
            if img_url:
              lower_url = img_url.lower()
              if any(
                  term in lower_url
                  for term in [
                      "logo",
                      "icon",
                      "avatar",
                      "pixel",
                      "banner",
                      "tracking",
                      "placeholder",
                      "1x1",
                      "svg",
                  ]
              ):
                continue
              main_image = img_url
              break
        if main_image:
          break

    videos = []
    seen_videos = set()
    mp4s = re.findall(r'https://[^\s"\'<>]*?\.mp4[^\s"\'<>]*', html_text)
    m3u8s = re.findall(r'https://[^\s"\'<>]*?\.m3u8[^\s"\'<>]*', html_text)
    potential_streams = list(set(mp4s + m3u8s))

    for s in potential_streams:
      if "video-websearch-indexing.mes.glomex.cloud" not in s:
        best_s = select_best_hd_stream([s])
        if best_s and best_s not in seen_videos:
          seen_videos.add(best_s)
          videos.append(best_s)

    return final_text, main_image, videos
  except Exception as e:
    xbmc.log(f"EXPRESS ARTICLE MEDIA ERROR: {e}", xbmc.LOGERROR)
    return f"Fehler beim Laden:\n{e}", "", []


def show_article(title, url):
  text, main_image, videos = get_article_media_and_text(url)

  options = []
  actions = []

  if main_image:
    options.append("Hauptbild anzeigen")
    actions.append(("image", main_image))

  for i, vid_url in enumerate(videos):
    label = "Video öffnen" if len(videos) == 1 else f"Video {i+1} öffnen"
    options.append(label)
    actions.append(("video", vid_url))

  options.append("Text öffnen")
  actions.append(("text", text))

  if len(options) > 1:
    selected = xbmcgui.Dialog().select(title, options)
    if selected < 0:
      return

    action_type, action_data = actions[selected]

    if action_type == "image":
      xbmc.executebuiltin(f'ShowPicture("{action_data}")')

    elif action_type == "video":
      xbmc.Player().play(action_data)

    elif action_type == "text":
      xbmcgui.Dialog().textviewer(title, text)
  else:
    xbmcgui.Dialog().textviewer(title, text)


def router(paramstring):
  params = dict(urllib.parse.parse_qsl(paramstring))
  mode = params.get("mode")

  if mode is None:
    show_categories()
  elif mode == "list":
    list_articles(params.get("url", ""), int(params.get("page", 1)))
  elif mode == "videos":
    list_express_videos(params.get("filter", "All"), int(params.get("page", 1)))
  elif mode == "play_direct_stream":
    play_direct_stream(params.get("link", ""))
  elif mode == "article":
    show_article(params.get("title", "Artikel"), params.get("link", ""))
  else:
    show_categories()


if __name__ == "__main__":
  try:
    paramstring = sys.argv[2].lstrip("?") if len(sys.argv) > 2 else ""
    router(paramstring)
  except Exception as e:
    xbmc.log(f"EXPRESS Addon FATAL ERROR: {e}", xbmc.LOGERROR)
    try:
      xbmcgui.Dialog().notification(
          "EXPRESS",
          f"Fehler: {str(e)[:100]}",
          xbmcgui.NOTIFICATION_ERROR,
          5000,
      )
    except Exception:
      pass
