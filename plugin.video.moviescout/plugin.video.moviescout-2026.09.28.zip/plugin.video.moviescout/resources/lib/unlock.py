import os
import xbmc
import xbmcaddon
import xbmcvfs

_SCRIPT_ID = 'script.unlock.moviescout'


def _installed():
    return xbmc.getCondVisibility('System.HasAddon(%s)' % _SCRIPT_ID)


def _flag_path(addon):
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    return os.path.join(profile, '.disclaimer_asked')


def check():
    try:
        addon = xbmcaddon.Addon()
        flag = _flag_path(addon)
        allowed = addon.getSetting('scraper.allow_unlicensed') == 'true'
        if not _installed():
            if os.path.exists(flag):
                os.remove(flag)
            if allowed:
                addon.setSetting('scraper.allow_unlicensed', 'false')
            return
        if allowed or os.path.exists(flag):
            return
        xbmc.executebuiltin('RunScript(%s)' % _SCRIPT_ID)
    except Exception:
        pass
