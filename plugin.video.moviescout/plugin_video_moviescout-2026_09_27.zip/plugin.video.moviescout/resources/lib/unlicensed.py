import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs


def _addon():
    return xbmcaddon.Addon()


def _marker_path():
    profile = xbmcvfs.translatePath(_addon().getAddonInfo('profile'))
    return os.path.join(profile, '.disclaimer_asked')


def _allow_unlicensed():
    return _addon().getSetting('scraper.allow_unlicensed') == 'true'


def _disclaimer_asked():
    path = _marker_path()
    if not os.path.exists(path):
        return False
    try:
        data = {}
        with open(path, 'r') as f:
            for line in f:
                if '=' in line:
                    k, v = line.strip().split('=', 1)
                    data[k] = v
        current = 'true' if _allow_unlicensed() else 'false'
        if data.get('allow') != current:
            os.remove(path)
            return False
    except Exception:
        return False
    return True


def _set_allow(val):
    _addon().setSetting('scraper.allow_unlicensed', 'true' if val else 'false')


def _set_asked(val, allow_val=None, decision=None):
    path = _marker_path()
    if val:
        try:
            profile = os.path.dirname(path)
            if not os.path.exists(profile):
                os.makedirs(profile)
            state = allow_val if allow_val is not None else ('true' if _allow_unlicensed() else 'false')
            with open(path, 'w') as f:
                f.write('allow=' + state + '\n')
                f.write('decision=' + (decision or 'unknown') + '\n')
        except Exception:
            pass
    else:
        try:
            os.remove(path)
        except Exception:
            pass


def _addon_name():
    return _addon().getAddonInfo('name')


def _is_german():
    lang = xbmc.getInfoLabel('System.Language').lower()
    return 'german' in lang or 'deutsch' in lang or 'austria' in lang or 'oesterreich' in lang


def check_disclaimer_on_startup():
    if _allow_unlicensed():
        return
    if _disclaimer_asked():
        return
    _show_disclaimer()


def _show_disclaimer():
    german = _is_german()
    if german:
        title = 'Rechtlicher Hinweis'
        agree = 'Einverstanden'
        decline = 'Ablehnen'
        msg = (
            'RECHTLICHER HINWEIS\n\n'
            'Dieses Addon kann Streams von nicht lizenzierten Quellen laden.\n'
            'Dies kann in deinem Land illegal sein.\n\n'
            'Der Ersteller dieses Addons uebernimmt KEINE Haftung.\n\n'
            'Mit Einverstanden bestatigst du:\n'
            '- Du kennst die Rechtslage in deinem Land\n'
            '- Du traegst die volle Verantwortung\n\n'
            'Moechtest du fortfahren?'
        )
    else:
        title = 'Legal Disclaimer'
        agree = 'I Agree'
        decline = 'Decline'
        msg = (
            'LEGAL DISCLAIMER\n\n'
            'This addon may load streams from sources that are NOT licensed or authorized.\n'
            'Accessing unlicensed content may be illegal in your country.\n\n'
            'The creator of this addon does NOT endorse or take responsibility for unlicensed content.\n\n'
            'By clicking I Agree you confirm that:\n'
            '- You are aware of the legal situation in your country\n'
            '- You accept full personal responsibility\n'
            '- The addon creator bears no liability\n\n'
            'Do you agree and wish to continue?'
        )

    result = xbmcgui.Dialog().yesno(
        _addon_name() + ' - ' + title,
        msg,
        nolabel=decline,
        yeslabel=agree
    )

    if result:
        if german:
            confirm_title = 'Bitte bestätigen'
            confirm_msg = (
                'Sie haben "[B]Einverstanden[/B]" ausgewählt,\n'
                'auch nicht legale Streams anzuzeigen.\n\n'
                'Bitte bestätigen.'
            )
            confirm_yes = 'Ja, ich bestätige'
            confirm_no = 'Nein, nur Legales'
        else:
            confirm_title = 'Please Confirm'
            confirm_msg = (
                'You have selected "[B]I Agree[/B]",\n'
                'including non-legal streams.\n\n'
                'Please confirm.'
            )
            confirm_yes = 'Yes, I confirm'
            confirm_no = 'No, legal only'

        confirmed = xbmcgui.Dialog().yesno(
            _addon_name() + ' - ' + confirm_title,
            confirm_msg,
            nolabel=confirm_no,
            yeslabel=confirm_yes
        )

        if confirmed:
            _set_allow(True)
            _set_asked(True, 'true', 'agreed')
        else:
            _set_allow(False)
            _set_asked(True, 'false', 'legal_only')
    else:
        _set_allow(False)
        _set_asked(True, 'false', 'declined')


def is_unlicensed_allowed():
    return _allow_unlicensed()


def filter_scrapers_by_license(scraper_modules):
    if _allow_unlicensed():
        return list(scraper_modules)
    result = []
    for m in scraper_modules:
        if getattr(m, 'STREAMLG', 'LG1') != 'LG1':
            result.append(m)
    return result


def filter_scraper_entries_by_license(scraper_entries):
    if _allow_unlicensed():
        return list(scraper_entries)
    result = []
    for entry in scraper_entries:
        if isinstance(entry, tuple):
            s, m = entry
            if getattr(m, 'STREAMLG', 'LG1') != 'LG1':
                result.append(entry)
        else:
            if getattr(entry, 'STREAMLG', 'LG1') != 'LG1':
                result.append(entry)
    return result
