import time
from resources.lib import log, multiquest
from resources.lib.control import getSetting

_KEY_INTERNAL = '86dd18b04874d9c94afadde7993d94e3'
_BASE = 'https://api.themoviedb.org/3'
_IMG  = 'https://image.tmdb.org/t/p/w500'
_IMG_FANART = 'https://image.tmdb.org/t/p/w1280'
_LANG = 'de-DE'

_CACHE     = {}
_CACHE_TTL = 3600

_cached_key    = None
_cached_key_ts = 0
_KEY_TTL       = 300


def _key():
    global _cached_key, _cached_key_ts
    if _cached_key and time.time() - _cached_key_ts < _KEY_TTL:
        return _cached_key
    _cached_key    = getSetting('tmdb.api_key').strip() or _KEY_INTERNAL
    _cached_key_ts = time.time()
    return _cached_key


def _get(endpoint, params=None):
    cache_key = (endpoint, tuple(sorted((params or {}).items())))
    entry = _CACHE.get(cache_key)
    if entry:
        data, ts = entry
        if time.time() - ts < _CACHE_TTL:
            return data
    p = {'api_key': _key(), 'language': _LANG}
    if params:
        p.update(params)
    try:
        r = multiquest.get(_BASE + endpoint, params=p, timeout=10)
        r.raise_for_status()
        data = r.json()
        _CACHE[cache_key] = (data, time.time())
        return data
    except Exception:
        log.error()
        return {}


def _img(path, fanart=False):
    if not path:
        return ''
    return (_IMG_FANART if fanart else _IMG) + path


def _sorted_aliases(d):
    titles = d.get('alternative_titles', {}).get('titles', [])
    orig = d.get('original_title', '')
    de   = [a['title'] for a in titles if a.get('iso_3166_1', '').upper() == 'DE']
    en   = [a['title'] for a in titles if a.get('iso_3166_1', '').upper() in ('US', 'GB')]
    rest = [a['title'] for a in titles if a.get('iso_3166_1', '').upper() not in ('DE', 'US', 'GB')]
    result = []
    seen = set()
    for t in de + en + ([orig] if orig else []) + rest:
        if t and t not in seen:
            seen.add(t)
            result.append(t)
    return result


def _format_movie(d):
    return {
        'tmdb_id':       d.get('id', ''),
        'imdb_id':       d.get('imdb_id', ''),
        'title':         d.get('title') or d.get('original_title', ''),
        'originaltitle': d.get('original_title', ''),
        'year':          int(d['release_date'][:4]) if d.get('release_date') else '',
        'premiered':     d.get('release_date', '1900-01-01'),
        'plot':          d.get('overview', ''),
        'rating':        d.get('vote_average', 0.0),
        'votes':         d.get('vote_count', 0),
        'duration':      (d.get('runtime') or 0) * 60,
        'genres':        [g['name'] for g in d.get('genres', [])],
        'studios':       [c['name'] for c in d.get('production_companies', [])],
        'directors':     [c['name'] for c in d.get('credits', {}).get('crew', []) if c.get('job') == 'Director'],
        'cast':          [{'name': a['name'], 'role': a.get('character', ''), 'order': a.get('order', 0),
                           'thumbnail': _img(a.get('profile_path'))} for a in d.get('credits', {}).get('cast', [])[:15]],
        'poster':        _img(d.get('poster_path')),
        'fanart':        _img(d.get('backdrop_path'), fanart=True),
        'mediatype':     'movie',
        'playcount':     0,
        'overlay':       6,
        'aliases':       _sorted_aliases(d),
    }


def _format_tvshow(d):
    return {
        'tmdb_id':             d.get('id', ''),
        'imdb_id':             d.get('external_ids', {}).get('imdb_id', ''),
        'tvdb_id':             d.get('external_ids', {}).get('tvdb_id', ''),
        'title':               d.get('name') or d.get('original_name', ''),
        'originaltitle':       d.get('original_name', ''),
        'tvshowtitle':         d.get('name') or d.get('original_name', ''),
        'year':                int(d['first_air_date'][:4]) if d.get('first_air_date') else '',
        'premiered':           d.get('first_air_date', '1900-01-01'),
        'plot':                d.get('overview', ''),
        'rating':              d.get('vote_average', 0.0),
        'votes':               d.get('vote_count', 0),
        'genres':              [g['name'] for g in d.get('genres', [])],
        'studios':             [c['name'] for c in d.get('networks', [])],
        'cast':                [{'name': a['name'], 'role': a.get('character', ''), 'order': a.get('order', 0),
                                 'thumbnail': _img(a.get('profile_path'))} for a in d.get('credits', {}).get('cast', [])[:15]],
        'number_of_seasons':   d.get('number_of_seasons', 0),
        'number_of_episodes':  d.get('number_of_episodes', 0),
        'poster':              _img(d.get('poster_path')),
        'fanart':              _img(d.get('backdrop_path'), fanart=True),
        'mediatype':           'tvshow',
        'playcount':           0,
        'overlay':             6,
    }


def _format_season(d, tmdb_id, tvshowtitle):
    episodes = [
        {
            'episode':   e.get('episode_number', 0),
            'season':    e.get('season_number', 0),
            'title':     e.get('name', ''),
            'plot':      e.get('overview', ''),
            'premiered': e.get('air_date', '1900-01-01'),
            'poster':    _img(e.get('still_path')),
            'rating':    e.get('vote_average', 0.0),
        }
        for e in d.get('episodes', [])
    ]
    return {
        'tmdb_id':              tmdb_id,
        'tvshowtitle':          tvshowtitle,
        'season':               d.get('season_number', 0),
        'number_of_episodes':   d.get('episode_count') or len(episodes),
        'premiered':            d.get('air_date', '1900-01-01'),
        'plot':                 d.get('overview', ''),
        'poster':               _img(d.get('poster_path')),
        'episodes':             episodes,
    }


def discover(mediatype, url_params, page=1):
    mt = 'movie' if mediatype == 'movie' else 'tv'
    if url_params == 'kino':
        data = _get('/movie/now_playing', {'page': page, 'region': 'DE'})
    elif url_params == 'popular':
        data = _get('/%s/popular' % mt, {'page': page})
    elif url_params == 'top_rated':
        data = _get('/%s/top_rated' % mt, {'page': page})
    else:
        data = _get('/discover/' + mt, {'page': page, **_parse_url_params(url_params)})
    ids = [r['id'] for r in data.get('results', [])]
    return ids, data.get('total_pages', 1)


def search(mediatype, query, page=1):
    mt = {'movie': 'movie', 'tvshow': 'tv', 'person': 'person'}.get(mediatype, 'movie')
    data = _get('/search/' + mt, {'query': query, 'page': page})
    ids  = [r['id'] for r in data.get('results', [])]
    return ids, data.get('total_pages', 1)


def get_movie(tmdb_id, full=False):
    params = {'append_to_response': 'credits,alternative_titles'} if full else {'append_to_response': 'alternative_titles'}
    d = _get('/movie/%s' % tmdb_id, params)
    return _format_movie(d) if d.get('id') else None


def get_tvshow(tmdb_id):
    d = _get('/tv/%s' % tmdb_id, {'append_to_response': 'credits,external_ids'})
    return _format_tvshow(d) if d.get('id') else None


def get_season(tmdb_id, season_number, tvshowtitle=''):
    d = _get('/tv/%s/season/%s' % (tmdb_id, season_number))
    return _format_season(d, tmdb_id, tvshowtitle) if d.get('season_number') is not None else None


def get_person(person_id):
    return _get('/person/%s' % person_id, {'append_to_response': 'combined_credits'})


def search_person(query, page=1):
    data = _get('/search/person', {'query': query, 'page': page})
    results = [
        {
            'tmdb_id':   r.get('id', ''),
            'name':      r.get('name', ''),
            'poster':    _img(r.get('profile_path')),
            'known_for': r.get('known_for_department', ''),
        }
        for r in data.get('results', [])
    ]
    return results, data.get('total_pages', 1)


def get_person_credits(person_id):
    d = _get('/person/%s/combined_credits' % person_id)
    movies = [c.get('id') for c in d.get('cast', []) if c.get('media_type') == 'movie']
    shows  = [c.get('id') for c in d.get('cast', []) if c.get('media_type') == 'tv']
    return movies[:30], shows[:30]


def _parse_url_params(url_str):
    from urllib.parse import parse_qsl
    return dict(parse_qsl(url_str))
