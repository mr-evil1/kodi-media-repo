import os
import json
import time
import hashlib
import importlib.util
from resources.lib import log, multiquest
from resources.lib.control import getSetting, addonProfile


def update_resolveurl(silent=False):
    from resources.lib.updateManager import UpdateResolve
    return UpdateResolve('Gujal00', 'ResolveURL', 'script.module.resolveurl', 'master', '', silent=silent)


_PROFILE    = addonProfile()
_CACHE      = os.path.join(_PROFILE, 'remote_cache')
_SCOUT      = os.path.join(_CACHE, 'scrapers')
_EVIL_PATH  = os.path.join(_CACHE, 'evil.py')

for _d in (_CACHE, _SCOUT):
    os.makedirs(_d, exist_ok=True)

_MANIFEST_FILE = os.path.join(_CACHE, 'manifest.json')
_MODULE_CACHE  = {}

_SETTINGS_CACHE = {}

def _get_cached_setting(key, default=''):
    if key not in _SETTINGS_CACHE:
        _SETTINGS_CACHE[key] = getSetting(key, default)
    return _SETTINGS_CACHE[key]

def _invalidate_settings_cache():
    _SETTINGS_CACHE.clear()

def _base_url():
    return _get_cached_setting('remote.base_url') or 'https://raw.githubusercontent.com/mr-evil1/moviescout-modules/main'

def _cache_hours():
    return int(_get_cached_setting('remote.cache_hours') or 24) * 3600

def _remote_enabled():
    return _get_cached_setting('remote.enable') != 'false'

def _scraper_reload():
    return _get_cached_setting('debug.scraper_reload') == 'true'

def _local_cache_only():
    return _get_cached_setting('debug.scraper_reload') == 'true'


def _meta_file(path):
    return path + '.meta'


def _is_valid(path):
    meta_path = _meta_file(path)
    if not os.path.exists(path) or not os.path.exists(meta_path):
        return False
    try:
        with open(meta_path) as f:
            meta = json.load(f)
        return (time.time() - meta.get('downloaded', 0)) < _cache_hours()
    except Exception:
        return False


def fetch_manifest(force=False):
    if _local_cache_only():
        if os.path.exists(_MANIFEST_FILE):
            try:
                with open(_MANIFEST_FILE) as f:
                    return json.load(f)
            except Exception:
                pass
        return {'scrapers': []}
    if not force and os.path.exists(_MANIFEST_FILE):
        if time.time() - os.path.getmtime(_MANIFEST_FILE) < _cache_hours():
            try:
                with open(_MANIFEST_FILE) as f:
                    return json.load(f)
            except Exception:
                pass
    try:
        r = multiquest.get(_base_url() + '/manifest.json', timeout=5)
        r.raise_for_status()
        data = r.json()
        with open(_MANIFEST_FILE, 'w') as f:
            json.dump(data, f)
        return data
    except Exception:
        if os.path.exists(_MANIFEST_FILE):
            try:
                with open(_MANIFEST_FILE) as f:
                    return json.load(f)
            except Exception:
                pass
        return {'scrapers': []}


def _download(name, force=False):
    path = os.path.join(_SCOUT, name + '.py')
    if _local_cache_only():
        return os.path.exists(path) or None
    if not force and _is_valid(path):
        return True
    url = '%s/scrapers/%s.py' % (_base_url(), name)
    try:
        r = multiquest.get(url, timeout=8)
        r.raise_for_status()
        content = r.text
        if 'ACTIVE = False' in content or 'ACTIVE=False' in content:
            return None
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        meta = {'downloaded': time.time(), 'url': url, 'hash': hashlib.md5(content.encode()).hexdigest()}
        with open(_meta_file(path), 'w') as f:
            json.dump(meta, f)
        return True
    except Exception:
        log.error()
        return False


_BLOCKED_FILE = os.path.join(_SCOUT, 'blocked_hosters.json')
_blocked_cache = None
_blocked_ts    = 0


def fetch_blocked(force=False):
    global _blocked_cache, _blocked_ts
    now = time.time()
    if not force and _blocked_cache is not None and now - _blocked_ts < _cache_hours():
        return _blocked_cache
    if not force and os.path.exists(_BLOCKED_FILE):
        if now - os.path.getmtime(_BLOCKED_FILE) < _cache_hours():
            try:
                with open(_BLOCKED_FILE, encoding='utf-8') as f:
                    _blocked_cache = json.load(f)
                    _blocked_ts    = now
                    return _blocked_cache
            except Exception:
                pass
    try:
        r = multiquest.get(_base_url() + '/scrapers/blocked_hosters.json', timeout=5)
        r.raise_for_status()
        data = r.json()
        with open(_BLOCKED_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        _blocked_cache = data
        _blocked_ts    = now
        return data
    except Exception:
        if os.path.exists(_BLOCKED_FILE):
            try:
                with open(_BLOCKED_FILE, encoding='utf-8') as f:
                    _blocked_cache = json.load(f)
                    _blocked_ts    = now
                    return _blocked_cache
            except Exception:
                pass
        return []


def get_blocked_hosters():
    try:
        data = fetch_blocked()
        if isinstance(data, list):
            return set(e.lower().strip() for e in data if e)
    except Exception:
        log.error()
    return set()


def update_all(force=False, progress_callback=None):
    if _local_cache_only():
        return
    if not _remote_enabled():
        return
    _invalidate_settings_cache()

    _RESERVED = {'evil', 'vavootv', 'livetv'}
    manifest = fetch_manifest(force=True)
    scrapers_to_do = [
        s for s in manifest.get('scrapers', [])
        if s.get('name') and s['name'] not in _RESERVED
        and (force or not _is_valid(os.path.join(_SCOUT, s['name'] + '.py')))
    ]
    skip_count = sum(
        1 for s in manifest.get('scrapers', [])
        if s.get('name') and s['name'] not in _RESERVED
        and not force and _is_valid(os.path.join(_SCOUT, s['name'] + '.py'))
    )

    fixed_tasks = [
        ('evil',    _download_evil),
        ('vavootv', _download_vavootv),
        ('livetv',  _download_livetv),
        ('blocked', lambda force=force: fetch_blocked(force=force)),
    ]
    total = len(fixed_tasks) + len(scrapers_to_do)
    done  = [0]

    def _report(label):
        done[0] += 1
        if progress_callback:
            pct = int(done[0] * 100 / total) if total else 100
            progress_callback(pct, label)

    from concurrent.futures import ThreadPoolExecutor, as_completed
    with ThreadPoolExecutor(max_workers=8) as ex:
        fixed_futures   = {ex.submit(fn, force): name for name, fn in fixed_tasks}
        scraper_futures = {ex.submit(_download, s['name'], force): s['name'] for s in scrapers_to_do}
        all_futures = {**fixed_futures, **scraper_futures}
        ok = err = 0
        for f in as_completed(all_futures):
            name = all_futures[f]
            try:
                result = f.result()
                if result is True:   ok  += 1
                elif result is None: pass
                else:                err += 1
            except Exception:
                log.error()
                err += 1
            _report(name)

    log.log('Remote-Update: %d ok, %d fehler, %d übersprungen' % (ok, err, skip_count))


def _load_module(name):
    debug_reload = _scraper_reload()
    if not debug_reload and name in _MODULE_CACHE:
        return _MODULE_CACHE[name]
    path = os.path.join(_SCOUT, name + '.py')
    if not os.path.exists(path):
        if not _download(name):
            return None
    try:
        spec   = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        custom_domain = get_scraper_domain(name)
        if custom_domain and hasattr(module, 'SITE_DOMAIN'):
            module.SITE_DOMAIN = custom_domain
        if not debug_reload:
            _MODULE_CACHE[name] = module
        return module
    except Exception:
        log.error()
        return None


def get_scout_scrapers():
    if not _remote_enabled():
        return []
    manifest = fetch_manifest()
    _RESERVED = {'evil', 'vavootv', 'livetv'}
    scrapers = [s for s in manifest.get('scrapers', []) if s.get('name') and s['name'] not in _RESERVED]
    disabled = {s['name'] for s in scrapers if _get_cached_setting('scraper.%s.disabled' % s['name']) == 'true'}
    result = []
    for s in scrapers:
        name = s['name']
        if name in disabled:
            continue
        m = _load_module(name)
        if m and hasattr(m, 'get_hosters'):
            if not hasattr(m, 'SCRAPER_TIMEOUT') and 'timeout' in s:
                m.SCRAPER_TIMEOUT = int(s['timeout'])
            result.append(m)
    return result


def get_browse_scrapers():
    if not _remote_enabled():
        return []
    manifest = fetch_manifest()
    _RESERVED = {'evil', 'vavootv', 'livetv'}
    scrapers = [s for s in manifest.get('scrapers', []) if s.get('name') and s['name'] not in _RESERVED]
    disabled = {s['name'] for s in scrapers if _get_cached_setting('scraper.%s.disabled' % s['name']) == 'true'}
    return [
        (s, m) for s in scrapers
        if s['name'] not in disabled
        for m in [_load_module(s['name'])]
        if m and hasattr(m, 'load')
    ]


def get_all_scraper_info():
    manifest = fetch_manifest()
    _RESERVED = {'evil', 'vavootv', 'livetv'}
    scrapers_raw = [s for s in manifest.get('scrapers', []) if s.get('name', '') not in _RESERVED and s.get('name')]
    result = []
    for s in scrapers_raw:
        name     = s.get('name', '')
        path     = os.path.join(_SCOUT, name + '.py')
        disabled = _get_cached_setting('scraper.%s.disabled' % name) == 'true'
        cached   = os.path.exists(path)
        m        = _load_module(name)
        caps     = []
        domain   = get_scraper_domain(name) or s.get('domain', '')
        if m:
            if hasattr(m, 'get_hosters'): caps.append('scout')
            if hasattr(m, 'load'):        caps.append('browse')
            if not domain and hasattr(m, 'SITE_DOMAIN'):
                domain = m.SITE_DOMAIN
        result.append({
            'name':     name,
            'type':     '+'.join(caps) if caps else s.get('type', '?'),
            'domain':   domain,
            'version':  s.get('version', ''),
            'disabled': disabled,
            'cached':   cached,
            'path':     path,
        })
    return result


def disable_scraper(name):
    from resources.lib.control import setSetting
    setSetting('scraper.%s.disabled' % name, 'true')

def enable_scraper(name):
    from resources.lib.control import setSetting
    setSetting('scraper.%s.disabled' % name, 'false')

def disable_all():
    for s in get_all_scraper_info():
        disable_scraper(s['name'])

def enable_all():
    for s in get_all_scraper_info():
        enable_scraper(s['name'])

def clear_cache():
    import shutil
    shutil.rmtree(_SCOUT, ignore_errors=True)
    os.makedirs(_SCOUT, exist_ok=True)
    for _p in (_MANIFEST_FILE, _EVIL_PATH, _VAVOOTV_PATH, _LIVETV_PATH):
        for _f in (_p, _meta_file(_p)):
            if os.path.exists(_f):
                try: os.remove(_f)
                except Exception: pass
    _MODULE_CACHE.clear()
    _VAVOOTV_CACHE.clear()
    _LIVETV_CACHE.clear()
    global _blocked_cache, _blocked_ts
    _blocked_cache = None
    _blocked_ts    = 0


def get_scraper_domain(name):
    return getSetting('scraper.%s.domain' % name) or ''

def set_scraper_domain(name, domain):
    from resources.lib.control import setSetting
    setSetting('scraper.%s.domain' % name, domain.strip())

def clear_scraper_domain(name):
    from resources.lib.control import setSetting
    setSetting('scraper.%s.domain' % name, '')

def force_download_one(name):
    _MODULE_CACHE.pop(name, None)
    return _download(name, force=True)


def _download_evil(force=False):
    if _local_cache_only():
        return os.path.exists(_EVIL_PATH) or None
    if not force and _is_valid(_EVIL_PATH):
        return True
    url = '%s/scrapers/evil.py' % _base_url()
    try:
        r = multiquest.get(url, timeout=8)
        r.raise_for_status()
        content = r.text
        with open(_EVIL_PATH, 'w', encoding='utf-8') as f:
            f.write(content)
        meta = {'downloaded': time.time(), 'url': url, 'hash': hashlib.md5(content.encode()).hexdigest()}
        with open(_meta_file(_EVIL_PATH), 'w') as f:
            json.dump(meta, f)
        _MODULE_CACHE.pop('evil', None)
        return True
    except Exception:
        log.error()
        return False


def get_evil_resolver():
    debug_reload = _scraper_reload()
    if not debug_reload and 'evil' in _MODULE_CACHE:
        return _MODULE_CACHE['evil']
    if not os.path.exists(_EVIL_PATH):
        if not _download_evil():
            return None
    try:
        spec   = importlib.util.spec_from_file_location('evil', _EVIL_PATH)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if not debug_reload:
            _MODULE_CACHE['evil'] = module
        return module
    except Exception:
        log.error()
    return None


_VAVOOTV_PATH  = os.path.join(_CACHE, 'vavootv.py')
_VAVOOTV_CACHE = {}


def _download_vavootv(force=False):
    if _local_cache_only():
        return os.path.exists(_VAVOOTV_PATH) or None
    if not force and _is_valid(_VAVOOTV_PATH):
        return True
    url = '%s/scrapers/vavootv.py' % _base_url()
    try:
        r = multiquest.get(url, timeout=8)
        r.raise_for_status()
        content = r.text
        with open(_VAVOOTV_PATH, 'w', encoding='utf-8') as f:
            f.write(content)
        meta = {'downloaded': time.time(), 'url': url, 'hash': hashlib.md5(content.encode()).hexdigest()}
        with open(_meta_file(_VAVOOTV_PATH), 'w') as f:
            json.dump(meta, f)
        _VAVOOTV_CACHE.clear()
        return True
    except Exception:
        log.error()
        return False


def get_vavootv():
    debug_reload = _scraper_reload()
    if not debug_reload and 'vavootv' in _VAVOOTV_CACHE:
        return _VAVOOTV_CACHE['vavootv']
    if not os.path.exists(_VAVOOTV_PATH):
        if not _download_vavootv():
            return None
    try:
        spec   = importlib.util.spec_from_file_location('vavootv', _VAVOOTV_PATH)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if not debug_reload:
            _VAVOOTV_CACHE['vavootv'] = module
        return module
    except Exception:
        log.error()
    return None


def update_vavootv(force=True):
    _VAVOOTV_CACHE.clear()
    return _download_vavootv(force=force)


_LIVETV_PATH  = os.path.join(_CACHE, 'livetv.py')
_LIVETV_CACHE = {}


def _download_livetv(force=False):
    if _local_cache_only():
        return os.path.exists(_LIVETV_PATH) or None
    if not force and _is_valid(_LIVETV_PATH):
        return True
    url = '%s/scrapers/livetv.py' % _base_url()
    try:
        r = multiquest.get(url, timeout=8)
        r.raise_for_status()
        cnt = r.text
        with open(_LIVETV_PATH, 'w', encoding='utf-8') as f:
            f.write(cnt)
        meta = {'downloaded': time.time(), 'url': url, 'hash': hashlib.md5(cnt.encode()).hexdigest()}
        with open(_meta_file(_LIVETV_PATH), 'w') as f:
            json.dump(meta, f)
        _LIVETV_CACHE.clear()
        return True
    except Exception:
        log.error()
        return False


def get_livetv():
    debug_reload = _scraper_reload()
    if not debug_reload and 'livetv' in _LIVETV_CACHE:
        return _LIVETV_CACHE['livetv']
    if not os.path.exists(_LIVETV_PATH):
        if not _download_livetv():
            return None
    try:
        spec   = importlib.util.spec_from_file_location('livetv', _LIVETV_PATH)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if not debug_reload:
            _LIVETV_CACHE['livetv'] = module
        return module
    except Exception:
        log.error()
    return None


def update_livetv(force=True):
    _LIVETV_CACHE.clear()
    return _download_livetv(force=force)
