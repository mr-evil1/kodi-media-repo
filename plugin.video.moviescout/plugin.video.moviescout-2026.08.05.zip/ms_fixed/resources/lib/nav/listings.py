import xbmcgui
import xbmcplugin
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote_plus, unquote_plus
from resources.lib import tmdb, log
from resources.lib.control import (
    sysaddon, syshandle, addonPoster, addonFanart, addonNext,
    addItem, content, directory, plugincategory, set_info_tag
)
from resources.lib.nav.scout import _hosts_mode

_MOVIE_GENRES = [
    ('28','Action'),('12','Abenteuer'),('16','Animation'),('35','Komödie'),
    ('80','Crime'),('99','Dokumentation'),('18','Drama'),('10751','Familie'),
    ('14','Fantasy'),('36','Geschichte'),('27','Horror'),('10402','Musik'),
    ('9648','Mystery'),('10749','Romanze'),('878','Science-Fiction'),
    ('53','Thriller'),('10770','TV-Film'),('37','Western'),
]
_TV_GENRES = [
    ('10759','Action & Adventure'),('16','Animation'),('35','Komödie'),
    ('80','Crime'),('99','Dokumentation'),('18','Drama'),('10751','Familie'),
    ('10762','Kids'),('9648','Mystery'),('10763','News'),('10764','Reality'),
    ('10765','Sci-Fi & Fantasy'),('10766','Soap'),('10767','Talk'),
    ('10768','War & Politics'),('37','Western'),
]
_YEARS = list(range(2025, 1989, -1))


def _build_li(tmdb_id, meta, addon, media_type, hosts_mode=0):
    label  = '%s (%s)' % (meta['title'], meta.get('year', ''))
    li     = xbmcgui.ListItem(label=label)
    poster = meta.get('poster') or addonPoster()
    fanart = meta.get('fanart') or addonFanart()
    li.setArt({'thumb': poster, 'poster': poster, 'fanart': fanart, 'icon': poster})

    safe_meta = {k: v for k, v in meta.items() if v not in (None, '', [], {})}
    try:
        if safe_meta.get('year'):
            safe_meta['year'] = int(str(safe_meta['year'])[:4]) if str(safe_meta.get('year',''))[:4].isdigit() else 0
    except Exception:
        safe_meta.pop('year', None)
    set_info_tag(li, safe_meta, 'movie' if media_type == 'movie' else 'tvshow')
    if media_type == 'movie':
        if hosts_mode == 2:
            li.setProperty('IsPlayable', 'false')
            li.setIsFolder(True)
            target_action = 'scoutListing&tmdb_id=%s&mt=movie&season=0&episode=0' % tmdb_id
            is_folder = True
        else:
            li.setProperty('IsPlayable', 'true')
            li.setIsFolder(False)
            target_action = 'scoutMovie&tmdb_id=%s' % tmdb_id
            is_folder = False
    else:
        li.setProperty('IsPlayable', 'false')
        li.setIsFolder(True)
        target_action = 'seasons&tmdb_id=%s&title=%s' % (tmdb_id, quote_plus(meta['title']))
        is_folder = True

    url = '%s?action=%s' % (addon, target_action)

    cm = []
    cm.append(('Info', 'RunPlugin(%s?action=info&tmdb_id=%s&media_type=%s)' % (addon, tmdb_id, media_type)))
    li.addContextMenuItems(cm)
    return url, li, is_folder


def show_listing(params):
    handle     = syshandle()
    addon      = sysaddon()
    media_type = params.get('media_type', 'movie')
    url_params = unquote_plus(params.get('url', ''))
    page       = int(params.get('page', 1))

    xbmcplugin.setContent(handle, 'movies' if media_type == 'movie' else 'tvshows')

    ids, total_pages = tmdb.discover(media_type, url_params, page)

    fetch_fn = tmdb.get_movie if media_type == 'movie' else tmdb.get_tvshow

    def _fetch(tmdb_id):
        try:
            meta = fetch_fn(tmdb_id)
            return tmdb_id, meta
        except Exception:
            log.error()
            return tmdb_id, None

    id_order   = {tmdb_id: i for i, tmdb_id in enumerate(ids)}
    results    = [None] * len(ids)
    hosts_mode = _hosts_mode()

    with ThreadPoolExecutor(max_workers=10) as ex:
        futures = {ex.submit(_fetch, tid): tid for tid in ids}
        for f in as_completed(futures):
            try:
                tmdb_id, meta = f.result()
                if meta:
                    results[id_order[tmdb_id]] = (tmdb_id, meta)
            except Exception:
                log.error()

    for entry in results:
        if not entry:
            continue
        tmdb_id, meta = entry
        try:
            url, li, is_folder = _build_li(tmdb_id, meta, addon, media_type, hosts_mode)
            addItem(handle, url, li, is_folder)
        except Exception:
            log.error()

    if page < total_pages:
        next_url_params = url_params
        li_next = xbmcgui.ListItem(label='[B]Nächste Seite »[/B]')
        li_next.setArt({'thumb': addonNext(), 'icon': addonNext()})
        li_next.setIsFolder(True)
        next_url = '%s?action=listings&media_type=%s&url=%s&page=%d' % (
            addon, media_type, quote_plus(next_url_params), page + 1)
        addItem(handle, next_url, li_next, True)

    directory(handle)


def show_movie_genres():
    handle = syshandle()
    addon  = sysaddon()
    xbmcplugin.setContent(handle, 'files')
    for gid, name in _MOVIE_GENRES:
        li = xbmcgui.ListItem(label=name)
        li.setIsFolder(True)
        url = '%s?action=listings&media_type=movie&url=%s' % (
            addon, quote_plus('with_genres=%s&sort_by=popularity.desc' % gid))
        addItem(handle, url, li, True)
    directory(handle)


def show_tv_genres():
    handle = syshandle()
    addon  = sysaddon()
    xbmcplugin.setContent(handle, 'files')
    for gid, name in _TV_GENRES:
        li = xbmcgui.ListItem(label=name)
        li.setIsFolder(True)
        url = '%s?action=listings&media_type=tv&url=%s' % (
            addon, quote_plus('with_genres=%s&sort_by=popularity.desc' % gid))
        addItem(handle, url, li, True)
    directory(handle)


def show_movie_years():
    handle = syshandle()
    addon  = sysaddon()
    xbmcplugin.setContent(handle, 'files')
    for year in _YEARS:
        li = xbmcgui.ListItem(label=str(year))
        li.setIsFolder(True)
        url = '%s?action=listings&media_type=movie&url=%s' % (
            addon, quote_plus('primary_release_year=%d&sort_by=popularity.desc' % year))
        addItem(handle, url, li, True)
    directory(handle)


def show_tv_years():
    handle = syshandle()
    addon  = sysaddon()
    xbmcplugin.setContent(handle, 'files')
    for year in _YEARS:
        li = xbmcgui.ListItem(label=str(year))
        li.setIsFolder(True)
        url = '%s?action=listings&media_type=tv&url=%s' % (
            addon, quote_plus('first_air_date_year=%d&sort_by=vote_count.desc' % year))
        addItem(handle, url, li, True)
    directory(handle)


def show_item(tmdb_id, media_type, addon, handle, add_to_dir=True):
    try:
        meta = tmdb.get_movie(tmdb_id) if media_type == 'movie' else tmdb.get_tvshow(tmdb_id)
        if not meta:
            return
        url, li, is_folder = _build_li(tmdb_id, meta, addon, media_type, _hosts_mode())
        addItem(handle, url, li, is_folder)
        return meta
    except Exception:
        log.error()
