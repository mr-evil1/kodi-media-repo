import sys
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from urllib.parse import quote_plus, unquote_plus, parse_qsl

_addon = xbmcaddon.Addon()

def addon():           return _addon
def addonId():         return _addon.getAddonInfo('id')
def addonName():       return _addon.getAddonInfo('name')
def addonVersion():    return _addon.getAddonInfo('version')
def addonPath():       return xbmcvfs.translatePath(_addon.getAddonInfo('path'))
def addonProfile():    return xbmcvfs.translatePath(_addon.getAddonInfo('profile'))
def getSetting(key, default=''):
    val = _addon.getSetting(key)
    return val if val != '' else default
def setSetting(k, v):  _addon.setSetting(k, str(v))
def openSettings():    _addon.openSettings()

def artPath():     return os.path.join(addonPath(), 'resources', 'images')
def addonFanart(): return os.path.join(addonPath(), 'fanart.jpg')
def addonPoster(): return os.path.join(addonPath(), 'icon.png')
def addonThumb():  return os.path.join(addonPath(), 'icon.png')
def addonBanner(): return os.path.join(addonPath(), 'icon.png')
def addonNext():
    p = os.path.join(artPath(), 'next.png')
    return p if xbmcvfs.exists(p) else addonThumb()

def translatePath(p): return xbmcvfs.translatePath(p)
def exists(p):        return xbmcvfs.exists(p)
def listDir(p):       return xbmcvfs.listdir(p)
def sleep(ms):        xbmc.sleep(ms)
def execute(cmd):     xbmc.executebuiltin(cmd)
def skin():           return xbmc.getSkinDir()

def syshandle(): return int(sys.argv[1]) if len(sys.argv) > 1 else -1
def sysaddon():  return sys.argv[0]

class _K19TagShim:
    def __init__(self, li):
        self._li = li
        self._info = {}
        self._mediatype = 'video'
    def setTitle(self, v): self._info['title'] = v
    def setPlot(self, v): self._info['plot'] = v
    def setMediaType(self, v): self._mediatype = v
    def setYear(self, v): self._info['year'] = v
    def setPremiered(self, v): self._info['premiered'] = v
    def setDuration(self, v): self._info['duration'] = v
    def setRating(self, rating, votes=0, typ='', dflt=False): self._info['rating'] = rating; self._info['votes'] = votes
    def setGenres(self, v): self._info['genre'] = v
    def setStudios(self, v): self._info['studio'] = v
    def setDirectors(self, v): self._info['director'] = v
    def setIMDBNumber(self, v): self._info['imdbnumber'] = v
    def setUniqueID(self, v, typ='', dflt=False): pass
    def setPlaycount(self, v): self._info['playcount'] = v
    def setTvShowTitle(self, v): self._info['tvshowtitle'] = v
    def setSeason(self, v): self._info['season'] = v
    def setEpisode(self, v): self._info['episode'] = v
    def setCast(self, v): pass
    def flush(self): self._li.setInfo('video', self._info)

def get_video_tag(li):
    try:
        tag = li.getVideoInfoTag()
        if not callable(getattr(tag, 'setTitle', None)):
            raise AttributeError
        return tag, False
    except AttributeError:
        return _K19TagShim(li), True

def item(label='', offscreen=True):
    return xbmcgui.ListItem(label=label, offscreen=offscreen)

def addItem(handle, url, listitem, isFolder):
    xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder)

def directory(handle, succeeded=True, cacheToDisc=True):
    xbmcplugin.endOfDirectory(handle, succeeded=succeeded, cacheToDisc=cacheToDisc)

def content(handle, content_type):
    xbmcplugin.setContent(handle, content_type)

def plugincategory(handle, category):
    xbmcplugin.setPluginCategory(handle, category)

def resolveUrl(handle, succeeded, listitem):
    xbmcplugin.setResolvedUrl(handle, succeeded, listitem)

def sortMethod(handle, method):
    xbmcplugin.addSortMethod(handle, method)

def infoDialog(msg, title='', icon='INFO', time=3000, sound=False):
    icons = {
        'INFO': xbmcgui.NOTIFICATION_INFO,
        'WARNING': xbmcgui.NOTIFICATION_WARNING,
        'ERROR': xbmcgui.NOTIFICATION_ERROR,
    }
    xbmcgui.Dialog().notification(title or addonName(), msg, icons.get(icon, xbmcgui.NOTIFICATION_INFO), time, sound)

def dialog_ok(title, msg):
    xbmcgui.Dialog().ok(title, msg)

def dialog_select(title, items):
    return xbmcgui.Dialog().select(title, items)

def dialog_input(title='', default=''):
    return xbmcgui.Dialog().input(title, default)

def keyboard(default='', title=''):
    kb = xbmc.Keyboard(default, title)
    return kb

progressDialog = xbmcgui.DialogProgress()
window = xbmcgui.Window(10000)

def busy():
    execute('ActivateWindow(busydialognocancel)')

def idle():
    execute('Dialog.Close(busydialognocancel)')

def visible():
    return xbmc.getCondVisibility('Window.IsVisible(busydialognocancel)')

def set_info_tag(li, meta, mediatype):
    tag, _shim = get_video_tag(li)
    try:
        tag.setMediaType(mediatype)
        if meta.get('title'):
            tag.setTitle(str(meta['title']))
        if meta.get('plot'):
            tag.setPlot(str(meta['plot']))
        if meta.get('year'):
            try: tag.setYear(int(str(meta['year'])[:4]))
            except Exception: pass
        if meta.get('premiered'):
            tag.setPremiered(str(meta['premiered']))
        if meta.get('duration'):
            try: tag.setDuration(int(meta['duration']))
            except Exception: pass
        if meta.get('rating'):
            try: tag.setRating(float(meta['rating']), int(meta.get('votes', 0)), 'tmdb', True)
            except Exception: pass
        if meta.get('genres'):
            tag.setGenres(meta['genres'] if isinstance(meta['genres'], list) else [str(meta['genres'])])
        if meta.get('studios'):
            tag.setStudios(meta['studios'] if isinstance(meta['studios'], list) else [str(meta['studios'])])
        if meta.get('directors'):
            tag.setDirectors(meta['directors'] if isinstance(meta['directors'], list) else [str(meta['directors'])])
        if meta.get('imdb_id'):
            tag.setIMDBNumber(str(meta['imdb_id']))
        if meta.get('tmdb_id'):
            tag.setUniqueID(str(meta['tmdb_id']), 'tmdb', True)
        if meta.get('playcount') is not None:
            try: tag.setPlaycount(int(meta['playcount']))
            except Exception: pass
        if mediatype in ('tvshow', 'season', 'episode') and meta.get('tvshowtitle'):
            tag.setTvShowTitle(str(meta['tvshowtitle']))
        if mediatype in ('season', 'episode') and meta.get('season'):
            try: tag.setSeason(int(meta['season']))
            except Exception: pass
        if mediatype == 'episode' and meta.get('episode'):
            try: tag.setEpisode(int(meta['episode']))
            except Exception: pass
        cast = meta.get('cast', [])
        if cast:
            actors = []
            for c in cast:
                if isinstance(c, dict):
                    actors.append(xbmc.Actor(
                        c.get('name', ''), c.get('role', ''),
                        c.get('order', 0), c.get('thumbnail', '')))
            if actors:
                try: tag.setCast(actors)
                except Exception: pass
        if _shim: tag.flush()
    except Exception:
        pass
