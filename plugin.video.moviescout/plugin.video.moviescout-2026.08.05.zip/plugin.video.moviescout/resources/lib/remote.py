import os
import json
import time
import hashlib
import importlib.util
from resources.lib import log, multiquest
from resources.lib.control import getSetting, addonProfile

# ---------------------------------------------------------------------------
# ResolveURL Update-Mechanismus – delegiert an updateManager.UpdateResolve()
# (1:1 aus plugin.video.streams portiert)
# ---------------------------------------------------------------------------


def update_resolveurl(silent=False):
    """
    Aktualisiert script.module.resolveurl via updateManager.UpdateResolve()
    (1:1 aus plugin.video.streams portiert, Quelle: Gujal00/ResolveURL @ master).

    Rückgabe: True (installiert) | None / False (kein Update / Fehler)
    """
    from resources.lib.updateManager import UpdateResolve
    import xbmcgui
    username    = 'Gujal00'
    resolve_dir = 'ResolveURL'
    resolve_id  = 'script.module.resolveurl'
    branch      = 'master'
    token       = ''
    return UpdateResolve(username, resolve_dir, resolve_id, branch, token, silent=silent)


_PROFILE    = addonProfile()
_CACHE      = os.path.join(_PROFILE, 'remote_cache')
_SCOUT      = os.path.join(_CACHE, 'scrapers')
_EVIL_PATH  = os.path.join(_CACHE, 'evil.py')

for _d in (_CACHE, _SCOUT):
    os.makedirs(_d, exist_ok=True)

_MANIFEST_FILE = os.path.join(_CACHE, 'manifest.json')
_MODULE_CACHE = {}


def _base_url():
    return getSetting('remote.base_url') or 'https://raw.githubusercontent.com/mr-evil1/moviescout-modules/main'

def _cache_hours():
    return int(getSetting('remote.cache_hours') or 24) * 3600

def _remote_enabled():
    val = getSetting('remote.enable'); return val != 'false'

def _scraper_reload():
    return getSetting('debug.scraper_reload') == 'true'

def _local_cache_only():
    return getSetting('debug.scraper_reload') == 'true'


def _meta_file(path):
    return path + '.meta'


def _is_valid(path):
    meta_path = _meta_file(path)
    if not os.path.exists(path) or not os.path.exists(meta_path):
        return False
    try:
        with open(meta_path) as f:
            meta = json.load(f)
        return (time.time() - meta.get('downloaded', 0)) < _cache_hours()
    except Exception:
        return False


def fetch_manifest(force=False):
    if _local_cache_only():
        if os.path.exists(_MANIFEST_FILE):
            try:
                with open(_MANIFEST_FILE) as f:
                    return json.load(f)
            except Exception:
                pass
        return {'scrapers': []}
    if not force and os.path.exists(_MANIFEST_FILE):
        age = time.time() - os.path.getmtime(_MANIFEST_FILE)
        if age < _cache_hours():
            try:
                with open(_MANIFEST_FILE) as f:
                    return json.load(f)
            except Exception:
                pass
    try:
        r = multiquest.get(_base_url() + '/manifest.json', timeout=5)
        r.raise_for_status()
        data = r.json()
        with open(_MANIFEST_FILE, 'w') as f:
            json.dump(data, f)
        return data
    except Exception:
        if os.path.exists(_MANIFEST_FILE):
            try:
                with open(_MANIFEST_FILE) as f:
                    return json.load(f)
            except Exception:
                pass
        return {'scrapers': []}


def _download(name, force=False):
    path = os.path.join(_SCOUT, name + '.py')
    if _local_cache_only():
        return os.path.exists(path) or None
    if not force and _is_valid(path):
        return True
    url = '%s/scrapers/%s.py' % (_base_url(), name)
    try:
        r = multiquest.get(url, timeout=8)
        r.raise_for_status()
        content = r.text
        if 'ACTIVE = False' in content or 'ACTIVE=False' in content:
            log.log('Remote scraper %s ist ACTIVE=False, übersprungen' % name)
            return None
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        meta = {'downloaded': time.time(), 'url': url, 'hash': hashlib.md5(content.encode()).hexdigest()}
        with open(_meta_file(path), 'w') as f:
            json.dump(meta, f)
        log.log('✓ Scraper heruntergeladen: %s' % name)
        return True
    except Exception:
        log.error()
        return False


_BLOCKED_FILE = os.path.join(_SCOUT, 'blocked_hosters.json')


def fetch_blocked(force=False):
    if not force and os.path.exists(_BLOCKED_FILE):
        age = time.time() - os.path.getmtime(_BLOCKED_FILE)
        if age < _cache_hours():
            try:
                with open(_BLOCKED_FILE, encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
    try:
        r = multiquest.get(_base_url() + '/scrapers/blocked_hosters.json', timeout=5)
        r.raise_for_status()
        data = r.json()
        with open(_BLOCKED_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        log.log('blocked_hosters.json aktualisiert')
        return data
    except Exception:
        if os.path.exists(_BLOCKED_FILE):
            try:
                with open(_BLOCKED_FILE, encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        return []


def get_blocked_hosters():
    try:
        data = fetch_blocked()
        if isinstance(data, list):
            return set(e.lower().strip() for e in data if e)
    except Exception:
        log.error()
    return set()


def update_all(force=False):
    if _local_cache_only():
        log.log('Cache-only Modus aktiv – kein Remote-Update.')
        return
    if not _remote_enabled():
        return
    _download_evil(force=force)
    _download_vavootv(force=force)
    _download_livetv(force=force)
    manifest = fetch_manifest(force=True)
    fetch_blocked(force=force)
    _RESERVED = {'evil', 'vavootv', 'livetv'}
    ok = err = skip = 0
    for s in manifest.get('scrapers', []):
        name = s.get('name')
        if not name or name in _RESERVED:
            continue
        path = os.path.join(_SCOUT, name + '.py')
        if not force and _is_valid(path):
            skip += 1
            continue
        result = _download(name, force=force)
        if result is True:
            ok += 1
        elif result is None:
            skip += 1
        else:
            err += 1
    log.log('Remote-Update: %d ok, %d fehler, %d übersprungen' % (ok, err, skip))


def _load_module(name):
    debug_reload = _scraper_reload()
    if not debug_reload and name in _MODULE_CACHE:
        return _MODULE_CACHE[name]
    path = os.path.join(_SCOUT, name + '.py')
    if not os.path.exists(path):
        if not _download(name):
            return None
    try:
        spec   = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        custom_domain = get_scraper_domain(name)
        if custom_domain and hasattr(module, 'SITE_DOMAIN'):
            module.SITE_DOMAIN = custom_domain
        if not debug_reload:
            _MODULE_CACHE[name] = module
        return module
    except Exception:
        log.error()
        return None


def get_scout_scrapers():
    if not _remote_enabled():
        return []
    manifest = fetch_manifest()
    result = []
    _RESERVED = {'evil', 'vavootv', 'livetv'}
    for s in manifest.get('scrapers', []):
        name = s.get('name')
        if not name or name in _RESERVED:
            continue
        if getSetting('scraper.%s.disabled' % name) == 'true':
            continue
        m = _load_module(name)
        if m and hasattr(m, 'get_hosters'):
            if not hasattr(m, 'SCRAPER_TIMEOUT') and 'timeout' in s:
                m.SCRAPER_TIMEOUT = int(s['timeout'])
            result.append(m)
    return result


def get_browse_scrapers():
    if not _remote_enabled():
        return []
    manifest = fetch_manifest()
    result = []
    _RESERVED = {'evil', 'vavootv', 'livetv'}
    for s in manifest.get('scrapers', []):
        name = s.get('name')
        if not name or name in _RESERVED:
            continue
        if getSetting('scraper.%s.disabled' % name) == 'true':
            continue
        m = _load_module(name)
        if m and hasattr(m, 'load'):
            result.append((s, m))
    return result


def get_all_scraper_info():
    manifest = fetch_manifest()
    result = []
    _RESERVED = {'evil', 'vavootv', 'livetv'}
    for s in manifest.get('scrapers', []):
        name = s.get('name', '')
        if name in _RESERVED:
            continue
        path = os.path.join(_SCOUT, name + '.py')
        disabled = getSetting('scraper.%s.disabled' % name) == 'true'
        cached   = os.path.exists(path)
        m = _load_module(name)
        caps = []
        domain = get_scraper_domain(name) or s.get('domain', '')
        if m:
            if hasattr(m, 'get_hosters'): caps.append('scout')
            if hasattr(m, 'load'):        caps.append('browse')
            if not domain and hasattr(m, 'SITE_DOMAIN'):
                domain = m.SITE_DOMAIN
        result.append({
            'name':     name,
            'type':     '+'.join(caps) if caps else s.get('type', '?'),
            'domain':   domain,
            'version':  s.get('version', ''),
            'disabled': disabled,
            'cached':   cached,
            'path':     path,
        })
    return result


def disable_scraper(name):
    from resources.lib.control import setSetting
    setSetting('scraper.%s.disabled' % name, 'true')

def enable_scraper(name):
    from resources.lib.control import setSetting
    setSetting('scraper.%s.disabled' % name, 'false')

def disable_all():
    for s in get_all_scraper_info():
        disable_scraper(s['name'])

def enable_all():
    for s in get_all_scraper_info():
        enable_scraper(s['name'])

def clear_cache():
    import shutil
    shutil.rmtree(_SCOUT, ignore_errors=True)
    os.makedirs(_SCOUT, exist_ok=True)
    for _p in (_MANIFEST_FILE, _EVIL_PATH, _VAVOOTV_PATH, _LIVETV_PATH):
        for _f in (_p, _meta_file(_p)):
            if os.path.exists(_f):
                os.remove(_f)
    _MODULE_CACHE.clear()
    _VAVOOTV_CACHE.clear()
    _LIVETV_CACHE.clear()
    log.log('Remote Cache gelöscht')


def get_scraper_domain(name):
    return getSetting('scraper.%s.domain' % name) or ''

def set_scraper_domain(name, domain):
    from resources.lib.control import setSetting
    setSetting('scraper.%s.domain' % name, domain.strip())

def clear_scraper_domain(name):
    from resources.lib.control import setSetting
    setSetting('scraper.%s.domain' % name, '')

def force_download_one(name):
    _MODULE_CACHE.pop(name, None)
    return _download(name, force=True)


def _download_evil(force=False):
    if _local_cache_only():
        return os.path.exists(_EVIL_PATH) or None
    if not force and _is_valid(_EVIL_PATH):
        return True
    url = '%s/scrapers/evil.py' % _base_url()
    try:
        r = multiquest.get(url, timeout=8)
        r.raise_for_status()
        content = r.text
        with open(_EVIL_PATH, 'w', encoding='utf-8') as f:
            f.write(content)
        meta = {'downloaded': time.time(), 'url': url, 'hash': hashlib.md5(content.encode()).hexdigest()}
        with open(_meta_file(_EVIL_PATH), 'w') as f:
            json.dump(meta, f)
        log.log('✓ evil.py heruntergeladen')
        _MODULE_CACHE.pop('evil', None)
        return True
    except Exception:
        log.error()
        return False


def get_evil_resolver():
    debug_reload = _scraper_reload()
    if not debug_reload and 'evil' in _MODULE_CACHE:
        return _MODULE_CACHE['evil']
    if not os.path.exists(_EVIL_PATH):
        if not _download_evil():
            return None
    try:
        spec   = importlib.util.spec_from_file_location('evil', _EVIL_PATH)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if not debug_reload:
            _MODULE_CACHE['evil'] = module
        return module
    except Exception:
        log.error()
    return None


_VAVOOTV_PATH = os.path.join(_CACHE, 'vavootv.py')
_VAVOOTV_CACHE = {}


def _download_vavootv(force=False):
    if _local_cache_only():
        return os.path.exists(_VAVOOTV_PATH) or None
    if not force and _is_valid(_VAVOOTV_PATH):
        return True
    url = '%s/scrapers/vavootv.py' % _base_url()
    try:
        r = multiquest.get(url, timeout=8)
        r.raise_for_status()
        content = r.text
        with open(_VAVOOTV_PATH, 'w', encoding='utf-8') as f:
            f.write(content)
        meta = {'downloaded': time.time(), 'url': url, 'hash': hashlib.md5(content.encode()).hexdigest()}
        with open(_meta_file(_VAVOOTV_PATH), 'w') as f:
            json.dump(meta, f)
        log.log('✓ vavootv.py heruntergeladen')
        _VAVOOTV_CACHE.clear()
        return True
    except Exception:
        log.error()
        return False


def get_vavootv():
    debug_reload = _scraper_reload()
    if not debug_reload and 'vavootv' in _VAVOOTV_CACHE:
        return _VAVOOTV_CACHE['vavootv']
    if not os.path.exists(_VAVOOTV_PATH):
        if not _download_vavootv():
            return None
    try:
        spec   = importlib.util.spec_from_file_location('vavootv', _VAVOOTV_PATH)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if not debug_reload:
            _VAVOOTV_CACHE['vavootv'] = module
        return module
    except Exception:
        log.error()
    return None


def update_vavootv(force=True):
    _VAVOOTV_CACHE.clear()
    return _download_vavootv(force=force)


_LIVETV_PATH = os.path.join(_CACHE, 'livetv.py')
_LIVETV_CACHE = {}


def _download_livetv(force=False):
    if _local_cache_only():
        return os.path.exists(_LIVETV_PATH) or None
    if not force and _is_valid(_LIVETV_PATH):
        return True
    url = '%s/scrapers/livetv.py' % _base_url()
    try:
        r = multiquest.get(url, timeout=8)
        r.raise_for_status()
        cnt = r.text
        with open(_LIVETV_PATH, 'w', encoding='utf-8') as f:
            f.write(cnt)
        meta = {'downloaded': time.time(), 'url': url, 'hash': hashlib.md5(cnt.encode()).hexdigest()}
        with open(_meta_file(_LIVETV_PATH), 'w') as f:
            json.dump(meta, f)
        log.log('livetv.py heruntergeladen')
        _LIVETV_CACHE.clear()
        return True
    except Exception:
        log.error()
        return False


def get_livetv():
    debug_reload = _scraper_reload()
    if not debug_reload and 'livetv' in _LIVETV_CACHE:
        return _LIVETV_CACHE['livetv']
    if not os.path.exists(_LIVETV_PATH):
        if not _download_livetv():
            return None
    try:
        spec   = importlib.util.spec_from_file_location('livetv', _LIVETV_PATH)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if not debug_reload:
            _LIVETV_CACHE['livetv'] = module
        return module
    except Exception:
        log.error()
    return None


def update_livetv(force=True):
    _LIVETV_CACHE.clear()
    return _download_livetv(force=force)
