import os
import re
import xbmcgui
from resources.lib import log, multiquest
from resources.lib.control import getSetting, infoDialog, addonName


def _safe_name(name):
    return re.sub(r'[\\/:*?"<>|]', '', name)


def _dest_path(name, mediatype='movie'):
    base = getSetting('download.movie.path') if mediatype != 'tvshow' else getSetting('download.tv.path')
    if not base:
        base = os.path.expanduser('~/Downloads')
    os.makedirs(base, exist_ok=True)
    ext = '.mp4'
    return os.path.join(base, _safe_name(name) + ext)


def download(title, url, mediatype='movie', image=''):
    dest = _dest_path(title, mediatype)
    dp = xbmcgui.DialogProgress()
    dp.create(addonName(), 'Download: %s' % title)
    try:
        r, total = multiquest.get_stream(url, timeout=30)
        done = 0
        with open(dest, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024 * 256):
                if dp.iscanceled():
                    break
                if chunk:
                    f.write(chunk)
                    done += len(chunk)
                    if total:
                        dp.update(int(done * 100 / total), 'Download: %s' % title)
        dp.close()
        if not dp.iscanceled():
            infoDialog('Download abgeschlossen: %s' % title)
            log.log('Download OK: %s → %s' % (title, dest))
    except Exception:
        dp.close()
        infoDialog('Download fehlgeschlagen!', icon='ERROR')
        log.error()
