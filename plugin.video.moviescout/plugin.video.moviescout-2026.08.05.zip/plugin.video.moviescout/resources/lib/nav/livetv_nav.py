import json
import os
import time
import threading

import xbmc
import xbmcgui
import xbmcplugin
from urllib.parse import quote_plus, unquote_plus

from resources.lib.control import (
    syshandle, sysaddon, getSetting,
    addItem, content, directory, plugincategory,
    infoDialog, addonFanart, addonProfile, get_video_tag,
)
from resources.lib import remote, log

_CH_CACHE_FILE = 'livetv_channels_cache.json'


def _h():
    return syshandle()


def _a():
    return sysaddon()


def _url(action, **kwargs):
    u = '%s?action=%s' % (_a(), action)
    for k, v in kwargs.items():
        u += '&%s=%s' % (k, v)
    return u


def _get_mod():
    mod = remote.get_livetv()
    if mod is None:
        log.log('[LiveTV] livetv.py nicht verfügbar – Remote-Update erforderlich')
    return mod


def _ch_cache_path():
    return os.path.join(addonProfile(), _CH_CACHE_FILE)



def show_groups(params):
    h = _h()

    if getSetting('livetv.enable') == 'false':
        directory(h, succeeded=False)
        return

    mod = _get_mod()
    if mod is None:
        infoDialog('livetv.py nicht geladen. Bitte Remote-Update durchführen.', icon='ERROR')
        directory(h, succeeded=False)
        return

    try:
        groups = mod.get_groups(_ch_cache_path())
    except Exception as e:
        infoDialog('Fehler beim Laden der Gruppen: %s' % e, icon='ERROR')
        directory(h, succeeded=False)
        return

    refresh_li = xbmcgui.ListItem(label='[COLOR gray]>> Aktualisieren (Kanäle)[/COLOR]')
    refresh_li.setArt({'thumb': 'DefaultAddonProgram.png', 'fanart': addonFanart()})
    refresh_li.setIsFolder(False)
    addItem(h, _url('liveTVRefresh'), refresh_li, False)

    for grp in groups:
        label = '%s  (%d)' % (grp['name'], grp['count'])
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': 'DefaultTVShows.png', 'icon': 'DefaultTVShows.png', 'fanart': addonFanart()})
        _t, _shim = get_video_tag(li); _t.setTitle(label);
        if _shim: _t.flush()
        li.setIsFolder(True)
        addItem(h, _url('liveTVGroup', group=quote_plus(grp['name'])), li, True)

    total = sum(g['count'] for g in groups)
    content(h, 'files')
    plugincategory(h, 'Live TV (%d)' % total)
    directory(h, cacheToDisc=True)


def show_group_channels(params):
    h = _h()
    group = unquote_plus(params.get('group', ''))

    mod = _get_mod()
    if mod is None:
        infoDialog('livetv.py nicht geladen. Bitte Remote-Update durchführen.', icon='ERROR')
        directory(h, succeeded=False)
        return

    try:
        channels = mod.get_group_channels(_ch_cache_path(), group)
    except Exception as e:
        infoDialog('Fehler beim Laden der Kanäle: %s' % e, icon='ERROR')
        directory(h, succeeded=False)
        return

    for ch in channels:
        label = mod.build_label(ch, {})
        plot = mod.build_plot(ch, {})
        thumb = ch.get('logo') or 'DefaultTVShows.png'
        fanart = ch.get('logo') or addonFanart()
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': fanart})
        tag, _shim = get_video_tag(li)
        tag.setTitle(ch['name'])
        tag.setPlot(plot)
        tag.setMediaType('video')
        if _shim: tag.flush()
        li.setIsFolder(False)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)
        play_url = _url(
            'liveTVPlay',
            ch_id=quote_plus(ch.get('id', '')),
            name=quote_plus(ch['name']),
        )
        addItem(h, play_url, li, False)

    content(h, 'files')
    plugincategory(h, 'Live TV - %s (%d)' % (group, len(channels)))
    directory(h, cacheToDisc=False)


def play_channel(params):
    h = _h()
    ch_id = unquote_plus(params.get('ch_id', ''))
    name = unquote_plus(params.get('name', 'Live TV'))

    mod = _get_mod()
    if mod is None:
        infoDialog('livetv.py nicht geladen. Bitte Remote-Update durchführen.', icon='ERROR')
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    try:
        channels = mod.get_channels(_ch_cache_path())
    except Exception as e:
        infoDialog('Fehler: %s' % e, icon='ERROR')
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    channel = next((c for c in channels if c.get('id') == ch_id), None)
    if not channel:
        infoDialog('Sender nicht gefunden', icon='ERROR')
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    stream_url = mod.resolve_stream(channel)
    if not stream_url:
        infoDialog('Stream konnte nicht aufgelöst werden.', icon='ERROR')
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    status = mod.probe_stream(stream_url, channel.get('page_url'))
    if status and status >= 400:
        infoDialog('Stream nicht erreichbar (HTTP %s)' % status, icon='WARNING')
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    from resources.lib import timeshift as _ts
    if _ts.is_enabled():
        _ts.play_channel_via_timeshift(stream_url, name, h)
        return

    playback_url = mod.build_kodi_url(stream_url, channel.get('page_url'))
    li = xbmcgui.ListItem(label=name, path=playback_url)
    li.setMimeType('application/x-mpegURL')
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(h, True, li)


def refresh_cache(params):
    remote.update_livetv(force=True)
    for path in (_ch_cache_path(),):
        if os.path.exists(path):
            try:
                os.remove(path)
            except Exception:
                pass
    mod = _get_mod()
    if mod is None:
        infoDialog('livetv.py nicht geladen. Bitte Remote-Update durchführen.', icon='ERROR')
        return
    try:
        channels = mod.get_channels(_ch_cache_path(), force_refresh=True)
        infoDialog('%d Kanäle geladen' % len(channels), icon='INFO')
    except Exception as e:
        infoDialog('Fehler: %s' % e, icon='ERROR')
    xbmc.executebuiltin('Container.Refresh')
