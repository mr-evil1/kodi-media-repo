import time
import threading
import xbmc
import xbmcgui
import xbmcplugin
from urllib.parse import quote_plus, unquote_plus
from resources.lib import tmdb, log, remote
from resources.lib.db import hoster_cache
from resources.lib.control import (
    sysaddon, syshandle, addonPoster, addonFanart,
    addItem, directory, plugincategory,
    getSetting, infoDialog, dialog_select, dialog_ok
)

progressDialog   = xbmcgui.DialogProgress()
progressDialogBG = xbmcgui.DialogProgressBG()


def _hosts_mode():
    try:    return int(getSetting('scout.hosts_mode') or 0)
    except: return 0


def _progress_dialog():
    return progressDialog if getSetting('progress.dialog') == '0' else progressDialogBG


def _count_qualities(sources):
    c = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0}
    for h in sources:
        q = (h[3] if len(h) > 3 else '').upper()
        if '4K' in q or '2160' in q: c['4K'] += 1
        elif '1080' in q:            c['1080p'] += 1
        elif '720' in q:             c['720p'] += 1
        else:                        c['SD'] += 1
    return c


def _get_scrapers():
    return remote.get_scout_scrapers()


def _cache_key(tmdb_id, mt, season, episode):
    return '%s_%s_%d_%d' % (tmdb_id, mt, int(season), int(episode))


def _query_scraper(scraper, all_names, year, season, episode, imdb_id, tmdb_id, sources, lock):
    site_name = getattr(scraper, 'SITE_NAME', '') or getattr(scraper, 'SITE_ID', '') or '?'
    found = []
    for t in all_names[:3]:
        try:
            found += list(scraper.get_hosters(
                title=t, year=year, season=season, episode=episode,
                imdb=imdb_id, tmdb=tmdb_id
            ))
        except TypeError:
            log.log('[%s] Scraper-Antwort ungültig (TypeError) – übersprungen' % site_name, log.LOGWARNING)
        except Exception:
            log.error()
    seen = set()
    deduped = []
    for h in found:
        from urllib.parse import urlparse as _up
        name_key = h[0].lower().strip() if h else ''
        netloc   = _up(h[1]).netloc.lower() if len(h) > 1 and h[1].startswith('http') else (h[1] if len(h) > 1 else '')
        key = (name_key, netloc)
        if key not in seen:
            seen.add(key)
            h = tuple(h)
            while len(h) < 5:
                h = h + ('',)
            deduped.append(h + (site_name,))
    with lock:
        sources.extend(deduped)


def _fetch_yts_magnet(imdb_id, title, year):
    try:
        from resources.lib import multiquest as _mq
        _API_BASES = [
            ('https://yts.gg/api/v2',         True),
            ('https://movies-api.accel.li/api/v2', False),
            ('https://yts.bz/api/v2',          False),
        ]
        torrents = None
        for base, cf in _API_BASES:
            try:
                resp = _mq.get('%s/movie_details.json' % base, params={'movie_id': imdb_id}, timeout=8, use_cf=cf)
                d = resp.json()
                movie = d.get('data', {}).get('movie', {})
                if movie and movie.get('id'):
                    torrents = movie.get('torrents', [])
                    break
            except Exception:
                pass
        if not torrents:
            for fb_base, cf in (('https://yts.gg/api/v2', True), ('https://movies-api.accel.li/api/v2', False), ('https://yts.bz/api/v2', False)):
                try:
                    resp = _mq.get('%s/list_movies.json' % fb_base, params={'query_term': imdb_id, 'limit': 5}, timeout=8, use_cf=cf)
                    d = resp.json()
                    movies = d.get('data', {}).get('movies', [])
                    if movies:
                        torrents = movies[0].get('torrents', [])
                        break
                except Exception:
                    pass
        if not torrents:
            return None, ''
        best = None
        for pref in ('2160p', '1080p', '720p'):
            for t in torrents:
                if t.get('quality') == pref:
                    best = t
                    break
            if best:
                break
        if not best:
            best = torrents[0]
        h = best.get('hash', '')
        q = best.get('quality', '')
        dn = '%s+%s' % (title.replace(' ', '+'), year)
        trackers = '&tr='.join([
            'udp://tracker.opentrackr.org:1337/announce',
            'udp://open.tracker.cl:1337/announce',
            'udp://tracker.openbittorrent.com:6969/announce',
        ])
        magnet = 'magnet:?xt=urn:btih:%s&dn=%s&tr=%s' % (h, dn, trackers)
        return magnet, q
    except Exception:
        log.error()
        return None, ''


def _fetch_eztv_magnet(imdb_id, season, episode):
    try:
        from resources.lib import multiquest as _mq
        import re as _re
        imdb_num = imdb_id.replace('tt', '')
        resp = _mq.get(
            'https://eztvx.to/api/get-torrents',
            params={'imdb_id': imdb_num, 'limit': 100},
            timeout=10
        )
        d = resp.json()
        torrents = d.get('torrents', [])
        pattern = _re.compile(r'[Ss]0*%d[Ee]0*%d' % (season, episode))
        matched = [t for t in torrents if pattern.search(t.get('title', '') or t.get('filename', ''))]
        if not matched:
            return None, ''
        for pref in ('1080p', '720p', '480p'):
            for t in matched:
                combined = (t.get('title', '') or '') + (t.get('filename', '') or '')
                if pref in combined:
                    return t.get('magnet_url', ''), pref
        return matched[0].get('magnet_url', ''), ''
    except Exception:
        log.error()
        return None, ''


def _rd_torrent_sources(meta, season=0, episode=0):
    try:
        from resources.lib import debrid as _deb
        rd = _deb.RealDebrid()
        if not rd.is_enabled() or not rd.token:
            return []
        imdb_id = meta.get('imdb_id', '')
        title   = meta.get('title', '')
        year    = str(meta.get('year', ''))
        if not imdb_id:
            return []
        is_movie = season == 0 and episode == 0
        if is_movie:
            magnet, quality = _fetch_yts_magnet(imdb_id, title, year)
        else:
            magnet, quality = _fetch_eztv_magnet(imdb_id, season, episode)
        if not magnet:
            log.log('[RD Torrent] Kein Magnet-Link gefunden')
            return []
        stream_url = rd.get_stream_from_magnet(magnet)
        if not stream_url:
            log.log('[RD Torrent] Kein Stream von RD erhalten')
            return []
        log.log('[RD Torrent] Stream bereit: %s' % stream_url[:60])
        return [(title, stream_url, True, quality, '', 'RD Torrent')]
    except Exception:
        log.error()
        return []


def getSources(meta, season=0, episode=0, timeout=20, scraper_timeout=10):
    scrapers = _get_scrapers()
    if not scrapers and getSetting('rd.torrent_enable') != 'true':
        return []

    title      = meta.get('title', '')
    year       = str(meta.get('year', ''))
    imdb_id    = meta.get('imdb_id', '')
    tmdb_id    = str(meta.get('tmdb_id', ''))
    alt_titles = meta.get('aliases', [])
    seen = {title}
    all_names = [title]
    for t in alt_titles:
        if t and t not in seen:
            seen.add(t)
            all_names.append(t)

    sources  = []
    lock     = threading.Lock()
    start_ts = time.time()

    threads = []
    for s in scrapers:
        t = threading.Thread(target=_query_scraper,
                             args=(s, all_names, year, season, episode, imdb_id, tmdb_id, sources, lock))
        t.daemon = True
        t.start()
        st = getattr(s, 'SCRAPER_TIMEOUT', scraper_timeout)
        threads.append((getattr(s, 'SITE_NAME', None) or getattr(s, '__name__', '?'), t, time.time(), st))

    if getSetting('rd.torrent_enable') == 'true':
        def _rd_torrent_thread():
            results = _rd_torrent_sources(meta, season, episode)
            with lock:
                sources.extend(results)
        _rdt = threading.Thread(target=_rd_torrent_thread)
        _rdt.daemon = True
        _rdt.start()
        threads.append(('RD Torrent', _rdt, time.time(), 25))

    dp = _progress_dialog()
    dp.create('MovieScout', '')
    dp.update(0, '4K: 0 | 1080p: 0 | 720p: 0 | SD: 0 | Total: 0')

    total_format = '[COLOR %s][B]%s[/B][/COLOR]'

    try:
        for i in range(0, 4 * timeout):
            try:
                if dp.iscanceled():
                    break
            except Exception:
                pass

            now   = time.time()
            alive = [name for name, t, ts, st in threads
                     if t.is_alive() and (now - ts) < st]

            with lock:
                current = list(sources)

            qc    = _count_qualities(current)
            total = len(current)

            def col(n):
                return total_format % ('red', n) if n == 0 else total_format % ('lime', n)

            line = ' 4K: %s | 1080p: %s | 720p: %s | SD: %s | Total: %s' % (
                col(qc['4K']), col(qc['1080p']), col(qc['720p']), col(qc['SD']), col(total))

            if len(alive) > 6:
                line += '                    Verbleibend: %d Scraper' % len(alive)
            elif alive:
                line += '                    Verbleibend: %s' % ', '.join(alive)
            else:
                line += '                    Suche beendet!'

            elapsed = time.time() - start_ts
            percent = min(99, int(100 * elapsed / timeout + 0.5))
            dp.update(max(1, percent), line)

            if not alive:
                break

            time.sleep(0.5)
    except Exception:
        log.error()

    time.sleep(0.8)
    try:    dp.close()
    except: pass

    seen_global = set()
    deduped_global = []
    for h in sources:
        from urllib.parse import urlparse as _up
        name_key = h[0].lower().strip() if h else ''
        netloc   = _up(h[1]).netloc.lower() if len(h) > 1 and h[1].startswith('http') else (h[1] if len(h) > 1 else '')
        key = (name_key, netloc)
        if key not in seen_global:
            seen_global.add(key)
            deduped_global.append(h)
    return deduped_global


def _play_from_hosters(hosters, title, meta, handle, params=None):
    if not hosters:
        infoDialog('Keine Streams gefunden.', icon='WARNING')
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    mode = _hosts_mode()

    if mode == 2:
        _open_listing(hosters, title, meta, params or {})
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if mode == 0 or len(hosters) == 1:
        _auto_play(hosters, title, meta, handle)
        return

    labels = ['%s  –  %s' % (h[0], h[1][:60]) for h in hosters]
    idx = dialog_select('[B]%s[/B]' % title, labels)
    if idx < 0:
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    _play_single(hosters[idx], title, meta, handle)


def _open_listing(hosters, title, meta, params):
    addon   = sysaddon()
    tmdb_id = meta.get('tmdb_id', '')
    mt      = params.get('mt', 'movie')
    season  = int(params.get('season', 0))
    episode = int(params.get('episode', 0))
    key     = _cache_key(tmdb_id, mt, season, episode)
    hoster_cache.set(key, hosters)
    url = '%s?action=scoutListing&tmdb_id=%s&mt=%s&season=%d&episode=%d' % (
        addon, tmdb_id, mt, season, episode)
    xbmc.executebuiltin('Container.Update(%s)' % url)


_EVIL_PRIORITY_HOSTS = (
    'vidara.', 'vidaraa.', 'vidsonic.', 'vidmatrixa.', 'viewdara.', 'thebesthosterv.',
    'dr0pstream.', 'supervideo.', 'mixdrop.', 'meinecloud.',
    'kinoger.pw', 'kinoger.be', 'fsst.online', 'playmate.', 'dood.',
)

def _resolve_url(url):
    try:
        from resources.lib import debrid as _deb
        if _deb.is_any_active():
            resolved, svc = _deb.resolve_url(url)
            if resolved:
                log.log('[Scout] Debrid aufgelöst via %s' % svc)
                from resources.lib.control import infoDialog
                infoDialog('%s ✓' % svc, title='Debrid', icon='INFO', time=3000)
                return resolved
    except Exception:
        log.error()
    try:
        evil = remote.get_evil_resolver()
        if evil and any(h in url.lower() for h in _EVIL_PRIORITY_HOSTS):
            resolved, ok = evil.resolve(url)
            if ok:
                log.log('[Scout] evil.py (priority) aufgelöst: %s' % resolved[:80])
                return resolved
    except Exception:
        log.error()
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url=url, include_disabled=False, include_universal=False)
        if hmf.valid_url():
            return hmf.resolve()
    except Exception:
        log.error()
    try:
        evil = remote.get_evil_resolver()
        if evil:
            resolved, ok = evil.resolve(url)
            if ok:
                log.log('[Scout] evil.py aufgelöst: %s' % resolved[:80])
                return resolved
    except Exception:
        log.error()
    return url


def _auto_play(hosters, title, meta, handle):
    for h in hosters:
        try:
            url         = h[1]
            is_resolved = h[2] if len(h) > 2 else False
            if not is_resolved:
                url = _resolve_url(url)
            if getSetting('debug.url') == 'true':
                dialog_ok('Debug – Player URL', url)
            _deliver(title, url, meta, handle)
            return
        except Exception:
            log.error()
    infoDialog('Kein spielbarer Stream gefunden.', icon='WARNING')
    if handle is not None:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def _play_single(h, title, meta, handle):
    url         = h[1]
    is_resolved = h[2] if len(h) > 2 else False
    if not is_resolved:
        url = _resolve_url(url)
    if getSetting('debug.url') == 'true':
        dialog_ok('Debug – Player URL', url)
    _deliver(title, url, meta, handle)


def _deliver(title, url, meta, handle):
    if handle is not None:
        li = xbmcgui.ListItem(label=title)
        li.setProperty('IsPlayable', 'true')
        li.setPath(url)
        xbmcplugin.setResolvedUrl(handle, True, li)
    else:
        from resources.lib.player import Player
        Player().run(title, url, meta)


def scout_movie(params):
    handle  = syshandle()
    tmdb_id = params.get('tmdb_id')
    try:
        meta = tmdb.get_movie(tmdb_id)
        if not meta:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        title    = meta.get('title', '')
        scrapers = _get_scrapers()
        if not scrapers and getSetting('rd.torrent_enable') != 'true':
            dialog_ok('Scout', 'Keine Scraper verfügbar.\n\nBitte Remote-Update unter:\nWerkzeuge → Scraper Manager')
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        hosters = getSources(meta)
        _play_from_hosters(hosters, title, meta, handle, params={'mt': 'movie', 'tmdb_id': tmdb_id, 'season': 0, 'episode': 0})
    except Exception:
        log.error()
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def scout_episode(params):
    handle  = syshandle()
    tmdb_id = params.get('tmdb_id')
    title   = unquote_plus(params.get('title', ''))
    season  = int(params.get('season', 1))
    episode = int(params.get('episode', 1))
    try:
        show = tmdb.get_tvshow(tmdb_id)
        if not show:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        show['title'] = title
        ep_label = '%s S%02dE%02d' % (title, season, episode)
        scrapers = _get_scrapers()
        if not scrapers and getSetting('rd.torrent_enable') != 'true':
            dialog_ok('Scout', 'Keine Scraper verfügbar.\n\nBitte Remote-Update unter:\nWerkzeuge → Scraper Manager')
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        hosters = getSources(show, season=season, episode=episode)
        _play_from_hosters(hosters, ep_label, show, handle, params={'mt': 'tv', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode})
    except Exception:
        log.error()
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def show_as_listing(params):
    handle  = syshandle()
    addon   = sysaddon()
    tmdb_id = params.get('tmdb_id')
    season  = int(params.get('season', 0))
    episode = int(params.get('episode', 0))
    mt      = params.get('mt', 'movie')

    if mt == 'movie':
        meta = tmdb.get_movie(tmdb_id)
    else:
        meta = tmdb.get_tvshow(tmdb_id)
    if not meta:
        directory(handle, succeeded=False)
        return

    title   = meta.get('title', '')
    poster  = meta.get('poster', addonPoster())
    fanart  = meta.get('fanart', addonFanart())
    key     = _cache_key(tmdb_id, mt, season, episode)
    cached  = hoster_cache.get(key)

    if cached is not None:
        hosters = cached
    else:
        hosters = getSources(meta, season=season, episode=episode)
        if hosters:
            hoster_cache.set(key, hosters)

    hoster_cache.cleanup()

    try:
        blocked = remote.get_blocked_hosters()
        if blocked:
            def _is_blocked(h):
                from urllib.parse import urlparse as _up
                domain = _up(h[1]).netloc.lower() if len(h) > 1 and h[1].startswith('http') else ''
                name_l = h[0].lower() if h else ''
                return domain in blocked or name_l in blocked
            hosters = [h for h in hosters if not _is_blocked(h)]
    except Exception:
        log.error()

    if getSetting('general.german_only') == 'true':
        import re as _re
        _LANG_RE = _re.compile(r'\(([a-zA-Z]{2,3})\)\s*$')
        def _is_german(h):
            lang = (h[4] if len(h) > 4 else '').lower().strip()
            if not lang:
                m = _LANG_RE.search((h[0] if h else '').strip())
                if m:
                    lang = m.group(1).lower()
                else:
                    return True
            return 'de' in lang or 'ger' in lang or 'deutsch' in lang
        hosters = [h for h in hosters if _is_german(h)]

    def _quality_rank(h):
        q = (h[3] if len(h) > 3 else '').upper()
        if '4K' in q or '2160' in q: return 0
        if '1080' in q:              return 1
        if '720' in q:               return 2
        return 3

    hosters = sorted(hosters, key=_quality_rank)

    xbmcplugin.setContent(handle, 'files')
    plugincategory(handle, title)

    for i, h in enumerate(hosters, 1):
        hname        = h[0]
        hurl         = h[1]
        quality      = h[3] if len(h) > 3 else ''
        lang         = h[4] if len(h) > 4 else ''
        scraper_name = h[5] if len(h) > 5 else ''
        from urllib.parse import urlparse as _up
        domain  = _up(hurl).netloc.upper() if hurl.startswith('http') else hurl[:30].upper()

        parts = ['[B]%s[/B]' % hname.upper(), domain]
        if quality:
            parts.append('[I]%s[/I]' % quality.upper())
        if lang:
            parts.append('[I]%s[/I]' % lang.upper())
        if scraper_name:
            parts.append('[COLOR orange]%s[/COLOR]' % scraper_name)
        label = '%02d | %s' % (i, ' | '.join(parts))

        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': poster, 'poster': poster, 'fanart': fanart})
        li.setIsFolder(False)
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': label, 'mediatype': 'video'})

        url = '%s?action=scoutPlay&title=%s&url=%s&tmdb_id=%s&mt=%s&season=%d&episode=%d' % (
            addon, quote_plus('%s – %s' % (title, hname)), quote_plus(hurl), tmdb_id, mt, season, episode)
        cm_refresh = ('Neu suchen', 'RunPlugin(%s?action=scoutRefresh&tmdb_id=%s&mt=%s&season=%d&episode=%d)' % (
            addon, tmdb_id, mt, season, episode))
        cm_dl = ('Download', 'RunPlugin(%s?action=download&title=%s&url=%s&mt=%s)' % (
            addon, quote_plus(title), quote_plus(hurl), mt))
        li.addContextMenuItems([cm_refresh, cm_dl])
        addItem(handle, url, li, False)

    if not hosters:
        infoDialog('Keine Streams gefunden.', icon='WARNING')
    directory(handle, cacheToDisc=False)


def refresh_listing(params):
    tmdb_id = params.get('tmdb_id')
    mt      = params.get('mt', 'movie')
    season  = int(params.get('season', 0))
    episode = int(params.get('episode', 0))
    key     = _cache_key(tmdb_id, mt, season, episode)
    hoster_cache.delete(key)
    addon = sysaddon()
    url   = '%s?action=scoutListing&tmdb_id=%s&mt=%s&season=%d&episode=%d' % (
        addon, tmdb_id, mt, season, episode)
    xbmc.executebuiltin('Container.Update(%s,replace)' % url)


def play_direct(params):
    handle = syshandle()
    title  = unquote_plus(params.get('title', ''))
    url    = unquote_plus(params.get('url', ''))
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        url = _resolve_url(url)
    except Exception:
        log.error()
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    if getSetting('debug.url') == 'true':
        dialog_ok('Debug – Player URL', url)
    li = xbmcgui.ListItem(label=title)
    li.setProperty('IsPlayable', 'true')
    li.setPath(url)
    xbmcplugin.setResolvedUrl(handle, bool(url), li)
