# -*- coding: utf-8 -*-
"""
MovieScout – Premium/Debrid Auth-Navigation
Verwaltet Auth-Flows für RealDebrid, Premiumize, AllDebrid, Debrid-Link.
"""

import xbmcgui
import xbmcplugin
from resources.lib import log, debrid
from resources.lib.control import syshandle, addonName, infoDialog, keyboard, setSetting


def _end(handle):
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


# ── Real-Debrid ───────────────────────────────────────────────────────────────

def auth_rd():
    handle = syshandle()
    rd = debrid.RealDebrid()
    data = rd.start_auth()
    if not data or not data.get('user_code'):
        infoDialog('Real-Debrid: Server nicht erreichbar.', icon='ERROR')
        _end(handle)
        return

    user_code   = data.get('user_code', '')
    verify_url  = data.get('verification_url', 'real-debrid.com/device')
    device_code = data.get('device_code', '')
    expires_in  = int(data.get('expires_in', 600))
    interval    = int(data.get('interval', 5))

    xbmcgui.Dialog().ok(
        'Real-Debrid autorisieren',
        '1. Öffne [B]%s[/B]\n'
        '2. Gib diesen Code ein:  [B][COLOR yellow]%s[/COLOR][/B]\n\n'
        'Dann OK drücken – der Dialog wartet auf Bestätigung.' % (verify_url, user_code)
    )

    if rd.poll_auth(device_code, interval, expires_in):
        user = rd.get_user()
        infoDialog('Real-Debrid verbunden: %s' % user.get('username', ''))
    else:
        infoDialog('Real-Debrid: Autorisierung fehlgeschlagen.', icon='ERROR')
    _end(handle)


def auth_rd_token():
    handle = syshandle()
    kb = keyboard('', 'Real-Debrid API Token')
    kb.doModal()
    if not kb.isConfirmed():
        _end(handle)
        return
    token = kb.getText().strip()
    if not token:
        _end(handle)
        return
    setSetting('rd.token', token)
    setSetting('rd.enabled', 'true')
    setSetting('rd.refresh_token', '')
    setSetting('rd.client_secret', '')
    setSetting('rd.client_id_custom', '')
    rd = debrid.RealDebrid()
    user = rd.get_user()
    if user.get('username'):
        infoDialog('Real-Debrid verbunden: %s' % user['username'])
    else:
        infoDialog('Real-Debrid: Token gespeichert (Benutzer nicht abrufbar).', icon='WARNING')
    _end(handle)


def logout_rd():
    handle = syshandle()
    if xbmcgui.Dialog().yesno(addonName(), 'Real-Debrid abmelden?'):
        debrid.RealDebrid().logout()
        infoDialog('Real-Debrid abgemeldet.')
    _end(handle)


# ── Premiumize.me ─────────────────────────────────────────────────────────────

def logout_pm():
    handle = syshandle()
    if xbmcgui.Dialog().yesno(addonName(), 'Premiumize.me abmelden?'):
        debrid.Premiumize().logout()
        infoDialog('Premiumize.me abgemeldet.')
    _end(handle)


# ── AllDebrid ─────────────────────────────────────────────────────────────────

def auth_ad():
    handle = syshandle()
    ad   = debrid.AllDebrid()
    data = ad.start_auth()
    if not data or not data.get('pin'):
        infoDialog('AllDebrid: Server nicht erreichbar.', icon='ERROR')
        _end(handle)
        return

    pin        = data.get('pin', '')
    base_url   = data.get('base_url', 'https://alldebrid.com/pin/')
    check      = data.get('check', '')
    expires_in = int(data.get('expires_in', 600))

    xbmcgui.Dialog().ok(
        'AllDebrid autorisieren',
        '1. Öffne [B]%s%s[/B]\n'
        '2. PIN:  [B][COLOR yellow]%s[/COLOR][/B]\n\n'
        'Dann OK drücken – der Dialog wartet auf Bestätigung.' % (base_url, pin, pin)
    )

    if ad.poll_auth(check, pin, expires_in):
        user = ad.get_user()
        infoDialog('AllDebrid verbunden: %s' % user.get('username', ''))
    else:
        infoDialog('AllDebrid: Autorisierung fehlgeschlagen.', icon='ERROR')
    _end(handle)


def logout_ad():
    handle = syshandle()
    if xbmcgui.Dialog().yesno(addonName(), 'AllDebrid abmelden?'):
        debrid.AllDebrid().logout()
        infoDialog('AllDebrid abgemeldet.')
    _end(handle)


# ── Debrid-Link ───────────────────────────────────────────────────────────────

def auth_dl():
    handle = syshandle()
    dl   = debrid.DebridLink()
    data = dl.start_auth()
    if not data or not data.get('user_code'):
        infoDialog('Debrid-Link: Server nicht erreichbar.', icon='ERROR')
        _end(handle)
        return

    user_code   = data.get('user_code', '')
    verify_url  = data.get('verification_uri', 'debrid-link.com/pin')
    device_code = data.get('device_code', '')
    expires_in  = int(data.get('expires_in', 600))
    interval    = int(data.get('interval', 5))

    xbmcgui.Dialog().ok(
        'Debrid-Link autorisieren',
        '1. Öffne [B]%s[/B]\n'
        '2. Gib diesen Code ein:  [B][COLOR yellow]%s[/COLOR][/B]\n\n'
        'Dann OK drücken – der Dialog wartet auf Bestätigung.' % (verify_url, user_code)
    )

    if dl.poll_auth(device_code, interval, expires_in):
        user = dl.get_user()
        infoDialog('Debrid-Link verbunden: %s' % user.get('email', ''))
    else:
        infoDialog('Debrid-Link: Autorisierung fehlgeschlagen.', icon='ERROR')
    _end(handle)


def logout_dl():
    handle = syshandle()
    if xbmcgui.Dialog().yesno(addonName(), 'Debrid-Link abmelden?'):
        debrid.DebridLink().logout()
        infoDialog('Debrid-Link abgemeldet.')
    _end(handle)
