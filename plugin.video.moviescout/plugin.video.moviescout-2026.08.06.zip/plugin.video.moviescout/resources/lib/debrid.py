# -*- coding: utf-8 -*-
"""
MovieScout – Premium / Debrid Integration
Dienste: Real-Debrid, Premiumize.me, AllDebrid, Debrid-Link
Portiert und angepasst aus plugin.video.streams/debrid.py
"""

import json
import time
import xbmc
import xbmcgui
from resources.lib import log
from resources.lib.control import getSetting, setSetting, addonName

# ── HTTP-Helper (ohne externe Abhängigkeiten) ─────────────────────────────────

def _http(method, url, data=None, headers=None, token=None, timeout=15):
    from urllib.request import Request, urlopen
    from urllib.parse import urlencode
    from urllib.error import HTTPError, URLError

    h = {'User-Agent': 'Mozilla/5.0 (Kodi; MovieScout)', 'Accept': 'application/json'}
    if token:
        h['Authorization'] = 'Bearer %s' % token
    if headers:
        h.update(headers)

    body = None
    if data and method.upper() == 'POST':
        if isinstance(data, bytes):
            body = data
        elif isinstance(data, dict):
            body = urlencode(data).encode('utf-8')
            h.setdefault('Content-Type', 'application/x-www-form-urlencoded')
    elif data and method.upper() == 'GET':
        sep = '&' if '?' in url else '?'
        url = url + sep + urlencode(data)

    req = Request(url, data=body, headers=h, method=method.upper())
    try:
        with urlopen(req, timeout=timeout) as r:
            raw = r.read().decode('utf-8', errors='replace')
            try:
                return r.status, json.loads(raw)
            except Exception:
                return r.status, raw
    except HTTPError as e:
        raw = e.read().decode('utf-8', errors='replace')
        try:
            return e.code, json.loads(raw)
        except Exception:
            return e.code, raw
    except (URLError, Exception) as e:
        log.log('[Debrid] HTTP-Fehler %s: %s' % (url[:60], e))
        return 0, str(e)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# REAL-DEBRID
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class RealDebrid:
    BASE      = 'https://api.real-debrid.com/rest/1.0'
    CLIENT_ID = 'X245A4XAIBGVM'   # Standard Open-Source-Client-ID

    def __init__(self):
        self.token   = getSetting('rd.token')
        self.refresh = getSetting('rd.refresh_token')

    def is_enabled(self):
        return getSetting('rd.enabled') == 'true'

    def start_auth(self):
        _, d = _http('GET', 'https://api.real-debrid.com/oauth/v2/device/code',
                     data={'client_id': self.CLIENT_ID, 'new_credentials': 'yes'})
        return d if isinstance(d, dict) else {}

    def poll_auth(self, device_code, interval=5, expires_in=600):
        deadline = time.time() + expires_in
        dp = xbmcgui.DialogProgress()
        dp.create(addonName(), 'Warte auf Real-Debrid Bestätigung...')
        try:
            while time.time() < deadline:
                if dp.iscanceled():
                    break
                pct = int(100 * (1.0 - (deadline - time.time()) / expires_in))
                dp.update(pct)
                xbmc.sleep(interval * 1000)
                _, d = _http('POST', 'https://api.real-debrid.com/oauth/v2/device/credentials',
                             data={'client_id': self.CLIENT_ID, 'code': device_code})
                if isinstance(d, dict) and d.get('client_secret'):
                    cid = d.get('client_id', self.CLIENT_ID)
                    cs  = d['client_secret']
                    setSetting('rd.client_id_custom', cid)
                    setSetting('rd.client_secret', cs)
                    dp.close()
                    return self._fetch_token(cid, cs, device_code)
        except Exception:
            log.error()
        dp.close()
        return False

    def _fetch_token(self, cid, cs, code):
        _, d = _http('POST', 'https://api.real-debrid.com/oauth/v2/token', data={
            'client_id': cid, 'client_secret': cs, 'code': code,
            'grant_type': 'http://oauth.net/grant_type/device/1.0'})
        if isinstance(d, dict) and d.get('access_token'):
            setSetting('rd.token',         d['access_token'])
            setSetting('rd.refresh_token', d.get('refresh_token', ''))
            self.token = d['access_token']
            return True
        return False

    def _refresh(self):
        cid = getSetting('rd.client_id_custom') or self.CLIENT_ID
        cs  = getSetting('rd.client_secret')
        if not cs or not self.refresh:
            return False
        _, d = _http('POST', 'https://api.real-debrid.com/oauth/v2/token', data={
            'client_id': cid, 'client_secret': cs, 'code': self.refresh,
            'grant_type': 'http://oauth.net/grant_type/device/1.0'})
        if isinstance(d, dict) and d.get('access_token'):
            setSetting('rd.token', d['access_token'])
            self.token = d['access_token']
            return True
        return False

    def is_logged_in(self):
        if not self.token:
            return False
        s, _ = _http('GET', self.BASE + '/user', token=self.token)
        if s == 401:
            return self._refresh()
        return s == 200

    def get_user(self):
        _, d = _http('GET', self.BASE + '/user', token=self.token)
        return d if isinstance(d, dict) else {}

    def resolve(self, url):
        if not self.token:
            return None
        s, d = _http('POST', self.BASE + '/unrestrict/link',
                     data={'link': url}, token=self.token)
        if s == 401 and self._refresh():
            s, d = _http('POST', self.BASE + '/unrestrict/link',
                         data={'link': url}, token=self.token)
        if isinstance(d, dict) and d.get('download'):
            log.log('[RD] aufgelöst: %s' % d['download'][:60])
            return d['download']
        return None

    def add_magnet(self, magnet):
        s, d = _http('POST', self.BASE + '/torrents/addMagnet',
                     data={'magnet': magnet}, token=self.token)
        if s == 401 and self._refresh():
            s, d = _http('POST', self.BASE + '/torrents/addMagnet',
                         data={'magnet': magnet}, token=self.token)
        if isinstance(d, dict) and d.get('id'):
            return d['id']
        return None

    def _select_files(self, torrent_id):
        _http('POST', self.BASE + '/torrents/selectFiles/' + torrent_id,
              data={'files': 'all'}, token=self.token)

    def _torrent_info(self, torrent_id):
        _, d = _http('GET', self.BASE + '/torrents/info/' + torrent_id,
                     token=self.token)
        return d if isinstance(d, dict) else {}

    def get_stream_from_magnet(self, magnet, timeout=22):
        torrent_id = self.add_magnet(magnet)
        if not torrent_id:
            return None
        self._select_files(torrent_id)
        deadline = time.time() + timeout
        while time.time() < deadline:
            info = self._torrent_info(torrent_id)
            status = info.get('status', '')
            if status == 'downloaded':
                links = info.get('links', [])
                if links:
                    resolved = self.resolve(links[0])
                    return resolved or links[0]
                return None
            if status in ('error', 'dead', 'magnet_error'):
                log.log('[RD Torrent] Fehler-Status: %s' % status)
                return None
            time.sleep(3)
        log.log('[RD Torrent] Timeout beim Warten auf Status')
        return None

    def logout(self):
        for k in ('rd.token', 'rd.refresh_token', 'rd.client_secret', 'rd.client_id_custom'):
            setSetting(k, '')
        self.token = ''


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PREMIUMIZE.ME
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class Premiumize:
    BASE = 'https://www.premiumize.me/api'

    def __init__(self):
        self.api_key = getSetting('pm.api_key')

    def is_enabled(self):
        return getSetting('pm.enabled') == 'true'

    def is_logged_in(self):
        if not self.api_key:
            return False
        s, d = _http('GET', self.BASE + '/account/info', data={'apikey': self.api_key})
        return s == 200 and isinstance(d, dict) and d.get('status') == 'success'

    def get_user(self):
        _, d = _http('GET', self.BASE + '/account/info', data={'apikey': self.api_key})
        return d if isinstance(d, dict) else {}

    def resolve(self, url):
        if not self.api_key:
            return None
        _, d = _http('GET', self.BASE + '/transfer/directdl',
                     data={'apikey': self.api_key, 'src': url})
        if isinstance(d, dict) and d.get('status') == 'success':
            content = d.get('content', [])
            if content:
                best = max(content, key=lambda x: int(x.get('size', 0) or 0))
                link = best.get('link', '')
                log.log('[PM] aufgelöst: %s' % link[:60])
                return link
        return None

    def logout(self):
        setSetting('pm.api_key', '')
        self.api_key = ''


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ALLDEBRID
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class AllDebrid:
    BASE  = 'https://api.alldebrid.com/v4'
    AGENT = 'moviescout_kodi'

    def __init__(self):
        self.token = getSetting('ad.token')

    def is_enabled(self):
        return getSetting('ad.enabled') == 'true'

    def start_auth(self):
        _, d = _http('GET', self.BASE + '/pin/get', data={'agent': self.AGENT})
        return d.get('data', {}) if isinstance(d, dict) else {}

    def poll_auth(self, check, pin, expires_in=600):
        deadline = time.time() + expires_in
        dp = xbmcgui.DialogProgress()
        dp.create(addonName(), 'Warte auf AllDebrid Bestätigung...')
        try:
            while time.time() < deadline:
                if dp.iscanceled():
                    break
                pct = int(100 * (1.0 - (deadline - time.time()) / expires_in))
                dp.update(pct)
                xbmc.sleep(5000)
                _, d = _http('GET', self.BASE + '/pin/check',
                             data={'agent': self.AGENT, 'check': check, 'pin': pin})
                if isinstance(d, dict):
                    data = d.get('data', {})
                    if data.get('activated') and data.get('apikey'):
                        setSetting('ad.token', data['apikey'])
                        self.token = data['apikey']
                        dp.close()
                        return True
        except Exception:
            log.error()
        dp.close()
        return False

    def is_logged_in(self):
        if not self.token:
            return False
        s, _ = _http('GET', self.BASE + '/user', data={'agent': self.AGENT, 'apikey': self.token})
        return s == 200

    def get_user(self):
        _, d = _http('GET', self.BASE + '/user', data={'agent': self.AGENT, 'apikey': self.token})
        return d.get('data', {}).get('user', {}) if isinstance(d, dict) else {}

    def resolve(self, url):
        if not self.token:
            return None
        _, d = _http('GET', self.BASE + '/link/unlock',
                     data={'agent': self.AGENT, 'apikey': self.token, 'link': url})
        if isinstance(d, dict):
            link = d.get('data', {}).get('link')
            if link:
                log.log('[AD] aufgelöst: %s' % link[:60])
                return link
        return None

    def logout(self):
        setSetting('ad.token', '')
        self.token = ''


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# DEBRID-LINK
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class DebridLink:
    BASE = 'https://debrid-link.com/api/v2'

    def __init__(self):
        self.token   = getSetting('dl.token')
        self.refresh = getSetting('dl.refresh_token')

    def is_enabled(self):
        return getSetting('dl.enabled') == 'true'

    def start_auth(self):
        _, d = _http('GET', 'https://debrid-link.com/api/oauth/device/code',
                     data={'client_id': 'debridlink',
                           'scope': 'get.post.account.links'})
        return d if isinstance(d, dict) else {}

    def poll_auth(self, device_code, interval=5, expires_in=600):
        deadline = time.time() + expires_in
        dp = xbmcgui.DialogProgress()
        dp.create(addonName(), 'Warte auf Debrid-Link Bestätigung...')
        try:
            while time.time() < deadline:
                if dp.iscanceled():
                    break
                pct = int(100 * (1.0 - (deadline - time.time()) / expires_in))
                dp.update(pct)
                xbmc.sleep(interval * 1000)
                _, d = _http('POST', 'https://debrid-link.com/api/oauth/token', data={
                    'client_id': 'debridlink',
                    'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
                    'device_code': device_code})
                if isinstance(d, dict) and d.get('access_token'):
                    setSetting('dl.token',         d['access_token'])
                    setSetting('dl.refresh_token', d.get('refresh_token', ''))
                    self.token = d['access_token']
                    dp.close()
                    return True
        except Exception:
            log.error()
        dp.close()
        return False

    def is_logged_in(self):
        if not self.token:
            return False
        s, _ = _http('GET', self.BASE + '/account/infos', token=self.token)
        return s == 200

    def get_user(self):
        _, d = _http('GET', self.BASE + '/account/infos', token=self.token)
        return d.get('value', {}) if isinstance(d, dict) else {}

    def resolve(self, url):
        if not self.token:
            return None
        _, d = _http('POST', self.BASE + '/downloader/add',
                     data={'url': url}, token=self.token)
        if isinstance(d, dict):
            files = d.get('value', {}).get('files', [])
            if files:
                best = max(files, key=lambda x: x.get('size', 0))
                link = best.get('downloadUrl', '')
                if link:
                    log.log('[DL] aufgelöst: %s' % link[:60])
                    return link
        return None

    def logout(self):
        setSetting('dl.token', '')
        setSetting('dl.refresh_token', '')
        self.token = ''


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# UNIFIED API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

_SERVICES = [
    ('realdebrid', 'Real-Debrid',    RealDebrid),
    ('premiumize', 'Premiumize.me',  Premiumize),
    ('alldebrid',  'AllDebrid',      AllDebrid),
    ('debridlink', 'Debrid-Link',    DebridLink),
]


def get_all():
    """Gibt Liste von (key, name, instanz) für alle Dienste zurück."""
    return [(key, name, cls()) for key, name, cls in _SERVICES]


def is_any_active():
    """True wenn mindestens ein Dienst aktiviert und eingeloggt ist."""
    for key, name, cls in _SERVICES:
        svc = cls()
        if svc.is_enabled() and (getattr(svc, 'token', '') or getattr(svc, 'api_key', '')):
            return True
    return False


def resolve_url(url):
    """
    Löst URL mit dem ersten aktiven Debrid-Dienst auf.
    Gibt (resolved_url, dienstname) zurück oder (None, None).
    """
    for key, name, cls in _SERVICES:
        svc = cls()
        if not svc.is_enabled():
            continue
        if not getattr(svc, 'token', '') and not getattr(svc, 'api_key', ''):
            continue
        try:
            resolved = svc.resolve(url)
            if resolved:
                return resolved, name
        except Exception:
            log.error()
    return None, None
