# -*- coding: utf-8 -*-
"""
MovieScout – Trakt.tv Integration
Full OAuth2 device-auth, scrobbling, watchlist, history, trending/popular.
"""

import time
import xbmc
import xbmcgui
from resources.lib import log
from resources.lib.control import getSetting, setSetting, addonName

TRAKT_BASE = 'https://api.trakt.tv'

# ── Settings accessors ────────────────────────────────────────────────────────

def _client_id():     return getSetting('trakt.client_id').strip()
def _client_secret(): return getSetting('trakt.client_secret').strip()
def _access_token():  return getSetting('trakt.access_token').strip()
def _refresh_token(): return getSetting('trakt.refresh_token').strip()

def is_enabled():
    return getSetting('trakt.enable') == 'true'

def is_authorized():
    return bool(is_enabled() and _client_id() and _access_token())

def is_scrobble_on():
    return is_authorized() and getSetting('trakt.scrobble') == 'true'

# ── HTTP ──────────────────────────────────────────────────────────────────────

def _headers():
    h = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': _client_id(),
    }
    tok = _access_token()
    if tok:
        h['Authorization'] = 'Bearer ' + tok
    return h


def _request(method, endpoint, data=None, params=None, _retried=False):
    try:
        import requests as req
        r = req.request(method, TRAKT_BASE + endpoint,
                        headers=_headers(), json=data,
                        params=params, timeout=15)
        if r.status_code == 401 and not _retried:
            if _do_refresh():
                return _request(method, endpoint, data=data, params=params, _retried=True)
            return None
        if r.status_code in (200, 201):
            try:
                return r.json()
            except Exception:
                return {}
        return None
    except Exception:
        log.error()
        return None


def _get(endpoint, params=None):
    return _request('GET', endpoint, params=params)


def _post(endpoint, data=None):
    return _request('POST', endpoint, data=data)

# ── Token refresh ─────────────────────────────────────────────────────────────

def _do_refresh():
    rt = _refresh_token()
    if not rt or not _client_id() or not _client_secret():
        return False
    try:
        import requests as req
        r = req.post(TRAKT_BASE + '/oauth/token',
                     json={
                         'refresh_token': rt,
                         'client_id': _client_id(),
                         'client_secret': _client_secret(),
                         'redirect_uri': 'urn:ietf:wg:oauth:2.0:oob',
                         'grant_type': 'refresh_token',
                     },
                     headers={'Content-Type': 'application/json'},
                     timeout=15)
        if r.ok:
            d = r.json()
            setSetting('trakt.access_token', d.get('access_token', ''))
            setSetting('trakt.refresh_token', d.get('refresh_token', rt))
            return True
    except Exception:
        log.error()
    return False

# ── Device-Auth (OAuth2) ──────────────────────────────────────────────────────

def start_device_auth():
    """POST /oauth/device/code → returns dict with user_code, device_code etc."""
    if not _client_id():
        return None
    try:
        import requests as req
        r = req.post(TRAKT_BASE + '/oauth/device/code',
                     json={'client_id': _client_id()},
                     headers={'Content-Type': 'application/json'},
                     timeout=15)
        r.raise_for_status()
        return r.json()
    except Exception:
        log.error()
        return None


def poll_device_auth(device_code, interval=5, expires_in=600):
    """Poll /oauth/device/token until authorised. Returns True on success."""
    data = {
        'code': device_code,
        'client_id': _client_id(),
        'client_secret': _client_secret(),
    }
    headers = {'Content-Type': 'application/json'}
    deadline = time.time() + expires_in
    dp = xbmcgui.DialogProgress()
    dp.create(addonName(), 'Warte auf Trakt-Bestätigung...')
    try:
        import requests as req
        while time.time() < deadline:
            if dp.iscanceled():
                break
            elapsed = deadline - time.time()
            pct = int(100 * (1.0 - elapsed / expires_in))
            dp.update(pct, 'Bitte auf trakt.tv/activate einloggen...')
            xbmc.sleep(max(int(interval), 5) * 1000)
            try:
                r = req.post(TRAKT_BASE + '/oauth/device/token',
                             json=data, headers=headers, timeout=15)
                if r.status_code == 200:
                    d = r.json()
                    setSetting('trakt.access_token', d.get('access_token', ''))
                    setSetting('trakt.refresh_token', d.get('refresh_token', ''))
                    dp.close()
                    return True
                elif r.status_code == 400:
                    continue   # still pending
                elif r.status_code in (404, 409, 410, 418, 429):
                    break      # expired / denied
            except Exception:
                pass
    except Exception:
        log.error()
    dp.close()
    return False


def logout():
    setSetting('trakt.access_token', '')
    setSetting('trakt.refresh_token', '')

# ── Scrobbling ────────────────────────────────────────────────────────────────

def _scrobble_payload(meta, progress):
    mt = meta.get('mediatype', 'movie')
    ids = {}
    if meta.get('imdb_id'):
        ids['imdb'] = meta['imdb_id']
    if meta.get('tmdb_id'):
        try:
            ids['tmdb'] = int(meta['tmdb_id'])
        except (ValueError, TypeError):
            pass
    pct = round(min(max(float(progress), 0.0), 100.0), 1)
    if mt == 'movie':
        return {
            'movie': {
                'title': meta.get('title', ''),
                'year': meta.get('year') or None,
                'ids': ids,
            },
            'progress': pct,
        }
    else:
        show_ids = dict(ids)
        return {
            'show': {
                'title': meta.get('tvshowtitle') or meta.get('title', ''),
                'ids': show_ids,
            },
            'episode': {
                'season': int(meta.get('season') or 1),
                'number': int(meta.get('episode') or 1),
            },
            'progress': pct,
        }


def scrobble_start(meta, progress=0.0):
    if not is_scrobble_on():
        return
    try:
        _post('/scrobble/start', _scrobble_payload(meta, progress))
        log.log('[Trakt] scrobble/start: %s' % meta.get('title', ''))
    except Exception:
        log.error()


def scrobble_pause(meta, progress):
    if not is_scrobble_on():
        return
    try:
        _post('/scrobble/pause', _scrobble_payload(meta, progress))
        log.log('[Trakt] scrobble/pause: %s @ %.1f%%' % (meta.get('title', ''), progress))
    except Exception:
        log.error()


def scrobble_stop(meta, progress):
    if not is_scrobble_on():
        return
    try:
        _post('/scrobble/stop', _scrobble_payload(meta, progress))
        log.log('[Trakt] scrobble/stop: %s @ %.1f%%' % (meta.get('title', ''), progress))
    except Exception:
        log.error()

# ── Watchlist ─────────────────────────────────────────────────────────────────

def get_watchlist(media_type='movies', page=1, limit=30):
    """media_type: 'movies' or 'shows'"""
    if not is_authorized():
        return []
    return _get('/sync/watchlist/%s/added' % media_type,
                params={'page': page, 'limit': limit, 'extended': 'full'}) or []


def add_to_watchlist(meta):
    if not is_authorized():
        return False
    mt = 'movie' if meta.get('mediatype', 'movie') == 'movie' else 'show'
    ids = {}
    if meta.get('imdb_id'):
        ids['imdb'] = meta['imdb_id']
    if meta.get('tmdb_id'):
        try:
            ids['tmdb'] = int(meta['tmdb_id'])
        except (ValueError, TypeError):
            pass
    data = {'%ss' % mt: [{'title': meta.get('title', ''),
                           'year': meta.get('year') or None,
                           'ids': ids}]}
    return bool(_post('/sync/watchlist', data))


def remove_from_watchlist(meta):
    if not is_authorized():
        return False
    mt = 'movie' if meta.get('mediatype', 'movie') == 'movie' else 'show'
    ids = {}
    if meta.get('imdb_id'):
        ids['imdb'] = meta['imdb_id']
    if meta.get('tmdb_id'):
        try:
            ids['tmdb'] = int(meta['tmdb_id'])
        except (ValueError, TypeError):
            pass
    return bool(_post('/sync/watchlist/remove', {'%ss' % mt: [{'ids': ids}]}))

# ── History ───────────────────────────────────────────────────────────────────

def get_history(media_type='movies', page=1, limit=30):
    if not is_authorized():
        return []
    return _get('/sync/history/%s' % media_type,
                params={'page': page, 'limit': limit, 'extended': 'full'}) or []

# ── Ratings ───────────────────────────────────────────────────────────────────

def rate_item(meta, rating):
    """rating: 1–10"""
    if not is_authorized():
        return False
    mt = 'movie' if meta.get('mediatype', 'movie') == 'movie' else 'show'
    ids = {}
    if meta.get('imdb_id'):
        ids['imdb'] = meta['imdb_id']
    if meta.get('tmdb_id'):
        try:
            ids['tmdb'] = int(meta['tmdb_id'])
        except (ValueError, TypeError):
            pass
    data = {'%ss' % mt: [{'rating': int(rating),
                           'title': meta.get('title', ''),
                           'ids': ids}]}
    return bool(_post('/sync/ratings', data))

# ── Discovery ─────────────────────────────────────────────────────────────────

def get_trending(media_type='movies', page=1, limit=30):
    return _get('/%s/trending' % media_type,
                params={'page': page, 'limit': limit, 'extended': 'full'}) or []


def get_popular(media_type='movies', page=1, limit=30):
    return _get('/%s/popular' % media_type,
                params={'page': page, 'limit': limit, 'extended': 'full'}) or []


def get_anticipated(media_type='movies', page=1, limit=30):
    return _get('/%s/anticipated' % media_type,
                params={'page': page, 'limit': limit, 'extended': 'full'}) or []
