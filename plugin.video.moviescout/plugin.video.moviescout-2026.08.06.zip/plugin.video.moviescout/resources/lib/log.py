import traceback
import xbmc
from resources.lib.control import getSetting, addonProfile, syshandle

LOGDEBUG   = xbmc.LOGDEBUG
LOGINFO    = xbmc.LOGINFO
LOGWARNING = xbmc.LOGWARNING
LOGERROR   = xbmc.LOGERROR

PREFIX = '[MovieScout] '

def log(msg, level=LOGINFO):
    if getSetting('debug.enable') == 'true':
        xbmc.log(PREFIX + str(msg), level)

def error():
    xbmc.log(PREFIX + traceback.format_exc(), LOGERROR)
