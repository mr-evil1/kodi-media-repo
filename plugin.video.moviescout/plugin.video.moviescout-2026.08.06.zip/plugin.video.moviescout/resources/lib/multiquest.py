# -*- coding: utf-8 -*-
import http.client
import json
import socket
import ssl
import sys
import os
import time
import zlib
import hashlib
import traceback
import xbmc
import xbmcgui
from random import choice
import xbmcvfs
from urllib.parse import urlencode, urlparse
from urllib.request import HTTPSHandler, HTTPRedirectHandler, build_opener
from http.cookiejar import LWPCookieJar

def _inject_module_paths():
    addons_dir = xbmcvfs.translatePath('special://home/addons')
    for name in ('script.module.urllib3',):
        candidate = os.path.join(addons_dir, name)
        lib = os.path.join(candidate, 'lib')
        path = lib if os.path.isdir(lib) else candidate
        if os.path.isdir(path) and path not in sys.path:
            sys.path.insert(0, path)
            xbmc.log('[MovieScout.multiquest] injected path: %s' % path, xbmc.LOGINFO)

_inject_module_paths()

_ADDON_LIB = os.path.join(os.path.dirname(__file__), 'vendor')
if _ADDON_LIB not in sys.path:
    sys.path.insert(0, _ADDON_LIB)

try:
    import httpx
    _HTTPX = True
except ImportError:
    _HTTPX = False

try:
    import cloudscraper as _cloudscraper_mod
    _CS = True
except ImportError:
    _CS = False

def RandomUA():
    # Random User Agents aktualisiert 08.06.2025
    FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0'
    OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 OPR/119.0.0.0'
    ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 15; SM-S931U Build/AP3A.240905.015.A2; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/132.0.6834.163 Mobile Safari/537.36'
    EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'
    CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36'
    SAFARI_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15'

    _User_Agents = [FF_USER_AGENT, OPERA_USER_AGENT, EDGE_USER_AGENT, CHROME_USER_AGENT, SAFARI_USER_AGENT]
    return choice(_User_Agents)

_DEFAULT_UA = RandomUA()
_DEFAULT_TIMEOUT = 10

_httpx_client = None
_cs_client = None
_cs_noverify_client = None

_DNS_CACHE     = {}
_DNS_TTL       = 3600
_DNS_DIRTY     = False

_SETTING_CACHE = {}
_SETTING_TTL   = 10


def _addon_data_base():
    try:
        return xbmcvfs.translatePath('special://profile/addon_data/plugin.video.moviescout')
    except Exception:
        return os.path.join(os.path.dirname(__file__), '..', '..')

_ADDON_DATA_BASE = _addon_data_base()
_DNS_CACHE_FILE  = os.path.join(_ADDON_DATA_BASE, 'dns_cache.json')
_HTML_CACHE_DIR  = os.path.join(_ADDON_DATA_BASE, 'htmlcache')
_COOKIE_DIR      = os.path.join(_ADDON_DATA_BASE, 'cookies')

for _d in (_HTML_CACHE_DIR, _COOKIE_DIR):
    os.makedirs(_d, exist_ok=True)


def _dns_cache_path():
    return _DNS_CACHE_FILE


def _dns_cache_load():
    try:
        path = _dns_cache_path()
        if not os.path.exists(path):
            return
        with open(path, 'r') as f:
            data = json.load(f)
        now = time.time()
        for host, entry in data.items():
            ip, ts = entry[0], entry[1]
            if now - ts < _DNS_TTL:
                _DNS_CACHE[host] = (ip, ts)
    except Exception:
        pass


def _dns_cache_save(force=False):
    global _DNS_DIRTY
    if not force and not _DNS_DIRTY:
        return
    try:
        with open(_dns_cache_path(), 'w') as f:
            json.dump({h: [v[0], v[1]] for h, v in _DNS_CACHE.items()}, f)
        _DNS_DIRTY = False
    except Exception:
        pass


_dns_cache_load()

_DOH_PROVIDERS = [
    {
        'url': 'https://1.1.1.1/dns-query?name={domain}&type=A',
        'headers': {'accept': 'application/dns-json'},
    },
    {
        'url': 'https://dns.google/resolve?name={domain}&type=A',
        'headers': {'accept': 'application/json'},
    },
    {
        'url': 'https://dns.quad9.net:5053/dns-query?name={domain}&type=A',
        'headers': {'accept': 'application/dns-json'},
    },
]


def _get_setting_cached(key, default='false'):
    now = time.time()
    entry = _SETTING_CACHE.get(key)
    if entry and now - entry[1] < _SETTING_TTL:
        return entry[0]
    try:
        from resources.lib.control import getSetting
        val = getSetting(key, default)
    except Exception:
        val = default
    _SETTING_CACHE[key] = (val, now)
    return val


def _debug_enabled():
    return _get_setting_cached('debug.enable') == 'true'


def _log(msg):
    if _debug_enabled():
        xbmc.log('[MovieScout.multiquest] %s' % msg, xbmc.LOGINFO)


def _log_error(msg):
    xbmc.log('[MovieScout.multiquest] ERROR: %s' % msg, xbmc.LOGERROR)


def _doh_enabled():
    return _get_setting_cached('network.doh.enable') == 'true'


def _resolve_doh(hostname):
    now = time.time()
    if hostname in _DNS_CACHE:
        ip, ts = _DNS_CACHE[hostname]
        if now - ts < _DNS_TTL:
            _log('DNS cache hit: %s -> %s' % (hostname, ip))
            return ip
        del _DNS_CACHE[hostname]

    import urllib.request
    for provider in _DOH_PROVIDERS:
        try:
            url = provider['url'].format(domain=hostname)
            _log('DoH query: %s' % url)
            req = urllib.request.Request(url, headers=provider['headers'])
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read().decode('utf-8', 'replace'))
            answers = data.get('Answer') or data.get('answer') or []
            for a in answers:
                ip = a.get('data') or a.get('rdata')
                if ip and not ip.startswith('0.'):
                    _DNS_CACHE[hostname] = (ip, now)
                    _DNS_DIRTY = True
                    _log('DoH resolved: %s -> %s' % (hostname, ip))
                    return ip
        except Exception as e:
            _log('DoH provider %s failed: %s' % (url, e))
            continue

    try:
        ip = socket.gethostbyname(hostname)
        if ip:
            _DNS_CACHE[hostname] = (ip, now)
            _DNS_DIRTY = True
            _log('System DNS fallback: %s -> %s' % (hostname, ip))
            return ip
    except Exception as e:
        _log_error('System DNS failed for %s: %s' % (hostname, e))

    _log_error('Could not resolve %s' % hostname)
    return None


class _IPHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, host, ip, port=None, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, context=None):
        self._target_ip = ip
        self._sni_host = host
        super().__init__(host, port, timeout=timeout, context=context)

    def connect(self):
        self.sock = self._create_connection((self._target_ip, self.port), self.timeout)
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        self.sock = ctx.wrap_socket(self.sock, server_hostname=self._sni_host)


class _IPHTTPSHandler(HTTPSHandler):
    def __init__(self, ip, hostname):
        self._ip = ip
        self._hostname = hostname
        super().__init__()

    def https_open(self, req):
        ip = self._ip
        hostname = self._hostname
        def factory(host, **kwargs):
            kwargs.pop('context', None)
            return _IPHTTPSConnection(hostname, ip, **kwargs)
        return self.do_open(factory, req)


def _make_noverify_ssl_ctx():
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx

# ---------------------------------------------------------------------------
# Portiert aus requestHandler: CUII-Filter, Dekompression, DDoS-Guard, Cache
# ---------------------------------------------------------------------------

class _DoHHTTPSHandler(HTTPSHandler):
    def https_open(self, req):
        hostname = (req.host or '').split(':')[0]
        if not hostname:
            return HTTPSHandler.https_open(self, req)
        ip = _resolve_doh(hostname)
        if not ip:
            return HTTPSHandler.https_open(self, req)
        def factory(host, **kwargs):
            kwargs.pop('context', None)
            return _IPHTTPSConnection(hostname, ip, **kwargs)
        return self.do_open(factory, req)


def _make_redirect_handler(allow_redirects=True):
    class _Handler(HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, hdrs, newurl):
            if 'notice.cuii' in newurl:
                xbmcgui.Dialog().notification(
                    'DNS-Lock erkannt',
                    'Diese Seite ist durch DNS-Lock gesperrt (CUII).',
                    xbmcgui.NOTIFICATION_WARNING, 5000)
                _log_error('CUII redirect blocked: %s' % newurl)
                return None
            if not allow_redirects:
                return None
            return HTTPRedirectHandler.redirect_request(self, req, fp, code, msg, hdrs, newurl)
    return _Handler()


def _decompress(raw_bytes, encoding):
    """gzip/deflate Dekompression für urllib-Responses (portiert aus requestHandler)."""
    enc = (encoding or '').lower()
    try:
        if enc == 'gzip':
            return zlib.decompress(raw_bytes, wbits=zlib.MAX_WBITS | 16)
        if enc == 'deflate':
            return zlib.decompress(raw_bytes, wbits=-zlib.MAX_WBITS)
    except Exception:
        pass
    return raw_bytes


def _ddos_guard_bypass(url, cookie_jar, user_agent):
    """
    DDoS-Guard check.js Handshake (portiert aus requestHandler).
    Gibt True zurück wenn der Bypass erfolgreich war (Cookies in jar gesetzt).
    """
    import urllib.request, re as _re
    try:
        _log('DDoS-Guard detected, attempting bypass for %s' % url)
        opener = build_opener(urllib.request.HTTPCookieProcessor(cookie_jar))
        opener.addheaders = [('User-Agent', user_agent), ('Referer', url)]
        resp = opener.open('https://check.ddos-guard.net/check.js', timeout=10)
        content = resp.read().decode('utf-8', 'replace')
        urls = _re.findall(r"Image.*?'([^']+)';\s*new", content)
        if not urls:
            _log_error('DDoS-Guard: could not parse check.js image URL')
            return False
        parsed = urlparse(url)
        img_url = '%s://%s/%s' % (parsed.scheme, parsed.netloc, urls[0])
        opener2 = build_opener(urllib.request.HTTPCookieProcessor(cookie_jar))
        opener2.addheaders = [('User-Agent', user_agent), ('Referer', url)]
        opener2.open(img_url, timeout=10).read()
        _log('DDoS-Guard bypass complete')
        return True
    except Exception as e:
        _log_error('DDoS-Guard bypass failed: %s' % e)
        return False


def _cache_path():
    return _HTML_CACHE_DIR


def _cache_read(url, ttl):
    """Liest gecachten HTML-Inhalt, wenn jünger als ttl Sekunden."""
    try:
        h = hashlib.md5(url.encode('utf-8')).hexdigest()
        path = os.path.join(_cache_path(), h)
        age = time.time() - os.stat(path).st_mtime
        if 0 < age < ttl:
            with open(path, 'rb') as f:
                return f.read().decode('utf-8', 'replace')
    except Exception:
        pass
    return None


def _cache_write(url, content):
    """Schreibt HTML-Inhalt in den dateibasierten Cache."""
    try:
        h = hashlib.md5(url.encode('utf-8')).hexdigest()
        with open(os.path.join(_cache_path(), h), 'wb') as f:
            f.write(content.encode('utf-8'))
    except Exception as e:
        _log_error('Cache write failed: %s' % e)


def _cookie_path(domain):
    safe = domain.replace('.', '_').replace(':', '_')
    path = os.path.join(_COOKIE_DIR, safe + '.txt')
    if not os.path.exists(path):
        open(path, 'w').close()
    return path


def _get_httpx(verify=True):
    global _httpx_client
    if not verify:
        _log('httpx: new client verify=False')
        return httpx.Client(
            headers={'User-Agent': _DEFAULT_UA},
            follow_redirects=True,
            timeout=_DEFAULT_TIMEOUT,
            verify=False,
        )
    if _httpx_client is None:
        _log('httpx: new client verify=True')
        _httpx_client = httpx.Client(
            headers={'User-Agent': _DEFAULT_UA},
            follow_redirects=True,
            timeout=_DEFAULT_TIMEOUT,
            verify=True,
        )
    return _httpx_client


def _get_cs(no_verify=False):
    global _cs_client, _cs_noverify_client
    if no_verify:
        if _cs_noverify_client is None:
            _log('cloudscraper: new session no_verify=True (vendored, pre-built ssl_context)')
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            _cs_noverify_client = _cloudscraper_mod.create_scraper(
                ssl_context=_make_noverify_ssl_ctx()
            )
            _cs_noverify_client.headers.update({'User-Agent': _DEFAULT_UA})
            _cs_noverify_client.verify = False
        return _cs_noverify_client
    if _cs_client is None:
        _log('cloudscraper: new session no_verify=False (vendored)')
        _cs_client = _cloudscraper_mod.create_scraper()
        _cs_client.headers.update({'User-Agent': _DEFAULT_UA})
    return _cs_client


def _cs_request(sess, method, url, no_verify=False, **kwargs):
    kwargs['verify'] = not no_verify
    return getattr(sess, method)(url, **kwargs)


class _CIDict(dict):
    def __setitem__(self, key, value):
        super().__setitem__(key.lower(), value)
    def __getitem__(self, key):
        return super().__getitem__(key.lower())
    def get(self, key, default=None):
        return super().get(key.lower(), default)
    def __contains__(self, key):
        return super().__contains__(key.lower())


class _Response:
    def __init__(self, status_code, headers, content, url=''):
        self.status_code = status_code
        self.headers = headers
        self.content = content
        self.url = url

    @property
    def text(self):
        enc = self.headers.get('content-type', '')
        charset = 'utf-8'
        if 'charset=' in enc:
            try:
                charset = enc.split('charset=')[-1].split(';')[0].strip()
            except Exception:
                pass
        return self.content.decode(charset, errors='replace')

    def json(self):
        return json.loads(self.content)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise Exception('HTTP %d' % self.status_code)

    def iter_content(self, chunk_size=65536):
        for i in range(0, len(self.content), chunk_size):
            yield self.content[i:i + chunk_size]


def _wrap_httpx(r):
    return _Response(r.status_code, _CIDict({k.lower(): v for k, v in r.headers.items()}), r.content, str(r.url))


def _wrap_requests(r):
    return _Response(r.status_code, _CIDict({k.lower(): v for k, v in r.headers.items()}), r.content, r.url)


def _urllib_get_doh(url, h, t, allow_redirects=True, cookie_jar=None):
    import urllib.request
    handlers = [_DoHHTTPSHandler(), _make_redirect_handler(allow_redirects)]
    if cookie_jar is not None:
        handlers.append(urllib.request.HTTPCookieProcessor(cookie_jar))
    opener = build_opener(*handlers)
    merged = {**{'User-Agent': _DEFAULT_UA}, **h}
    req = urllib.request.Request(url, headers=merged)
    _log('GET via urllib+DoH url=%s allow_redirects=%s' % (url, allow_redirects))
    import urllib.error
    try:
        with opener.open(req, timeout=t) as resp:
            raw  = resp.read()
            raw  = _decompress(raw, resp.headers.get('Content-Encoding', ''))
            hdrs = _CIDict(dict(resp.headers))
            _log('GET response: %d' % resp.status)
            if b'DDOS-GUARD' in raw[:4096] and cookie_jar is not None:
                _log('DDoS-Guard in DoH response — bypass')
                if _ddos_guard_bypass(url, cookie_jar, _DEFAULT_UA):
                    with build_opener(*handlers).open(req, timeout=t) as r2:
                        raw  = _decompress(r2.read(), r2.headers.get('Content-Encoding', ''))
                        hdrs = _CIDict(dict(r2.headers))
            return _Response(resp.status, hdrs, raw, resp.geturl())
    except urllib.error.HTTPError as e:
        if not allow_redirects and e.code in (301, 302, 303, 307, 308):
            loc = e.headers.get('Location') or e.headers.get('location') or ''
            _log('DoH GET redirect blocked: %d -> %s' % (e.code, loc))
            return _Response(e.code, _CIDict(dict(e.headers)), b'', loc or url)
        raise


def _urllib_post_doh(url, body, h, t, cookie_jar=None):
    import urllib.request
    handlers = [_DoHHTTPSHandler(), _make_redirect_handler(True)]
    if cookie_jar is not None:
        handlers.append(urllib.request.HTTPCookieProcessor(cookie_jar))
    opener = build_opener(*handlers)
    merged = {**{'User-Agent': _DEFAULT_UA}, **h}
    req = urllib.request.Request(url, data=body, headers=merged, method='POST')
    _log('POST via urllib+DoH url=%s' % url)
    with opener.open(req, timeout=t) as resp:
        raw = _decompress(resp.read(), resp.headers.get('Content-Encoding', ''))
        _log('POST response: %d' % resp.status)
        return _Response(resp.status, _CIDict(dict(resp.headers)), raw, resp.geturl())


def get(url, params=None, headers=None, timeout=None, stream=False,
        allow_redirects=True, use_cf=False, no_verify=False, verify=None):
    if verify is not None:
        no_verify = not verify
    t = timeout or _DEFAULT_TIMEOUT
    h = headers or {}

    if params:
        sep = '&' if '?' in url else '?'
        url = url + sep + urlencode(params)

    doh = _doh_enabled()
    _log('GET %s | doh=%s use_cf=%s no_verify=%s httpx=%s cs=%s' % (url, doh, use_cf, no_verify, _HTTPX, _CS))

    if doh and not use_cf:
        parsed = urlparse(url)
        hostname = parsed.hostname
        if hostname:
            ip = _resolve_doh(hostname)
            if ip:
                return _urllib_get_doh(url, h, t, allow_redirects)

    try:
        if use_cf and _CS:
            _log('GET via cloudscraper (vendored) no_verify=%s' % no_verify)
            sess = _get_cs(no_verify=no_verify)
            r = _cs_request(sess, 'get', url, no_verify=no_verify,
                            headers=h, timeout=t, allow_redirects=allow_redirects)
            _log('GET response: %d' % r.status_code)
            return _wrap_requests(r)

        if _HTTPX:
            _log('GET via httpx allow_redirects=%s' % allow_redirects)
            if not allow_redirects:
                with httpx.Client(
                    headers={'User-Agent': _DEFAULT_UA},
                    follow_redirects=False,
                    timeout=t,
                    verify=not no_verify,
                ) as _c:
                    r = _c.get(url, headers=h, timeout=t)
            else:
                r = _get_httpx(verify=not no_verify).get(url, headers=h, timeout=t)
            _log('GET response: %d' % r.status_code)
            return _wrap_httpx(r)

        if _CS:
            _log('GET via cloudscraper (vendored, fallback) no_verify=%s' % no_verify)
            sess = _get_cs(no_verify=no_verify)
            r = _cs_request(sess, 'get', url, no_verify=no_verify,
                            headers=h, timeout=t, allow_redirects=allow_redirects)
            _log('GET response: %d' % r.status_code)
            return _wrap_requests(r)

        import urllib.request, urllib.error

        # Cache-Prüfung (nur GET, nur wenn cache_ttl übergeben)
        _cache_ttl = h.pop('_cache_ttl', 0)
        if _cache_ttl and allow_redirects:
            cached = _cache_read(url, _cache_ttl)
            if cached:
                _log('GET from cache: %s' % url)
                return _Response(200, _CIDict({}), cached.encode('utf-8'), url)

        _log('GET via urllib allow_redirects=%s' % allow_redirects)
        handlers = [_make_redirect_handler(allow_redirects)]
        if no_verify:
            handlers.append(urllib.request.HTTPSHandler(context=_make_noverify_ssl_ctx()))

        def _do_urllib_get(opener):
            req = urllib.request.Request(url, headers={**{'User-Agent': _DEFAULT_UA}, **h})
            try:
                with opener.open(req, timeout=t) as resp:
                    raw   = resp.read()
                    raw   = _decompress(raw, resp.headers.get('Content-Encoding', ''))
                    hdrs  = _CIDict(dict(resp.headers))
                    code  = resp.status
                    final = resp.geturl()
                    _log('GET response: %d' % code)
                    # DDoS-Guard erkennen
                    if b'DDOS-GUARD' in raw[:4096]:
                        _log('DDoS-Guard detected in response body')
                        jar = LWPCookieJar()
                        if _ddos_guard_bypass(url, jar, _DEFAULT_UA):
                            dg_opener = build_opener(urllib.request.HTTPCookieProcessor(jar), _make_redirect_handler())
                            with dg_opener.open(req, timeout=t) as r2:
                                raw   = _decompress(r2.read(), r2.headers.get('Content-Encoding', ''))
                                hdrs  = _CIDict(dict(r2.headers))
                                code  = r2.status
                                final = r2.geturl()
                    resp_obj = _Response(code, hdrs, raw, final)
                    # Cache schreiben
                    if _cache_ttl and allow_redirects and code == 200:
                        _cache_write(url, resp_obj.text)
                    return resp_obj
            except urllib.error.HTTPError as e:
                if not allow_redirects and e.code in (301, 302, 303, 307, 308):
                    loc = e.headers.get('Location') or e.headers.get('location') or ''
                    _log('GET redirect blocked: %d -> %s' % (e.code, loc))
                    return _Response(e.code, _CIDict(dict(e.headers)), b'', loc or url)
                raise

        opener = build_opener(*handlers)
        try:
            return _do_urllib_get(opener)
        except socket.timeout:
            _log('GET timeout, retrying with fresh connection: %s' % url)
            try:
                return _do_urllib_get(build_opener(*handlers))
            except Exception as retry_err:
                _log_error('GET retry failed: %s' % retry_err)
                raise

    except Exception as e:
        _log_error('GET failed for %s: %s\n%s' % (url, e, traceback.format_exc()))
        raise


def post(url, data=None, json=None, headers=None, timeout=None,
         use_cf=False, no_verify=False, verify=None):
    if verify is not None:
        no_verify = not verify
    import json as _json
    t = timeout or _DEFAULT_TIMEOUT
    h = headers or {}
    body = None
    if json is not None:
        body = _json.dumps(json).encode()
        h = {**h, 'Content-Type': 'application/json'}
    elif data is not None:
        if isinstance(data, dict):
            body = urlencode(data).encode()
            h = {**h, 'Content-Type': 'application/x-www-form-urlencoded'}
        else:
            body = data if isinstance(data, bytes) else data.encode()

    doh = _doh_enabled()
    _log('POST %s | doh=%s use_cf=%s no_verify=%s' % (url, doh, use_cf, no_verify))

    if doh and not use_cf:
        parsed = urlparse(url)
        hostname = parsed.hostname
        if hostname:
            ip = _resolve_doh(hostname)
            if ip:
                return _urllib_post_doh(url, body, h, t)

    try:
        if use_cf and _CS:
            _log('POST via cloudscraper (vendored) no_verify=%s' % no_verify)
            sess = _get_cs(no_verify=no_verify)
            r = _cs_request(sess, 'post', url, no_verify=no_verify,
                            data=body, headers=h, timeout=t)
            _log('POST response: %d' % r.status_code)
            return _wrap_requests(r)

        if _HTTPX:
            _log('POST via httpx')
            client = _get_httpx(verify=not no_verify)
            r = client.post(url, content=body, headers=h, timeout=t)
            _log('POST response: %d' % r.status_code)
            return _wrap_httpx(r)

        if _CS:
            _log('POST via cloudscraper (vendored, fallback) no_verify=%s' % no_verify)
            sess = _get_cs(no_verify=no_verify)
            r = _cs_request(sess, 'post', url, no_verify=no_verify,
                            data=body, headers=h, timeout=t)
            _log('POST response: %d' % r.status_code)
            return _wrap_requests(r)

        import urllib.request
        _log('POST via urllib')
        req = urllib.request.Request(url, data=body,
                                     headers={**{'User-Agent': _DEFAULT_UA}, **h}, method='POST')
        if no_verify:
            ctx = _make_noverify_ssl_ctx()
            with urllib.request.urlopen(req, timeout=t, context=ctx) as resp:
                _log('POST response: %d' % resp.status)
                return _Response(resp.status, dict(resp.headers), resp.read(), resp.geturl())
        with urllib.request.urlopen(req, timeout=t) as resp:
            _log('POST response: %d' % resp.status)
            return _Response(resp.status, dict(resp.headers), resp.read(), resp.geturl())

    except Exception as e:
        _log_error('POST failed for %s: %s\n%s' % (url, e, traceback.format_exc()))
        raise


def get_stream(url, headers=None, timeout=30, chunk_size=1024 * 256,
               use_cf=False, no_verify=False):
    r = get(url, headers=headers, timeout=timeout, stream=True,
            use_cf=use_cf, no_verify=no_verify)
    r.raise_for_status()
    total = int(r.headers.get('content-length', 0))
    return r, total


class Session:
    def __init__(self, headers=None, use_cf=False, no_verify=False, cookie_file=None):
        self._use_cf = use_cf
        self._no_verify = no_verify
        self._base_headers = {**{'User-Agent': _DEFAULT_UA}, **(headers or {})}
        self._httpx_client = None
        self._cs_client = None
        # LWPCookieJar mit Dateipersistenz wenn cookie_file angegeben,
        # sonst In-Memory-Jar — Cookies überleben in beiden Fällen den Request.
        if cookie_file:
            self._urllib_jar = LWPCookieJar(filename=cookie_file)
            try:
                self._urllib_jar.load(ignore_discard=True, ignore_expires=True)
            except Exception:
                pass
        else:
            self._urllib_jar = LWPCookieJar()
        self._cookie_file = cookie_file

    def _merged(self, extra):
        return {**self._base_headers, **(extra or {})}

    def _get_httpx(self):
        if self._httpx_client is None:
            self._httpx_client = httpx.Client(
                headers=self._base_headers,
                follow_redirects=True,
                timeout=_DEFAULT_TIMEOUT,
                verify=not self._no_verify,
            )
        return self._httpx_client

    def _get_cs(self):
        if self._cs_client is None:
            if self._no_verify:
                import urllib3
                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
                self._cs_client = _cloudscraper_mod.create_scraper(
                    ssl_context=_make_noverify_ssl_ctx()
                )
                self._cs_client.verify = False
            else:
                self._cs_client = _cloudscraper_mod.create_scraper()
            self._cs_client.headers.update(self._base_headers)
        return self._cs_client

    def _get_urllib_opener(self):
        import http.cookiejar
        import urllib.request
        if self._urllib_jar is None:
            self._urllib_jar = http.cookiejar.CookieJar()
        handlers = [urllib.request.HTTPCookieProcessor(self._urllib_jar)]
        if self._no_verify:
            handlers.append(urllib.request.HTTPSHandler(context=_make_noverify_ssl_ctx()))
        return build_opener(*handlers)

    def get(self, url, params=None, headers=None, timeout=None, allow_redirects=True):
        t = timeout or _DEFAULT_TIMEOUT
        h = self._merged(headers)

        if params:
            sep = '&' if '?' in url else '?'
            url = url + sep + urlencode(params)

        doh = _doh_enabled()
        _log('Session.GET %s | doh=%s use_cf=%s no_verify=%s' % (url, doh, self._use_cf, self._no_verify))

        if doh:
            parsed = urlparse(url)
            hostname = parsed.hostname
            if hostname:
                ip = _resolve_doh(hostname)
                if ip:
                    r = _urllib_get_doh(url, h, t, allow_redirects,
                                        cookie_jar=self._urllib_jar)
                    # Cookies persistieren wenn LWPCookieJar mit Datei
                    if self._cookie_file:
                        try:
                            self._urllib_jar.save(ignore_discard=True, ignore_expires=True)
                        except Exception:
                            pass
                    return r

        try:
            if self._use_cf and _CS:
                sess = self._get_cs()
                r = sess.get(url, headers=h, timeout=t, allow_redirects=allow_redirects,
                             verify=not self._no_verify)
                _log('Session.GET response: %d' % r.status_code)
                return _wrap_requests(r)

            if _HTTPX:
                # follow_redirects per Request — gleicher Client, Cookies bleiben erhalten
                _log('Session.GET via httpx allow_redirects=%s' % allow_redirects)
                r = self._get_httpx().get(url, headers=h, timeout=t,
                                          follow_redirects=allow_redirects)
                _log('Session.GET response: %d' % r.status_code)
                # Sicherheitscheck: Wenn allow_redirects=False aber httpx hat trotzdem
                # weitergeleitet (manche Versionen ignorieren per-Request follow_redirects),
                # erkennen wir das daran, dass status_code kein 3xx ist.
                # In dem Fall fällt der Code auf urllib durch, das via HTTPError zuverlässig blockt.
                if allow_redirects or r.status_code in (301, 302, 303, 307, 308):
                    return _wrap_httpx(r)
                _log('Session.GET httpx hat Redirect trotz allow_redirects=False verfolgt — Fallback auf urllib')

            if _CS:
                sess = self._get_cs()
                r = sess.get(url, headers=h, timeout=t, allow_redirects=allow_redirects,
                             verify=not self._no_verify)
                _log('Session.GET response: %d' % r.status_code)
                return _wrap_requests(r)

            import urllib.request, urllib.error
            # CUII-Filter + Cookie-Jar immer dabei
            handlers = [
                urllib.request.HTTPCookieProcessor(self._urllib_jar),
                _make_redirect_handler(allow_redirects),
            ]
            if self._no_verify:
                handlers.append(urllib.request.HTTPSHandler(context=_make_noverify_ssl_ctx()))

            def _do_sess_get(opener):
                req = urllib.request.Request(url, headers=h)
                try:
                    with opener.open(req, timeout=t) as resp:
                        raw  = resp.read()
                        raw  = _decompress(raw, resp.headers.get('Content-Encoding', ''))
                        hdrs = _CIDict(dict(resp.headers))
                        _log('Session.GET response: %d' % resp.status)
                        # DDoS-Guard erkennen
                        if b'DDOS-GUARD' in raw[:4096]:
                            _log('DDoS-Guard in Session response — bypass')
                            if _ddos_guard_bypass(url, self._urllib_jar, _DEFAULT_UA):
                                with build_opener(*handlers).open(req, timeout=t) as r2:
                                    raw  = _decompress(r2.read(), r2.headers.get('Content-Encoding', ''))
                                    hdrs = _CIDict(dict(r2.headers))
                        resp_obj = _Response(resp.status, hdrs, raw, resp.geturl())
                        # Cookies persistieren wenn LWPCookieJar mit Datei
                        if self._cookie_file:
                            try:
                                self._urllib_jar.save(ignore_discard=True, ignore_expires=True)
                            except Exception:
                                pass
                        return resp_obj
                except urllib.error.HTTPError as e:
                    if not allow_redirects and e.code in (301, 302, 303, 307, 308):
                        loc = e.headers.get('Location') or e.headers.get('location') or ''
                        _log('Session.GET redirect blocked: %d -> %s' % (e.code, loc))
                        return _Response(e.code, _CIDict(dict(e.headers)), b'', loc or url)
                    raise

            opener = build_opener(*handlers)
            try:
                return _do_sess_get(opener)
            except socket.timeout:
                _log('Session.GET timeout, retrying: %s' % url)
                try:
                    return _do_sess_get(build_opener(*handlers))
                except Exception as retry_err:
                    _log_error('Session.GET retry failed: %s' % retry_err)
                    raise

        except Exception as e:
            _log_error('Session.GET failed for %s: %s\n%s' % (url, e, traceback.format_exc()))
            raise

    def post(self, url, data=None, json=None, headers=None, timeout=None):
        import json as _json
        t = timeout or _DEFAULT_TIMEOUT
        h = self._merged(headers)
        body = None

        if json is not None:
            body = _json.dumps(json).encode()
            h = {**h, 'Content-Type': 'application/json'}
        elif data is not None:
            if isinstance(data, dict):
                body = urlencode(data).encode()
                h = {**h, 'Content-Type': 'application/x-www-form-urlencoded'}
            else:
                body = data if isinstance(data, bytes) else data.encode()

        doh = _doh_enabled()
        _log('Session.POST %s | doh=%s use_cf=%s no_verify=%s' % (url, doh, self._use_cf, self._no_verify))

        if doh:
            parsed = urlparse(url)
            hostname = parsed.hostname
            if hostname:
                ip = _resolve_doh(hostname)
                if ip:
                    return _urllib_post_doh(url, body, h, t,
                                            cookie_jar=self._urllib_jar)

        try:
            if self._use_cf and _CS:
                sess = self._get_cs()
                r = sess.post(url, data=body, headers=h, timeout=t,
                              verify=not self._no_verify)
                _log('Session.POST response: %d' % r.status_code)
                return _wrap_requests(r)

            if _HTTPX:
                r = self._get_httpx().post(url, content=body, headers=h, timeout=t)
                _log('Session.POST response: %d' % r.status_code)
                return _wrap_httpx(r)

            if _CS:
                sess = self._get_cs()
                r = sess.post(url, data=body, headers=h, timeout=t,
                              verify=not self._no_verify)
                _log('Session.POST response: %d' % r.status_code)
                return _wrap_requests(r)

            import urllib.request
            opener = self._get_urllib_opener()
            req = urllib.request.Request(url, data=body, headers=h, method='POST')
            with opener.open(req, timeout=t) as resp:
                _log('Session.POST response: %d' % resp.status)
                return _Response(resp.status, dict(resp.headers), resp.read(), resp.geturl())

        except Exception as e:
            _log_error('Session.POST failed for %s: %s\n%s' % (url, e, traceback.format_exc()))
            raise

    def close(self):
        if self._httpx_client is not None:
            try:
                self._httpx_client.close()
            except Exception:
                pass
            self._httpx_client = None
        self._cs_client = None
        # Cookies auf Disk sichern bevor Jar geleert wird
        if self._cookie_file:
            try:
                self._urllib_jar.save(ignore_discard=True, ignore_expires=True)
            except Exception:
                pass
        self._urllib_jar.clear()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def clear_dns_cache():
    _DNS_CACHE.clear()
    try:
        path = _dns_cache_path()
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def close():
    global _httpx_client, _cs_client, _cs_noverify_client
    if _httpx_client is not None:
        try:
            _httpx_client.close()
        except Exception:
            pass
        _httpx_client = None
    _cs_client = None
    _cs_noverify_client = None
    _dns_cache_save(force=True)
