# -*- coding: utf-8 -*-
import json
import time
import xbmc
import xbmcgui
from resources.lib import control
from resources.lib.log import log, LOGERROR, LOGDEBUG
from resources.lib import multiquest


class CaptchaSolver:

    def __init__(self, api_key=None, provider=None, timeout=120):
        self.api_key = api_key
        self.provider = provider
        self.timeout = timeout
        self.is_alive = True

    def set_kill(self):
        self.is_alive = False

    def solve_recaptcha_v2(self, site_key, page_url):
        if self.provider == '2captcha':
            return self._solve_with_2captcha(site_key, page_url)
        elif self.provider == '9kw':
            return self._solve_with_9kw(site_key, page_url)
        else:
            raise ValueError("Captcha-Provider '{}' wird nicht unterstützt".format(self.provider))

    def _solve_with_2captcha(self, site_key, page_url):
        if not self.api_key:
            xbmcgui.Dialog().ok(control.addonName(), control.addonName())
            return None

        params = {
            'key': self.api_key,
            'method': 'userrecaptcha',
            'googlekey': site_key,
            'pageurl': page_url,
            'json': 1,
        }

        try:
            response = multiquest.post('https://2captcha.com/in.php', json=params, timeout=30)
            json_response = response.json()
        except Exception as e:
            raise Exception("2Captcha Anfrage fehlgeschlagen: {}".format(str(e)))

        if 'request' not in json_response:
            raise Exception("Ungültige Antwort vom 2Captcha-Dienst: {}".format(json_response))

        captcha_id = json_response['request']
        log('CaptchaSolver: 2captcha ID={}'.format(captcha_id), LOGDEBUG)
        return self._get_2captcha_result(captcha_id)

    def _get_2captcha_result(self, captcha_id):
        start_time = time.time()
        while True:
            try:
                response = multiquest.get(
                    'https://2captcha.com/res.php',
                    params={'key': self.api_key, 'json': 1, 'action': 'get', 'id': captcha_id},
                    timeout=30
                )
                json_res = response.json()
            except Exception as e:
                raise Exception("2Captcha Ergebnis-Anfrage fehlgeschlagen: {}".format(str(e)))

            if json_res.get('status') == 1:
                return json_res.get('request')
            elif json_res.get('request') != 'CAPCHA_NOT_READY':
                raise Exception("2Captcha Fehler: {}".format(json.dumps(json_res)))

            if time.time() - start_time >= self.timeout:
                raise Exception("2Captcha Timeout (ID: {})".format(captcha_id))

            time.sleep(2)

    def _solve_with_9kw(self, site_key, page_url):
        if not self.api_key:
            xbmcgui.Dialog().ok(control.addonName(), control.addonName())
            return None

        selfsolve = '1' if control.getSetting('captcha.9kw.selfsolve', 'false') == 'true' else '0'

        post_data = {
            'apikey': self.api_key,
            'action': 'usercaptchaupload',
            'interactive': '1',
            'json': '1',
            'file-upload-01': site_key,
            'oldsource': 'recaptchav2',
            'pageurl': page_url,
            'maxtimeout': str(self.timeout),
        }
        if selfsolve == '1':
            post_data['selfsolve'] = '1'

        token = ''
        try:
            response = multiquest.post('https://www.9kw.eu/index.cgi', data=post_data, timeout=30)
            data = response.json()
            if 'captchaid' not in data:
                return token
            captcha_id = data['captchaid']
            tries = 0
            while tries < self.timeout and self.is_alive:
                tries += 1
                xbmc.sleep(1000)
                try:
                    res = multiquest.get(
                        'https://www.9kw.eu/index.cgi',
                        params={'action': 'usercaptchacorrectdata', 'id': captcha_id,
                                'apikey': self.api_key, 'json': '1'},
                        timeout=30
                    )
                    result_data = res.json()
                    token = result_data.get('answer', '')
                    if token:
                        break
                except Exception as e:
                    log('CaptchaSolver: 9kw poll error: {}'.format(str(e)), LOGERROR)
        except Exception as e:
            log('CaptchaSolver: 9kw error: {}'.format(str(e)), LOGERROR)

        return token
