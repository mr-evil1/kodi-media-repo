# -*- coding: utf-8 -*-
import re
from resources.lib import control
from resources.lib.log import log, LOGERROR
from resources.lib.captcha.captcha_solver import CaptchaSolver


def solve_recaptcha(site_key, page_url, provider=None):
    if provider is None:
        provider = control.getSetting('captcha.provider', '2captcha')

    if not provider:
        log('CaptchaHelper: kein Provider konfiguriert', LOGERROR)
        return None

    if provider == '2captcha':
        api_key = control.getSetting('captcha.2captcha.apikey', '')
    elif provider == '9kw':
        api_key = control.getSetting('captcha.9kw.apikey', '')
    else:
        log("CaptchaHelper: unbekannter Provider '{}'".format(provider), LOGERROR)
        return None

    if not api_key:
        log('CaptchaHelper: API-Schlüssel für {} nicht gesetzt'.format(provider), LOGERROR)
        return None

    timeout = int(control.getSetting('captcha.timeout', '120'))
    solver = CaptchaSolver(api_key=api_key, provider=provider, timeout=timeout)
    try:
        return solver.solve_recaptcha_v2(site_key, page_url)
    except Exception as e:
        log('CaptchaHelper: Fehler beim Lösen: {}'.format(str(e)), LOGERROR)
        return None


def extract_recaptcha_sitekey(html_content):
    patterns = [
        r"series\.init\s*\(\s*\d+\s*,\s*\d+\s*,\s*'([^']+)'\s*\)\s*;",
        r'data-sitekey="([^"]+)"',
        r"grecaptcha\.execute\s*\(\s*'([^']+)'",
    ]
    for pattern in patterns:
        m = re.search(pattern, html_content)
        if m:
            return m.group(1)
    return None
