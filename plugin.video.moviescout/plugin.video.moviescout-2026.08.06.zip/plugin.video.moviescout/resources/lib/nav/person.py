import xbmcplugin
from urllib.parse import unquote_plus
from resources.lib import tmdb, log
from resources.lib.nav.listings import show_item
from resources.lib.control import (
    sysaddon, syshandle, directory, plugincategory, content
)


def show_person_credits(params):
    handle    = syshandle()
    addon     = sysaddon()
    person_id = params.get('person_id')
    name      = unquote_plus(params.get('name', 'Person'))

    movies, shows = tmdb.get_person_credits(person_id)
    xbmcplugin.setContent(handle, 'movies')
    plugincategory(handle, name)

    for tmdb_id in movies:
        try:
            show_item(tmdb_id, 'movie', addon, handle)
        except Exception:
            log.error()

    for tmdb_id in shows:
        try:
            show_item(tmdb_id, 'tv', addon, handle)
        except Exception:
            log.error()

    directory(handle)
