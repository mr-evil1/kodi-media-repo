import xbmcgui
import xbmcplugin
from urllib.parse import quote_plus, unquote_plus
from resources.lib import tmdb, log
from resources.lib.control import (
    sysaddon, syshandle, addonPoster, addonFanart,
    addItem, content, directory, plugincategory, set_info_tag
)


def show_seasons(params):
    handle     = syshandle()
    addon      = sysaddon()
    tmdb_id    = params.get('tmdb_id')
    title      = unquote_plus(params.get('title', ''))

    show = tmdb.get_tvshow(tmdb_id)
    if not show:
        directory(handle, succeeded=False)
        return

    xbmcplugin.setContent(handle, 'tvshows')
    plugincategory(handle, title)

    num_seasons = show.get('number_of_seasons', 0)
    for sn in range(1, num_seasons + 1):
        try:
            sdata = tmdb.get_season(tmdb_id, sn, title)
            if not sdata:
                continue
            ep_count = sdata.get('number_of_episodes', 0)
            label    = 'Staffel %d  (%d Episoden)' % (sn, ep_count)
            li = xbmcgui.ListItem(label=label)
            poster = sdata.get('poster') or show.get('poster') or addonPoster()
            fanart = show.get('fanart') or addonFanart()
            li.setArt({'thumb': poster, 'poster': poster, 'fanart': fanart})
            meta = {
                'tvshowtitle':  title,
                'season':       sn,
                'year':         show.get('year', ''),
                'premiered':    sdata.get('premiered', ''),
                'plot':         sdata.get('plot', show.get('plot', '')),
                'rating':       show.get('rating', 0.0),
                'votes':        show.get('votes', 0),
                'tmdb_id':      tmdb_id,
                'playcount':    0,
                'overlay':      6,
            }
            set_info_tag(li, meta, 'season')
            li.setIsFolder(True)
            url = '%s?action=episodes&tmdb_id=%s&season=%d&title=%s' % (
                addon, tmdb_id, sn, quote_plus(title))
            addItem(handle, url, li, True)
        except Exception:
            log.error()

    directory(handle)
