import xbmcgui
import xbmcplugin
from urllib.parse import quote_plus, unquote_plus
from resources.lib import tmdb, log
from resources.lib.db import playcount as pcdb
from resources.lib.control import (
    sysaddon, syshandle, addonPoster, addonFanart,
    addItem, content, directory, plugincategory, set_info_tag
)
from resources.lib.nav.scout import _hosts_mode


def show_episodes(params):
    handle  = syshandle()
    addon   = sysaddon()
    tmdb_id = params.get('tmdb_id')
    season  = int(params.get('season', 1))
    title   = unquote_plus(params.get('title', ''))

    sdata = tmdb.get_season(tmdb_id, season, title)
    if not sdata:
        directory(handle, succeeded=False)
        return

    show = tmdb.get_tvshow(tmdb_id)
    fanart = show.get('fanart') if show else addonFanart()

    xbmcplugin.setContent(handle, 'episodes')
    plugincategory(handle, '%s – Staffel %d' % (title, season))

    hosts_mode = _hosts_mode()
    for ep in sdata.get('episodes', []):
        ep_num  = ep.get('episode', 0)
        ep_title= ep.get('title', 'Episode %d' % ep_num)
        label   = '%dx%02d – %s' % (season, ep_num, ep_title)

        premiered = ep.get('premiered', '')
        is_future = _is_future(premiered)
        if is_future:
            label = '[COLOR red][I]%s[/I][/COLOR]' % label

        poster = ep.get('poster') or (show.get('poster') if show else addonPoster())
        pc     = pcdb.get('episode', title, season=season, episode=ep_num)

        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': poster, 'poster': poster, 'fanart': fanart or addonFanart()})
        meta = {
            'tvshowtitle': title,
            'title':       ep_title,
            'season':      season,
            'episode':     ep_num,
            'premiered':   premiered,
            'plot':        ep.get('plot', ''),
            'rating':      ep.get('rating', 0.0),
            'tmdb_id':     tmdb_id,
            'playcount':   pc,
            'overlay':     7 if pc else 6,
        }
        set_info_tag(li, meta, 'episode')

        if is_future:
            li.setIsFolder(False)
            li.setProperty('IsPlayable', 'false')
            url       = '%s?action=noaction' % addon
            is_folder = False
        else:
            if hosts_mode == 2:
                li.setIsFolder(True)
                li.setProperty('IsPlayable', 'false')
                url       = '%s?action=scoutListing&tmdb_id=%s&mt=tv&season=%d&episode=%d' % (
                    addon, tmdb_id, season, ep_num)
                is_folder = True
            else:
                li.setIsFolder(False)
                li.setProperty('IsPlayable', 'true')
                url       = '%s?action=scoutEpisode&tmdb_id=%s&title=%s&season=%d&episode=%d' % (
                    addon, tmdb_id, quote_plus(title), season, ep_num)
                is_folder = False

        cm = []
        cm.append(('Gesehen', 'RunPlugin(%s?action=markWatched&mt=episode&title=%s&season=%d&ep=%d)' % (
            addon, quote_plus(title), season, ep_num)))
        cm.append(('Ungesehen', 'RunPlugin(%s?action=markUnwatched&mt=episode&title=%s&season=%d&ep=%d)' % (
            addon, quote_plus(title), season, ep_num)))
        li.addContextMenuItems(cm)
        addItem(handle, url, li, is_folder)

    directory(handle)


def _is_future(premiered):
    if not premiered or premiered == '1900-01-01':
        return False
    from datetime import datetime
    try:
        return datetime.strptime(premiered, '%Y-%m-%d') > datetime.now()
    except Exception:
        return False
