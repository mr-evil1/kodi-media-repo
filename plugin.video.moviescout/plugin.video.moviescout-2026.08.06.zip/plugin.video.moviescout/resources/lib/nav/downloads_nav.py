import os
import time

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.control import (
    syshandle, sysaddon, getSetting,
    addItem, content, directory, plugincategory,
    addonFanart, get_video_tag,
)
from resources.lib import downloader


_STATUS_LABEL = {
    'pending':   '[COLOR yellow]Wartend…[/COLOR]',
    'running':   '[COLOR cyan]Läuft…[/COLOR]',
    'done':      '[COLOR green]Fertig[/COLOR]',
    'stopped':   '[COLOR orange]Gestoppt[/COLOR]',
    'cancelled': '[COLOR gray]Abgebrochen[/COLOR]',
    'error':     '[COLOR red]Fehler[/COLOR]',
}


def _h():
    return syshandle()


def _a():
    return sysaddon()


def _url(action, **kwargs):
    u = '%s?action=%s' % (_a(), action)
    for k, v in kwargs.items():
        u += '&%s=%s' % (k, v)
    return u


def _fmt_time(ts):
    if not ts:
        return ''
    return time.strftime('%d.%m. %H:%M', time.localtime(ts))


def _fmt_size(size_kb):
    if not size_kb:
        return ''
    if size_kb >= 1024 * 1024:
        return '%.1f GB' % (size_kb / (1024 * 1024))
    if size_kb >= 1024:
        return '%.1f MB' % (size_kb / 1024)
    return '%d KB' % size_kb


def _fmt_elapsed(started):
    if not started:
        return ''
    secs = int(time.time() - started)
    if secs < 60:
        return '%ds' % secs
    m, s = divmod(secs, 60)
    h, m = divmod(m, 60)
    if h:
        return '%d:%02d:%02d' % (h, m, s)
    return '%d:%02d' % (m, s)


def show_downloads(params):
    h = _h()
    state = downloader.get_all()

    if not state:
        li = xbmcgui.ListItem(label='Keine Downloads vorhanden')
        li.setIsFolder(False)
        addItem(h, _url('noaction'), li, False)
        content(h, 'files')
        plugincategory(h, 'Downloads')
        directory(h, cacheToDisc=False)
        return

    entries = sorted(state.values(),
                     key=lambda e: e.get('created', 0), reverse=True)

    for e in entries:
        dl_id   = e['id']
        title   = e.get('title', '?')
        status  = e.get('status', '?')
        dest    = e.get('dest', '')
        pct     = e.get('progress', 0)
        size_kb = e.get('size_kb', 0)
        started = e.get('started')
        created = e.get('created')
        is_hls  = downloader._is_hls(e.get('url', ''))

        status_str = _STATUS_LABEL.get(status, status)
        size_str   = _fmt_size(size_kb)
        time_str   = _fmt_time(created)

        label = '%s  %s' % (title, status_str)

        if status == 'running':
            if is_hls:
                elapsed = _fmt_elapsed(started)
                if elapsed:
                    label += '  [COLOR gray]%s[/COLOR]' % elapsed
            else:
                label += '  %d%%' % pct

        if size_str:
            label += '  [COLOR gray]%s[/COLOR]' % size_str
        if time_str:
            label += '  [COLOR gray]%s[/COLOR]' % time_str

        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': 'DefaultAddonProgram.png', 'fanart': addonFanart()})
        tag, shim = get_video_tag(li)
        tag.setTitle(title)

        lines = []
        lines.append('Sender / Titel:  %s' % title)
        lines.append('')

        started_ts = e.get('started')
        ended_ts   = e.get('ended')

        if started_ts:
            lines.append('Aufnahmebeginn:  %s' % _fmt_time(started_ts))
        if ended_ts:
            lines.append('Aufnahmeende:    %s' % _fmt_time(ended_ts))
        if started_ts and ended_ts and ended_ts > started_ts:
            dur_s = ended_ts - started_ts
            hrs, rem = divmod(dur_s, 3600)
            m, s   = divmod(rem, 60)
            dur_str = ('%d:%02d:%02d Std.' % (hrs, m, s)) if hrs else ('%d:%02d Min.' % (m, s))
            lines.append('Spieldauer:      %s' % dur_str)
            tag.setDuration(dur_s)
        elif started_ts and status == 'running':
            elapsed_s = int(time.time() - started_ts)
            hrs, rem = divmod(elapsed_s, 3600)
            m, s   = divmod(rem, 60)
            running_str = ('%d:%02d:%02d (läuft)' % (hrs, m, s)) if hrs else ('%d:%02d (läuft)' % (m, s))
            lines.append('Laufzeit:        %s' % running_str)

        if size_str:
            lines.append('Größe:           %s' % size_str)
        if dest:
            lines.append('')
            lines.append('Datei:  %s' % dest)

        err = e.get('error', '')
        if err:
            lines.append('')
            lines.append('Fehler:  %s' % err)

        tag.setPlot('\n'.join(lines))
        if shim:
            tag.flush()
        li.setIsFolder(False)

        ctx = []
        if status in ('running', 'pending'):
            ctx.append(('Aufnahme abbrechen',
                         'RunPlugin(%s)' % _url('downloadCancel', dl_id=dl_id)))
        ctx.append(('Aus Liste entfernen',
                     'RunPlugin(%s)' % _url('downloadRemove', dl_id=dl_id)))
        if status == 'done' and dest and os.path.exists(dest):
            ctx.append(('Datei abspielen',
                         'PlayMedia(%s)' % dest))
        li.addContextMenuItems(ctx)

        if status == 'done' and dest and os.path.exists(dest):
            li.setProperty('IsPlayable', 'true')
            item_url = _url('downloadPlay', dest=dest.replace('&', '%26'))
        else:
            item_url = _url('noaction')
        addItem(h, item_url, li, False)

    li_clear = xbmcgui.ListItem(
        label='[COLOR gray]>> Abgeschlossene / Fehler entfernen[/COLOR]')
    li_clear.setArt({'fanart': addonFanart()})
    li_clear.setIsFolder(False)
    addItem(h, _url('downloadClearDone'), li_clear, False)

    active = downloader.count_active()
    total  = downloader.count_total()
    cat    = 'Downloads (%d aktiv / %d gesamt)' % (active, total)
    content(h, 'files')
    plugincategory(h, cat)
    directory(h, cacheToDisc=False)


def cancel_download(params):
    dl_id = params.get('dl_id', '')
    if dl_id:
        downloader.cancel(dl_id)
    xbmc.executebuiltin('Container.Refresh')


def remove_download(params):
    dl_id = params.get('dl_id', '')
    if dl_id:
        downloader.remove(dl_id)
    xbmc.executebuiltin('Container.Refresh')


def clear_done(params):
    state = downloader.get_all()
    for dl_id, e in list(state.items()):
        if e.get('status') not in ('pending', 'running'):
            downloader.remove(dl_id)
    xbmc.executebuiltin('Container.Refresh')


def play_download(params):
    from urllib.parse import unquote_plus
    dest = unquote_plus(params.get('dest', ''))
    if dest and os.path.exists(dest):
        import xbmcplugin
        li = xbmcgui.ListItem(path=dest)
        xbmcplugin.setResolvedUrl(syshandle(), True, li)
    else:
        import xbmcplugin
        xbmcplugin.setResolvedUrl(syshandle(), False, xbmcgui.ListItem())
