import xbmcgui
import xbmcplugin
from urllib.parse import quote_plus
from resources.lib import tmdb, log
from resources.lib.db import search as sdb
from resources.lib.nav.listings import show_item
from resources.lib.control import (
    sysaddon, syshandle, addonPoster, addonNext,
    addItem, content, directory, plugincategory, keyboard, get_video_tag
)


def _search_input(default=''):
    kb = keyboard(default, 'Suche')
    kb.doModal()
    if not kb.isConfirmed():
        return ''
    return kb.getText().strip()


def _show_history_with_new_search(handle, addon, table):
    action = 'searchMovies' if table == 'movie' else 'searchTV'
    label  = 'Suche Filme' if table == 'movie' else 'Suche Serien'

    li_new = xbmcgui.ListItem(label='[B]» Neue Suche[/B]')
    li_new.setArt({'thumb': 'DefaultAddonsSearch.png'})
    li_new.setIsFolder(True)
    addItem(handle, '%s?action=%s&new=1' % (addon, action), li_new, True)

    rows = sdb.get_all(table)
    for row_id, query in rows:
        li = xbmcgui.ListItem(label='[COLOR gray]%s[/COLOR]' % query)
        li.setIsFolder(True)
        url = '%s?action=%s&query=%s' % (addon, action, quote_plus(query))
        cm = [('Verlauf löschen', 'RunPlugin(%s?action=searchDelEntry&id=%d)' % (addon, row_id))]
        li.addContextMenuItems(cm)
        addItem(handle, url, li, True)

    if rows:
        li_clear = xbmcgui.ListItem(label='[B][COLOR red]Verlauf löschen[/COLOR][/B]')
        li_clear.setIsFolder(False)
        addItem(handle, '%s?action=searchClearAll&table=%s' % (addon, table), li_clear, False)


def show_search_movies(params):
    handle = syshandle()
    addon  = sysaddon()
    query  = params.get('query', '')
    page   = int(params.get('page', 1))
    new    = params.get('new', '')

    if not query and not new:
        plugincategory(handle, 'Suche Filme')
        _show_history_with_new_search(handle, addon, 'movie')
        directory(handle, cacheToDisc=False)
        return

    if new and not query:
        query = _search_input()
        if not query:
            directory(handle, succeeded=False)
            return

    if page == 1:
        sdb.save(query, 'movie')

    ids, total = tmdb.search('movie', query, page)
    xbmcplugin.setContent(handle, 'movies')
    plugincategory(handle, 'Suche Filme: %s' % query)

    for tmdb_id in ids:
        show_item(tmdb_id, 'movie', addon, handle)

    if page < total:
        li = xbmcgui.ListItem(label='[B]Nächste Seite »[/B]')
        li.setArt({'thumb': addonNext()})
        li.setIsFolder(True)
        addItem(handle, '%s?action=searchMovies&query=%s&page=%d' % (addon, quote_plus(query), page + 1), li, True)

    directory(handle)


def show_search_tv(params):
    handle = syshandle()
    addon  = sysaddon()
    query  = params.get('query', '')
    page   = int(params.get('page', 1))
    new    = params.get('new', '')

    if not query and not new:
        plugincategory(handle, 'Suche Serien')
        _show_history_with_new_search(handle, addon, 'tv')
        directory(handle, cacheToDisc=False)
        return

    if new and not query:
        query = _search_input()
        if not query:
            directory(handle, succeeded=False)
            return

    if page == 1:
        sdb.save(query, 'tv')

    ids, total = tmdb.search('tvshow', query, page)
    xbmcplugin.setContent(handle, 'tvshows')
    plugincategory(handle, 'Suche Serien: %s' % query)

    for tmdb_id in ids:
        show_item(tmdb_id, 'tv', addon, handle)

    if page < total:
        li = xbmcgui.ListItem(label='[B]Nächste Seite »[/B]')
        li.setArt({'thumb': addonNext()})
        li.setIsFolder(True)
        addItem(handle, '%s?action=searchTV&query=%s&page=%d' % (addon, quote_plus(query), page + 1), li, True)

    directory(handle)


def show_search_person(params):
    handle = syshandle()
    addon  = sysaddon()
    query  = params.get('query', '')

    if not query:
        query = _search_input()
        if not query:
            directory(handle, succeeded=False)
            return

    sdb.save(query, 'person')
    results, _ = tmdb.search_person(query)
    xbmcplugin.setContent(handle, 'artists')
    plugincategory(handle, 'Person: %s' % query)

    for r in results:
        li = xbmcgui.ListItem(label=r['name'])
        li.setArt({'thumb': r.get('poster') or addonPoster()})
        tag, _shim = get_video_tag(li)
        tag.setTitle(r['name'])
        tag.setPlot(r.get('known_for', ''))
        if _shim: tag.flush()
        li.setIsFolder(True)
        url = '%s?action=personCredits&person_id=%s&name=%s' % (addon, r['tmdb_id'], quote_plus(r['name']))
        addItem(handle, url, li, True)

    directory(handle)


def _show_history(handle, addon, table):
    rows = sdb.get_all(table)
    for row_id, query in rows:
        li = xbmcgui.ListItem(label='[COLOR gray]%s[/COLOR]' % query)
        li.setIsFolder(True)
        action = 'searchMovies' if table == 'movie' else ('searchTV' if table == 'tv' else 'searchPerson')
        url = '%s?action=%s&query=%s' % (addon, action, quote_plus(query))
        cm = [('Verlauf löschen', 'RunPlugin(%s?action=searchDelEntry&id=%d)' % (addon, row_id))]
        li.addContextMenuItems(cm)
        addItem(handle, url, li, True)
    if rows:
        li_clear = xbmcgui.ListItem(label='[B][COLOR red]Verlauf löschen[/COLOR][/B]')
        li_clear.setIsFolder(False)
        addItem(handle, '%s?action=searchClearAll&table=%s' % (addon, table), li_clear, False)
