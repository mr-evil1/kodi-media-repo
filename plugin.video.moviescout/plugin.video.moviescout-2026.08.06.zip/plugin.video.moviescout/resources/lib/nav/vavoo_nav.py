import json
import os
import time

import xbmcgui
import xbmcplugin
from urllib.parse import quote_plus, unquote_plus

from resources.lib import remote, log
from resources.lib.control import (
    syshandle, sysaddon, getSetting,
    addItem, content, directory, plugincategory,
    infoDialog, addonFanart, addonProfile, get_video_tag,
)

_ORDER = [
    'Germany', 'Austria', 'Switzerland',
    'Turkey', 'Poland', 'Romania', 'Russia',
    'UK', 'USA', 'France', 'France Sport',
    'Italy', 'Spain', 'Netherlands', 'Belgium',
    'Albania', 'Arabia', 'Balkans', 'Bulgaria',
    'Croatia', 'Czech', 'Denmark', 'Finland',
    'Greece', 'Hungary', 'Israel', 'India',
    'Kurdish', 'Macedonia', 'Norway', 'Portugal',
    'Serbia', 'Sweden', 'Slovenia', 'Slovakia',
    'XXX',
]

_CACHE_TTL = 6 * 3600

_FALLBACK_BUNDLES = [
    ('vavoo.to',  'https://vavoo.to'),
    ('vavoo.net', 'https://vavoo.net'),
    ('vavoo.top', 'https://vavoo.top'),
    ('kool.to',   'https://kool.to'),
    ('oha.to',    'https://oha.to'),
    ('huhu.to',   'https://huhu.to'),
]


def _get_mod():
    mod = remote.get_vavootv()
    if mod is None:
        log.log('[VavooNav] vavootv.py nicht verfügbar – Fallback auf lokale Kopie')
    return mod


def _bundles():
    mod = _get_mod()
    if mod and hasattr(mod, 'BUNDLES'):
        return mod.BUNDLES
    return _FALLBACK_BUNDLES


def _h():
    return syshandle()


def _a():
    return sysaddon()


def _url(action, **kwargs):
    u = '%s?action=%s' % (_a(), action)
    for k, v in kwargs.items():
        u += '&%s=%s' % (k, v)
    return u


def _bundle_idx():
    idx = int(getSetting('vavoo.bundle') or '0')
    bundles = _bundles()
    if idx < 0 or idx >= len(bundles):
        idx = 0
    return idx


def _get_bundle_url():
    return _bundles()[_bundle_idx()][1]


def _get_client():
    mod = _get_mod()
    if mod is None or not hasattr(mod, 'VavooClient'):
        raise RuntimeError('vavootv.py nicht geladen – bitte Remote-Update durchführen')
    timeout = int(getSetting('vavoo.timeout') or '20')
    return mod.VavooClient(_get_bundle_url(), timeout=timeout)


def _is_adult_group(group):
    g = group.lower()
    return 'xxx' in g or 'adult' in g or 'erot' in g or 'porn' in g


def _cache_path():
    return os.path.join(addonProfile(), 'vavoo_ch_%d.json' % _bundle_idx())


def _load_from_cache():
    path = _cache_path()
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'r', encoding='utf-8') as f:
            cached = json.load(f)
        if time.time() - cached.get('ts', 0) < _CACHE_TTL:
            return cached.get('channels', [])
    except Exception:
        pass
    return None


def _save_to_cache(channels):
    path = _cache_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'ts': time.time(), 'channels': channels}, f, separators=(',', ':'))
    except Exception:
        pass


def _fetch_channels():
    import xbmc as _xbmc
    import xbmcgui as _xbmcgui
    client = _get_client()

    dp = _xbmcgui.DialogProgressBG()
    dp.create('Live TV', 'Kanäle werden geladen...')
    _start = [time.time()]

    def _on_progress(count, still_loading):
        try:
            elapsed = time.time() - _start[0]
            pct = min(95, int(elapsed / client._timeout * 95)) if still_loading else 99
            msg = '%d Kanäle geladen%s' % (count, ' ...' if still_loading else ' ✓')
            dp.update(pct, 'Live TV', msg)
        except Exception:
            pass

    raw = client.get_all_channels(adult=True, progress_callback=_on_progress)

    try:
        dp.update(100, 'Live TV', '%d Kanäle geladen ✓' % len(raw))
        _xbmc.sleep(800)
        dp.close()
    except Exception:
        pass

    channels = []
    for item in raw:
        item_url = item.get('url') or ''
        item_id = (item.get('ids') or {}).get('id', '') or item_url
        if not item_id:
            continue
        name = (item.get('name') or '').strip()
        if not name:
            continue
        group = (item.get('group') or '').strip() or 'Other'
        if _is_adult_group(group):
            group = 'XXX'
        logo = item.get('logo') or ''
        channels.append({
            'id': item_id,
            'url': item_url,
            'name': name,
            'group': group,
            'logo': logo,
        })
    _save_to_cache(channels)
    return channels


def _load_channels(force_refresh=False):
    adult = getSetting('vavoo.adult') == 'true'
    if not force_refresh:
        channels = _load_from_cache()
        if channels is not None:
            if not adult:
                channels = [c for c in channels if c['group'] != 'XXX']
            return channels
    channels = _fetch_channels()
    if not adult:
        channels = [c for c in channels if c['group'] != 'XXX']
    return channels


def show_groups(params):
    h = _h()

    mod = _get_mod()
    if mod is None:
        infoDialog('vavootv.py nicht geladen. Bitte Remote-Update durchführen.', icon='ERROR')
        directory(h, succeeded=False)
        return

    try:
        channels = _load_channels()
    except Exception as e:
        infoDialog('Fehler: %s' % e, icon='ERROR')
        directory(h, succeeded=False)
        return

    groups = {}
    for ch in channels:
        g = ch['group']
        groups.setdefault(g, []).append(ch)

    ordered = [g for g in _ORDER if g in groups]
    for g in sorted(groups):
        if g not in ordered:
            ordered.append(g)

    bundles = _bundles()
    bundle_name = bundles[_bundle_idx()][0]

    refresh_li = xbmcgui.ListItem(label='[COLOR gray]>> Kanalliste aktualisieren[/COLOR]')
    refresh_li.setArt({'thumb': 'DefaultAddonProgram.png', 'fanart': addonFanart()})
    refresh_li.setIsFolder(False)
    addItem(h, _url('vavooRefresh'), refresh_li, False)

    for g in ordered:
        count = len(groups[g])
        label = '%s  (%d)' % (g, count)
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': 'DefaultTVShows.png', 'icon': 'DefaultTVShows.png', 'fanart': addonFanart()})
        _t, _shim = get_video_tag(li); _t.setTitle(label)
        if _shim: _t.flush()
        li.setIsFolder(True)
        addItem(h, _url('vavooGroup', group=quote_plus(g)), li, True)

    content(h, 'files')
    plugincategory(h, 'Live TV - %s' % bundle_name)
    directory(h, cacheToDisc=True)


def show_group_channels(params):
    h = _h()
    group = unquote_plus(params.get('group', 'Other'))
    try:
        channels = _load_channels()
    except Exception as e:
        infoDialog('Fehler: %s' % e, icon='ERROR')
        directory(h, succeeded=False)
        return

    filtered = sorted(
        [ch for ch in channels if ch['group'] == group],
        key=lambda c: c['name'].lower()
    )

    bundle_url = _get_bundle_url()

    for ch in filtered:
        li = xbmcgui.ListItem(label=ch['name'])
        thumb = ch['logo'] or 'DefaultTVShows.png'
        li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': addonFanart()})
        tag, _shim = get_video_tag(li)
        tag.setTitle(ch['name'])
        tag.setMediaType('video')
        if _shim: tag.flush()
        li.setIsFolder(False)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('video/mp2t')
        li.setContentLookup(False)
        play_url = _url(
            'vavooPlay',
            bundle_url=quote_plus(bundle_url),
            stream_id=quote_plus(ch['url'] or ch['id']),
            name=quote_plus(ch['name']),
        )
        dl_url = _url(
            'vavooDownload',
            bundle_url=quote_plus(bundle_url),
            stream_id=quote_plus(ch['url'] or ch['id']),
            name=quote_plus(ch['name']),
        )
        li.addContextMenuItems([
            ('Download', 'RunPlugin(%s)' % dl_url),
        ])
        addItem(h, play_url, li, False)

    content(h, 'files')
    plugincategory(h, 'Live TV - %s (%d)' % (group, len(filtered)))
    directory(h, cacheToDisc=True)


def download_stream(params):
    bundle_url   = unquote_plus(params.get('bundle_url', ''))
    stream_id    = unquote_plus(params.get('stream_id', ''))
    channel_name = unquote_plus(params.get('name', 'LiveTV'))
    timeout      = int(getSetting('vavoo.timeout') or '20')

    mod = _get_mod()
    if mod is None or not hasattr(mod, 'VavooClient'):
        infoDialog('vavootv.py nicht geladen.', icon='ERROR')
        return

    try:
        client   = mod.VavooClient(bundle_url, timeout=timeout)
        resolved = client.resolve_stream_url(stream_id)
    except Exception as e:
        infoDialog('Fehler: %s' % e, icon='ERROR')
        return

    from resources.lib import downloader
    downloader.download(channel_name, resolved, 'movie')


def refresh_cache(params):
    remote.update_vavootv(force=True)
    try:
        channels = _load_channels(force_refresh=True)
        infoDialog('%d Kanaele geladen' % len(channels), icon='INFO')
    except Exception as e:
        infoDialog('Fehler: %s' % e, icon='ERROR')
    import xbmc
    xbmc.executebuiltin('Container.Refresh')


def play_channel(params):
    h = _h()
    bundle_url   = unquote_plus(params.get('bundle_url', ''))
    stream_id    = unquote_plus(params.get('stream_id', ''))
    channel_name = unquote_plus(params.get('name', 'Live TV'))
    timeout      = int(getSetting('vavoo.timeout') or '20')

    mod = _get_mod()
    if mod is None or not hasattr(mod, 'VavooClient'):
        infoDialog('vavootv.py nicht geladen. Bitte Remote-Update durchführen.', icon='ERROR')
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    try:
        client   = mod.VavooClient(bundle_url, timeout=timeout)
        resolved = client.resolve_stream_url(stream_id)
    except Exception as e:
        infoDialog('Fehler: %s' % e, icon='ERROR')
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    from resources.lib import timeshift as _ts
    if _ts.is_enabled():
        _ts.play_channel_via_timeshift(resolved, channel_name, h)
        return

    resolved_lower = resolved.lower().split('?')[0]
    if resolved_lower.endswith('.m3u8') or '/hls/' in resolved_lower:
        mime = 'application/x-mpegURL'
    elif resolved_lower.endswith('.mpd'):
        mime = 'application/dash+xml'
    else:
        mime = 'video/mp2t'
    li = xbmcgui.ListItem(path=resolved)
    li.setMimeType(mime)
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(h, True, li)
