# -*- coding: utf-8 -*-
"""
MovieScout – Trakt navigation: watchlist, history, trending, popular, auth.
"""

import xbmcgui
import xbmcplugin
from resources.lib import log, trakt, tmdb
from resources.lib.control import (
    sysaddon, syshandle, addonPoster, addonFanart, addonNext, addonName,
    addItem, content, directory, plugincategory, infoDialog
)
from resources.lib.nav.listings import _build_li


# ── helpers ───────────────────────────────────────────────────────────────────

def _folder_li(handle, addon, label, action, img='DefaultFolder.png'):
    import os
    from resources.lib.control import artPath
    path = os.path.join(artPath(), img) if not img.startswith('Default') else img
    li = xbmcgui.ListItem(label=label)
    li.setArt({'thumb': path, 'icon': img})
    li.setIsFolder(True)
    addItem(handle, '%s?action=%s' % (addon, action), li, True)


def _action_li(handle, addon, label, action, img='DefaultAddonProgram.png'):
    import os
    from resources.lib.control import artPath
    path = os.path.join(artPath(), img) if not img.startswith('Default') else img
    li = xbmcgui.ListItem(label=label)
    li.setArt({'thumb': path, 'icon': img})
    li.setIsFolder(False)
    li.setProperty('IsPlayable', 'false')
    addItem(handle, '%s?action=%s' % (addon, action), li, False)


def _tmdb_id_from_item(item, media_type):
    """Extract TMDB ID from a Trakt API response item."""
    # trending/watchlist/history: {'movie': {..., 'ids': {'tmdb': N}}}
    # popular/anticipated: flat {'ids': {'tmdb': N}} or wrapped
    if media_type == 'movies':
        obj = item.get('movie') or item
    else:
        obj = item.get('show') or item
    return obj.get('ids', {}).get('tmdb')


def _render_list(handle, addon, items, media_type, page, next_action):
    """Fetch TMDB metadata for Trakt items and add to Kodi listing."""
    mt = 'movie' if media_type == 'movies' else 'tv'
    xbmcplugin.setContent(handle, 'movies' if mt == 'movie' else 'tvshows')
    shown = 0
    for item in items:
        try:
            tmdb_id = _tmdb_id_from_item(item, media_type)
            if not tmdb_id:
                continue
            meta = tmdb.get_movie(tmdb_id) if mt == 'movie' else tmdb.get_tvshow(tmdb_id)
            if not meta:
                continue
            url, li, is_folder = _build_li(str(tmdb_id), meta, addon, mt)

            # Add Trakt context menu items
            cm = []
            title_enc = __import__('urllib.parse', fromlist=['quote_plus']).quote_plus(meta.get('title', ''))
            imdb_id   = meta.get('imdb_id', '')
            cm.append(('[Trakt] Zur Watchlist hinzufügen',
                       'RunPlugin(%s?action=traktAddWatchlist&title=%s&tmdb_id=%s&imdb_id=%s&mt=%s)'
                       % (addon, title_enc, tmdb_id, imdb_id, 'movie' if mt == 'movie' else 'tvshow')))
            cm.append(('[Trakt] Bewerten',
                       'RunPlugin(%s?action=traktRate&title=%s&tmdb_id=%s&imdb_id=%s&mt=%s)'
                       % (addon, title_enc, tmdb_id, imdb_id, 'movie' if mt == 'movie' else 'tvshow')))
            existing_cm = li.getContextMenuItems()
            li.addContextMenuItems(list(existing_cm) + cm)

            addItem(handle, url, li, is_folder)
            shown += 1
        except Exception:
            log.error()

    if shown >= 30:
        li_next = xbmcgui.ListItem(label='[B]Nächste Seite »[/B]')
        li_next.setArt({'thumb': addonNext(), 'icon': addonNext()})
        li_next.setIsFolder(True)
        addItem(handle, '%s?action=%s&page=%d' % (addon, next_action, page + 1), li_next, True)


# ── Root menu ─────────────────────────────────────────────────────────────────

def show_root():
    handle = syshandle()
    addon  = sysaddon()

    if not trakt.is_enabled():
        infoDialog('Trakt ist deaktiviert – bitte in den Einstellungen aktivieren.',
                   icon='WARNING')
        directory(handle, succeeded=False, cacheToDisc=False)
        return

    if not trakt.is_authorized():
        _action_li(handle, addon, '[COLOR orange][B]⚠ Trakt autorisieren[/B][/COLOR]',
                   'traktAuth', 'DefaultAddonProgram.png')
    else:
        _folder_li(handle, addon, '[B]Watchlist[/B] – Filme',     'traktWatchlistMovies',  'DefaultMovies.png')
        _folder_li(handle, addon, '[B]Watchlist[/B] – Serien',    'traktWatchlistShows',   'DefaultTVShows.png')
        _folder_li(handle, addon, '[B]Verlauf[/B] – Filme',       'traktHistoryMovies',    'DefaultMovies.png')
        _folder_li(handle, addon, '[B]Verlauf[/B] – Serien',      'traktHistoryShows',     'DefaultTVShows.png')
        _folder_li(handle, addon, '[B]Trending[/B] – Filme',      'traktTrendingMovies',   'DefaultMovies.png')
        _folder_li(handle, addon, '[B]Trending[/B] – Serien',     'traktTrendingShows',    'DefaultTVShows.png')
        _folder_li(handle, addon, '[B]Beliebt[/B] – Filme',       'traktPopularMovies',    'DefaultMovies.png')
        _folder_li(handle, addon, '[B]Beliebt[/B] – Serien',      'traktPopularShows',     'DefaultTVShows.png')
        _folder_li(handle, addon, '[B]Erwartet[/B] – Filme',      'traktAnticipatedMovies','DefaultMovies.png')
        _folder_li(handle, addon, '[B]Erwartet[/B] – Serien',     'traktAnticipatedShows', 'DefaultTVShows.png')
        _action_li(handle, addon, 'Trakt abmelden',                'traktLogout',           'DefaultAddonProgram.png')

    content(handle, '')
    plugincategory(handle, 'Trakt')
    directory(handle, cacheToDisc=False)


# ── Watchlist ─────────────────────────────────────────────────────────────────

def show_watchlist_movies(params):
    handle = syshandle()
    addon  = sysaddon()
    page   = int(params.get('page', 1))
    if not trakt.is_authorized():
        infoDialog('Trakt nicht autorisiert.', icon='WARNING')
        directory(handle, succeeded=False, cacheToDisc=False)
        return
    items = trakt.get_watchlist('movies', page=page)
    _render_list(handle, addon, items, 'movies', page, 'traktWatchlistMovies')
    plugincategory(handle, 'Trakt Watchlist – Filme')
    directory(handle)


def show_watchlist_shows(params):
    handle = syshandle()
    addon  = sysaddon()
    page   = int(params.get('page', 1))
    if not trakt.is_authorized():
        infoDialog('Trakt nicht autorisiert.', icon='WARNING')
        directory(handle, succeeded=False, cacheToDisc=False)
        return
    items = trakt.get_watchlist('shows', page=page)
    _render_list(handle, addon, items, 'shows', page, 'traktWatchlistShows')
    plugincategory(handle, 'Trakt Watchlist – Serien')
    directory(handle)


# ── History ───────────────────────────────────────────────────────────────────

def show_history_movies(params):
    handle = syshandle()
    addon  = sysaddon()
    page   = int(params.get('page', 1))
    if not trakt.is_authorized():
        infoDialog('Trakt nicht autorisiert.', icon='WARNING')
        directory(handle, succeeded=False, cacheToDisc=False)
        return
    items = trakt.get_history('movies', page=page)
    _render_list(handle, addon, items, 'movies', page, 'traktHistoryMovies')
    plugincategory(handle, 'Trakt Verlauf – Filme')
    directory(handle)


def show_history_shows(params):
    handle = syshandle()
    addon  = sysaddon()
    page   = int(params.get('page', 1))
    if not trakt.is_authorized():
        infoDialog('Trakt nicht autorisiert.', icon='WARNING')
        directory(handle, succeeded=False, cacheToDisc=False)
        return
    items = trakt.get_history('shows', page=page)
    _render_list(handle, addon, items, 'shows', page, 'traktHistoryShows')
    plugincategory(handle, 'Trakt Verlauf – Serien')
    directory(handle)


# ── Trending ──────────────────────────────────────────────────────────────────

def show_trending_movies(params):
    handle = syshandle()
    addon  = sysaddon()
    page   = int(params.get('page', 1))
    items  = trakt.get_trending('movies', page=page)
    _render_list(handle, addon, items, 'movies', page, 'traktTrendingMovies')
    plugincategory(handle, 'Trakt Trending – Filme')
    directory(handle)


def show_trending_shows(params):
    handle = syshandle()
    addon  = sysaddon()
    page   = int(params.get('page', 1))
    items  = trakt.get_trending('shows', page=page)
    _render_list(handle, addon, items, 'shows', page, 'traktTrendingShows')
    plugincategory(handle, 'Trakt Trending – Serien')
    directory(handle)


# ── Popular ───────────────────────────────────────────────────────────────────

def show_popular_movies(params):
    handle = syshandle()
    addon  = sysaddon()
    page   = int(params.get('page', 1))
    # popular endpoint returns flat list of movie objects → wrap for _render_list
    raw   = trakt.get_popular('movies', page=page)
    items = [{'movie': m} for m in raw]
    _render_list(handle, addon, items, 'movies', page, 'traktPopularMovies')
    plugincategory(handle, 'Trakt Beliebt – Filme')
    directory(handle)


def show_popular_shows(params):
    handle = syshandle()
    addon  = sysaddon()
    page   = int(params.get('page', 1))
    raw   = trakt.get_popular('shows', page=page)
    items = [{'show': s} for s in raw]
    _render_list(handle, addon, items, 'shows', page, 'traktPopularShows')
    plugincategory(handle, 'Trakt Beliebt – Serien')
    directory(handle)


# ── Anticipated ───────────────────────────────────────────────────────────────

def show_anticipated_movies(params):
    handle = syshandle()
    addon  = sysaddon()
    page   = int(params.get('page', 1))
    items  = trakt.get_anticipated('movies', page=page)
    _render_list(handle, addon, items, 'movies', page, 'traktAnticipatedMovies')
    plugincategory(handle, 'Trakt Erwartet – Filme')
    directory(handle)


def show_anticipated_shows(params):
    handle = syshandle()
    addon  = sysaddon()
    page   = int(params.get('page', 1))
    items  = trakt.get_anticipated('shows', page=page)
    _render_list(handle, addon, items, 'shows', page, 'traktAnticipatedShows')
    plugincategory(handle, 'Trakt Erwartet – Serien')
    directory(handle)


# ── Auth actions ──────────────────────────────────────────────────────────────

def do_auth():
    handle = syshandle()
    if not trakt._client_id() or not trakt._client_secret():
        xbmcgui.Dialog().ok(
            addonName(),
            'Bitte zuerst [B]Client-ID[/B] und [B]Client-Secret[/B] '
            'im Trakt-Reiter der Einstellungen eintragen.\n\n'
            'Kostenlose App unter: [B]trakt.tv/oauth/applications[/B]'
        )
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return

    code_data = trakt.start_device_auth()
    if not code_data:
        infoDialog('Trakt: Server nicht erreichbar.', icon='ERROR')
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return

    user_code   = code_data.get('user_code', '')
    verify_url  = code_data.get('verification_url', 'trakt.tv/activate')
    device_code = code_data.get('device_code', '')
    expires_in  = int(code_data.get('expires_in', 600))
    interval    = int(code_data.get('interval', 5))

    xbmcgui.Dialog().ok(
        'Trakt autorisieren',
        '1. Öffne [B]%s[/B]\n'
        '2. Gib diesen Code ein:  [B][COLOR yellow]%s[/COLOR][/B]\n\n'
        'Dann OK drücken – der Dialog wartet auf die Bestätigung.'
        % (verify_url, user_code)
    )

    success = trakt.poll_device_auth(device_code, interval, expires_in)
    if success:
        infoDialog('Trakt erfolgreich autorisiert!', icon='INFO')
    else:
        infoDialog('Autorisierung fehlgeschlagen oder abgebrochen.', icon='ERROR')
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


def do_logout():
    handle = syshandle()
    if xbmcgui.Dialog().yesno(addonName(), 'Von Trakt abmelden?'):
        trakt.logout()
        infoDialog('Von Trakt abgemeldet.')
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


# ── Watchlist add/remove (context menu) ───────────────────────────────────────

def add_to_watchlist(params):
    handle = syshandle()
    from urllib.parse import unquote_plus
    meta = {
        'title':     unquote_plus(params.get('title', '')),
        'tmdb_id':   params.get('tmdb_id', ''),
        'imdb_id':   params.get('imdb_id', ''),
        'mediatype': params.get('mt', 'movie'),
    }
    if trakt.add_to_watchlist(meta):
        infoDialog('Zur Watchlist hinzugefügt: %s' % meta['title'])
    else:
        infoDialog('Watchlist-Fehler.', icon='ERROR')
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


def remove_from_watchlist(params):
    handle = syshandle()
    from urllib.parse import unquote_plus
    meta = {
        'title':     unquote_plus(params.get('title', '')),
        'tmdb_id':   params.get('tmdb_id', ''),
        'imdb_id':   params.get('imdb_id', ''),
        'mediatype': params.get('mt', 'movie'),
    }
    if trakt.remove_from_watchlist(meta):
        infoDialog('Von Watchlist entfernt: %s' % meta['title'])
    else:
        infoDialog('Watchlist-Fehler.', icon='ERROR')
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


# ── Rating dialog ─────────────────────────────────────────────────────────────

def rate_dialog(params):
    handle = syshandle()
    from urllib.parse import unquote_plus
    title = unquote_plus(params.get('title', ''))
    meta  = {
        'title':     title,
        'tmdb_id':   params.get('tmdb_id', ''),
        'imdb_id':   params.get('imdb_id', ''),
        'mediatype': params.get('mt', 'movie'),
    }
    if not trakt.is_authorized():
        infoDialog('Trakt nicht autorisiert.', icon='WARNING')
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return

    labels = [
        '1 – Grauenhaft', '2 – Furchtbar', '3 – Schlecht',
        '4 – Enttäuschend', '5 – Mittelmäßig', '6 – Gut',
        '7 – Sehr gut', '8 – Großartig', '9 – Überragend', '10 – Meisterwerk',
    ]
    idx = xbmcgui.Dialog().select('Trakt-Bewertung: ' + title, labels)
    if idx >= 0:
        if trakt.rate_item(meta, idx + 1):
            infoDialog('Bewertet %d/10: %s' % (idx + 1, title))
        else:
            infoDialog('Bewertung fehlgeschlagen.', icon='ERROR')
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
