import xbmcgui
import xbmcplugin
from urllib.parse import quote_plus
from resources.lib import log, remote
from resources.lib.control import (
    sysaddon, syshandle, addonName, addonPoster,
    addItem, directory, plugincategory, infoDialog,
    execute, keyboard, get_video_tag
)


def _label_color(info):
    if info['disabled']:
        return 'red'
    if not info['cached']:
        return 'orange'
    return 'green'


def _status_text(info):
    if info['disabled']:
        return 'AUS'
    if not info['cached']:
        return 'AN – nicht gecacht'
    return 'AN'


def _domain_for(info):
    custom = remote.get_scraper_domain(info['name'])
    if custom:
        return custom
    m = remote._load_module(info['name'])
    if m and hasattr(m, 'SITE_DOMAIN'):
        return m.SITE_DOMAIN
    return info.get('domain', '')


def _plot(info):
    custom = remote.get_scraper_domain(info['name'])
    domain = _domain_for(info)
    lines = [
        'Typ:     %s' % info['type'],
        'Version: %s' % info['version'],
        '',
        '[B]Domain / URL:[/B]',
        '[COLOR cyan]%s[/COLOR]' % domain,
    ]
    if custom:
        lines += ['', '[COLOR orange]► Benutzerdefiniert (überschrieben)[/COLOR]']
    else:
        lines += ['', '[COLOR gray](aus Scraper-Modul / Manifest)[/COLOR]']
    lines.append('')
    lines.append('Gecacht: %s' % ('Ja' if info['cached'] else 'Nein'))
    return '\n'.join(lines)


def show_manager():
    handle   = syshandle()
    addon    = sysaddon()
    scrapers = remote.get_all_scraper_info()

    if not scrapers:
        infoDialog('Keine Scraper im Manifest. Remote-Update durchführen.', icon='WARNING')
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return

    xbmcplugin.setContent(handle, '')
    plugincategory(handle, 'Scraper Manager')

    _add_global_actions(handle, addon)

    for info in sorted(scrapers, key=lambda x: x['name']):
        name   = info['name']
        color  = _label_color(info)
        status = _status_text(info)
        domain = _domain_for(info)
        custom = remote.get_scraper_domain(name)

        label = '[COLOR %s][%s][/COLOR]  [B]%s[/B]  [COLOR cyan]%s[/COLOR]' % (
            color, status, name, domain)

        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': addonPoster()})
        tag, _shim = get_video_tag(li)
        tag.setTitle(name)
        tag.setPlot(_plot(info))
        if _shim: tag.flush()
        li.setIsFolder(False)
        li.setProperty('IsPlayable', 'false')

        cm = []
        if info['disabled']:
            cm.append(('Aktivieren',
                       'RunPlugin(%s?action=scraperEnable&name=%s)' % (addon, name)))
        else:
            cm.append(('Deaktivieren',
                       'RunPlugin(%s?action=scraperDisable&name=%s)' % (addon, name)))

        cm.append(('Domain / URL setzen',
                   'RunPlugin(%s?action=scraperSetDomain&name=%s)' % (addon, name)))

        if custom:
            cm.append(('Domain zuruecksetzen (Original)',
                       'RunPlugin(%s?action=scraperResetDomain&name=%s)' % (addon, name)))

        cm.append(('Neu laden',
                   'RunPlugin(%s?action=scraperForceOne&name=%s)' % (addon, name)))

        li.addContextMenuItems(cm)

        url = '%s?action=scraperManager' % addon
        addItem(handle, url, li, False)

    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def _add_global_actions(handle, addon):
    rows = [
        ('[B][COLOR cyan]Alle aktivieren[/COLOR][/B]',      'scraperEnableAll'),
        ('[B][COLOR red]Alle deaktivieren[/COLOR][/B]',     'scraperDisableAll'),
        ('[B][COLOR yellow]Alle aktualisieren[/COLOR][/B]', 'scraperForceUpdate'),
        ('[B][COLOR gray]Cache loeschen[/COLOR][/B]',       'scraperClearCache'),
    ]
    for label, action in rows:
        li = xbmcgui.ListItem(label=label)
        li.setIsFolder(False)
        li.setProperty('IsPlayable', 'false')
        tag, _shim = get_video_tag(li)
        tag.setTitle(label)
        if _shim: tag.flush()
        addItem(handle, '%s?action=%s' % (addon, action), li, False)


def set_domain(params):
    handle  = syshandle()
    name    = params.get('name', '')
    current = remote.get_scraper_domain(name)

    kb = keyboard(current, 'Domain für %s  (z.B. einschalten.in)' % name)
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return

    val = kb.getText().strip()
    if val:
        remote.set_scraper_domain(name, val)
        remote._MODULE_CACHE.pop(name, None)
        infoDialog('Domain gesetzt: %s' % val)
    else:
        infoDialog('Leer eingegeben – keine Änderung.', icon='WARNING')

    execute('Container.Refresh')
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


def reset_domain(params):
    handle = syshandle()
    name   = params.get('name', '')
    remote.clear_scraper_domain(name)
    remote._MODULE_CACHE.pop(name, None)
    infoDialog('Domain zurückgesetzt auf Original.')
    execute('Container.Refresh')
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


def force_one(params):
    handle = syshandle()
    name   = params.get('name', '')
    ok = remote.force_download_one(name)
    infoDialog('%s aktualisiert.' % name if ok else 'Fehler: %s' % name,
               icon='INFO' if ok else 'ERROR')
    execute('Container.Refresh')
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
