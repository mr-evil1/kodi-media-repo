import re
import sys
import xbmcgui
import xbmcplugin
from resources.lib import log, remote, multiquest
from resources.lib.control import sysaddon, syshandle, addonName, infoDialog

_CF_RE = re.compile(r'cf-browser-verification|cf_chl_prog|checking your browser|DDoS protection', re.I)
_ERR_RE = re.compile(
    r'domain.{0,20}(for sale|parked|kaufen)|404.{0,20}(not found|error)|'
    r'access denied|403 forbidden|website unavailable|suspended.{0,40}(account|domain)', re.I)


def _fmt_err(e):
    err = str(e).lower()
    if 'max retries' in err or 'connectionpool' in err:
        return 'Nicht erreichbar (Timeout/Retries)'
    if 'timed out' in err or 'timeout' in err:
        return 'Timeout'
    if 'name or service not known' in err or 'nodename nor servname' in err or 'getaddrinfo' in err:
        return 'DNS nicht auflösbar'
    if 'connection refused' in err:
        return 'Verbindung abgelehnt'
    if 'remote end closed' in err or 'connection reset' in err:
        return 'Verbindung getrennt'
    return str(e)[:60]


def _check_domain(domain):
    if not domain:
        return 'unknown', 'Keine Domain'
    for scheme in ('https://', 'http://'):
        try:
            r = multiquest.get(scheme + domain, timeout=8, use_cf=True)
            body = r.text[:4096]
            if _CF_RE.search(body):
                return 'cloudflare', 'Cloudflare-Challenge'
            if _ERR_RE.search(body):
                return 'error', 'Fehlerseite (%d)' % r.status_code
            if r.status_code >= 500:
                return 'down', 'Server-Fehler %d' % r.status_code
            if r.status_code == 410:
                return 'down', 'HTTP 410 Gone'
            return 'ok', 'HTTP %d' % r.status_code
        except Exception as e:
            err = str(e)
            if 'ssl' in err.lower() or 'SSL' in err:
                continue
            return 'down', _fmt_err(e)
    return 'down', 'Nicht erreichbar'


def _status_color(status):
    return {'ok': 'green', 'cloudflare': 'orange', 'down': 'red', 'error': 'red', 'unknown': 'gray'}.get(status, 'gray')


def run_as_listing():
    handle = syshandle()
    addon  = sysaddon()
    scrapers = remote.get_all_scraper_info()
    if not scrapers:
        infoDialog('Keine Remote-Scraper im Manifest.')
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    dp = xbmcgui.DialogProgress()
    dp.create(addonName(), 'Scraper-Check läuft...')
    total = len(scrapers)
    results = []
    for i, s in enumerate(scrapers):
        if dp.iscanceled():
            break
        dp.update(int(i * 100 / total), 'Prüfe: %s' % s['name'])
        status, reason = _check_domain(s['domain'])
        results.append({**s, 'status': status, 'reason': reason})
    dp.close()

    xbmcplugin.setContent(handle, '')
    xbmcplugin.setPluginCategory(handle, 'Scraper Checker')

    for r in sorted(results, key=lambda x: x['status']):
        color  = _status_color(r['status'])
        label  = '[COLOR %s][%s][/COLOR]  %s  (%s)' % (color, r['status'].upper(), r['name'], r['type'])
        detail = '%s | %s | %s' % (r['domain'], r['status'], r['reason'])
        li = xbmcgui.ListItem(label=label)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(r['name'])
            tag.setPlot(detail)
        except AttributeError:
            li.setInfo('video', {'title': r['name'], 'plot': detail})
        li.setIsFolder(False)

        cm = []
        if r['disabled']:
            cm.append(('Aktivieren', 'RunPlugin(%s?action=scraperEnable&name=%s)' % (addon, r['name'])))
        else:
            cm.append(('Deaktivieren', 'RunPlugin(%s?action=scraperDisable&name=%s)' % (addon, r['name'])))
        li.addContextMenuItems(cm)

        url = '%s?action=scraperDetail&name=%s&status=%s&reason=%s&domain=%s&type=%s' % (
            addon, r['name'], r['status'], r['reason'], r['domain'], r['type'])
        xbmcplugin.addDirectoryItem(handle, url, li, False)

    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def show_detail(params):
    text = (
        'Name:     %s\n'
        'Typ:      %s\n'
        'Domain:   %s\n'
        'Status:   %s\n'
        'Grund:    %s'
    ) % (params.get('name'), params.get('type'), params.get('domain'), params.get('status'), params.get('reason'))
    xbmcgui.Dialog().textviewer(params.get('name', 'Detail'), text)
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)
