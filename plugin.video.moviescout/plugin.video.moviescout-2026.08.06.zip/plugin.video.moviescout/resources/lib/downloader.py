import json
import os
import re
import threading
import time
from urllib.parse import urljoin, urlparse

import xbmcgui

from resources.lib import log
from resources.lib.control import getSetting, addonName, addonProfile

_STATE_FILE = 'downloads.json'
_LOCK = threading.Lock()

_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) '
    'Gecko/20100101 Firefox/128.0'
)

_DOWNLOAD_PATHS = [
    '/storage/emulated/0/Download',
    '/storage/emulated/0/Downloads',
    '/storage/self/primary/Download',
    '/sdcard/Download',
    '/sdcard/Downloads',
    os.path.expanduser('~/Downloads'),
]

_HEADERS = {'User-Agent': _UA}


def _android_downloads():
    try:
        from jnius import autoclass
        Environment = autoclass('android.os.Environment')
        d = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_DOWNLOADS)
        path = d.getAbsolutePath()
        if path:
            return path
    except Exception:
        pass
    return None


def _writable(path):
    try:
        os.makedirs(path, exist_ok=True)
        test = os.path.join(path, '.write_test')
        open(test, 'w').close()
        os.remove(test)
        return True
    except Exception:
        return False


def _dest_dir(mediatype='movie'):
    key = 'download.movie.path' if mediatype != 'tvshow' else 'download.tv.path'
    base = getSetting(key)
    if base and _writable(base):
        return base

    android = _android_downloads()
    if android and _writable(android):
        log.log('[downloader] Speicherort (Android API): %s' % android)
        return android

    for p in _DOWNLOAD_PATHS:
        if _writable(p):
            log.log('[downloader] Speicherort (Fallback): %s' % p)
            return p

    fallback = os.path.expanduser('~/Downloads')
    os.makedirs(fallback, exist_ok=True)
    return fallback


def _safe_name(name):
    return re.sub(r'[\\/\:*?"<>|]', '', name).strip()


def _state_path():
    return os.path.join(addonProfile(), _STATE_FILE)


def _load_state():
    try:
        p = _state_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save_state(state):
    try:
        p = _state_path()
        d = os.path.dirname(p)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(p, 'w', encoding='utf-8') as f:
            json.dump(state, f, ensure_ascii=False, separators=(',', ':'))
    except Exception:
        pass


def _update_entry(dl_id, **kwargs):
    with _LOCK:
        state = _load_state()
        entry = state.get(dl_id, {})
        entry.update(kwargs)
        state[dl_id] = entry
        _save_state(state)


def _notify(msg, error=False):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification(addonName(), msg, icon, 4000)


def _is_hls(url):
    return '.m3u8' in (url or '').lower()


def _is_cancelled(dl_id):
    with _LOCK:
        state = _load_state()
    return state.get(dl_id, {}).get('status') == 'cancelled'


def _make_session():
    try:
        import requests
        s = requests.Session()
        s.headers.update(_HEADERS)
        return s
    except ImportError:
        return None


def _get(session, url, stream=False, timeout=20, extra_headers=None):
    if extra_headers:
        return session.get(url, stream=stream, timeout=timeout,
                           headers={**_HEADERS, **extra_headers})
    return session.get(url, stream=stream, timeout=timeout)


def _pick_best_variant(lines, base_url):
    variants = []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith('#EXT-X-STREAM-INF'):
            bw = 0
            m = re.search(r'BANDWIDTH=(\d+)', line)
            if m:
                bw = int(m.group(1))
            i += 1
            while i < len(lines) and lines[i].strip().startswith('#'):
                i += 1
            if i < len(lines) and lines[i].strip():
                variants.append((bw, lines[i].strip()))
        i += 1
    if not variants:
        return None
    variants.sort(key=lambda x: x[0], reverse=True)
    uri = variants[0][1]
    if uri.startswith('http'):
        return uri
    return urljoin(base_url, uri)


def _parse_segments(text, base_url):
    segments = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('http'):
            segments.append(line)
        else:
            segments.append(urljoin(base_url, line))
    return segments


def _run_hls(dl_id, title, url, dest):
    session = _make_session()
    if session is None:
        _notify('requests nicht verfügbar', error=True)
        _update_entry(dl_id, status='error', error='requests fehlt',
                      ended=int(time.time()))
        return

    _notify('Aufnahme gestartet: %s' % title)
    _update_entry(dl_id, status='running', started=int(time.time()), dest=dest)
    log.log('[downloader] HLS start: %s → %s' % (url, dest))

    try:
        r = _get(session, url, timeout=20)
        r.raise_for_status()
        text = r.text
        base = url.split('?')[0].rsplit('/', 1)[0] + '/'

        if '#EXT-X-STREAM-INF' in text:
            variant_url = _pick_best_variant(text.splitlines(), base)
            if not variant_url:
                raise ValueError('Kein Variant-Stream gefunden')
            r = _get(session, variant_url, timeout=20)
            r.raise_for_status()
            text = r.text
            base = variant_url.split('?')[0].rsplit('/', 1)[0] + '/'

        is_live = '#EXT-X-ENDLIST' not in text
        seen = set()
        total_segs = 0
        done_segs = 0

        with open(dest, 'wb') as f:
            start_time = time.time()

            while True:
                if _is_cancelled(dl_id):
                    log.log('[downloader] HLS gestoppt: %s' % dest)
                    size_kb = 0
                    try:
                        size_kb = os.path.getsize(dest) // 1024
                    except Exception:
                        pass
                    _notify('Aufnahme gespeichert: %s' % title)
                    _update_entry(dl_id, status='done', ended=int(time.time()),
                                  progress=100, size_kb=size_kb)
                    return

                segs = _parse_segments(text, base)
                new_segs = [s for s in segs if s not in seen]
                total_segs += len(new_segs)

                for seg_url in new_segs:
                    if _is_cancelled(dl_id):
                        break
                    try:
                        sr = _get(session, seg_url, stream=True, timeout=15)
                        sr.raise_for_status()
                        for chunk in sr.iter_content(chunk_size=1024 * 128):
                            if chunk:
                                f.write(chunk)
                    except Exception as seg_exc:
                        log.log('[downloader] Segment-Fehler: %s – %s' %
                                (seg_url, seg_exc))
                    seen.add(seg_url)
                    done_segs += 1
                    if total_segs > 0:
                        _update_entry(dl_id,
                                      progress=min(99, int(done_segs * 100 / total_segs)),
                                      size_kb=f.tell() // 1024)

                if not is_live:
                    break

                elapsed = int(time.time() - start_time)
                _update_entry(dl_id, elapsed=elapsed,
                              size_kb=f.tell() // 1024)

                time.sleep(4)

                try:
                    r2 = _get(session, url, timeout=20)
                    r2.raise_for_status()
                    text = r2.text
                    base = url.split('?')[0].rsplit('/', 1)[0] + '/'
                    if '#EXT-X-STREAM-INF' in text:
                        vu = _pick_best_variant(text.splitlines(), base)
                        if vu:
                            r2 = _get(session, vu, timeout=20)
                            r2.raise_for_status()
                            text = r2.text
                            base = vu.split('?')[0].rsplit('/', 1)[0] + '/'
                except Exception:
                    pass

        size_kb = os.path.getsize(dest) // 1024
        _notify('Aufnahme abgeschlossen: %s' % title)
        _update_entry(dl_id, status='done', ended=int(time.time()),
                      progress=100, size_kb=size_kb)
        log.log('[downloader] HLS fertig: %s (%d KB)' % (dest, size_kb))

    except Exception as exc:
        _notify('Aufnahme-Fehler: %s' % title, error=True)
        _update_entry(dl_id, status='error', error=str(exc),
                      ended=int(time.time()))
        log.log('[downloader] HLS Fehler: %s' % exc)
        try:
            log.error()
        except Exception:
            pass


def _run_http(dl_id, title, url, dest):
    try:
        from resources.lib import multiquest
        _notify('Download gestartet: %s' % title)
        _update_entry(dl_id, status='running', started=int(time.time()), dest=dest)
        log.log('[downloader] HTTP start: %s → %s' % (url, dest))

        r, total = multiquest.get_stream(url, timeout=30)
        done = 0
        with open(dest, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024 * 256):
                if not chunk:
                    continue
                if _is_cancelled(dl_id):
                    log.log('[downloader] HTTP gestoppt: %s' % dest)
                    _notify('Download gespeichert: %s' % title)
                    _update_entry(dl_id, status='done', ended=int(time.time()),
                                  progress=100, size_kb=done // 1024)
                    return
                f.write(chunk)
                done += len(chunk)
                pct = int(done * 100 / total) if total else 0
                _update_entry(dl_id, progress=pct, size_kb=done // 1024)

        _notify('Download abgeschlossen: %s' % title)
        _update_entry(dl_id, status='done', ended=int(time.time()),
                      progress=100, size_kb=done // 1024)
        log.log('[downloader] HTTP fertig: %s' % dest)

    except Exception as exc:
        _notify('Download-Fehler: %s' % title, error=True)
        _update_entry(dl_id, status='error', error=str(exc),
                      ended=int(time.time()))
        log.log('[downloader] HTTP Fehler: %s' % exc)
        try:
            log.error()
        except Exception:
            pass


def download(title, url, mediatype='movie'):
    dl_id = '%d' % int(time.time() * 1000)
    safe = _safe_name(title)
    ext = '.ts' if _is_hls(url) else '.mp4'
    dest = os.path.join(_dest_dir(mediatype), safe + ext)

    with _LOCK:
        state = _load_state()
        state[dl_id] = {
            'id': dl_id,
            'title': title,
            'url': url,
            'dest': dest,
            'status': 'pending',
            'mediatype': mediatype,
            'created': int(time.time()),
            'progress': 0,
            'size_kb': 0,
        }
        _save_state(state)

    if _is_hls(url):
        t = threading.Thread(target=_run_hls,
                             args=(dl_id, title, url, dest), daemon=True)
    else:
        t = threading.Thread(target=_run_http,
                             args=(dl_id, title, url, dest), daemon=True)
    t.start()
    return dl_id


def cancel(dl_id):
    with _LOCK:
        state = _load_state()
        entry = state.get(dl_id)
        if not entry:
            return
        entry['status'] = 'done'
        entry['ended'] = int(time.time())
        state[dl_id] = entry
        _save_state(state)


def remove(dl_id):
    with _LOCK:
        state = _load_state()
        state.pop(dl_id, None)
        _save_state(state)


def get_all():
    with _LOCK:
        return _load_state()


def has_active():
    state = get_all()
    return any(e.get('status') in ('pending', 'running')
               for e in state.values())


def count_active():
    state = get_all()
    return sum(1 for e in state.values()
               if e.get('status') in ('pending', 'running'))


def count_total():
    return len(get_all())
