import os
import sqlite3
from resources.lib.control import addonProfile

_DB = os.path.join(addonProfile(), 'playcount.db')

def _conn():
    os.makedirs(os.path.dirname(_DB), exist_ok=True)
    c = sqlite3.connect(_DB, check_same_thread=False)
    c.execute('''CREATE TABLE IF NOT EXISTS playcount (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        mediatype TEXT, title TEXT, imdb_id TEXT,
        season INTEGER DEFAULT 0, episode INTEGER DEFAULT 0,
        playcount INTEGER DEFAULT 0)''')
    c.commit()
    return c

def get(mediatype, title, imdb_id='', season=0, episode=0):
    with _conn() as c:
        row = c.execute(
            'SELECT playcount FROM playcount WHERE mediatype=? AND title=? AND season=? AND episode=?',
            (mediatype, title, season, episode)).fetchone()
        return row[0] if row else 0

def set(mediatype, title, imdb_id='', season=0, episode=0, playcount=1):
    with _conn() as c:
        row = c.execute(
            'SELECT id FROM playcount WHERE mediatype=? AND title=? AND season=? AND episode=?',
            (mediatype, title, season, episode)).fetchone()
        if row:
            c.execute('UPDATE playcount SET playcount=? WHERE id=?', (playcount, row[0]))
        else:
            c.execute('INSERT INTO playcount (mediatype,title,imdb_id,season,episode,playcount) VALUES (?,?,?,?,?,?)',
                      (mediatype, title, imdb_id, season, episode, playcount))
