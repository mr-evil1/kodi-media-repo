import os
import sqlite3
from resources.lib.control import addonProfile

_DB = os.path.join(addonProfile(), 'bookmark.db')

def _conn():
    os.makedirs(os.path.dirname(_DB), exist_ok=True)
    c = sqlite3.connect(_DB, check_same_thread=False)
    c.execute('CREATE TABLE IF NOT EXISTS bookmark (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, offset REAL DEFAULT 0)')
    c.commit()
    return c

def get(name):
    with _conn() as c:
        row = c.execute('SELECT offset FROM bookmark WHERE name=?', (name,)).fetchone()
        return row[0] if row else 0.0

def set(name, offset):
    with _conn() as c:
        c.execute('INSERT OR REPLACE INTO bookmark (name, offset) VALUES (?,?)', (name, offset))

def delete(name):
    with _conn() as c:
        c.execute('DELETE FROM bookmark WHERE name=?', (name,))
