import os
import sqlite3
from resources.lib.control import addonProfile

_DB = os.path.join(addonProfile(), 'search.db')

def _conn():
    os.makedirs(os.path.dirname(_DB), exist_ok=True)
    c = sqlite3.connect(_DB, check_same_thread=False)
    c.execute('CREATE TABLE IF NOT EXISTS history (id INTEGER PRIMARY KEY AUTOINCREMENT, query TEXT, table_name TEXT, ts DATETIME DEFAULT CURRENT_TIMESTAMP)')
    c.commit()
    return c

def save(query, table='global'):
    with _conn() as c:
        c.execute('DELETE FROM history WHERE query=? AND table_name=?', (query, table))
        c.execute('INSERT INTO history (query, table_name) VALUES (?,?)', (query, table))

def get_all(table='global'):
    with _conn() as c:
        return c.execute('SELECT id, query FROM history WHERE table_name=? ORDER BY ts DESC LIMIT 50', (table,)).fetchall()

def remove(row_id):
    with _conn() as c:
        c.execute('DELETE FROM history WHERE id=?', (row_id,))

def remove_all(table='global'):
    with _conn() as c:
        c.execute('DELETE FROM history WHERE table_name=?', (table,))
