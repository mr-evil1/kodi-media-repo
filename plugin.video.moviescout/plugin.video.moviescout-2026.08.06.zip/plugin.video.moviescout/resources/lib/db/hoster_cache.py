import json
import xbmcgui

_WIN    = xbmcgui.Window(10000)
_PREFIX = 'moviescout.hcache.'


def get(key):
    try:
        raw = _WIN.getProperty(_PREFIX + key)
        if raw:
            return json.loads(raw)
    except Exception:
        pass
    return None


def set(key, hosters):
    try:
        _WIN.setProperty(_PREFIX + key, json.dumps(hosters))
    except Exception:
        pass


def delete(key):
    try:
        _WIN.clearProperty(_PREFIX + key)
    except Exception:
        pass


def cleanup():
    pass
