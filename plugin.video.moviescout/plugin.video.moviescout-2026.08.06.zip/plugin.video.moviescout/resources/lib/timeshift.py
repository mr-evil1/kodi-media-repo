"""
Timeshift für plugin.video.moviescout
Buffer-first: Stream wird sofort aufgenommen, TS-Datei direkt abgespielt.
Recording läuft unbegrenzt bis Wiedergabe beendet wird.
"""
import os
import threading
import time
import uuid
from urllib.parse import urljoin

import xbmc
import xbmcgui

from resources.lib.control import getSetting, addonProfile
from resources.lib import log

_MIN_BUFFER_BYTES = 524288   # 512 KB vor erstem Play
_MIN_BUFFER_WAIT  = 8.0      # max Sekunden warten
_TS_SUBDIR        = 'timeshift'

_active_session = None
_session_lock   = threading.Lock()


def _ts_dir():
    d = getSetting('timeshift.dir') or ''
    if not d:
        d = os.path.join(addonProfile(), _TS_SUBDIR)
    os.makedirs(d, exist_ok=True)
    return d


def is_enabled():
    return getSetting('timeshift.enabled') == 'true'


def cleanup_on_startup():
    for d in [os.path.join(addonProfile(), _TS_SUBDIR),
              getSetting('timeshift.dir') or '']:
        if d and os.path.isdir(d):
            for fn in os.listdir(d):
                if fn.startswith('ts_') and fn.endswith('.ts'):
                    try:
                        os.remove(os.path.join(d, fn))
                    except Exception:
                        pass
    log.log('Timeshift: Startup-Cleanup abgeschlossen')


# ── Recorder (läuft bis stop() aufgerufen wird) ──────────────────────────────

class _RecordThread(threading.Thread):
    def __init__(self, ts_path, stream_url, extra_headers=None):
        super().__init__(daemon=True, name='ts_recorder')
        self._ts_path       = ts_path
        self._stream_url    = stream_url
        self._extra_headers = dict(extra_headers or {})
        self._stop_event    = threading.Event()
        self.bytes_written  = 0

    def stop(self):
        self._stop_event.set()

    def _hdrs(self):
        h = {'User-Agent': 'Kodi/21 (compatible)'}
        h.update(self._extra_headers)
        return h

    @staticmethod
    def _is_hls(url):
        return '.m3u8' in url.lower()

    def run(self):
        try:
            if self._is_hls(self._stream_url):
                self._record_hls(self._hdrs())
            else:
                self._record_stream(self._hdrs())
        except Exception as e:
            log.log('Timeshift Recorder Fehler: %s' % e)

    def _record_stream(self, headers):
        import requests
        retries = 0
        append  = False
        while not self._stop_event.is_set():
            try:
                mode = 'ab' if append else 'wb'
                with requests.get(self._stream_url, stream=True,
                                  headers=headers, timeout=(10, 60)) as r:
                    r.raise_for_status()
                    with open(self._ts_path, mode) as f:
                        for chunk in r.iter_content(chunk_size=65536):
                            if self._stop_event.is_set():
                                return
                            if chunk:
                                f.write(chunk)
                                self.bytes_written += len(chunk)
                if self._stop_event.is_set():
                    return
                append  = True
                retries += 1
                if retries > 20:
                    break
                time.sleep(min(2 * retries, 15))
            except Exception as e:
                if self._stop_event.is_set():
                    return
                retries += 1
                append   = True
                if retries > 20:
                    break
                log.log('Timeshift: Reconnect %d/20 (%s)' % (retries, e))
                time.sleep(min(2 * retries, 15))

    def _record_hls(self, headers):
        import requests
        seen      = set()
        media_url = self._stream_url
        try:
            r = requests.get(self._stream_url, headers=headers, timeout=(10, 30))
            r.raise_for_status()
            if '#EXT-X-STREAM-INF' in r.text:
                for line in r.text.splitlines():
                    line = line.strip()
                    if line and not line.startswith('#'):
                        media_url = (line if line.startswith('http')
                                     else urljoin(self._stream_url, line))
                        break
        except Exception as e:
            log.log('Timeshift HLS Master-Fehler: %s' % e)
            return
        try:
            with open(self._ts_path, 'wb') as f:
                while not self._stop_event.is_set():
                    try:
                        r = requests.get(media_url, headers=headers, timeout=(10, 30))
                        r.raise_for_status()
                        new_segs = []
                        for line in r.text.splitlines():
                            line = line.strip()
                            if line and not line.startswith('#'):
                                su = (line if line.startswith('http')
                                      else urljoin(media_url, line))
                                if su not in seen:
                                    new_segs.append(su)
                        for su in new_segs:
                            if self._stop_event.is_set():
                                return
                            try:
                                sr = requests.get(su, headers=headers,
                                                  timeout=(5, 30), stream=True)
                                sr.raise_for_status()
                                for chunk in sr.iter_content(65536):
                                    if chunk:
                                        f.write(chunk)
                                        self.bytes_written += len(chunk)
                                seen.add(su)
                            except Exception as se:
                                log.log('Timeshift HLS Segment %s: %s' % (su, se))
                        time.sleep(1 if new_segs else 2)
                    except Exception as e:
                        if self._stop_event.is_set():
                            return
                        log.log('Timeshift HLS Playlist-Fehler: %s' % e)
                        time.sleep(3)
        except Exception as e:
            log.log('Timeshift HLS Schreibfehler: %s' % e)


# ── Stop-Monitor: beendet Recording wenn Wiedergabe stoppt ──────────────────

class _StopMonitor(xbmc.Player):
    """Beobachtet Wiedergabe und ruft stop_active() beim Beenden auf."""
    def __init__(self):
        super().__init__()
        self._started = False

    def onPlayBackStarted(self):
        self._started = True

    def onPlayBackStopped(self):
        self._on_end()

    def onPlayBackEnded(self):
        self._on_end()

    def onPlayBackError(self):
        self._on_end()

    def _on_end(self):
        if not self._started:
            return
        log.log('Timeshift: Wiedergabe beendet → Recording stoppen & löschen')
        stop_active()


# ── Session ──────────────────────────────────────────────────────────────────

class _Session:
    def __init__(self, stream_url, channel_name, extra_headers=None):
        self.session_id   = uuid.uuid4().hex
        self.ts_path      = os.path.join(_ts_dir(), 'ts_%s.ts' % self.session_id)
        self.channel_name = channel_name
        self._rec_thread  = _RecordThread(self.ts_path, stream_url, extra_headers)
        self._rec_thread.start()
        log.log('Timeshift: Recording gestartet (unbegrenzt) → %s' % self.ts_path)

    def wait_for_buffer(self):
        deadline = time.time() + _MIN_BUFFER_WAIT
        while time.time() < deadline:
            try:
                if (os.path.exists(self.ts_path)
                        and os.path.getsize(self.ts_path) >= _MIN_BUFFER_BYTES):
                    return True
            except OSError:
                pass
            xbmc.sleep(300)
        try:
            return os.path.exists(self.ts_path) and os.path.getsize(self.ts_path) > 0
        except OSError:
            return False

    def play_ts(self):
        li = xbmcgui.ListItem(self.channel_name, path=self.ts_path)
        li.setContentLookup(False)
        try:
            tag = li.getVideoInfoTag()
            tag.setMediaType('movie')
            tag.setTitle(self.channel_name)
        except Exception:
            li.setInfo('video', {'mediatype': 'movie', 'title': self.channel_name})
        xbmc.Player().play(self.ts_path, li)
        log.log('Timeshift: TS-Wiedergabe gestartet')

    def stop(self):
        self._rec_thread.stop()
        rec  = self._rec_thread
        path = self.ts_path

        def _cleanup():
            rec.join(timeout=5)
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                    log.log('Timeshift: TS gelöscht: %s' % path)
                except Exception as e:
                    log.log('Timeshift: Löschfehler: %s' % e)

        threading.Thread(target=_cleanup, daemon=True, name='ts_cleanup').start()


# ── Öffentliche API ──────────────────────────────────────────────────────────

def play_channel_via_timeshift(stream_url, channel_name, handle, extra_headers=None):
    """
    Startet Recording, wartet auf Puffer, spielt TS-Datei als Movie.
    Recording läuft bis Wiedergabe beendet → dann automatisch löschen.
    """
    global _active_session
    import xbmcplugin

    with _session_lock:
        if _active_session is not None:
            _active_session.stop()
        session = _Session(stream_url, channel_name, extra_headers)
        _active_session = session

    # Plugin-Handle schließen bevor Player aufgerufen wird
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())

    xbmcgui.Dialog().notification(
        'Timeshift', '⏺ Puffer wird aufgebaut…',
        xbmcgui.NOTIFICATION_INFO, 3000)

    if not session.wait_for_buffer():
        xbmcgui.Dialog().notification(
            'Timeshift', 'Kein Puffer — direkter Play',
            xbmcgui.NOTIFICATION_WARNING, 3000)
        with _session_lock:
            if _active_session is session:
                _active_session = None
        session.stop()
        return False

    # Stop-Monitor starten (beendet Recording wenn User stoppt)
    monitor = _StopMonitor()
    monitor._started = True   # TS-Play zählt als gestartet

    session.play_ts()
    return True


def stop_active():
    global _active_session
    with _session_lock:
        s = _active_session
        _active_session = None
    if s:
        s.stop()
