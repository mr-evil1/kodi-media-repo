import os
import json
import xbmc
import xbmcaddon
import xbmcvfs

class _Monitor(xbmc.Monitor):
    pass

_PLAYER_JSON = {
    "name": "MovieScout",
    "plugin": "plugin.video.moviescout",
    "priority": 1,
    "is_resolvable": "true",
    "play_movie": "plugin://plugin.video.moviescout?action=scoutMovie&tmdb_id={tmdb}",
    "play_episode": "plugin://plugin.video.moviescout?action=scoutEpisode&tmdb_id={tmdb}&season={season}&episode={episode}&title={showname_url}"
}

def _kodi_major():
    try:
        return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except Exception:
        return 20

def _apply_settings_xml():
    try:
        addon_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
        res = os.path.join(addon_path, 'resources')
        target = os.path.join(res, 'settings.xml')
        if os.path.exists(target):
            return
        if _kodi_major() >= 20:
            src = os.path.join(res, 'settings-kodi20.xml')
        else:
            src = os.path.join(res, 'settings-kodi19.xml')
        if os.path.exists(src):
            with open(src, 'rb') as _s, open(target, 'wb') as _t:
                _t.write(_s.read())
            xbmc.log('[MovieScout] settings.xml für Kodi %d erstellt' % _kodi_major(), xbmc.LOGINFO)
    except Exception:
        try:
            from resources.lib import log
            log.error()
        except Exception:
            pass

def _install_tmdbhelper_player():
    try:
        target_dir = xbmcvfs.translatePath(
            'special://userdata/addon_data/plugin.video.themoviedb.helper/players/'
        )
        target = os.path.join(target_dir, 'moviescout.json')
        if os.path.exists(target):
            return
        os.makedirs(target_dir, exist_ok=True)
        with open(target, 'w', encoding='utf-8') as f:
            json.dump(_PLAYER_JSON, f, indent=4)
        xbmc.log('[MovieScout] TMDbHelper Player installiert: %s' % target, xbmc.LOGINFO)
    except Exception:
        try:
            from resources.lib import log
            log.error()
        except Exception:
            pass

def run():
    monitor = _Monitor()
    addon   = xbmcaddon.Addon()
    _apply_settings_xml()
    _install_tmdbhelper_player()
    try:
        from resources.lib import timeshift as _ts
        _ts.cleanup_on_startup()
    except Exception:
        pass
    try:
        from resources.lib.remote import update_all, _remote_enabled
        if _remote_enabled():
            update_all(force=False)
    except Exception:
        try:
            from resources.lib import log
            log.error()
        except Exception:
            pass
    monitor.waitForAbort(10)

run()
