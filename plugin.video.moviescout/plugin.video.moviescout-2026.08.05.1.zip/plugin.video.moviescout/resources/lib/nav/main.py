from resources.lib.control import (
    getSetting, sysaddon, syshandle, addonName, addonVersion,
    addItem, content, directory, plugincategory, artPath, get_video_tag, sortMethod
)
import os
import xbmcgui
import xbmcplugin

_handle = None
_addon  = None


def _on(key):
    """Returns True unless the setting is explicitly set to 'false'.
    New/unset settings (empty string or anything else) are treated as ON."""
    return getSetting(key) != 'false'


def _li(label, action, img='DefaultFolder.png', folder=True, icon=None):
    url  = '%s?action=%s' % (_addon, action)
    path = os.path.join(artPath(), img) if not img.startswith('Default') else img
    kodi_icon = icon if icon else (img if img.startswith('Default') else 'DefaultFolder.png')
    li = xbmcgui.ListItem(label=label)
    li.setArt({'thumb': path, 'poster': path, 'clearart': path, 'icon': kodi_icon})
    tag, _shim = get_video_tag(li)
    tag.setTitle(label)
    tag.setPlot('[COLOR blue]%s[/COLOR]' % label)
    if _shim: tag.flush()
    if not folder:
        li.setProperty('IsPlayable', 'false')
    li.setIsFolder(folder)
    addItem(_handle, url, li, folder)


def show_root():
    global _handle, _addon
    _handle = syshandle()
    _addon  = sysaddon()

    if _on('menu.show_movies'):
        _li('Filme',        'movieNavigator', 'DefaultMovies.png')

    if _on('menu.show_tvshows'):
        _li('TV-Serien',    'tvNavigator',    'DefaultTVShows.png')
    if _on('menu.show_search_movies'):
        _li('Suche Filme',  'searchMovies',   'DefaultAddonsSearch.png')
    if _on('menu.show_search_tv'):
        _li('Suche Serien', 'searchTV',       'DefaultAddonsSearch.png')
    if _on('menu.show_search_person'):
        _li('Suche Person', 'searchPerson',   'DefaultAddonsSearch.png')

    if getSetting('scout.enable') != 'false' and _on('menu.show_scout'):
        _li('[B]Scout[/B] – TMDB + ResolveURL', 'scoutRoot', 'DefaultAddonVideo.png')

    if getSetting('browse.enable') != 'false':
        if _on('menu.show_browse'):
            _li('[B]Browse[/B] – Scraper Sites',  'browseRoot',   'DefaultAddonVideo.png')
        if _on('menu.show_browse_search'):
            _li('[B]Browse[/B] – Globale Suche',  'browseSearch', 'DefaultAddonsSearch.png')

    if getSetting('trakt.enable') == 'true' and _on('menu.show_trakt'):
        _li('[B]Trakt[/B]', 'traktRoot', 'DefaultAddonVideo.png')

    if getSetting('vavoo.enable') != 'false' and _on('menu.show_livetv'):
        _li('[B]Live TV[/B] - VAVOO', 'vavooRoot', 'DefaultTVShows.png')

    if getSetting('livetv.enable') != 'false' and _on('menu.show_livetv2'):
        _li('[B]Live TV[/B]', 'liveTVRoot', 'DefaultTVShows.png')

    if _on('menu.show_play_url'):
        _li('URL direkt abspielen', 'playURL', 'DefaultAddonWebSkin.png', folder=False)

    if _on('menu.show_tools'):
        _li('Werkzeuge', 'toolsRoot', 'DefaultAddonProgram.png')


    content(_handle, '')
    plugincategory(_handle, '%s %s' % (addonName(), addonVersion()))
    directory(_handle, cacheToDisc=False)


def show_scout_root():
    """Scout eigenes Hauptmenü – alle Einträge spielen via TMDB + ResolveURL."""
    global _handle, _addon
    _handle = syshandle()
    _addon  = sysaddon()

    _li('[B]Filme[/B] – Neu im Kino',
        'listings&media_type=movie&url=kino',                                'kino.png',
        icon='DefaultInProgressShows.png')
    _li('[B]Filme[/B] – Am populärsten',
        'listings&media_type=movie&url=popular',                             'popular.png',
        icon='DefaultMovies.png')
    _li('[B]Filme[/B] – Am besten bewertet',
        'listings&media_type=movie&url=top_rated',                           'toprated.png',
        icon='DefaultFavourites.png')
    _li('[B]Filme[/B] – Meist bewertet',
        'listings&media_type=movie&url=sort_by%3Dvote_count.desc',           'votecount.png',
        icon='DefaultFavourites.png')
    _li('[B]Filme[/B] – Box Office',
        'listings&media_type=movie&url=sort_by%3Drevenue.desc',              'boxoffice.png',
        icon='DefaultRecentlyAddedMovies.png')
    _li('[B]Filme[/B] – Genres',       'movieGenres',                        'genres.png',
        icon='DefaultGenre.png')
    _li('[B]Filme[/B] – Jahr',         'movieYears',                         'year.png',
        icon='DefaultYear.png')

    _li('[B]Serien[/B] – Aktuell im TV',
        'listings&media_type=tv&url=with_status%3D0%26sort_by%3Dpopularity.desc', 'aktuell.png',
        icon='DefaultTVShows.png')
    _li('[B]Serien[/B] – Am populärsten',
        'listings&media_type=tv&url=popular',                                'popular.png',
        icon='DefaultMovies.png')
    _li('[B]Serien[/B] – Am besten bewertet',
        'listings&media_type=tv&url=top_rated',                              'toprated.png',
        icon='DefaultFavourites.png')
    _li('[B]Serien[/B] – Meist bewertet',
        'listings&media_type=tv&url=sort_by%3Dvote_count.desc',              'votecount.png',
        icon='DefaultFavourites.png')
    _li('[B]Serien[/B] – Genres',      'tvGenres',                           'genres.png',
        icon='DefaultGenre.png')
    _li('[B]Serien[/B] – Jahr',        'tvYears',                            'year.png',
        icon='DefaultYear.png')

    _li('[B]Suche[/B] – Filme',        'searchMovies',  'DefaultAddonsSearch.png')
    _li('[B]Suche[/B] – Serien',       'searchTV',      'DefaultAddonsSearch.png')
    _li('[B]Suche[/B] – Person',       'searchPerson',  'DefaultAddonsSearch.png')

    content(_handle, '')
    sortMethod(_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    plugincategory(_handle, 'Scout – TMDB + ResolveURL')
    directory(_handle)


def show_movies():
    global _handle, _addon
    _handle = syshandle()
    _addon  = sysaddon()

    _li('[B]Filme[/B] – Neu im Kino',
        'listings&media_type=movie&url=kino',                              'kino.png',
        icon='DefaultInProgressShows.png')
    _li('[B]Filme[/B] – Jahr',         'movieYears',                       'year.png',
        icon='DefaultYear.png')
    _li('[B]Filme[/B] – Genres',       'movieGenres',                      'genres.png',
        icon='DefaultGenre.png')
    _li('[B]Filme[/B] – Streaming Anbieter', 'scoutMovieProviders',         'streaming.png',
        icon='DefaultMovies.png')
    _li('[B]Filme[/B] – Am populärsten',
        'listings&media_type=movie&url=popular',                           'popular.png',
        icon='DefaultMovies.png')
    _li('[B]Filme[/B] – Am besten bewertet',
        'listings&media_type=movie&url=top_rated',                         'toprated.png',
        icon='DefaultFavourites.png')
    _li('[B]Filme[/B] – Meist bewertet',
        'listings&media_type=movie&url=sort_by%3Dvote_count.desc',         'votecount.png',
        icon='DefaultFavourites.png')
    _li('[B]Filme[/B] – Box Office',
        'listings&media_type=movie&url=sort_by%3Drevenue.desc',            'boxoffice.png',
        icon='DefaultRecentlyAddedMovies.png')

    if _on('menu.show_search_movies'):
        _li('Suche Filme',  'searchMovies',   'DefaultAddonsSearch.png')

    content(_handle, '')
    sortMethod(_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    plugincategory(_handle, 'Filme')
    directory(_handle)


def show_tvshows():
    global _handle, _addon
    _handle = syshandle()
    _addon  = sysaddon()

    _li('[B]Serien[/B] – Aktuell im TV',
        'listings&media_type=tv&url=with_status%3D0%26sort_by%3Dpopularity.desc', 'aktuell.png',
        icon='DefaultTVShows.png')
    _li('[B]Serien[/B] – Jahr',        'tvYears',                           'year.png',
        icon='DefaultYear.png')
    _li('[B]Serien[/B] – Genres',
        'tvGenres',                                                        'genres.png',
        icon='DefaultGenre.png')
    _li('[B]Serien[/B] – Streaming Anbieter', 'scoutTVProviders',          'streaming.png',
        icon='DefaultMovies.png')
    _li('[B]Serien[/B] – Am populärsten',
        'listings&media_type=tv&url=popular',                              'popular.png',
        icon='DefaultMovies.png')
    _li('[B]Serien[/B] – Am besten bewertet',
        'listings&media_type=tv&url=top_rated',                            'toprated.png',
        icon='DefaultFavourites.png')
    _li('[B]Serien[/B] – Meist bewertet',
        'listings&media_type=tv&url=sort_by%3Dvote_count.desc',            'votecount.png',
        icon='DefaultFavourites.png')

    if _on('menu.show_search_tv'):
        _li('Suche Serien', 'searchTV',       'DefaultAddonsSearch.png')

    content(_handle, '')
    sortMethod(_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    plugincategory(_handle, 'TV-Serien')
    directory(_handle)


def show_tools():
    global _handle, _addon
    _handle = syshandle()
    _addon  = sysaddon()

    _li('[B]Scraper Manager[/B]',
        'scraperManager',     'DefaultAddonProgram.png', folder=True)
    _li('[B]Scraper Checker[/B] – Domain-Test',
        'scraperCheck',       'DefaultAddonProgram.png', folder=True)
    _li('[B]Scraper[/B] – Remote Update',
        'scraperUpdate',      'DefaultAddonProgram.png', folder=False)
    _li('[B]Scraper[/B] – Force Update',
        'scraperForceUpdate', 'DefaultAddonProgram.png', folder=False)
    _li('[B]Scraper[/B] – Alle aktivieren',
        'scraperEnableAll',   'DefaultAddonProgram.png', folder=False)
    _li('[B]Scraper[/B] – Alle deaktivieren',
        'scraperDisableAll',  'DefaultAddonProgram.png', folder=False)
    _li('[B]Scraper[/B] – Cache löschen',
        'scraperClearCache',  'DefaultAddonProgram.png', folder=False)
    _li('[B]ResolveURL[/B] – Update',
        'resolverUpdate',     'DefaultAddonProgram.png', folder=False)
    _li('[B]ResolveURL[/B] – Einstellungen',
        'resolverSettings',   'DefaultAddonProgram.png', folder=False)
    from resources.lib.control import getSetting as _gs
    if _gs('rd.enabled') == 'true':
        rd_token = _gs('rd.token') or ''
        if not rd_token:
            _li('[B]Real-Debrid[/B] – OAuth autorisieren',
                'debridAuthRD',   'DefaultAddonProgram.png', folder=False)
            _li('[B]Real-Debrid[/B] – API Token eintragen',
                'debridTokenRD',  'DefaultAddonProgram.png', folder=False)
        else:
            _li('[B]Real-Debrid[/B] – Abmelden',
                'debridLogoutRD', 'DefaultAddonProgram.png', folder=False)
    if _gs('pm.enabled') == 'true':
        _li('[B]Premiumize[/B] – API Key (Einstellungen)',
            'addonSettings',  'DefaultAddonProgram.png', folder=False)
    if _gs('ad.enabled') == 'true':
        if not (_gs('ad.token') or ''):
            _li('[B]AllDebrid[/B] – Authorisieren',
                'debridAuthAD',   'DefaultAddonProgram.png', folder=False)
        else:
            _li('[B]AllDebrid[/B] – Abmelden',
                'debridLogoutAD', 'DefaultAddonProgram.png', folder=False)
    if _gs('dl.enabled') == 'true':
        if not (_gs('dl.token') or ''):
            _li('[B]Debrid-Link[/B] – Authorisieren',
                'debridAuthDL',   'DefaultAddonProgram.png', folder=False)
        else:
            _li('[B]Debrid-Link[/B] – Abmelden',
                'debridLogoutDL', 'DefaultAddonProgram.png', folder=False)
    _li('[B]Addon[/B] – Einstellungen',
        'addonSettings',      'DefaultAddonProgram.png', folder=False)
    _li('[B]Addon[/B] – Reset Settings',
        'resetSettings',      'DefaultAddonProgram.png', folder=False)

    content(_handle, '')
    plugincategory(_handle, 'Werkzeuge')
    directory(_handle, cacheToDisc=False)
