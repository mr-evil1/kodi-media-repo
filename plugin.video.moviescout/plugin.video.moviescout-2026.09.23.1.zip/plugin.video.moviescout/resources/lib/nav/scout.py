import time
import threading
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
import xbmc
import xbmcgui
import xbmcplugin
from urllib.parse import quote_plus, unquote_plus, urlparse as _urlparse
from resources.lib import tmdb, log, remote
from resources.lib.db import hoster_cache
from resources.lib.control import (
    sysaddon, syshandle, addonPoster, addonFanart,
    addItem, directory, plugincategory,
    getSetting, infoDialog, dialog_select, dialog_ok
)

progressDialog   = xbmcgui.DialogProgress()
progressDialogBG = xbmcgui.DialogProgressBG()


def _hosts_mode():
    try:    return int(getSetting('scout.hosts_mode') or 0)
    except: return 0


def _progress_dialog():
    return progressDialog if getSetting('progress.dialog') == '0' else progressDialogBG


def _count_qualities(sources):
    c = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0}
    for h in sources:
        q = (h[3] if len(h) > 3 else '').upper()
        if '4K' in q or '2160' in q: c['4K'] += 1
        elif '1080' in q:            c['1080p'] += 1
        elif '720' in q:             c['720p'] += 1
        else:                        c['SD'] += 1
    return c


def _get_scrapers():
    return remote.get_scout_scrapers()


def _cache_key(tmdb_id, mt, season, episode):
    return '%s_%s_%d_%d' % (tmdb_id, mt, int(season), int(episode))


def _netloc(url):
    if url and url.startswith('http'):
        return _urlparse(url).netloc.lower()
    return url or ''


def _query_scraper(scraper, all_names, year, season, episode, imdb_id, tmdb_id):
    site_name = getattr(scraper, 'SITE_NAME', '') or getattr(scraper, 'SITE_ID', '') or '?'
    found = []
    for t in all_names[:3]:
        try:
            found += list(scraper.get_hosters(
                title=t, year=year, season=season, episode=episode,
                imdb=imdb_id, tmdb=tmdb_id
            ))
        except TypeError:
            pass
        except Exception:
            log.error()
    seen = set()
    deduped = []
    for h in found:
        name_key = h[0].lower().strip() if h else ''
        key = (name_key, _netloc(h[1] if len(h) > 1 else ''))
        if key not in seen:
            seen.add(key)
            h = tuple(h)
            while len(h) < 5:
                h = h + ('',)
            deduped.append(h + (site_name,))
    return deduped


def _fetch_yts_magnet(imdb_id, title, year):
    try:
        from resources.lib import multiquest as _mq
        _API_BASES = [
            ('https://yts.gg/api/v2',              True),
            ('https://movies-api.accel.li/api/v2',  False),
            ('https://yts.bz/api/v2',               False),
        ]
        torrents = None
        for base, cf in _API_BASES:
            try:
                resp = _mq.get('%s/movie_details.json' % base, params={'movie_id': imdb_id}, timeout=8, use_cf=cf)
                movie = resp.json().get('data', {}).get('movie', {})
                if movie and movie.get('id'):
                    torrents = movie.get('torrents', [])
                    break
            except Exception:
                pass
        if not torrents:
            for base, cf in _API_BASES:
                try:
                    resp = _mq.get('%s/list_movies.json' % base, params={'query_term': imdb_id, 'limit': 5}, timeout=8, use_cf=cf)
                    movies = resp.json().get('data', {}).get('movies', [])
                    if movies:
                        torrents = movies[0].get('torrents', [])
                        break
                except Exception:
                    pass
        if not torrents:
            return None, ''
        best = None
        for pref in ('2160p', '1080p', '720p'):
            for t in torrents:
                if t.get('quality') == pref:
                    best = t
                    break
            if best:
                break
        if not best:
            best = torrents[0]
        h = best.get('hash', '')
        q = best.get('quality', '')
        dn = '%s+%s' % (title.replace(' ', '+'), year)
        trackers = '&tr='.join([
            'udp://tracker.opentrackr.org:1337/announce',
            'udp://open.tracker.cl:1337/announce',
            'udp://tracker.openbittorrent.com:6969/announce',
        ])
        return 'magnet:?xt=urn:btih:%s&dn=%s&tr=%s' % (h, dn, trackers), q
    except Exception:
        log.error()
        return None, ''


def _fetch_eztv_magnet(imdb_id, season, episode):
    try:
        from resources.lib import multiquest as _mq
        import re as _re
        imdb_num = imdb_id.replace('tt', '')
        resp = _mq.get('https://eztvx.to/api/get-torrents',
                       params={'imdb_id': imdb_num, 'limit': 100}, timeout=10)
        torrents = resp.json().get('torrents', [])
        pattern = _re.compile(r'[Ss]0*%d[Ee]0*%d' % (season, episode))
        matched = [t for t in torrents if pattern.search(t.get('title', '') or t.get('filename', ''))]
        if not matched:
            return None, ''
        for pref in ('1080p', '720p', '480p'):
            for t in matched:
                if pref in ((t.get('title', '') or '') + (t.get('filename', '') or '')):
                    return t.get('magnet_url', ''), pref
        return matched[0].get('magnet_url', ''), ''
    except Exception:
        log.error()
        return None, ''


def _rd_torrent_sources(meta, season=0, episode=0):
    try:
        from resources.lib import debrid as _deb
        rd = _deb.RealDebrid()
        if not rd.is_enabled() or not rd.token:
            return []
        imdb_id = meta.get('imdb_id', '')
        if not imdb_id:
            return []
        title = meta.get('title', '')
        year  = str(meta.get('year', ''))
        is_movie = season == 0 and episode == 0
        magnet, quality = (_fetch_yts_magnet(imdb_id, title, year) if is_movie
                           else _fetch_eztv_magnet(imdb_id, season, episode))
        if not magnet:
            return []
        stream_url = rd.get_stream_from_magnet(magnet)
        if not stream_url:
            return []
        return [(title, stream_url, True, quality, '', 'RD Torrent')]
    except Exception:
        log.error()
        return []


def getSources(meta, season=0, episode=0, timeout=20, scraper_timeout=10):
    scrapers   = _get_scrapers()
    rd_torrent = getSetting('rd.torrent_enable') == 'true'
    if not scrapers and not rd_torrent:
        return []

    title      = meta.get('title', '')
    year       = str(meta.get('year', ''))
    imdb_id    = meta.get('imdb_id', '')
    tmdb_id    = str(meta.get('tmdb_id', ''))
    alt_titles = meta.get('aliases', [])
    seen_t = {title}
    all_names = [title]
    for t in alt_titles:
        if t and t not in seen_t:
            seen_t.add(t)
            all_names.append(t)

    sources  = []
    lock     = threading.Lock()
    start_ts = time.time()

    max_workers = min(len(scrapers) + (1 if rd_torrent else 0), 16)
    executor = ThreadPoolExecutor(max_workers=max_workers)
    futures = {}

    for s in scrapers:
        st = getattr(s, 'SCRAPER_TIMEOUT', scraper_timeout)
        name = getattr(s, 'SITE_NAME', None) or getattr(s, '__name__', '?')
        f = executor.submit(_query_scraper, s, all_names, year, season, episode, imdb_id, tmdb_id)
        futures[f] = (name, time.time(), st)

    if rd_torrent:
        f = executor.submit(_rd_torrent_sources, meta, season, episode)
        futures[f] = ('RD Torrent', time.time(), 25)

    dp = _progress_dialog()
    dp.create('MovieScout', '')
    dp.update(0, '4K: 0 | 1080p: 0 | 720p: 0 | SD: 0 | Total: 0')

    total_format = '[COLOR %s][B]%s[/B][/COLOR]'
    deadline = start_ts + timeout

    try:
        pending = set(futures.keys())
        while pending:
            try:
                if dp.iscanceled():
                    executor.shutdown(wait=False, cancel_futures=True)
                    break
            except Exception:
                pass

            now = time.time()
            if now >= deadline:
                executor.shutdown(wait=False, cancel_futures=True)
                break

            done_set = set()
            for f in list(pending):
                _, ts, st = futures[f]
                if f.done():
                    done_set.add(f)
                    try:
                        result = f.result()
                        with lock:
                            sources.extend(result)
                    except Exception:
                        log.error()
                elif now - ts >= st:
                    done_set.add(f)
            pending -= done_set

            with lock:
                current = list(sources)
            qc    = _count_qualities(current)
            total = len(current)

            def col(n):
                return total_format % ('red', n) if n == 0 else total_format % ('lime', n)

            alive_names = [futures[f][0] for f in pending]
            line = ' 4K: %s | 1080p: %s | 720p: %s | SD: %s | Total: %s' % (
                col(qc['4K']), col(qc['1080p']), col(qc['720p']), col(qc['SD']), col(total))
            if len(alive_names) > 6:
                line += '                    Verbleibend: %d Scraper' % len(alive_names)
            elif alive_names:
                line += '                    Verbleibend: %s' % ', '.join(alive_names)
            else:
                line += '                    Suche beendet!'

            elapsed = now - start_ts
            dp.update(max(1, min(99, int(100 * elapsed / timeout + 0.5))), line)

            if not pending:
                break
            time.sleep(0.25)

    except Exception:
        log.error()

    executor.shutdown(wait=False)

    try:    dp.close()
    except: pass

    seen_global = set()
    deduped_global = []
    for h in sources:
        key = (h[0].lower().strip() if h else '', _netloc(h[1] if len(h) > 1 else ''))
        if key not in seen_global:
            seen_global.add(key)
            deduped_global.append(h)
    return deduped_global


def _play_from_hosters(hosters, title, meta, handle, params=None):
    if not hosters:
        infoDialog('Keine Streams gefunden.', icon='WARNING')
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    mode = _hosts_mode()

    if mode == 2:
        _open_listing(hosters, title, meta, params or {})
        if handle is not None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    if mode == 0 or len(hosters) == 1:
        _auto_play(hosters, title, meta, handle)
        return

    _QUALITY_RANK = {'4k': 0, '2160p': 0, '1080p': 1, 'fhd': 1, '720p': 2, 'hd': 3, 'sd': 4}

    def _quality_rank(h):
        q = (h[3] if len(h) > 3 else '').lower()
        return _QUALITY_RANK.get(q, 5)

    def _lang_rank(h):
        lang = (h[4] if len(h) > 4 else '').lower()
        return 0 if lang in ('de', 'ger', 'german') else 1

    hosters = sorted(hosters, key=lambda h: (_lang_rank(h), _quality_rank(h)))

    _DEBRID_SCRAPERS = {'rd torrent', 'real-debrid', 'premiumize.me', 'alldebrid', 'debrid-link'}

    def _make_label(h, failed=False):
        hname   = h[0]
        hurl    = h[1] if len(h) > 1 else ''
        quality = h[3] if len(h) > 3 else ''
        lang    = h[4] if len(h) > 4 else ''
        site    = h[5] if len(h) > 5 else ''
        parts   = [hname]
        if quality: parts.append('[I]%s[/I]' % quality.upper())
        if lang:    parts.append('[I]%s[/I]' % lang.upper())
        if site:    parts.append('[COLOR orange]%s[/COLOR]' % site)
        parts.append(hurl[:50])
        label = '  –  '.join(parts)
        if failed:
            label = '✗  ' + label
        if site.lower() in _DEBRID_SCRAPERS:
            label = '[COLOR gold]%s[/COLOR]' % label
        return label

    if handle is not None:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())

    failed_indices = set()
    while True:
        labels = [_make_label(h, failed=(i in failed_indices)) for i, h in enumerate(hosters)]
        idx = dialog_select('[B]%s[/B]' % title, labels)
        if idx < 0:
            return
        ok = _play_single(hosters[idx], title, meta, None)
        failed_indices.add(idx)
        if not ok:
            infoDialog('Stream fehlgeschlagen – bitte anderen wählen.', icon='WARNING')


def _open_listing(hosters, title, meta, params):
    addon   = sysaddon()
    tmdb_id = meta.get('tmdb_id', '')
    mt      = params.get('mt', 'movie')
    season  = int(params.get('season', 0))
    episode = int(params.get('episode', 0))
    key     = _cache_key(tmdb_id, mt, season, episode)
    hoster_cache.set(key, hosters)
    url = '%s?action=scoutListing&tmdb_id=%s&mt=%s&season=%d&episode=%d' % (
        addon, tmdb_id, mt, season, episode)
    xbmc.executebuiltin('Container.Update(%s)' % url)


_EVIL_PRIORITY_HOSTS = (
    'vidara.', 'vidaraa.', 'vidsonic.', 'vidmatrixa.', 'viewdara.', 'thebesthosterv.',
    'dr0pstream.', 'supervideo.', 'mixdrop.', 'meinecloud.',
    'kinoger.pw', 'kinoger.be', 'fsst.online', 'playmate.', 'dood.',
)

def _resolve_url(url):
    try:
        from resources.lib import debrid as _deb
        if _deb.is_any_active():
            resolved, svc = _deb.resolve_url(url)
            if resolved:
                log.log('[Scout] Debrid aufgelöst via %s' % svc)
                from resources.lib.control import infoDialog
                infoDialog('%s ✓' % svc, title='Debrid', icon='INFO', time=3000)
                return resolved
    except Exception:
        log.error()
    url_lower = url.lower()
    try:
        evil = remote.get_evil_resolver()
        if evil and any(h in url_lower for h in _EVIL_PRIORITY_HOSTS):
            resolved, ok = evil.resolve(url)
            if ok:
                return resolved
    except Exception:
        log.error()
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url=url, include_disabled=False, include_universal=False)
        if hmf.valid_url():
            return hmf.resolve()
    except Exception:
        log.error()
    try:
        evil = remote.get_evil_resolver()
        if evil:
            resolved, ok = evil.resolve(url)
            if ok:
                return resolved
    except Exception:
        log.error()
    return url


def _auto_play(hosters, title, meta, handle):
    for idx, h in enumerate(hosters):
        try:
            url         = h[1]
            is_resolved = h[2] if len(h) > 2 else False
            if not is_resolved:
                url = _resolve_url(url)
            if getSetting('debug.url') == 'true':
                dialog_ok('Debug – Player URL', url)
            if handle is not None:
                li = xbmcgui.ListItem(label=title)
                li.setProperty('IsPlayable', 'true')
                li.setPath(url)
                xbmcplugin.setResolvedUrl(handle, True, li)
            else:
                from resources.lib.player import Player
                p = Player()
                p.set_fallback(hosters, idx + 1, _resolve_url, handle)
                p.run(title, url, meta)
            return
        except Exception:
            log.error()
    infoDialog('Kein spielbarer Stream gefunden.', icon='WARNING')
    if handle is not None:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def _wait_for_playback_end():
    timeout = 0
    while not xbmc.Player().isPlaying() and timeout < 5:
        xbmc.sleep(200)
        timeout += 1
    if not xbmc.Player().isPlaying():
        return False
    while xbmc.Player().isPlaying():
        xbmc.sleep(200)
    return True


def _play_single(h, title, meta, handle):
    url         = h[1]
    is_resolved = h[2] if len(h) > 2 else False
    if not is_resolved:
        url = _resolve_url(url)
    if not url:
        return False
    if getSetting('debug.url') == 'true':
        dialog_ok('Debug – Player URL', url)
    _deliver(title, url, meta, handle)
    _wait_for_playback_end()
    return True


def _deliver(title, url, meta, handle):
    if handle is not None:
        li = xbmcgui.ListItem(label=title)
        li.setProperty('IsPlayable', 'true')
        li.setPath(url)
        xbmcplugin.setResolvedUrl(handle, True, li)
    else:
        from resources.lib.player import Player
        Player().run(title, url, meta)


def scout_movie(params):
    handle  = syshandle()
    tmdb_id = params.get('tmdb_id')
    try:
        meta = tmdb.get_movie(tmdb_id)
        if not meta:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        title = meta.get('title', '')
        if not _get_scrapers() and getSetting('rd.torrent_enable') != 'true':
            dialog_ok('Scout', 'Keine Scraper verfügbar.\n\nBitte Remote-Update unter:\nWerkzeuge → Scraper Manager')
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        hosters = getSources(meta)
        _play_from_hosters(hosters, title, meta, handle, params={'mt': 'movie', 'tmdb_id': tmdb_id, 'season': 0, 'episode': 0})
    except Exception:
        log.error()
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def scout_episode(params):
    handle  = syshandle()
    tmdb_id = params.get('tmdb_id')
    title   = unquote_plus(params.get('title', ''))
    season  = int(params.get('season', 1))
    episode = int(params.get('episode', 1))
    try:
        show = tmdb.get_tvshow(tmdb_id)
        if not show:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        show['title'] = title
        ep_label = '%s S%02dE%02d' % (title, season, episode)
        if not _get_scrapers() and getSetting('rd.torrent_enable') != 'true':
            dialog_ok('Scout', 'Keine Scraper verfügbar.\n\nBitte Remote-Update unter:\nWerkzeuge → Scraper Manager')
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        hosters = getSources(show, season=season, episode=episode)
        _play_from_hosters(hosters, ep_label, show, handle, params={'mt': 'tv', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode})
    except Exception:
        log.error()
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def show_as_listing(params):
    handle  = syshandle()
    addon   = sysaddon()
    tmdb_id = params.get('tmdb_id')
    season  = int(params.get('season', 0))
    episode = int(params.get('episode', 0))
    mt      = params.get('mt', 'movie')

    meta = tmdb.get_movie(tmdb_id) if mt == 'movie' else tmdb.get_tvshow(tmdb_id)
    if not meta:
        directory(handle, succeeded=False)
        return

    title  = meta.get('title', '')
    poster = meta.get('poster', addonPoster())
    fanart = meta.get('fanart', addonFanart())
    key    = _cache_key(tmdb_id, mt, season, episode)
    cached = hoster_cache.get(key)

    if cached is not None:
        hosters = cached
    else:
        hosters = getSources(meta, season=season, episode=episode)
        if hosters:
            hoster_cache.set(key, hosters)

    hoster_cache.cleanup()

    try:
        blocked = remote.get_blocked_hosters()
        if blocked:
            hosters = [h for h in hosters
                       if (_netloc(h[1] if len(h) > 1 else '') not in blocked
                           and (h[0].lower() if h else '') not in blocked)]
    except Exception:
        log.error()

    if getSetting('general.german_only') == 'true':
        import re as _re
        _LANG_RE = _re.compile(r'\(([a-zA-Z]{2,3})\)\s*$')
        def _is_german(h):
            lang = (h[4] if len(h) > 4 else '').lower().strip()
            if not lang:
                m = _LANG_RE.search((h[0] if h else '').strip())
                lang = m.group(1).lower() if m else ''
            return not lang or 'de' in lang or 'ger' in lang or 'deutsch' in lang
        hosters = [h for h in hosters if _is_german(h)]

    def _quality_rank(h):
        q = (h[3] if len(h) > 3 else '').upper()
        if '4K' in q or '2160' in q: return 0
        if '1080' in q:              return 1
        if '720' in q:               return 2
        return 3

    hosters = sorted(hosters, key=_quality_rank)

    xbmcplugin.setContent(handle, 'files')
    plugincategory(handle, title)

    _DEBRID_SCRAPERS = {'rd torrent', 'real-debrid', 'premiumize.me', 'alldebrid', 'debrid-link'}

    for i, h in enumerate(hosters, 1):
        hname        = h[0]
        hurl         = h[1]
        drm_info     = h[2] if (len(h) > 2 and isinstance(h[2], dict)) else {}
        quality      = h[3] if len(h) > 3 else ''
        lang         = h[4] if len(h) > 4 else ''
        scraper_name = h[5] if len(h) > 5 else ''
        domain  = _urlparse(hurl).netloc.upper() if hurl.startswith('http') else hurl[:30].upper()

        is_premium = scraper_name.lower() in _DEBRID_SCRAPERS

        parts = ['[B]%s[/B]' % hname.upper(), domain]
        if quality:      parts.append('[I]%s[/I]' % quality.upper())
        if lang:         parts.append('[I]%s[/I]' % lang.upper())
        if scraper_name: parts.append('[COLOR orange]%s[/COLOR]' % scraper_name)
        label = '%02d | %s' % (i, ' | '.join(parts))
        if is_premium:
            label = '[COLOR gold]%s[/COLOR]' % label

        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': poster, 'poster': poster, 'fanart': fanart})
        li.setIsFolder(False)
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': label, 'mediatype': 'video'})

        url = '%s?action=scoutPlay&title=%s&url=%s&tmdb_id=%s&mt=%s&season=%d&episode=%d&drm=%s' % (
            addon, quote_plus('%s – %s' % (title, hname)), quote_plus(hurl), tmdb_id, mt, season, episode,
            quote_plus(json.dumps(drm_info)) if drm_info else '')
        cm_refresh = ('Neu suchen', 'RunPlugin(%s?action=scoutRefresh&tmdb_id=%s&mt=%s&season=%d&episode=%d)' % (
            addon, tmdb_id, mt, season, episode))
        cm_dl = ('Download', 'RunPlugin(%s?action=download&title=%s&url=%s&mt=%s)' % (
            addon, quote_plus(title), quote_plus(hurl), mt))
        li.addContextMenuItems([cm_refresh, cm_dl])
        addItem(handle, url, li, False)

    if not hosters:
        infoDialog('Keine Streams gefunden.', icon='WARNING')
    directory(handle, cacheToDisc=False)


def refresh_listing(params):
    tmdb_id = params.get('tmdb_id')
    mt      = params.get('mt', 'movie')
    season  = int(params.get('season', 0))
    episode = int(params.get('episode', 0))
    hoster_cache.delete(_cache_key(tmdb_id, mt, season, episode))
    addon = sysaddon()
    url   = '%s?action=scoutListing&tmdb_id=%s&mt=%s&season=%d&episode=%d' % (
        addon, tmdb_id, mt, season, episode)
    xbmc.executebuiltin('Container.Update(%s,replace)' % url)


def _go_back_to_listing(params):
    addon   = sysaddon()
    tmdb_id = params.get('tmdb_id', '')
    mt      = params.get('mt', 'movie')
    season  = int(params.get('season', 0))
    episode = int(params.get('episode', 0))
    if not tmdb_id:
        return
    url = '%s?action=scoutListing&tmdb_id=%s&mt=%s&season=%d&episode=%d' % (
        addon, tmdb_id, mt, season, episode)
    xbmc.executebuiltin('Container.Update(%s,replace)' % url)


def play_direct(params):
    handle  = syshandle()
    title   = unquote_plus(params.get('title', ''))
    url     = unquote_plus(params.get('url', ''))

    # Parse optional DRM info passed from show_as_listing
    drm_info = {}
    try:
        drm_raw = params.get('drm', '')
        if drm_raw:
            drm_info = json.loads(unquote_plus(drm_raw))
    except Exception:
        pass

    # DRM/MPD streams must NOT go through the generic resolver
    is_mpd = '.mpd' in url.lower() or bool(drm_info)

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    resolved_url = None
    try:
        if is_mpd:
            resolved_url = url          # pass MPD URL unchanged to inputstream.adaptive
        else:
            resolved_url = _resolve_url(url)
    except Exception:
        log.error()
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    if not resolved_url:
        infoDialog('Stream konnte nicht aufgelöst werden.', icon='WARNING')
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        _go_back_to_listing(params)
        return

    if getSetting('debug.url') == 'true':
        dialog_ok('Debug – Player URL', resolved_url)

    li = xbmcgui.ListItem(label=title)
    li.setProperty('IsPlayable', 'true')
    li.setPath(resolved_url)

    url_lower = resolved_url.lower()
    if '.mpd' in url_lower or drm_info:
        try:
            import inputstreamhelper
            is_helper = inputstreamhelper.Helper('mpd', drm='com.widevine.alpha')
            if is_helper.check_inputstream():
                li.setContentLookup(False)
                li.setMimeType('application/dash+xml')
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
                if drm_info:
                    license_key = drm_info.get('license_key', '')
                    license_url = drm_info.get('drm_license', '')
                    cert_url    = drm_info.get('drm_certificate', '')
                    li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                    if license_key:
                        li.setProperty('inputstream.adaptive.license_key', license_key)
                    elif license_url:
                        li.setProperty(
                            'inputstream.adaptive.license_key',
                            '%s|Content-Type=application%%2Foctet-stream|R{SSM}|' % license_url
                        )
                    if cert_url:
                        try:
                            import base64
                            from resources.lib import multiquest as _mq
                            cert_resp = _mq.get(cert_url, timeout=10)
                            cert_b64  = base64.b64encode(cert_resp.content).decode('utf-8')
                            li.setProperty('inputstream.adaptive.server_certificate', cert_b64)
                        except Exception:
                            log.error()
                if drm_info.get('is_live'):
                    li.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
        except Exception:
            log.error()
    elif '.m3u8' in url_lower:
        try:
            import inputstreamhelper
            is_helper = inputstreamhelper.Helper('hls')
            if is_helper.check_inputstream():
                li.setContentLookup(False)
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        except Exception:
            log.error()

    if not xbmcplugin.setResolvedUrl(handle, True, li):
        _go_back_to_listing(params)
        return
