import sys
from urllib.parse import parse_qsl

params = dict(parse_qsl(sys.argv[2].lstrip('?'))) if len(sys.argv) > 2 else {}
action = params.get('action', 'root')

try:
    if action == 'root':
        from resources.lib.nav.main import show_root
        show_root()

    elif action == 'movieNavigator':
        from resources.lib.nav.main import show_movies
        show_movies()

    elif action == 'tvNavigator':
        from resources.lib.nav.main import show_tvshows
        show_tvshows()

    elif action == 'toolsRoot':
        from resources.lib.nav.main import show_tools
        show_tools()

    elif action == 'listings':
        from resources.lib.nav.listings import show_listing
        show_listing(params)

    elif action == 'movieGenres':
        from resources.lib.nav.listings import show_movie_genres
        show_movie_genres()

    elif action == 'tvGenres':
        from resources.lib.nav.listings import show_tv_genres
        show_tv_genres()

    elif action == 'movieYears':
        from resources.lib.nav.listings import show_movie_years
        show_movie_years()

    elif action == 'tvYears':
        from resources.lib.nav.listings import show_tv_years
        show_tv_years()

    elif action == 'scoutMovieProviders':
        from resources.lib.nav.listings import show_movie_providers
        show_movie_providers()

    elif action == 'scoutTVProviders':
        from resources.lib.nav.listings import show_tv_providers
        show_tv_providers()

    elif action == 'scoutProviderListing':
        from resources.lib.nav.listings import show_provider_listing
        show_provider_listing(params)

    elif action == 'seasons':
        from resources.lib.nav.seasons import show_seasons
        show_seasons(params)

    elif action == 'episodes':
        from resources.lib.nav.episodes import show_episodes
        show_episodes(params)

    elif action == 'searchMovies':
        from resources.lib.nav.search import show_search_movies
        show_search_movies(params)

    elif action == 'searchTV':
        from resources.lib.nav.search import show_search_tv
        show_search_tv(params)

    elif action == 'searchPerson':
        from resources.lib.nav.search import show_search_person
        show_search_person(params)

    elif action == 'personCredits':
        from resources.lib.nav.person import show_person_credits
        show_person_credits(params)

    elif action == 'searchDelEntry':
        from resources.lib.nav.tools import search_del_entry
        search_del_entry(params)

    elif action == 'searchClearAll':
        from resources.lib.nav.tools import search_clear_all
        search_clear_all(params)

    elif action == 'scoutRoot':
        from resources.lib.nav.main import show_scout_root
        show_scout_root()

    elif action == 'scoutMovie':
        from resources.lib.nav.scout import scout_movie
        scout_movie(params)

    elif action == 'scoutEpisode':
        from resources.lib.nav.scout import scout_episode
        scout_episode(params)

    elif action == 'scoutListing':
        from resources.lib.nav.scout import show_as_listing
        show_as_listing(params)

    elif action == 'scoutPlay':
        from resources.lib.nav.scout import play_direct
        play_direct(params)

    elif action == 'scoutRefresh':
        from resources.lib.nav.scout import refresh_listing
        refresh_listing(params)

    elif action == 'browseRoot':
        from resources.lib.nav.browse import show_root
        show_root()

    elif action == 'browseNav':
        from resources.lib.nav.browse import navigate
        navigate(params)

    elif action == 'browseHosters':
        from resources.lib.nav.browse import show_hosters
        show_hosters(params)

    elif action == 'browseHosterList':
        from resources.lib.nav.browse import show_hosters_list
        show_hosters_list(params)

    elif action == 'browsePlay':
        from resources.lib.nav.browse import play_hoster
        play_hoster(params)

    elif action == 'browseSearch':
        from resources.lib.nav.browse import global_search
        global_search(params)

    elif action == 'scraperManager':
        from resources.lib.nav.scraper_manager import show_manager
        show_manager()

    elif action == 'scraperSetDomain':
        from resources.lib.nav.scraper_manager import set_domain
        set_domain(params)

    elif action == 'scraperResetDomain':
        from resources.lib.nav.scraper_manager import reset_domain
        reset_domain(params)

    elif action == 'scraperForceOne':
        from resources.lib.nav.scraper_manager import force_one
        force_one(params)

    elif action == 'scraperSetType':
        from resources.lib.nav.scraper_manager import set_type
        set_type(params)

    elif action == 'scraperResetType':
        from resources.lib.nav.scraper_manager import reset_type
        reset_type(params)

    elif action == 'scraperCheck':
        from resources.lib.scraper_check import run_as_listing
        run_as_listing()

    elif action == 'scraperDetail':
        from resources.lib.scraper_check import show_detail
        show_detail(params)

    elif action == 'scraperUpdate':
        from resources.lib.nav.tools import scraper_update
        scraper_update(force=False)

    elif action == 'scraperForceUpdate':
        from resources.lib.nav.tools import scraper_update
        scraper_update(force=True)

    elif action == 'scraperEnableAll':
        from resources.lib.nav.tools import scraper_enable_all
        scraper_enable_all()

    elif action == 'scraperDisableAll':
        from resources.lib.nav.tools import scraper_disable_all
        scraper_disable_all()

    elif action == 'scraperEnable':
        from resources.lib.nav.tools import scraper_enable
        scraper_enable(params)

    elif action == 'scraperDisable':
        from resources.lib.nav.tools import scraper_disable
        scraper_disable(params)

    elif action == 'scraperClearCache':
        from resources.lib.nav.tools import scraper_clear_cache
        scraper_clear_cache()

    elif action == 'resolverUpdate':
        from resources.lib.nav.tools import resolver_update
        resolver_update()

    elif action == 'resolverSettings':
        from resources.lib.nav.tools import resolver_settings
        resolver_settings()

    elif action == 'addonSettings':
        from resources.lib.nav.tools import addon_settings
        addon_settings()

    elif action == 'resetSettings':
        from resources.lib.nav.tools import reset_settings
        reset_settings()

    elif action == 'playURL':
        from resources.lib.nav.tools import play_url_dialog
        play_url_dialog()

    elif action == 'markWatched':
        from resources.lib.nav.tools import mark_watched
        mark_watched(params)

    elif action == 'markUnwatched':
        from resources.lib.nav.tools import mark_unwatched
        mark_unwatched(params)

    elif action == 'download':
        from resources.lib.nav.tools import download
        download(params)

    elif action == 'noaction':
        from resources.lib.nav.tools import no_action
        no_action()

    elif action == 'vavooRoot':
        from resources.lib.nav.vavoo_nav import show_groups
        show_groups(params)

    elif action == 'vavooGroup':
        from resources.lib.nav.vavoo_nav import show_group_channels
        show_group_channels(params)

    elif action == 'vavooPlay':
        from resources.lib.nav.vavoo_nav import play_channel
        play_channel(params)

    elif action == 'vavooRefresh':
        from resources.lib.nav.vavoo_nav import refresh_cache
        refresh_cache(params)

    elif action == 'vavooDownload':
        from resources.lib.nav.vavoo_nav import download_stream
        download_stream(params)

    elif action == 'liveTVRoot':
        from resources.lib.nav.livetv_nav import show_groups
        show_groups(params)

    elif action == 'liveTVGroup':
        from resources.lib.nav.livetv_nav import show_group_channels
        show_group_channels(params)

    elif action == 'liveTVPlay':
        from resources.lib.nav.livetv_nav import play_channel
        play_channel(params)

    elif action == 'liveTVRefresh':
        from resources.lib.nav.livetv_nav import refresh_cache
        refresh_cache(params)

    elif action == 'liveTVDownload':
        from resources.lib.nav.livetv_nav import download_stream
        download_stream(params)

    elif action == 'downloadsRoot':
        from resources.lib.nav.downloads_nav import show_downloads
        show_downloads(params)

    elif action == 'downloadCancel':
        from resources.lib.nav.downloads_nav import cancel_download
        cancel_download(params)

    elif action == 'downloadRemove':
        from resources.lib.nav.downloads_nav import remove_download
        remove_download(params)

    elif action == 'downloadClearDone':
        from resources.lib.nav.downloads_nav import clear_done
        clear_done(params)

    elif action == 'downloadPlay':
        from resources.lib.nav.downloads_nav import play_download
        play_download(params)

    # ── Trakt actions ───────────────────────────────────────────────────────

    elif action == 'traktRoot':
        from resources.lib.nav.trakt_nav import show_root
        show_root()

    elif action == 'traktAuth':
        from resources.lib.nav.trakt_nav import do_auth
        do_auth()

    elif action == 'traktLogout':
        from resources.lib.nav.trakt_nav import do_logout
        do_logout()

    elif action == 'traktWatchlistMovies':
        from resources.lib.nav.trakt_nav import show_watchlist_movies
        show_watchlist_movies(params)

    elif action == 'traktWatchlistShows':
        from resources.lib.nav.trakt_nav import show_watchlist_shows
        show_watchlist_shows(params)

    elif action == 'traktHistoryMovies':
        from resources.lib.nav.trakt_nav import show_history_movies
        show_history_movies(params)

    elif action == 'traktHistoryShows':
        from resources.lib.nav.trakt_nav import show_history_shows
        show_history_shows(params)

    elif action == 'traktTrendingMovies':
        from resources.lib.nav.trakt_nav import show_trending_movies
        show_trending_movies(params)

    elif action == 'traktTrendingShows':
        from resources.lib.nav.trakt_nav import show_trending_shows
        show_trending_shows(params)

    elif action == 'traktPopularMovies':
        from resources.lib.nav.trakt_nav import show_popular_movies
        show_popular_movies(params)

    elif action == 'traktPopularShows':
        from resources.lib.nav.trakt_nav import show_popular_shows
        show_popular_shows(params)

    elif action == 'traktAnticipatedMovies':
        from resources.lib.nav.trakt_nav import show_anticipated_movies
        show_anticipated_movies(params)

    elif action == 'traktAnticipatedShows':
        from resources.lib.nav.trakt_nav import show_anticipated_shows
        show_anticipated_shows(params)

    elif action == 'traktAddWatchlist':
        from resources.lib.nav.trakt_nav import add_to_watchlist
        add_to_watchlist(params)

    elif action == 'traktRemoveWatchlist':
        from resources.lib.nav.trakt_nav import remove_from_watchlist
        remove_from_watchlist(params)

    elif action == 'traktRate':
        from resources.lib.nav.trakt_nav import rate_dialog
        rate_dialog(params)


    # ── Debrid / Premium actions ────────────────────────────────────────────

    elif action == 'debridAuthRD':
        from resources.lib.nav.debrid_nav import auth_rd
        auth_rd()

    elif action == 'debridTokenRD':
        from resources.lib.nav.debrid_nav import auth_rd_token
        auth_rd_token()

    elif action == 'debridLogoutRD':
        from resources.lib.nav.debrid_nav import logout_rd
        logout_rd()

    elif action == 'debridLogoutPM':
        from resources.lib.nav.debrid_nav import logout_pm
        logout_pm()

    elif action == 'debridAuthAD':
        from resources.lib.nav.debrid_nav import auth_ad
        auth_ad()

    elif action == 'debridLogoutAD':
        from resources.lib.nav.debrid_nav import logout_ad
        logout_ad()

    elif action == 'debridAuthDL':
        from resources.lib.nav.debrid_nav import auth_dl
        auth_dl()

    elif action == 'debridLogoutDL':
        from resources.lib.nav.debrid_nav import logout_dl
        logout_dl()

    else:
        from resources.lib.nav.main import show_root
        show_root()

except Exception:
    from resources.lib import log
    log.error()
    import xbmcplugin
    import xbmcgui
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
