class ArchiveError(Exception):
    pass


class Bad7zFile(ArchiveError):
    pass


class UnsupportedCompressionMethodError(ArchiveError):
    pass


class DecompressionError(ArchiveError):
    pass


class InternalError(ArchiveError):
    pass
