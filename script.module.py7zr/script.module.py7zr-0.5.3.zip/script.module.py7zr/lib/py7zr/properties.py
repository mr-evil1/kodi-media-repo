import binascii
from enum import Enum

from py7zr.exceptions import InternalError

MAGIC_7Z = binascii.unhexlify('377abcaf271c')


class Configuration:
    P7ZIP_MAJOR_VERSION = b'\x00'
    P7ZIP_MINOR_VERSION = b'\x04'
    read_blocksize = 32248
    _instance = None

    @classmethod
    def get(cls, key):
        if cls._instance is None:
            cls._instance = cls()
        return getattr(cls._instance, key)

    @classmethod
    def set(cls, size):
        if cls._instance is None:
            cls._instance = cls()
            setattr(cls._instance, 'read_blocksize', size)
        else:
            raise InternalError("Try to set buffer size after instanced.")


class ByteEnum(bytes, Enum):
    pass


class Property(ByteEnum):
    END = binascii.unhexlify('00')
    HEADER = binascii.unhexlify('01')
    ARCHIVE_PROPERTIES = binascii.unhexlify('02')
    ADDITIONAL_STREAMS_INFO = binascii.unhexlify('03')
    MAIN_STREAMS_INFO = binascii.unhexlify('04')
    FILES_INFO = binascii.unhexlify('05')
    PACK_INFO = binascii.unhexlify('06')
    UNPACK_INFO = binascii.unhexlify('07')
    SUBSTREAMS_INFO = binascii.unhexlify('08')
    SIZE = binascii.unhexlify('09')
    CRC = binascii.unhexlify('0a')
    FOLDER = binascii.unhexlify('0b')
    CODERS_UNPACK_SIZE = binascii.unhexlify('0c')
    NUM_UNPACK_STREAM = binascii.unhexlify('0d')
    EMPTY_STREAM = binascii.unhexlify('0e')
    EMPTY_FILE = binascii.unhexlify('0f')
    ANTI = binascii.unhexlify('10')
    NAME = binascii.unhexlify('11')
    CREATION_TIME = binascii.unhexlify('12')
    LAST_ACCESS_TIME = binascii.unhexlify('13')
    LAST_WRITE_TIME = binascii.unhexlify('14')
    ATTRIBUTES = binascii.unhexlify('15')
    COMMENT = binascii.unhexlify('16')
    ENCODED_HEADER = binascii.unhexlify('17')
    START_POS = binascii.unhexlify('18')
    DUMMY = binascii.unhexlify('19')


class CompressionMethod(ByteEnum):
    COPY = binascii.unhexlify('00')
    DELTA = binascii.unhexlify('03')
    BCJ = binascii.unhexlify('04')
    PPC = binascii.unhexlify('05')
    IA64 = binascii.unhexlify('06')
    ARM = binascii.unhexlify('07')
    ARMT = binascii.unhexlify('08')
    SPARC = binascii.unhexlify('09')
    SWAP2 = binascii.unhexlify('020302')
    SWAP4 = binascii.unhexlify('020304')
    LZMA = binascii.unhexlify('030101')
    PPMD = binascii.unhexlify('030401')
    P7Z_BCJ = binascii.unhexlify('03030103')
    P7Z_BCJ2 = binascii.unhexlify('0303011B')
    BCJ_PPC = binascii.unhexlify('03030205')
    BCJ_IA64 = binascii.unhexlify('03030401')
    BCJ_ARM = binascii.unhexlify('03030501')
    BCJ_ARMT = binascii.unhexlify('03030701')
    BCJ_SPARC = binascii.unhexlify('03030805')
    LZMA2 = binascii.unhexlify('21')
    MISC_ZIP = binascii.unhexlify('0401')
    MISC_BZIP2 = binascii.unhexlify('040202')
    MISC_DEFLATE = binascii.unhexlify('040108')
    MISC_DEFLATE64 = binascii.unhexlify('040109')
    MISC_Z = binascii.unhexlify('0405')
    MISC_LZH = binascii.unhexlify('0406')
    NSIS_DEFLATE = binascii.unhexlify('040901')
    NSIS_BZIP2 = binascii.unhexlify('040902')
    CRYPT_ZIPCRYPT = binascii.unhexlify('06f10101')
    CRYPT_RAR29AES = binascii.unhexlify('06f10303')
    CRYPT_AES256_SHA256 = binascii.unhexlify('06f10701')


class SupportedMethods:
    formats = [{'name': "7z", 'magic': MAGIC_7Z}]
    codecs = [
        {'id': CompressionMethod.LZMA, 'name': "LZMA"},
        {'id': CompressionMethod.LZMA2, 'name': "LZMA2"},
        {'id': CompressionMethod.DELTA, 'name': "DELTA"},
        {'id': CompressionMethod.P7Z_BCJ, 'name': "BCJ"},
        {'id': CompressionMethod.BCJ_PPC, 'name': 'PPC'},
        {'id': CompressionMethod.BCJ_IA64, 'name': 'IA64'},
        {'id': CompressionMethod.BCJ_ARM, 'name': "ARM"},
        {'id': CompressionMethod.BCJ_ARMT, 'name': "ARMT"},
        {'id': CompressionMethod.BCJ_SPARC, 'name': 'SPARC'},
    ]
