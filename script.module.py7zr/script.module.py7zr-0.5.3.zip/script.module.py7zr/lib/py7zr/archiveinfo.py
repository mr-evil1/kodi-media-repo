import functools
import io
import os
import struct
from binascii import unhexlify
from functools import reduce
from io import BytesIO
from operator import and_, or_
from struct import pack, unpack
from typing import Any, BinaryIO, Dict, List, Optional, Tuple

from py7zr.compression import SevenZipCompressor, SevenZipDecompressor
from py7zr.exceptions import Bad7zFile, UnsupportedCompressionMethodError
from py7zr.helpers import ArchiveTimestamp, calculate_crc32
from py7zr.properties import (MAGIC_7Z, CompressionMethod, Configuration, Property)

MAX_LENGTH = 65536


def read_crcs(file, count):
    data = file.read(4 * count)
    return [unpack('<L', data[i * 4:i * 4 + 4])[0] for i in range(count)]


def write_crcs(file, crcs):
    for crc in crcs:
        write_uint32(file, crc)


def read_bytes(file, length):
    return unpack(b'B' * length, file.read(length))


def read_byte(file):
    return ord(file.read(1))


def write_bytes(file, data):
    if isinstance(data, bytes):
        return file.write(data)
    elif isinstance(data, bytearray):
        assert len(data) > 0
        return file.write(pack(b'B' * len(data), data))
    else:
        raise


def write_byte(file, data):
    assert len(data) == 1
    return write_bytes(file, data)


def read_real_uint64(file):
    res = file.read(8)
    a = unpack('<Q', res)[0]
    return a, res


def read_uint32(file):
    res = file.read(4)
    a = unpack('<L', res)[0]
    return a, res


def write_uint32(file, value):
    b = pack('<L', value)
    file.write(b)


def read_uint64(file):
    b = ord(file.read(1))
    if b == 255:
        return read_real_uint64(file)[0]
    blen = [(0b01111111, 0), (0b10111111, 1), (0b11011111, 2), (0b11101111, 3),
            (0b11110111, 4), (0b11111011, 5), (0b11111101, 6), (0b11111110, 7)]
    mask = 0x80
    vlen = 8
    for v, l in blen:
        if b <= v:
            vlen = l
            break
        mask >>= 1
    if vlen == 0:
        return b & (mask - 1)
    val = file.read(vlen)
    value = int.from_bytes(val, byteorder='little')
    highpart = b & (mask - 1)
    return value + (highpart << (vlen * 8))


def write_real_uint64(file, value):
    file.write(pack('<Q', value))


def write_uint64(file, value):
    mask = 0x80
    length = (value.bit_length() + 7) // 8 or 1
    ba = bytearray(value.to_bytes(length, 'little'))
    for _ in range(length - 1):
        mask |= mask >> 1
    if ba[0] >= 2 ** (8 - length):
        file.write(pack('B', mask))
    elif length > 1:
        ba[0] |= mask
    else:
        pass
    file.write(ba)


def read_boolean(file, count, checkall=False):
    if checkall:
        all_defined = file.read(1)
        if all_defined != unhexlify('00'):
            return [True] * count
    result = []
    b = 0
    mask = 0
    for i in range(count):
        if mask == 0:
            b = ord(file.read(1))
            mask = 0x80
        result.append(b & mask != 0)
        mask >>= 1
    return result


def write_boolean(file, booleans, all_defined=False):
    if all_defined and reduce(and_, booleans):
        file.write(b'\x01')
        return
    elif all_defined:
        file.write(b'\x00')
    mask = 0x80
    o = 0x00
    for b in booleans:
        if mask == 0:
            file.write(pack('B', o))
            mask = 0x80
            o = 0x80 if b else 0x00
        else:
            o |= mask if b else 0x00
            mask >>= 1
    if mask != 0x00:
        file.write(pack('B', o))


def read_utf16(file):
    val = ''
    for _ in range(MAX_LENGTH):
        ch = file.read(2)
        if ch == unhexlify('0000'):
            break
        val += ch.decode('utf-16LE')
    return val


def write_utf16(file, val):
    for c in val:
        file.write(c.encode('utf-16LE'))
    file.write(b'\x00\x00')


def bits_to_bytes(bit_length):
    return - (-bit_length // 8)


class ArchiveProperties:

    __slots__ = ['property_data']

    def __init__(self):
        self.property_data = []

    @classmethod
    def retrieve(cls, file):
        return cls()._read(file)

    def _read(self, file):
        pid = file.read(1)
        if pid == Property.ARCHIVE_PROPERTIES:
            while True:
                ptype = file.read(1)
                if ptype == Property.END:
                    break
                size = read_uint64(file)
                props = read_bytes(file, size)
                self.property_data.append(props)
        return self

    def write(self, file):
        if len(self.property_data) > 0:
            write_byte(file, Property.ARCHIVE_PROPERTIES)
            for data in self.property_data:
                write_uint64(file, len(data))
                write_bytes(file, data)
            write_byte(file, Property.END)


class PackInfo:

    __slots__ = ['packpos', 'numstreams', 'packsizes', 'packpositions', 'crcs']

    def __init__(self):
        self.packpos = 0
        self.numstreams = 0
        self.packsizes = []
        self.crcs = None

    @classmethod
    def retrieve(cls, file):
        return cls()._read(file)

    def _read(self, file):
        self.packpos = read_uint64(file)
        self.numstreams = read_uint64(file)
        pid = file.read(1)
        if pid == Property.SIZE:
            self.packsizes = [read_uint64(file) for _ in range(self.numstreams)]
            pid = file.read(1)
            if pid == Property.CRC:
                self.crcs = [read_uint64(file) for _ in range(self.numstreams)]
                pid = file.read(1)
        if pid != Property.END:
            raise Bad7zFile('end id expected but %s found' % repr(pid))
        self.packpositions = [sum(self.packsizes[:i]) for i in range(self.numstreams)]
        return self

    def write(self, file):
        assert self.packpos is not None
        numstreams = len(self.packsizes)
        assert self.crcs is None or len(self.crcs) == numstreams
        write_byte(file, Property.PACK_INFO)
        write_uint64(file, self.packpos)
        write_uint64(file, numstreams)
        write_byte(file, Property.SIZE)
        for size in self.packsizes:
            write_uint64(file, size)
        if self.crcs is not None:
            write_bytes(file, Property.CRC)
            for crc in self.crcs:
                write_uint64(file, crc)
        write_byte(file, Property.END)


class Folder:

    __slots__ = ['unpacksizes', 'solid', 'coders', 'digestdefined', 'totalin', 'totalout',
                 'bindpairs', 'packed_indices', 'crc', 'decompressor', 'compressor', 'files']

    def __init__(self):
        self.unpacksizes = None
        self.coders = []
        self.bindpairs = []
        self.packed_indices = []
        self.totalin = 0
        self.totalout = 0
        self.solid = False
        self.digestdefined = False
        self.crc = None
        self.decompressor = None
        self.compressor = None
        self.files = None

    @classmethod
    def retrieve(cls, file):
        obj = cls()
        obj._read(file)
        return obj

    def _read(self, file):
        num_coders = read_uint64(file)
        for i in range(num_coders):
            while True:
                b = read_byte(file)
                methodsize = b & 0xf
                iscomplex = b & 0x10 == 0x10
                hasattributes = b & 0x20 == 0x20
                last_alternative = b & 0x80 == 0
                c = {'method': file.read(methodsize)}
                if iscomplex:
                    c['numinstreams'] = read_uint64(file)
                    c['numoutstreams'] = read_uint64(file)
                else:
                    c['numinstreams'] = 1
                    c['numoutstreams'] = 1
                self.totalin += c['numinstreams']
                self.totalout += c['numoutstreams']
                if hasattributes:
                    proplen = read_uint64(file)
                    c['properties'] = file.read(proplen)
                self.coders.append(c)
                if last_alternative:
                    break
        num_bindpairs = self.totalout - 1
        for i in range(num_bindpairs):
            self.bindpairs.append((read_uint64(file), read_uint64(file),))
        num_packedstreams = self.totalin - num_bindpairs
        if num_packedstreams == 1:
            for i in range(self.totalin):
                if self._find_in_bin_pair(i) < 0:
                    self.packed_indices.append(i)
        elif num_packedstreams > 1:
            for i in range(num_packedstreams):
                self.packed_indices.append(read_uint64(file))

    def write(self, file):
        num_coders = len(self.coders)
        assert num_coders > 0
        write_uint64(file, num_coders)
        for i, c in enumerate(self.coders):
            method = c['method']
            method_size = len(method)
            numinstreams = c['numinstreams']
            numoutstreams = c['numoutstreams']
            iscomplex = 0x00 if numinstreams == 1 and numoutstreams == 1 else 0x10
            last_alternative = 0x80 if i < num_coders - 1 else 0x00
            hasattributes = 0x20 if c['properties'] is not None else 0x00
            write_byte(file, struct.pack('B', method_size & 0xf | iscomplex | hasattributes | last_alternative))
            write_bytes(file, method)
            if iscomplex == 0x10:
                write_uint64(file, numinstreams)
                write_uint64(file, numoutstreams)
            if c['properties'] is not None:
                write_uint64(file, len(c['properties']))
                write_bytes(file, c['properties'])
        num_bindpairs = self.totalout - 1
        assert len(self.bindpairs) == num_bindpairs
        num_packedstreams = self.totalin - num_bindpairs
        for bp in self.bindpairs:
            write_uint64(file, bp[0])
            write_uint64(file, bp[1])
        if num_packedstreams > 1:
            for pi in self.packed_indices:
                write_uint64(file, pi)

    def get_decompressor(self, size):
        if self.decompressor is not None:
            return self.decompressor
        else:
            try:
                self.decompressor = SevenZipDecompressor(self.coders, size, self.crc)
            except Exception as e:
                raise e
            if self.decompressor is not None:
                return self.decompressor
            else:
                raise

    def get_compressor(self):
        if self.compressor is not None:
            return self.compressor
        else:
            try:
                self.compressor = SevenZipCompressor()
                self.coders = self.compressor.coders
                return self.compressor
            except Exception as e:
                raise e

    def get_unpack_size(self):
        if self.unpacksizes is None:
            return 0
        for i in range(len(self.unpacksizes) - 1, -1, -1):
            if self._find_out_bin_pair(i):
                return self.unpacksizes[i]
        raise TypeError('not found')

    def _find_in_bin_pair(self, index):
        for idx, (a, b) in enumerate(self.bindpairs):
            if a == index:
                return idx
        return -1

    def _find_out_bin_pair(self, index):
        for idx, (a, b) in enumerate(self.bindpairs):
            if b == index:
                return idx
        return -1

    def is_encrypted(self):
        return CompressionMethod.CRYPT_AES256_SHA256 in [x['method'] for x in self.coders]


class UnpackInfo:

    __slots__ = ['numfolders', 'folders', 'datastreamidx']

    @classmethod
    def retrieve(cls, file):
        obj = cls()
        obj._read(file)
        return obj

    def __init__(self):
        self.numfolders = None
        self.folders = []
        self.datastreamidx = None

    def _read(self, file):
        pid = file.read(1)
        if pid != Property.FOLDER:
            raise Bad7zFile('folder id expected but %s found' % repr(pid))
        self.numfolders = read_uint64(file)
        self.folders = []
        external = read_byte(file)
        if external == 0x00:
            self.folders = [Folder.retrieve(file) for _ in range(self.numfolders)]
        else:
            datastreamidx = read_uint64(file)
            current_pos = file.tell()
            file.seek(datastreamidx, 0)
            self.folders = [Folder.retrieve(file) for _ in range(self.numfolders)]
            file.seek(current_pos, 0)
        self._retrieve_coders_info(file)

    def _retrieve_coders_info(self, file):
        pid = file.read(1)
        if pid != Property.CODERS_UNPACK_SIZE:
            raise Bad7zFile('coders unpack size id expected but %s found' % repr(pid))
        for folder in self.folders:
            folder.unpacksizes = [read_uint64(file) for _ in range(folder.totalout)]
        pid = file.read(1)
        if pid == Property.CRC:
            defined = read_boolean(file, self.numfolders, checkall=True)
            crcs = read_crcs(file, self.numfolders)
            for idx, folder in enumerate(self.folders):
                folder.digestdefined = defined[idx]
                folder.crc = crcs[idx]
            pid = file.read(1)
        if pid != Property.END:
            raise Bad7zFile('end id expected but %s found' % repr(pid))

    def write(self, file):
        assert self.numfolders is not None
        assert self.folders is not None
        file.write(Property.UNPACK_INFO)
        file.write(Property.FOLDER)
        write_uint64(file, self.numfolders)
        write_byte(file, b'\x00')
        for i in range(self.numfolders):
            for folder in self.folders:
                folder.write(file)
        write_byte(file, Property.CODERS_UNPACK_SIZE)
        for folder in self.folders:
            for i in range(folder.totalout):
                write_uint64(file, folder.unpacksizes[i])
        write_byte(file, Property.END)


class SubstreamsInfo:

    __slots__ = ['digests', 'digestsdefined', 'unpacksizes', 'num_unpackstreams_folders']

    def __init__(self):
        self.digests = []
        self.digestsdefined = []
        self.unpacksizes = None
        self.num_unpackstreams_folders = []

    @classmethod
    def retrieve(cls, file, numfolders, folders):
        obj = cls()
        obj._read(file, numfolders, folders)
        return obj

    def _read(self, file, numfolders, folders):
        pid = file.read(1)
        if pid == Property.NUM_UNPACK_STREAM:
            self.num_unpackstreams_folders = [read_uint64(file) for _ in range(numfolders)]
            pid = file.read(1)
        else:
            self.num_unpackstreams_folders = [1] * numfolders
        if pid == Property.SIZE:
            self.unpacksizes = []
            for i in range(len(self.num_unpackstreams_folders)):
                totalsize = 0
                for j in range(1, self.num_unpackstreams_folders[i]):
                    size = read_uint64(file)
                    self.unpacksizes.append(size)
                    totalsize += size
                self.unpacksizes.append(folders[i].get_unpack_size() - totalsize)
            pid = file.read(1)
        num_digests = 0
        num_digests_total = 0
        for i in range(numfolders):
            numsubstreams = self.num_unpackstreams_folders[i]
            if numsubstreams != 1 or not folders[i].digestdefined:
                num_digests += numsubstreams
            num_digests_total += numsubstreams
        if pid == Property.CRC:
            defined = read_boolean(file, num_digests, checkall=True)
            crcs = read_crcs(file, num_digests)
            didx = 0
            for i in range(numfolders):
                folder = folders[i]
                numsubstreams = self.num_unpackstreams_folders[i]
                if numsubstreams == 1 and folder.digestdefined and folder.crc is not None:
                    self.digestsdefined.append(True)
                    self.digests.append(folder.crc)
                else:
                    for j in range(numsubstreams):
                        self.digestsdefined.append(defined[didx])
                        self.digests.append(crcs[didx])
                        didx += 1
            pid = file.read(1)
        if pid != Property.END:
            raise Bad7zFile('end id expected but %r found' % pid)
        if not self.digestsdefined:
            self.digestsdefined = [False] * num_digests_total
            self.digests = [0] * num_digests_total

    def write(self, file, numfolders):
        assert self.num_unpackstreams_folders is not None
        if len(self.num_unpackstreams_folders) == 0:
            return
        if self.unpacksizes is None:
            raise ValueError
        write_byte(file, Property.SUBSTREAMS_INFO)
        if not functools.reduce(lambda x, y: x and (y == 1), self.num_unpackstreams_folders, True):
            write_byte(file, Property.NUM_UNPACK_STREAM)
            for n in self.num_unpackstreams_folders:
                write_uint64(file, n)
        write_byte(file, Property.SIZE)
        idx = 0
        for i in range(numfolders):
            for j in range(1, self.num_unpackstreams_folders[i]):
                size = self.unpacksizes[idx]
                write_uint64(file, size)
                idx += 1
            idx += 1
        if functools.reduce(lambda x, y: x or y, self.digestsdefined, False):
            write_byte(file, Property.CRC)
            write_boolean(file, self.digestsdefined, all_defined=True)
            write_crcs(file, self.digests)
        write_byte(file, Property.END)


class StreamsInfo:

    __slots__ = ['packinfo', 'unpackinfo', 'substreamsinfo']

    def __init__(self):
        self.packinfo = None
        self.unpackinfo = None
        self.substreamsinfo = None

    @classmethod
    def retrieve(cls, file):
        obj = cls()
        obj.read(file)
        return obj

    def read(self, file):
        pid = file.read(1)
        if pid == Property.PACK_INFO:
            self.packinfo = PackInfo.retrieve(file)
            pid = file.read(1)
        if pid == Property.UNPACK_INFO:
            self.unpackinfo = UnpackInfo.retrieve(file)
            pid = file.read(1)
        if pid == Property.SUBSTREAMS_INFO:
            self.substreamsinfo = SubstreamsInfo.retrieve(file, self.unpackinfo.numfolders, self.unpackinfo.folders)
            pid = file.read(1)
        if pid != Property.END:
            raise Bad7zFile('end id expected but %s found' % repr(pid))

    def write(self, file):
        write_byte(file, Property.MAIN_STREAMS_INFO)
        if self.packinfo is not None:
            self.packinfo.write(file)
        if self.unpackinfo is not None:
            self.unpackinfo.write(file)
        if self.substreamsinfo is not None:
            self.substreamsinfo.write(file, self.unpackinfo.numfolders)
        write_byte(file, Property.END)


class FilesInfo:

    __slots__ = ['files', 'emptyfiles', 'antifiles']

    def __init__(self):
        self.files = []
        self.emptyfiles = []
        self.antifiles = None

    @classmethod
    def retrieve(cls, file):
        obj = cls()
        obj._read(file)
        return obj

    def _read(self, fp):
        numfiles = read_uint64(fp)
        self.files = [{'emptystream': False} for _ in range(numfiles)]
        numemptystreams = 0
        while True:
            typ = read_uint64(fp)
            if typ > 255:
                raise Bad7zFile('invalid type, must be below 256, is %d' % typ)
            prop = struct.pack(b'B', typ)
            if prop == Property.END:
                break
            size = read_uint64(fp)
            if prop == Property.DUMMY:
                fp.seek(size, os.SEEK_CUR)
                continue
            buffer = io.BytesIO(fp.read(size))
            if prop == Property.EMPTY_STREAM:
                isempty = read_boolean(buffer, numfiles, checkall=False)
                list(map(lambda x, y: x.update({'emptystream': y}), self.files, isempty))
                numemptystreams += isempty.count(True)
                self.emptyfiles = [False] * numemptystreams
                self.antifiles = [False] * numemptystreams
            elif prop == Property.EMPTY_FILE:
                self.emptyfiles = read_boolean(buffer, numemptystreams, checkall=False)
            elif prop == Property.ANTI:
                self.antifiles = read_boolean(buffer, numemptystreams, checkall=False)
            elif prop == Property.NAME:
                external = buffer.read(1)
                if external == b'\x00':
                    self._read_name(buffer)
                else:
                    dataindex = read_uint64(buffer)
                    current_pos = fp.tell()
                    fp.seek(dataindex, 0)
                    self._read_name(fp)
                    fp.seek(current_pos, 0)
            elif prop == Property.CREATION_TIME:
                self._read_times(buffer, 'creationtime')
            elif prop == Property.LAST_ACCESS_TIME:
                self._read_times(buffer, 'lastaccesstime')
            elif prop == Property.LAST_WRITE_TIME:
                self._read_times(buffer, 'lastwritetime')
            elif prop == Property.ATTRIBUTES:
                defined = read_boolean(buffer, numfiles, checkall=True)
                external = buffer.read(1)
                if external == b'\x00':
                    self._read_attributes(buffer, defined)
                else:
                    dataindex = read_uint64(buffer)
                    current_pos = fp.tell()
                    fp.seek(dataindex, 0)
                    self._read_attributes(fp, defined)
                    fp.seek(current_pos, 0)
            elif prop == Property.START_POS:
                self._read_start_pos(buffer)
            else:
                raise Bad7zFile('invalid type %r' % (prop))

    def _read_name(self, buffer):
        for f in self.files:
            f['filename'] = read_utf16(buffer)

    def _read_attributes(self, buffer, defined):
        for idx, f in enumerate(self.files):
            f['attributes'] = read_uint32(buffer)[0] if defined[idx] else None

    def _read_times(self, fp, name):
        defined = read_boolean(fp, len(self.files), checkall=True)
        external = fp.read(1)
        assert external == b'\x00'
        for i, f in enumerate(self.files):
            f[name] = ArchiveTimestamp(read_real_uint64(fp)[0]) if defined[i] else None

    def _read_start_pos(self, fp):
        defined = read_boolean(fp, len(self.files), checkall=True)
        external = fp.read(1)
        assert external == 0x00
        for i, f in enumerate(self.files):
            f['startpos'] = read_real_uint64(fp)[0] if defined[i] else None

    def _write_times(self, fp, propid, name):
        write_byte(fp, propid)
        defined = []
        num_defined = 0
        for f in self.files:
            if name in f.keys():
                if f[name] is not None:
                    defined.append(True)
                    num_defined += 1
        if num_defined == len(defined):
            write_byte(fp, (num_defined * 8 + 2).to_bytes(1, byteorder='little'))
        else:
            write_byte(fp, (num_defined * 8 + bits_to_bytes(num_defined) + 2).to_bytes(1, byteorder='little'))
        write_boolean(fp, defined, all_defined=True)
        write_byte(fp, b'\x00')
        for i, file in enumerate(self.files):
            if defined[i]:
                write_real_uint64(fp, ArchiveTimestamp.from_datetime(file[name]))

    def _write_prop_bool_vector(self, fp, propid, vector):
        write_byte(fp, propid)
        write_boolean(fp, vector, all_defined=True)

    def _are_there(self, vector):
        if vector is not None:
            if functools.reduce(or_, vector):
                return True
        return False

    def _write_names(self, file):
        name_defined = 0
        names = []
        name_size = 0
        for f in self.files:
            if f.get('filename', None) is not None:
                name_defined += 1
                names.append(f['filename'])
                name_size += len(f['filename'].encode('utf-16LE')) + 2
        if name_defined > 0:
            write_byte(file, Property.NAME)
            write_uint64(file, name_size + 1)
            write_byte(file, b'\x00')
            for n in names:
                write_utf16(file, n)

    def _write_attributes(self, file):
        defined = []
        num_defined = 0
        for f in self.files:
            if 'attributes' in f.keys():
                if f['attributes'] is not None:
                    defined.append(True)
                    num_defined += 1
                    continue
            defined.append(False)
        write_byte(file, Property.ATTRIBUTES)
        if num_defined == len(defined):
            write_byte(file, (num_defined * 4 + 2).to_bytes(1, byteorder='little'))
        else:
            write_byte(file, (num_defined * 4 + bits_to_bytes(num_defined) + 2).to_bytes(1, byteorder='little'))
        write_boolean(file, defined, all_defined=False)
        write_byte(file, b'\x00')
        for i, f in enumerate(self.files):
            if defined[i]:
                write_uint32(file, f['attributes'])

    def write(self, file):
        assert self.files is not None
        write_byte(file, Property.FILES_INFO)
        numfiles = len(self.files)
        write_uint64(file, numfiles)
        emptystreams = []
        for f in self.files:
            emptystreams.append(f['emptystream'])
        if self._are_there(emptystreams):
            write_byte(file, Property.EMPTY_STREAM)
            write_byte(file, bits_to_bytes(numfiles).to_bytes(1, 'little'))
            write_boolean(file, emptystreams, all_defined=False)
        else:
            if self._are_there(self.emptyfiles):
                self._write_prop_bool_vector(file, Property.EMPTY_FILE, self.emptyfiles)
            if self._are_there(self.antifiles):
                self._write_prop_bool_vector(file, Property.ANTI, self.antifiles)
        self._write_names(file)
        self._write_times(file, Property.CREATION_TIME, 'creationtime')
        self._write_times(file, Property.LAST_ACCESS_TIME, 'lastaccesstime')
        self._write_times(file, Property.LAST_WRITE_TIME, 'lastwritetime')
        self._write_attributes(file)
        write_byte(file, Property.END)


class Header:

    __slot__ = ['solid', 'properties', 'additional_streams', 'main_streams', 'files_info',
                'size', '_start_pos']

    def __init__(self):
        self.solid = False
        self.properties = None
        self.additional_streams = None
        self.main_streams = None
        self.files_info = None
        self.size = 0
        self._start_pos = 0

    @classmethod
    def retrieve(cls, fp, buffer, start_pos):
        obj = cls()
        obj._read(fp, buffer, start_pos)
        return obj

    def _read(self, fp, buffer, start_pos):
        self._start_pos = start_pos
        fp.seek(self._start_pos)
        self._decode_header(fp, buffer)

    def _decode_header(self, fp, buffer):
        pid = buffer.read(1)
        if not pid:
            return
        elif pid == Property.HEADER:
            self._extract_header_info(buffer)
            return
        elif pid != Property.ENCODED_HEADER:
            raise TypeError('Unknown field: %r' % (id))
        streams = StreamsInfo.retrieve(buffer)
        self._decode_header(fp, self._get_headerdata_from_streams(fp, streams))

    def _get_headerdata_from_streams(self, fp, streams):
        buffer = io.BytesIO()
        src_start = self._start_pos
        for folder in streams.unpackinfo.folders:
            if folder.is_encrypted():
                raise UnsupportedCompressionMethodError()
            uncompressed = folder.unpacksizes
            if not isinstance(uncompressed, (list, tuple)):
                uncompressed = [uncompressed] * len(folder.coders)
            compressed_size = streams.packinfo.packsizes[0]
            uncompressed_size = uncompressed[-1]
            src_start += streams.packinfo.packpos
            fp.seek(src_start, 0)
            decompressor = folder.get_decompressor(compressed_size)
            folder_data = decompressor.decompress(fp.read(compressed_size))[:uncompressed_size]
            src_start += uncompressed_size
            if folder.digestdefined:
                if folder.crc != calculate_crc32(folder_data):
                    raise Bad7zFile('invalid block data')
            buffer.write(folder_data)
        buffer.seek(0, 0)
        return buffer

    def build_header(self, folders):
        self.files_info = FilesInfo()
        self.main_streams = StreamsInfo()
        self.main_streams.packinfo = PackInfo()
        self.main_streams.packinfo.numstreams = 0
        self.main_streams.packinfo.packpos = 0
        self.main_streams.unpackinfo = UnpackInfo()
        self.main_streams.unpackinfo.numfolders = len(folders)
        self.main_streams.unpackinfo.folders = folders
        self.main_streams.substreamsinfo = SubstreamsInfo()
        self.main_streams.substreamsinfo.num_unpackstreams_folders = [len(folders)]
        self.main_streams.substreamsinfo.unpacksizes = []

    def write(self, file, encoded=True):
        startpos = file.tell()
        if encoded:
            buf = io.BytesIO()
            self.write(buf, encoded=False)
            header_data = buf.getvalue()
            streams = StreamsInfo()
            streams.packinfo = PackInfo()
            streams.packinfo.packpos = 0
            streams.packinfo.packsizes = []
            streams.unpackinfo = UnpackInfo()
            streams.unpackinfo.folders = []
            write_byte(file, Property.ENCODED_HEADER)
            streams.write(file)
        else:
            write_byte(file, Property.HEADER)
            if self.main_streams is not None:
                self.main_streams.write(file)
            if self.files_info is not None:
                self.files_info.write(file)
            if self.properties is not None:
                self.properties.write(file)
            if self.additional_streams is not None:
                self.additional_streams.write(file)
            write_byte(file, Property.END)
        endpos = file.tell()
        return endpos - startpos

    def _extract_header_info(self, fp):
        pid = fp.read(1)
        if pid == Property.ARCHIVE_PROPERTIES:
            self.properties = ArchiveProperties.retrieve(fp)
            pid = fp.read(1)
        if pid == Property.ADDITIONAL_STREAMS_INFO:
            self.additional_streams = StreamsInfo.retrieve(fp)
            pid = fp.read(1)
        if pid == Property.MAIN_STREAMS_INFO:
            self.main_streams = StreamsInfo.retrieve(fp)
            pid = fp.read(1)
        if pid == Property.FILES_INFO:
            self.files_info = FilesInfo.retrieve(fp)
            pid = fp.read(1)
        if pid != Property.END:
            raise Bad7zFile('end id expected but %s found' % (repr(pid)))


class SignatureHeader:

    __slots__ = ['version', 'startheadercrc', 'nextheaderofs', 'nextheadersize', 'nextheadercrc']

    def __init__(self):
        self.version = (Configuration.P7ZIP_MAJOR_VERSION, Configuration.P7ZIP_MINOR_VERSION)
        self.startheadercrc = None
        self.nextheaderofs = None
        self.nextheadersize = None
        self.nextheadercrc = None

    @classmethod
    def retrieve(cls, file):
        obj = cls()
        obj._read(file)
        return obj

    def _read(self, file):
        file.seek(len(MAGIC_7Z), 0)
        self.version = read_bytes(file, 2)
        self.startheadercrc, _ = read_uint32(file)
        self.nextheaderofs, data = read_real_uint64(file)
        crc = calculate_crc32(data)
        self.nextheadersize, data = read_real_uint64(file)
        crc = calculate_crc32(data, crc)
        self.nextheadercrc, data = read_uint32(file)
        crc = calculate_crc32(data, crc)
        if crc != self.startheadercrc:
            raise Bad7zFile('invalid header data')

    def calccrc(self, data):
        self.nextheadersize = len(data)
        self.nextheadercrc = calculate_crc32(data)
        assert self.nextheaderofs is not None
        buf = io.BytesIO()
        write_real_uint64(buf, self.nextheaderofs)
        write_real_uint64(buf, self.nextheadersize)
        write_uint32(buf, self.nextheadercrc)
        startdata = buf.getvalue()
        self.startheadercrc = calculate_crc32(startdata)

    def write(self, file):
        assert self.startheadercrc is not None
        assert self.nextheadercrc is not None
        assert self.nextheaderofs is not None
        assert self.nextheadersize is not None
        file.seek(0, 0)
        write_bytes(file, MAGIC_7Z)
        write_byte(file, self.version[0])
        write_byte(file, self.version[1])
        write_uint32(file, self.startheadercrc)
        write_real_uint64(file, self.nextheaderofs)
        write_real_uint64(file, self.nextheadersize)
        write_uint32(file, self.nextheadercrc)

    def _write_skelton(self, file):
        file.seek(0, 0)
        write_bytes(file, MAGIC_7Z)
        write_byte(file, self.version[0])
        write_byte(file, self.version[1])
        write_uint32(file, 1)
        write_real_uint64(file, 2)
        write_real_uint64(file, 3)
        write_uint32(file, 4)
