import datetime
import errno
import functools
import io
import operator
import os
import pathlib
import stat
import threading
from io import BytesIO
from typing import Any, BinaryIO, Dict, List, Optional, Tuple, Union

from py7zr.archiveinfo import Folder, Header, SignatureHeader
from py7zr.compression import SevenZipCompressor, Worker, get_methods_names
from py7zr.exceptions import Bad7zFile
from py7zr.helpers import ArchiveTimestamp, calculate_crc32, filetime_to_dt
from py7zr.properties import MAGIC_7Z, Configuration

FILE_ATTRIBUTE_UNIX_EXTENSION = 0x8000
FILE_ATTRIBUTE_WINDOWS_MASK = 0x04fff


class ArchiveFile:

    def __init__(self, id, file_info):
        self.id = id
        self._file_info = file_info

    def file_properties(self):
        properties = self._file_info
        if properties is not None:
            properties['readonly'] = self.readonly
            properties['posix_mode'] = self.posix_mode
            properties['archivable'] = self.archivable
            properties['is_directory'] = self.is_directory
        return properties

    def _get_property(self, key):
        try:
            return self._file_info[key]
        except KeyError:
            return None

    @property
    def origin(self):
        return self._get_property('origin')

    @property
    def folder(self):
        return self._get_property('folder')

    @property
    def filename(self):
        return self._get_property('filename')

    @property
    def emptystream(self):
        return self._get_property('emptystream')

    @property
    def uncompressed(self):
        return self._get_property('uncompressed')

    @property
    def uncompressed_size(self):
        return functools.reduce(operator.add, self.uncompressed)

    @property
    def compressed(self):
        return self._get_property('compressed')

    def _test_attribute(self, target_bit):
        attributes = self._get_property('attributes')
        if attributes is None:
            return False
        return attributes & target_bit == target_bit

    @property
    def archivable(self):
        return self._test_attribute(stat.FILE_ATTRIBUTE_ARCHIVE)

    @property
    def is_directory(self):
        return self._test_attribute(stat.FILE_ATTRIBUTE_DIRECTORY)

    @property
    def readonly(self):
        return self._test_attribute(stat.FILE_ATTRIBUTE_READONLY)

    def _get_unix_extension(self):
        attributes = self._get_property('attributes')
        if self._test_attribute(FILE_ATTRIBUTE_UNIX_EXTENSION):
            return attributes >> 16
        return None

    @property
    def is_symlink(self):
        e = self._get_unix_extension()
        if e is not None:
            return stat.S_ISLNK(e)
        return False

    @property
    def is_socket(self):
        e = self._get_unix_extension()
        if e is not None:
            return stat.S_ISSOCK(e)
        return False

    @property
    def lastwritetime(self):
        return self._get_property('lastwritetime')

    @property
    def posix_mode(self):
        e = self._get_unix_extension()
        if e is not None:
            return stat.S_IMODE(e)
        return None

    @property
    def st_fmt(self):
        e = self._get_unix_extension()
        if e is not None:
            return stat.S_IFMT(e)
        return None


class ArchiveFileList:

    def __init__(self, offset=0):
        self.files_list = []
        self.index = 0
        self.offset = offset

    def append(self, file_info):
        self.files_list.append(file_info)

    def __len__(self):
        return len(self.files_list)

    def __iter__(self):
        self.index = 0
        return self

    def __next__(self):
        if self.index == len(self.files_list):
            raise StopIteration
        res = ArchiveFile(self.index + self.offset, self.files_list[self.index])
        self.index += 1
        return res


class ArchiveInfo:

    def __init__(self, filename, size, header_size, method_names, solid, blocks):
        self.filename = filename
        self.size = size
        self.header_size = header_size
        self.method_names = method_names
        self.solid = solid
        self.blocks = blocks


class FileInfo:

    def __init__(self, filename, compressed, uncompressed, archivable, is_directory, creationtime):
        self.filename = filename
        self.compressed = compressed
        self.uncompressed = uncompressed
        self.archivable = archivable
        self.is_directory = is_directory
        self.creationtime = creationtime


class SevenZipFile:

    def __init__(self, file, mode='r', filters=None):
        if mode not in ('r', 'w', 'x', 'a'):
            raise ValueError("ZipFile requires mode 'r', 'w', 'x', or 'a'")
        if isinstance(file, str):
            self._filePassed = False
            self.filename = file
            if mode == 'r':
                self.fp = open(file, 'rb')
            elif mode == 'w':
                self.fp = open(file, 'w+b')
            elif mode == 'x':
                self.fp = open(file, 'x+b')
            elif mode == 'a':
                self.fp = open(file, 'r+b')
            else:
                raise ValueError("File open error.")
            self.mode = mode
        elif isinstance(file, pathlib.Path):
            self._filePassed = False
            self.filename = str(file)
            if mode == 'r':
                self.fp = file.open(mode='rb')
            elif mode == 'w':
                self.fp = file.open(mode='w+b')
            elif mode == 'x':
                self.fp = file.open(mode='x+b')
            elif mode == 'a':
                self.fp = file.open(mode='r+b')
            else:
                raise ValueError("File open error.")
            self.mode = mode
        elif isinstance(file, io.IOBase):
            self._filePassed = True
            self.fp = file
            self.filename = getattr(file, 'name', None)
            self.mode = mode
        else:
            raise TypeError("invalid file: {}".format(type(file)))
        self._fileRefCnt = 1
        self._lock = threading.RLock()
        try:
            if mode == "r":
                self._real_get_contents(self.fp)
                self.reset()
            elif mode in 'w':
                self._write_open()
                self._prepare_write()
            elif mode in 'x':
                raise NotImplementedError
            elif mode == 'a':
                raise NotImplementedError
            else:
                raise ValueError("Mode must be 'r', 'w', 'x', or 'a'")
        except Exception as e:
            self._fpclose()
            raise e

    def _write_open(self):
        self.folder = self._create_folder()
        self.files = ArchiveFileList()

    def _create_folder(self):
        folder = Folder()
        folder.compressor = SevenZipCompressor()
        folder.coders = folder.compressor.coders
        folder.solid = True
        folder.digestdefined = False
        folder.bindpairs = []
        folder.totalin = 1
        folder.totalout = 1
        return folder

    def _fpclose(self):
        assert self._fileRefCnt > 0
        self._fileRefCnt -= 1
        if not self._fileRefCnt and not self._filePassed:
            self.fp.close()

    def _real_get_contents(self, fp):
        if not self._check_7zfile(fp):
            raise Bad7zFile('not a 7z file')
        self.sig_header = SignatureHeader.retrieve(self.fp)
        self.afterheader = self.fp.tell()
        buffer = self._read_header_data()
        header = Header.retrieve(self.fp, buffer, self.afterheader)
        if header is None:
            return
        self.header = header
        buffer.close()
        self.files = ArchiveFileList()
        if getattr(self.header, 'files_info', None) is not None:
            self._filelist_retrieve()

    def _read_header_data(self):
        self.fp.seek(self.sig_header.nextheaderofs, os.SEEK_CUR)
        buffer = io.BytesIO(self.fp.read(self.sig_header.nextheadersize))
        if self.sig_header.nextheadercrc != calculate_crc32(buffer.getvalue()):
            raise Bad7zFile('invalid header data')
        return buffer

    class ParseStatus:
        def __init__(self, src_pos=0):
            self.src_pos = src_pos
            self.folder = 0
            self.outstreams = 0
            self.input = 0
            self.stream = 0

    def _gen_filename(self):
        try:
            basefilename = self.filename
        except AttributeError:
            return 'contents'
        else:
            if basefilename is not None:
                fn, ext = os.path.splitext(os.path.basename(basefilename))
                return fn
            else:
                return 'contents'

    def _get_fileinfo_sizes(self, pstat, subinfo, packinfo, folder, packsizes, unpacksizes, file_in_solid, numinstreams):
        if pstat.input == 0:
            folder.solid = subinfo.num_unpackstreams_folders[pstat.folder] > 1
        maxsize = (folder.solid and packinfo.packsizes[pstat.stream]) or None
        uncompressed = unpacksizes[pstat.outstreams]
        if not isinstance(uncompressed, (list, tuple)):
            uncompressed = [uncompressed] * len(folder.coders)
        if file_in_solid > 0:
            compressed = None
        elif pstat.stream < len(packsizes):
            compressed = packsizes[pstat.stream]
        else:
            compressed = uncompressed
        packsize = packsizes[pstat.stream:pstat.stream + numinstreams]
        return maxsize, compressed, uncompressed, packsize, folder.solid

    def _filelist_retrieve(self):
        if hasattr(self.header, 'main_streams'):
            folders = self.header.main_streams.unpackinfo.folders
            packinfo = self.header.main_streams.packinfo
            subinfo = self.header.main_streams.substreamsinfo
            packsizes = packinfo.packsizes
            unpacksizes = subinfo.unpacksizes if subinfo.unpacksizes is not None else [x.unpacksizes for x in folders]
        else:
            subinfo = None
            folders = None
            packinfo = None
            packsizes = []
            unpacksizes = [0]

        pstat = self.ParseStatus()
        pstat.src_pos = self.afterheader
        file_in_solid = 0

        for file_id, file_info in enumerate(self.header.files_info.files):
            if not file_info['emptystream'] and folders is not None:
                folder = folders[pstat.folder]
                numinstreams = max([coder.get('numinstreams', 1) for coder in folder.coders])
                (maxsize, compressed, uncompressed,
                 packsize, solid) = self._get_fileinfo_sizes(pstat, subinfo, packinfo, folder, packsizes,
                                                             unpacksizes, file_in_solid, numinstreams)
                pstat.input += 1
                folder.solid = solid
                file_info['folder'] = folder
                file_info['maxsize'] = maxsize
                file_info['compressed'] = compressed
                file_info['uncompressed'] = uncompressed
                file_info['packsizes'] = packsize
                if subinfo.digestsdefined[pstat.outstreams]:
                    file_info['digest'] = subinfo.digests[pstat.outstreams]
                if folder is None:
                    pstat.src_pos += file_info['compressed']
                else:
                    if folder.solid:
                        file_in_solid += 1
                    pstat.outstreams += 1
                    if folder.files is None:
                        folder.files = ArchiveFileList(offset=file_id)
                    folder.files.append(file_info)
                    if pstat.input >= subinfo.num_unpackstreams_folders[pstat.folder]:
                        file_in_solid = 0
                        pstat.src_pos += sum(packinfo.packsizes[pstat.stream:pstat.stream + numinstreams])
                        pstat.folder += 1
                        pstat.stream += numinstreams
                        pstat.input = 0
            else:
                file_info['folder'] = None
                file_info['maxsize'] = 0
                file_info['compressed'] = 0
                file_info['uncompressed'] = [0]
                file_info['packsizes'] = [0]

            if 'filename' not in file_info:
                file_info['filename'] = self._gen_filename()
            self.files.append(file_info)

    def _num_files(self):
        if getattr(self.header, 'files_info', None) is not None:
            return len(self.header.files_info.files)
        return 0

    def _set_file_property(self, outfilename, properties):
        creationtime = ArchiveTimestamp(properties['lastwritetime']).totimestamp()
        if creationtime is not None:
            os.utime(str(outfilename), times=(creationtime, creationtime))
        if os.name == 'posix':
            st_mode = properties['posix_mode']
            if st_mode is not None:
                outfilename.chmod(st_mode)
                return
        if properties['readonly'] and not properties['is_directory']:
            ro_mask = 0o777 ^ (stat.S_IWRITE | stat.S_IWGRP | stat.S_IWOTH)
            outfilename.chmod(outfilename.stat().st_mode & ro_mask)

    def reset(self):
        self.fp.seek(self.afterheader)
        self.worker = Worker(self.files, self.afterheader, self.header)

    @staticmethod
    def _check_7zfile(fp):
        result = MAGIC_7Z == fp.read(len(MAGIC_7Z))[:len(MAGIC_7Z)]
        fp.seek(-len(MAGIC_7Z), 1)
        return result

    def _get_method_names(self):
        methods_names = []
        for folder in self.header.main_streams.unpackinfo.folders:
            methods_names += get_methods_names(folder.coders)
        return ', '.join(x for x in methods_names)

    def _test_digest_raw(self, pos, size, crc):
        self.fp.seek(pos)
        remaining_size = size
        digest = None
        while remaining_size > 0:
            block = min(Configuration.read_blocksize, remaining_size)
            digest = calculate_crc32(self.fp.read(block), digest)
            remaining_size -= block
        return digest == crc

    def _test_pack_digest(self):
        self.reset()
        crcs = self.header.main_streams.packinfo.crcs
        if crcs is not None and len(crcs) > 0:
            for i, p in enumerate(self.header.main_streams.packinfo.packpositions):
                if not self._test_digest_raw(p, self.header.main_streams.packinfo.packsizes[i], crcs[i]):
                    return False
        return True

    def _test_unpack_digest(self):
        self.reset()
        for f in self.files:
            self.worker.register_filelike(f.id, None)
        try:
            self.worker.extract(self.fp)
        except Bad7zFile:
            return False
        else:
            return True

    def _test_digests(self):
        if self._test_pack_digest():
            if self._test_unpack_digest():
                return True
        return False

    def _prepare_write(self):
        self.sig_header = SignatureHeader()
        self.sig_header._write_skelton(self.fp)
        self.afterheader = self.fp.tell()
        self.header = Header()
        self.folder.totalin = 1
        self.folder.totalout = 1
        self.folder.bindpairs = []
        self.folder.unpacksizes = []
        self.header.build_header([self.folder])

    def _write_archive(self):
        compressor = self.folder.get_compressor()
        outsize = 0
        self.header.main_streams.packinfo.numstreams = 1
        num_unpack_streams = 0
        self.header.main_streams.substreamsinfo.digests = []
        self.header.main_streams.substreamsinfo.digestsdefined = []
        last_file_index = 0
        foutsize = 0
        for i, f in enumerate(self.files):
            file_info = f.file_properties()
            self.header.files_info.files.append(file_info)
            self.header.files_info.emptyfiles.append(f.emptystream)
            foutsize = 0
            if not f.emptystream:
                last_file_index = i
                num_unpack_streams += 1
                insize = 0
                with pathlib.Path(f.origin).open(mode='rb') as fd:
                    data = fd.read(Configuration.read_blocksize)
                    insize += len(data)
                    crc = 0
                    while data:
                        crc = calculate_crc32(data, crc)
                        out = compressor.compress(data)
                        outsize += len(out)
                        foutsize += len(out)
                        self.fp.write(out)
                        data = fd.read(Configuration.read_blocksize)
                        insize += len(data)
                    self.header.main_streams.substreamsinfo.digests.append(crc)
                    self.header.main_streams.substreamsinfo.digestsdefined.append(True)
                    self.header.files_info.files[i]['maxsize'] = foutsize
                self.header.main_streams.substreamsinfo.unpacksizes.append(insize)
        else:
            out = compressor.flush()
            outsize += len(out)
            foutsize += len(out)
            self.fp.write(out)
            if len(self.files) > 0:
                self.header.files_info.files[last_file_index]['maxsize'] = foutsize
        pos = self.fp.tell()
        self.header.main_streams.packinfo.packsizes = [outsize]
        self.folder.unpacksizes = [sum(self.header.main_streams.substreamsinfo.unpacksizes)]
        self.header.main_streams.substreamsinfo.num_unpackstreams_folders = [num_unpack_streams]
        self.sig_header.nextheaderofs = pos - self.afterheader
        encoded_header = False
        self.header.write(self.fp, encoded=encoded_header)
        buf = io.BytesIO()
        self.header.write(buf, encoded=encoded_header)
        data = buf.getvalue()
        self.sig_header.calccrc(data)
        self.sig_header.write(self.fp)

    def _is_solid(self):
        return self.header.main_streams.packinfo.numstreams == 1

    @staticmethod
    def _make_file_info(target, arcname=None):
        f = {}
        f['origin'] = target
        if arcname is not None:
            f['filename'] = arcname
        else:
            f['filename'] = str(target)
        fstat = target.stat()
        if target.is_dir():
            f['emptystream'] = True
            f['attributes'] = stat.FILE_ATTRIBUTE_DIRECTORY
            if os.name == 'posix':
                f['attributes'] |= FILE_ATTRIBUTE_UNIX_EXTENSION | (stat.S_IFDIR << 16)
        elif target.is_symlink():
            f['emptystream'] = True
            if os.name == 'posix':
                f['attributes'] = FILE_ATTRIBUTE_UNIX_EXTENSION | (stat.S_IFLNK << 16)
            else:
                f['attributes'] = 0x0
        elif target.is_file():
            f['emptystream'] = False
            f['attributes'] = stat.FILE_ATTRIBUTE_ARCHIVE
            f['uncompressed'] = fstat.st_size
        if os.name == 'posix':
            f['attributes'] |= FILE_ATTRIBUTE_UNIX_EXTENSION | (stat.S_IMODE(fstat.st_mode) << 16)
        elif os.name == 'nt':
            f['attributes'] |= (fstat.st_file_attributes & FILE_ATTRIBUTE_WINDOWS_MASK)
        f['creationtime'] = target.stat().st_ctime
        f['lastwritetime'] = target.stat().st_mtime
        f['lastaccesstime'] = target.stat().st_atime
        return f

    def getnames(self):
        return list(map(lambda x: x.filename, self.files))

    def archiveinfo(self):
        fstat = os.stat(self.filename)
        return ArchiveInfo(self.filename, fstat.st_size, self.header.size, self._get_method_names(),
                           self._is_solid(), len(self.header.main_streams.unpackinfo.folders))

    def list(self):
        alist = []
        creationtime = None
        for f in self.files:
            if f.lastwritetime is not None:
                creationtime = filetime_to_dt(f.lastwritetime)
            alist.append(FileInfo(f.filename, f.compressed, f.uncompressed_size, f.archivable, f.is_directory,
                                  creationtime))
        return alist

    def test(self):
        return self._test_digests()

    def extractall(self, path=None):
        target_sym = []
        target_files = []
        target_dirs = []
        self.reset()
        if path is not None:
            if isinstance(path, str):
                path = pathlib.Path(path)
            try:
                if not path.exists():
                    path.mkdir(parents=True)
                else:
                    pass
            except OSError as e:
                if e.errno == errno.EEXIST and path.is_dir():
                    pass
                else:
                    raise e

        multi_thread = self.header.main_streams.unpackinfo.numfolders > 1 and \
            self.header.main_streams.packinfo.numstreams == self.header.main_streams.unpackinfo.numfolders
        fnames = []
        for f in self.files:
            if f.filename.startswith('../'):
                raise Bad7zFile
            if f.filename in fnames:
                multi_thread = False
            fnames.append(f.filename)
            if path is not None:
                outfilename = path.joinpath(f.filename)
            else:
                outfilename = pathlib.Path(f.filename)
            if f.is_directory:
                if not outfilename.exists():
                    target_dirs.append(outfilename)
                    target_files.append((outfilename, f.file_properties()))
                else:
                    pass
            elif f.is_socket:
                pass
            elif f.is_symlink:
                buf = io.BytesIO()
                pair = (buf, f.filename)
                target_sym.append(pair)
                self.worker.register_filelike(f.id, buf)
            else:
                self.worker.register_filelike(f.id, outfilename)
                target_files.append((outfilename, f.file_properties()))
        for target_dir in sorted(target_dirs):
            try:
                target_dir.mkdir()
            except FileExistsError:
                if target_dir.is_dir():
                    pass
                elif target_dir.is_file():
                    raise Exception("Directory name is existed as a normal file.")
                else:
                    raise Exception("Directory making fails on unknown condition.")
        self.worker.extract(self.fp, multithread=multi_thread)
        for b, t in target_sym:
            b.seek(0)
            sym_src_org = b.read().decode(encoding='utf-8')
            dirname = os.path.dirname(t)
            if path:
                sym_src = path.joinpath(dirname, sym_src_org)
                sym_dst = path.joinpath(t)
            else:
                sym_src = pathlib.Path(dirname).joinpath(sym_src_org)
                sym_dst = pathlib.Path(t)
            sym_dst.symlink_to(sym_src)
        for o, p in target_files:
            self._set_file_property(o, p)

    def writeall(self, path, arcname=None):
        if isinstance(path, str):
            path = pathlib.Path(path)
        if path.is_file():
            self.write(path, arcname)
        elif path.is_dir():
            if not path.samefile('.'):
                self.write(path, arcname)
            for nm in sorted(os.listdir(str(path))):
                arc = os.path.join(arcname, nm) if arcname is not None else None
                self.writeall(path.joinpath(nm), arc)

    def write(self, file, arcname=None):
        if isinstance(file, str):
            path = pathlib.Path(file)
        elif isinstance(file, pathlib.Path):
            path = file
        else:
            raise ValueError("Unsupported file type.")
        file_info = self._make_file_info(path, arcname)
        self.files.append(file_info)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def close(self):
        if 'w' in self.mode:
            self._write_archive()
        self._fpclose()


def is_7zfile(file):
    result = False
    try:
        if isinstance(file, io.IOBase) and hasattr(file, "read"):
            result = SevenZipFile._check_7zfile(file)
        elif isinstance(file, str):
            with open(file, 'rb') as fp:
                result = SevenZipFile._check_7zfile(fp)
        elif isinstance(file, pathlib.Path):
            with file.open(mode='rb') as fp:
                result = SevenZipFile._check_7zfile(fp)
        else:
            raise TypeError('invalid type: file should be str, pathlib.Path or BinaryIO, but {}'.format(type(file)))
    except OSError:
        pass
    return result


def unpack_7zarchive(archive, path, extra=None):
    arc = SevenZipFile(archive)
    arc.extractall(path)
    arc.close()
