import sys
import os
import json
import xbmc
import xbmcgui
import xbmcplugin
from urllib.parse import unquote_plus, quote_plus
from resources.lib import log
from resources.lib.control import getSetting, addonProfile, syshandle, get_video_tag
from resources.lib.db import bookmark, playcount

_VIDEODB = {
    22: 'MyVideos141.db',
    21: 'MyVideos131.db',
    20: 'MyVideos121.db',
}


def _kodi_ver():
    return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])


def _videodb_path():
    db = _VIDEODB.get(_kodi_ver(), 'MyVideos141.db')
    return os.path.join(xbmc.translatePath('special://database/'), db)


def _make_listitem(title, url, meta, drm_info=None):
    li = xbmcgui.ListItem(label=title)
    li.setProperty('IsPlayable', 'true')
    li.setInfo('video', {'title': title, 'mediatype': meta.get('mediatype', 'video')})
    if meta.get('poster'):
        li.setArt({'poster': meta['poster'], 'thumb': meta['poster']})
    plot = unquote_plus(str(meta.get('plot', ''))) if '%' in str(meta.get('plot', '')) else str(meta.get('plot', ''))
    tag, _shim = get_video_tag(li)
    tag.setTitle(title)
    tag.setPlot(plot)
    if _shim: tag.flush()

    clean_url = url.split('|')[0] if '|' in url else url
    is_hls    = any(x in clean_url.lower() for x in ('.m3u8', '/hls/', 'master.m3u8'))
    is_dash   = '.mpd' in clean_url.lower()

    if (is_hls or is_dash) and '|' in url:
        headers_str = url.split('|', 1)[1]
        headers     = {}
        for part in headers_str.split('&'):
            if '=' in part:
                k, v = part.split('=', 1)
                if k.lower() != 'verifypeer':
                    headers[k] = v
        li.setPath(clean_url)
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'mpd' if is_dash else 'hls')
        if headers:
            enc = '&'.join('%s=%s' % (k, quote_plus(v)) for k, v in headers.items())
            li.setProperty('inputstream.adaptive.manifest_headers', enc)
            li.setProperty('inputstream.adaptive.stream_headers', enc)
        li.setMimeType('application/dash+xml' if is_dash else 'application/vnd.apple.mpegurl')
        li.setContentLookup(False)
    elif is_dash:
        li.setPath(clean_url)
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        li.setMimeType('application/dash+xml')
        li.setContentLookup(False)
    else:
        if getSetting('verify.peer') == 'true' and '&verifypeer=false' not in url:
            url += '&verifypeer=false'
        li.setPath(url)

    if drm_info and (is_dash or '.mpd' in clean_url.lower()):
        try:
            import inputstreamhelper
            is_helper = inputstreamhelper.Helper('mpd', drm='com.widevine.alpha')
            if is_helper.check_inputstream():
                li.setContentLookup(False)
                li.setMimeType('application/dash+xml')
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
                li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                license_key = drm_info.get('license_key', '')
                license_url = drm_info.get('drm_license', '')
                if license_key:
                    li.setProperty('inputstream.adaptive.license_key', license_key)
                elif license_url:
                    li.setProperty(
                        'inputstream.adaptive.license_key',
                        '%s|Content-Type=application%%2Foctet-stream|R{SSM}|' % license_url
                    )
                if drm_info.get('is_live'):
                    li.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
        except Exception:
            log.error()

    return li, url


_AUTOPLAY_THRESHOLD = 10


class Player(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.finished       = False
        self.total_time     = 0
        self.current_time   = 0
        self.name           = ''
        self.meta           = {}
        self.offset         = 0.0
        self._paused        = False
        self._fallback_hosters  = []
        self._fallback_index    = 0
        self._fallback_resolve  = None
        self._fallback_handle   = None
        self._autoplay_aborted  = False
        self._drm_info          = {}
        self._user_stopped      = False

    def set_fallback(self, hosters, start_index, resolve_fn, handle=None):
        self._fallback_hosters = hosters
        self._fallback_index   = start_index
        self._fallback_resolve = resolve_fn
        self._fallback_handle  = handle

    def run(self, title, url, meta, drm_info=None):
        self.meta     = meta if isinstance(meta, dict) else {}
        self.name     = title
        self.offset   = bookmark.get(title)
        self._drm_info = drm_info or {}
        li, resolved_url = _make_listitem(title, url, self.meta, drm_info=self._drm_info)
        xbmc.Player().play(resolved_url, li)
        self._monitor()
        return not self._autoplay_aborted and self.current_time > 0

    # ── Kodi playback callbacks ──────────────────────────────────────────────

    def onPlayBackPaused(self):
        self._paused = True
        try:
            pct = (self.current_time / self.total_time * 100) if self.total_time > 0 else 0.0
            from resources.lib import trakt
            trakt.scrobble_pause(self.meta, pct)
        except Exception:
            log.error()

    def onPlayBackStopped(self):
        self._user_stopped = True

    def onPlayBackResumed(self):
        self._paused = False
        try:
            pct = (self.current_time / self.total_time * 100) if self.total_time > 0 else 0.0
            from resources.lib import trakt
            trakt.scrobble_start(self.meta, pct)
        except Exception:
            log.error()

    # ── Monitor loop ─────────────────────────────────────────────────────────

    def _try_next_fallback(self):
        while self._fallback_index < len(self._fallback_hosters):
            h = self._fallback_hosters[self._fallback_index]
            self._fallback_index += 1
            try:
                url      = h[1]
                drm_info = h[2] if (len(h) > 2 and isinstance(h[2], dict)) else {}
                is_resolved = bool(drm_info) or (
                    h[2] if (len(h) > 2 and not isinstance(h[2], dict)) else False
                )
                if not is_resolved and self._fallback_resolve:
                    url = self._fallback_resolve(url)
                if not url:
                    continue
                log.log('[Player] Autoplay-Next: versuche Hoster %d – %s' % (self._fallback_index, h[0]))
                self._drm_info = drm_info
                li, resolved_url = _make_listitem(self.name, url, self.meta, drm_info=drm_info)
                xbmc.Player().play(resolved_url, li)
                return True
            except Exception:
                log.error()
        return False

    def _monitor(self):
        timeout = 0
        while not self.isPlaying() and timeout < 20:
            xbmc.sleep(500)
            timeout += 1
        if not self.isPlaying():
            if self._fallback_hosters and self._fallback_index < len(self._fallback_hosters):
                log.log('[Player] Autoplay-Next: Start fehlgeschlagen, nächster Hoster wird versucht')
                if self._try_next_fallback():
                    self._monitor()
            return

        # Seek to bookmark if applicable
        if self.offset > 60:
            d = xbmcgui.Dialog()
            choice = d.yesno(
                self.name,
                'Fortsetzen bei %s?' % xbmc.getInfoLabel('Slideshow.BitRate'),
                nolabel='Von vorne',
                yeslabel='Fortsetzen'
            )
            if choice:
                self.seekTime(self.offset)

        try:
            self.total_time = self.getTotalTime()
        except Exception:
            self.total_time = 0

        # Trakt: scrobble start
        try:
            from resources.lib import trakt
            trakt.scrobble_start(self.meta, 0.0)
        except Exception:
            log.error()

        _trakt_update_interval = 0
        _early_stop_checked    = False
        while self.isPlaying():
            try:
                self.current_time = self.getTime()
            except Exception:
                pass
            xbmc.sleep(2000)

            if not _early_stop_checked and self.current_time >= _AUTOPLAY_THRESHOLD:
                _early_stop_checked = True

            _trakt_update_interval += 1
            if _trakt_update_interval >= 150 and not self._paused:   # 150 × 2s = 300s
                _trakt_update_interval = 0
                try:
                    pct = (self.current_time / self.total_time * 100) if self.total_time > 0 else 0.0
                    from resources.lib import trakt
                    trakt.scrobble_start(self.meta, pct)
                except Exception:
                    pass

        if (not _early_stop_checked
                and not self._user_stopped
                and self._fallback_hosters
                and self._fallback_index < len(self._fallback_hosters)):
            log.log('[Player] Autoplay-Next: Stream abgebrochen vor %ds, nächster Hoster wird versucht' % _AUTOPLAY_THRESHOLD)
            self._autoplay_aborted = True
            if self._try_next_fallback():
                self._monitor()
            return

        self._on_stop()

    # ── On stop ──────────────────────────────────────────────────────────────

    def _on_stop(self):
        pct = 0.0
        if self.total_time > 0 and self.current_time > 0:
            pct = (self.current_time / self.total_time) * 100.0

        # Trakt scrobble stop (marks watched on Trakt if pct >= 80)
        try:
            from resources.lib import trakt
            trakt.scrobble_stop(self.meta, pct)
        except Exception:
            log.error()

        if self.total_time > 0 and self.current_time > 0:
            ratio = self.current_time / self.total_time
            if ratio > 0.9:
                bookmark.delete(self.name)
                mt    = self.meta.get('mediatype', 'movie')
                title = self.meta.get('title', self.name)
                imdb  = self.meta.get('imdb_id', '')
                s     = int(self.meta.get('season', 0))
                e     = int(self.meta.get('episode', 0))
                playcount.set(mt, title, imdb, s, e, 1)
                log.log('Gesehen markiert: %s' % title)
            elif self.current_time > 120:
                bookmark.set(self.name, self.current_time)
                log.log('Lesezeichen gesetzt bei %.0fs: %s' % (self.current_time, self.name))


def play_url(handle, title, url, meta):
    li, resolved_url = _make_listitem(title, url, meta)
    xbmcplugin.setResolvedUrl(handle, True, li)


def resolve_and_play(title, url, meta, handle=None):
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url=url, include_disabled=False, include_universal=False)
        if hmf.valid_url():
            url = hmf.resolve()
    except Exception:
        pass
    if handle is not None:
        play_url(handle, title, url, meta)
    else:
        p = Player()
        p.run(title, url, meta)
