import xbmcgui
import xbmcplugin
from urllib.parse import unquote_plus
from resources.lib import log, remote
from resources.lib.control import (
    syshandle, sysaddon, infoDialog, addonName, execute,
    directory, keyboard, dialog_ok
)


def scraper_update(force=False):
    handle = syshandle()
    dp = xbmcgui.DialogProgress()
    dp.create(addonName(), 'Remote-Scraper werden aktualisiert...')
    dp.update(0, 'Starte Update...')

    def _progress(pct, label):
        if dp.iscanceled():
            return
        dp.update(pct, label)

    try:
        if force:
            dp.update(0, 'Cache wird geleert...')
            remote.clear_cache()
        remote.update_all(force=force, progress_callback=_progress)
        remote._MODULE_CACHE.clear()
        dp.update(100, 'Abgeschlossen.')
        infoDialog('Scraper-Update abgeschlossen.')
    except Exception:
        log.error()
        infoDialog('Fehler beim Update.', icon='ERROR')
    dp.close()
    execute('Container.Refresh')
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


def scraper_enable_all():
    remote.enable_all()
    infoDialog('Alle Scraper aktiviert.')
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def scraper_disable_all():
    confirmed = xbmcgui.Dialog().yesno(addonName(), 'Alle Scraper deaktivieren?')
    if confirmed:
        remote.disable_all()
        infoDialog('Alle Scraper deaktiviert.')
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def scraper_enable(params):
    name = params.get('name', '')
    remote.enable_scraper(name)
    infoDialog('%s aktiviert.' % name)
    execute('Container.Refresh')
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def scraper_disable(params):
    name = params.get('name', '')
    remote.disable_scraper(name)
    infoDialog('%s deaktiviert.' % name)
    execute('Container.Refresh')
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def scraper_clear_cache():
    confirmed = xbmcgui.Dialog().yesno(addonName(), 'Scraper-Cache löschen?')
    if confirmed:
        remote.clear_cache()
        infoDialog('Cache gelöscht.')
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def resolver_update():
    handle = syshandle()
    try:
        from resources.lib.remote import update_resolveurl
        result = update_resolveurl(silent=False)
        if result is None:
            infoDialog('ResolveURL ist bereits aktuell.')
        elif result is False:
            infoDialog('ResolveURL Update fehlgeschlagen.', icon='ERROR')
        # True: Notification wird bereits in update_resolveurl() angezeigt
    except Exception:
        log.error()
        infoDialog('Fehler beim ResolveURL Update.', icon='ERROR')
    xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)


def resolver_settings():
    try:
        import resolveurl
        resolveurl.display_settings()
    except Exception:
        log.error()
        infoDialog('ResolveURL nicht gefunden.', icon='ERROR')
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def addon_settings():
    execute('Addon.OpenSettings(plugin.video.moviescout)')
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def reset_settings():
    confirmed = xbmcgui.Dialog().yesno(addonName(), 'Einstellungen zurücksetzen?')
    if confirmed:
        from resources.lib.control import addon
        a = addon()
        for key in ('scout.enable', 'browse.enable', 'scout.hosts_mode',
                    'fanart.enable', 'verify.peer', 'remote.enable',
                    'remote.cache_hours', 'remote.base_url'):
            try:
                a.setSetting(key, '')
            except Exception:
                pass
        infoDialog('Einstellungen zurückgesetzt.')
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def play_url_dialog():
    handle = syshandle()
    kb = keyboard('', 'URL eingeben')
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    url = kb.getText().strip()
    if not url:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url=url, include_disabled=False, include_universal=False)
        if hmf.valid_url():
            url = hmf.resolve()
    except Exception:
        pass
    li = xbmcgui.ListItem(label='URL')
    li.setProperty('IsPlayable', 'true')
    li.setPath(url)
    xbmcplugin.setResolvedUrl(handle, True, li)


def mark_watched(params):
    from resources.lib.db import playcount as pcdb
    mt      = params.get('mt', 'episode')
    title   = unquote_plus(params.get('title', ''))
    season  = int(params.get('season', 0))
    episode = int(params.get('ep', 0))
    pcdb.set(mt, title, season=season, episode=episode, playcount=1)
    infoDialog('Gesehen: %s' % title)
    execute('Container.Refresh')
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def mark_unwatched(params):
    from resources.lib.db import playcount as pcdb
    mt      = params.get('mt', 'episode')
    title   = unquote_plus(params.get('title', ''))
    season  = int(params.get('season', 0))
    episode = int(params.get('ep', 0))
    pcdb.set(mt, title, season=season, episode=episode, playcount=0)
    infoDialog('Ungesehen: %s' % title)
    execute('Container.Refresh')
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def download(params):
    from resources.lib import downloader
    title = unquote_plus(params.get('title', 'Download'))
    url   = unquote_plus(params.get('url', ''))
    mt    = params.get('mt', 'movie')
    if url:
        downloader.download(title, url, mt)
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def search_del_entry(params):
    from resources.lib.db import search as sdb
    sdb.remove(int(params.get('id', 0)))
    execute('Container.Refresh')
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def search_clear_all(params):
    from resources.lib.db import search as sdb
    sdb.remove_all(params.get('table', 'global'))
    execute('Container.Refresh')
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)


def no_action():
    xbmcplugin.endOfDirectory(syshandle(), succeeded=False, cacheToDisc=False)
