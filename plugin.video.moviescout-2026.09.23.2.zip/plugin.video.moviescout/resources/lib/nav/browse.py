import json
import xbmcgui
import xbmcplugin
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote_plus, unquote_plus, urlparse as _urlparse
from resources.lib import log, remote
from resources.lib.control import (
    sysaddon, syshandle, addonPoster, addonFanart,
    addItem, content, directory, plugincategory,
    infoDialog, keyboard, dialog_select, dialog_ok, getSetting, get_video_tag
)

_ITEM_DEFAULTS = {
    'title':       '',
    'year':        '',
    'url':         '',
    'poster':      '',
    'plot':        '',
    'mediatype':   'movie',
    'is_playable': False,
    'next_func':   'load',
    'season':      0,
    'episode':     0,
    'is_future':   False,
}


def _merge(item):
    d = dict(_ITEM_DEFAULTS)
    d.update(item)
    return d


def _build_item_li(item, addon, site_id, parent_url=''):
    d    = _merge(item)
    label = str(d['title'])
    if d.get('year'):
        label = '%s (%s)' % (label, d['year'])
    if d.get('is_future'):
        label = '[COLOR red][I]%s[/I][/COLOR]' % label

    li     = xbmcgui.ListItem(label=label)
    poster = d.get('poster') or addonPoster()
    fanart = d.get('fanart', '') or addonFanart()
    li.setArt({'thumb': poster, 'poster': poster, 'fanart': fanart})

    tag, _shim = get_video_tag(li)
    tag.setTitle(str(d['title']))
    if d.get('plot'):   tag.setPlot(str(d['plot']))
    if d.get('year'):   tag.setYear(int(d['year']))
    if d.get('rating'): tag.setRating(float(d['rating']))
    if _shim: tag.flush()

    extra = {'season': d['season'], 'episode': d['episode']}

    if d['is_playable'] or d['next_func'] == 'get_hosters':
        li.setIsFolder(True)
        url = '%s?action=browseHosterList&site=%s&url=%s&extra=%s' % (
            addon, site_id, quote_plus(d['url']), quote_plus(json.dumps(extra)))
        cm = [('Download', 'RunPlugin(%s?action=download&title=%s&url=%s&mt=%s)' % (
            addon, quote_plus(d['title']), quote_plus(d['url']), d.get('mediatype', 'movie')))]
        li.addContextMenuItems(cm)
        return url, li, True

    li.setIsFolder(True)
    params = json.dumps({'season': d['season'], 'episode': d['episode']})
    url = '%s?action=browseNav&site=%s&func=%s&url=%s&params=%s' % (
        addon, site_id, d['next_func'], quote_plus(d['url']), quote_plus(params))
    return url, li, True


def show_root():
    handle  = syshandle()
    addon   = sysaddon()
    scrapers= remote.get_browse_scrapers()

    if not scrapers:
        infoDialog('Keine Browse-Scraper verfuegbar. Remote-Update durchfuehren.', icon='WARNING')
        directory(handle, succeeded=False)
        return

    xbmcplugin.setContent(handle, 'files')
    plugincategory(handle, 'Browse - Sites')

    for s_info, module in scrapers:
        site_id   = s_info.get('name', '')
        site_name = getattr(module, 'SITE_NAME', site_id)
        domain    = s_info.get('domain', '')
        label = ('[B]%s[/B]  [COLOR gray](%s)[/COLOR]' % (site_name, domain)) if domain else ('[B]%s[/B]' % site_name)
        li = xbmcgui.ListItem(label=label)
        li.setIsFolder(True)
        li.setArt({'thumb': addonPoster(), 'fanart': addonFanart()})
        tag, _shim = get_video_tag(li)
        tag.setTitle(site_name)
        tag.setPlot(domain)
        if _shim: tag.flush()
        url = '%s?action=browseNav&site=%s&func=load&url=&params=%s' % (
            addon, site_id, quote_plus('{}'))
        addItem(handle, url, li, True)

    directory(handle, cacheToDisc=False)


def navigate(params):
    handle  = syshandle()
    addon   = sysaddon()
    site_id = params.get('site', '')
    func    = params.get('func', 'load')
    url     = unquote_plus(params.get('url', ''))
    extra   = {}
    try:
        extra = json.loads(unquote_plus(params.get('params', '{}')))
    except Exception:
        pass

    _, module = _get_module(site_id)
    if not module:
        infoDialog('Scraper nicht gefunden: %s' % site_id, icon='ERROR')
        directory(handle, succeeded=False)
        return

    fn = getattr(module, func, None) or getattr(module, 'load', None)
    if not fn:
        directory(handle, succeeded=False)
        return

    try:
        items = fn(url=url, params=extra) if url or extra else fn()
    except Exception:
        log.error()
        directory(handle, succeeded=False)
        return

    if not items:
        infoDialog('Keine Eintraege von: %s' % site_id, icon='WARNING')
        directory(handle, succeeded=False)
        return

    get_details_fn = getattr(module, 'get_details', None)
    if get_details_fn:
        playable = [i for i in items if i.get('url') and not i.get('plot') and (i.get('is_playable') or i.get('mediatype') in ('tvshow', 'season', 'episode', 'movie'))]
        if playable:
            details_map = {}
            def _fetch_detail(item):
                try:
                    return item['url'], get_details_fn(url=item['url'])
                except Exception:
                    return item['url'], {}
            with ThreadPoolExecutor(max_workers=12) as ex:
                futures = {ex.submit(_fetch_detail, i): i for i in playable}
                for f in as_completed(futures):
                    try:
                        item_url, detail = f.result(timeout=15)
                        if detail:
                            details_map[item_url] = detail
                    except Exception:
                        pass
            for item in items:
                if item.get('url') in details_map:
                    d = details_map[item['url']]
                    for k, v in d.items():
                        if k not in item or not item[k]:
                            item[k] = v

    xbmcplugin.setContent(handle, 'movies')
    site_name = getattr(module, 'SITE_NAME', site_id)
    plugincategory(handle, site_name)

    for item in items:
        try:
            url_item, li, is_folder = _build_item_li(item, addon, site_id)
            addItem(handle, url_item, li, is_folder)
        except Exception:
            log.error()

    directory(handle)


def show_hosters(params):
    show_hosters_list(params)


def show_hosters_list(params):
    handle  = syshandle()
    addon   = sysaddon()
    site_id = params.get('site', '')
    url     = unquote_plus(params.get('url', ''))
    extra   = {}
    try:
        extra = json.loads(unquote_plus(params.get('extra', '{}')))
    except Exception:
        pass

    _, module = _get_module(site_id)
    if not module or not hasattr(module, 'get_hosters'):
        directory(handle, succeeded=False)
        return

    try:
        hosters = module.get_hosters(url=url, params=extra)
    except Exception:
        log.error()
        directory(handle, succeeded=False)
        return

    if not hosters:
        infoDialog('Keine Streams von: %s' % site_id, icon='WARNING')
        directory(handle, succeeded=False)
        return

    try:
        blocked = remote.get_blocked_hosters()
        if blocked:
            def _is_blocked(h):
                domain = _urlparse(h[1]).netloc.lower() if len(h) > 1 and h[1].startswith('http') else ''
                name_l = h[0].lower() if h else ''
                return domain in blocked or name_l in blocked
            hosters = [h for h in hosters if not _is_blocked(h)]
    except Exception:
        log.error()

    if getSetting('general.german_only') == 'true':
        import re as _re
        _LANG_RE = _re.compile(r'\(([a-zA-Z]{2,3})\)\s*$')
        def _is_german_browse(h):
            lang = (h[4] if len(h) > 4 else '').lower().strip()
            if not lang:
                m = _LANG_RE.search((h[0] if h else '').strip())
                if m:
                    lang = m.group(1).lower()
                else:
                    return True
            return 'de' in lang or 'ger' in lang or 'deutsch' in lang
        hosters = [h for h in hosters if _is_german_browse(h)]
        if not hosters:
            infoDialog('Keine deutschen Streams von: %s' % site_id, icon='WARNING')
            directory(handle, succeeded=False)
            return

    xbmcplugin.setContent(handle, 'movies')
    plugincategory(handle, 'Streams')

    for i, h in enumerate(hosters):
        hname = h[0]
        hurl  = h[1]
        is_resolved = h[2] if len(h) > 2 else False
        quality     = h[3] if len(h) > 3 else ''
        label = '%02d | %s' % (i + 1, hname)
        if quality:
            label = '%s  [COLOR gray][%s][/COLOR]' % (label, quality)
        li = xbmcgui.ListItem(label=label)
        li.setIsFolder(False)
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': label, 'mediatype': 'video'})
        li.setArt({'thumb': addonPoster(), 'fanart': addonFanart()})
        drm_info = h[2] if (len(h) > 2 and isinstance(h[2], dict)) else {}
        resolved_flag = '0' if drm_info else ('1' if is_resolved else '0')
        play_url = '%s?action=browsePlay&site=%s&hname=%s&hurl=%s&resolved=%s&drm=%s' % (
            addon, site_id,
            quote_plus(hname),
            quote_plus(hurl),
            resolved_flag,
            quote_plus(json.dumps(drm_info)) if drm_info else ''
        )
        addItem(handle, play_url, li, False)

    directory(handle, cacheToDisc=False)


def play_hoster(params):
    handle      = syshandle()
    hname       = unquote_plus(params.get('hname', ''))
    hurl        = unquote_plus(params.get('hurl', ''))
    site_id     = params.get('site', '')
    is_resolved = params.get('resolved', '0') == '1'
    drm_info    = {}
    try:
        drm_raw = unquote_plus(params.get('drm', ''))
        if drm_raw:
            drm_info = json.loads(drm_raw)
    except Exception:
        pass
    _resolve_and_play((hname, hurl, is_resolved, drm_info), handle, site_id)


def _parse_pipe_url(raw_url):
    headers = {}
    url = raw_url
    if '|' in raw_url:
        url, header_str = raw_url.split('|', 1)
        from urllib.parse import parse_qs, unquote_plus as _uqp
        for k, v in parse_qs(header_str, keep_blank_values=True).items():
            headers[k] = _uqp(v[0])
    return url, headers


def _resolve_and_play(h, handle, site_id=''):
    hname = h[0]
    hurl  = h[1]
    is_resolved = bool(h[2]) if len(h) > 2 else False
    drm_info = h[3] if len(h) > 3 and isinstance(h[3], dict) else {}

    if not is_resolved and not drm_info:
        try:
            import resolveurl
            hmf = resolveurl.HostedMediaFile(url=hurl, include_disabled=False, include_universal=False)
            if hmf.valid_url():
                resolved = hmf.resolve()
                if resolved and isinstance(resolved, str):
                    hurl = resolved
                    is_resolved = True
        except Exception:
            log.error()
        if not is_resolved:
            try:
                evil = remote.get_evil_resolver()
                if evil:
                    resolved, ok = evil.resolve(hurl)
                    if ok:
                        hurl = resolved
            except Exception:
                log.error()

    url, headers = _parse_pipe_url(hurl)

    if getSetting('debug.url') == 'true':
        dialog_ok('Debug – Player URL', url)

    li = xbmcgui.ListItem(label=hname)
    li.setProperty('IsPlayable', 'true')
    tag, _shim = get_video_tag(li)
    tag.setTitle(hname)
    if _shim: tag.flush()

    url_lower = url.lower()
    use_is = False

    if '.mpd' in url_lower or drm_info:
        try:
            import inputstreamhelper
            is_helper = inputstreamhelper.Helper('mpd', drm='com.widevine.alpha')
            if is_helper.check_inputstream():
                li.setContentLookup(False)
                li.setMimeType('application/dash+xml')
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
                if drm_info:
                    license_key = drm_info.get('license_key', '')
                    license_url = drm_info.get('drm_license', '')
                    cert_url = drm_info.get('drm_certificate', '')
                    li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                    if license_key:
                        li.setProperty('inputstream.adaptive.license_key', license_key)
                    elif license_url:
                        li.setProperty(
                            'inputstream.adaptive.license_key',
                            '%s|Content-Type=application%%2Foctet-stream|R{SSM}|' % license_url
                        )
                    if cert_url:
                        try:
                            import requests as _req, base64 as _b64
                            _r = _req.get(cert_url, timeout=10)
                            _r.raise_for_status()
                            cert_b64 = _b64.b64encode(_r.content).decode('ascii')
                            li.setProperty('inputstream.adaptive.server_certificate', cert_b64)
                        except Exception:
                            log.error()
                if drm_info.get('is_live'):
                    li.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                use_is = True
        except Exception:
            log.error()

    elif '.m3u8' in url_lower:
        try:
            import inputstreamhelper
            is_helper = inputstreamhelper.Helper('hls')
            if is_helper.check_inputstream():
                li.setContentLookup(False)
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
                use_is = True
        except Exception:
            pass

    if use_is and headers:
        header_str = '&'.join('%s=%s' % (k, quote_plus(v)) for k, v in headers.items())
        li.setProperty('inputstream.adaptive.stream_headers', header_str)
        li.setProperty('inputstream.adaptive.manifest_headers', header_str)

    if use_is:
        li.setPath(url)
    elif headers:
        li.setPath(url + '|' + '&'.join('%s=%s' % (k, quote_plus(v)) for k, v in headers.items()))
    else:
        li.setPath(hurl)

    if handle and handle != -1:
        xbmcplugin.setResolvedUrl(handle, bool(url), li)
    else:
        import xbmc
        xbmc.Player().play(li.getPath(), li)


def global_search(params):
    handle  = syshandle()
    addon   = sysaddon()
    query   = params.get('query', '')

    if not query:
        kb = keyboard('', 'Browse Globale Suche')
        kb.doModal()
        if not kb.isConfirmed():
            directory(handle, succeeded=False)
            return
        query = kb.getText().strip()
    if not query:
        directory(handle, succeeded=False)
        return

    scrapers = remote.get_browse_scrapers()
    scrapers_with_search = [(si, m) for si, m in scrapers if hasattr(m, 'search')
                            and getattr(m, 'GLOBAL_SEARCH', False)]
    if not scrapers_with_search:
        infoDialog('Kein Scraper unterstuetzt globale Suche.', icon='WARNING')
        directory(handle, succeeded=False)
        return

    results = []

    def _do_search(site_id, module):
        try:
            return site_id, module.search(query=query)
        except Exception:
            log.error()
            return site_id, []

    with ThreadPoolExecutor(max_workers=12) as ex:
        futures = {ex.submit(_do_search, si['name'], m): si for si, m in scrapers_with_search}
        for f in as_completed(futures):
            try:
                sid, items = f.result(timeout=20)
                for item in (items or []):
                    results.append((sid, item))
            except Exception:
                log.error()

    xbmcplugin.setContent(handle, 'movies')
    plugincategory(handle, 'Browse Suche: %s' % query)

    for site_id, item in results:
        try:
            url_item, li, is_folder = _build_item_li(item, addon, site_id)
            addItem(handle, url_item, li, is_folder)
        except Exception:
            log.error()

    if not results:
        infoDialog('Keine Ergebnisse fuer: %s' % query, icon='INFO')
    directory(handle)


def _get_module(site_id):
    scrapers = remote.get_browse_scrapers()
    for s_info, module in scrapers:
        if s_info.get('name') == site_id:
            return s_info, module
    return None, None
