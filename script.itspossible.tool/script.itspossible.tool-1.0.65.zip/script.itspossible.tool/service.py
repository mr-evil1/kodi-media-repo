import os, sys, runpy

BASE = os.path.dirname(os.path.abspath(__file__))
APPS = os.path.join(BASE, "apps")


def _bootstrap(app):
    """Put the shared shims, the common module and the wanted app on sys.path."""
    for path in (os.path.join(APPS, "shims"),
                 os.path.join(APPS, "module", "resources", "modules"),
                 os.path.join(APPS, app)):
        if path not in sys.path:
            sys.path.insert(0, path)


def run(app, script):
    _bootstrap(app)
    runpy.run_path(os.path.join(APPS, app, script), run_name="__main__")


def _start_scanner():
    """Lauflicht fuer den Ladebildschirm im Hintergrund starten."""
    try:
        import importlib.util

        path = os.path.join(APPS, "scanner", "default.py")
        spec = importlib.util.spec_from_file_location("itspossible_scanner", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.start()
    except Exception:
        pass


def _rows_path(path):
    """Pfad fuer die Reihen der Startseite: Addon-Pfade laufen ueber den
    eigenen Plugin-Pfad, dort werden Ordner ohne Bilder (Genres, Streaming
    Anbieter) nach unten sortiert. Bibliothek und Heim-Eintraege bleiben
    unveraendert."""
    if not path.lower().startswith('plugin://'):
        return path
    try:
        import base64
        encoded = base64.urlsafe_b64encode(path.encode('utf-8'))
        encoded = encoded.decode('ascii').rstrip('=')
    except Exception:
        return path
    return ('plugin://script.itspossible.tool/?action=rows&source=%s' % encoded)


def _start_sidebar():
    """Merkt sich, welcher Menuepunkt oben gewaehlt ist: dessen Inhaltspfad
    (plugin://, library://, videodb://) und seine Art (home / addon / library).
    Daraus baut das Skin das Seitenmenue und entscheidet, ob die Netflix-Ansicht
    gezeigt wird."""
    import re
    import threading

    containers = (971, 900, 972, 960)
    pattern = re.compile(r'(plugin://[^,)"\']+|library://[^,)"\']+|videodb://[^,)"\']+|musicdb://[^,)"\']+)')

    def loop():
        import xbmc
        monitor = xbmc.Monitor()
        last = None
        while not monitor.abortRequested():
            try:
                if xbmc.getCondVisibility('Window.IsActive(home)'):
                    action = ''
                    position = ''
                    menu_name = ''
                    for cid in containers:
                        action = xbmc.getInfoLabel(
                            'Container(%d).ListItem.Property(action)' % cid)
                        if action:
                            position = xbmc.getInfoLabel('Container(%d).Position' % cid)
                            menu_name = xbmc.getInfoLabel(
                                'Container(%d).ListItem.Property(name)' % cid)
                            break
                    if not action:
                        action = xbmc.getInfoLabel('ListItem.Property(action)')

                    if not action:
                        # Der Fokus liegt nicht im oberen Menue (z.B. in einer
                        # Reihe): alten Zustand behalten, sonst springt die
                        # Startseite kurz auf die Ersatzreihen.
                        if monitor.waitForAbort(0.4):
                            break
                        continue

                    found = pattern.search(action or '')
                    path = found.group(1) if found else ''

                    # Art des Menuepunkts bestimmen
                    if path.startswith('plugin://'):
                        kind = 'addon'
                    elif position.isdigit() and position == '0':
                        kind = 'home'
                    elif not action:
                        kind = 'home'
                    elif menu_name in ('itspossible', 'home'):
                        kind = 'home'
                    else:
                        kind = 'library'

                    state = (path, kind)
                    if state != last:
                        last = state
                        try:
                            xbmc.log('[itspossible] Menuepunkt: art=%s pfad=%s'
                                     % (kind, path or '-'), xbmc.LOGINFO)
                        except Exception:
                            pass
                        xbmc.executebuiltin('SetProperty(NFKind,%s,Home)' % kind)
                        if path:
                            xbmc.executebuiltin(
                                'SetProperty(NFPath,%s,Home)'
                                % _rows_path(path).replace(',', ''))
                        else:
                            xbmc.executebuiltin('ClearProperty(NFPath,Home)')
            except Exception:
                pass
            if monitor.waitForAbort(0.4):
                break

    threading.Thread(target=loop, name='itspossible-sidebar', daemon=True).start()


def _start_hero():
    """Waehlt zufaellig einen Eintrag aus dem gerade geoeffneten Addon-Ordner
    und legt ihn als Buehneninhalt ab (Titel, Beschreibung, Bild)."""
    import json
    import random
    import re
    import threading
    import time
    import xbmc
    import xbmcgui

    def clean(value, limit=600):
        """Bereinigt Text fuer Window-Properties: BBCode weg, keine Kommas,
        keine Zeilenumbrueche (Properties enden am Komma)."""
        value = value or ''
        value = re.sub(r'\[/?[^\]]*\]', '', value)
        value = value.replace(',', ' ').replace('[', '').replace(']', '')
        value = value.replace('\n', ' ').replace('\r', ' ')
        text = ' '.join(value.split())
        if len(text) > limit:
            # an der letzten Wortgrenze kuerzen, nicht mitten im Wort
            cut = text[:limit].rsplit(' ', 1)[0]
            text = (cut or text[:limit]).rstrip(' .,;:') + ' \u2026'
        return text.strip()

    # Ersatzbilder, die ein Addon im eigenen Ordner mitbringt
    generic_names = ('icon.png', 'icon.jpg', 'fanart.jpg', 'fanart.png',
                     'poster.jpg', 'poster.png', 'banner.jpg', 'banner.png',
                     'logo.png', 'logo.jpg')

    def is_placeholder(image):
        """Addon-eigene Ersatzbilder (icon.png, fanart.jpg) taugen nicht fuer
        die Buehne: solche Eintraege haben kein echtes Poster/Fanart und
        ueberspringen wir."""
        path = (image or '').split('?')[0].lower()
        # image://<pfad> kommt url-kodiert an (%2f statt /)
        path = path.replace('%2f', '/').replace('%5c', '/')
        path = path.replace('\\', '/').rstrip('/')
        name = path.rsplit('/', 1)[-1]
        if name == 'icon.png':
            return True
        # generische Bilder direkt im Addon-Ordner
        return (name in generic_names
                and ('/addons/' in path or '/addon_data/' in path))

    def unique_images(rows):
        """Gemeinsame Ersatzbilder aussortieren.

        Ein Bild, das bei mehreren Eintraegen auftaucht (z. B. das Fanart des
        Addons), ist kein eigenes Poster. Jeder Eintrag bekommt das erste Bild,
        das nur bei ihm vorkommt - Eintraege ohne eigenes Bild fallen weg."""
        counts = {}
        for row in rows:
            for image in set(row['images']):
                counts[image] = counts.get(image, 0) + 1
        picked = []
        for row in rows:
            row['image'] = next((i for i in row['images'] if counts[i] == 1), '')
            if row['image']:
                picked.append(row)
        return picked

    def from_jsonrpc(path):
        """Buehnenkandidaten direkt aus dem Addon-Ordner holen."""
        request = {
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Files.GetDirectory',
            'params': {
                'directory': path,
                'media': 'video',
                'properties': ['title', 'plot', 'art', 'year', 'genre'],
                'limits': {'end': 120},
            },
        }
        result = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        files = (result.get('result') or {}).get('files') or []
        found = []
        plain = []
        for item in files:
            # Serien sind Ordner (Staffel-/Folgenliste). Reine Menue-Ordner
            # (Genre, Anbieter) haben keinen solchen Link und fallen raus.
            is_dir = item.get('filetype') == 'directory'
            play = item.get('file') or ''
            if is_dir and not is_series_link(play):
                continue
            if is_dir and is_play_link(play):
                continue
            art = item.get('art') or {}
            images = [art.get('fanart'), art.get('landscape'),
                      art.get('thumb'), art.get('poster'),
                      item.get('thumbnail')]
            # Ersatz-Icons (icon.png) und Doppelte raus
            images = [i for i in images
                      if i and not is_placeholder(i)]
            images = list(dict.fromkeys(images))
            title = item.get('title') or item.get('label')
            if title and images:
                genre = item.get('genre') or []
                meta = ' '.join([str(item.get('year') or ''),
                                 '\u00b7', ', '.join(genre[:2])])
                plot = item.get('plot') or ''
                if plot.strip() == title.strip():
                    plot = ''
                entry = {'title': title, 'images': images, 'plot': plot,
                         'meta': meta, 'play': play, 'folder': is_dir}
                # Echte Filme haben eine Beschreibung. Kategorie-Ordner
                # (z. B. Genre "Mystery") haben keine und liefern nur das
                # Addon-Banner als Bild -> taugen nicht fuer die Buehne.
                if plot.strip():
                    found.append(entry)
                else:
                    plain.append(entry)
        picked = unique_images(found) or unique_images(plain)
        return [(r['title'], r['image'], r['plot'], r['meta'], r['play'],
                 r['folder']) for r in picked]

    def from_containers(current_path=''):
        """Fallback: Eintrag direkt aus der sichtbaren Bilderreihe lesen.
        Funktioniert auch dann, wenn das Addon keine JSON-RPC-Liste liefert."""
        row_ids = ['9521', '9522', '9523', '9524', '9525',
                   '9526', '9527', '9528', '9529', '9530', '9531']
        found = []
        for cid in row_ids:
            if not xbmc.getCondVisibility('Control.IsVisible(%s)' % cid):
                continue
            try:
                num = int(xbmc.getInfoLabel(
                    'Container(%s).NumItems' % cid) or 0)
            except Exception:
                num = 0
            for i in range(min(num, 20)):
                base = 'Container(%s).ListItemAbsolute(%d).' % (cid, i)
                title = xbmc.getInfoLabel(base + 'Label')
                images = []
                for key in ('Art(fanart)', 'Art(landscape)', 'Art(thumb)',
                            'Art(poster)', 'Icon'):
                    image = xbmc.getInfoLabel(base + key)
                    if image and not is_placeholder(image) \
                            and image not in images:
                        images.append(image)
                if not title or not images:
                    continue
                meta = ' '.join([xbmc.getInfoLabel(base + 'Year'),
                                 '\u00b7',
                                 xbmc.getInfoLabel(base + 'Genre')])
                plot = xbmc.getInfoLabel(base + 'Plot')
                if plot.strip() == title.strip():
                    plot = ''
                # Ordner sind hier nur dann interessant, wenn es Serien sind
                # (Staffel-/Folgenlink). Menue-Ordner bleiben draussen.
                is_dir = xbmc.getInfoLabel(base + 'IsFolder') == 'true'
                file_path = xbmc.getInfoLabel(base + 'FileNameAndPath')
                folder_path = xbmc.getInfoLabel(base + 'FolderPath')
                if is_dir:
                    # Wie beim Klick auf das Poster unten: der Ordnerpfad
                    # oeffnet die Serie. Ist er leer oder der aktuelle
                    # Menuepfad, dann der volle Eintragspfad.
                    play = folder_path or file_path
                    if play == current_path:
                        play = file_path
                    if not play or not is_series_link(play) \
                            or is_play_link(play):
                        continue
                else:
                    play = file_path or folder_path
                found.append({'title': title, 'images': images, 'plot': plot,
                              'meta': meta, 'play': play, 'folder': is_dir})
        picked = unique_images(found)
        return [(r['title'], r['image'], r['plot'], r['meta'], r['play'],
                 r['folder']) for r in picked]

    def is_play_link(path):
        """Darf NIE als Ordner abgefragt werden: Wiedergabe-Links wie
        ?action=scoutMovie oder direkte Videodateien loesen beim Auflisten
        sofort einen Film aus (MovieScout ruft dabei setResolvedUrl auf)."""
        low = (path or '').lower()
        if not low:
            return False
        markers = ('scoutmovie', 'scoutepisode', 'scoutplay', 'info=play',
                   'action=play')
        if any(marker in low for marker in markers):
            return True
        # Endung nur am Pfadende: "plugin.video.moviescout" enthaelt ".mov"
        suffixes = ('.mp4', '.mkv', '.m3u8', '.avi', '.mov', '.wmv', '.ts',
                    '.flv', '.webm')
        return low.split('?')[0].rstrip('/').endswith(suffixes)

    # Serien sind in den Addons Ordner mit einem Folgen-/Staffel-Link. Filme
    # dagegen haben einen Abspiellink und werden nicht als Ordner gefuehrt.
    series_markers = ('action=seasons', 'action=season', 'action=episodes',
                      'action=episode', 'action=tvshow', 'action=series',
                      'tvshowid=', '/tvshows/')

    def is_series_link(path):
        low = (path or '').lower()
        return any(marker in low for marker in series_markers)

    def tmdb_of(path):
        """TMDB-Nummer aus dem Eintragslink (Serie: tmdb_id=1234)."""
        match = re.search(r'tmdb_id=(\d+)', path or '', re.I)
        return match.group(1) if match else ''

    def type_of(path):
        """Film oder Serie - aus dem Link, nicht aus dem Fokus der Startseite."""
        low = (path or '').lower()
        match = re.search(r'tmdb_type=(tv|movie)', low)
        if match:
            return match.group(1)
        return 'tv' if is_series_link(path) else 'movie'

    def clear_hero():
        for prop in ('NFHeroTitle', 'NFHeroPlot', 'NFHeroPlotLong', 'NFHeroArt',
                     'NFHeroMeta', 'NFHeroPath', 'NFHeroFolder',
                     'NFHeroTMDB', 'NFHeroType'):
            xbmc.executebuiltin('ClearProperty(%s,Home)' % prop)

    def loop():
        monitor = xbmc.Monitor()
        last = None
        tries = 0
        last_action = None
        last_change = 0.0
        while not monitor.abortRequested():
            try:
                # Waehrend ein Dialog offen ist (z. B. Film-Info) die Buehne
                # nicht staendig neu fuellen: das kostet nur Rechenzeit.
                if xbmc.getCondVisibility('Window.IsActive(home) + !Window.IsActive(DialogVideoInfo.xml)'):
                    path = ''
                    for key in ('NFItemsPath', 'NFPath'):
                        path = xbmc.getInfoLabel('Window(Home).Property(%s)' % key)
                        if path:
                            break
                    # Kein Menuepfad: keine Ersatzreihe. Sonst stuenden im
                    # Serien-Reiter Filme auf der Buehne. Dann bleibt sie leer.
                    if not path:
                        if last != '':
                            last = ''
                            tries = 0
                            clear_hero()
                        if monitor.waitForAbort(0.75):
                            break
                        continue
                    # Nach JEDER Aktion (Fokuswechsel, Auswahl, Scrollen) einen
                    # neuen Filmvorschlag auf der Buehne zeigen. Erkannt wird die
                    # Aktion am gerade fokussierten Element (Steuerelement,
                    # Position in der Reihe und Beschriftung).
                    force = False
                    cid = xbmc.getInfoLabel('System.CurrentControlId') or ''
                    parts = [cid]
                    if cid.isdigit():
                        parts.append(xbmc.getInfoLabel(
                            'Container(%s).Position' % cid) or '')
                    parts.append(xbmc.getInfoLabel('ListItem.Label') or '')
                    action_now = '|'.join(parts)
                    if action_now != last_action:
                        first = last_action is None
                        last_action = action_now
                        # kurze Sperre: schnelles Scrollen soll nicht flackern
                        if not first and time.monotonic() - last_change > 0.9:
                            force = True
                            last_change = time.monotonic()

                    if path != last:
                        last = path
                        tries = 0
                        force = True
                        # Buehne leeren: beim Reiterwechsel darf kein Eintrag
                        # vom vorigen Reiter stehen bleiben.
                        clear_hero()

                    if path and tries < 6:
                        hero_title = xbmc.getInfoLabel(
                            'Window(Home).Property(NFHeroTitle)')
                        if force or not hero_title:
                            tries += 1
                            # Zuerst die sichtbaren Poster-Reihen lesen. Das
                            # kostet kein Netz und startet nichts.
                            picks = from_containers(path)
                            # Nur echte Menue-Pfade abfragen. Ein Film-Link
                            # (z. B. ?action=scoutMovie) wuerde beim
                            # Auflisten sofort die Wiedergabe starten.
                            # Addon-Pfade (plugin://) nie abfragen: dabei laedt
                            # das Addon im Hintergrund den ganzen Ordner nach,
                            # blockiert Kodi minutenlang und kann Filme starten.
                            if not picks and not is_play_link(path) \
                                    and not path.lower().startswith('plugin://'):
                                try:
                                    picks = from_jsonrpc(path)
                                except Exception:
                                    picks = []
                            if picks:
                                # nicht zweimal hintereinander denselben Film
                                current = xbmc.getInfoLabel(
                                    'Window(Home).Property(NFHeroPath)')
                                others = [p for p in picks if p[4] != current]
                                title, image, plot, meta, play, is_dir = \
                                    random.choice(others or picks)
                                xbmc.executebuiltin(
                                    'SetProperty(NFHeroTitle,%s,Home)' % clean(title))
                                xbmc.executebuiltin(
                                    'SetProperty(NFHeroPlot,%s,Home)' % clean(plot, 300))
                                xbmc.executebuiltin(
                                    'SetProperty(NFHeroPlotLong,%s,Home)' % clean(plot, 900))
                                xbmc.executebuiltin(
                                    'SetProperty(NFHeroMeta,%s,Home)' % clean(meta, 120))
                                xbmc.executebuiltin(
                                    'SetProperty(NFHeroArt,%s,Home)' % clean(image, 900))
                                # Pfad direkt setzen: so bleiben Kommas, Quotes
                                # und lange Links unveraendert erhalten (ueber
                                # SetProperty wuerde der Link zerlegt).
                                xbmcgui.Window(10000).setProperty(
                                    'NFHeroPath', (play or '').strip())
                                # Serie = Ordner: der Knopf 'Wiedergeben' darf
                                # dann nichts starten, sondern oeffnet wie der
                                # Klick auf das Poster die Folgenliste. Filme
                                # behalten ihren Abspiellink und starten direkt.
                                folder = 1 if (is_dir and is_series_link(play)) \
                                    else 0
                                xbmc.executebuiltin(
                                    'SetProperty(NFHeroFolder,%d,Home)' % folder)
                                # TMDB-Nummer und Art mitschreiben: damit laesst
                                # sich beim Klick ein sauberer Staffel-Link
                                # bauen, auch wenn der Poster-Link nur auf die
                                # Liste zeigt, aus der das Poster kam.
                                xbmcgui.Window(10000).setProperty(
                                    'NFHeroTMDB', tmdb_of(play))
                                xbmcgui.Window(10000).setProperty(
                                    'NFHeroType', type_of(play))
                                tries = 0
            except Exception:
                pass
            if monitor.waitForAbort(0.75):
                break

    threading.Thread(target=loop, name='itspossible-hero', daemon=True).start()


def _start_deep():
    """Geht die Kategorien des gewaehlten Menuepunkts bis zur untersten Ebene
    durch, damit die Startseite fertige Filmreihen zeigen kann."""
    import importlib.util

    try:
        path = os.path.join(APPS, "deep", "default.py")
        spec = importlib.util.spec_from_file_location("itspossible_deep", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.start()
    except Exception:
        pass


if __name__ == "__main__":
    _start_scanner()
    _start_sidebar()
    _start_hero()
    run("widgets", "service.py")
