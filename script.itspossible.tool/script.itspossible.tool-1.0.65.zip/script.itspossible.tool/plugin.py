import os, sys, runpy

BASE = os.path.dirname(os.path.abspath(__file__))
APPS = os.path.join(BASE, "apps")


def _bootstrap(app):
    """Put the shared shims, the common module and the wanted app on sys.path."""
    for path in (os.path.join(APPS, "shims"),
                 os.path.join(APPS, "module", "resources", "modules"),
                 os.path.join(APPS, app)):
        if path not in sys.path:
            sys.path.insert(0, path)


def run(app, script):
    _bootstrap(app)
    runpy.run_path(os.path.join(APPS, app, script), run_name="__main__")

import urllib.parse


def main():
    raw = sys.argv[2] if len(sys.argv) > 2 else ""
    params = dict(urllib.parse.parse_qsl(raw.replace("?", "").lower()))
    # Startseiten-Reihen: Ordner ohne Bilder nach unten sortiert
    if params.get("action") == "rows":
        run("rows", "plugin.py")
    # fertige Reihen der Startseite (vom Durchlaeufer ermittelt)
    elif params.get("action") in ("deeprow", "deepmore"):
        run("deep", "plugin.py")
    # widget listings always carry a mediatype, everything else is toolbox content
    elif "mediatype" in params:
        run("widgets", "plugin.py")
    else:
        run("toolbox", "plugin.py")


if __name__ == "__main__":
    main()
