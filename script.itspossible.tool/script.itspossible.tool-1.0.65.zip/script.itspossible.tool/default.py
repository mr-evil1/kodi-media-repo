import os, sys, runpy

BASE = os.path.dirname(os.path.abspath(__file__))
APPS = os.path.join(BASE, "apps")


def _bootstrap(app):
    """Put the shared shims, the common module and the wanted app on sys.path."""
    for path in (os.path.join(APPS, "shims"),
                 os.path.join(APPS, "module", "resources", "modules"),
                 os.path.join(APPS, app)):
        if path not in sys.path:
            sys.path.insert(0, path)


def run(app, script):
    _bootstrap(app)
    runpy.run_path(os.path.join(APPS, app, script), run_name="__main__")


def main():
    args = [arg.lower() for arg in sys.argv[1:]]
    if "controller" in args:
        index = args.index("controller")
        sys.argv = ["controller.py"] + sys.argv[1 + index + 1:]
        run("controller", "default.py")
    elif "toolbox" in args:
        run("toolbox", "default.py")
    elif "widgets" in args:
        run("widgets", "plugin.py")
    else:
        run("helper", "default.py")


if __name__ == "__main__":
    main()
