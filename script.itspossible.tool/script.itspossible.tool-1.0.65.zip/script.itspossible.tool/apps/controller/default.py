import os
import runpy
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
if BASE not in sys.path:
    sys.path.insert(0, BASE)

runpy.run_path(os.path.join(BASE, 'controller.py'), run_name='__main__')
