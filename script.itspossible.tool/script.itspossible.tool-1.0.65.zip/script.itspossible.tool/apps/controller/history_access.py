"""Read Hybrid's authoritative playback history for ItsPossible widgets.

Do not create a second progress store in the skin. All writes/clears are
performed by the Hybrid plugin, which also synchronizes its legacy bookmarks.
"""
import json
import sqlite3
from pathlib import Path
from urllib.parse import urlencode
import xbmcvfs


def db_path():
    return Path(xbmcvfs.translatePath('special://profile/addon_data/plugin.video.moviescout/playcount.db'))


def rows(media='all', include_completed=False, limit=250):
    db = db_path()
    if not db.is_file():
        return []
    connection = None
    try:
        # Read-only mode: skin never creates or alters Hybrid's database.
        connection = sqlite3.connect(db.as_uri() + '?mode=ro', uri=True, timeout=3)
        connection.row_factory = sqlite3.Row
        conditions = []
        params = []
        if media == 'tv':
            conditions.append('media=?'); params.append('episode')
        elif media == 'movie':
            conditions.append('media=?'); params.append('movie')
        if not include_completed:
            conditions.append('completed=0 AND position>0')
        where = ' WHERE ' + ' AND '.join(conditions) if conditions else ''
        sql = 'SELECT * FROM itspossible_history' + where + ' ORDER BY updated DESC LIMIT ?'
        params.append(min(1000, max(1, int(limit))))
        return [dict(row) for row in connection.execute(sql, params)]
    except (sqlite3.DatabaseError, OSError):
        return []
    finally:
        if connection:
            connection.close()


def _art(row):
    try:
        return json.loads(row.get('art') or '{}')
    except (ValueError, TypeError):
        return {}


def to_item(row):
    typ = 'tv' if row['media'] == 'episode' else 'movie'
    tmdb_id = str(row.get('tmdb_id') or '')
    art = _art(row)
    params = {'info': 'play', 'tmdb_type': typ}
    if tmdb_id.isdigit():
        params['tmdb_id'] = tmdb_id
    elif row.get('imdb_id', '').startswith('tt'):
        params['tmdb_id'] = row['imdb_id']
    else:
        # Not a valid playback route.
        return None
    if typ == 'tv':
        params.update(season=str(row['season']), episode=str(row['episode']))
    name = row.get('title') or ''
    ep = (' · S%02dE%02d' % (row['season'], row['episode'])) if typ == 'tv' else ''
    return {
        'Title': name + ep,
        'ShowTitle': row.get('showtitle') or (name if typ == 'tv' else ''),
        'TMDB': tmdb_id,
        'Type': typ, 'DBType': 'episode' if typ == 'tv' else 'movie',
        'Season': str(row['season']) if typ == 'tv' else '',
        'Episode': str(row['episode']) if typ == 'tv' else '',
        'Poster': art.get('poster') or 'special://skin/media/itspossible/poster.png',
        'Fanart': art.get('fanart') or '', 'Clearlogo': art.get('clearlogo') or '',
        'Resume': float(row.get('position') or 0),
        'Total': float(row.get('duration') or 0), 'Updated': float(row.get('updated') or 0),
        'Path': 'plugin://plugin.video.moviescout/?' + urlencode(params),
        'HybridIdentity': row['identity'], 'HybridMedia': row['media'],
    }


def continue_items(media='all'):
    result = []
    for row in rows(media):
        item = to_item(row)
        if item:
            result.append(item)
    return result


def resume_for(item):
    media = 'episode' if item.get('DBType') == 'episode' else 'movie'
    tmdb = str(item.get('TMDB') or '')
    if not tmdb.isdigit():
        return None
    key = 'tmdb:' + tmdb
    s = int(item.get('Season') or 0) if media == 'episode' else 0
    e = int(item.get('Episode') or 0) if media == 'episode' else 0
    for row in rows('tv' if media == 'episode' else 'movie', include_completed=True, limit=1000):
        if row['identity'] == key and row['season'] == s and row['episode'] == e:
            return row
    return None


def delete_url(item):
    media = item.get('HybridMedia') or ('episode' if item.get('DBType') == 'episode' else 'movie')
    identity = item.get('HybridIdentity')
    if not identity or media not in ('movie', 'episode'):
        return ''
    params = dict(action='historyRemove', media=media, identity=identity,
                  season=item.get('Season') or 0, episode=item.get('Episode') or 0)
    return 'plugin://plugin.video.moviescout/?' + urlencode(params)


def contains(media, identity, season=0, episode=0):
    """Read a single exact row; no cached result or 250-item list limit."""
    if media not in ('movie', 'episode') or not identity:
        return False
    db = db_path()
    if not db.is_file():
        return False
    connection = None
    try:
        connection = sqlite3.connect(db.as_uri() + '?mode=ro', uri=True, timeout=2)
        hit = connection.execute(
            'SELECT 1 FROM itspossible_history WHERE media=? AND identity=? AND season=? AND episode=? LIMIT 1',
            (media, identity, int(season), int(episode))).fetchone()
        return hit is not None
    except (OSError, ValueError, sqlite3.DatabaseError):
        # A missing/unreadable DB is not positive evidence of removal.
        return None
    finally:
        if connection is not None:
            connection.close()
