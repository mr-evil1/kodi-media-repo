"""Read-only bridge from Vavoo TV Plus favorite groups into ItsPossible Live TV."""
import json
import gzip
import io
import os
import re
import threading
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import parse_qs, quote, quote_plus, urlparse
from urllib.request import Request, urlopen

import xbmcvfs
import xbmc


PROFILE = Path(xbmcvfs.translatePath(
    'special://profile/addon_data/plugin.video.vavoo.tv.plus/'))
ADDON = Path(xbmcvfs.translatePath(
    'special://home/addons/plugin.video.vavoo.tv.plus/'))
PLACEHOLDER = 'special://skin/media/itspossible/poster.png'
_EPG_REFRESH_LOCK = threading.Lock()
_EPG_LAST_ATTEMPT = 0.0


def _read_json(path, default):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return default


def _groups():
    rows = _read_json(PROFILE / 'groups.json', [])
    return [row for row in rows if row.get('name') and row.get('file')]


def _group_icon(filename):
    stem = Path(os.path.basename(filename)).stem + '.png'
    candidates = (
        PROFILE / 'favo_icons' / stem,
        ADDON / 'resources' / 'art' / 'favo_icons' / stem,
        ADDON / 'resources' / 'art' / 'favo_icons' / 'default.png',
    )
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return PLACEHOLDER


def _parse_group(filename):
    safe_file = os.path.basename(filename or '')
    if not safe_file or safe_file != filename:
        return []
    path = PROFILE / 'favgroups' / safe_file
    try:
        lines = path.read_text(encoding='utf-8', errors='replace').splitlines()
    except OSError:
        return []

    channels = []
    extinf = ''
    raw_url = ''
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith('#EXTINF:'):
            extinf, raw_url = line, ''
            continue
        if line.startswith('##VAVOO-URL:'):
            raw_url = line[len('##VAVOO-URL:'):].strip()
            continue
        if line.startswith('#') or not extinf:
            continue

        name_match = re.search(r',(.+)$', extinf)
        id_match = re.search(r'tvg-id="([^"]*)"', extinf)
        logo_match = re.search(r'tvg-logo="([^"]*)"', extinf)
        name = name_match.group(1).strip() if name_match else ''
        url = raw_url
        if not url and line.startswith('plugin://'):
            values = parse_qs(urlparse(line).query)
            url = (values.get('url') or [''])[0]
        elif not url:
            url = line
        if name and url:
            channels.append({
                'name': name,
                'url': url,
                'tvg_id': id_match.group(1).strip() if id_match else '',
                'logo': logo_match.group(1).strip() if logo_match else '',
            })
        extinf, raw_url = '', ''
    return channels


def _normal(value):
    value = re.sub(r'\[[^\]]*\]|\([^)]*\)', ' ', str(value or '').lower())
    value = re.sub(r'\s+(?:hd\+?|fhd|uhd|4k|sd)$', '', value)
    return re.sub(r'[^a-z0-9]', '', value)


def _epg_cache():
    data = _read_json(PROFILE / 'epg_cache.json', {})
    return data.get('data') if isinstance(data.get('data'), dict) else {}


def _refresh_epg_if_stale():
    """Refresh Vavoo's XMLTV cache without importing its add-on-only Python context."""
    global _EPG_LAST_ATTEMPT
    cache = _read_json(PROFILE / 'epg_cache.json', {})
    if cache.get('expires', 0) > time.time():
        return
    if time.monotonic() - _EPG_LAST_ATTEMPT < 900:
        return
    if not _EPG_REFRESH_LOCK.acquire(False):
        return
    _EPG_LAST_ATTEMPT = time.monotonic()
    try:
        settings = ET.parse(str(PROFILE / 'settings.xml')).getroot()
        node = settings.find("setting[@id='epg_url']")
        epg_url = (node.text or '').strip() if node is not None else ''
        if not epg_url:
            return
        request = Request(epg_url, headers={'User-Agent': 'ItsPossible Kodi EPG/1.0'})
        with urlopen(request, timeout=60) as response:
            raw = response.read()
        if epg_url.lower().endswith('.gz') or raw[:2] == b'\x1f\x8b':
            raw = gzip.decompress(raw)

        data = {}
        for _, node in ET.iterparse(io.BytesIO(raw), events=('end',)):
            if node.tag == 'channel':
                node.clear()
                continue
            if node.tag != 'programme':
                continue
            channel_id = (node.get('channel') or '').strip()
            start = _xmltv_datetime(node.get('start', ''))
            stop = _xmltv_datetime(node.get('stop', ''))
            if channel_id and start and stop:
                title = _xmltv_text(node, 'title')
                desc = _xmltv_text(node, 'desc')
                data.setdefault(channel_id, []).append(
                    [start.isoformat(), stop.isoformat(), title, desc])
            node.clear()

        if not data:
            raise ValueError('Die XMLTV-Quelle enthält keine verwertbaren Sendungen')
        cache_hours = 2
        try:
            configured_hours = settings.find("setting[@id='epg_cache_hours']")
            if configured_hours is not None and configured_hours.text:
                cache_hours = max(1, int(configured_hours.text))
        except (TypeError, ValueError):
            pass
        refreshed = {'url': epg_url, 'expires': time.time() + cache_hours * 3600, 'data': data}
        cache_path = PROFILE / 'epg_cache.json'
        temporary_path = cache_path.with_suffix('.json.itspossible-tmp')
        temporary_path.write_text(json.dumps(refreshed, ensure_ascii=False), encoding='utf-8')
        os.replace(str(temporary_path), str(cache_path))
        xbmc.log('[ItsPossible] Vavoo-EPG aktualisiert: %d Sender-IDs' % len(data), xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log('[ItsPossible] Vavoo-EPG-Refresh: ' + str(exc), xbmc.LOGWARNING)
    finally:
        _EPG_REFRESH_LOCK.release()


def _xmltv_datetime(value):
    """Parse XMLTV timestamps into naive UTC datetimes used by Vavoo's cache."""
    try:
        parts = value.strip().split(None, 1)
        parsed = datetime.strptime(parts[0][:14], '%Y%m%d%H%M%S')
        if len(parts) == 1:
            return parsed
        zone = parts[1]
        sign = -1 if zone.startswith('-') else 1
        offset = timedelta(hours=int(zone[1:3]), minutes=int(zone[3:5])) * sign
        return parsed - offset
    except (AttributeError, TypeError, ValueError):
        return None


def _xmltv_text(node, tag):
    choices = node.findall(tag)
    if not choices:
        return ''
    preferred = next((child for child in choices
                      if (child.get('lang') or '').lower() in ('de', 'deu')), choices[0])
    return (preferred.text or '').strip()


def _programme(channel, epg):
    requested = channel.get('tvg_id') or channel.get('name', '')
    key = next((candidate for candidate in epg if candidate.casefold() == requested.casefold()), '')
    if not key:
        normalized = _normal(requested)
        if normalized:
            exact = [candidate for candidate in epg if _normal(candidate) == normalized]
            if exact:
                key = exact[0]
            else:
                matches = [candidate for candidate in epg
                           if len(normalized) >= 5 and
                           (normalized in _normal(candidate) or _normal(candidate) in normalized)]
                if matches:
                    key = max(matches, key=lambda candidate: min(len(normalized), len(_normal(candidate))))
    if not key:
        return None

    now = datetime.now(timezone.utc).replace(tzinfo=None)
    entries = []
    for entry in epg.get(key, []):
        try:
            start = datetime.fromisoformat(entry[0]).replace(tzinfo=None)
            stop = datetime.fromisoformat(entry[1]).replace(tzinfo=None)
            entries.append((start, stop, str(entry[2] or ''), str(entry[3] or '')))
        except (TypeError, ValueError, IndexError):
            continue
    entries.sort(key=lambda entry: entry[0])
    for index, (start, stop, title, desc) in enumerate(entries):
        if start <= now <= stop:
            local_stop = stop.replace(tzinfo=timezone.utc).astimezone().strftime('%H:%M')
            minutes = max(0, int((stop - now).total_seconds() // 60))
            label = 'Jetzt: %s · bis %s' % (title, local_stop) if title else ''
            plot = 'Jetzt läuft: %s\nBis %s Uhr (%d Min.)' % (title, local_stop, minutes) if title else ''
            if desc:
                plot += '\n\n' + desc
            next_title = ''
            next_time = ''
            if index + 1 < len(entries) and entries[index + 1][2]:
                next_title = entries[index + 1][2]
                next_time = entries[index + 1][0].replace(
                    tzinfo=timezone.utc).astimezone().strftime('%H:%M')
                plot += '\n\nDanach: %s ab %s Uhr' % (next_title, next_time)
            duration = max(1, (stop - start).total_seconds())
            progress = min(100, max(0, int((now - start).total_seconds() * 100 / duration)))
            return {'label': label, 'plot': plot, 'minutes': minutes,
                    'next': next_title, 'next_time': next_time, 'progress': progress}
    return None


def directory(path):
    """Return Vavoo group folders or their channels as ItsPossible items."""
    if path == 'nf://vavoo/groups':
        _refresh_epg_if_stale()
        items = []
        for group in _groups():
            filename = os.path.basename(group['file'])
            items.append({
                'Title': group['name'],
                'Path': 'plugin://skin.its.possible/?vavoo=group&file=' + quote(filename),
                'Fanart': _group_icon(filename),
                'Poster': _group_icon(filename),
                'Plot': 'Vavoo TV-Gruppe',
                'Type': 'tv', 'DBType': 'folder', 'Folder': True,
            })
        return items, ''

    parsed = urlparse(path)
    if parsed.scheme != 'nf' or parsed.netloc != 'vavoo' or parsed.path != '/group':
        return [], ''
    filename = (parse_qs(parsed.query).get('file') or [''])[0]
    group = next((entry for entry in _groups()
                  if os.path.basename(entry['file']) == filename), None)
    if not group:
        return [], ''
    epg = _epg_cache()
    items = []
    for channel in _parse_group(filename):
        programme = _programme(channel, epg)
        logo = channel.get('logo') or _group_icon(filename)
        route = 'plugin://plugin.video.vavoo.tv.plus/?' + (
            'action=play&name=%s&url=%s&tvg_id=%s&logo=%s' % (
                quote_plus(channel['name']), quote_plus(channel['url']),
                quote_plus(channel.get('tvg_id', '')), quote_plus(channel.get('logo', ''))))
        items.append({
            'Title': channel['name'], 'Path': route,
            'Fanart': logo, 'Poster': logo,
            'Plot': programme['plot'] if programme else '',
            'EPG': programme['label'] if programme else '',
            'EPGNext': ((programme['next'] + ' · ' + programme['next_time'])
                        if programme and programme.get('next') else 'Keine Folgesendung im EPG'),
            'EPGProgress': programme['progress'] if programme else 0,
            'Type': 'tv', 'DBType': 'channel',
            'Genres': group['name'], 'TMDB': '',
        })
    return items, ''
