"""Lauflicht fuer den Ladebildschirm des Its-Possible-Skins.

Rechnet dieselbe K.I.T.T.-Animation wie das Python-Beispiel des Nutzers:
15 LEDs, alle 180 ms wandert der Kopf eine LED weiter, die Helligkeit der
uebrigen LEDs dunkelt dabei mit Faktor 0.8 ab (Schweif hinter dem Kopf).
Die Werte werden als Fenster-Properties an den Skin geschrieben.
"""

import threading

import xbmc
import xbmcgui

LEDS = 15
STEP_MS = 180
MIN_BRIGHT = 25
DECAY = 0.8

WINDOW = xbmcgui.Window(10000)
ACTIVE = "Window.IsActive(DialogBusy.xml) | Window.IsActive(1103) | Window.IsActive(1104)"


def _prop(index):
    return "kitt_led%02d" % index


def _paint(values):
    for index, value in enumerate(values, 1):
        WINDOW.setProperty(_prop(index), "FF%02X0000" % value)


def _reset():
    _paint([MIN_BRIGHT] * LEDS)


def _loop():
    helligkeit = [MIN_BRIGHT] * LEDS
    position = 0
    richtung = 1
    _reset()

    while True:
        if xbmc.getCondVisibility(ACTIVE):
            for i in range(LEDS):
                helligkeit[i] = int(helligkeit[i] * DECAY)
            helligkeit[position] = 255
            _paint([max(MIN_BRIGHT, wert) for wert in helligkeit])

            position += richtung
            if position >= LEDS - 1:
                richtung = -1
            elif position <= 0:
                richtung = 1
            xbmc.sleep(STEP_MS)
        else:
            # Nicht sichtbar: zuruecksetzen, damit es beim naechsten Mal
            # wieder von vorne loslaeuft und nichts weiterrechnet.
            if any(wert != MIN_BRIGHT for wert in helligkeit) or position or richtung != 1:
                _reset()
            helligkeit = [MIN_BRIGHT] * LEDS
            position = 0
            richtung = 1
            xbmc.sleep(250)


def start():
    """Startet das Lauflicht als Hintergrund-Thread (vom Service aufgerufen)."""
    threading.Thread(target=_loop, name="itspossible-scanner", daemon=True).start()


if __name__ == "__main__":
    _loop()
