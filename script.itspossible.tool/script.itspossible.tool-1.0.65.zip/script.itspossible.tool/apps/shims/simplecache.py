"""Minimal SimpleCache replacement for the bundled helper scripts."""
import hashlib
import json
import os
import time

import xbmcvfs


class SimpleCache(object):
    def __init__(self, *args, **kwargs):
        self.dir = xbmcvfs.translatePath("special://temp/itspossible-cache/")
        try:
            xbmcvfs.mkdirs(self.dir)
        except Exception:
            pass

    def _path(self, key):
        name = hashlib.md5(str(key).encode("utf-8")).hexdigest()
        return os.path.join(self.dir, name + ".json")

    def get(self, key, default=None, *args, **kwargs):
        path = self._path(key)
        try:
            with open(path, encoding="utf-8") as handle:
                payload = json.load(handle)
            if payload.get("expires") and payload["expires"] < time.time():
                return default
            return payload["value"]
        except Exception:
            return default

    def set(self, key, value, expiration=None, *args, **kwargs):
        expires = time.time() + expiration if expiration else None
        try:
            with open(self._path(key), "w", encoding="utf-8") as handle:
                json.dump({"expires": expires, "value": value}, handle)
        except Exception:
            pass

    def delete(self, key, *args, **kwargs):
        try:
            os.remove(self._path(key))
        except Exception:
            pass

    def clear(self, *args, **kwargs):
        for name in glob_names(self.dir):
            try:
                os.remove(name)
            except Exception:
                pass


def glob_names(folder):
    try:
        return [os.path.join(folder, n) for n in os.listdir(folder)]
    except Exception:
        return []
