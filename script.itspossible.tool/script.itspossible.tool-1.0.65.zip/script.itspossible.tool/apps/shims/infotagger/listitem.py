"""No-op ListItemInfoTag: the info is already set by the caller."""


class ListItemInfoTag(object):
    def __init__(self, listitem=None, tag_type=None):
        self.listitem = listitem
        self.tag_type = tag_type

    def set_info(self, info, *args, **kwargs):
        try:
            for key, value in (info or {}).items():
                self.listitem.setInfo(self.tag_type or "video", {key: value})
        except Exception:
            pass

    def get_info(self, key, *args, **kwargs):
        return ""

    def set_cast(self, *args, **kwargs):
        pass

    def set_available_art(self, *args, **kwargs):
        pass

    def set_unique_ids(self, *args, **kwargs):
        pass

    def set_stream_details(self, *args, **kwargs):
        pass

    def set_ratings(self, *args, **kwargs):
        pass

    def set_resume_point(self, *args, **kwargs):
        pass
