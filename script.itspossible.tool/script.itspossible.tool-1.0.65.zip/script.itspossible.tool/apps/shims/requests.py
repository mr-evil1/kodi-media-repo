"""Tiny urllib based stand-in for the parts of requests the scripts use."""
import json as _json
import urllib.error
import urllib.parse
import urllib.request


class Response(object):
    def __init__(self, body, status, url):
        self.content = body
        self.status_code = status
        self.url = url

    @property
    def text(self):
        return self.content.decode("utf-8", "replace")

    def json(self):
        return _json.loads(self.text)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise Exception("HTTP %s" % self.status_code)


def _request(url, method="GET", params=None, data=None, headers=None, timeout=15, **kwargs):
    if params:
        url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    body = data
    if isinstance(body, dict):
        body = urllib.parse.urlencode(body).encode("utf-8")
    request = urllib.request.Request(url, data=body, headers=headers or {}, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as handle:
            return Response(handle.read(), handle.status, url)
    except urllib.error.HTTPError as exc:
        return Response(exc.read(), exc.code, url)


def get(url, **kwargs):
    return _request(url, "GET", **kwargs)


def post(url, **kwargs):
    return _request(url, "POST", **kwargs)


def head(url, **kwargs):
    return _request(url, "HEAD", **kwargs)
