#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Reihen der Startseite.

Liest den Ordner des gewaehlten Menuepunkts und gibt ihn in derselben
Reihenfolge zurueck - nur mit einem Unterschied: Eintraege, die keine Bilder
haben und nur weitere Ordner enthalten (z. B. "Filme - Genres", "Filme -
Streaming Anbieter", "Filme - Jahr"), wandern ganz nach unten. So stehen die
Poster-Reihen oben und die Text-Reihen unter z. B. "Box Office".
"""

import base64
import json
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])

# Ordnernamen, hinter denen nur weitere Ordner ohne Bilder stecken.
MENU_WORDS = ("genre", "year", "jahr", "provider", "anbieter")


def _option(name):
    """Wert eines Aufruf-Parameters - ohne Kleinschreibung, weil base64
    zwischen Gross- und Kleinschreibung unterscheidet."""
    raw = sys.argv[2] if len(sys.argv) > 2 else ""
    for key, value in urllib.parse.parse_qsl(raw.lstrip("?"), keep_blank_values=True):
        if key.lower() == name:
            return value
    return ""


def _decode(value):
    value = (value or "").strip()
    value += "=" * (-len(value) % 4)
    try:
        return base64.urlsafe_b64decode(value.encode("utf-8")).decode("utf-8")
    except Exception:
        return ""


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log("[itspossible] Reihen: %s" % message, level)
    except Exception:
        pass


def _listing(path):
    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Files.GetDirectory",
        "params": {
            "directory": path,
            "media": "files",
            "properties": ["title", "art", "thumbnail"],
        },
    }
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps(request)) or "{}")
    except Exception as error:
        _log("Abfrage fehlgeschlagen (%s)" % error, xbmc.LOGWARNING)
        return []
    if answer.get("error"):
        _log("Abfrage abgelehnt: %s" % answer["error"], xbmc.LOGWARNING)
        return []
    return ((answer.get("result") or {}).get("files")) or []


def _has_image(item):
    if item.get("thumbnail"):
        return True
    for value in (item.get("art") or {}).values():
        if value:
            return True
    return False


def _is_menu(item):
    """Ordner, hinter dem nur weitere Ordner ohne Bilder liegen."""
    path = (item.get("file") or "").lower()
    return any(word in path for word in MENU_WORDS)


def _goes_down(item):
    if item.get("filetype") != "directory":
        return False
    return _is_menu(item) or not _has_image(item)


def _listitem(item):
    art = dict(item.get("art") or {})
    if item.get("thumbnail"):
        art.setdefault("thumb", item["thumbnail"])
    label = item.get("label") or ""
    entry = xbmcgui.ListItem(label=label)
    if art:
        entry.setArt(art)
    file = item.get("file") or ""
    if file:
        entry.setPath(file)
    entry.setIsFolder(item.get("filetype") == "directory")
    return (file, entry, item.get("filetype") == "directory")


def main():
    source = _decode(_option("source"))
    if not source:
        _log("kein Quellordner uebergeben", xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    items = _listing(source)
    # Python sortiert stabil: alles andere bleibt in seiner Reihenfolge.
    items.sort(key=lambda item: 1 if _goes_down(item) else 0)

    entries = []
    for item in items:
        where, entry, is_folder = _listitem(item)
        entries.append((where, entry, is_folder))

    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    _log("%d Eintraege aus %s" % (len(entries), source))


if __name__ == "__main__":
    main()
