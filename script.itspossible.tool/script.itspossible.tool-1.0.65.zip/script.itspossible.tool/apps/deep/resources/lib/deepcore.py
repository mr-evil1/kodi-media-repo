#!/usr/bin/python
# coding: utf8
"""Geht die Kategorien eines Addon-Menuepunkts bis zur untersten Ebene durch.

Ergebnis:
  rows   - fertige Reihen mit echten Eintraegen (Filme), also die unterste Ebene
  deeper - Ordner, unter denen es noch weiter geht (kommen ganz ans Ende)

Das Ergebnis wird als JSON zwischengespeichert, damit der Skin die Reihen
ueber eine eigene Plugin-Adresse abholen kann (plugin://.../?action=deeprow&row=N).
"""

import json
import os
import re
import time

import xbmc
import xbmcvfs

ADDON_ID = 'script.itspossible.tool'

MAX_ROWS = 10
MAX_ITEMS_PER_ROW = 40
MAX_ITEMS_PER_DIR = 200
MAX_FOLDERS = 80
MAX_DEPTH = 4
TIME_BUDGET = 60

PLAY_MARKERS = ('scoutmovie', 'scoutepisode', 'scoutplay', 'info=play',
                'action=play', '.mp4', '.mkv', '.m3u8', '.avi', '.mov',
                '.wmv', '.ts?', '.flv', '.webm')


def cache_path():
    base = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
    try:
        if not xbmcvfs.exists(base):
            xbmcvfs.mkdirs(base)
    except Exception:
        pass
    return os.path.join(base, 'deep.json')


def load_cache():
    try:
        with open(cache_path(), encoding='utf-8') as fh:
            return json.load(fh)
    except Exception:
        return {}


def save_cache(data):
    try:
        with open(cache_path(), 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
    except Exception:
        pass


def is_play_link(path):
    """Ein Wiedergabe-Link darf nie aufgelistet werden - das wuerde starten."""
    low = (path or '').lower()
    return any(marker in low for marker in PLAY_MARKERS)


def clean(value, limit=120):
    text = re.sub(r'\[/?[^\]]*\]', '', value or '')
    text = ' '.join(text.replace(',', ' ').split())
    if len(text) > limit:
        text = text[:limit].rstrip() + ' \u2026'
    return text


def _list_dir(path):
    request = {
        'jsonrpc': '2.0', 'id': 1,
        'method': 'Files.GetDirectory',
        'params': {
            'directory': path,
            'media': 'video',
            'properties': ['title', 'year', 'genre', 'art', 'plot', 'file',
                           'thumbnail', 'season', 'episode'],
            'limits': {'end': MAX_ITEMS_PER_DIR},
        },
    }
    try:
        result = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except Exception:
        return []
    return (result.get('result') or {}).get('files') or []


def _art_of(item):
    art = item.get('art') or {}
    for key in ('poster', 'thumb', 'landscape', 'fanart', 'banner'):
        value = art.get(key)
        if value:
            return value
    return item.get('thumbnail') or ''


def _is_dir(item):
    return item.get('filetype') == 'directory'


def _norm_file(item):
    genre = item.get('genre') or []
    if isinstance(genre, str):
        genre = [genre]
    return {
        'label': clean(item.get('label') or item.get('title') or ''),
        'path': item.get('file') or '',
        'art': _art_of(item),
        'plot': clean(item.get('plot') or '', 400),
        'year': item.get('year') or 0,
        'genre': ', '.join(genre[:2]),
    }


def _norm_dir(item):
    return {
        'label': clean(item.get('label') or item.get('title') or ''),
        'path': item.get('file') or '',
        'art': _art_of(item),
    }


def walk(root, cancel=None, on_row=None):
    """Durchsucht root und liefert (rows, deeper, finished).

    rows     - Liste von {'title': ..., 'items': [...]} mit der untersten Ebene
    deeper   - Ordner, unter denen noch etwas kommt (ans Ende der Startseite)
    finished - False, wenn das Zeit- oder Mengenlimit erreicht wurde
    """
    rows = []
    deeper = []
    seen = set()
    deadline = time.time() + TIME_BUDGET
    counter = {'folders': 0, 'finished': True}

    def out_of_time():
        return time.time() > deadline or counter['folders'] > MAX_FOLDERS \
            or len(rows) >= MAX_ROWS or (cancel and cancel())

    def add_row(title, entries):
        rows.append({'title': clean(title, 90) or 'Eintraege',
                     'items': entries[:MAX_ITEMS_PER_ROW]})
        if on_row:
            try:
                on_row(len(rows) - 1, rows[-1]['title'], len(rows[-1]['items']))
            except Exception:
                pass

    def walk_into(path, title, depth):
        if not path or path in seen:
            return
        if out_of_time():
            counter['finished'] = False
            if depth > 0:
                deeper.append({'label': clean(title, 90), 'path': path,
                               'art': ''})
            return
        seen.add(path)
        counter['folders'] += 1

        items = _list_dir(path)
        dirs = []
        files = []
        for item in items:
            file_path = item.get('file') or ''
            if not file_path or is_play_link(file_path):
                continue
            if _is_dir(item):
                dirs.append(item)
            else:
                files.append(item)

        # Unterste Ebene: hier liegen echte Eintraege (Filme/Serien)
        if files:
            entries = [_norm_file(item) for item in files]
            entries = [e for e in entries if e['label'] and e['path']]
            if entries:
                add_row(title or 'Alle Eintraege', entries)
            # Ordner, die hier zusaetzlich liegen, kommen ans Ende
            for item in dirs:
                if len(deeper) < 40:
                    deeper.append(_norm_dir(item))
            return

        # Reine Ordnerebene: eine Ebene tiefer schauen
        if depth >= MAX_DEPTH:
            counter['finished'] = False
            for item in dirs:
                if len(deeper) < 40:
                    deeper.append(_norm_dir(item))
            return

        for item in dirs:
            if out_of_time():
                counter['finished'] = False
                if len(deeper) < 40:
                    deeper.append(_norm_dir(item))
                continue
            label = clean(item.get('label') or '', 60)
            sub_title = label if depth == 0 else '%s \u00b7 %s' % (title, label)
            walk_into(item.get('file') or '', sub_title, depth + 1)

    walk_into(root, '', 0)

    data = {
        'root': root,
        'time': int(time.time()),
        'rows': rows,
        'deeper': deeper[:40],
        'finished': counter['finished'],
    }
    save_cache(data)
    return rows, data['deeper'], data['finished']
