#!/usr/bin/python
# coding: utf8
"""Beobachtet den gewaehlten Menuepunkt und geht dessen Kategorien bis zur
untersten Ebene durch. Die fertigen Reihen werden als Fenster-Eigenschaften
abgelegt (NFDeep0T ... NFDeep9T) und die Rest-Ordner als NFDeepMoreT."""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'resources', 'lib'))

import xbmc  # noqa: E402

from deepcore import walk  # noqa: E402

ROW_PROP = 'NFDeep%dT'
MORE_PROP = 'NFDeepMoreT'
BUSY_PROP = 'NFDeepBusy'


def _set(prop, value):
    value = (value or '').replace(',', ' ').replace('(', ' ').replace(')', ' ')
    value = ' '.join(value.split())
    if value:
        xbmc.executebuiltin('SetProperty(%s,%s,Home)' % (prop, value))
    else:
        xbmc.executebuiltin('ClearProperty(%s,Home)' % prop)


def _clear_all():
    for index in range(12):
        xbmc.executebuiltin('ClearProperty(%s,Home)' % (ROW_PROP % index))
    xbmc.executebuiltin('ClearProperty(%s,Home)' % MORE_PROP)


def start():
    import threading
    threading.Thread(target=_loop, name='itspossible-deep', daemon=True).start()


def _loop():
    monitor = xbmc.Monitor()
    last = None
    while not monitor.abortRequested():
        try:
            if not xbmc.getCondVisibility('Window.IsActive(home)'):
                if last is not None:
                    last = None
                    _clear_all()
            else:
                path = xbmc.getInfoLabel('Window(Home).Property(NFPath)')
                if path != last:
                    last = path
                    _clear_all()
                    if path.startswith('plugin://'):
                        _set(BUSY_PROP, '1')
                        def publish(index, title, _count):
                            if index < 10:
                                _set(ROW_PROP % index, title)

                        rows, deeper, _finished = walk(
                            path,
                            cancel=lambda p=path: xbmc.getInfoLabel(
                                'Window(Home).Property(NFPath)') != p,
                            on_row=publish)
                        xbmc.executebuiltin('ClearProperty(%s,Home)' % BUSY_PROP)
                        for index, row in enumerate(rows[:10]):
                            _set(ROW_PROP % index, row.get('title'))
                        if deeper:
                            _set(MORE_PROP, 'Weitere Kategorien')
        except Exception:
            try:
                xbmc.executebuiltin('ClearProperty(%s,Home)' % BUSY_PROP)
            except Exception:
                pass
        if monitor.waitForAbort(0.8):
            break
