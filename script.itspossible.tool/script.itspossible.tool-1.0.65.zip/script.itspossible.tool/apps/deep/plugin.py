#!/usr/bin/python
# coding: utf8
"""Liefert die vom Durchlaeufer gefundenen Reihen an den Skin.

Aufruf:
  plugin://script.itspossible.tool/?action=deeprow&row=0   -> fertige Reihe 0
  plugin://script.itspossible.tool/?action=deepmore       -> Ordner, die tiefer fuehren
"""

import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'resources', 'lib'))

from deepcore import load_cache  # noqa: E402


def _item(entry, is_folder):
    label = entry.get('label') or ''
    listitem = xbmcgui.ListItem(label=label)
    art = entry.get('art') or ''
    if art:
        listitem.setArt({'thumb': art, 'icon': art, 'poster': art,
                         'landscape': art, 'fanart': art})
    info = {'title': label}
    if entry.get('plot'):
        info['plot'] = entry['plot']
    if entry.get('genre'):
        info['genre'] = entry['genre']
    try:
        if entry.get('year'):
            info['year'] = int(entry['year'])
    except Exception:
        pass
    try:
        listitem.setInfo('video', info)
    except Exception:
        pass
    if not is_folder:
        listitem.setProperty('IsPlayable', 'true')
    return listitem


def main():
    handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    raw = sys.argv[2] if len(sys.argv) > 2 else ''
    params = dict(urllib.parse.parse_qsl(raw.replace('?', '')))

    data = load_cache()
    action = (params.get('action') or 'deeprow').lower()

    if action == 'deepmore':
        for entry in data.get('deeper') or []:
            if not entry.get('path'):
                continue
            xbmcplugin.addDirectoryItem(handle, entry['path'],
                                        _item(entry, True), isFolder=True)
    else:
        try:
            index = int(params.get('row') or 0)
        except Exception:
            index = 0
        rows = data.get('rows') or []
        if 0 <= index < len(rows):
            for entry in rows[index].get('items') or []:
                if not entry.get('path'):
                    continue
                xbmcplugin.addDirectoryItem(handle, entry['path'],
                                            _item(entry, False), isFolder=False)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


if __name__ == '__main__':
    main()
