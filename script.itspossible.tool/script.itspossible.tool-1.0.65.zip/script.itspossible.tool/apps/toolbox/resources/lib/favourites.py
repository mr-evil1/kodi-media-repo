#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
import xbmc
import xbmcgui
from resources.lib.utils import log_msg, log_exception

# Spotlight-Liste der Netflix-Style-Startseite
CONTAINER = "17290"

# Texte (die Skin-Sprachdatei ist aus einem Addon nicht lesbar)
LANG = {
    "added": "Zu meiner Liste hinzugefügt",
    "removed": "Aus meiner Liste entfernt",
    "nopath": "Dieser Titel lässt sich nicht merken.",
    "header": "Meine Liste",
}


class Favourites:
    '''adds or removes the spotlight title to the Kodi favourites'''

    def toggle(self, header=""):
        '''switch the favourite state of the item shown in the spotlight'''
        try:
            path = self._info("FolderPath")
            label = self._info("Label")
            thumb = (self._info("Art(poster)") or self._info("Art(thumb)") or
                     self._info("Art(landscape)") or self._info("Art(fanart)"))
            if not path:
                log_msg("Favourites: no path on the spotlight item", xbmc.LOGWARNING)
                xbmcgui.Dialog().notification(header or LANG["header"], LANG["nopath"],
                                              xbmcgui.NOTIFICATION_WARNING, 3000)
                return
            favourite_id = self._find(path)
            if favourite_id is not None:
                self._rpc("Favourites.RemoveFavourite", {"favouriteid": favourite_id})
                log_msg("Favourites: removed %s" % path)
                xbmcgui.Dialog().notification(header or LANG["header"], LANG["removed"],
                                              xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                self._rpc("Favourites.AddFavourite", {"title": label or path,
                                                      "type": "media",
                                                      "path": path,
                                                      "window": "videos",
                                                      "thumbnail": thumb or ""})
                log_msg("Favourites: added %s" % path)
                xbmcgui.Dialog().notification(header or LANG["header"], LANG["added"],
                                              xbmcgui.NOTIFICATION_INFO, 3000)
            # Die Favoritenreihe der Startseite neu einlesen
            xbmc.executebuiltin("Container.Refresh")
        except Exception as exc:
            log_exception(__name__, exc)

    def _info(self, info):
        '''reads an infolabel of the spotlight item'''
        try:
            return xbmc.getInfoLabel("Container(%s).ListItem.%s" % (CONTAINER, info))
        except Exception:
            return ""

    def _find(self, path):
        '''returns the favourite id of an already stored path or None'''
        result = self._rpc("Favourites.GetFavourites",
                           {"type": "media", "properties": ["path", "window", "thumbnail"]})
        for favourite in (result or {}).get("favourites", []):
            if (favourite.get("path") or "") == path:
                return favourite.get("favouriteid")
        return None

    def _rpc(self, method, params):
        '''runs a json-rpc call and returns its result'''
        try:
            payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
            response = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
            if "error" in response:
                log_msg("Favourites: %s failed: %s" % (method, response["error"]), xbmc.LOGWARNING)
                return None
            return response.get("result")
        except Exception as exc:
            log_exception(__name__, exc)
            return None
