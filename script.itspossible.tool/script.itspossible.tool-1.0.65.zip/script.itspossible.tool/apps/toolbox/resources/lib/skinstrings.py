#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import re
import xbmc
import xbmcvfs
from resources.lib.utils import try_decode, log_exception

STRINGS = {}
LOADED = False


def _parse(path):
    '''liest eine strings.po und liefert id -> text'''
    strings = {}
    current = None
    try:
        handle = xbmcvfs.File(path)
        content = try_decode(handle.read())
        handle.close()
        for line in content.splitlines():
            line = line.strip()
            if line.startswith("msgctxt"):
                match = re.search(r"#(\d+)", line)
                current = match.group(1) if match else None
            elif line.startswith("msgstr") and current:
                text = line.split("msgstr", 1)[1].strip()
                if text.startswith('"'):
                    text = text[1:]
                if text.endswith('"'):
                    text = text[:-1]
                strings[current] = text
                current = None
    except Exception as exc:
        log_exception(__name__, exc)
    return strings


def load_strings():
    '''laedt die Sprachdatei des aktiven Skins'''
    global LOADED
    if LOADED:
        return STRINGS
    LOADED = True
    language = (try_decode(xbmc.getLanguage(xbmc.ISO_639_1)) or "en").lower()
    language_dir = try_decode(xbmcvfs.translatePath("special://skin/language"))
    candidates = []
    try:
        dirs, files = xbmcvfs.listdir(language_dir)
        dirs = [try_decode(d) for d in dirs]
    except Exception:
        dirs = []
    # exakte Sprache zuerst, dann Sprachvariante (z.B. de_de), dann Englisch, dann irgendeine
    for wanted in ("resource.language.%s" % language,
                   "resource.language.%s_%s" % (language, language),
                   "resource.language.en_gb", "resource.language.en"):
        if wanted in dirs and wanted not in candidates:
            candidates.append(wanted)
    for folder in dirs:
        if folder.startswith("resource.language.%s_" % language) and folder not in candidates:
            candidates.append(folder)
    for folder in candidates:
        path = os.path.join(language_dir, folder, "strings.po")
        if xbmcvfs.exists(path):
            STRINGS.update(_parse(path))
            if STRINGS:
                break
    return STRINGS


def localize(text):
    '''ersetzt $LOCALIZE[...] durch die Texte der Skin-Sprachdatei'''
    if not text or "$LOCALIZE[" not in text:
        return text
    strings = load_strings()

    def _replace(match):
        string_id = match.group(1)
        if strings.get(string_id):
            return strings[string_id]
        try:
            return xbmc.getLocalizedString(int(string_id))
        except Exception:
            return ""

    return re.sub(r"\$LOCALIZE\[(\d+)\]", _replace, text)
