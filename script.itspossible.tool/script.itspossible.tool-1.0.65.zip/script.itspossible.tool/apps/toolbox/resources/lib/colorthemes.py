#!/usr/bin/python
# -*- coding: utf-8 -*-

import ast
import os
import xbmc
import xbmcvfs
import xbmcgui
from resources.lib.utils import log_msg, log_exception, try_decode
from resources.lib.dialogselect import DialogSelect

THEME_EXT = ".theme"
PREVIEW_EXT = ".jpg"
SAVE_ID = "savetheme"

# Texte des Skins (die Skin-Sprachdatei ist aus einem Addon nicht lesbar)
LANG = {
    "savelabel": "Aktuelles Design als Thema speichern",
    "savedesc": "Sichert alle aktuellen Farbeinstellungen als neues Farbthema.",
    "applied": "Farbthema angewendet",
    "saved": "Farbthema gespeichert",
    "savedesc_new": "Alle aktuellen Farben wurden gesichert.",
}

def getLocalizedString(key):
    '''liefert den Text zu einem internen Schlüssel'''
    return LANG.get(key, "")


class ColorThemes:
    '''applies, stores and resets the color themes of the skin'''

    def __init__(self):
        self.themes_dir = try_decode(xbmcvfs.translatePath("special://skin/extras/skinthemes"))

    def manage(self, header=""):
        '''show a dialog with all themes and apply the chosen one'''
        try:
            themes = self.get_themes()
            listitems = []
            for theme in themes:
                listitem = xbmcgui.ListItem(
                    label=theme["name"], label2=theme["description"])
                if theme["preview"]:
                    listitem.setArt({"thumb": theme["preview"], "icon": theme["preview"]})
                listitem.setProperty("path", theme["path"])
                listitems.append(listitem)
            # always offer to store the current colors as a new theme
            saveitem = xbmcgui.ListItem(
                label=LANG["savelabel"],
                label2=LANG["savedesc"])
            saveitem.setProperty("path", SAVE_ID)
            listitems.append(saveitem)
            if not listitems:
                return
            dialog = DialogSelect("DialogSelect.xml", "", listing=listitems,
                                  windowtitle=header)
            dialog.doModal()
            result = dialog.result
            del dialog
            if not result:
                return
            path = result.getProperty("path")
            if path == SAVE_ID:
                self.save_theme()
            elif path:
                self.apply_theme(path)
        except Exception as exc:
            log_exception(__name__, exc)

    def get_themes(self):
        '''reads all theme files from the skin'''
        themes = []
        if not xbmcvfs.exists(self.themes_dir):
            return themes
        try:
            dirs, files = xbmcvfs.listdir(self.themes_dir)
        except Exception:
            return themes
        for filename in sorted(files):
            filename = try_decode(filename)
            if not filename.lower().endswith(THEME_EXT):
                continue
            path = os.path.join(self.themes_dir, filename)
            name, description = self.read_header(path)
            if not name:
                name = filename[:-len(THEME_EXT)]
            preview = path[:-len(THEME_EXT)] + PREVIEW_EXT
            if not xbmcvfs.exists(preview):
                preview = ""
            themes.append({"name": name, "description": description,
                           "path": path, "preview": preview})
        return themes

    @staticmethod
    def read_file(path):
        '''read a theme file as plain text'''
        handle = xbmcvfs.File(path)
        try:
            return try_decode(handle.read())
        finally:
            handle.close()

    @staticmethod
    def write_file(path, text):
        '''write a theme file as plain text'''
        handle = xbmcvfs.File(path, "w")
        try:
            handle.write(text)
            return True
        finally:
            handle.close()

    def parse_theme(self, path):
        '''parses a theme file into its entries'''
        text = self.read_file(path)
        return ast.literal_eval(text)

    def read_header(self, path):
        '''returns name and description of a theme file'''
        try:
            name, description = "", ""
            for entry in self.parse_theme(path):
                if entry[0] == "THEMENAME":
                    name = entry[1]
                elif entry[0] == "DESCRIPTION":
                    description = entry[1]
            return name, description
        except Exception as exc:
            log_exception(__name__, exc)
            return "", ""

    def apply_theme(self, path):
        '''applies all colors of a theme to the skin settings'''
        entries = self.parse_theme(path)
        count = 0
        for entry in entries:
            kind = entry[0]
            if kind == "string":
                xbmc.executebuiltin("Skin.SetString(%s,%s)" % (entry[1], entry[2]))
                count += 1
            elif kind == "bool":
                if str(entry[2]).lower() in ("true", "1", "yes"):
                    xbmc.executebuiltin("Skin.SetBool(%s)" % entry[1])
                else:
                    xbmc.executebuiltin("Skin.Reset(%s)" % entry[1])
                count += 1
            elif kind == "reset":
                xbmc.executebuiltin("Skin.Reset(%s)" % entry[1])
                count += 1
        name, description = self.read_header(path)
        xbmc.executebuiltin("Notification(%s,%s,3000,%s)" % (
            name, LANG["applied"], ""))
        log_msg("color theme %s applied with %s entries" % (name, count))
        return count

    def save_theme(self):
        '''stores the current color settings as a new theme file'''
        name = xbmcgui.Dialog().input(LANG["savelabel"], type=xbmcgui.INPUT_ALPHANUM)
        if not name:
            return
        entries = [("THEMENAME", name), ("DESCRIPTION", LANG["savedesc_new"])]
        for key in self.get_color_keys():
            value = try_decode(xbmc.getInfoLabel("Skin.String(%s)" % key))
            if value:
                entries.append(("string", key, value))
        filename = "".join(c for c in name if c not in '\\/:*?"<>|').strip() or "theme"
        path = os.path.join(self.themes_dir, filename + THEME_EXT)
        counter = 2
        while xbmcvfs.exists(path):
            path = os.path.join(self.themes_dir, "%s %s%s" % (filename, counter, THEME_EXT))
            counter += 1
        self.write_file(path, repr(entries))
        xbmc.executebuiltin("Notification(%s,%s,3000,%s)" % (
            name, LANG["saved"], ""))
        log_msg("color theme %s saved to %s" % (name, path))

    def get_color_keys(self):
        '''collects all color settings used by the available themes'''
        keys = []
        for theme in self.get_themes():
            try:
                for entry in self.parse_theme(theme["path"]):
                    if entry[0] == "string" and entry[1] not in keys:
                        keys.append(entry[1])
            except Exception as exc:
                log_exception(__name__, exc)
        return keys
