#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Search sources (Suchquellen) for the skin search window.

Every source is stored in a skin string pair:

    searchsrc<N>name   visible label of the source row
    searchsrc<N>path   plugin path with the search term appended by the skin

The skin renders one result row per filled slot (1 .. SLOTS).
"""

import os
import re
import threading

import xbmc
import xbmcaddon
import xbmcgui

from .utils import kodi_json, log_msg, log_exception, try_decode

SLOTS = 6

# addons that are known to offer a search endpoint
GUESSES = {
    "plugin.video.youtube":
        "plugin://plugin.video.youtube/search/?q=",
    "plugin.video.tmdb.bingie.helper":
        "plugin://plugin.video.tmdb.bingie.helper?info=search&tmdb_type=both&nextpage=false&query=",
    "plugin.video.themoviedb.helper":
        "plugin://plugin.video.themoviedb.helper?info=search&tmdb_type=both&nextpage=false&query=",
    "plugin.video.multitrailer":
        "plugin://plugin.video.multitrailer/?action=search&query=",
}

ADDON_TYPES = ("xbmc.python.pluginsource", "xbmc.python.script", "xbmc.addon.executable")

# Parameter, über die Addons ihre Suche aufrufen bzw. den Suchbegriff übergeben
ROUTE_KEYS = ("action", "mode", "type", "func", "function", "task", "do", "method", "site")
TERM_KEYS = ("query", "q", "search", "search_string", "searchstring", "search_text",
             "searchtext", "searchterm", "s", "term", "keyword", "keywords", "text")

# übliche Suchadressen von Addons; das Suchwort wird hinten angehängt
SEARCH_TEMPLATES = (
    "plugin://%s/?info=search&query=",
    "plugin://%s/search/?q=",
    "plugin://%s/?action=search&query=",
    "plugin://%s/?query=",
    "plugin://%s/?search=",
)


class SearchSources:
    """manage the addon based search sources of the skin"""

    def __init__(self, params=None):
        self.params = params or {}

    # ---------------------------------------------------------------- helpers
    def _text(self, name, default):
        value = self.params.get(name, "")
        if not value:
            return default
        if "$LOCALIZE[" in value:
            from .skinstrings import localize
            return localize(value)
        return try_decode(value)

    @staticmethod
    def _label(skinstring):
        return xbmc.getInfoLabel("Skin.String(%s)" % skinstring)

    def sources(self):
        """list of (slot, label, path) for every configured source"""
        sources = []
        for index in range(1, SLOTS + 1):
            name = self._label("searchsrc%dname" % index)
            path = self._label("searchsrc%dpath" % index)
            if path:
                sources.append((index, name or path, path))
        return sources

    def free_slot(self):
        used = set(source[0] for source in self.sources())
        for index in range(1, SLOTS + 1):
            if index not in used:
                return index
        return None

    def save(self, index, name, path):
        name = name.replace(",", " ").strip()
        if not name:
            name = path
        xbmc.executebuiltin("Skin.SetString(searchsrc%dname,%s)" % (index, name))
        xbmc.executebuiltin("Skin.SetString(searchsrc%dpath,%s)" % (index, path))

    def remove(self, index):
        xbmc.executebuiltin("Skin.Reset(searchsrc%dname)" % index)
        xbmc.executebuiltin("Skin.Reset(searchsrc%dpath)" % index)

    # ---------------------------------------------------------------- actions
    def manage(self):
        mode = self.params.get("mode", "add").lower()
        try:
            if mode == "edit":
                self.edit_source()
            elif mode == "remove":
                self.remove_source()
            elif mode == "clear":
                self.clear_sources()
            else:
                self.add_source()
        except Exception as exc:
            log_exception(__name__, exc)
            # sichtbar machen: sonst passiert beim Klick scheinbar nichts
            xbmc.executebuiltin("Notification(Suchquellen,%s,5000)" % str(exc)[:120].replace(",", " "))

    def add_source(self):
        """pick an installed addon and store its search path"""
        header = self._text("header", "Addon als Suchquelle hinzufügen")
        slot = self.free_slot()
        if slot is None:
            xbmc.executebuiltin("Notification(%s,%s,4000)" % (
                header, "Alle Plätze sind belegt. Bitte zuerst eine Suchquelle entfernen."))
            return

        addons = self.installed_addons()
        if not addons:
            xbmc.executebuiltin("Notification(%s,%s,4000)" % (
                header, "Keine installierten Addons gefunden."))
            return

        labels = ["%s  (%s)" % (addon["name"], addon["addonid"]) for addon in addons]
        dialog = xbmcgui.Dialog()
        selected = dialog.select(header, labels, useDetails=False)
        del dialog
        if selected is None or selected < 0:
            return

        addon = addons[selected]
        search_path = self.detect_path(addon["addonid"])
        if search_path:
            self.save(slot, addon["name"], search_path)
            xbmc.executebuiltin("Notification(%s,%s,4000)" % (
                header, "Suchadresse automatisch erkannt: %s" % addon["name"]))
            return
        search_path = self.ask_path(addon["addonid"], addon["name"])
        if not search_path:
            return
        self.save(slot, addon["name"], search_path)
        xbmc.executebuiltin("Notification(%s,%s,3000)" % (
            header, "Suchquelle gespeichert: %s" % addon["name"]))

    @staticmethod
    def _listing(path):
        """get a plugin listing (empty list if the path is not usable)"""
        try:
            return kodi_json("Files.GetDirectory",
                             {"directory": path, "media": "files",
                              "properties": ["title"]}, "files") or []
        except Exception:
            return []

    def detect_path(self, addon_id, timeout=25):
        """automatische Erkennung mit Zeitlimit, damit nichts haengen bleibt"""
        result = {"path": ""}

        def worker():
            try:
                result["path"] = self._detect(addon_id)
            except Exception as exc:
                log_exception(__name__, exc)

        xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
        thread = threading.Thread(target=worker)
        thread.daemon = True
        thread.start()
        thread.join(timeout)
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        return result["path"]

    @staticmethod
    def code_candidates(addon_id):
        """read the addon code and look for the search addresses it builds itself"""
        try:
            addon_path = xbmcaddon.Addon(addon_id).getAddonInfo("path")
        except Exception:
            return []
        if not addon_path or not os.path.isdir(addon_path):
            return []
        found = []
        for root, dirs, files in os.walk(addon_path):
            dirs[:] = [d for d in dirs if d not in ("language", "skins", "__pycache__", ".git")]
            for name in files:
                if not name.endswith((".py", ".xml")):
                    continue
                path = os.path.join(root, name)
                try:
                    if os.path.getsize(path) > 500000:
                        continue
                    text = open(path, encoding="utf-8", errors="ignore").read()
                except Exception:
                    continue
                for line in text.split("\n"):
                    low = line.lower()
                    if "search" not in low and "suche" not in low:
                        continue
                    pairs = re.findall(r"([A-Za-z_][A-Za-z_0-9]*)=([A-Za-z_0-9]*)", line)
                    terms = [key for key, _value in pairs if key in TERM_KEYS]
                    routes = [(key, value) for key, value in pairs
                              if key in ROUTE_KEYS and "search" in value.lower()]
                    for route_key, route_value in routes:
                        for term in terms:
                            candidate = "?%s=%s&%s=" % (route_key, route_value, term)
                            if candidate not in found:
                                found.append(candidate)
                    for term in terms:
                        candidate = "?%s=" % term
                        if candidate not in found:
                            found.append(candidate)
                if len(found) > 8:
                    return found[:8]
        log_msg("search sources: %d candidates found in %s" % (len(found), addon_id))
        return found

    def _detect(self, addon_id):
        """try the search addresses of an addon and use the first that delivers items"""
        root = self._listing("plugin://%s/" % addon_id)
        candidates = []
        if addon_id in GUESSES:
            candidates.append(GUESSES[addon_id])
        # zuerst, was im Code des Addons steht, danach die allgemeinen Muster
        candidates += ["plugin://%s/%s" % (addon_id, suffix)
                       for suffix in self.code_candidates(addon_id)]
        candidates += [template % addon_id for template in SEARCH_TEMPLATES]
        # manche Addons brauchen zusätzlich eine Seitenzahl
        extended = []
        for candidate in candidates:
            extended.append(candidate)
            if "?" in candidate and "page=" not in candidate:
                extended.append(candidate + "&page=1")
        for candidate in extended:
            listing = self._listing("%sbaum" % candidate)
            if not listing:
                continue
            # gleiche Antwort wie das Addon-Hauptmenue => Parameter wird ignoriert
            files = [i.get("file") for i in listing]
            if len(listing) == len(root) and files == [i.get("file") for i in root]:
                continue
            # nur echte Treffer: mindestens ein Eintrag, der nicht im Hauptmenü steht
            if not [f for f in files if f not in [i.get("file") for i in root]]:
                continue
            log_msg("search sources: detected %s for %s" % (candidate, addon_id))
            return candidate
        return ""

    def ask_path(self, addon_id, addon_name, detected=""):
        """ask the user for the search path of the selected addon"""
        header = self._text("headerpath", "Suchadresse für die Suche dieses Addons")
        default = detected or GUESSES.get(addon_id, "plugin://%s/?info=search&query=" % addon_id)
        dialog = xbmcgui.Dialog()
        # Kodi 21+ kennt xbmcgui.INPUT_ALPHA nicht mehr, die Standardeingabe ist Text
        value = dialog.input("%s\n%s" % (header, addon_name), default)
        del dialog
        return try_decode(value).strip() if value else ""

    def edit_source(self):
        """change address or name of one source, or remove it"""
        try:
            slot = int(self.params.get("slot", "0"))
        except ValueError:
            slot = 0
        if slot < 1 or slot > SLOTS:
            return
        name = self._label("searchsrc%dname" % slot)
        path = self._label("searchsrc%dpath" % slot)
        if not path:
            return
        header = self._text("headeredit", "Suchquelle bearbeiten")
        dialog = xbmcgui.Dialog()
        choice = dialog.select("%s\n%s" % (header, name),
                               ["Adresse ändern", "Namen ändern", "Quelle entfernen"])
        if choice is None or choice < 0:
            del dialog
            return
        if choice == 0:
            path = dialog.input("Suchadresse", path) or path
            del dialog
            self.save(slot, name, try_decode(path).strip())
            xbmc.executebuiltin("Notification(%s,%s,3000)" % (header, "Adresse gespeichert"))
        elif choice == 1:
            name = dialog.input("Name der Quelle", name) or name
            del dialog
            self.save(slot, try_decode(name).strip(), path)
            xbmc.executebuiltin("Notification(%s,%s,3000)" % (header, "Name gespeichert"))
        else:
            del dialog
            self.remove(slot)
            xbmc.executebuiltin("Notification(%s,%s,3000)" % (header, "Suchquelle entfernt"))

    def remove_source(self):
        """remove one of the configured sources"""
        header = self._text("headerremove", "Suchquelle entfernen")
        sources = self.sources()
        if not sources:
            xbmc.executebuiltin("Notification(%s,%s,3000)" % (
                header, "Es ist keine Suchquelle eingerichtet."))
            return
        labels = ["%s  (%s)" % (name, path) for _index, name, path in sources]
        dialog = xbmcgui.Dialog()
        selected = dialog.select(header, labels, useDetails=False)
        del dialog
        if selected is None or selected < 0:
            return
        self.remove(sources[selected][0])
        xbmc.executebuiltin("Notification(%s,%s,3000)" % (header, "Suchquelle entfernt"))

    def clear_sources(self):
        """drop all configured sources"""
        header = self._text("headerclear", "Alle Suchquellen löschen")
        dialog = xbmcgui.Dialog()
        if not dialog.yesno(header, "Alle eingerichteten Suchquellen entfernen?"):
            del dialog
            return
        del dialog
        for index, _name, _path in self.sources():
            self.remove(index)
            log_msg("search source %d removed" % index)
        xbmc.executebuiltin("Notification(%s,%s,3000)" % (header, "Alle Suchquellen gelöscht"))

    # ------------------------------------------------------------ addon list
    @staticmethod
    def addon_type(addon_id):
        """type of an installed addon (e.g. xbmc.python.pluginsource)"""
        try:
            return xbmcaddon.Addon(addon_id).getAddonInfo("type") or ""
        except Exception:
            return ""

    @classmethod
    def installed_addons(cls):
        """all enabled addons that may offer a search"""
        addons = []
        result = kodi_json("Addons.GetAddons",
                           {"enabled": True, "properties": ["name", "version", "path"]},
                           "addons")
        for addon in result or []:
            addon_id = addon.get("addonid", "")
            if not addon_id or addon_id.startswith(("script.module.", "resource.",
                                                   "skin.", "repository.",
                                                   "metadata.", "service.", "xbmc.")):
                continue
            addon_type = cls.addon_type(addon_id)
            if addon_type and addon_type not in ADDON_TYPES:
                continue
            addons.append({"addonid": addon_id,
                           "name": try_decode(addon.get("name") or addon_id)})
        addons.sort(key=lambda item: item["name"].lower())
        log_msg("search sources: %d addons available" % len(addons))
        return addons
