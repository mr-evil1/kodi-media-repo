#!/usr/bin/python
# coding: utf8

import xbmc
import xbmcgui
import xbmcvfs
import os
import simplejson as json
from resources.lib.helper import *

RESET_VALUE = '0'
PLAY_MARKERS = ('scoutmovie', 'scoutepisode', 'scoutplay', 'info=play',
                'action=play')
# Endungen duerfen nur am Ende des Pfads gelten: "video.moviescout" enthaelt
# naemlich auch ".mov", sonst galt jeder MovieScout-Link als Abspiellink.
PLAY_SUFFIXES = ('.mp4', '.mkv', '.m3u8', '.avi', '.mov', '.wmv', '.ts',
                 '.flv', '.webm')


SERIES_MARKERS = ('action=seasons', 'action=season', 'action=episodes',
                  'action=episode', 'action=tvshow', 'action=series',
                  'tvshowid=', '/tvshows/')


def is_play_link(path):
    """Ist der Link ein echter Abspiellink (Film/Folge) und kein Ordner?"""
    low = (path or '').lower()
    if any(marker in low for marker in PLAY_MARKERS):
        return True
    return low.split('?')[0].rstrip('/').endswith(PLAY_SUFFIXES)


def is_series_link(path):
    """Link einer Serie: fuehrt zur Staffel-/Folgenliste, spielt nichts ab."""
    low = (path or '').lower()
    return any(marker in low for marker in SERIES_MARKERS)


def open_videos_path(path):
    """Oeffnet einen Ordner (Serie) in der Video-Ansicht.

    Zwei Wege, weil der Aufruf je nach Geraet unterschiedlich ankommt: erst
    der normale Befehl, danach - falls die Startseite noch steht - derselbe
    Aufruf ueber die Fernsteuerung von Kodi."""
    xbmc.executebuiltin('ActivateWindow(Videos,"%s",return)' % path)
    for _ in range(6):
        xbmc.sleep(250)
        if not visible("Window.IsActive(home)"):
            return True
    log("play: Videos-Fenster nicht geoeffnet, zweiter Versuch", force=True)
    request = {'jsonrpc': '2.0', 'id': 1,
               'method': 'GUI.ActivateWindow',
               'params': {'window': 'videos', 'parameters': [path]}}
    try:
        xbmc.executeJSONRPC(json.dumps(request))
    except Exception as error:
        log("play: zweiter Versuch fehlgeschlagen %s" % error, force=True)
        return False
    return True
THUMBSUP_VALUE_SETTING_ID = 'ThumbsUpRateValue'
THUMBSDOWN_VALUE_SETTING_ID = 'ThumbsDownRateValue'
NEW_TAG = 'mylist'


def ismylist(params):
    # gets item DBID and DBType (str)
    item_id = xbmc.getInfoLabel('ListItem.DBID')
    item_type = xbmc.getInfoLabel('ListItem.DBType')

    if item_id and item_type:
        # prepare get tag query
        item_tags = {'jsonrpc': '2.0', 'id': 'IsInMyList',
                    'method': 'VideoLibrary.Get' + item_type + 'Details',
                    'params': {item_type + 'id': int(item_id),
                               'properties': ['tag']}}
        # get item tags
        item_tags = json.loads(xbmc.executeJSONRPC(json.dumps(item_tags)))
        if 'result' in item_tags:
            # extract tags to list
            item_tags = item_tags['result'][item_type + 'details']['tag']

            # if in my list -> set window property
            if NEW_TAG in item_tags:
                xbmcgui.Window(10000).setProperty("IsInMyList", item_id)

def togglemylist(params):
    # gets item DBID and DBType (str)
    item_id = xbmc.getInfoLabel('ListItem.DBID')
    item_type = xbmc.getInfoLabel('ListItem.DBType')

    if item_id and item_type:
        # prepare get tag query
        item_tags = {'jsonrpc': '2.0', 'id': 'TagMyList',
                    'method': 'VideoLibrary.Get' + item_type + 'Details',
                    'params': {item_type + 'id': int(item_id),
                               'properties': ['tag']}}
        # get item tags
        item_tags = json.loads(xbmc.executeJSONRPC(json.dumps(item_tags)))
        if 'result' in item_tags:
            # extract tags to list
            item_tags = item_tags['result'][item_type + 'details']['tag']

            # remove NEW_TAG
            if NEW_TAG in item_tags:
                item_tags.remove(NEW_TAG)

            # NEW_TAG not in list - let's add it
            else:
                item_tags.append(NEW_TAG)
                xbmcgui.Window(10000).setProperty("IsInMyList", item_id)

            # prepare set tag query
            json_query = {'jsonrpc': '2.0', 'id': 'TagMyList',
                         'method': 'VideoLibrary.Set' + item_type + 'Details',
                         'params': {item_type + 'id': int(item_id),
                                    'tag': item_tags}}
            # submit json query
            xbmc.executeJSONRPC(json.dumps(json_query))
            
def ratetitle(params):
    action = params.get("rateaction")
    action_dict = {'like': xbmc.getInfoLabel("Skin.String(%s)" % THUMBSUP_VALUE_SETTING_ID),
                   'dislike': xbmc.getInfoLabel("Skin.String(%s)" % THUMBSDOWN_VALUE_SETTING_ID),
                   'reset': RESET_VALUE}

    if action in action_dict:
        # gets item DBID and DBType (str)
        item_id = xbmc.getInfoLabel('ListItem.DBID')
        item_type = xbmc.getInfoLabel('ListItem.DBType')

        if item_id and item_type:
            # prepare json query
            json_query = {'jsonrpc': '2.0', 'id': 'RateTitle',
                         'method': 'VideoLibrary.Set' + item_type + 'Details',
                         'params': {item_type + 'id': int(item_id),
                                    'userrating': int(action_dict[action])}}        

            # submit json query
            xbmc.executeJSONRPC(json.dumps(json_query))
            xbmcgui.Window(10000).setProperty("RateTitle", item_id)
            xbmcgui.Window(10000).setProperty("RateTitle.Action", action)

def gettvshowid(params):
    """extracts tvshowid from kodidb"""
    episode_query = json_call('VideoLibrary.GetEpisodeDetails',
                              properties=['tvshowid'],
                              params={'episodeid': int(params.get('dbid'))})
    try:
        tvshow_id = str(episode_query['result']['episodedetails']['tvshowid'])
        output = params.get("output", "ListItem.TVShowID")
        xbmcgui.Window(10000).setProperty(output, tvshow_id)
    except Exception:
        log('Could not get the TV show ID')
        return

def play(params):
    """Startet die Wiedergabe des gewaehlten Films.

    Der Pfad kommt vom Addon selbst (plugin://...). Gegenueber PlayMedia im
    Skin hat das zwei Vorteile: der Start laeuft in einem eigenen Thread,
    damit die Oberflaeche bedienbar bleibt, und jeder Schritt landet im Log,
    sodass ein Fehlschlag nachvollziehbar ist."""
    source = params.get("source", "")
    path = ""
    is_folder = False

    if source == "hero":
        path = xbmc.getInfoLabel("Window(Home).Property(NFHeroPath)")
        # Auf der Buehne liegt der Fokus auf einem Knopf, nicht auf einer Reihe.
        # ListItem.IsFolder wuerde dort den zuletzt markierten Serien-Eintrag
        # melden, der Film startete dann faelschlich als Ordner und es passierte
        # gar nichts. Deshalb gilt hier nur, was beim Fuellen mitgegeben wurde.
        is_folder = xbmc.getInfoLabel(
            "Window(Home).Property(NFHeroFolder)") == "1"
    else:
        path = xbmc.getInfoLabel("ListItem.FileNameAndPath")
        if not path:
            path = xbmc.getInfoLabel("ListItem.FolderPath")
        if not path and source == "dialog":
            path = xbmc.getInfoLabel("Window(Home).Property(NFHeroPath)")
        is_folder = visible("ListItem.IsFolder")

    path = (path or "").strip().strip('"')

    # Serien sind Ordner, keine Abspiellinks. Der Klick auf das Poster unten
    # oeffnet sie und zeigt das Episodenmenue - der Buehnen-Knopf macht es
    # jetzt genauso. Filme haben einen Abspiellink und starten weiter direkt.
    if source == "hero" and not is_folder and is_series_link(path) \
            and not is_play_link(path):
        is_folder = True

    log("play: source=%s folder=%s path=%s" % (source, is_folder, path), force=True)

    if not path:
        log("play: kein Pfad fuer source=%s" % source, force=True)
        return

    if visible("Window.IsActive(movieinformation) | Window.IsActive(DialogVideoInfo.xml)"):
        xbmc.executebuiltin("Dialog.Close(movieinformation)")

    if is_folder:
        # Ordner (z.B. Serie) lassen sich nicht direkt abspielen: Liste
        # oeffnen - genau wie beim Klick auf das Poster.
        # Genau den Link nehmen, der auch im Poster steckt - der oeffnet die
        # Staffel-/Folgenliste. Ein selbst gebauter "?info=seasons"-Link
        # landet beim Addon nur im Hauptmenue.
        log("play: oeffne Ordner %s" % path, force=True)
        open_videos_path(path)
        return

    if path.startswith("plugin://"):
        # Plugin-Links muss Kodi selbst aufloesen, ein direkter Player-Aufruf
        # scheitert bei manchen Addons stillschweigend.
        xbmc.executebuiltin('PlayMedia("%s")' % path)
        log("play: Wiedergabe angestossen (Plugin)", force=True)
        return

    try:
        li = xbmcgui.ListItem(path=path)
        li.setProperty("IsPlayable", "true")
        xbmc.Player().play(item=li)
        log("play: Wiedergabe angestossen", force=True)
    except Exception as error:
        log("play: Player-Fehler %s" % error, force=True)
        xbmc.executebuiltin('PlayMedia("%s")' % path)


def playtrailer(params):
    """auto play first youtube trailer windowed/fullscreen, tvshows local grab integrated
            (will later seperate methods)"""
    if not visible("!String.IsEmpty(Window(Home).Property(traileractionbusy)) "):
        title = params.get("title", "")
        trailer_mode = params.get("mode", "windowed").replace("auto_", "")
        local = params.get("local", "") == "true"
        allow_local_tv_show = params.get("tvshow", "") == "true"
        item_control_id = params.get("control", "System.CurrentControlID")
        allow_youtube = params.get("youtube", "true") == "true"
        list_item_title = xbmc.getInfoLabel("ListItem.Title")
        local_language = ""
        if local:
            local_language = " " + xbmc.getInfoLabel("System.Language")
        li_trailer = ""

        if allow_local_tv_show:
            item_path = xbmc.getInfoLabel(
                'Container({}).ListItem().Path'.format(xbmc.getInfoLabel('%s' % item_control_id)))
            if not item_path:
                item_path = xbmc.getInfoLabel(
                    'Container({}).ListItem.Property(originalpath)'.format(
                        xbmc.getInfoLabel('%s' % item_control_id)))
            folder_name = xbmc.getInfoLabel(
                'Container({}).ListItem().FolderName'.format(xbmc.getInfoLabel('%s' % item_control_id)))
            if item_path:
                dirs, files = xbmcvfs.listdir(item_path)
                for filename in files:
                    folder_name_trailer = folder_name.lower() + "-trailer"
                    file_name_noext = os.path.splitext(filename)[0].lower()
                    if file_name_noext.endswith("-trailer") and \
                            (file_name_noext == "tvshow-trailer" or file_name_noext == folder_name_trailer):
                        li_trailer = os.path.join(item_path, filename)

        if not li_trailer and title and allow_youtube \
                and not visible("Container.Scrolling | Container.OnNext"
                                          " | Container.OnPrevious | Player.HasVideo"):
            tvshow_str = ""
            if allow_local_tv_show:
                tvshow_str = " tv show"
            li_trailer = get_first_youtube_video("%s%s%s trailer" % (title, tvshow_str, local_language))

        xbmcgui.Window(10000).setProperty("traileractionbusy", "traileractionbusy")
        if li_trailer and not visible("Container.Scrolling | Container.OnNext "
                                                "| Container.OnPrevious | Player.HasVideo") \
                and list_item_title == xbmc.getInfoLabel("ListItem.Title"):
            if trailer_mode == "fullscreen" or trailer_mode == "background":
                xbmc.executebuiltin('PlayMedia("%s")' % li_trailer)
            else:
                xbmc.executebuiltin('PlayMedia("%s",1)' % li_trailer)
            xbmcgui.Window(10000).setProperty("TrailerPlaying", trailer_mode)
        xbmcgui.Window(10000).clearProperty("traileractionbusy")
