# -*- coding: utf-8 -*-
import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
from resources.lib import netzkino

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def add_items(items):
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)

    directory_items = []
    for item in items:
        title = item.get('title', '')
        url = item.get('url', '')
        is_playable = item.get('is_playable', False)
        next_func = item.get('next_func', '')

        list_item = xbmcgui.ListItem(label=title)
        
        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(title)
        
        info_dict = {'title': title}

        if item.get('plot'):
            info_tag.setPlot(item['plot'])
            info_dict['plot'] = item['plot']

        if item.get('year'):
            try:
                year_int = int(item['year'])
                info_tag.setYear(year_int)
                info_dict['year'] = year_int
            except ValueError:
                pass

        if item.get('genre'):
            genres = item['genre']
            if isinstance(genres, list):
                info_tag.setGenres(genres)
                info_dict['genre'] = ' / '.join(genres)
            else:
                info_tag.setGenres([str(genres)])
                info_dict['genre'] = str(genres)

        if item.get('duration'):
            try:
                dur = int(item['duration'])
                info_tag.setDuration(dur)
                info_dict['duration'] = dur
            except ValueError:
                pass

        if item.get('rating'):
            try:
                rat = float(item['rating'])
                info_tag.setRating(rat)
                info_dict['rating'] = rat
            except ValueError:
                pass

        if item.get('director'):
            dirs = item['director']
            if isinstance(dirs, list):
                info_tag.setDirectors(dirs)
                info_dict['director'] = ' / '.join(dirs)
            else:
                info_tag.setDirectors([str(dirs)])
                info_dict['director'] = str(dirs)

        if item.get('mediatype'):
            info_tag.setMediaType(item['mediatype'])
            info_dict['mediatype'] = item['mediatype']

        list_item.setInfo('video', info_dict)

        art = {}
        if item.get('poster'):
            art['poster'] = item['poster']
            art['thumb'] = item['poster']
        if item.get('fanart'):
            art['fanart'] = item['fanart']
        list_item.setArt(art)

        if is_playable:
            list_item.setProperty('IsPlayable', 'true')
            target_url = build_url({'action': 'play', 'url': url, 'season': item.get('season', 0)})
            is_folder = False
        else:
            target_url = build_url({'action': next_func, 'url': url})
            is_folder = True

        directory_items.append((target_url, list_item, is_folder))

    xbmcplugin.addDirectoryItems(HANDLE, directory_items)
    xbmcplugin.endOfDirectory(HANDLE)

def play(url, season=0):
    hosters = netzkino.get_hosters(url=url, season=season)
    if hosters:
        stream_url = hosters[0][1]
        play_item = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(HANDLE, True, play_item)
    else:
        xbmcgui.Dialog().notification('Netzkino', 'Stream konnte nicht geladen werden', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    url = params.get('url', '')

    if not action:
        xbmcplugin.setContent(HANDLE, 'movies')
        add_items(netzkino.load())
    elif action == 'showEntries':
        xbmcplugin.setContent(HANDLE, 'movies')
        add_items(netzkino.showEntries(url))
    elif action == 'showGenres':
        xbmcplugin.setContent(HANDLE, 'genres')
        add_items(netzkino.showGenres())
    elif action == 'clearCache':
        netzkino.clear_cache()
        xbmcgui.Dialog().notification('Netzkino', 'Cache geleert – beim nächsten Aufruf werden frische Daten geladen.', xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(HANDLE, False)
    elif action == 'showSeasons':
        xbmcplugin.setContent(HANDLE, 'tvshows')
        add_items(netzkino.showSeasons(url))
    elif action == 'showEpisodes':
        xbmcplugin.setContent(HANDLE, 'episodes')
        add_items(netzkino.showEpisodes(url))
    elif action == 'search':
        xbmcplugin.setContent(HANDLE, 'movies')
        dialog = xbmcgui.Dialog()
        search_term = dialog.input('Netzkino Suche', type=xbmcgui.INPUT_ALPHANUM)
        if search_term:
            add_items(netzkino.search(query=search_term))
        else:
            xbmcplugin.endOfDirectory(HANDLE, False)
    elif action == 'play':
        season = params.get('season', 0)
        play(url, season)

if __name__ == '__main__':
    main()
